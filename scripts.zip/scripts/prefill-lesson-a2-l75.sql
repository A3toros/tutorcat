-- =========================================
-- Pre-fill Database with Sample Lesson Data
-- A2-L75: Talking About Pain
-- =========================================

DELETE FROM grammar_sentences WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'A2-L75');
DELETE FROM vocabulary_items WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'A2-L75');
DELETE FROM lesson_activities WHERE lesson_id = 'A2-L75';
DELETE FROM lessons WHERE id = 'A2-L75';

INSERT INTO lessons (id, level, lesson_number, topic) VALUES
('A2-L75', 'A2', 75, 'Talking About Pain')
ON CONFLICT (id) DO UPDATE SET topic = EXCLUDED.topic;

DO $$
DECLARE
    lesson_id_var TEXT := 'A2-L75';
    activity_id_var UUID;
BEGIN
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'warm_up_speaking', 1, 'Describe Pain', 'Talk about pain', '{"prompt": "How can you explain pain to a doctor?"}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_intro', 2, 'Pain Words', 'Learn words about pain', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'pain', 'ความเจ็บปวด', NULL),
    (activity_id_var, 'hurt', 'เจ็บ', NULL),
    (activity_id_var, 'sore', 'ปวดเมื่อย', NULL),
    (activity_id_var, 'sharp', 'แหลม/เจ็บแปลบ', NULL),
    (activity_id_var, 'dull', 'ตื้อ/ไม่รุนแรง', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_matching_drag', 3, 'Match Pain Words', 'Match pain words', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'pain', 'ความเจ็บปวด', NULL),
    (activity_id_var, 'hurt', 'เจ็บ', NULL),
    (activity_id_var, 'sore', 'ปวดเมื่อย', NULL),
    (activity_id_var, 'sharp', 'แหลม/เจ็บแปลบ', NULL),
    (activity_id_var, 'dull', 'ตื้อ/ไม่รุนแรง', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 4, 'Complete the Sentences 1', 'Fill with the correct word', '{"text": "I feel ___. My arm ___. It is a ___ pain.", "blanks": [{"id": "blank1", "text": "pain", "options": ["pain", "hurt", "sore", "sharp"], "correctAnswer": "pain"}, {"id": "blank2", "text": "hurts", "options": ["hurts", "sore", "dull", "sharp"], "correctAnswer": "hurts"}, {"id": "blank3", "text": "sharp", "options": ["sharp", "dull", "sore", "pain"], "correctAnswer": "sharp"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 5, 'Complete the Sentences 2', 'Fill with the correct word', '{"text": "Yesterday it was ___. Today it is ___.", "blanks": [{"id": "blank1", "text": "dull", "options": ["dull", "sharp", "sore", "pain"], "correctAnswer": "dull"}, {"id": "blank2", "text": "sore", "options": ["sore", "dull", "hurt", "pain"], "correctAnswer": "sore"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_explanation', 6, 'Can / Questions', 'Ask and answer about pain', '{"rules": "Use can to ask for help; use questions to locate pain.\n- Can you show me where it hurts?\n- Does it hurt here?\nShort: Yes, it does. No, it doesn''t.", "examples": ["Can you show me where it hurts?", "Does it hurt here?", "Can you rate the pain?", "Can you sit if you feel sore?", "Does it feel sharp or dull?"]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 7, 'Build Sentences 1', 'Arrange words', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'Can you show me where it hurts', 'Can you show me where it hurts?', '["Can", "you", "show", "me", "where", "it", "hurts?"]'::jsonb),
    (activity_id_var, 'Does it hurt here', 'Does it hurt here?', '["Does", "it", "hurt", "here?"]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 8, 'Build Sentences 2', 'Arrange words', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'Can you rate the pain', 'Can you rate the pain?', '["Can", "you", "rate", "the", "pain?"]'::jsonb),
    (activity_id_var, 'Does it feel sharp or dull', 'Does it feel sharp or dull?', '["Does", "it", "feel", "sharp", "or", "dull?"]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'speaking_practice', 9, 'Talk About Pain', 'Practice describing pain', '{"prompts": ["How can you explain pain to a doctor?", "Can you show where it hurts?", "Can you describe the pain clearly?", "Can you rate the pain from 1 to 10?", "What can you say about your symptoms?"]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (
      lesson_id,
      activity_type,
      activity_order,
      title,
      description,
      content
    ) VALUES (
      'A2-L75',
      'speaking_improvement',
      10,
      'Speaking Improvement',
      'Read the improved version of your speech',
      '{"type": "speaking_improvement", "similarityThreshold": 70}'::jsonb
    );
END $$;

