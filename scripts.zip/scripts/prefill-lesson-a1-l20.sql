-- =========================================
-- Pre-fill Database with Sample Lesson Data
-- A1-L20: Transport (car, bus, train)
-- =========================================

DELETE FROM grammar_sentences WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'A1-L20');
DELETE FROM vocabulary_items WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'A1-L20');
DELETE FROM lesson_activities WHERE lesson_id = 'A1-L20');
DELETE FROM lessons WHERE id = 'A1-L20';

INSERT INTO lessons (id, level, lesson_number, topic) VALUES
('A1-L20', 'A1', 20, 'Transport (car, bus, train)')
ON CONFLICT (id) DO UPDATE SET topic = EXCLUDED.topic;

DO $$
DECLARE
    lesson_id_var TEXT := 'A1-L20';
    activity_id_var UUID;
BEGIN
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'warm_up_speaking', 1, 'Travel', 'Talk about transport', '{"prompt": "Do you take the bus?"}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_intro', 2, 'Transport Words', 'Learn transport words', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'car', 'รถยนต์', NULL),
    (activity_id_var, 'bus', 'รถบัส', NULL),
    (activity_id_var, 'train', 'รถไฟ', NULL),
    (activity_id_var, 'ticket', 'ตั๋ว', NULL),
    (activity_id_var, 'driver', 'คนขับรถ', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_matching_drag', 3, 'Match Transport Words', 'Match transport words', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'car', 'รถยนต์', NULL),
    (activity_id_var, 'bus', 'รถบัส', NULL),
    (activity_id_var, 'train', 'รถไฟ', NULL),
    (activity_id_var, 'ticket', 'ตั๋ว', NULL),
    (activity_id_var, 'driver', 'คนขับรถ', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 4, 'Complete the Sentences 1', 'Fill with the correct word', '{"text": "I take the ___. The ___ is kind.", "blanks": [{"id": "blank1", "text": "bus", "options": ["bus", "car", "train", "ticket"], "correctAnswer": "bus"}, {"id": "blank2", "text": "driver", "options": ["driver", "ticket", "train", "car"], "correctAnswer": "driver"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 5, 'Complete the Sentences 2', 'Fill with the correct word', '{"text": "I buy a ___. I take the ___.", "blanks": [{"id": "blank1", "text": "ticket", "options": ["ticket", "driver", "bus", "train"], "correctAnswer": "ticket"}, {"id": "blank2", "text": "train", "options": ["train", "car", "bus", "ticket"], "correctAnswer": "train"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_explanation', 6, 'Can for Ability', 'Say what you can do', '{"rules": "Use can to talk about ability.\n- I can drive a car.\n- I can take a bus.\nAsk: Can you drive?", "examples": ["I can drive a car.", "I can take a bus.", "She can take a train.", "Can you drive?", "Can you buy a ticket?"]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 7, 'Build Sentences 1', 'Arrange words', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'I can drive a car', 'I can drive a car.', '["I", "can", "drive", "a", "car."]'::jsonb),
    (activity_id_var, 'I can take a bus', 'I can take a bus.', '["I", "can", "take", "a", "bus."]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 8, 'Build Sentences 2', 'Arrange words', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'She can take a train', 'She can take a train.', '["She", "can", "take", "a", "train."]'::jsonb),
    (activity_id_var, 'Can you drive', 'Can you drive?', '["Can", "you", "drive?"]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'speaking_practice', 9, 'Talk About Transport', 'Practice can/ability', '{"prompts": ["Do you take the bus?", "Can you drive?", "Do you like trains?", "Do you buy a ticket?", "Is the driver kind?"]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (
      lesson_id,
      activity_type,
      activity_order,
      title,
      description,
      content
    ) VALUES (
      'A1-L20',
      'speaking_improvement',
      10,
      'Speaking Improvement',
      'Read the improved version of your speech',
      '{"type": "speaking_improvement", "similarityThreshold": 70}'::jsonb
    );
END $$;

