-- =========================================
-- Pre-fill Database with Sample Lesson Data
-- B1-L11: Daily Life Changes
-- =========================================

DELETE FROM grammar_sentences WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'B1-L11');
DELETE FROM vocabulary_items WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'B1-L11');
DELETE FROM lesson_activities WHERE lesson_id = 'B1-L11';
DELETE FROM lessons WHERE id = 'B1-L11';

INSERT INTO lessons (id, level, lesson_number, topic) VALUES
('B1-L11', 'B1', 11, 'Daily Life Changes')
ON CONFLICT (id) DO UPDATE SET topic = EXCLUDED.topic;

DO $$
DECLARE
    lesson_id_var TEXT := 'B1-L11';
    activity_id_var UUID;
BEGIN
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'warm_up_speaking', 1, 'Life Changes', 'Talk about changes in daily life', '{"prompt": "What change did you make recently that really helped you?"}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_intro', 2, 'Change Words', 'Learn vocabulary about life changes and habits', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'routine', 'กิจวัตร', NULL),
    (activity_id_var, 'adjust', 'ปรับ', NULL),
    (activity_id_var, 'improve', 'ปรับปรุง', NULL),
    (activity_id_var, 'habit', 'นิสัย', NULL),
    (activity_id_var, 'change', 'เปลี่ยนแปลง', NULL);

    -- Vocabulary Matching
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_matching_drag', 3, 'Match Change Words', 'Match words with meanings', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'routine', 'กิจวัตร', NULL),
    (activity_id_var, 'adjust', 'ปรับ', NULL),
    (activity_id_var, 'improve', 'ปรับปรุง', NULL),
    (activity_id_var, 'habit', 'นิสัย', NULL),
    (activity_id_var, 'change', 'เปลี่ยนแปลง', NULL);

    -- Vocabulary Fill Blanks
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 4, 'Complete the Sentences 1', 'Fill with the correct word', '{"text": "I adjusted my morning ___. This small ___ improved my day. A new ___ can change everything.", "blanks": [{"id": "blank1", "text": "routine", "options": ["routine", "habit", "improve", "adjust"], "correctAnswer": "routine"}, {"id": "blank2", "text": "change", "options": ["change", "habit", "adjust", "improve"], "correctAnswer": "change"}, {"id": "blank3", "text": "habit", "options": ["habit", "change", "adjust", "improve"], "correctAnswer": "habit"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 5, 'Complete the Sentences 2', 'Fill with the correct word', '{"text": "I ___ to new hours. This helped me ___. My daily ___ is better now.", "blanks": [{"id": "blank1", "text": "adjust", "options": ["adjust", "improve", "change", "habit"], "correctAnswer": "adjust"}, {"id": "blank2", "text": "improve", "options": ["improve", "adjust", "habit", "routine"], "correctAnswer": "improve"}, {"id": "blank3", "text": "routine", "options": ["routine", "improve", "habit", "change"], "correctAnswer": "routine"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    -- Grammar Explanation: Present Perfect (experience)
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_explanation', 6, 'Present Perfect for Life Changes', 'Use have/has + past participle to talk about recent changes and experiences', '{"rules": "Present perfect (have/has + past participle) to describe life changes and recent experiences without a specific time:\\n- I have changed my routine.\\n- She has adjusted her schedule.\\n- They have improved their habits.\\nUse for experiences up to now and recent results. Avoid specific past times (use past simple for that).", "examples": ["I have changed my morning routine.", "She has improved her study habits.", "We have adjusted to a new schedule.", "He has formed a new habit.", "They have seen a big change in energy."]}'::jsonb)
    RETURNING id INTO activity_id_var;

    -- Grammar Sentences 1
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 7, 'Build Sentences 1', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'I have changed my morning routine', 'I have changed my morning routine', '["I", "have", "changed", "my", "morning", "routine"]'::jsonb),
    (activity_id_var, 'She has improved her study habits', 'She has improved her study habits', '["She", "has", "improved", "her", "study", "habits"]'::jsonb);

    -- Grammar Sentences 2
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 8, 'Build Sentences 2', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'We have adjusted to a new schedule', 'We have adjusted to a new schedule', '["We", "have", "adjusted", "to", "a", "new", "schedule"]'::jsonb),
    (activity_id_var, 'They have seen a big change in energy', 'They have seen a big change in energy', '["They", "have", "seen", "a", "big", "change", "in", "energy"]'::jsonb);

    -- Speaking Practice
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'speaking_practice', 9, 'Talk About Changes', 'Practice talking about life changes and habits', '{"prompts": ["What change did you make recently that really helped you?", "Which habit have you kept the longest and why?", "Tell me about a small change you are proud of."]}'::jsonb)
    RETURNING id INTO activity_id_var;

    -- Speaking Improvement
    INSERT INTO lesson_activities (
      lesson_id,
      activity_type,
      activity_order,
      title,
      description,
      content
    ) VALUES (
      'B1-L11',
      'speaking_improvement',
      10,
      'Speaking Improvement',
      'Read the improved version of your speech',
      '{"type": "speaking_improvement", "similarityThreshold": 70}'::jsonb
    );
END $$;


