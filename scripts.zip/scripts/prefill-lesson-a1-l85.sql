-- =========================================
-- Pre-fill Database with Sample Lesson Data
-- A1-L85: Hobbies & Free Time
-- =========================================

DELETE FROM grammar_sentences WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'A1-L85');
DELETE FROM vocabulary_items WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'A1-L85');
DELETE FROM lesson_activities WHERE lesson_id = 'A1-L85';
DELETE FROM lessons WHERE id = 'A1-L85';

INSERT INTO lessons (id, level, lesson_number, topic) VALUES
('A1-L85', 'A1', 85, 'Hobbies & Free Time')
ON CONFLICT (id) DO UPDATE SET topic = EXCLUDED.topic;

DO $$
DECLARE
    lesson_id_var TEXT := 'A1-L85';
    activity_id_var UUID;
BEGIN
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'warm_up_speaking', 1, 'Hobbies', 'Talk about hobbies', '{"prompt": "Do you like to read?"}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_intro', 2, 'Hobby Words', 'Learn hobby words', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'read', 'อ่าน', NULL),
    (activity_id_var, 'draw', 'วาดภาพ', NULL),
    (activity_id_var, 'sing', 'ร้องเพลง', NULL),
    (activity_id_var, 'dance', 'เต้นรำ', NULL),
    (activity_id_var, 'play', 'เล่น', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_matching_drag', 3, 'Match Hobby Words', 'Match hobby words', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'read', 'อ่าน', NULL),
    (activity_id_var, 'draw', 'วาดภาพ', NULL),
    (activity_id_var, 'sing', 'ร้องเพลง', NULL),
    (activity_id_var, 'dance', 'เต้นรำ', NULL),
    (activity_id_var, 'play', 'เล่น', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 4, 'Complete the Sentences 1', 'Fill with the correct word', '{"text": "I like to ___. I like to ___.", "blanks": [{"id": "blank1", "text": "read", "options": ["read", "draw", "sing", "dance"], "correctAnswer": "read"}, {"id": "blank2", "text": "draw", "options": ["draw", "sing", "dance", "play"], "correctAnswer": "draw"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 5, 'Complete the Sentences 2', 'Fill with the correct word', '{"text": "I like to ___. I like to ___.", "blanks": [{"id": "blank1", "text": "sing", "options": ["sing", "dance", "play", "read"], "correctAnswer": "sing"}, {"id": "blank2", "text": "play", "options": ["play", "read", "sing", "draw"], "correctAnswer": "play"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_explanation', 6, 'Like / Don’t Like', 'Talk about hobbies you like', '{"rules": "Use like/don''t like + to + verb.\n- I like to read.\n- I don''t like to dance.\nAsk: Do you like to sing?", "examples": ["I like to read.", "I like to draw.", "I don''t like to dance.", "Do you like to sing?", "Do you like to play games?"]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 7, 'Build Sentences 1', 'Arrange words', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'I like to read', 'I like to read.', '["I", "like", "to", "read."]'::jsonb),
    (activity_id_var, 'I like to draw', 'I like to draw.', '["I", "like", "to", "draw."]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 8, 'Build Sentences 2', 'Arrange words', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'Do you like to sing', 'Do you like to sing?', '["Do", "you", "like", "to", "sing?"]'::jsonb),
    (activity_id_var, 'Do you like to dance', 'Do you like to dance?', '["Do", "you", "like", "to", "dance?"]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'speaking_practice', 9, 'Talk About Hobbies', 'Practice hobby likes', '{"prompts": ["Do you like to read?", "Do you like to draw?", "Do you like to sing?", "Do you like to dance?", "Do you like to play games?"]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (
      lesson_id,
      activity_type,
      activity_order,
      title,
      description,
      content
    ) VALUES (
      'A1-L85',
      'speaking_improvement',
      10,
      'Speaking Improvement',
      'Read the improved version of your speech',
      '{"type": "speaking_improvement", "similarityThreshold": 70}'::jsonb
    );
END $$;

