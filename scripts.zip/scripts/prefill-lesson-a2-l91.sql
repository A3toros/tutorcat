-- =========================================
-- Pre-fill Database with Sample Lesson Data
-- A2-L91: Renting a Bicycle or Scooter
-- =========================================

DELETE FROM grammar_sentences WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'A2-L91');
DELETE FROM vocabulary_items WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'A2-L91');
DELETE FROM lesson_activities WHERE lesson_id = 'A2-L91';
DELETE FROM lessons WHERE id = 'A2-L91';

INSERT INTO lessons (id, level, lesson_number, topic) VALUES
('A2-L91', 'A2', 91, 'Renting a Bicycle or Scooter')
ON CONFLICT (id) DO UPDATE SET topic = EXCLUDED.topic;

DO $$
DECLARE
    lesson_id_var TEXT := 'A2-L91';
    activity_id_var UUID;
BEGIN
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'warm_up_speaking', 1, 'First Ride', 'Talk about renting a bike or scooter', '{"prompt": "Where are you going to ride first?"}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_intro', 2, 'Rental Words', 'Learn words for renting bikes', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'rent', 'เช่า', NULL),
    (activity_id_var, 'helmet', 'หมวกกันน็อก', NULL),
    (activity_id_var, 'lock', 'กุญแจล็อก', NULL),
    (activity_id_var, 'hourly', 'รายชั่วโมง', NULL),
    (activity_id_var, 'return', 'ส่งคืน', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_matching_drag', 3, 'Match Rental Words', 'Match rental words', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'rent', 'เช่า', NULL),
    (activity_id_var, 'helmet', 'หมวกกันน็อก', NULL),
    (activity_id_var, 'lock', 'กุญแจล็อก', NULL),
    (activity_id_var, 'hourly', 'รายชั่วโมง', NULL),
    (activity_id_var, 'return', 'ส่งคืน', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 4, 'Complete the Sentences 1', 'Fill with the correct word', '{"text": "I will ___ a bike. I need a ___. I want an ___ price.", "blanks": [{"id": "blank1", "text": "rent", "options": ["rent", "helmet", "lock", "return"], "correctAnswer": "rent"}, {"id": "blank2", "text": "helmet", "options": ["helmet", "lock", "hourly", "return"], "correctAnswer": "helmet"}, {"id": "blank3", "text": "hourly", "options": ["hourly", "return", "rent", "lock"], "correctAnswer": "hourly"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 5, 'Complete the Sentences 2', 'Fill with the correct word', '{"text": "Please ___ the bike here. Use the ___ outside.", "blanks": [{"id": "blank1", "text": "return", "options": ["return", "rent", "hourly", "helmet"], "correctAnswer": "return"}, {"id": "blank2", "text": "lock", "options": ["lock", "helmet", "rent", "return"], "correctAnswer": "lock"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_explanation', 6, 'Going to (Future Plans)', 'Talk about what you will do with the bike', '{"rules": "Use am/is/are + going to + verb for plans.\n- I am going to rent a scooter.\n- We are going to ride for two hours.", "examples": ["I am going to rent a scooter today.", "We are going to ride by the river.", "Are you going to wear a helmet?", "She is going to pay the hourly price.", "They are going to return it at six."]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 7, 'Build Sentences 1', 'Arrange words', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'I am going to rent a scooter today', 'I am going to rent a scooter today.', '["I", "am", "going", "to", "rent", "a", "scooter", "today."]'::jsonb),
    (activity_id_var, 'We are going to ride for two hours', 'We are going to ride for two hours.', '["We", "are", "going", "to", "ride", "for", "two", "hours."]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 8, 'Build Sentences 2', 'Arrange words', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'Are you going to wear a helmet', 'Are you going to wear a helmet?', '["Are", "you", "going", "to", "wear", "a", "helmet?"]'::jsonb),
    (activity_id_var, 'They are going to return it at six', 'They are going to return it at six.', '["They", "are", "going", "to", "return", "it", "at", "six."]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'speaking_practice', 9, 'Talk About Renting', 'Practice rental plans', '{"prompts": ["Where are you going to ride first?", "How long are you going to ride?", "Are you going to wear a helmet?", "What are you going to check before renting?", "What do you need to rent one?"]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (
      lesson_id,
      activity_type,
      activity_order,
      title,
      description,
      content
    ) VALUES (
      'A2-L91',
      'speaking_improvement',
      10,
      'Speaking Improvement',
      'Read the improved version of your speech',
      '{"type": "speaking_improvement", "similarityThreshold": 70}'::jsonb
    );
END $$;

