-- =========================================
-- Pre-fill Database with Sample Lesson Data
-- B2-L75: Travel challenges
-- =========================================

DELETE FROM grammar_sentences WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'B2-L75');
DELETE FROM vocabulary_items WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'B2-L75');
DELETE FROM lesson_activities WHERE lesson_id = 'B2-L75';
DELETE FROM lessons WHERE id = 'B2-L75';

INSERT INTO lessons (id, level, lesson_number, topic) VALUES
('B2-L75', 'B2', 75, 'Travel challenges')
ON CONFLICT (id) DO UPDATE SET topic = EXCLUDED.topic;

DO $$
DECLARE
    lesson_id_var TEXT := 'B2-L75';
    activity_id_var UUID;
BEGIN
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'warm_up_speaking', 1, 'Trip Problems', 'Talk about difficult trips', '{"prompt": "What challenge was so disruptive you changed plans, and how did you recover?"}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_intro', 2, 'Challenge Words', 'Key words for travel problems', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'delay', 'ความล่าช้า', NULL),
    (activity_id_var, 'backup', 'สำรอง/แผนสำรอง', NULL),
    (activity_id_var, 'refund', 'การคืนเงิน', NULL),
    (activity_id_var, 'reschedule', 'จัดเวลาใหม่', NULL),
    (activity_id_var, 'lost', 'สูญหาย/หายไป', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_matching_drag', 3, 'Match Challenge Words', 'Match words with meanings', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'delay', 'ความล่าช้า', NULL),
    (activity_id_var, 'backup', 'สำรอง/แผนสำรอง', NULL),
    (activity_id_var, 'refund', 'การคืนเงิน', NULL),
    (activity_id_var, 'reschedule', 'จัดเวลาใหม่', NULL),
    (activity_id_var, 'lost', 'สูญหาย/หายไป', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 4, 'Complete the Sentences 1', 'Fill with the correct word', '{"text": "A long ___ made us ___. We requested a ___.", "blanks": [{"id": "blank1", "text": "delay", "options": ["delay", "backup", "refund", "reschedule"], "correctAnswer": "delay"}, {"id": "blank2", "text": "reschedule", "options": ["reschedule", "backup", "refund", "lost"], "correctAnswer": "reschedule"}, {"id": "blank3", "text": "refund", "options": ["refund", "delay", "backup", "reschedule"], "correctAnswer": "refund"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 5, 'Complete the Sentences 2', 'Fill with the correct word', '{"text": "A ___ bag needed a ___.", "blanks": [{"id": "blank1", "text": "lost", "options": ["lost", "delay", "backup", "refund"], "correctAnswer": "lost"}, {"id": "blank2", "text": "backup", "options": ["backup", "refund", "reschedule", "delay"], "correctAnswer": "backup"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_explanation', 6, 'Reason & Result (so/such…that)', 'Explain impact of travel problems', '{"rules": "Use so + adj/adv + that or such + (a/an) + noun + that for cause→specific result.\\n- The delay was so long that we missed the connection.\\n- It was such a big backup plan that we stayed calm.", "examples": ["The delay was so long that we changed tickets.", "It was such a bad route that we rescheduled.", "The crowd was so large that we waited outside.", "The backup plan was so clear that we relaxed.", "It was such a sudden change that we asked for a refund."]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 7, 'Build Sentences 1', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'The delay was so long that we changed tickets', 'The delay was so long that we changed tickets.', '["The", "delay", "was", "so", "long", "that", "we", "changed", "tickets."]'::jsonb),
    (activity_id_var, 'The backup plan was so clear that we relaxed', 'The backup plan was so clear that we relaxed.', '["The", "backup", "plan", "was", "so", "clear", "that", "we", "relaxed."]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 8, 'Build Sentences 2', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'It was such a bad route that we rescheduled', 'It was such a bad route that we rescheduled.', '["It", "was", "such", "a", "bad", "route", "that", "we", "rescheduled."]'::jsonb),
    (activity_id_var, 'The crowd was so large that we waited outside', 'The crowd was so large that we waited outside.', '["The", "crowd", "was", "so", "large", "that", "we", "waited", "outside."]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'speaking_practice', 9, 'Talk About Travel Challenges', 'Practice cause/effect', '{"prompts": ["What challenge was so disruptive you changed plans?", "How did you recover after a delay?", "What backup plan kept you calm?"]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (
      lesson_id,
      activity_type,
      activity_order,
      title,
      description,
      content
    ) VALUES (
      'B2-L75',
      'speaking_improvement',
      10,
      'Speaking Improvement',
      'Read the improved version of your speech',
      '{"type": "speaking_improvement", "similarityThreshold": 70}'::jsonb
    );
END $$;


