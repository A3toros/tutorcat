-- =========================================
-- Pre-fill Database with Sample Lesson Data
-- A2-L82: Online Shopping Basics
-- =========================================

DELETE FROM grammar_sentences WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'A2-L82');
DELETE FROM vocabulary_items WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'A2-L82');
DELETE FROM lesson_activities WHERE lesson_id = 'A2-L82';
DELETE FROM lessons WHERE id = 'A2-L82';

INSERT INTO lessons (id, level, lesson_number, topic) VALUES
('A2-L82', 'A2', 82, 'Online Shopping Basics')
ON CONFLICT (id) DO UPDATE SET topic = EXCLUDED.topic;

DO $$
DECLARE
    lesson_id_var TEXT := 'A2-L82';
    activity_id_var UUID;
BEGIN
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'warm_up_speaking', 1, 'Shopping Online', 'Talk about buying online', '{"prompt": "How often do you shop online?"}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_intro', 2, 'Online Shopping Words', 'Learn online shopping words', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'cart', 'ตะกร้าสินค้า', NULL),
    (activity_id_var, 'delivery', 'การส่งสินค้า', NULL),
    (activity_id_var, 'address', 'ที่อยู่', NULL),
    (activity_id_var, 'track', 'ติดตาม', NULL),
    (activity_id_var, 'review', 'รีวิว', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_matching_drag', 3, 'Match Online Shopping Words', 'Match online shopping words', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'cart', 'ตะกร้าสินค้า', NULL),
    (activity_id_var, 'delivery', 'การส่งสินค้า', NULL),
    (activity_id_var, 'address', 'ที่อยู่', NULL),
    (activity_id_var, 'track', 'ติดตาม', NULL),
    (activity_id_var, 'review', 'รีวิว', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 4, 'Complete the Sentences 1', 'Fill with the correct word', '{"text": "Add items to the ___. Check your ___. Choose a ___ option.", "blanks": [{"id": "blank1", "text": "cart", "options": ["cart", "address", "delivery", "review"], "correctAnswer": "cart"}, {"id": "blank2", "text": "address", "options": ["address", "review", "track", "delivery"], "correctAnswer": "address"}, {"id": "blank3", "text": "delivery", "options": ["delivery", "cart", "address", "review"], "correctAnswer": "delivery"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 5, 'Complete the Sentences 2', 'Fill with the correct word', '{"text": "You can ___ your package. Read the ___ first.", "blanks": [{"id": "blank1", "text": "track", "options": ["track", "review", "delivery", "cart"], "correctAnswer": "track"}, {"id": "blank2", "text": "review", "options": ["review", "track", "address", "cart"], "correctAnswer": "review"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_explanation', 6, 'Adverbs of Frequency', 'Talk about how often you shop online', '{"rules": "Use always/usually/often/sometimes/rarely/never to show frequency.\nPlace: before main verb; after be.\n- I often buy online.\n- Deliveries are usually fast.", "examples": ["I often buy online.", "She is usually careful with addresses.", "We sometimes forget to track packages.", "Do you always read reviews?", "They rarely choose express delivery."]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 7, 'Build Sentences 1', 'Arrange words', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'I often buy online', 'I often buy online.', '["I", "often", "buy", "online."]'::jsonb),
    (activity_id_var, 'She is usually careful with addresses', 'She is usually careful with addresses.', '["She", "is", "usually", "careful", "with", "addresses."]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 8, 'Build Sentences 2', 'Arrange words', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'Do you always read reviews', 'Do you always read reviews?', '["Do", "you", "always", "read", "reviews?"]'::jsonb),
    (activity_id_var, 'They rarely choose express delivery', 'They rarely choose express delivery.', '["They", "rarely", "choose", "express", "delivery."]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'speaking_practice', 9, 'Talk About Online Shopping', 'Practice online shopping habits', '{"prompts": ["How often do you shop online?", "Do you usually read reviews before buying?", "How often do you track your orders?", "What do you often buy online?", "Do you ever return items?"]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (
      lesson_id,
      activity_type,
      activity_order,
      title,
      description,
      content
    ) VALUES (
      'A2-L82',
      'speaking_improvement',
      10,
      'Speaking Improvement',
      'Read the improved version of your speech',
      '{"type": "speaking_improvement", "similarityThreshold": 70}'::jsonb
    );
END $$;

