-- =========================================
-- Pre-fill Database with Sample Lesson Data
-- C1-L47: Virtual Communities
-- =========================================
DELETE FROM lesson_activity_results WHERE lesson_id = 'C1-L47';
DELETE FROM user_progress WHERE lesson_id = 'C1-L47';
DELETE FROM lesson_history WHERE lesson_id = 'C1-L47';
DELETE FROM grammar_sentences WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'C1-L47');
DELETE FROM vocabulary_items WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'C1-L47');
DELETE FROM lesson_activities WHERE lesson_id = 'C1-L47';
DELETE FROM lessons WHERE id = 'C1-L47';

INSERT INTO lessons (id, level, lesson_number, topic) VALUES
('C1-L47', 'C1', 47, 'Virtual Communities')
ON CONFLICT (id) DO UPDATE SET topic = EXCLUDED.topic;

DO $$
DECLARE
    lesson_id_var TEXT := 'C1-L47';
    activity_id_var UUID;
BEGIN
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'warm_up_speaking', 1, 'Virtual Communities', 'Discuss virtual communities', '{"prompt": "Why do people join virtual communities?"}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_intro', 2, 'Virtual Communities Vocabulary', 'Learn vocabulary about virtual communities', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'community', 'ชุมชน', NULL),
    (activity_id_var, 'belonging', 'ความรู้สึกเป็นเจ้าของ', NULL),
    (activity_id_var, 'norm', 'บรรทัดฐาน', NULL),
    (activity_id_var, 'benefit', 'ประโยชน์', NULL),
    (activity_id_var, 'challenge', 'ความท้าทาย', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_matching_drag', 3, 'Match Virtual Community Words', 'Match English words with Thai meanings', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'community', 'ชุมชน', NULL),
    (activity_id_var, 'belonging', 'ความรู้สึกเป็นเจ้าของ', NULL),
    (activity_id_var, 'norm', 'บรรทัดฐาน', NULL),
    (activity_id_var, 'benefit', 'ประโยชน์', NULL),
    (activity_id_var, 'challenge', 'ความท้าทาย', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 4, 'Complete the Sentences 1', 'Fill with the correct word', '{"text": "Virtual ___ create ___. Online ___ develop ___.", "blanks": [{"id": "blank1", "text": "communities", "options": ["communities", "belonging", "norm", "benefit"], "correctAnswer": "communities"}, {"id": "blank2", "text": "belonging", "options": ["belonging", "community", "norm", "benefit"], "correctAnswer": "belonging"}, {"id": "blank3", "text": "norms", "options": ["norms", "community", "belonging", "benefit"], "correctAnswer": "norms"}, {"id": "blank4", "text": "naturally", "options": ["naturally", "community", "belonging", "norm"], "correctAnswer": "naturally"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 5, 'Complete the Sentences 2', 'Fill with the correct word', '{"text": "Online ___ offer ___. Virtual ___ face ___.", "blanks": [{"id": "blank1", "text": "communities", "options": ["communities", "belonging", "norm", "benefit"], "correctAnswer": "communities"}, {"id": "blank2", "text": "benefits", "options": ["benefits", "community", "belonging", "norm"], "correctAnswer": "benefits"}, {"id": "blank3", "text": "communities", "options": ["communities", "belonging", "norm", "benefit"], "correctAnswer": "communities"}, {"id": "blank4", "text": "challenges", "options": ["challenges", "community", "belonging", "norm"], "correctAnswer": "challenges"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_explanation', 6, 'Cohesion and Substitution', 'Learn cohesion and substitution', '{"rules": "Cohesion and substitution:\n- Substitution: \"Virtual communities create belonging, and offline ones do too.\"\n- Reference: \"Online communities differ from offline ones; these differences matter.\"\n- Ellipsis: \"Virtual groups form norms, and offline groups do as well.\"\n\nUse for:\n- Avoiding repetition: \"Online communities offer benefits, and offline ones do too.\"\n- Creating flow: \"Virtual groups create belonging; such belonging matters.\"\n- Connecting ideas: \"Challenges exist; these challenges need addressing.\"", "examples": ["Virtual communities create belonging, and offline ones do too.", "Online communities differ from offline ones; these differences matter.", "Virtual groups form norms, and offline groups do as well.", "Online communities offer benefits; such benefits are valuable.", "Challenges exist in virtual communities; these challenges need addressing."]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 7, 'Build Sentences 1', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'Virtual communities create belonging, and offline ones do too.', 'Virtual communities create belonging, and offline ones do too.', '["Virtual", "communities", "create", "belonging,", "and", "offline", "ones", "do", "too."]'::jsonb),
    (activity_id_var, 'Online communities differ from offline ones; these differences matter.', 'Online communities differ from offline ones; these differences matter.', '["Online", "communities", "differ", "from", "offline", "ones;", "these", "differences", "matter."]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 8, 'Build Sentences 2', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'Virtual groups form norms, and offline groups do as well.', 'Virtual groups form norms, and offline groups do as well.', '["Virtual", "groups", "form", "norms,", "and", "offline", "groups", "do", "as", "well."]'::jsonb),
    (activity_id_var, 'Online communities offer benefits; such benefits are valuable.', 'Online communities offer benefits; such benefits are valuable.', '["Online", "communities", "offer", "benefits;", "such", "benefits", "are", "valuable."]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'speaking_practice', 9, 'Discuss Virtual Communities', 'Practice speaking about virtual communities', '{"prompts": ["What creates belonging online?", "What norms form in virtual groups?", "How do online communities differ from offline ones?", "What benefits do they offer?", "What challenges do they face?"]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (
      lesson_id,
      activity_type,
      activity_order,
      title,
      description,
      content
    ) VALUES (
      'C1-L47',
      'speaking_improvement',
      10,
      'Speaking Improvement',
      'Read the improved version of your speech',
      '{"type": "speaking_improvement", "similarityThreshold": 70}'::jsonb
    );
END $$;
