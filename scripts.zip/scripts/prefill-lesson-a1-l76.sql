-- =========================================
-- Pre-fill Database with Sample Lesson Data
-- A1-L76: Work or Study
-- =========================================

DELETE FROM grammar_sentences WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'A1-L76');
DELETE FROM vocabulary_items WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'A1-L76');
DELETE FROM lesson_activities WHERE lesson_id = 'A1-L76';
DELETE FROM lessons WHERE id = 'A1-L76';

INSERT INTO lessons (id, level, lesson_number, topic) VALUES
('A1-L76', 'A1', 76, 'Work or Study')
ON CONFLICT (id) DO UPDATE SET topic = EXCLUDED.topic;

DO $$
DECLARE
    lesson_id_var TEXT := 'A1-L76';
    activity_id_var UUID;
BEGIN
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'warm_up_speaking', 1, 'Work or Study', 'Talk about work or school', '{"prompt": "Do you work?"}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_intro', 2, 'Work/Study Words', 'Learn work or study words', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'work', 'ทำงาน', NULL),
    (activity_id_var, 'study', 'เรียน', NULL),
    (activity_id_var, 'job', 'งาน', NULL),
    (activity_id_var, 'school', 'โรงเรียน', NULL),
    (activity_id_var, 'busy', 'ยุ่ง', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_matching_drag', 3, 'Match Work/Study Words', 'Match work/study words', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'work', 'ทำงาน', NULL),
    (activity_id_var, 'study', 'เรียน', NULL),
    (activity_id_var, 'job', 'งาน', NULL),
    (activity_id_var, 'school', 'โรงเรียน', NULL),
    (activity_id_var, 'busy', 'ยุ่ง', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 4, 'Complete the Sentences 1', 'Fill with the correct word', '{"text": "I ___. I have a ___.", "blanks": [{"id": "blank1", "text": "work", "options": ["work", "study", "job", "busy"], "correctAnswer": "work"}, {"id": "blank2", "text": "job", "options": ["job", "school", "work", "study"], "correctAnswer": "job"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 5, 'Complete the Sentences 2', 'Fill with the correct word', '{"text": "I ___. I am ___.", "blanks": [{"id": "blank1", "text": "study", "options": ["study", "work", "job", "busy"], "correctAnswer": "study"}, {"id": "blank2", "text": "busy", "options": ["busy", "work", "school", "job"], "correctAnswer": "busy"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_explanation', 6, 'Present Simple (habits)', 'Talk about work/study habits', '{"rules": "Use present simple for habits.\n- I work. I study.\nAsk: Do you work? Do you study?", "examples": ["I work every day.", "I study at school.", "I have a job.", "Do you work?", "Do you study?"]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 7, 'Build Sentences 1', 'Arrange words', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'I work every day', 'I work every day.', '["I", "work", "every", "day."]'::jsonb),
    (activity_id_var, 'I study at school', 'I study at school.', '["I", "study", "at", "school."]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 8, 'Build Sentences 2', 'Arrange words', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'Do you work', 'Do you work?', '["Do", "you", "work?"]'::jsonb),
    (activity_id_var, 'Do you study', 'Do you study?', '["Do", "you", "study?"]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'speaking_practice', 9, 'Talk About Work/Study', 'Practice habits', '{"prompts": ["Do you work?", "Do you study?", "Are you busy?", "Do you have a job?", "Do you go to school?"]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (
      lesson_id,
      activity_type,
      activity_order,
      title,
      description,
      content
    ) VALUES (
      'A1-L76',
      'speaking_improvement',
      10,
      'Speaking Improvement',
      'Read the improved version of your speech',
      '{"type": "speaking_improvement", "similarityThreshold": 70}'::jsonb
    );
END $$;

