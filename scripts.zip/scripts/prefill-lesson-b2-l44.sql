-- =========================================
-- Pre-fill Database with Sample Lesson Data
-- B2-L44: Living in another country
-- =========================================

DELETE FROM grammar_sentences WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'B2-L44');
DELETE FROM vocabulary_items WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'B2-L44');
DELETE FROM lesson_activities WHERE lesson_id = 'B2-L44';
DELETE FROM lessons WHERE id = 'B2-L44';

INSERT INTO lessons (id, level, lesson_number, topic) VALUES
('B2-L44', 'B2', 44, 'Living in another country')
ON CONFLICT (id) DO UPDATE SET topic = EXCLUDED.topic;

DO $$
DECLARE
    lesson_id_var TEXT := 'B2-L44';
    activity_id_var UUID;
BEGIN
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'warm_up_speaking', 1, 'Moving Today', 'Talk about first steps abroad', '{"prompt": "If you moved today, what would you do first, and who would you lean on?"}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_intro', 2, 'Living Abroad Words', 'Key words for settling in', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'settle', 'ตั้งหลัก/ลงหลักปักฐาน', NULL),
    (activity_id_var, 'adapt', 'ปรับตัว', NULL),
    (activity_id_var, 'routine', 'กิจวัตร', NULL),
    (activity_id_var, 'network', 'เครือข่ายคนรู้จัก', NULL),
    (activity_id_var, 'homesick', 'คิดถึงบ้าน', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_matching_drag', 3, 'Match Living Abroad Words', 'Match words with meanings', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'settle', 'ตั้งหลัก/ลงหลักปักฐาน', NULL),
    (activity_id_var, 'adapt', 'ปรับตัว', NULL),
    (activity_id_var, 'routine', 'กิจวัตร', NULL),
    (activity_id_var, 'network', 'เครือข่ายคนรู้จัก', NULL),
    (activity_id_var, 'homesick', 'คิดถึงบ้าน', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 4, 'Complete the Sentences 1', 'Fill with the correct word', '{"text": "I try to ___ fast. A simple ___ keeps me calm. I build a small ___.", "blanks": [{"id": "blank1", "text": "adapt", "options": ["adapt", "settle", "routine", "network"], "correctAnswer": "adapt"}, {"id": "blank2", "text": "routine", "options": ["routine", "network", "homesick", "settle"], "correctAnswer": "routine"}, {"id": "blank3", "text": "network", "options": ["network", "routine", "homesick", "adapt"], "correctAnswer": "network"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 5, 'Complete the Sentences 2', 'Fill with the correct word', '{"text": "It takes time to ___. I felt ___ at first.", "blanks": [{"id": "blank1", "text": "settle", "options": ["settle", "adapt", "routine", "network"], "correctAnswer": "settle"}, {"id": "blank2", "text": "homesick", "options": ["homesick", "settle", "adapt", "network"], "correctAnswer": "homesick"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_explanation', 6, 'Second Conditional', 'Plan hypothetical moves', '{"rules": "Use if + past simple + would + base verb for unreal present/future.\\n- If I moved today, I would call my buddy.\\nUse were after I/he/she/it in formal style.", "examples": ["If I moved tomorrow, I would set a routine first.", "If I were more flexible, I would adapt faster.", "If you felt homesick, who would you call?", "If we had no network, we would join local groups.", "If they were new here, they would visit campus first."]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 7, 'Build Sentences 1', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'If I moved tomorrow, I would set a routine first', 'If I moved tomorrow, I would set a routine first.', '["If", "I", "moved", "tomorrow,", "I", "would", "set", "a", "routine", "first."]'::jsonb),
    (activity_id_var, 'If I were more flexible, I would adapt faster', 'If I were more flexible, I would adapt faster.', '["If", "I", "were", "more", "flexible,", "I", "would", "adapt", "faster."]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 8, 'Build Sentences 2', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'If we had no network, we would join local groups', 'If we had no network, we would join local groups.', '["If", "we", "had", "no", "network,", "we", "would", "join", "local", "groups."]'::jsonb),
    (activity_id_var, 'If you felt homesick, who would you call', 'If you felt homesick, who would you call?', '["If", "you", "felt", "homesick,", "who", "would", "you", "call?"]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'speaking_practice', 9, 'Talk About Moving Abroad', 'Practice second conditional', '{"prompts": ["If you moved today, what would you do first?", "Who would you lean on in a new country?", "How would you build a routine to avoid feeling homesick?"]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (
      lesson_id,
      activity_type,
      activity_order,
      title,
      description,
      content
    ) VALUES (
      'B2-L44',
      'speaking_improvement',
      10,
      'Speaking Improvement',
      'Read the improved version of your speech',
      '{"type": "speaking_improvement", "similarityThreshold": 70}'::jsonb
    );
END $$;


