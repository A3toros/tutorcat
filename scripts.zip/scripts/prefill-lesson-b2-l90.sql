-- ===== LESSON B2-L90 =====

-- =========================================
-- Pre-fill Database with Sample Lesson Data
-- B2-L90: Planning for adulthood
-- =========================================

DELETE FROM lesson_activity_results WHERE lesson_id = 'B2-L90';
DELETE FROM user_progress WHERE lesson_id = 'B2-L90';
DELETE FROM lesson_history WHERE lesson_id = 'B2-L90';
DELETE FROM grammar_sentences WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'B2-L90');
DELETE FROM vocabulary_items WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'B2-L90');
DELETE FROM lesson_activities WHERE lesson_id = 'B2-L90';
DELETE FROM lessons WHERE id = 'B2-L90';

INSERT INTO lessons (id, level, lesson_number, topic) VALUES
('B2-L90', 'B2', 90, 'Planning for adulthood')
ON CONFLICT (id) DO UPDATE SET topic = EXCLUDED.topic;

DO $$
DECLARE
    lesson_id_var TEXT := 'B2-L90';
    activity_id_var UUID;
BEGIN
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'warm_up_speaking', 1, 'Future Planning', 'Talk about preparing for adult responsibilities', '{"prompt": "If you shifted plans now, what would future you gain?"}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_intro', 2, 'Adulthood Words', 'Learn words related to adult planning', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'milestone', 'จุดสำคัญ', NULL),
    (activity_id_var, 'stable', 'มั่นคง', NULL),
    (activity_id_var, 'anticipate', 'คาดหวัง', NULL),
    (activity_id_var, 'prepare', 'เตรียม', NULL),
    (activity_id_var, 'transition', 'การเปลี่ยนแปลง', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_matching_drag', 3, 'Match Adulthood Words', 'Match words related to adult planning', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'milestone', 'จุดสำคัญ', NULL),
    (activity_id_var, 'stable', 'มั่นคง', NULL),
    (activity_id_var, 'anticipate', 'คาดหวัง', NULL),
    (activity_id_var, 'prepare', 'เตรียม', NULL),
    (activity_id_var, 'transition', 'การเปลี่ยนแปลง', NULL);

    -- 4. Vocabulary Fill Blanks #1
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 4, 'Complete the Sentences 1', 'Fill in the blanks with correct words', '{"text": "I reached a ___. I want to be ___. I need to ___.", "blanks": [{"id": "blank1", "text": "milestone", "options": ["milestone", "stable", "anticipate", "prepare"], "correctAnswer": "milestone"}, {"id": "blank2", "text": "stable", "options": ["stable", "milestone", "anticipate", "transition"], "correctAnswer": "stable"}, {"id": "blank3", "text": "anticipate", "options": ["anticipate", "milestone", "stable", "prepare"], "correctAnswer": "anticipate"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    -- 5. Vocabulary Fill Blanks #2
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 5, 'Complete the Sentences 2', 'Fill in the blanks with correct words', '{"text": "I need to ___ for this. It is a ___. We must ___.", "blanks": [{"id": "blank1", "text": "prepare", "options": ["prepare", "milestone", "stable", "anticipate"], "correctAnswer": "prepare"}, {"id": "blank2", "text": "transition", "options": ["transition", "milestone", "stable", "prepare"], "correctAnswer": "transition"}, {"id": "blank3", "text": "prepare", "options": ["prepare", "transition", "milestone", "stable"], "correctAnswer": "prepare"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    -- 6. Grammar Explanation
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_explanation', 6, 'Second Conditional', 'Learn if/when for hypothetical situations', '{"rules": "Use second conditional for hypothetical or unreal situations:\n\n- Form: If + past simple, would + base verb\n- If I planned better, I would have more stability\n- If she anticipated, she would prepare\n- Use were for all subjects (If I were, If you were)\n- Expresses unlikely or imaginary situations\n- Often used for advice, suggestions, or hypothetical planning", "examples": ["If I planned better now, I would have more stability later.", "If she anticipated challenges, she would prepare differently.", "If they focused on milestones, they would feel more accomplished.", "If I were you, I would start preparing now.", "What would you do if you had to plan your future?"]}'::jsonb)
    RETURNING id INTO activity_id_var;

    -- 7. Grammar Sentences #1
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 7, 'Build Sentences 1', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'If I planned better now I would have more stability later', 'If I planned better now, I would have more stability later.', '["If", "I", "planned", "better", "now,", "I", "would", "have", "more", "stability", "later."]'::jsonb),
    (activity_id_var, 'If she anticipated challenges she would prepare differently', 'If she anticipated challenges, she would prepare differently.', '["If", "she", "anticipated", "challenges,", "she", "would", "prepare", "differently."]'::jsonb);

    -- 8. Grammar Sentences #2
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 8, 'Build Sentences 2', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'If they focused on milestones they would feel more accomplished', 'If they focused on milestones, they would feel more accomplished.', '["If", "they", "focused", "on", "milestones,", "they", "would", "feel", "more", "accomplished."]'::jsonb),
    (activity_id_var, 'If I were you I would start preparing now', 'If I were you, I would start preparing now.', '["If", "I", "were", "you,", "I", "would", "start", "preparing", "now."]'::jsonb);

    -- 9. Speaking Practice
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'speaking_practice', 9, 'Discuss Adult Planning', 'Practice talking about future responsibilities', '{"prompts": ["If you shifted plans now, what would future you gain?", "How do you prepare?", "Who keeps you realistic?", "What milestones do you want to reach?", "How do you anticipate challenges?"]}'::jsonb)
    RETURNING id INTO activity_id_var;

    -- 10. Speaking Improvement
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'speaking_improvement', 10, 'Speaking Improvement', 'Read the improved version of your speech', '{"type": "speaking_improvement", "similarityThreshold": 70}'::jsonb)
    RETURNING id INTO activity_id_var;
END $$;


-- =========================================
-- END OF MISSING LESSONS
-- =========================================
--
-- Summary of added lessons:
-- A1: L45-L50 (6 lessons) ✅ COMPLETE
-- B1: L61-L70 (10 lessons) ✅ COMPLETE
-- B2: L51-L60, L81-L90 (20 lessons) ✅ COMPLETE
--
-- Total: 36 lessons added ✅ ALL GAPS FILLED
--
-- This file contains all missing lessons to fill the gaps identified in the database.
-- =========================================