-- =========================================
-- Pre-fill Database with Sample Lesson Data
-- B2-L47: Social media and distraction
-- =========================================

DELETE FROM grammar_sentences WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'B2-L47');
DELETE FROM vocabulary_items WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'B2-L47');
DELETE FROM lesson_activities WHERE lesson_id = 'B2-L47';
DELETE FROM lessons WHERE id = 'B2-L47';

INSERT INTO lessons (id, level, lesson_number, topic) VALUES
('B2-L47', 'B2', 47, 'Social media and distraction')
ON CONFLICT (id) DO UPDATE SET topic = EXCLUDED.topic;

DO $$
DECLARE
    lesson_id_var TEXT := 'B2-L47';
    activity_id_var UUID;
BEGIN
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'warm_up_speaking', 1, 'Scroll Control', 'Talk about limiting distractions', '{"prompt": "What should be limited or muted, and who keeps you accountable?"}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_intro', 2, 'Distraction Words', 'Key words for managing social media', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'scroll', 'เลื่อนหน้าจอ', NULL),
    (activity_id_var, 'trigger', 'สิ่งกระตุ้น', NULL),
    (activity_id_var, 'blocklist', 'รายการบล็อก', NULL),
    (activity_id_var, 'limit', 'จำกัด', NULL),
    (activity_id_var, 'notification', 'การแจ้งเตือน', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_matching_drag', 3, 'Match Distraction Words', 'Match words with meanings', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'scroll', 'เลื่อนหน้าจอ', NULL),
    (activity_id_var, 'trigger', 'สิ่งกระตุ้น', NULL),
    (activity_id_var, 'blocklist', 'รายการบล็อก', NULL),
    (activity_id_var, 'limit', 'จำกัด', NULL),
    (activity_id_var, 'notification', 'การแจ้งเตือน', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 4, 'Complete the Sentences 1', 'Fill with the correct word', '{"text": "I set a ___ for apps. I add triggers to a ___. I mute ___.", "blanks": [{"id": "blank1", "text": "limit", "options": ["limit", "blocklist", "notification", "scroll"], "correctAnswer": "limit"}, {"id": "blank2", "text": "blocklist", "options": ["blocklist", "limit", "trigger", "notification"], "correctAnswer": "blocklist"}, {"id": "blank3", "text": "notifications", "options": ["notifications", "scroll", "limit", "blocklist"], "correctAnswer": "notifications"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 5, 'Complete the Sentences 2', 'Fill with the correct word', '{"text": "Constant ___ can be a ___.", "blanks": [{"id": "blank1", "text": "scrolling", "options": ["scrolling", "trigger", "limit", "notification"], "correctAnswer": "scrolling"}, {"id": "blank2", "text": "trigger", "options": ["trigger", "scrolling", "blocklist", "limit"], "correctAnswer": "trigger"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_explanation', 6, 'Passive with Modals', 'Set rules for apps and alerts', '{"rules": "Use modal + be + past participle for necessity/permission.\\n- Notifications should be muted at night.\\n- Triggers can be blocklisted.\\nUse modal + have + been + past participle for past duties.", "examples": ["Notifications should be muted during study time.", "Triggers must be added to the blocklist.", "Time limits can be set per app.", "Distractions could be reduced with one rule.", "Alerts should have been turned off before exams."]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 7, 'Build Sentences 1', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'Notifications should be muted during study time', 'Notifications should be muted during study time.', '["Notifications", "should", "be", "muted", "during", "study", "time."]'::jsonb),
    (activity_id_var, 'Triggers must be added to the blocklist', 'Triggers must be added to the blocklist.', '["Triggers", "must", "be", "added", "to", "the", "blocklist."]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 8, 'Build Sentences 2', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'Time limits can be set per app', 'Time limits can be set per app.', '["Time", "limits", "can", "be", "set", "per", "app."]'::jsonb),
    (activity_id_var, 'Alerts should have been turned off before exams', 'Alerts should have been turned off before exams.', '["Alerts", "should", "have", "been", "turned", "off", "before", "exams."]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'speaking_practice', 9, 'Talk About Distraction Rules', 'Practice passive with modals', '{"prompts": ["What should be limited or muted first?", "Who keeps you accountable for screen rules?", "When must alerts be turned off for you?"]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (
      lesson_id,
      activity_type,
      activity_order,
      title,
      description,
      content
    ) VALUES (
      'B2-L47',
      'speaking_improvement',
      10,
      'Speaking Improvement',
      'Read the improved version of your speech',
      '{"type": "speaking_improvement", "similarityThreshold": 70}'::jsonb
    );
END $$;


