-- ===== LESSON B2-L54 =====

-- =========================================
-- Pre-fill Database with Sample Lesson Data
-- B2-L54: Entertainment choices
-- =========================================

DELETE FROM lesson_activity_results WHERE lesson_id = 'B2-L54';
DELETE FROM user_progress WHERE lesson_id = 'B2-L54';
DELETE FROM lesson_history WHERE lesson_id = 'B2-L54';
DELETE FROM grammar_sentences WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'B2-L54');
DELETE FROM vocabulary_items WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'B2-L54');
DELETE FROM lesson_activities WHERE lesson_id = 'B2-L54';
DELETE FROM lessons WHERE id = 'B2-L54';

INSERT INTO lessons (id, level, lesson_number, topic) VALUES
('B2-L54', 'B2', 54, 'Entertainment choices')
ON CONFLICT (id) DO UPDATE SET topic = EXCLUDED.topic;

DO $$
DECLARE
    lesson_id_var TEXT := 'B2-L54';
    activity_id_var UUID;
BEGIN
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'warm_up_speaking', 1, 'Media Choices', 'Talk about entertainment preferences', '{"prompt": "If you cut one platform, what changes?"}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_intro', 2, 'Entertainment Words', 'Learn words related to entertainment choices', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'genre', 'ประเภท', NULL),
    (activity_id_var, 'binge', 'ดูต่อเนื่อง', NULL),
    (activity_id_var, 'mood', 'อารมณ์', NULL),
    (activity_id_var, 'uplift', 'ให้กำลังใจ', NULL),
    (activity_id_var, 'resonate', 'สั่นไหว', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_matching_drag', 3, 'Match Entertainment Words', 'Match entertainment-related words', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'genre', 'ประเภท', NULL),
    (activity_id_var, 'binge', 'ดูต่อเนื่อง', NULL),
    (activity_id_var, 'mood', 'อารมณ์', NULL),
    (activity_id_var, 'uplift', 'ให้กำลังใจ', NULL),
    (activity_id_var, 'resonate', 'สั่นไหว', NULL);

    -- 4. Vocabulary Fill Blanks #1
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 4, 'Complete the Sentences 1', 'Fill in the blanks with correct words', '{"text": "I like this ___. I ___ watch shows. My ___ affects my choice.", "blanks": [{"id": "blank1", "text": "genre", "options": ["genre", "binge", "mood", "uplift"], "correctAnswer": "genre"}, {"id": "blank2", "text": "binge", "options": ["binge", "genre", "mood", "resonate"], "correctAnswer": "binge"}, {"id": "blank3", "text": "mood", "options": ["mood", "genre", "binge", "uplift"], "correctAnswer": "mood"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    -- 5. Vocabulary Fill Blanks #2
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 5, 'Complete the Sentences 2', 'Fill in the blanks with correct words', '{"text": "This show can ___ me. The story ___ with me. I feel ___.", "blanks": [{"id": "blank1", "text": "uplift", "options": ["uplift", "genre", "binge", "mood"], "correctAnswer": "uplift"}, {"id": "blank2", "text": "resonates", "options": ["resonates", "genre", "binge", "uplift"], "correctAnswer": "resonates"}, {"id": "blank3", "text": "uplifted", "options": ["uplifted", "genre", "binge", "mood"], "correctAnswer": "uplifted"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    -- 6. Grammar Explanation
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_explanation', 6, 'Second Conditional for Hypotheticals', 'Learn if/when for unreal situations', '{"rules": "Use second conditional for hypothetical or unreal situations:\n\n- Form: If + past simple, would + base verb\n- If you cut services, what would you do?\n- If a show resonated, you would recommend it\n- Use were for all subjects (If I were, If you were)\n- Expresses unlikely or imaginary situations\n- Often used for advice or suggestions", "examples": ["If you cut streaming services, what would you do for entertainment?", "If a show resonated with you, you would recommend it to friends.", "If you were in a bad mood, which genre would you choose?", "If I had more time, I would watch more shows.", "What would you do if you couldn''t watch TV?"]}'::jsonb)
    RETURNING id INTO activity_id_var;

    -- 7. Grammar Sentences #1
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 7, 'Build Sentences 1', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'If you cut streaming services what would you do for entertainment', 'If you cut streaming services, what would you do for entertainment?', '["If", "you", "cut", "streaming", "services,", "what", "would", "you", "do", "for", "entertainment?"]'::jsonb),
    (activity_id_var, 'If a show resonated with you you would recommend it to friends', 'If a show resonated with you, you would recommend it to friends.', '["If", "a", "show", "resonated", "with", "you,", "you", "would", "recommend", "it", "to", "friends."]'::jsonb);

    -- 8. Grammar Sentences #2
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 8, 'Build Sentences 2', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'If you were in a bad mood which genre would you choose', 'If you were in a bad mood, which genre would you choose?', '["If", "you", "were", "in", "a", "bad", "mood,", "which", "genre", "would", "you", "choose?"]'::jsonb),
    (activity_id_var, 'If I had more time I would watch more shows', 'If I had more time, I would watch more shows.', '["If", "I", "had", "more", "time,", "I", "would", "watch", "more", "shows."]'::jsonb);

    -- 9. Speaking Practice
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'speaking_practice', 9, 'Talk About Movies and TV', 'Practice talking about watching shows', '{"prompts": ["What is your favorite TV show?", "Do you watch movies with your family?", "Who is your favorite movie star?", "What genre do you prefer?", "If you could only watch one show, what would it be?"]}'::jsonb)
    RETURNING id INTO activity_id_var;

    -- 10. Speaking Improvement
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'speaking_improvement', 10, 'Speaking Improvement', 'Read the improved version of your speech', '{"type": "speaking_improvement", "similarityThreshold": 70}'::jsonb)
    RETURNING id INTO activity_id_var;
END $$;