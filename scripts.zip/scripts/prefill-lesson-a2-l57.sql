-- =========================================
-- Pre-fill Database with Sample Lesson Data
-- A2-L57: Invitations to Parties
-- =========================================

DELETE FROM grammar_sentences WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'A2-L57');
DELETE FROM vocabulary_items WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'A2-L57');
DELETE FROM lesson_activities WHERE lesson_id = 'A2-L57';
DELETE FROM lessons WHERE id = 'A2-L57';

INSERT INTO lessons (id, level, lesson_number, topic) VALUES
('A2-L57', 'A2', 57, 'Invitations to Parties')
ON CONFLICT (id) DO UPDATE SET topic = EXCLUDED.topic;

DO $$
DECLARE
    lesson_id_var TEXT := 'A2-L57';
    activity_id_var UUID;
BEGIN
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'warm_up_speaking', 1, 'Inviting Friends', 'Talk about inviting people', '{"prompt": "How do you ask people to come to a party?"}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_intro', 2, 'Invitation Words', 'Learn invitation vocabulary', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'invite', 'เชิญ', NULL),
    (activity_id_var, 'RSVP', 'ตอบรับ/ปฏิเสธ', NULL),
    (activity_id_var, 'bring', 'นำมา', NULL),
    (activity_id_var, 'come', 'มา', NULL),
    (activity_id_var, 'time', 'เวลา', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_matching_drag', 3, 'Match Invitation Words', 'Match invitation words', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'invite', 'เชิญ', NULL),
    (activity_id_var, 'RSVP', 'ตอบรับ/ปฏิเสธ', NULL),
    (activity_id_var, 'bring', 'นำมา', NULL),
    (activity_id_var, 'come', 'มา', NULL),
    (activity_id_var, 'time', 'เวลา', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 4, 'Complete the Sentences 1', 'Fill with the correct word', '{"text": "I want to ___ you. Please ___ by Friday. ___ at 7 p.m.", "blanks": [{"id": "blank1", "text": "invite", "options": ["invite", "RSVP", "come", "bring"], "correctAnswer": "invite"}, {"id": "blank2", "text": "RSVP", "options": ["RSVP", "come", "bring", "invite"], "correctAnswer": "RSVP"}, {"id": "blank3", "text": "Come", "options": ["Come", "Bring", "Invite", "RSVP"], "correctAnswer": "Come"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 5, 'Complete the Sentences 2', 'Fill with the correct word', '{"text": "Please ___ a snack. What ___ works for you?", "blanks": [{"id": "blank1", "text": "bring", "options": ["bring", "come", "invite", "RSVP"], "correctAnswer": "bring"}, {"id": "blank2", "text": "time", "options": ["time", "bring", "RSVP", "invite"], "correctAnswer": "time"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_explanation', 6, 'Imperatives / Requests', 'Invite politely', '{"rules": "Use imperatives + please for polite invites.\n- Please come at 7.\nUse Can you…? for requests.\n- Can you bring snacks?\n- Can you RSVP by Friday?", "examples": ["Please come at 7 p.m.", "Please bring a snack.", "Can you RSVP by Friday?", "Can you invite your friend?", "Please be on time."]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 7, 'Build Sentences 1', 'Arrange words', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'Please come at seven', 'Please come at seven.', '["Please", "come", "at", "seven."]'::jsonb),
    (activity_id_var, 'Can you bring a snack', 'Can you bring a snack?', '["Can", "you", "bring", "a", "snack?"]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 8, 'Build Sentences 2', 'Arrange words', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'Can you RSVP by Friday', 'Can you RSVP by Friday?', '["Can", "you", "RSVP", "by", "Friday?"]'::jsonb),
    (activity_id_var, 'Please be on time', 'Please be on time.', '["Please", "be", "on", "time."]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'speaking_practice', 9, 'Talk About Invitations', 'Practice inviting friends', '{"prompts": ["How do you ask people to come to a party?", "What do you usually say in an invitation message?", "What should guests bring to a party?", "How do you ask someone to reply?", "What do you say if you cannot go?"]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (
      lesson_id,
      activity_type,
      activity_order,
      title,
      description,
      content
    ) VALUES (
      'A2-L57',
      'speaking_improvement',
      10,
      'Speaking Improvement',
      'Read the improved version of your speech',
      '{"type": "speaking_improvement", "similarityThreshold": 70}'::jsonb
    );
END $$;

