-- =========================================
-- Pre-fill Database with Sample Lesson Data
-- B1-L42: Language Barriers
-- =========================================

DELETE FROM grammar_sentences WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'B1-L42');
DELETE FROM vocabulary_items WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'B1-L42');
DELETE FROM lesson_activities WHERE lesson_id = 'B1-L42';
DELETE FROM lessons WHERE id = 'B1-L42';

INSERT INTO lessons (id, level, lesson_number, topic) VALUES
('B1-L42', 'B1', 42, 'Language Barriers')
ON CONFLICT (id) DO UPDATE SET topic = EXCLUDED.topic;

DO $$
DECLARE
    lesson_id_var TEXT := 'B1-L42';
    activity_id_var UUID;
BEGIN
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'warm_up_speaking', 1, 'Sharing Messages', 'Talk about retelling and misunderstandings', '{"prompt": "How do you retell something you heard in another language?"}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_intro', 2, 'Barrier Words', 'Learn vocabulary about language barriers', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'clarify', 'ชี้แจง', NULL),
    (activity_id_var, 'translate', 'แปล', NULL),
    (activity_id_var, 'repeat', 'พูดซ้ำ', NULL),
    (activity_id_var, 'understand', 'เข้าใจ', NULL),
    (activity_id_var, 'mishear', 'ได้ยินผิด', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_matching_drag', 3, 'Match Barrier Words', 'Match words with meanings', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'clarify', 'ชี้แจง', NULL),
    (activity_id_var, 'translate', 'แปล', NULL),
    (activity_id_var, 'repeat', 'พูดซ้ำ', NULL),
    (activity_id_var, 'understand', 'เข้าใจ', NULL),
    (activity_id_var, 'mishear', 'ได้ยินผิด', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 4, 'Complete the Sentences 1', 'Fill with the correct word', '{"text": "Please ___. Can you ___ this? I want to ___ fully.", "blanks": [{"id": "blank1", "text": "repeat", "options": ["repeat", "clarify", "translate", "mishear"], "correctAnswer": "repeat"}, {"id": "blank2", "text": "translate", "options": ["translate", "clarify", "understand", "repeat"], "correctAnswer": "translate"}, {"id": "blank3", "text": "understand", "options": ["understand", "mishear", "repeat", "clarify"], "correctAnswer": "understand"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 5, 'Complete the Sentences 2', 'Fill with the correct word', '{"text": "Let us ___. I might ___. Please ___ if needed.", "blanks": [{"id": "blank1", "text": "clarify", "options": ["clarify", "repeat", "translate", "mishear"], "correctAnswer": "clarify"}, {"id": "blank2", "text": "mishear", "options": ["mishear", "clarify", "understand", "translate"], "correctAnswer": "mishear"}, {"id": "blank3", "text": "repeat", "options": ["repeat", "clarify", "translate", "understand"], "correctAnswer": "repeat"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    -- Grammar Explanation: Reported Speech (statements) — review
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_explanation', 6, 'Reported Speech (Statements)', 'Use said/told + (object) + that + clause; shift tenses when needed', '{"rules": "Reported speech for statements: subject + said/told + (object) + that + clause. Use told + object. Shift tenses when reporting past statements.\\n- She said that the train was late.\\n- He told me that he was lost.", "examples": ["She said that the instructions were clear.", "He told me that he needed help.", "They said that the room was full.", "I told them that we could translate later.", "The guide said that we would meet at noon."]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 7, 'Build Sentences 1', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'She said that the instructions were clear', 'She said that the instructions were clear', '["She", "said", "that", "the", "instructions", "were", "clear"]'::jsonb),
    (activity_id_var, 'He told me that he needed help', 'He told me that he needed help', '["He", "told", "me", "that", "he", "needed", "help"]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 8, 'Build Sentences 2', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'They said that the room was full', 'They said that the room was full', '["They", "said", "that", "the", "room", "was", "full"]'::jsonb),
    (activity_id_var, 'I told them that we could translate later', 'I told them that we could translate later', '["I", "told", "them", "that", "we", "could", "translate", "later"]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'speaking_practice', 9, 'Talk About Language Barriers', 'Practice talking about retelling and misunderstandings', '{"prompts": ["How do you retell something you heard in another language?", "Describe a misunderstanding you had.", "How did you fix it in the moment?"]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (
      lesson_id,
      activity_type,
      activity_order,
      title,
      description,
      content
    ) VALUES (
      'B1-L42',
      'speaking_improvement',
      10,
      'Speaking Improvement',
      'Read the improved version of your speech',
      '{"type": "speaking_improvement", "similarityThreshold": 70}'::jsonb
    );
END $$;

