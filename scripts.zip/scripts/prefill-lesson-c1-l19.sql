-- =========================================
-- Pre-fill Database with Sample Lesson Data
-- C1-L19: Educational Inequality
-- =========================================

DELETE FROM grammar_sentences WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'C1-L19');
DELETE FROM vocabulary_items WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'C1-L19');
DELETE FROM lesson_activities WHERE lesson_id = 'C1-L19';
DELETE FROM lessons WHERE id = 'C1-L19';

INSERT INTO lessons (id, level, lesson_number, topic) VALUES
('C1-L19', 'C1', 19, 'Educational Inequality')
ON CONFLICT (id) DO UPDATE SET topic = EXCLUDED.topic;

DO $$
DECLARE
    lesson_id_var TEXT := 'C1-L19';
    activity_id_var UUID;
BEGIN
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'warm_up_speaking', 1, 'Educational Inequality', 'Discuss educational inequality', '{"prompt": "What causes inequality in education?"}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_intro', 2, 'Inequality Vocabulary', 'Learn vocabulary about educational inequality', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'inequality', 'ความไม่เท่าเทียม', NULL),
    (activity_id_var, 'privilege', 'สิทธิพิเศษ', NULL),
    (activity_id_var, 'disadvantage', 'ข้อเสียเปรียบ', NULL),
    (activity_id_var, 'socioeconomic', 'ทางสังคมและเศรษฐกิจ', NULL),
    (activity_id_var, 'marginalization', 'การถูกทำให้เป็นชายขอบ', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_matching_drag', 3, 'Match Inequality Words', 'Match English words with Thai meanings', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'inequality', 'ความไม่เท่าเทียม', NULL),
    (activity_id_var, 'privilege', 'สิทธิพิเศษ', NULL),
    (activity_id_var, 'disadvantage', 'ข้อเสียเปรียบ', NULL),
    (activity_id_var, 'socioeconomic', 'ทางสังคมและเศรษฐกิจ', NULL),
    (activity_id_var, 'marginalization', 'การถูกทำให้เป็นชายขอบ', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 4, 'Complete the Sentences 1', 'Fill with the correct word', '{"text": "Educational ___ persists globally. ___ status affects access.", "blanks": [{"id": "blank1", "text": "inequality", "options": ["inequality", "privilege", "disadvantage", "marginalization"], "correctAnswer": "inequality"}, {"id": "blank2", "text": "Socioeconomic", "options": ["Socioeconomic", "Inequality", "Privilege", "Disadvantage"], "correctAnswer": "Socioeconomic"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 5, 'Complete the Sentences 2', 'Fill with the correct word', '{"text": "___ creates unfair advantages. ___ leads to educational ___.", "blanks": [{"id": "blank1", "text": "Privilege", "options": ["Privilege", "Inequality", "Disadvantage", "Marginalization"], "correctAnswer": "Privilege"}, {"id": "blank2", "text": "Marginalization", "options": ["Marginalization", "Privilege", "Inequality", "Disadvantage"], "correctAnswer": "Marginalization"}, {"id": "blank3", "text": "disadvantage", "options": ["disadvantage", "privilege", "inequality", "marginalization"], "correctAnswer": "disadvantage"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_explanation', 6, 'Articles: Generic Reference', 'Learn articles with generic nouns', '{"rules": "Generic reference with articles:\n- Zero article for general concepts: \"Inequality affects many.\"\n- \"The\" for specific instances: \"The inequality in this region is severe.\"\n- \"A/an\" for classifying: \"Inequality is a complex issue.\"\n\nPatterns:\n- General statements: \"Privilege creates advantages.\"\n- Specific reference: \"The privilege of wealth enables access.\"\n- Classification: \"Education is a right, not a privilege.\"\n\nUse for:\n- General statements: \"Inequality persists in education.\"\n- Specific cases: \"The inequality we see is systemic.\"\n- Classification: \"Privilege is a form of advantage.\"", "examples": ["Inequality affects educational outcomes globally.", "The inequality in urban areas is particularly visible.", "Privilege creates unfair advantages in access.", "The privilege of socioeconomic status shapes opportunities.", "Education should be a right, not a privilege."]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 7, 'Build Sentences 1', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'Inequality affects educational outcomes across regions.', 'Inequality affects educational outcomes across regions.', '["Inequality", "affects", "educational", "outcomes", "across", "regions."]'::jsonb),
    (activity_id_var, 'The inequality in this system is deeply entrenched.', 'The inequality in this system is deeply entrenched.', '["The", "inequality", "in", "this", "system", "is", "deeply", "entrenched."]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 8, 'Build Sentences 2', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'Privilege creates unfair advantages in access to education.', 'Privilege creates unfair advantages in access to education.', '["Privilege", "creates", "unfair", "advantages", "in", "access", "to", "education."]'::jsonb),
    (activity_id_var, 'The privilege of wealth enables better opportunities.', 'The privilege of wealth enables better opportunities.', '["The", "privilege", "of", "wealth", "enables", "better", "opportunities."]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'speaking_practice', 9, 'Discuss Educational Inequality', 'Practice speaking about inequality', '{"prompts": ["What factors create educational inequality?", "How does family background affect opportunity?", "Where do you see inequality in your community?", "How does privilege influence outcomes?", "What steps could reduce inequality?"]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (
      lesson_id,
      activity_type,
      activity_order,
      title,
      description,
      content
    ) VALUES (
      'C1-L19',
      'speaking_improvement',
      10,
      'Speaking Improvement',
      'Read the improved version of your speech',
      '{"type": "speaking_improvement", "similarityThreshold": 70}'::jsonb
    );
END $$;
