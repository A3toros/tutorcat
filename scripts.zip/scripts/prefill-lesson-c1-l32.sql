-- =========================================
-- Pre-fill Database with Sample Lesson Data
-- C1-L32: Preserving Traditions in Modern Societies
-- =========================================
DELETE FROM lesson_activity_results WHERE lesson_id = 'C1-L32';
DELETE FROM user_progress WHERE lesson_id = 'C1-L32';
DELETE FROM lesson_history WHERE lesson_id = 'C1-L32';
DELETE FROM grammar_sentences WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'C1-L32');
DELETE FROM vocabulary_items WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'C1-L32');
DELETE FROM lesson_activities WHERE lesson_id = 'C1-L32';
DELETE FROM lessons WHERE id = 'C1-L32';

INSERT INTO lessons (id, level, lesson_number, topic) VALUES
('C1-L32', 'C1', 32, 'Preserving Traditions in Modern Societies')
ON CONFLICT (id) DO UPDATE SET topic = EXCLUDED.topic;

DO $$
DECLARE
    lesson_id_var TEXT := 'C1-L32';
    activity_id_var UUID;
BEGIN
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'warm_up_speaking', 1, 'Preserving Traditions', 'Discuss preserving traditions', '{"prompt": "What traditions have you kept over time?"}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_intro', 2, 'Traditions Vocabulary', 'Learn vocabulary about traditions', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'preservation', 'การอนุรักษ์', NULL),
    (activity_id_var, 'custom', 'ประเพณี', NULL),
    (activity_id_var, 'evolution', 'วิวัฒนาการ', NULL),
    (activity_id_var, 'continuity', 'ความต่อเนื่อง', NULL),
    (activity_id_var, 'relevance', 'ความเกี่ยวข้อง', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_matching_drag', 3, 'Match Traditions Words', 'Match English words with Thai meanings', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'preservation', 'การอนุรักษ์', NULL),
    (activity_id_var, 'custom', 'ประเพณี', NULL),
    (activity_id_var, 'evolution', 'วิวัฒนาการ', NULL),
    (activity_id_var, 'continuity', 'ความต่อเนื่อง', NULL),
    (activity_id_var, 'relevance', 'ความเกี่ยวข้อง', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 4, 'Complete the Sentences 1', 'Fill with the correct word', '{"text": "Cultural ___ requires ___. Traditional ___ undergo ___.", "blanks": [{"id": "blank1", "text": "preservation", "options": ["preservation", "custom", "evolution", "continuity"], "correctAnswer": "preservation"}, {"id": "blank2", "text": "continuity", "options": ["continuity", "preservation", "custom", "relevance"], "correctAnswer": "continuity"}, {"id": "blank3", "text": "customs", "options": ["customs", "preservation", "evolution", "continuity"], "correctAnswer": "customs"}, {"id": "blank4", "text": "evolution", "options": ["evolution", "preservation", "custom", "continuity"], "correctAnswer": "evolution"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 5, 'Complete the Sentences 2', 'Fill with the correct word', '{"text": "Maintaining ___ ensures ___. Modern ___ requires ___.", "blanks": [{"id": "blank1", "text": "traditions", "options": ["traditions", "preservation", "custom", "evolution"], "correctAnswer": "traditions"}, {"id": "blank2", "text": "relevance", "options": ["relevance", "preservation", "continuity", "evolution"], "correctAnswer": "relevance"}, {"id": "blank3", "text": "preservation", "options": ["preservation", "custom", "evolution", "continuity"], "correctAnswer": "preservation"}, {"id": "blank4", "text": "adaptation", "options": ["adaptation", "preservation", "custom", "evolution"], "correctAnswer": "adaptation"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_explanation', 6, 'Advanced Perfect Aspect', 'Learn advanced perfect forms', '{"rules": "Advanced perfect aspect:\n- Present perfect: \"I have kept traditions for years.\"\n- Past perfect: \"I had preserved customs before they changed.\"\n- Future perfect: \"I will have maintained traditions by then.\"\n- Perfect continuous: \"I have been preserving customs for decades.\"\n\nUse for:\n- Completed actions with present relevance: \"I have kept traditions over time.\"\n- Past before past: \"I had preserved customs before modernization.\"\n- Future completion: \"I will have maintained traditions by next year.\"", "examples": ["I have kept traditions for many years.", "I had preserved customs before they evolved.", "I will have maintained traditions by next generation.", "I have been preserving customs for decades.", "Having kept traditions, communities maintain cultural continuity."]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 7, 'Build Sentences 1', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'I have kept traditions for many years.', 'I have kept traditions for many years.', '["I", "have", "kept", "traditions", "for", "many", "years."]'::jsonb),
    (activity_id_var, 'I had preserved customs before they evolved.', 'I had preserved customs before they evolved.', '["I", "had", "preserved", "customs", "before", "they", "evolved."]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 8, 'Build Sentences 2', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'I have been preserving customs for decades.', 'I have been preserving customs for decades.', '["I", "have", "been", "preserving", "customs", "for", "decades."]'::jsonb),
    (activity_id_var, 'Having kept traditions, communities maintain cultural continuity.', 'Having kept traditions, communities maintain cultural continuity.', '["Having", "kept", "traditions,", "communities", "maintain", "cultural", "continuity."]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'speaking_practice', 9, 'Discuss Traditions', 'Practice speaking about preserving traditions', '{"prompts": ["What traditions remain important to you?", "What traditions have changed?", "How are traditions preserved today?", "Why do some traditions disappear?", "How can traditions adapt to modern life?"]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (
      lesson_id,
      activity_type,
      activity_order,
      title,
      description,
      content
    ) VALUES (
      'C1-L32',
      'speaking_improvement',
      10,
      'Speaking Improvement',
      'Read the improved version of your speech',
      '{"type": "speaking_improvement", "similarityThreshold": 70}'::jsonb
    );
END $$;
