-- =========================================
-- Pre-fill Database with Sample Lesson Data
-- A1-L21: Colors
-- =========================================

DELETE FROM grammar_sentences WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'A1-L21');
DELETE FROM vocabulary_items WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'A1-L21');
DELETE FROM lesson_activities WHERE lesson_id = 'A1-L21';
DELETE FROM lessons WHERE id = 'A1-L21';

INSERT INTO lessons (id, level, lesson_number, topic) VALUES
('A1-L21', 'A1', 21, 'Colors')
ON CONFLICT (id) DO UPDATE SET topic = EXCLUDED.topic;

DO $$
DECLARE
    lesson_id_var TEXT := 'A1-L21';
    activity_id_var UUID;
BEGIN
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'warm_up_speaking', 1, 'Favorite Color', 'Talk about colors', '{"prompt": "What is your favorite color?"}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_intro', 2, 'Color Words', 'Learn color words', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'red', 'สีแดง', NULL),
    (activity_id_var, 'blue', 'สีน้ำเงิน', NULL),
    (activity_id_var, 'green', 'สีเขียว', NULL),
    (activity_id_var, 'black', 'สีดำ', NULL),
    (activity_id_var, 'white', 'สีขาว', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_matching_drag', 3, 'Match Color Words', 'Match color words', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'red', 'สีแดง', NULL),
    (activity_id_var, 'blue', 'สีน้ำเงิน', NULL),
    (activity_id_var, 'green', 'สีเขียว', NULL),
    (activity_id_var, 'black', 'สีดำ', NULL),
    (activity_id_var, 'white', 'สีขาว', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 4, 'Complete the Sentences 1', 'Fill with the correct word', '{"text": "This bag is ___. That car is ___.", "blanks": [{"id": "blank1", "text": "blue", "options": ["blue", "red", "green", "black"], "correctAnswer": "blue"}, {"id": "blank2", "text": "red", "options": ["red", "white", "green", "blue"], "correctAnswer": "red"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 5, 'Complete the Sentences 2', 'Fill with the correct word', '{"text": "The board is ___. The shirt is ___.", "blanks": [{"id": "blank1", "text": "white", "options": ["white", "black", "blue", "red"], "correctAnswer": "white"}, {"id": "blank2", "text": "black", "options": ["black", "green", "white", "red"], "correctAnswer": "black"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_explanation', 6, 'Adjectives + Noun', 'Put color before noun', '{"rules": "Put color before the noun.\n- red bag, blue pen, green shirt.\nUse be + color: It is red.", "examples": ["This is a red bag.", "That is a blue pen.", "It is green.", "The shoes are black.", "Is the shirt white?"]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 7, 'Build Sentences 1', 'Arrange words', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'This is a red bag', 'This is a red bag.', '["This", "is", "a", "red", "bag."]'::jsonb),
    (activity_id_var, 'That is a blue pen', 'That is a blue pen.', '["That", "is", "a", "blue", "pen."]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 8, 'Build Sentences 2', 'Arrange words', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'The shoes are black', 'The shoes are black.', '["The", "shoes", "are", "black."]'::jsonb),
    (activity_id_var, 'Is the shirt white', 'Is the shirt white?', '["Is", "the", "shirt", "white?"]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'speaking_practice', 9, 'Talk About Colors', 'Practice colors', '{"prompts": ["What is your favorite color?", "Is your bag blue?", "Do you like red shoes?", "Are your shoes black?", "Is the board white?"]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (
      lesson_id,
      activity_type,
      activity_order,
      title,
      description,
      content
    ) VALUES (
      'A1-L21',
      'speaking_improvement',
      10,
      'Speaking Improvement',
      'Read the improved version of your speech',
      '{"type": "speaking_improvement", "similarityThreshold": 70}'::jsonb
    );
END $$;

