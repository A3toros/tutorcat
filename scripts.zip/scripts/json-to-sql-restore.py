#!/usr/bin/env python3
"""
Convert lesson_activity_results.json to SQL restore script
Properly escapes JSON for PostgreSQL
"""

import json
import sys
from pathlib import Path

def escape_sql_string(value):
    """Escape single quotes for SQL"""
    if isinstance(value, str):
        return value.replace("'", "''")
    return value

def json_to_sql_value(value):
    """Convert JSON value to SQL JSONB string"""
    if value is None:
        return 'NULL'
    json_str = json.dumps(value, ensure_ascii=False)
    # Escape single quotes for SQL
    json_str = json_str.replace("'", "''")
    return f"'{json_str}'::jsonb"

script_dir = Path(__file__).parent
json_file = script_dir.parent / 'lesson_activity_results.json'

if not json_file.exists():
    print(f"Error: {json_file} not found")
    sys.exit(1)

print(f"Reading {json_file}...")
with open(json_file, 'r', encoding='utf-8') as f:
    data = json.load(f)

output_file = script_dir / 'restore-lesson-activity-results.sql'

sql_lines = []
sql_lines.append("-- =========================================\n")
sql_lines.append("-- Restore Lesson Activity Results\n")
sql_lines.append("-- This script restores lesson_activity_results from backup JSON\n")
sql_lines.append("-- Generated from lesson_activity_results.json\n")
sql_lines.append("-- =========================================\n\n")

sql_lines.append("-- Clear existing data for this user (optional - comment out if you want to keep existing)\n")
sql_lines.append("-- DELETE FROM lesson_activity_results WHERE user_id = 'b20b9a1e-5633-4ed6-bd1a-fcea31cc9240';\n\n")

sql_lines.append("-- Restore lesson_activity_results\n")
sql_lines.append("INSERT INTO lesson_activity_results (\n")
sql_lines.append("    id,\n")
sql_lines.append("    user_id,\n")
sql_lines.append("    lesson_id,\n")
sql_lines.append("    activity_type,\n")
sql_lines.append("    activity_order,\n")
sql_lines.append("    score,\n")
sql_lines.append("    max_score,\n")
sql_lines.append("    attempts,\n")
sql_lines.append("    time_spent,\n")
sql_lines.append("    completed_at,\n")
sql_lines.append("    answers,\n")
sql_lines.append("    feedback,\n")
sql_lines.append("    created_at\n")
sql_lines.append(") VALUES\n")

values = []
for i, record in enumerate(data):
    # Build VALUES row
    value_parts = [
        f"'{record['id']}'",
        f"'{record['user_id']}'",
        f"'{record['lesson_id']}'",
        f"'{record['activity_type']}'",
        str(record['activity_order']),
        str(record['score']) if record['score'] is not None else 'NULL',
        str(record['max_score']) if record['max_score'] is not None else 'NULL',
        str(record['attempts']) if record['attempts'] is not None else 'NULL',
        str(record['time_spent']) if record['time_spent'] is not None else 'NULL',
        f"'{record['completed_at']}'::timestamp",
        json_to_sql_value(record.get('answers', {})),
        json_to_sql_value(record.get('feedback', {})),
        f"'{record['created_at']}'::timestamp"
    ]
    
    values.append(f"({', '.join(value_parts)})")

sql_lines.append(',\n'.join(values))
sql_lines.append("\nON CONFLICT (id) DO UPDATE SET\n")
sql_lines.append("    user_id = EXCLUDED.user_id,\n")
sql_lines.append("    lesson_id = EXCLUDED.lesson_id,\n")
sql_lines.append("    activity_type = EXCLUDED.activity_type,\n")
sql_lines.append("    activity_order = EXCLUDED.activity_order,\n")
sql_lines.append("    score = EXCLUDED.score,\n")
sql_lines.append("    max_score = EXCLUDED.max_score,\n")
sql_lines.append("    attempts = EXCLUDED.attempts,\n")
sql_lines.append("    time_spent = EXCLUDED.time_spent,\n")
sql_lines.append("    completed_at = EXCLUDED.completed_at,\n")
sql_lines.append("    answers = EXCLUDED.answers,\n")
sql_lines.append("    feedback = EXCLUDED.feedback,\n")
sql_lines.append("    created_at = EXCLUDED.created_at;\n\n")

sql_lines.append("-- =========================================\n")
sql_lines.append(f"-- Restore complete\n")
sql_lines.append(f"-- Total records restored: {len(data)}\n")
sql_lines.append("-- =========================================\n")

with open(output_file, 'w', encoding='utf-8') as f:
    f.write(''.join(sql_lines))

print(f"[OK] SQL restore script created: {output_file}")
print(f"[OK] Total records: {len(data)}")
print(f"\nTo restore, run:")
print(f"  - Neon Console: SQL Editor -> Paste contents of {output_file.name} -> Run")
print(f"  - PostgreSQL CLI: psql \"your-connection-string\" -f {output_file.name}")

