-- =========================================
-- Pre-fill Database with Sample Lesson Data
-- B1-L43: Budgeting
-- =========================================

DELETE FROM grammar_sentences WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'B1-L43');
DELETE FROM vocabulary_items WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'B1-L43');
DELETE FROM lesson_activities WHERE lesson_id = 'B1-L43';
DELETE FROM lessons WHERE id = 'B1-L43';

INSERT INTO lessons (id, level, lesson_number, topic) VALUES
('B1-L43', 'B1', 43, 'Budgeting')
ON CONFLICT (id) DO UPDATE SET topic = EXCLUDED.topic;

DO $$
DECLARE
    lesson_id_var TEXT := 'B1-L43';
    activity_id_var UUID;
BEGIN
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'warm_up_speaking', 1, 'Monthly Budget', 'Talk about planning money monthly', '{"prompt": "How do you actually plan a monthly budget?"}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_intro', 2, 'Budget Words', 'Learn vocabulary about budgeting', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'budget', 'งบประมาณ', NULL),
    (activity_id_var, 'expense', 'ค่าใช้จ่าย', NULL),
    (activity_id_var, 'category', 'หมวดหมู่', NULL),
    (activity_id_var, 'total', 'ยอดรวม', NULL),
    (activity_id_var, 'leftover', 'เหลืออยู่', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_matching_drag', 3, 'Match Budget Words', 'Match words with meanings', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'budget', 'งบประมาณ', NULL),
    (activity_id_var, 'expense', 'ค่าใช้จ่าย', NULL),
    (activity_id_var, 'category', 'หมวดหมู่', NULL),
    (activity_id_var, 'total', 'ยอดรวม', NULL),
    (activity_id_var, 'leftover', 'เหลืออยู่', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 4, 'Complete the Sentences 1', 'Fill with the correct word', '{"text": "We set a ___. Each ___ is listed. I track the ___.", "blanks": [{"id": "blank1", "text": "budget", "options": ["budget", "expense", "category", "total"], "correctAnswer": "budget"}, {"id": "blank2", "text": "expense", "options": ["expense", "category", "budget", "leftover"], "correctAnswer": "expense"}, {"id": "blank3", "text": "total", "options": ["total", "category", "budget", "leftover"], "correctAnswer": "total"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 5, 'Complete the Sentences 2', 'Fill with the correct word', '{"text": "We group items by ___. Money ___ helps us decide. I see what is ___.", "blanks": [{"id": "blank1", "text": "category", "options": ["category", "expense", "budget", "total"], "correctAnswer": "category"}, {"id": "blank2", "text": "leftover", "options": ["leftover", "category", "expense", "total"], "correctAnswer": "leftover"}, {"id": "blank3", "text": "leftover", "options": ["leftover", "budget", "category", "expense"], "correctAnswer": "leftover"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    -- Grammar Explanation: Articles (definite vs zero) — budgeting
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_explanation', 6, 'Articles in Budgeting', 'Use the/zero article with general vs specific money items', '{"rules": "Use the for specific known items: the budget, the total. Use zero article for general plural/uncountable: pay bills, track expenses.\\n- The budget is tight.\\n- We track expenses weekly.\\nAvoid extra articles.", "examples": ["The budget is tight this month.", "We track expenses each week.", "The total is higher than expected.", "I reviewed categories again.", "They pay bills on the first day."]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 7, 'Build Sentences 1', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'The budget is tight this month', 'The budget is tight this month', '["The", "budget", "is", "tight", "this", "month"]'::jsonb),
    (activity_id_var, 'We track expenses each week', 'We track expenses each week', '["We", "track", "expenses", "each", "week"]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 8, 'Build Sentences 2', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'The total is higher than expected', 'The total is higher than expected', '["The", "total", "is", "higher", "than", "expected"]'::jsonb),
    (activity_id_var, 'They pay bills on the first day', 'They pay bills on the first day', '["They", "pay", "bills", "on", "the", "first", "day"]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'speaking_practice', 9, 'Talk About Budgeting', 'Practice talking about budgeting habits', '{"prompts": ["How do you actually plan a monthly budget?", "What expense surprised you lately?", "When do you decide to cut costs?"]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (
      lesson_id,
      activity_type,
      activity_order,
      title,
      description,
      content
    ) VALUES (
      'B1-L43',
      'speaking_improvement',
      10,
      'Speaking Improvement',
      'Read the improved version of your speech',
      '{"type": "speaking_improvement", "similarityThreshold": 70}'::jsonb
    );
END $$;

