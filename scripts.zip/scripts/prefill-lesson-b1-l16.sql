-- =========================================
-- Pre-fill Database with Sample Lesson Data
-- B1-L16: Health Problems & Advice
-- =========================================

DELETE FROM grammar_sentences WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'B1-L16');
DELETE FROM vocabulary_items WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'B1-L16');
DELETE FROM lesson_activities WHERE lesson_id = 'B1-L16';
DELETE FROM lessons WHERE id = 'B1-L16';

INSERT INTO lessons (id, level, lesson_number, topic) VALUES
('B1-L16', 'B1', 16, 'Health Problems & Advice')
ON CONFLICT (id) DO UPDATE SET topic = EXCLUDED.topic;

DO $$
DECLARE
    lesson_id_var TEXT := 'B1-L16';
    activity_id_var UUID;
BEGIN
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'warm_up_speaking', 1, 'Health Choices', 'Talk about what you do when you feel sick', '{"prompt": "What do you do first when you feel sick?"}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_intro', 2, 'Health Words', 'Learn vocabulary about health problems and advice', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'symptom', 'อาการ', NULL),
    (activity_id_var, 'rest', 'พักผ่อน', NULL),
    (activity_id_var, 'consult', 'ปรึกษา', NULL),
    (activity_id_var, 'remedy', 'การรักษา', NULL),
    (activity_id_var, 'clinic', 'คลินิก', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_matching_drag', 3, 'Match Health Words', 'Match words with meanings', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'symptom', 'อาการ', NULL),
    (activity_id_var, 'rest', 'พักผ่อน', NULL),
    (activity_id_var, 'consult', 'ปรึกษา', NULL),
    (activity_id_var, 'remedy', 'การรักษา', NULL),
    (activity_id_var, 'clinic', 'คลินิก', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 4, 'Complete the Sentences 1', 'Fill with the correct word', '{"text": "I check my ___. Then I take ___. I try a simple ___.", "blanks": [{"id": "blank1", "text": "symptoms", "options": ["symptoms", "rest", "remedy", "clinic"], "correctAnswer": "symptoms"}, {"id": "blank2", "text": "rest", "options": ["rest", "consult", "clinic", "symptom"], "correctAnswer": "rest"}, {"id": "blank3", "text": "remedy", "options": ["remedy", "clinic", "consult", "rest"], "correctAnswer": "remedy"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 5, 'Complete the Sentences 2', 'Fill with the correct word', '{"text": "If it gets worse, I ___ a doctor. I can go to a ___. I explain every ___.", "blanks": [{"id": "blank1", "text": "consult", "options": ["consult", "remedy", "clinic", "rest"], "correctAnswer": "consult"}, {"id": "blank2", "text": "clinic", "options": ["clinic", "consult", "rest", "remedy"], "correctAnswer": "clinic"}, {"id": "blank3", "text": "symptom", "options": ["symptom", "clinic", "consult", "rest"], "correctAnswer": "symptom"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    -- Grammar Explanation: Zero Conditional (health advice)
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_explanation', 6, 'Zero Conditional for Health Advice', 'Use if + present, present to give general advice and results', '{"rules": "Zero conditional: If + present simple, present simple to show general truths or habits.\\n- If I feel sick, I rest.\\n- If symptoms stay, I see a doctor.\\nUse for advice and predictable results.", "examples": ["If I feel sick, I rest at home.", "If symptoms stay, I consult a doctor.", "If I am tired, I go to bed early.", "If it hurts, I stop the activity.", "If I get a fever, I call the clinic."]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 7, 'Build Sentences 1', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'If I feel sick I rest at home', 'If I feel sick, I rest at home', '["If", "I", "feel", "sick,", "I", "rest", "at", "home"]'::jsonb),
    (activity_id_var, 'If symptoms stay I consult a doctor', 'If symptoms stay, I consult a doctor', '["If", "symptoms", "stay,", "I", "consult", "a", "doctor"]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 8, 'Build Sentences 2', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'If it hurts I stop the activity', 'If it hurts, I stop the activity', '["If", "it", "hurts,", "I", "stop", "the", "activity"]'::jsonb),
    (activity_id_var, 'If I get a fever I call the clinic', 'If I get a fever, I call the clinic', '["If", "I", "get", "a", "fever,", "I", "call", "the", "clinic"]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'speaking_practice', 9, 'Talk About Health Choices', 'Practice talking about handling health issues', '{"prompts": ["What do you do first when you feel sick?", "Who gives you health advice you trust?", "How do you decide it is time to see a doctor?"]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (
      lesson_id,
      activity_type,
      activity_order,
      title,
      description,
      content
    ) VALUES (
      'B1-L16',
      'speaking_improvement',
      10,
      'Speaking Improvement',
      'Read the improved version of your speech',
      '{"type": "speaking_improvement", "similarityThreshold": 70}'::jsonb
    );
END $$;


