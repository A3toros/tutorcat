-- =========================================
-- Pre-fill Database with Sample Lesson Data
-- C1-L39: Cultural Stereotypes
-- =========================================
DELETE FROM lesson_activity_results WHERE lesson_id = 'C1-L39';
DELETE FROM user_progress WHERE lesson_id = 'C1-L39';
DELETE FROM lesson_history WHERE lesson_id = 'C1-L39';
DELETE FROM grammar_sentences WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'C1-L39');
DELETE FROM vocabulary_items WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'C1-L39');
DELETE FROM lesson_activities WHERE lesson_id = 'C1-L39';
DELETE FROM lessons WHERE id = 'C1-L39';

INSERT INTO lessons (id, level, lesson_number, topic) VALUES
('C1-L39', 'C1', 39, 'Cultural Stereotypes')
ON CONFLICT (id) DO UPDATE SET topic = EXCLUDED.topic;

DO $$
DECLARE
    lesson_id_var TEXT := 'C1-L39';
    activity_id_var UUID;
BEGIN
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'warm_up_speaking', 1, 'Cultural Stereotypes', 'Discuss cultural stereotypes', '{"prompt": "Why do stereotypes persist?"}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_intro', 2, 'Stereotypes Vocabulary', 'Learn vocabulary about stereotypes', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'stereotype', 'ภาพเหมารวม', NULL),
    (activity_id_var, 'formation', 'การก่อตัว', NULL),
    (activity_id_var, 'inaccuracy', 'ความไม่ถูกต้อง', NULL),
    (activity_id_var, 'harm', 'อันตราย', NULL),
    (activity_id_var, 'challenge', 'ความท้าทาย', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_matching_drag', 3, 'Match Stereotypes Words', 'Match English words with Thai meanings', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'stereotype', 'ภาพเหมารวม', NULL),
    (activity_id_var, 'formation', 'การก่อตัว', NULL),
    (activity_id_var, 'inaccuracy', 'ความไม่ถูกต้อง', NULL),
    (activity_id_var, 'harm', 'อันตราย', NULL),
    (activity_id_var, 'challenge', 'ความท้าทาย', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 4, 'Complete the Sentences 1', 'Fill with the correct word', '{"text": "Stereotype ___ leads to ___. ___ of stereotypes causes ___.", "blanks": [{"id": "blank1", "text": "formation", "options": ["formation", "stereotype", "inaccuracy", "harm"], "correctAnswer": "formation"}, {"id": "blank2", "text": "inaccuracy", "options": ["inaccuracy", "formation", "stereotype", "harm"], "correctAnswer": "inaccuracy"}, {"id": "blank3", "text": "Harm", "options": ["Harm", "Stereotype", "Formation", "Inaccuracy"], "correctAnswer": "Harm"}, {"id": "blank4", "text": "harm", "options": ["harm", "formation", "inaccuracy", "challenge"], "correctAnswer": "harm"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 5, 'Complete the Sentences 2', 'Fill with the correct word', '{"text": "Challenging ___ requires awareness. ___ of stereotypes promotes understanding.", "blanks": [{"id": "blank1", "text": "stereotypes", "options": ["stereotypes", "formation", "inaccuracy", "harm"], "correctAnswer": "stereotypes"}, {"id": "blank2", "text": "Challenge", "options": ["Challenge", "Stereotype", "Formation", "Harm"], "correctAnswer": "Challenge"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_explanation', 6, 'Modals: Certainty', 'Learn modals expressing certainty', '{"rules": "Modals for certainty:\n- \"must\" (high certainty): \"Stereotypes must be inaccurate.\"\n- \"should\" (probable): \"Stereotypes should be challenged.\"\n- \"might/may\" (possible): \"Stereotypes might be harmful.\"\n- \"could\" (less certain): \"Stereotypes could be wrong.\"\n\nUse for:\n- Expressing confidence: \"I am certain stereotypes are inaccurate.\"\n- Showing uncertainty: \"I am not sure if stereotypes are wrong.\"\n- Speculating: \"Stereotypes might cause harm.\"", "examples": ["Stereotypes must be inaccurate given the evidence.", "I should be certain that stereotypes cause harm.", "Stereotypes might be harmful if unchallenged.", "I could be wrong about stereotype accuracy.", "You may be confident that stereotypes are inaccurate."]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 7, 'Build Sentences 1', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'Stereotypes must be inaccurate given the evidence.', 'Stereotypes must be inaccurate given the evidence.', '["Stereotypes", "must", "be", "inaccurate", "given", "the", "evidence."]'::jsonb),
    (activity_id_var, 'I should be certain that stereotypes cause harm.', 'I should be certain that stereotypes cause harm.', '["I", "should", "be", "certain", "that", "stereotypes", "cause", "harm."]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 8, 'Build Sentences 2', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'Stereotypes might be harmful if unchallenged.', 'Stereotypes might be harmful if unchallenged.', '["Stereotypes", "might", "be", "harmful", "if", "unchallenged."]'::jsonb),
    (activity_id_var, 'You may be confident that stereotypes are inaccurate.', 'You may be confident that stereotypes are inaccurate.', '["You", "may", "be", "confident", "that", "stereotypes", "are", "inaccurate."]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'speaking_practice', 9, 'Discuss Stereotypes', 'Practice speaking about cultural stereotypes', '{"prompts": ["How do stereotypes form?", "How sure can we be they are inaccurate?", "What harm do stereotypes cause?", "When did you change a belief?", "How can stereotypes be challenged?"]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (
      lesson_id,
      activity_type,
      activity_order,
      title,
      description,
      content
    ) VALUES (
      'C1-L39',
      'speaking_improvement',
      10,
      'Speaking Improvement',
      'Read the improved version of your speech',
      '{"type": "speaking_improvement", "similarityThreshold": 70}'::jsonb
    );
END $$;
