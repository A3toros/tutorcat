-- =========================================
-- Pre-fill Database with Sample Lesson Data
-- B2-L92: Study habits and routines
-- =========================================

DELETE FROM grammar_sentences WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'B2-L92');
DELETE FROM vocabulary_items WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'B2-L92');
DELETE FROM lesson_activities WHERE lesson_id = 'B2-L92';
DELETE FROM lessons WHERE id = 'B2-L92';

INSERT INTO lessons (id, level, lesson_number, topic) VALUES
('B2-L92', 'B2', 92, 'Study habits and routines')
ON CONFLICT (id) DO UPDATE SET topic = EXCLUDED.topic;

DO $$
DECLARE
    lesson_id_var TEXT := 'B2-L92';
    activity_id_var UUID;
BEGIN
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'warm_up_speaking', 1, 'Reliable Routines', 'Talk about routines you rely on', '{"prompt": "Which habit, which you rely on, keeps you steady, and how do you tweak it?"}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_intro', 2, 'Routine Words', 'Key words for steady study', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'streak', 'ช่วงต่อเนื่อง/สถิติทำต่อเนื่อง', NULL),
    (activity_id_var, 'tweak', 'ปรับเล็กน้อย', NULL),
    (activity_id_var, 'routine', 'กิจวัตร', NULL),
    (activity_id_var, 'track', 'ติดตาม', NULL),
    (activity_id_var, 'habit', 'นิสัย/พฤติกรรม', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_matching_drag', 3, 'Match Routine Words', 'Match words with meanings', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'streak', 'ช่วงต่อเนื่อง/สถิติทำต่อเนื่อง', NULL),
    (activity_id_var, 'tweak', 'ปรับเล็กน้อย', NULL),
    (activity_id_var, 'routine', 'กิจวัตร', NULL),
    (activity_id_var, 'track', 'ติดตาม', NULL),
    (activity_id_var, 'habit', 'นิสัย/พฤติกรรม', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 4, 'Complete the Sentences 1', 'Fill with the correct word', '{"text": "A steady ___ helps my ___. I ___ my progress.", "blanks": [{"id": "blank1", "text": "routine", "options": ["routine", "streak", "habit", "track"], "correctAnswer": "routine"}, {"id": "blank2", "text": "streak", "options": ["streak", "habit", "track", "tweak"], "correctAnswer": "streak"}, {"id": "blank3", "text": "track", "options": ["track", "tweak", "routine", "streak"], "correctAnswer": "track"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 5, 'Complete the Sentences 2', 'Fill with the correct word', '{"text": "I keep one key ___. I ____ it weekly.", "blanks": [{"id": "blank1", "text": "habit", "options": ["habit", "routine", "streak", "track"], "correctAnswer": "habit"}, {"id": "blank2", "text": "tweak", "options": ["tweak", "track", "habit", "streak"], "correctAnswer": "tweak"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_explanation', 6, 'Relative Clauses (non-defining)', 'Add extra info about habits', '{"rules": "Use commas with who/which/where to add non-essential info. Do not drop the pronoun.\\n- My habit, which I rely on, keeps me steady.\\n- The routine, which I track, is flexible.", "examples": ["My morning routine, which I track, keeps me calm.", "The streak, which started last month, motivates me.", "This habit, which my mentor suggested, works well.", "The checklist, which is short, helps me start fast.", "My study spot, which is quiet, keeps me focused."]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 7, 'Build Sentences 1', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'My morning routine, which I track, keeps me calm', 'My morning routine, which I track, keeps me calm.', '["My", "morning", "routine,", "which", "I", "track,", "keeps", "me", "calm."]'::jsonb),
    (activity_id_var, 'The streak, which started last month, motivates me', 'The streak, which started last month, motivates me.', '["The", "streak,", "which", "started", "last", "month,", "motivates", "me."]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 8, 'Build Sentences 2', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'The checklist, which is short, helps me start fast', 'The checklist, which is short, helps me start fast.', '["The", "checklist,", "which", "is", "short,", "helps", "me", "start", "fast."]'::jsonb),
    (activity_id_var, 'My study spot, which is quiet, keeps me focused', 'My study spot, which is quiet, keeps me focused.', '["My", "study", "spot,", "which", "is", "quiet,", "keeps", "me", "focused."]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'speaking_practice', 9, 'Talk About Study Routines', 'Practice non-defining relatives', '{"prompts": ["Which habit, which you rely on, keeps you steady?", "How do you tweak your routine weekly?", "What streak motivates you now?"]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (
      lesson_id,
      activity_type,
      activity_order,
      title,
      description,
      content
    ) VALUES (
      'B2-L92',
      'speaking_improvement',
      10,
      'Speaking Improvement',
      'Read the improved version of your speech',
      '{"type": "speaking_improvement", "similarityThreshold": 70}'::jsonb
    );
END $$;


