-- =========================================
-- Pre-fill Database with Sample Lesson Data
-- C1-L45: Technology and Attention Span
-- =========================================
DELETE FROM lesson_activity_results WHERE lesson_id = 'C1-L45';
DELETE FROM user_progress WHERE lesson_id = 'C1-L45';
DELETE FROM lesson_history WHERE lesson_id = 'C1-L45';
DELETE FROM grammar_sentences WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'C1-L45');
DELETE FROM vocabulary_items WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'C1-L45');
DELETE FROM lesson_activities WHERE lesson_id = 'C1-L45';
DELETE FROM lessons WHERE id = 'C1-L45';

INSERT INTO lessons (id, level, lesson_number, topic) VALUES
('C1-L45', 'C1', 45, 'Technology and Attention Span')
ON CONFLICT (id) DO UPDATE SET topic = EXCLUDED.topic;

DO $$
DECLARE
    lesson_id_var TEXT := 'C1-L45';
    activity_id_var UUID;
BEGIN
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'warm_up_speaking', 1, 'Technology and Attention', 'Discuss technology and attention span', '{"prompt": "What affects your ability to focus?"}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_intro', 2, 'Attention Vocabulary', 'Learn vocabulary about attention', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'attention', 'ความสนใจ', NULL),
    (activity_id_var, 'distraction', 'สิ่งที่ทำให้ไขว้เขว', NULL),
    (activity_id_var, 'concentration', 'การมีสมาธิ', NULL),
    (activity_id_var, 'strategy', 'กลยุทธ์', NULL),
    (activity_id_var, 'improvement', 'การปรับปรุง', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_matching_drag', 3, 'Match Attention Words', 'Match English words with Thai meanings', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'attention', 'ความสนใจ', NULL),
    (activity_id_var, 'distraction', 'สิ่งที่ทำให้ไขว้เขว', NULL),
    (activity_id_var, 'concentration', 'การมีสมาธิ', NULL),
    (activity_id_var, 'strategy', 'กลยุทธ์', NULL),
    (activity_id_var, 'improvement', 'การปรับปรุง', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 4, 'Complete the Sentences 1', 'Fill with the correct word', '{"text": "Technology affects ___. Digital ___ reduce ___. Protecting ___ requires ___.", "blanks": [{"id": "blank1", "text": "attention", "options": ["attention", "distraction", "concentration", "strategy"], "correctAnswer": "attention"}, {"id": "blank2", "text": "distractions", "options": ["distractions", "attention", "concentration", "strategy"], "correctAnswer": "distractions"}, {"id": "blank3", "text": "concentration", "options": ["concentration", "attention", "distraction", "strategy"], "correctAnswer": "concentration"}, {"id": "blank4", "text": "strategies", "options": ["strategies", "attention", "distraction", "concentration"], "correctAnswer": "strategies"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 5, 'Complete the Sentences 2', 'Fill with the correct word', '{"text": "Effective ___ help maintain ___. ___ in attention requires practice.", "blanks": [{"id": "blank1", "text": "strategies", "options": ["strategies", "attention", "distraction", "concentration"], "correctAnswer": "strategies"}, {"id": "blank2", "text": "focus", "options": ["focus", "attention", "distraction", "concentration"], "correctAnswer": "focus"}, {"id": "blank3", "text": "Improvement", "options": ["Improvement", "Attention", "Distraction", "Concentration"], "correctAnswer": "Improvement"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_explanation', 6, 'Articles: Abstract Reference', 'Learn articles with abstract nouns', '{"rules": "Articles with abstract nouns:\n- Use \"the\" when referring to a specific abstract concept: \"the attention span\"\n- Omit article for general abstract concepts: \"attention is important\"\n- Use \"a/an\" when classifying: \"an attention problem\"\n\nStylistic use:\n- \"The\" can emphasize importance: \"the ability to focus\"\n- Zero article for broad concepts: \"technology affects attention\"\n\nUse for:\n- General statements: \"Attention requires protection.\"\n- Specific reference: \"The attention span has decreased.\"\n- Classification: \"Distraction is a common problem.\"", "examples": ["The attention span has decreased over time.", "Attention is essential for learning.", "A distraction can disrupt concentration.", "The ability to focus requires practice.", "Technology affects attention in various ways."]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 7, 'Build Sentences 1', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'The attention span has decreased over time.', 'The attention span has decreased over time.', '["The", "attention", "span", "has", "decreased", "over", "time."]'::jsonb),
    (activity_id_var, 'Attention is essential for learning.', 'Attention is essential for learning.', '["Attention", "is", "essential", "for", "learning."]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 8, 'Build Sentences 2', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'A distraction can disrupt concentration.', 'A distraction can disrupt concentration.', '["A", "distraction", "can", "disrupt", "concentration."]'::jsonb),
    (activity_id_var, 'The ability to focus requires practice.', 'The ability to focus requires practice.', '["The", "ability", "to", "focus", "requires", "practice."]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'speaking_practice', 9, 'Discuss Attention Span', 'Practice speaking about technology and attention', '{"prompts": ["How has technology affected attention?", "What distracts you most?", "How do you protect concentration?", "What strategies help maintain focus?", "How can attention be improved?"]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (
      lesson_id,
      activity_type,
      activity_order,
      title,
      description,
      content
    ) VALUES (
      'C1-L45',
      'speaking_improvement',
      10,
      'Speaking Improvement',
      'Read the improved version of your speech',
      '{"type": "speaking_improvement", "similarityThreshold": 70}'::jsonb
    );
END $$;
