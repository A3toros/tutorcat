-- =========================================
-- Pre-fill Database with Sample Lesson Data
-- B1-L79: Travel Alone vs With Others
-- =========================================

DELETE FROM grammar_sentences WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'B1-L79');
DELETE FROM vocabulary_items WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'B1-L79');
DELETE FROM lesson_activities WHERE lesson_id = 'B1-L79';
DELETE FROM lessons WHERE id = 'B1-L79';

INSERT INTO lessons (id, level, lesson_number, topic) VALUES
('B1-L79', 'B1', 79, 'Travel Alone vs With Others')
ON CONFLICT (id) DO UPDATE SET topic = EXCLUDED.topic;

DO $$
DECLARE
    lesson_id_var TEXT := 'B1-L79';
    activity_id_var UUID;
BEGIN
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'warm_up_speaking', 1, 'Solo or Group Travel', 'Talk about travel styles', '{"prompt": "What were you doing the first time you traveled alone?"}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_intro', 2, 'Travel Style Words', 'Learn vocabulary about solo vs group travel', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'solo', 'คนเดียว', NULL),
    (activity_id_var, 'companion', 'เพื่อนร่วมทาง', NULL),
    (activity_id_var, 'plan', 'วางแผน', NULL),
    (activity_id_var, 'safety', 'ความปลอดภัย', NULL),
    (activity_id_var, 'adjust', 'ปรับตัว', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_matching_drag', 3, 'Match Travel Style Words', 'Match words with meanings', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'solo', 'คนเดียว', NULL),
    (activity_id_var, 'companion', 'เพื่อนร่วมทาง', NULL),
    (activity_id_var, 'plan', 'วางแผน', NULL),
    (activity_id_var, 'safety', 'ความปลอดภัย', NULL),
    (activity_id_var, 'adjust', 'ปรับตัว', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 4, 'Complete the Sentences 1', 'Fill with the correct word', '{"text": "I traveled ___. A ___ joined later. We made a quick ___.", "blanks": [{"id": "blank1", "text": "solo", "options": ["solo", "companion", "plan", "safety"], "correctAnswer": "solo"}, {"id": "blank2", "text": "companion", "options": ["companion", "solo", "safety", "adjust"], "correctAnswer": "companion"}, {"id": "blank3", "text": "plan", "options": ["plan", "adjust", "safety", "companion"], "correctAnswer": "plan"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 5, 'Complete the Sentences 2', 'Fill with the correct word', '{"text": "We talked about ___. I had to ___. The ___ of the group mattered.", "blanks": [{"id": "blank1", "text": "safety", "options": ["safety", "plan", "companion", "adjust"], "correctAnswer": "safety"}, {"id": "blank2", "text": "adjust", "options": ["adjust", "solo", "plan", "safety"], "correctAnswer": "adjust"}, {"id": "blank3", "text": "safety", "options": ["safety", "plan", "companion", "adjust"], "correctAnswer": "safety"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    -- Grammar Explanation: Past Continuous (travel moments)
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_explanation', 6, 'Past Continuous for Travel Moments', 'Use was/were + verb-ing for actions in progress during travel', '{"rules": "Past continuous: was/were + verb-ing to describe what was happening when something else occurred.\\n- I was planning routes when my companion arrived.\\n- We were walking when the weather changed.", "examples": ["I was planning routes when my companion arrived.", "We were walking when the weather changed.", "She was adjusting to the city when friends joined.", "They were checking safety tips while traveling.", "We were waiting at the station when the train was delayed."]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 7, 'Build Sentences 1', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'I was planning routes when my companion arrived', 'I was planning routes when my companion arrived', '["I", "was", "planning", "routes", "when", "my", "companion", "arrived"]'::jsonb),
    (activity_id_var, 'We were walking when the weather changed', 'We were walking when the weather changed', '["We", "were", "walking", "when", "the", "weather", "changed"]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 8, 'Build Sentences 2', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'She was adjusting to the city when friends joined', 'She was adjusting to the city when friends joined', '["She", "was", "adjusting", "to", "the", "city", "when", "friends", "joined"]'::jsonb),
    (activity_id_var, 'We were waiting at the station when the train was delayed', 'We were waiting at the station when the train was delayed', '["We", "were", "waiting", "at", "the", "station", "when", "the", "train", "was", "delayed"]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'speaking_practice', 9, 'Talk About Travel Styles', 'Practice talking about solo vs group travel', '{"prompts": ["What were you doing the first time you traveled alone?", "How is traveling with friends different for you?", "When did a companion really help?"]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (
      lesson_id,
      activity_type,
      activity_order,
      title,
      description,
      content
    ) VALUES (
      'B1-L79',
      'speaking_improvement',
      10,
      'Speaking Improvement',
      'Read the improved version of your speech',
      '{"type": "speaking_improvement", "similarityThreshold": 70}'::jsonb
    );
END $$;

