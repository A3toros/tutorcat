-- ===== LESSON B1-L62 =====

-- =========================================
-- Pre-fill Database with Sample Lesson Data
-- B1-L62: Protecting Nature
-- =========================================

DELETE FROM lesson_activity_results WHERE lesson_id = 'B1-L62';
DELETE FROM user_progress WHERE lesson_id = 'B1-L62';
DELETE FROM lesson_history WHERE lesson_id = 'B1-L62';
DELETE FROM grammar_sentences WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'B1-L62');
DELETE FROM vocabulary_items WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'B1-L62');
DELETE FROM lesson_activities WHERE lesson_id = 'B1-L62';
DELETE FROM lessons WHERE id = 'B1-L62';

INSERT INTO lessons (id, level, lesson_number, topic) VALUES
('B1-L62', 'B1', 62, 'Protecting Nature')
ON CONFLICT (id) DO UPDATE SET topic = EXCLUDED.topic;

DO $$
DECLARE
    lesson_id_var TEXT := 'B1-L62';
    activity_id_var UUID;
BEGIN
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'warm_up_speaking', 1, 'Environmental Issues', 'Talk about nature protection in your area', '{"prompt": "What places near you are being protected?"}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_intro', 2, 'Conservation Words', 'Learn words related to environmental protection', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'conserved', 'อนุรักษ์', NULL),
    (activity_id_var, 'protected', 'ปกป้อง', NULL),
    (activity_id_var, 'restored', 'ฟื้นฟู', NULL),
    (activity_id_var, 'cleaned', 'ทำความสะอาด', NULL),
    (activity_id_var, 'planted', 'ปลูก', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_matching_drag', 3, 'Match Conservation Words', 'Match environmental protection words', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'conserved', 'อนุรักษ์', NULL),
    (activity_id_var, 'protected', 'ปกป้อง', NULL),
    (activity_id_var, 'restored', 'ฟื้นฟู', NULL),
    (activity_id_var, 'cleaned', 'ทำความสะอาด', NULL),
    (activity_id_var, 'planted', 'ปลูก', NULL);

    -- 4. Vocabulary Fill Blanks #1
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 4, 'Complete the Sentences 1', 'Fill in the blanks with correct words', '{"text": "Forests are ___ by volunteers. The river is ___ by law. Parks are ___ every year.", "blanks": [{"id": "blank1", "text": "conserved", "options": ["conserved", "protected", "restored", "cleaned"], "correctAnswer": "conserved"}, {"id": "blank2", "text": "protected", "options": ["protected", "conserved", "restored", "planted"], "correctAnswer": "protected"}, {"id": "blank3", "text": "cleaned", "options": ["cleaned", "conserved", "protected", "planted"], "correctAnswer": "cleaned"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    -- 5. Vocabulary Fill Blanks #2
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 5, 'Complete the Sentences 2', 'Fill in the blanks with correct words', '{"text": "The area was ___ last year. Trees are ___ every spring. Nature is being ___.", "blanks": [{"id": "blank1", "text": "restored", "options": ["restored", "conserved", "protected", "cleaned"], "correctAnswer": "restored"}, {"id": "blank2", "text": "planted", "options": ["planted", "conserved", "protected", "restored"], "correctAnswer": "planted"}, {"id": "blank3", "text": "protected", "options": ["protected", "conserved", "restored", "planted"], "correctAnswer": "protected"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    -- 6. Grammar Explanation
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_explanation', 6, 'Present Passive Voice', 'Learn present passive constructions', '{"rules": "Use passive voice when the action is more important than who does it:\n\n- Form: be + past participle (are conserved, is protected)\n- Use by to show who does the action (by volunteers, by law)\n- Use is for singular, are for plural\n- Focus on what happens, not who does it", "examples": ["Forests are conserved by volunteers.", "The river is protected by law.", "Trees are planted every year.", "Parks are cleaned regularly.", "Nature is being restored."]}'::jsonb)
    RETURNING id INTO activity_id_var;

    -- 7. Grammar Sentences #1
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 7, 'Build Sentences 1', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'Forests are conserved by volunteers', 'Forests are conserved by volunteers.', '["Forests", "are", "conserved", "by", "volunteers."]'::jsonb),
    (activity_id_var, 'The river is protected by law', 'The river is protected by law.', '["The", "river", "is", "protected", "by", "law."]'::jsonb);

    -- 8. Grammar Sentences #2
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 8, 'Build Sentences 2', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'Trees are planted every year', 'Trees are planted every year.', '["Trees", "are", "planted", "every", "year."]'::jsonb),
    (activity_id_var, 'Parks are cleaned regularly', 'Parks are cleaned regularly.', '["Parks", "are", "cleaned", "regularly."]'::jsonb);

    -- 9. Speaking Practice
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'speaking_practice', 9, 'Talk About Nature', 'Practice talking about the environment', '{"prompts": ["Do you like going to the park?", "What animals live near your home?", "Do you recycle at home?", "What can we do to protect nature?", "Are there protected areas near you?"]}'::jsonb)
    RETURNING id INTO activity_id_var;

    -- 10. Speaking Improvement
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'speaking_improvement', 10, 'Speaking Improvement', 'Read the improved version of your speech', '{"type": "speaking_improvement", "similarityThreshold": 70}'::jsonb)
    RETURNING id INTO activity_id_var;
END $$;