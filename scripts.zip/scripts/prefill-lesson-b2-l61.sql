-- =========================================
-- Pre-fill Database with Sample Lesson Data
-- B2-L61: Student discounts and costs
-- =========================================

DELETE FROM grammar_sentences WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'B2-L61');
DELETE FROM vocabulary_items WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'B2-L61');
DELETE FROM lesson_activities WHERE lesson_id = 'B2-L61';
DELETE FROM lessons WHERE id = 'B2-L61';

INSERT INTO lessons (id, level, lesson_number, topic) VALUES
('B2-L61', 'B2', 61, 'Student discounts and costs')
ON CONFLICT (id) DO UPDATE SET topic = EXCLUDED.topic;

DO $$
DECLARE
    lesson_id_var TEXT := 'B2-L61';
    activity_id_var UUID;
BEGIN
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'warm_up_speaking', 1, 'Saving Check', 'Talk about finding discounts', '{"prompt": "How have you been finding discounts, and what documents do you keep?"}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_intro', 2, 'Discount Words', 'Key words for student savings', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'discount', 'ส่วนลด', NULL),
    (activity_id_var, 'validate', 'ยืนยันความถูกต้อง', NULL),
    (activity_id_var, 'fare', 'ค่าโดยสาร', NULL),
    (activity_id_var, 'receipt', 'ใบเสร็จ', NULL),
    (activity_id_var, 'proof', 'หลักฐาน', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_matching_drag', 3, 'Match Discount Words', 'Match words with meanings', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'discount', 'ส่วนลด', NULL),
    (activity_id_var, 'validate', 'ยืนยันความถูกต้อง', NULL),
    (activity_id_var, 'fare', 'ค่าโดยสาร', NULL),
    (activity_id_var, 'receipt', 'ใบเสร็จ', NULL),
    (activity_id_var, 'proof', 'หลักฐาน', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 4, 'Complete the Sentences 1', 'Fill with the correct word', '{"text": "I ask for a student ___. They need to ___ my card. The bus ___ drops with the pass.", "blanks": [{"id": "blank1", "text": "discount", "options": ["discount", "fare", "validate", "receipt"], "correctAnswer": "discount"}, {"id": "blank2", "text": "validate", "options": ["validate", "proof", "receipt", "fare"], "correctAnswer": "validate"}, {"id": "blank3", "text": "fare", "options": ["fare", "discount", "receipt", "proof"], "correctAnswer": "fare"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 5, 'Complete the Sentences 2', 'Fill with the correct word', '{"text": "I keep a ___. I carry student ___.", "blanks": [{"id": "blank1", "text": "receipt", "options": ["receipt", "discount", "fare", "validate"], "correctAnswer": "receipt"}, {"id": "blank2", "text": "proof", "options": ["proof", "receipt", "validate", "discount"], "correctAnswer": "proof"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_explanation', 6, 'Present Perfect Continuous', 'Show ongoing saving habits', '{"rules": "Use have/has + been + -ing for actions started in the past and still continuing, often with for/since.\\n- I have been looking for discounts all semester.\\n- She has been keeping receipts since January.", "examples": ["I have been tracking fares for weeks.", "She has been validating her pass daily.", "They have been saving receipts for refunds.", "We have been keeping proof for discounts since orientation.", "He has been asking about student fares each month."]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 7, 'Build Sentences 1', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'I have been tracking fares for weeks', 'I have been tracking fares for weeks.', '["I", "have", "been", "tracking", "fares", "for", "weeks."]'::jsonb),
    (activity_id_var, 'She has been keeping receipts since January', 'She has been keeping receipts since January.', '["She", "has", "been", "keeping", "receipts", "since", "January."]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 8, 'Build Sentences 2', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'They have been saving receipts for refunds', 'They have been saving receipts for refunds.', '["They", "have", "been", "saving", "receipts", "for", "refunds."]'::jsonb),
    (activity_id_var, 'We have been keeping proof for discounts since orientation', 'We have been keeping proof for discounts since orientation.', '["We", "have", "been", "keeping", "proof", "for", "discounts", "since", "orientation."]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'speaking_practice', 9, 'Talk About Discounts', 'Practice present perfect continuous', '{"prompts": ["How have you been finding discounts?", "What documents do you keep for proof?", "When do you validate your pass?"]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (
      lesson_id,
      activity_type,
      activity_order,
      title,
      description,
      content
    ) VALUES (
      'B2-L61',
      'speaking_improvement',
      10,
      'Speaking Improvement',
      'Read the improved version of your speech',
      '{"type": "speaking_improvement", "similarityThreshold": 70}'::jsonb
    );
END $$;


