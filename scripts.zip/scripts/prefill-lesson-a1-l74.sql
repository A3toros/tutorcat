-- =========================================
-- Pre-fill Database with Sample Lesson Data
-- A1-L74: Simple Preferences
-- =========================================

DELETE FROM grammar_sentences WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'A1-L74');
DELETE FROM vocabulary_items WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'A1-L74');
DELETE FROM lesson_activities WHERE lesson_id = 'A1-L74';
DELETE FROM lessons WHERE id = 'A1-L74';

INSERT INTO lessons (id, level, lesson_number, topic) VALUES
('A1-L74', 'A1', 74, 'Simple Preferences')
ON CONFLICT (id) DO UPDATE SET topic = EXCLUDED.topic;

DO $$
DECLARE
    lesson_id_var TEXT := 'A1-L74';
    activity_id_var UUID;
BEGIN
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'warm_up_speaking', 1, 'Preferences', 'Talk about what you like', '{"prompt": "Do you like tea or coffee?"}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_intro', 2, 'Preference Words', 'Learn like/prefer words', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'like', 'ชอบ', NULL),
    (activity_id_var, 'prefer', 'ชอบมากกว่า', NULL),
    (activity_id_var, 'love', 'รัก/ชอบมาก', NULL),
    (activity_id_var, 'hate', 'เกลียด', NULL),
    (activity_id_var, 'okay', 'โอเค', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_matching_drag', 3, 'Match Preference Words', 'Match preference words', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'like', 'ชอบ', NULL),
    (activity_id_var, 'prefer', 'ชอบมากกว่า', NULL),
    (activity_id_var, 'love', 'รัก/ชอบมาก', NULL),
    (activity_id_var, 'hate', 'เกลียด', NULL),
    (activity_id_var, 'okay', 'โอเค', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 4, 'Complete the Sentences 1', 'Fill with the correct word', '{"text": "I ___ tea. I ___ coffee.", "blanks": [{"id": "blank1", "text": "like", "options": ["like", "prefer", "love", "hate"], "correctAnswer": "like"}, {"id": "blank2", "text": "prefer", "options": ["prefer", "like", "hate", "okay"], "correctAnswer": "prefer"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 5, 'Complete the Sentences 2', 'Fill with the correct word', '{"text": "I ___ rain. Rice is ___.", "blanks": [{"id": "blank1", "text": "hate", "options": ["hate", "love", "like", "prefer"], "correctAnswer": "hate"}, {"id": "blank2", "text": "okay", "options": ["okay", "prefer", "like", "hate"], "correctAnswer": "okay"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_explanation', 6, 'Like / Prefer / Hate', 'Express simple preferences', '{"rules": "Use like/prefer/love/hate + noun/verb-ing.\n- I like tea. I prefer coffee. I hate rain.\nAsk: Do you like rice?", "examples": ["I like tea.", "I prefer coffee.", "I love music.", "I hate rain.", "Is rice okay?"]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 7, 'Build Sentences 1', 'Arrange words', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'I like tea', 'I like tea.', '["I", "like", "tea."]'::jsonb),
    (activity_id_var, 'I prefer coffee', 'I prefer coffee.', '["I", "prefer", "coffee."]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 8, 'Build Sentences 2', 'Arrange words', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'I hate rain', 'I hate rain.', '["I", "hate", "rain."]'::jsonb),
    (activity_id_var, 'Is rice okay', 'Is rice okay?', '["Is", "rice", "okay?"]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'speaking_practice', 9, 'Talk About Preferences', 'Practice preferences', '{"prompts": ["Do you like tea or coffee?", "Do you prefer rice?", "Do you hate rain?", "Do you love music?", "Is rice okay?"]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (
      lesson_id,
      activity_type,
      activity_order,
      title,
      description,
      content
    ) VALUES (
      'A1-L74',
      'speaking_improvement',
      10,
      'Speaking Improvement',
      'Read the improved version of your speech',
      '{"type": "speaking_improvement", "similarityThreshold": 70}'::jsonb
    );
END $$;

