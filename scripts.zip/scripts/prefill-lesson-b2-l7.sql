-- =========================================
-- Pre-fill Database with Sample Lesson Data
-- B2-L7: Global Travel & Tourism
-- =========================================

DELETE FROM grammar_sentences WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'B2-L7');
DELETE FROM vocabulary_items WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'B2-L7');
DELETE FROM lesson_activities WHERE lesson_id = 'B2-L7';
DELETE FROM lessons WHERE id = 'B2-L7';

INSERT INTO lessons (id, level, lesson_number, topic) VALUES
('B2-L7', 'B2', 7, 'Global Travel & Tourism')
ON CONFLICT (id) DO UPDATE SET topic = EXCLUDED.topic;

DO $$
DECLARE
    lesson_id_var TEXT := 'B2-L7';
    activity_id_var UUID;
BEGIN
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'warm_up_speaking', 1, 'Trip Plans', 'Talk about future trips', '{"prompt": "Where will you be traveling next, and why?"}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_intro', 2, 'Travel Words', 'Key words for travel and tourism', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'itinerary', 'กำหนดการเดินทาง', NULL),
    (activity_id_var, 'layover', 'การแวะพักระหว่างทาง', NULL),
    (activity_id_var, 'tourism board', 'คณะกรรมการการท่องเที่ยว', NULL),
    (activity_id_var, 'sustainable travel', 'การท่องเที่ยวอย่างยั่งยืน', NULL),
    (activity_id_var, 'local economy', 'เศรษฐกิจท้องถิ่น', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_matching_drag', 3, 'Match Travel Words', 'Match words with meanings', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'itinerary', 'กำหนดการเดินทาง', NULL),
    (activity_id_var, 'layover', 'การแวะพักระหว่างทาง', NULL),
    (activity_id_var, 'tourism board', 'คณะกรรมการการท่องเที่ยว', NULL),
    (activity_id_var, 'sustainable travel', 'การท่องเที่ยวอย่างยั่งยืน', NULL),
    (activity_id_var, 'local economy', 'เศรษฐกิจท้องถิ่น', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 4, 'Complete the Sentences 1', 'Fill with the correct word', '{"text": "I shared the ___. We had a long ___. The ___ promotes safe trips.", "blanks": [{"id": "blank1", "text": "itinerary", "options": ["itinerary", "layover", "tourism board", "sustainable travel"], "correctAnswer": "itinerary"}, {"id": "blank2", "text": "layover", "options": ["layover", "itinerary", "local economy", "tourism board"], "correctAnswer": "layover"}, {"id": "blank3", "text": "tourism board", "options": ["tourism board", "itinerary", "layover", "sustainable travel"], "correctAnswer": "tourism board"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 5, 'Complete the Sentences 2', 'Fill with the correct word', '{"text": "I care about ___. Spending locally supports the ___. I planned time to rest during the ___.", "blanks": [{"id": "blank1", "text": "sustainable travel", "options": ["sustainable travel", "itinerary", "layover", "tourism board"], "correctAnswer": "sustainable travel"}, {"id": "blank2", "text": "local economy", "options": ["local economy", "tourism board", "itinerary", "layover"], "correctAnswer": "local economy"}, {"id": "blank3", "text": "layover", "options": ["layover", "local economy", "itinerary", "sustainable travel"], "correctAnswer": "layover"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_explanation', 6, 'Future Continuous & Future Perfect', 'Talk about future actions and completion', '{"rules": "Use will be + -ing for actions in progress at a future time. Use will have + past participle for actions completed before a future point.\\n- This time next week, I will be flying to Seoul.\\n- By Friday, I will have finished packing.", "examples": ["By June, we will have booked every train.", "At 10 p.m. tomorrow, I will be waiting at the airport.", "They will have planned a sustainable route.", "The tourism board will be promoting new trails next month.", "We will have supported the local economy by staying local."]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 7, 'Build Sentences 1', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'By Friday, we will have finished the itinerary', 'By Friday, we will have finished the itinerary.', '["By", "Friday,", "we", "will", "have", "finished", "the", "itinerary."]'::jsonb),
    (activity_id_var, 'At 10 p.m. tomorrow, I will be waiting at the airport', 'At 10 p.m. tomorrow, I will be waiting at the airport.', '["At", "10", "p.m.", "tomorrow,", "I", "will", "be", "waiting", "at", "the", "airport."]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 8, 'Build Sentences 2', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'They will have booked every train by June', 'They will have booked every train by June.', '["They", "will", "have", "booked", "every", "train", "by", "June."]'::jsonb),
    (activity_id_var, 'The tourism board will be promoting new trails next month', 'The tourism board will be promoting new trails next month.', '["The", "tourism", "board", "will", "be", "promoting", "new", "trails", "next", "month."]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'speaking_practice', 9, 'Talk About Travel Plans', 'Practice future travel talk', '{"prompts": ["What will you be doing during your next layover?", "By the end of the trip, what will you have learned?", "How do you support the local economy when you travel?"]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (
      lesson_id,
      activity_type,
      activity_order,
      title,
      description,
      content
    ) VALUES (
      'B2-L7',
      'speaking_improvement',
      10,
      'Speaking Improvement',
      'Read the improved version of your speech',
      '{"type": "speaking_improvement", "similarityThreshold": 70}'::jsonb
    );
END $$;


