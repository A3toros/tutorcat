-- =========================================
-- Pre-fill Database with Sample Lesson Data
-- C1-L1: Defining Success in Modern Society
-- =========================================
DELETE FROM lesson_activity_results WHERE lesson_id = 'C1-L1';
DELETE FROM user_progress WHERE lesson_id = 'C1-L1';
DELETE FROM lesson_history WHERE lesson_id = 'C1-L1';
DELETE FROM grammar_sentences WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'C1-L1');
DELETE FROM vocabulary_items WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'C1-L1');
DELETE FROM lesson_activities WHERE lesson_id = 'C1-L1';
DELETE FROM lessons WHERE id = 'C1-L1';

INSERT INTO lessons (id, level, lesson_number, topic) VALUES
('C1-L1', 'C1', 1, 'Defining Success in Modern Society')
ON CONFLICT (id) DO UPDATE SET topic = EXCLUDED.topic;

DO $$
DECLARE
    lesson_id_var TEXT := 'C1-L1';
    activity_id_var UUID;
BEGIN
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'warm_up_speaking', 1, 'Success Discussion', 'Discuss what success means', '{"prompt": "What does success mean to you now?"}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_intro', 2, 'Success Vocabulary', 'Learn vocabulary about success', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'achievement', 'ความสำเร็จ', NULL),
    (activity_id_var, 'fulfillment', 'ความพึงพอใจ', NULL),
    (activity_id_var, 'aspiration', 'ความหวัง', NULL),
    (activity_id_var, 'milestone', 'จุดสำคัญ', NULL),
    (activity_id_var, 'accomplishment', 'ผลสำเร็จ', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_matching_drag', 3, 'Match Success Words', 'Match English words with Thai meanings', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'achievement', 'ความสำเร็จ', NULL),
    (activity_id_var, 'fulfillment', 'ความพึงพอใจ', NULL),
    (activity_id_var, 'aspiration', 'ความหวัง', NULL),
    (activity_id_var, 'milestone', 'จุดสำคัญ', NULL),
    (activity_id_var, 'accomplishment', 'ผลสำเร็จ', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 4, 'Complete the Sentences 1', 'Fill with the correct word', '{"text": "Personal ___ brings deep ___. Setting clear ___ helps track progress.", "blanks": [{"id": "blank1", "text": "achievement", "options": ["achievement", "fulfillment", "aspiration", "milestone"], "correctAnswer": "achievement"}, {"id": "blank2", "text": "fulfillment", "options": ["fulfillment", "achievement", "aspiration", "accomplishment"], "correctAnswer": "fulfillment"}, {"id": "blank3", "text": "aspirations", "options": ["aspirations", "achievements", "milestones", "accomplishments"], "correctAnswer": "aspirations"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 5, 'Complete the Sentences 2', 'Fill with the correct word', '{"text": "Reaching a major ___ is a significant ___. Each ___ builds toward greater success.", "blanks": [{"id": "blank1", "text": "milestone", "options": ["milestone", "achievement", "aspiration", "fulfillment"], "correctAnswer": "milestone"}, {"id": "blank2", "text": "accomplishment", "options": ["accomplishment", "achievement", "milestone", "fulfillment"], "correctAnswer": "accomplishment"}, {"id": "blank3", "text": "achievement", "options": ["achievement", "milestone", "aspiration", "fulfillment"], "correctAnswer": "achievement"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_explanation', 6, 'Cleft Sentences and Emphatic Structures', 'Learn cleft sentences for emphasis', '{"rules": "Cleft sentences emphasize specific elements:\n- It-cleft: \"It is success that matters most.\"\n- What-cleft: \"What defines success is personal fulfillment.\"\n- Wh-cleft: \"What I value is achievement.\"\n\nStructure:\n- It + be + emphasized element + that/who clause\n- What + verb + be + emphasized element\n\nUse for:\n- Emphasizing importance: \"It is fulfillment that brings true happiness.\"\n- Highlighting focus: \"What matters is personal growth.\"\n- Clarifying meaning: \"What I seek is meaningful accomplishment.\"", "examples": ["It is fulfillment that defines true success.", "What matters most is personal achievement.", "What I value is meaningful accomplishment.", "It is aspiration that drives progress.", "What defines success is individual fulfillment."]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 7, 'Build Sentences 1', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'It is fulfillment that defines true success.', 'It is fulfillment that defines true success.', '["It", "is", "fulfillment", "that", "defines", "true", "success."]'::jsonb),
    (activity_id_var, 'What matters most is personal achievement.', 'What matters most is personal achievement.', '["What", "matters", "most", "is", "personal", "achievement."]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 8, 'Build Sentences 2', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'What I value is meaningful accomplishment.', 'What I value is meaningful accomplishment.', '["What", "I", "value", "is", "meaningful", "accomplishment."]'::jsonb),
    (activity_id_var, 'It is aspiration that drives personal growth.', 'It is aspiration that drives personal growth.', '["It", "is", "aspiration", "that", "drives", "personal", "growth."]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'speaking_practice', 9, 'Discuss Success', 'Practice speaking about success', '{"prompts": ["What does success mean to you at this stage of your life?", "When do people usually redefine success?", "How do you define success in your academic life?", "What factors influence your idea of success?", "How has your view of success changed over time?"]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (
      lesson_id,
      activity_type,
      activity_order,
      title,
      description,
      content
    ) VALUES (
      'C1-L1',
      'speaking_improvement',
      10,
      'Speaking Improvement',
      'Read the improved version of your speech',
      '{"type": "speaking_improvement", "similarityThreshold": 70}'::jsonb
    );
END $$;
