-- Migration: Fix achievement progress calculation for score threshold achievements
-- This updates existing achievements that use score_average incorrectly
-- to use score_threshold_count with proper requirement_count values
-- 
-- IMPORTANT: Run this migration BEFORE inserting new achievements with requirement_count

DO $$
BEGIN
    -- Add requirement_count column if it doesn't exist
    IF NOT EXISTS (
        SELECT 1 FROM information_schema.columns 
        WHERE table_name = 'achievements' AND column_name = 'requirement_count'
    ) THEN
        ALTER TABLE achievements 
        ADD COLUMN requirement_count INTEGER DEFAULT NULL;
        
        RAISE NOTICE 'Added requirement_count column to achievements table';
    ELSE
        RAISE NOTICE 'requirement_count column already exists';
    END IF;

    -- Update "Excellent" achievement: Score 90%+ on 10 lessons
    UPDATE achievements
    SET requirement_type = 'score_threshold_count',
        requirement_value = 90,
        requirement_count = 10
    WHERE code = 'excellent'
      AND requirement_type = 'score_average';

    -- Update "Above Average" achievement: Score 80%+ on 20 lessons
    UPDATE achievements
    SET requirement_type = 'score_threshold_count',
        requirement_value = 80,
        requirement_count = 20
    WHERE code = 'above_average'
      AND requirement_type = 'score_average';

    -- Update "Above Average" performance achievement: Score 80%+ on 5 lessons
    UPDATE achievements
    SET requirement_type = 'score_threshold_count',
        requirement_value = 80,
        requirement_count = 5
    WHERE code = 'above_average_perf'
      AND requirement_type = 'score_average';

    -- Update "Outstanding" achievement: Score 95%+ on 5 lessons
    UPDATE achievements
    SET requirement_type = 'score_threshold_count',
        requirement_value = 95,
        requirement_count = 5
    WHERE code = 'outstanding'
      AND requirement_type = 'score_average';

    -- Update "Consistent Performer" achievement: Score 80%+ on 10 lessons
    UPDATE achievements
    SET requirement_type = 'score_threshold_count',
        requirement_value = 80,
        requirement_count = 10
    WHERE code = 'consistent_performer'
      AND requirement_type = 'score_average';

    -- Update "Grammar Guru" achievement: Score 90%+ on 10 grammar activities
    UPDATE achievements
    SET requirement_type = 'score_threshold_count',
        requirement_value = 90,
        requirement_count = 10
    WHERE code = 'grammar_guru'
      AND requirement_type = 'score_average';

    -- Update "Vocabulary Master" achievement: Score 90%+ on 10 vocabulary activities
    UPDATE achievements
    SET requirement_type = 'score_threshold_count',
        requirement_value = 90,
        requirement_count = 10
    WHERE code = 'vocabulary_master'
      AND requirement_type = 'score_average';

    -- Update "Speaking Star" achievement: Score 90%+ on 10 speaking activities
    UPDATE achievements
    SET requirement_type = 'score_threshold_count',
        requirement_value = 90,
        requirement_count = 10
    WHERE code = 'speaking_star'
      AND requirement_type = 'score_average';

    -- Update "Quick Learner" performance achievement: Score 90%+ on 5 lessons
    UPDATE achievements
    SET requirement_type = 'score_threshold_count',
        requirement_value = 90,
        requirement_count = 5
    WHERE code = 'quick_learner_perf'
      AND requirement_type = 'score_average';

    -- Update "Consistency King" achievement: Score 85%+ on 30 lessons
    UPDATE achievements
    SET requirement_type = 'score_threshold_count',
        requirement_value = 85,
        requirement_count = 30
    WHERE code = 'consistency_king'
      AND requirement_type = 'score_average';

    RAISE NOTICE 'Updated achievement progress calculations successfully!';
END $$;

