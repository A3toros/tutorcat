-- =========================================
-- Pre-fill Database with Sample Lesson Data
-- A2-L36: Social Media Basics
-- =========================================

DELETE FROM grammar_sentences WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'A2-L36');
DELETE FROM vocabulary_items WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'A2-L36');
DELETE FROM lesson_activities WHERE lesson_id = 'A2-L36';
DELETE FROM lessons WHERE id = 'A2-L36';

INSERT INTO lessons (id, level, lesson_number, topic) VALUES
('A2-L36', 'A2', 36, 'Social Media Basics')
ON CONFLICT (id) DO UPDATE SET topic = EXCLUDED.topic;

DO $$
DECLARE
    lesson_id_var TEXT := 'A2-L36';
    activity_id_var UUID;
BEGIN
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'warm_up_speaking', 1, 'Social Media', 'Talk about using social media', '{"prompt": "How often do you use social media?"}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_intro', 2, 'Social Media Words', 'Learn social media words', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'post', 'โพสต์', NULL),
    (activity_id_var, 'scroll', 'เลื่อนดู', NULL),
    (activity_id_var, 'like', 'กดถูกใจ', NULL),
    (activity_id_var, 'follow', 'ติดตาม', NULL),
    (activity_id_var, 'share', 'แชร์', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_matching_drag', 3, 'Match Social Words', 'Match social media words', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'post', 'โพสต์', NULL),
    (activity_id_var, 'scroll', 'เลื่อนดู', NULL),
    (activity_id_var, 'like', 'กดถูกใจ', NULL),
    (activity_id_var, 'follow', 'ติดตาม', NULL),
    (activity_id_var, 'share', 'แชร์', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 4, 'Complete the Sentences 1', 'Fill with the correct word', '{"text": "I ___ a photo. I ___ the feed. I ___ my friend''s page.", "blanks": [{"id": "blank1", "text": "post", "options": ["post", "scroll", "follow", "share"], "correctAnswer": "post"}, {"id": "blank2", "text": "scroll", "options": ["scroll", "like", "post", "share"], "correctAnswer": "scroll"}, {"id": "blank3", "text": "follow", "options": ["follow", "share", "like", "post"], "correctAnswer": "follow"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 5, 'Complete the Sentences 2', 'Fill with the correct word', '{"text": "I ___ a funny video. I ___ the picture. Do you ___ many accounts?", "blanks": [{"id": "blank1", "text": "share", "options": ["share", "like", "scroll", "follow"], "correctAnswer": "share"}, {"id": "blank2", "text": "like", "options": ["like", "share", "post", "follow"], "correctAnswer": "like"}, {"id": "blank3", "text": "follow", "options": ["follow", "like", "share", "scroll"], "correctAnswer": "follow"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_explanation', 6, 'Adverbs of Frequency', 'Talk about how often you post', '{"rules": "Use always, usually, often, sometimes, rarely, never to show how often.\n- I often post stories.\n- She never shares at night.\nPlace: before the main verb; after be.", "examples": ["I often post photos.", "She is usually online at night.", "We sometimes share videos.", "Do you always like friend posts?", "He rarely follows new accounts."]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 7, 'Build Sentences 1', 'Arrange words', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'I often post photos', 'I often post photos.', '["I", "often", "post", "photos."]'::jsonb),
    (activity_id_var, 'She is usually online at night', 'She is usually online at night.', '["She", "is", "usually", "online", "at", "night."]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 8, 'Build Sentences 2', 'Arrange words', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'Do you always like friend posts', 'Do you always like friend posts?', '["Do", "you", "always", "like", "friend", "posts?"]'::jsonb),
    (activity_id_var, 'He rarely follows new accounts', 'He rarely follows new accounts.', '["He", "rarely", "follows", "new", "accounts."]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'speaking_practice', 9, 'Talk About Social Media', 'Practice social media habits', '{"prompts": ["How often do you use social media?", "Do you follow news or friends more often?", "How often do you scroll on your phone?", "What social media apps do you use?", "How much time do you usually spend online?"]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (
      lesson_id,
      activity_type,
      activity_order,
      title,
      description,
      content
    ) VALUES (
      'A2-L36',
      'speaking_improvement',
      10,
      'Speaking Improvement',
      'Read the improved version of your speech',
      '{"type": "speaking_improvement", "similarityThreshold": 70}'::jsonb
    );
END $$;

