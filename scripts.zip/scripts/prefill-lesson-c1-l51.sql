-- =========================================
-- Pre-fill Database with Sample Lesson Data
-- C1-L51: Climate Responsibility of Individuals
-- =========================================
DELETE FROM lesson_activity_results WHERE lesson_id = 'C1-L51';
DELETE FROM user_progress WHERE lesson_id = 'C1-L51';
DELETE FROM lesson_history WHERE lesson_id = 'C1-L51';
DELETE FROM grammar_sentences WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'C1-L51');
DELETE FROM vocabulary_items WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'C1-L51');
DELETE FROM lesson_activities WHERE lesson_id = 'C1-L51';
DELETE FROM lessons WHERE id = 'C1-L51';

INSERT INTO lessons (id, level, lesson_number, topic) VALUES
('C1-L51', 'C1', 51, 'Climate Responsibility of Individuals')
ON CONFLICT (id) DO UPDATE SET topic = EXCLUDED.topic;

DO $$
DECLARE
    lesson_id_var TEXT := 'C1-L51';
    activity_id_var UUID;
BEGIN
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'warm_up_speaking', 1, 'Climate Responsibility', 'Discuss climate responsibility', '{"prompt": "What is it that you can change first in your daily life?"}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_intro', 2, 'Climate Responsibility Vocabulary', 'Learn vocabulary about climate responsibility', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'responsibility', 'ความรับผิดชอบ', NULL),
    (activity_id_var, 'action', 'การกระทำ', NULL),
    (activity_id_var, 'individual', 'บุคคล', NULL),
    (activity_id_var, 'collective', 'รวมกัน', NULL),
    (activity_id_var, 'change', 'การเปลี่ยนแปลง', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_matching_drag', 3, 'Match Climate Responsibility Words', 'Match English words with Thai meanings', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'responsibility', 'ความรับผิดชอบ', NULL),
    (activity_id_var, 'action', 'การกระทำ', NULL),
    (activity_id_var, 'individual', 'บุคคล', NULL),
    (activity_id_var, 'collective', 'รวมกัน', NULL),
    (activity_id_var, 'change', 'การเปลี่ยนแปลง', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 4, 'Complete the Sentences 1', 'Fill with the correct word', '{"text": "Individual ___ matters. Taking ___ requires ___.", "blanks": [{"id": "blank1", "text": "responsibility", "options": ["responsibility", "action", "individual", "collective"], "correctAnswer": "responsibility"}, {"id": "blank2", "text": "action", "options": ["action", "responsibility", "individual", "change"], "correctAnswer": "action"}, {"id": "blank3", "text": "commitment", "options": ["commitment", "responsibility", "action", "individual"], "correctAnswer": "commitment"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 5, 'Complete the Sentences 2', 'Fill with the correct word', '{"text": "Balancing ___ and ___ responsibility is important. Making ___ requires effort.", "blanks": [{"id": "blank1", "text": "personal", "options": ["personal", "individual", "collective", "change"], "correctAnswer": "personal"}, {"id": "blank2", "text": "collective", "options": ["collective", "individual", "responsibility", "change"], "correctAnswer": "collective"}, {"id": "blank3", "text": "changes", "options": ["changes", "individual", "responsibility", "action"], "correctAnswer": "changes"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_explanation', 6, 'Cleft Sentences and Emphatic Structures', 'Learn cleft sentences for emphasis', '{"rules": "Cleft sentences emphasize specific elements:\n- It-cleft: \"It is individual action that matters most.\"\n- What-cleft: \"What you can change first is your daily habits.\"\n- Wh-cleft: \"What matters is taking action.\"\n\nStructure:\n- It + be + emphasized element + that/who clause\n- What + verb + be + emphasized element\n\nUse for:\n- Emphasizing importance: \"It is individual responsibility that drives change.\"\n- Highlighting focus: \"What you can change first is your lifestyle.\"\n- Clarifying meaning: \"What matters is taking action.\"", "examples": ["It is individual action that matters most for climate.", "What you can change first is your daily habits.", "What matters is taking responsibility.", "It is personal commitment that drives change.", "What makes a difference is collective action."]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 7, 'Build Sentences 1', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'It is individual action that matters most for climate.', 'It is individual action that matters most for climate.', '["It", "is", "individual", "action", "that", "matters", "most", "for", "climate."]'::jsonb),
    (activity_id_var, 'What you can change first is your daily habits.', 'What you can change first is your daily habits.', '["What", "you", "can", "change", "first", "is", "your", "daily", "habits."]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 8, 'Build Sentences 2', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'What matters is taking responsibility.', 'What matters is taking responsibility.', '["What", "matters", "is", "taking", "responsibility."]'::jsonb),
    (activity_id_var, 'It is personal commitment that drives change.', 'It is personal commitment that drives change.', '["It", "is", "personal", "commitment", "that", "drives", "change."]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'speaking_practice', 9, 'Discuss Climate Responsibility', 'Practice speaking about climate responsibility', '{"prompts": ["What is it that you can change first?", "How do you take action on climate issues?", "What individual actions matter most?", "How do you balance personal and collective responsibility?", "What changes have you already made for the climate?"]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (
      lesson_id,
      activity_type,
      activity_order,
      title,
      description,
      content
    ) VALUES (
      'C1-L51',
      'speaking_improvement',
      10,
      'Speaking Improvement',
      'Read the improved version of your speech',
      '{"type": "speaking_improvement", "similarityThreshold": 70}'::jsonb
    );
END $$;
