-- =========================================
-- Pre-fill Database with Sample Lesson Data
-- C1-L33: Cultural Appropriation vs Appreciation
-- =========================================
DELETE FROM lesson_activity_results WHERE lesson_id = 'C1-L33';
DELETE FROM user_progress WHERE lesson_id = 'C1-L33';
DELETE FROM lesson_history WHERE lesson_id = 'C1-L33';
DELETE FROM grammar_sentences WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'C1-L33');
DELETE FROM vocabulary_items WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'C1-L33');
DELETE FROM lesson_activities WHERE lesson_id = 'C1-L33';
DELETE FROM lessons WHERE id = 'C1-L33';

INSERT INTO lessons (id, level, lesson_number, topic) VALUES
('C1-L33', 'C1', 33, 'Cultural Appropriation vs Appreciation')
ON CONFLICT (id) DO UPDATE SET topic = EXCLUDED.topic;

DO $$
DECLARE
    lesson_id_var TEXT := 'C1-L33';
    activity_id_var UUID;
BEGIN
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'warm_up_speaking', 1, 'Cultural Appropriation', 'Discuss cultural appropriation and appreciation', '{"prompt": "What separates appreciation from misuse?"}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_intro', 2, 'Cultural Exchange Vocabulary', 'Learn vocabulary about cultural exchange', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'appropriation', 'การยึดครอง', NULL),
    (activity_id_var, 'appreciation', 'การชื่นชม', NULL),
    (activity_id_var, 'exchange', 'การแลกเปลี่ยน', NULL),
    (activity_id_var, 'intent', 'เจตนา', NULL),
    (activity_id_var, 'respect', 'ความเคารพ', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_matching_drag', 3, 'Match Cultural Exchange Words', 'Match English words with Thai meanings', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'appropriation', 'การยึดครอง', NULL),
    (activity_id_var, 'appreciation', 'การชื่นชม', NULL),
    (activity_id_var, 'exchange', 'การแลกเปลี่ยน', NULL),
    (activity_id_var, 'intent', 'เจตนา', NULL),
    (activity_id_var, 'respect', 'ความเคารพ', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 4, 'Complete the Sentences 1', 'Fill with the correct word', '{"text": "Cultural ___ differs from ___. Respectful ___ requires ___.", "blanks": [{"id": "blank1", "text": "appropriation", "options": ["appropriation", "appreciation", "exchange", "intent"], "correctAnswer": "appropriation"}, {"id": "blank2", "text": "appreciation", "options": ["appreciation", "appropriation", "exchange", "respect"], "correctAnswer": "appreciation"}, {"id": "blank3", "text": "exchange", "options": ["exchange", "appropriation", "appreciation", "intent"], "correctAnswer": "exchange"}, {"id": "blank4", "text": "respect", "options": ["respect", "appropriation", "appreciation", "intent"], "correctAnswer": "respect"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 5, 'Complete the Sentences 2', 'Fill with the correct word', '{"text": "Understanding ___ matters. Positive ___ promotes cultural ___.", "blanks": [{"id": "blank1", "text": "intent", "options": ["intent", "appropriation", "appreciation", "exchange"], "correctAnswer": "intent"}, {"id": "blank2", "text": "appreciation", "options": ["appreciation", "appropriation", "exchange", "respect"], "correctAnswer": "appreciation"}, {"id": "blank3", "text": "exchange", "options": ["exchange", "appropriation", "appreciation", "respect"], "correctAnswer": "exchange"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_explanation', 6, 'Cleft Sentences and Emphatic Structures', 'Learn cleft sentences for emphasis', '{"rules": "Cleft sentences emphasize specific elements:\n- It-cleft: \"It is respect that separates appreciation from appropriation.\"\n- What-cleft: \"What divides respect from misuse is intent.\"\n- Wh-cleft: \"What matters is respectful engagement.\"\n\nStructure:\n- It + be + emphasized element + that/who clause\n- What + verb + be + emphasized element\n\nUse for:\n- Emphasizing importance: \"It is intent that determines appropriation.\"\n- Highlighting focus: \"What matters is respectful exchange.\"\n- Clarifying meaning: \"What separates appreciation is respect.\"", "examples": ["It is respect that separates appreciation from appropriation.", "What divides respect from misuse is intent.", "What matters is respectful cultural exchange.", "It is intent that determines whether exchange is appropriate.", "What makes exchange respectful is understanding."]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 7, 'Build Sentences 1', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'It is respect that separates appreciation from appropriation.', 'It is respect that separates appreciation from appropriation.', '["It", "is", "respect", "that", "separates", "appreciation", "from", "appropriation."]'::jsonb),
    (activity_id_var, 'What divides respect from misuse is intent.', 'What divides respect from misuse is intent.', '["What", "divides", "respect", "from", "misuse", "is", "intent."]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 8, 'Build Sentences 2', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'What matters is respectful cultural exchange.', 'What matters is respectful cultural exchange.', '["What", "matters", "is", "respectful", "cultural", "exchange."]'::jsonb),
    (activity_id_var, 'It is intent that determines whether exchange is appropriate.', 'It is intent that determines whether exchange is appropriate.', '["It", "is", "intent", "that", "determines", "whether", "exchange", "is", "appropriate."]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'speaking_practice', 9, 'Discuss Cultural Exchange', 'Practice speaking about cultural appropriation', '{"prompts": ["How do you define cultural appropriation?", "When does appreciation become harmful?", "What makes cultural exchange respectful?", "Why is intent important?", "How can people engage respectfully with cultures?"]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (
      lesson_id,
      activity_type,
      activity_order,
      title,
      description,
      content
    ) VALUES (
      'C1-L33',
      'speaking_improvement',
      10,
      'Speaking Improvement',
      'Read the improved version of your speech',
      '{"type": "speaking_improvement", "similarityThreshold": 70}'::jsonb
    );
END $$;
