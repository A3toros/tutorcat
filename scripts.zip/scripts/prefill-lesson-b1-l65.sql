-- ===== LESSON B1-L65 =====

-- =========================================
-- Pre-fill Database with Sample Lesson Data
-- B1-L65: Balancing Health and Work
-- =========================================

DELETE FROM lesson_activity_results WHERE lesson_id = 'B1-L65';
DELETE FROM user_progress WHERE lesson_id = 'B1-L65';
DELETE FROM lesson_history WHERE lesson_id = 'B1-L65';
DELETE FROM grammar_sentences WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'B1-L65');
DELETE FROM vocabulary_items WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'B1-L65');
DELETE FROM lesson_activities WHERE lesson_id = 'B1-L65';
DELETE FROM lessons WHERE id = 'B1-L65';

INSERT INTO lessons (id, level, lesson_number, topic) VALUES
('B1-L65', 'B1', 65, 'Balancing Health and Work')
ON CONFLICT (id) DO UPDATE SET topic = EXCLUDED.topic;

DO $$
DECLARE
    lesson_id_var TEXT := 'B1-L65';
    activity_id_var UUID;
BEGIN
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'warm_up_speaking', 1, 'Work-Life Health Balance', 'Talk about staying healthy while working', '{"prompt": "What must you do to stay healthy at work?"}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_intro', 2, 'Health at Work Words', 'Learn words related to workplace health', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'prioritize', 'จัดลำดับความสำคัญ', NULL),
    (activity_id_var, 'rest', 'พักผ่อน', NULL),
    (activity_id_var, 'hydrate', 'ดื่มน้ำ', NULL),
    (activity_id_var, 'pause', 'หยุดชั่วคราว', NULL),
    (activity_id_var, 'stretch', 'ยืดกล้ามเนื้อ', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_matching_drag', 3, 'Match Health Words', 'Match workplace health words', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'prioritize', 'จัดลำดับความสำคัญ', NULL),
    (activity_id_var, 'rest', 'พักผ่อน', NULL),
    (activity_id_var, 'hydrate', 'ดื่มน้ำ', NULL),
    (activity_id_var, 'pause', 'หยุดชั่วคราว', NULL),
    (activity_id_var, 'stretch', 'ยืดกล้ามเนื้อ', NULL);

    -- 4. Vocabulary Fill Blanks #1
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 4, 'Complete the Sentences 1', 'Fill in the blanks with correct words', '{"text": "You should ___ when tired. Workers must ___. I need to ___.", "blanks": [{"id": "blank1", "text": "rest", "options": ["rest", "prioritize", "hydrate", "pause"], "correctAnswer": "rest"}, {"id": "blank2", "text": "pause", "options": ["pause", "rest", "hydrate", "stretch"], "correctAnswer": "pause"}, {"id": "blank3", "text": "hydrate", "options": ["hydrate", "rest", "pause", "stretch"], "correctAnswer": "hydrate"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    -- 5. Vocabulary Fill Blanks #2
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 5, 'Complete the Sentences 2', 'Fill in the blanks with correct words', '{"text": "We should ___ our health. I ___ every hour. They ___ to stay healthy.", "blanks": [{"id": "blank1", "text": "prioritize", "options": ["prioritize", "rest", "hydrate", "pause"], "correctAnswer": "prioritize"}, {"id": "blank2", "text": "stretch", "options": ["stretch", "rest", "hydrate", "pause"], "correctAnswer": "stretch"}, {"id": "blank3", "text": "rest", "options": ["rest", "prioritize", "hydrate", "stretch"], "correctAnswer": "rest"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    -- 6. Grammar Explanation
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_explanation', 6, 'Should and Must for Advice', 'Learn modal verbs for obligations and advice', '{"rules": "Use should and must to give advice and express obligations:\n\n- Should for advice/recommendations (You should rest)\n- Must for strong obligations/rules (Workers must take breaks)\n- Should + base verb (should rest, should drink)\n- Must + base verb (must take, must do)\n- Should is less strong than must", "examples": ["You should rest when you are tired.", "Workers must take breaks.", "I should drink more water.", "We must prioritize health.", "They should stretch regularly."]}'::jsonb)
    RETURNING id INTO activity_id_var;

    -- 7. Grammar Sentences #1
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 7, 'Build Sentences 1', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'You should rest when you are tired', 'You should rest when you are tired.', '["You", "should", "rest", "when", "you", "are", "tired."]'::jsonb),
    (activity_id_var, 'Workers must take breaks', 'Workers must take breaks.', '["Workers", "must", "take", "breaks."]'::jsonb);

    -- 8. Grammar Sentences #2
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 8, 'Build Sentences 2', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'I should drink more water', 'I should drink more water.', '["I", "should", "drink", "more", "water."]'::jsonb),
    (activity_id_var, 'We must prioritize health', 'We must prioritize health.', '["We", "must", "prioritize", "health."]'::jsonb);

    -- 9. Speaking Practice
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'speaking_practice', 9, 'Talk About Daily Routine', 'Practice talking about your daily schedule', '{"prompts": ["What time do you wake up?", "When do you eat dinner?", "Do you exercise every day?", "How do you stay healthy at work?", "What should people do to stay healthy?"]}'::jsonb)
    RETURNING id INTO activity_id_var;

    -- 10. Speaking Improvement
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'speaking_improvement', 10, 'Speaking Improvement', 'Read the improved version of your speech', '{"type": "speaking_improvement", "similarityThreshold": 70}'::jsonb)
    RETURNING id INTO activity_id_var;
END $$;