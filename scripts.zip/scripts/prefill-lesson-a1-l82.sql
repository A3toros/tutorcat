-- =========================================
-- Pre-fill Database with Sample Lesson Data
-- A1-L82: Vegetables
-- =========================================

DELETE FROM grammar_sentences WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'A1-L82');
DELETE FROM vocabulary_items WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'A1-L82');
DELETE FROM lesson_activities WHERE lesson_id = 'A1-L82';
DELETE FROM lessons WHERE id = 'A1-L82';

INSERT INTO lessons (id, level, lesson_number, topic) VALUES
('A1-L82', 'A1', 82, 'Vegetables')
ON CONFLICT (id) DO UPDATE SET topic = EXCLUDED.topic;

DO $$
DECLARE
    lesson_id_var TEXT := 'A1-L82';
    activity_id_var UUID;
BEGIN
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'warm_up_speaking', 1, 'Veggies', 'Talk about vegetables', '{"prompt": "Do you like carrots?"}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_intro', 2, 'Vegetable Words', 'Learn vegetable words', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'carrot', 'แครอท', NULL),
    (activity_id_var, 'tomato', 'มะเขือเทศ', NULL),
    (activity_id_var, 'onion', 'หัวหอม', NULL),
    (activity_id_var, 'potato', 'มันฝรั่ง', NULL),
    (activity_id_var, 'corn', 'ข้าวโพด', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_matching_drag', 3, 'Match Vegetable Words', 'Match vegetable words', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'carrot', 'แครอท', NULL),
    (activity_id_var, 'tomato', 'มะเขือเทศ', NULL),
    (activity_id_var, 'onion', 'หัวหอม', NULL),
    (activity_id_var, 'potato', 'มันฝรั่ง', NULL),
    (activity_id_var, 'corn', 'ข้าวโพด', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 4, 'Complete the Sentences 1', 'Fill with the correct word', '{"text": "I like ___. I like ___.", "blanks": [{"id": "blank1", "text": "carrots", "options": ["carrots", "tomatoes", "onions", "corn"], "correctAnswer": "carrots"}, {"id": "blank2", "text": "corn", "options": ["corn", "potatoes", "carrots", "onions"], "correctAnswer": "corn"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 5, 'Complete the Sentences 2', 'Fill with the correct word', '{"text": "These are ___. Those are ___.", "blanks": [{"id": "blank1", "text": "tomatoes", "options": ["tomatoes", "onions", "potatoes", "corn"], "correctAnswer": "tomatoes"}, {"id": "blank2", "text": "potatoes", "options": ["potatoes", "carrots", "onions", "tomatoes"], "correctAnswer": "potatoes"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_explanation', 6, 'A/Some + Plurals', 'Use a/some with vegetables', '{"rules": "Use a/an for one; some for many/uncount.\n- a carrot, a tomato; some onions, some corn.", "examples": ["This is a carrot.", "That is a tomato.", "These are some onions.", "Those are some potatoes.", "Do you like some corn?"]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 7, 'Build Sentences 1', 'Arrange words', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'This is a carrot', 'This is a carrot.', '["This", "is", "a", "carrot."]'::jsonb),
    (activity_id_var, 'These are some onions', 'These are some onions.', '["These", "are", "some", "onions."]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 8, 'Build Sentences 2', 'Arrange words', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'That is a tomato', 'That is a tomato.', '["That", "is", "a", "tomato."]'::jsonb),
    (activity_id_var, 'Do you like some corn', 'Do you like some corn?', '["Do", "you", "like", "some", "corn?"]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'speaking_practice', 9, 'Talk About Vegetables', 'Practice veggie words', '{"prompts": ["Do you like carrots?", "Do you like tomatoes?", "Do you buy onions?", "Do you like potatoes?", "Is corn sweet?"]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (
      lesson_id,
      activity_type,
      activity_order,
      title,
      description,
      content
    ) VALUES (
      'A1-L82',
      'speaking_improvement',
      10,
      'Speaking Improvement',
      'Read the improved version of your speech',
      '{"type": "speaking_improvement", "similarityThreshold": 70}'::jsonb
    );
END $$;

