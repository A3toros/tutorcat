-- =========================================
-- Pre-fill Database with Sample Lesson Data
-- A2-L97: Holiday Food
-- =========================================

DELETE FROM grammar_sentences WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'A2-L97');
DELETE FROM vocabulary_items WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'A2-L97');
DELETE FROM lesson_activities WHERE lesson_id = 'A2-L97';
DELETE FROM lessons WHERE id = 'A2-L97';

INSERT INTO lessons (id, level, lesson_number, topic) VALUES
('A2-L97', 'A2', 97, 'Holiday Food')
ON CONFLICT (id) DO UPDATE SET topic = EXCLUDED.topic;

DO $$
DECLARE
    lesson_id_var TEXT := 'A2-L97';
    activity_id_var UUID;
BEGIN
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'warm_up_speaking', 1, 'Special Dishes', 'Talk about holiday food', '{"prompt": "Do you eat any special food on holidays?"}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_intro', 2, 'Holiday Food Words', 'Learn words for holiday dishes', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'dessert', 'ของหวาน', NULL),
    (activity_id_var, 'special', 'พิเศษ', NULL),
    (activity_id_var, 'dish', 'จานอาหาร', NULL),
    (activity_id_var, 'sweet', 'หวาน', NULL),
    (activity_id_var, 'spicy', 'เผ็ด', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_matching_drag', 3, 'Match Holiday Food Words', 'Match holiday food words', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'dessert', 'ของหวาน', NULL),
    (activity_id_var, 'special', 'พิเศษ', NULL),
    (activity_id_var, 'dish', 'จานอาหาร', NULL),
    (activity_id_var, 'sweet', 'หวาน', NULL),
    (activity_id_var, 'spicy', 'เผ็ด', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 4, 'Complete the Sentences 1', 'Fill with the correct word', '{"text": "This ___ is ___. I love this ___.", "blanks": [{"id": "blank1", "text": "dish", "options": ["dish", "dessert", "special", "sweet"], "correctAnswer": "dish"}, {"id": "blank2", "text": "special", "options": ["special", "spicy", "sweet", "dessert"], "correctAnswer": "special"}, {"id": "blank3", "text": "dessert", "options": ["dessert", "dish", "spicy", "sweet"], "correctAnswer": "dessert"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 5, 'Complete the Sentences 2', 'Fill with the correct word', '{"text": "It is very ___. Do you like ___ food?", "blanks": [{"id": "blank1", "text": "sweet", "options": ["sweet", "spicy", "dessert", "special"], "correctAnswer": "sweet"}, {"id": "blank2", "text": "spicy", "options": ["spicy", "sweet", "dish", "special"], "correctAnswer": "spicy"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_explanation', 6, 'Some / Any', 'Ask and offer holiday food', '{"rules": "Use some in offers/affirmatives; any in questions/negatives.\n- Do you want some dessert?\n- Are there any spicy dishes?", "examples": ["Do you want some dessert?", "Are there any spicy dishes?", "We have some sweet cakes.", "I don''t have any sugar.", "Can I try some special dish?"]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 7, 'Build Sentences 1', 'Arrange words', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'Do you want some dessert', 'Do you want some dessert?', '["Do", "you", "want", "some", "dessert?"]'::jsonb),
    (activity_id_var, 'Are there any spicy dishes', 'Are there any spicy dishes?', '["Are", "there", "any", "spicy", "dishes?"]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 8, 'Build Sentences 2', 'Arrange words', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'We have some sweet cakes', 'We have some sweet cakes.', '["We", "have", "some", "sweet", "cakes."]'::jsonb),
    (activity_id_var, 'I don t have any sugar', 'I don''t have any sugar.', '["I", "don''t", "have", "any", "sugar."]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'speaking_practice', 9, 'Talk About Holiday Food', 'Practice offers and choices', '{"prompts": ["Do you eat any special food on holidays?", "Do you make some food at home?", "Do you try any new dishes?", "Is there any food you always eat?", "Who makes the holiday food?"]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (
      lesson_id,
      activity_type,
      activity_order,
      title,
      description,
      content
    ) VALUES (
      'A2-L97',
      'speaking_improvement',
      10,
      'Speaking Improvement',
      'Read the improved version of your speech',
      '{"type": "speaking_improvement", "similarityThreshold": 70}'::jsonb
    );
END $$;

