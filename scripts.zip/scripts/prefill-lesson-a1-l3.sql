-- =========================================
-- Pre-fill Database with Sample Lesson Data
-- A1-L3: Daily Routines
-- =========================================

-- Clear existing sample data for A1-L3 (optional - comment out if you want to keep existing data)
DELETE FROM grammar_sentences WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'A1-L3');
DELETE FROM vocabulary_items WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'A1-L3');
DELETE FROM lesson_activities WHERE lesson_id = 'A1-L3';
DELETE FROM lessons WHERE id = 'A1-L3';

INSERT INTO lessons (id, level, lesson_number, topic) VALUES
('A1-L3', 'A1', 3, 'Daily Routines')
ON CONFLICT (id) DO UPDATE SET topic = EXCLUDED.topic;

DO $$
DECLARE
    lesson_id_var TEXT := 'A1-L3';
    activity_id_var UUID;
BEGIN
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content) VALUES (lesson_id_var, 'warm_up_speaking', 1, 'Your Daily Routine', 'Talk about your day', '{"prompt": "What do you do every day?"}'::jsonb) RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content) VALUES (lesson_id_var, 'vocabulary_intro', 2, 'Daily Routine Words', 'Learn daily activities', '{}'::jsonb) RETURNING id INTO activity_id_var;

    -- 2. Vocabulary Introduction (5 words)
    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'wake up', 'ตื่นนอน', NULL),
    (activity_id_var, 'get up', 'ลุกขึ้น', NULL),
    (activity_id_var, 'brush teeth', 'แปรงฟัน', NULL),
    (activity_id_var, 'have breakfast', 'ทานอาหารเช้า', NULL),
    (activity_id_var, 'go to work', 'ไปทำงาน', NULL);

    -- 3. Vocabulary Matching Drag #1 (5 pairs - same words)
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content) VALUES (lesson_id_var, 'vocabulary_matching_drag', 3, 'Match Daily Activities 1', 'Match English phrases (left) with Thai meanings (right)', '{}'::jsonb) RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'wake up', 'ตื่นนอน', NULL),
    (activity_id_var, 'get up', 'ลุกขึ้น', NULL),
    (activity_id_var, 'brush teeth', 'แปรงฟัน', NULL),
    (activity_id_var, 'have breakfast', 'ทานอาหารเช้า', NULL),
    (activity_id_var, 'go to work', 'ไปทำงาน', NULL);

    

    -- 4. Vocabulary Fill Blanks #1 (4 words: wake up, get up, brush teeth, have breakfast - go to work left out)
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content) VALUES (lesson_id_var, 'vocabulary_fill_blanks', 4, 'Complete the Sentences 1', 'Fill in the blanks with correct words', '{"text": "I ___ at 7 AM. Then I ___ from bed and ___ my teeth. After that, I ___.", "blanks": [{"id": "blank1", "text": "wake up", "options": ["wake up", "car", "snow", "go"], "correctAnswer": "wake up"}, {"id": "blank2", "text": "get up", "options": ["get up", "book", "water", "run"], "correctAnswer": "get up"}, {"id": "blank3", "text": "brush teeth", "options": ["brush teeth", "table", "blue", "eat"], "correctAnswer": "brush teeth"}, {"id": "blank4", "text": "have breakfast", "options": ["have breakfast", "door", "red", "sleep"], "correctAnswer": "have breakfast"}]}'::jsonb) RETURNING id INTO activity_id_var;

    -- 5. Vocabulary Fill Blanks #2 (4 words: wake up, get up, brush teeth, go to work - have breakfast left out)
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content) VALUES (lesson_id_var, 'vocabulary_fill_blanks', 5, 'Complete the Sentences 2', 'Fill in the blanks with correct words', '{"text": "I ___ early in the morning. I ___ from bed and ___ my teeth. Then I ___.", "blanks": [{"id": "blank1", "text": "wake up", "options": ["wake up", "tree", "yellow", "jump"], "correctAnswer": "wake up"}, {"id": "blank2", "text": "get up", "options": ["get up", "chair", "green", "walk"], "correctAnswer": "get up"}, {"id": "blank3", "text": "brush teeth", "options": ["brush teeth", "window", "black", "sing"], "correctAnswer": "brush teeth"}, {"id": "blank4", "text": "go to work", "options": ["go to work", "phone", "white", "dance"], "correctAnswer": "go to work"}]}'::jsonb) RETURNING id INTO activity_id_var;

    -- 4. Grammar Explanation (5 examples)
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content) VALUES (lesson_id_var, 'grammar_explanation', 6, 'Present Simple - Daily Routines', 'Learn how to talk about daily habits', '{"rules": "We use present simple for daily routines and habits:\n\n- I/You/We/They + verb (I wake up)\n- He/She/It + verb + s (She goes)\n- Questions: Do/Does + subject + verb? (Do you wake up?)\n- Negative: don''t/doesn''t + verb (I don''t work)", "examples": ["I wake up at 7 AM.", "She goes to work at 9 AM.", "Do you have breakfast?", "He doesn''t work on weekends.", "We eat lunch at 12 PM."]}'::jsonb) RETURNING id INTO activity_id_var;
    -- 4. Grammar Sentences #1
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content) VALUES (lesson_id_var, 'grammar_sentences', 7, 'Build Sentences 1', 'Arrange words to make sentences', '{}'::jsonb) RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'I wake up at seven o clock', 'I wake up at seven o''clock', '["I", "wake", "up", "at", "seven", "o''clock"]'::jsonb),
    (activity_id_var, 'I go to work every day', 'I go to work every day', '["I", "go", "to", "work", "every", "day"]'::jsonb);
    -- 4. Grammar Sentences #2
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content) VALUES (lesson_id_var, 'grammar_sentences', 8, 'Build Sentences 2', 'Arrange words to make sentences', '{}'::jsonb) RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'She brushes her teeth in the morning', 'She brushes her teeth in the morning', '["She", "brushes", "her", "teeth", "in", "the", "morning"]'::jsonb),
    (activity_id_var, 'We have breakfast at eight', 'We have breakfast at eight', '["We", "have", "breakfast", "at", "eight"]'::jsonb);
    -- 4. Speaking Practice (5 prompts - CEFR A1)
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content) VALUES (lesson_id_var, 'speaking_practice', 9, 'Describe Your Day', 'Talk about your daily routine', '{"prompts": ["What time do you wake up?", "What do you do in the morning?", "When do you go to school?", "What time do you have lunch?", "When do you go to bed?"]}'::jsonb) RETURNING id INTO activity_id_var;

END $$;
