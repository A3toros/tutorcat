-- =========================================
-- Pre-fill Database with Sample Lesson Data
-- B2-L38: Making important decisions
-- =========================================

DELETE FROM grammar_sentences WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'B2-L38');
DELETE FROM vocabulary_items WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'B2-L38');
DELETE FROM lesson_activities WHERE lesson_id = 'B2-L38';
DELETE FROM lessons WHERE id = 'B2-L38';

INSERT INTO lessons (id, level, lesson_number, topic) VALUES
('B2-L38', 'B2', 38, 'Making important decisions')
ON CONFLICT (id) DO UPDATE SET topic = EXCLUDED.topic;

DO $$
DECLARE
    lesson_id_var TEXT := 'B2-L38';
    activity_id_var UUID;
BEGIN
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'warm_up_speaking', 1, 'Decision Moments', 'Talk about choices', '{"prompt": "Rarely do you decide fast—when did you, and who helped?"}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_intro', 2, 'Decision Words', 'Key words for weighing options', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'weigh', 'ชั่งน้ำหนัก/พิจารณา', NULL),
    (activity_id_var, 'option', 'ทางเลือก', NULL),
    (activity_id_var, 'risk', 'ความเสี่ยง', NULL),
    (activity_id_var, 'decisive', 'เด็ดขาด', NULL),
    (activity_id_var, 'regret', 'เสียใจ/เสียดาย', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_matching_drag', 3, 'Match Decision Words', 'Match words with meanings', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'weigh', 'ชั่งน้ำหนัก/พิจารณา', NULL),
    (activity_id_var, 'option', 'ทางเลือก', NULL),
    (activity_id_var, 'risk', 'ความเสี่ยง', NULL),
    (activity_id_var, 'decisive', 'เด็ดขาด', NULL),
    (activity_id_var, 'regret', 'เสียใจ/เสียดาย', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 4, 'Complete the Sentences 1', 'Fill with the correct word', '{"text": "I ___ options before choosing. Every ___ carries some ___.", "blanks": [{"id": "blank1", "text": "weigh", "options": ["weigh", "option", "risk", "regret"], "correctAnswer": "weigh"}, {"id": "blank2", "text": "option", "options": ["option", "risk", "decisive", "regret"], "correctAnswer": "option"}, {"id": "blank3", "text": "risk", "options": ["risk", "regret", "option", "weigh"], "correctAnswer": "risk"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 5, 'Complete the Sentences 2', 'Fill with the correct word', '{"text": "Sometimes I act ___. I try to avoid ___.", "blanks": [{"id": "blank1", "text": "decisive", "options": ["decisive", "weigh", "option", "risk"], "correctAnswer": "decisive"}, {"id": "blank2", "text": "regret", "options": ["regret", "risk", "decisive", "option"], "correctAnswer": "regret"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_explanation', 6, 'Inversion with Rarely/Seldom', 'Emphasize unusual quick decisions', '{"rules": "For emphasis with negative adverbials (Rarely/Seldom), invert auxiliary and subject: Rarely do I… Rarely have I… Use do/does/did for simple tenses; have/has for perfect.\\n- Rarely do I decide fast.\\n- Seldom have I regretted clear choices.", "examples": ["Rarely do I decide in a minute.", "Seldom have I regretted a slow choice.", "Rarely does he act without weighing options.", "Seldom have we skipped a risk check.", "Rarely do you change course without evidence."]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 7, 'Build Sentences 1', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'Rarely do I decide in a minute', 'Rarely do I decide in a minute.', '["Rarely", "do", "I", "decide", "in", "a", "minute."]'::jsonb),
    (activity_id_var, 'Seldom have I regretted a slow choice', 'Seldom have I regretted a slow choice.', '["Seldom", "have", "I", "regretted", "a", "slow", "choice."]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 8, 'Build Sentences 2', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'Rarely does he act without weighing options', 'Rarely does he act without weighing options.', '["Rarely", "does", "he", "act", "without", "weighing", "options."]'::jsonb),
    (activity_id_var, 'Seldom have we skipped a risk check', 'Seldom have we skipped a risk check.', '["Seldom", "have", "we", "skipped", "a", "risk", "check."]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'speaking_practice', 9, 'Talk About Decisions', 'Practice inversion emphasis', '{"prompts": ["Rarely do you decide fast—when did you?", "Who helps you weigh options?", "What choice have you seldom regretted?"]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (
      lesson_id,
      activity_type,
      activity_order,
      title,
      description,
      content
    ) VALUES (
      'B2-L38',
      'speaking_improvement',
      10,
      'Speaking Improvement',
      'Read the improved version of your speech',
      '{"type": "speaking_improvement", "similarityThreshold": 70}'::jsonb
    );
END $$;


