-- =========================================
-- Pre-fill Database with Sample Lesson Data
-- C1-L10: Value of Failure in Learning
-- =========================================

DELETE FROM grammar_sentences WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'C1-L10');
DELETE FROM vocabulary_items WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'C1-L10');
DELETE FROM lesson_activities WHERE lesson_id = 'C1-L10';
DELETE FROM lessons WHERE id = 'C1-L10';

INSERT INTO lessons (id, level, lesson_number, topic) VALUES
('C1-L10', 'C1', 10, 'Value of Failure in Learning')
ON CONFLICT (id) DO UPDATE SET topic = EXCLUDED.topic;

DO $$
DECLARE
    lesson_id_var TEXT := 'C1-L10';
    activity_id_var UUID;
BEGIN
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'warm_up_speaking', 1, 'Failure in Learning', 'Discuss the value of failure', '{"prompt": "If you had not failed at a key moment, what might you have missed?"}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_intro', 2, 'Failure Vocabulary', 'Learn vocabulary about failure and learning', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'failure', 'ความล้มเหลว', NULL),
    (activity_id_var, 'setback', 'ความล้มเหลว', NULL),
    (activity_id_var, 'resilience', 'ความยืดหยุ่น', NULL),
    (activity_id_var, 'reflection', 'การสะท้อน', NULL),
    (activity_id_var, 'growth', 'การเติบโต', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_matching_drag', 3, 'Match Failure Words', 'Match English words with Thai meanings', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'failure', 'ความล้มเหลว', NULL),
    (activity_id_var, 'setback', 'ความล้มเหลว', NULL),
    (activity_id_var, 'resilience', 'ความยืดหยุ่น', NULL),
    (activity_id_var, 'reflection', 'การสะท้อน', NULL),
    (activity_id_var, 'growth', 'การเติบโต', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 4, 'Complete the Sentences 1', 'Fill with the correct word', '{"text": "Learning from ___ builds ___. ___ on ___ promotes ___.", "blanks": [{"id": "blank1", "text": "failure", "options": ["failure", "setback", "resilience", "reflection"], "correctAnswer": "failure"}, {"id": "blank2", "text": "resilience", "options": ["resilience", "failure", "setback", "growth"], "correctAnswer": "resilience"}, {"id": "blank3", "text": "Reflection", "options": ["Reflection", "Failure", "Setback", "Resilience"], "correctAnswer": "Reflection"}, {"id": "blank4", "text": "setbacks", "options": ["setbacks", "failures", "resilience", "reflection"], "correctAnswer": "setbacks"}, {"id": "blank5", "text": "growth", "options": ["growth", "failure", "resilience", "reflection"], "correctAnswer": "growth"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 5, 'Complete the Sentences 2', 'Fill with the correct word', '{"text": "Each ___ teaches valuable lessons. ___ helps overcome ___.", "blanks": [{"id": "blank1", "text": "setback", "options": ["setback", "failure", "resilience", "reflection"], "correctAnswer": "setback"}, {"id": "blank2", "text": "Resilience", "options": ["Resilience", "Failure", "Setback", "Reflection"], "correctAnswer": "Resilience"}, {"id": "blank3", "text": "failure", "options": ["failure", "setback", "resilience", "reflection"], "correctAnswer": "failure"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_explanation', 6, 'Mixed Conditionals', 'Learn mixed conditional structures', '{"rules": "Mixed conditionals combine different time references:\n- Mixed 2/3: \"If I had not failed (past), I would be different now (present).\"\n- Mixed 3/2: \"If I had failed (past), I would not understand now (present).\"\n\nStructures:\n- If + past perfect, would + base form (past condition, present result)\n- If + past simple, would have + past participle (present condition, past result)\n\nUse for:\n- Hypothetical past affecting present: \"If I had not failed, I would be overconfident now.\"\n- Unreal present affecting past: \"If I were better, I would have succeeded.\"", "examples": ["If I had not failed, I would have missed important lessons.", "If I had not failed, I would be overconfident now.", "If I were more careful, I would not have failed.", "If I had failed earlier, I would understand better now.", "If I had not experienced failure, I would not have grown."]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 7, 'Build Sentences 1', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'If I had not failed, I would have missed important lessons.', 'If I had not failed, I would have missed important lessons.', '["If", "I", "had", "not", "failed,", "I", "would", "have", "missed", "important", "lessons."]'::jsonb),
    (activity_id_var, 'If I had not failed, I would be overconfident now.', 'If I had not failed, I would be overconfident now.', '["If", "I", "had", "not", "failed,", "I", "would", "be", "overconfident", "now."]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 8, 'Build Sentences 2', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'If I had failed earlier, I would understand better now.', 'If I had failed earlier, I would understand better now.', '["If", "I", "had", "failed", "earlier,", "I", "would", "understand", "better", "now."]'::jsonb),
    (activity_id_var, 'If I had not experienced failure, I would not have grown.', 'If I had not experienced failure, I would not have grown.', '["If", "I", "had", "not", "experienced", "failure,", "I", "would", "not", "have", "grown."]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'speaking_practice', 9, 'Discuss Failure in Learning', 'Practice speaking about failure and learning', '{"prompts": ["If you had not failed, what would you have missed?", "How has failure contributed to your learning?", "What lessons have you learned from failure?", "How can failure be reframed as opportunity?", "What role should failure play in education?"]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (
      lesson_id,
      activity_type,
      activity_order,
      title,
      description,
      content
    ) VALUES (
      'C1-L10',
      'speaking_improvement',
      10,
      'Speaking Improvement',
      'Read the improved version of your speech',
      '{"type": "speaking_improvement", "similarityThreshold": 70}'::jsonb
    );
END $$;
