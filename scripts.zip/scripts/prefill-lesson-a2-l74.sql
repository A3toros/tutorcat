-- =========================================
-- Pre-fill Database with Sample Lesson Data
-- A2-L74: Fast Food vs Restaurants
-- =========================================

DELETE FROM grammar_sentences WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'A2-L74');
DELETE FROM vocabulary_items WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'A2-L74');
DELETE FROM lesson_activities WHERE lesson_id = 'A2-L74';
DELETE FROM lessons WHERE id = 'A2-L74';

INSERT INTO lessons (id, level, lesson_number, topic) VALUES
('A2-L74', 'A2', 74, 'Fast Food vs Restaurants')
ON CONFLICT (id) DO UPDATE SET topic = EXCLUDED.topic;

DO $$
DECLARE
    lesson_id_var TEXT := 'A2-L74';
    activity_id_var UUID;
BEGIN
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'warm_up_speaking', 1, 'Eating Out', 'Compare fast food and restaurants', '{"prompt": "Which is better: fast food or restaurants?"}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_intro', 2, 'Eating Out Words', 'Learn words for comparing places to eat', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'fast', 'เร็ว', NULL),
    (activity_id_var, 'slow', 'ช้า', NULL),
    (activity_id_var, 'healthy', 'สุขภาพดี', NULL),
    (activity_id_var, 'tasty', 'อร่อย', NULL),
    (activity_id_var, 'service', 'บริการ', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_matching_drag', 3, 'Match Eating Out Words', 'Match eating out words', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'fast', 'เร็ว', NULL),
    (activity_id_var, 'slow', 'ช้า', NULL),
    (activity_id_var, 'healthy', 'สุขภาพดี', NULL),
    (activity_id_var, 'tasty', 'อร่อย', NULL),
    (activity_id_var, 'service', 'บริการ', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 4, 'Complete the Sentences 1', 'Fill with the correct word', '{"text": "Fast food is ___. Restaurants can be ___. Both can be ___.", "blanks": [{"id": "blank1", "text": "fast", "options": ["fast", "slow", "tasty", "healthy"], "correctAnswer": "fast"}, {"id": "blank2", "text": "slow", "options": ["slow", "fast", "tasty", "service"], "correctAnswer": "slow"}, {"id": "blank3", "text": "tasty", "options": ["tasty", "healthy", "fast", "slow"], "correctAnswer": "tasty"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 5, 'Complete the Sentences 2', 'Fill with the correct word', '{"text": "Some fast food is not ___. Restaurant ___ can be better.", "blanks": [{"id": "blank1", "text": "healthy", "options": ["healthy", "tasty", "fast", "service"], "correctAnswer": "healthy"}, {"id": "blank2", "text": "service", "options": ["service", "healthy", "slow", "fast"], "correctAnswer": "service"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_explanation', 6, 'Comparatives', 'Compare two options', '{"rules": "Use comparatives: fast → faster; slow → slower; healthy → healthier; tasty → tastier.\nPattern: X is faster than Y.", "examples": ["Fast food is faster than a restaurant.", "Restaurants are slower but tastier.", "This salad is healthier than fries.", "Service here is better than there.", "This place is busier than that café."]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 7, 'Build Sentences 1', 'Arrange words', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'Fast food is faster than a restaurant', 'Fast food is faster than a restaurant.', '["Fast", "food", "is", "faster", "than", "a", "restaurant."]'::jsonb),
    (activity_id_var, 'Restaurants are slower but tastier', 'Restaurants are slower but tastier.', '["Restaurants", "are", "slower", "but", "tastier."]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 8, 'Build Sentences 2', 'Arrange words', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'This salad is healthier than fries', 'This salad is healthier than fries.', '["This", "salad", "is", "healthier", "than", "fries."]'::jsonb),
    (activity_id_var, 'Service here is better than there', 'Service here is better than there.', '["Service", "here", "is", "better", "than", "there."]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'speaking_practice', 9, 'Talk About Eating Out', 'Practice comparing fast food and restaurants', '{"prompts": ["Is fast food cheaper than restaurants?", "Are restaurants healthier than fast food?", "Which place is more comfortable?", "Where is service faster?", "Which option do you prefer, and why?"]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (
      lesson_id,
      activity_type,
      activity_order,
      title,
      description,
      content
    ) VALUES (
      'A2-L74',
      'speaking_improvement',
      10,
      'Speaking Improvement',
      'Read the improved version of your speech',
      '{"type": "speaking_improvement", "similarityThreshold": 70}'::jsonb
    );
END $$;

