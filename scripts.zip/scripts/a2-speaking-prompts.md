# A2 Speaking Prompts Reference
## Warm-up and Speaking Practice Prompts for All A2 Lessons

This file contains all warm-up speaking prompts and speaking practice prompts for A2 lessons (L1-L100).

---

Lesson 1: Travel & Transport

Grammar Focus: Past Simple

Warm-up Prompt:

How do you usually travel to school or work?

Speaking Practice Prompts:

Do you like traveling by bus or taxi?

What is your favorite way to travel in your city?

Have you ever been on a long train trip?

Do you prefer flying or driving for holidays?

Where did you go on your last trip?

Lesson 2: Shopping & Prices

Grammar Focus: How much / How many

Warm-up Prompt:

What do you usually buy when you go shopping?

Speaking Practice Prompts:

How much does a T-shirt cost in your area?

Do you prefer to pay by cash or card?

Have you ever received a discount in a shop?

What did you buy last time you went shopping?

Where do you usually shop for food or clothes?

Lesson 3: Eating Out & Restaurants

Grammar Focus: Polite Requests

Warm-up Prompt:

When do you usually eat at restaurants?

Speaking Practice Prompts:

What is your favorite restaurant near your home?

What do you usually order when you eat out?

Have you ever complained about food in a restaurant?

Do you leave tips for waiters in your country?

What restaurant would you recommend to a friend?

Lesson 4: Work & Jobs

Grammar Focus: Past Simple – Work

Warm-up Prompt:

What jobs do people in your family do?

Speaking Practice Prompts:

What job does one person in your family have?

Do you want to be a teacher or another worker?

Have you ever visited a workplace like a factory or office?

What uniforms do workers wear in your area?

Where do doctors usually work?

Lesson 5: Health & Illness

Grammar Focus: I have / I feel

Warm-up Prompt:

What do you do to stay healthy?

Speaking Practice Prompts:

How do you feel today?

What do you do when you feel sick?

Have you ever been to a hospital or clinic?

What do you do when you have a headache or fever?

Do you exercise to stay healthy?

Lesson 6: Holidays & Celebrations

Grammar Focus: Future: going to

Warm-up Prompt:

What holidays do you celebrate each year?

Speaking Practice Prompts:

What is your favorite holiday?

Are you going to have a birthday party this year?

Do you give presents to friends or family?

What traditions do you follow during holidays?

What are you going to eat for New Year or a festival?

Lesson 7: Technology in Daily Life

Grammar Focus: Present Simple / Present Continuous

Warm-up Prompt:

What technology do you use every day?

Speaking Practice Prompts:

What app do you use most on your phone?

Do you have a fast computer or a slow one?

How do you use the internet in your daily life?

Is your phone new or old?

What technology do you use at school or work?

Lesson 8: Feelings & Emotions

Grammar Focus: Adjectives / Feelings

Warm-up Prompt:

How do you feel today?

Speaking Practice Prompts:

How do you feel when you win a game or competition?

What makes you feel sad or unhappy?

When do you feel excited?

Do you feel tired after school or work?

How do you feel when you meet your friends?

Lesson 9: Sports & Activities

Grammar Focus: Can (ability)

Warm-up Prompt:

What sports do you like?

Speaking Practice Prompts:

What sports can you play?

Can you go swimming? Where?

What games do you like to play?

Can you play football or another team sport?

What activities do you do with friends in your free time?

Lesson 10: Describing People & Objects

Grammar Focus: Adjectives / Comparatives

Warm-up Prompt:

How do you describe your friends?

Speaking Practice Prompts:

Is your teacher tall or short?

What color is your school bag or backpack?

Describe your best friend.

Is your house bigger or smaller than your friend’s?

What does your favorite toy or object look like?

Lesson 11: Buying a Train or Bus Ticket

Grammar Focus: Present Simple questions #1

Warm-up Prompt:

Where do you usually buy bus or train tickets?

Speaking Practice Prompts:

Where do you usually buy bus or train tickets?

How do you ask for the time at a station?

Do you prefer the bus or the train? Why?

What information do you need when buying a ticket?

Have you ever missed a bus or train?

Lesson 12: Talking About Happiness

Grammar Focus: Adverbs of manner #1

Warm-up Prompt:

What makes you happy in your daily life?

Speaking Practice Prompts:

What makes you happy in your daily life?

How do you relax after school or work?

Who makes you laugh?

What activities bring you joy?

When do you feel happiest?

Lesson 13: Comparing Prices

Grammar Focus: Comparatives / Superlatives #1

Warm-up Prompt:

Where do you usually find good prices?

Speaking Practice Prompts:

Where do you usually find good prices?

Do you compare prices online or in stores?

What was the best deal you have ever found?

Which store near you has the cheapest prices?

How do you decide if something is worth buying?

Lesson 14: Daily Work Tasks

Grammar Focus: Present Simple #1

Warm-up Prompt:

What tasks do you do every day at work or school?

Speaking Practice Prompts:

What tasks do you do every day?

When do you usually take breaks?

Do you like meetings or group work?

What is your first task in the morning?

How do you organize your work or school day?

Lesson 15: Booking a Table

Grammar Focus: Present Continuous #1

Warm-up Prompt:

How do you usually book a table at a restaurant?

Speaking Practice Prompts:

How do you book a table at a restaurant?

Do you prefer an early dinner or a late dinner?

Who do you usually eat out with?

What information do you give when booking a table?

Have you ever forgotten a restaurant reservation?

Lesson 16: Common Illnesses

Grammar Focus: There is / There are + health #1

Warm-up Prompt:

How do you feel when you have a cold or fever?

Speaking Practice Prompts:

How do you feel when you have a cold?

Do you see a doctor quickly when you feel sick?

Who takes care of you when you are ill?

What symptoms do you usually have when you are sick?

How do you prevent getting sick?

Lesson 17: Using a Smartphone

Grammar Focus: Can (ability) #1

Warm-up Prompt:

What can your phone help you do every day?

Speaking Practice Prompts:

What can your phone help you do?

Do you install many apps on your phone?

How do you fix small phone problems?

What apps do you use the most?

Can you use your phone without the internet?

Lesson 18: Planning a Holiday

Grammar Focus: Going to (future) #1

Warm-up Prompt:

Where are you going to travel next?

Speaking Practice Prompts:

Where are you going to travel next?

How do you book hotels or places to stay?

Do you set a budget for your holiday?

What are you going to pack for your holiday?

Who are you going to travel with?

Lesson 19: Playing Team Sports

Grammar Focus: Present Continuous #2

Warm-up Prompt:

Are you playing on a team now?

Speaking Practice Prompts:

Are you playing on a team now?

What position do you like to play?

When are you practicing with your team?

How often do you play or train?

What sport would you like to try in the future?

Lesson 20: Physical Appearance

Grammar Focus: Adjectives / Basic comparatives #2

Warm-up Prompt:

How would you describe yourself physically?

Speaking Practice Prompts:

How would you describe yourself?

Do you look like anyone in your family?

Do you wear glasses or contact lenses?

What color is your hair?

Are you taller or shorter than your friends?

Lesson 21: Asking About Timetables

Grammar Focus: Prepositions of time #1

Warm-up Prompt:

When was the last time your bus or train was late?

Speaking Practice Prompts:

When was the last time your bus or train was late?

How do you usually check transport times?

What do you do while you are waiting?

How early do you arrive before departure?

What happens when public transport is late?

Lesson 22: Paying by Cash or Card

Grammar Focus: Present Simple negatives / questions #2

Warm-up Prompt:

Do you usually pay by cash or by card?

Speaking Practice Prompts:

Do you usually pay by cash or by card?

Have you ever lost a receipt?

Do you trust card machines in shops?

When do you prefer to use cash?

What payment method do you prefer, and why?

Lesson 23: Job Schedules

Grammar Focus: Time prepositions #2

Warm-up Prompt:

What time do you usually start work or school?

Speaking Practice Prompts:

What time do you usually start work or school?

Do you work or study on weekends?

How do you feel about working overtime?

What is your normal daily schedule?

Do you prefer morning or evening shifts?

Lesson 24: Reading a Menu

Grammar Focus: There is / There are + food #2

Warm-up Prompt:

What do you usually check first on a menu?

Speaking Practice Prompts:

What do you usually check first on a menu?

Do you ask if food is spicy?

What desserts do you usually like?

How do you choose what to order?

Are there vegetarian options on the menu?

Lesson 25: Visiting a Doctor

Grammar Focus: Questions / negatives #3

Warm-up Prompt:

How do you usually make a doctor’s appointment?

Speaking Practice Prompts:

How do you usually make a doctor’s appointment?

Do you ask the doctor many questions?

Do you always follow the doctor’s advice?

What do you tell the doctor about your symptoms?

How often do you visit a doctor?

Lesson 26: Sending Messages

Grammar Focus: Questions with do / does #4

Warm-up Prompt:

Do you usually reply to messages quickly?

Speaking Practice Prompts:

Do you usually reply to messages quickly?

Do you use emojis when you message?

How do you feel about voice messages?

What apps do you use most for messaging?

When do you usually send messages?

Lesson 27: Birthday Celebrations

Grammar Focus: Past Simple #2

Warm-up Prompt:

How did you celebrate your last birthday?

Speaking Practice Prompts:

How did you celebrate your last birthday?

Who came to your celebration?

What gift did you like the most?

What food did you eat?

Where did you celebrate your birthday?

Lesson 28: Feeling Angry or Upset

Grammar Focus: Linkers because / so #1

Warm-up Prompt:

What usually makes you angry or upset?

Speaking Practice Prompts:

What usually makes you angry or upset?

How do you calm down when you are angry?

Do you talk to someone when you feel upset?

Why do small problems sometimes feel big?

What helps you feel better quickly?

Lesson 29: Going to the Gym

Grammar Focus: Adverbs of frequency #1

Warm-up Prompt:

How often do you go to the gym or exercise?

Speaking Practice Prompts:

How often do you go to the gym or exercise?

Do you follow an exercise plan?

Who shows you new exercises?

What equipment do you usually use?

Do you exercise alone or with friends?

Lesson 30: Clothes & Style

Grammar Focus: Adjectives / comparatives #3

Warm-up Prompt:

What clothes do you usually wear to school or work?

Speaking Practice Prompts:

Do you wear a uniform at school or work?

Do you prefer casual or formal clothes?

What clothes are the most comfortable for you?

What colors do you like to wear?

Where do you usually buy clothes?

---

Lesson 31: Missing a Bus or Train

Grammar Focus: Past Simple #3

Warm-up Prompt:

Have you ever missed a bus or train?

Speaking Practice Prompts:

Have you ever missed a bus or train?

Who helped you when that happened?

How did you feel at the time?

What did you do after you missed it?

How did you solve the problem?

Lesson 32: Returning a Product

Grammar Focus: Past Simple #4

Warm-up Prompt:

Have you ever returned a product to a shop?

Speaking Practice Prompts:

Have you ever returned a product to a shop?

Why did you return it?

What was wrong with the product?

How did the shop staff help you?

Did you get a refund or exchange?

Lesson 33: Workplace Rules

Grammar Focus: Must / mustn’t #1

Warm-up Prompt:

What rules must people follow at your job or school?

Speaking Practice Prompts:

What rules must people follow at your job or school?

Which rule is the hardest to follow?

Why must people follow rules?

What happens if someone breaks a rule?

Are there any rules you disagree with?

Lesson 34: Asking About Ingredients

Grammar Focus: Questions (what / which) #4

Warm-up Prompt:

Do you ask about ingredients when you order food?

Speaking Practice Prompts:

Do you ask about ingredients when you order food?

What foods do you avoid eating?

Which ingredients do you usually check for?

How do you order food safely?

Why is it important to ask about ingredients?

Lesson 35: Buying Medicine

Grammar Focus: Can (permission) #2

Warm-up Prompt:

How do you ask a pharmacist for medicine?

Speaking Practice Prompts:

How do you ask a pharmacist for medicine?

Can you buy medicine without a prescription?

Do you read the instructions before using medicine?

What medicine do you buy most often?

Where do you usually buy medicine?

Lesson 36: Social Media Basics

Grammar Focus: Adverbs of frequency #2

Warm-up Prompt:

How often do you use social media?

Speaking Practice Prompts:

How often do you use social media?

Do you follow news or friends more often?

How often do you scroll on your phone?

What social media apps do you use?

How much time do you usually spend online?

Lesson 37: Holiday Traditions

Grammar Focus: Present Simple #2

Warm-up Prompt:

What holiday do you enjoy most?

Speaking Practice Prompts:

What holiday do you enjoy most?

What do people usually do on that day?

Do you get time off work or school?

What food do people usually eat?

Who do you celebrate with?

Lesson 38: Being Nervous

Grammar Focus: Present Continuous #3

Warm-up Prompt:

When do you feel nervous?

Speaking Practice Prompts:

When do you feel nervous?

What are you doing to feel calmer?

Who is helping or supporting you?

How are you preparing for the situation?

What situations make you nervous?

Lesson 39: Outdoor Activities

Grammar Focus: Prepositions of movement #1

Warm-up Prompt:

Where do you usually go for outdoor activities?

Speaking Practice Prompts:

Where do you usually go for outdoor activities?

Do you walk through parks or along paths?

Do you like walking up hills or on flat ground?

What outdoor activities do you enjoy?

When do you usually go outside?

Lesson 40: Describing Personality

Grammar Focus: Adjectives / feelings #1

Warm-up Prompt:

How would you describe your best friend’s personality?

Speaking Practice Prompts:

How would you describe your best friend’s personality?

Are you more shy or outgoing?

Who is the funniest person you know?

What personality traits do you like in people?

How would you describe your own personality?
---

Lesson 41: Airport Check-in

Grammar Focus: Present Continuous #4

Warm-up Prompt:

What are you usually doing when you arrive at the airport?

Speaking Practice Prompts:

What are you usually doing when you arrive at the airport?

Are you checking in online or at the counter?

What documents are you showing at check-in?

What are you packing in your carry-on bag?

How are you preparing for your flight?

Lesson 42: Asking for a Different Size

Grammar Focus: Comparatives #4

Warm-up Prompt:

Are these clothes too big or too small for you?

Speaking Practice Prompts:

Are these clothes too big or too small for you?

Do you ask for a bigger or smaller size?

Which size fits you better?

How do you know if clothes fit well?

Who usually helps you when you shop?

Lesson 43: Part-Time Jobs

Grammar Focus: Past Simple #5

Warm-up Prompt:

Have you ever had a part-time job?

Speaking Practice Prompts:

Have you ever had a part-time job?

What kind of work did you do?

What skills did you learn from it?

How much did you earn per week or month?

Would you like to do that job again?

Lesson 44: Ordering Takeaway Food

Grammar Focus: Imperatives / requests #2

Warm-up Prompt:

How do you usually order takeaway food?

Speaking Practice Prompts:

How do you usually order takeaway food?

What app or phone service do you use?

What food do you order most often?

How long does delivery usually take?

What do you say when you place an order?

Lesson 45: Healthy Food Choices

Grammar Focus: Comparatives #5

Warm-up Prompt:

Which food is healthier: home-cooked or fast food?

Speaking Practice Prompts:

Which food is healthier: home-cooked or fast food?

Do you eat fried food more or less often now?

Who eats healthier food in your family?

What makes one meal healthier than another?

How do you choose healthy food when eating out?

Lesson 46: Watching Videos Online

Grammar Focus: Adverbs of frequency #3

Warm-up Prompt:

How often do you watch videos online?

Speaking Practice Prompts:

How often do you watch videos online?

What type of videos do you watch most often?

Do you usually skip advertisements?

How long do you watch videos each day?

Which platform do you use most?

Lesson 47: Giving Presents

Grammar Focus: Going to (future) #2

Warm-up Prompt:

Who are you going to give a present to next?

Speaking Practice Prompts:

Who are you going to give a present to next?

What kind of gift are you going to buy?

When are you going to give it?

How do you usually choose presents?

Do you prefer giving or receiving gifts?

Lesson 48: Feeling Relaxed

Grammar Focus: Comparatives #6

Warm-up Prompt:

Where do you feel more relaxed: at home or outside?

Speaking Practice Prompts:

Where do you feel more relaxed: at home or outside?

Is listening to music more relaxing than watching TV?

What activities help you relax most?

When do you feel the most relaxed during the day?

What makes one place more relaxing than another?

Lesson 49: Watching Sports

Grammar Focus: Past Simple #6

Warm-up Prompt:

What sports game did you watch recently?

Speaking Practice Prompts:

What sports game did you watch recently?

Which team or player won the game?

Who did you watch it with?

Where did you watch the game?

How did you feel about the result?

Lesson 50: Talking About Family Members

Grammar Focus: Possessive / object pronouns #1

Warm-up Prompt:

Who are you closest to in your family?

Speaking Practice Prompts:

Who are you closest to in your family?

Who do you live with now?

Which family member do you talk to most?

How many people are there in your family?

What do you usually do with them?

Lesson 51: Carrying Luggage

Grammar Focus: Comparatives #5

Warm-up Prompt:

Do you travel with lighter or heavier luggage?

Speaking Practice Prompts:

Do you travel with lighter or heavier luggage?

Which bag is easier to carry?

Is a backpack more comfortable than a suitcase?

How much luggage do you usually take?

What items make your bag heavier?

Lesson 52: Shopping at a Market

Grammar Focus: Present Continuous #5

Warm-up Prompt:

What are you usually buying at markets?

Speaking Practice Prompts:

What are you usually buying at markets?

Are people selling food or clothes there?

Are you bargaining with sellers now or usually?

What are people doing at the market?

How is shopping at a market different from a mall?

Lesson 53: Talking About Salary (basic)

Grammar Focus: Comparatives #7

Warm-up Prompt:

Is a high salary more important than job happiness?

Speaking Practice Prompts:

Is a high salary more important than job happiness?

Which jobs pay better in your opinion?

Is your salary higher or lower than you expected?

Which is better: more money or more free time?

What job do you think pays the most?

Lesson 54: Paying the Bill

Grammar Focus: Past Simple #7

Warm-up Prompt:

When did you last pay a bill with friends?

Speaking Practice Prompts:

When did you last pay a bill with friends?

Did you split the bill or pay together?

Who paid for the meal last time?

Did you ever forget to pay your share?

What did you do when the bill was wrong?

Lesson 55: Exercising Regularly

Grammar Focus: Adverbs of frequency #4

Warm-up Prompt:

How often do you exercise in a week?

Speaking Practice Prompts:

How often do you exercise in a week?

Do you usually exercise alone or with others?

What exercise do you do most often?

How long do you usually exercise?

Do you exercise more now than before?

Lesson 56: Using Apps

Grammar Focus: Can (ability) #3

Warm-up Prompt:

Can you solve simple problems with apps?

Speaking Practice Prompts:

Can you solve simple problems with apps?

Can you remember many passwords?

What app can you not live without?

Can you use apps to manage your day?

What new app would you like to learn to use?

Lesson 57: Invitations to Parties

Grammar Focus: Imperatives / requests #3

Warm-up Prompt:

How do you ask people to come to a party?

Speaking Practice Prompts:

How do you ask people to come to a party?

What do you usually say in an invitation message?

What should guests bring to a party?

How do you ask someone to reply?

What do you say if you cannot go?

Lesson 58: Expressing Likes & Dislikes

Grammar Focus: Object pronouns #2

Warm-up Prompt:

What activities do you enjoy doing?

Speaking Practice Prompts:

What activities do you enjoy doing?

What food do you dislike eating?

What music do you like listening to?

Is there anything you love doing every day?

What activities do you really hate doing?

Lesson 59: Sports Equipment

Grammar Focus: Some / any / much / many #2

Warm-up Prompt:

How much sports equipment do you use?

Speaking Practice Prompts:

How much sports equipment do you use?

Do you have any safety equipment?

How many pairs of shoes do you need?

Do you buy much equipment or borrow it?

How much does basic sports equipment cost?

Lesson 60: Describing a Place

Grammar Focus: Prepositions of place #2

Warm-up Prompt:

Where is your home located?

Speaking Practice Prompts:

Where is your home located?

What places are near your home?

Where is your room in the house?

What is next to or across from your home?

How do you explain directions to visitors?
---

Lesson 61: Taxi Rides

Grammar Focus: Can (requests) #2

Warm-up Prompt:

How can you ask a driver to stop?

Speaking Practice Prompts:

How can you ask a driver to stop?

Can you ask the driver to slow down?

Can you tell the driver where to go?

Can you share a taxi with others?

What can you say to the driver politely?

Lesson 62: Discounts & Sales

Grammar Focus: Some / any / much / many #3

Warm-up Prompt:

Do you buy many things during sales?

Speaking Practice Prompts:

Do you buy many things during sales?

How much money do you usually spend?

Do you buy any clothes online?

Are there many discounts at your favorite store?

How much can you save during sales?

Lesson 63: Work Clothes

Grammar Focus: Adjectives / comparatives #5

Warm-up Prompt:

Are your work clothes comfortable?

Speaking Practice Prompts:

Are your work clothes comfortable?

Is a uniform better than casual clothes?

What clothes are more practical for work?

Do you prefer formal or informal clothes?

How do you choose the best clothes for work?

Lesson 64: Complaining About Food

Grammar Focus: Can (permission / requests) #3

Warm-up Prompt:

How can you complain politely in a restaurant?

Speaking Practice Prompts:

How can you complain politely in a restaurant?

Can you ask to change a dish?

Can you ask for a refund or replacement?

What can you say if food is cold?

How can staff help you?

Lesson 65: Feeling Tired or Sick

Grammar Focus: Past Simple #8

Warm-up Prompt:

When were you last very tired?

Speaking Practice Prompts:

When were you last very tired?

What did you do to feel better?

Did you rest or see a doctor?

Who helped you when you were sick?

How did you recover?

Lesson 66: Online Learning

Grammar Focus: Going to (future) #6

Warm-up Prompt:

What are you going to learn online?

Speaking Practice Prompts:

What are you going to learn online?

Are you going to take a course soon?

How are you going to practice at home?

What skills are you going to improve?

When are you going to study online?

Lesson 67: Holiday Weather

Grammar Focus: Comparatives / superlatives #6

Warm-up Prompt:

What is the best weather for a holiday?

Speaking Practice Prompts:

What is the best weather for a holiday?

Is hot weather better than cold weather?

What was the coldest place you visited?

What season is best for travel?

How does weather change your plans?

Lesson 68: Talking About Stress

Grammar Focus: Linkers because / so #2

Warm-up Prompt:

Why do people feel stressed?

Speaking Practice Prompts:

Why do people feel stressed?

I feel stressed because…

What do you do, so you feel calmer?

Who helps you when you feel stressed?

What situations cause stress?

Lesson 69: Exercising With Friends

Grammar Focus: Adverbs of manner #2

Warm-up Prompt:

How do you usually exercise?

Speaking Practice Prompts:

How do you usually exercise?

Do you exercise slowly or quickly?

How do you exercise safely?

How do friends help you exercise better?

Do you exercise differently with friends?

Lesson 70: Colors & Shapes

Grammar Focus: Describing objects #1

Warm-up Prompt:

What colors do you like wearing?

Speaking Practice Prompts:

What colors do you like wearing?

Do you prefer round or square objects?

Describe a bag you use every day.

What shapes do you see in your room?

What color and shape do you like most?
---

Lesson 71: Travel Delays

Grammar Focus: Linkers and / but / because / so #3

Warm-up Prompt:

Why were you late last time?

Speaking Practice Prompts:

I was late because…

I felt stressed, but I stayed calm.

There was a delay, so I waited.

What happened, and how did you react?

What causes delays, and how do they affect plans?

Lesson 72: Buying Gifts

Grammar Focus: Going to (future) #4

Warm-up Prompt:

Who are you going to buy a gift for?

Speaking Practice Prompts:

Who are you going to buy a gift for?

What gift are you going to choose?

When are you going to buy it?

Where are you going to shop?

How are you going to surprise them?

Lesson 73: Looking for a Job

Grammar Focus: Going to (future) #5

Warm-up Prompt:

Are you going to look for a new job?

Speaking Practice Prompts:

Are you going to look for a new job?

What kind of job are you going to apply for?

How are you going to prepare for interviews?

Who is going to help you with your resume?

When are you going to start applying?

Lesson 74: Fast Food vs Restaurants

Grammar Focus: Comparatives #8

Warm-up Prompt:

Which is better: fast food or restaurants?

Speaking Practice Prompts:

Is fast food cheaper than restaurants?

Are restaurants healthier than fast food?

Which place is more comfortable?

Where is service faster?

Which option do you prefer, and why?

Lesson 75: Talking About Pain

Grammar Focus: Can (questions) #5

Warm-up Prompt:

How can you explain pain to a doctor?

Speaking Practice Prompts:

How can you explain pain to a doctor?

Can you show where it hurts?

Can you describe the pain clearly?

Can you rate the pain from 1 to 10?

What can you say about your symptoms?

Lesson 76: Internet Problems

Grammar Focus: Past Simple #9

Warm-up Prompt:

When was the last time your internet stopped working?

Speaking Practice Prompts:

When did the problem start?

What did you do first?

Did you restart the router?

Who helped you fix the problem?

How did you solve it?

Lesson 77: Favorite Celebrations

Grammar Focus: Present Perfect (light) #1

Warm-up Prompt:

What celebrations have you enjoyed?

Speaking Practice Prompts:

What celebrations have you enjoyed?

Have you celebrated with family or friends?

Which celebration have you liked the most?

How have you celebrated it?

Why has it been special for you?

(Note: Past Simple removed to protect Present Perfect focus)

Lesson 78: Feeling Bored

Grammar Focus: Present Simple #9

Warm-up Prompt:

What things make you feel bored?

Speaking Practice Prompts:

What activities feel boring to you?

When do you usually feel bored?

What do you do when you feel bored?

How do you make boring days better?

What hobbies help you avoid boredom?

Lesson 79: Traveling With Friends

Grammar Focus: Pronouns (object / possessive) #3

Warm-up Prompt:

Who plans your trips with friends?

Speaking Practice Prompts:

Who plans the trip, and who helps them?

Do friends share costs, or does one person pay?

How do you divide tasks between you?

Do you book hotels yourselves or ask someone else?

How do you organize trips together?

Lesson 80: Describing Objects You Use Daily

Grammar Focus: Adjectives / this / that #2

Warm-up Prompt:

What is in your bag right now?

Speaking Practice Prompts:

What is this object you use every day?

What is that item used for?

How would you describe your phone?

Which object is most important to you?

How do you describe everyday items clearly?

---

Lesson 81: Asking for Directions

Grammar Focus: Imperatives / places #2

Warm-up Prompt:

How do you ask for directions?

Speaking Practice Prompts:

How do you ask for directions politely?

Can you say: “Turn left” or “Go straight”?

How do you explain where a place is?

Do you use landmarks when giving directions?

What do you do if you get lost?

Lesson 82: Online Shopping Basics

Grammar Focus: Adverbs of frequency #4

Warm-up Prompt:

How often do you shop online?

Speaking Practice Prompts:

How often do you shop online?

Do you usually read reviews before buying?

How often do you track your orders?

What do you often buy online?

Do you ever return items?

Lesson 83: Talking About Colleagues

Grammar Focus: Object / possessive pronouns #4

Warm-up Prompt:

Who helps you at work?

Speaking Practice Prompts:

Who helps you at work, and how do they help you?

Do you work with them every day?

How do you support your colleagues?

Do you share tasks with them?

How do you work as a team?

Lesson 84: Eating at Home

Grammar Focus: Adverbs of frequency #5

Warm-up Prompt:

How often do you cook at home?

Speaking Practice Prompts:

How often do you cook at home?

Who usually cooks in your house?

What food do you cook most often?

Do you usually eat at home or outside?

What do you cook on busy days?

Lesson 85: Rest & Sleep

Grammar Focus: Prepositions of time #4

Warm-up Prompt:

What time do you usually go to sleep?

Speaking Practice Prompts:

What time do you usually go to sleep?

Do you sleep early on weekdays?

Do you wake up at the same time every day?

How many hours do you sleep at night?

What do you do before bedtime?

Lesson 86: Email Communication

Grammar Focus: Formal / informal openings #1

Warm-up Prompt:

How do you start an email?

Speaking Practice Prompts:

How do you start a formal email?

How do you start an informal email?

Do you write short or long emails?

How often do you check your email?

Have you ever sent an email by mistake?

Lesson 87: Family Celebrations

Grammar Focus: Object / possessive pronouns #5

Warm-up Prompt:

Who organizes family celebrations?

Speaking Practice Prompts:

Who organizes family celebrations, and how do they do it?

Do you help them prepare food?

Do you share photos with relatives?

What traditions are important to your family?

What makes family celebrations special?

Lesson 88: Excitement About Plans

Grammar Focus: Going to (future) #7

Warm-up Prompt:

What are you going to do soon?

Speaking Practice Prompts:

What are you going to do soon?

Who are you going to meet?

Where are you going to go?

How are you going to prepare?

Why are you excited about it?

Lesson 89: Talking About Fitness Goals

Grammar Focus: Linkers because / so #3

Warm-up Prompt:

What fitness goal do you have?

Speaking Practice Prompts:

What fitness goal do you have, and why?

Why is this goal important to you?

What will you do so you can reach it?

How do you stay motivated?

Who supports you because they care about your health?

Lesson 90: Talking About Age

Grammar Focus: Questions with how old #1

Warm-up Prompt:

How old are you?

Speaking Practice Prompts:

How old are you?

When is your birthday?

Do you feel older or younger than your friends?

How do you usually celebrate birthdays?

What age do you think is the best, and why?
---

Lesson 91: Renting a Bicycle or Scooter

Grammar Focus: Going to (future) #8

Warm-up Prompt:

Where are you going to ride first?

Speaking Practice Prompts:

Where are you going to ride first?

How long are you going to ride?

Are you going to wear a helmet?

What are you going to check before renting?

What do you need to rent one?

Lesson 92: Asking About Quality

Grammar Focus: Questions with do / does #5

Warm-up Prompt:

How do you ask if something is good quality?

Speaking Practice Prompts:

How do you ask if something is good quality?

Do you check reviews before buying?

Does the material feel strong?

Do you trust guarantees?

What makes something good quality for you?

Lesson 93: Working Hours

Grammar Focus: Adverbs of frequency #6

Warm-up Prompt:

How often do you work late?

Speaking Practice Prompts:

How often do you work late?

Do you usually take breaks?

What day do you work the longest?

Do you sometimes work weekends?

How do you manage your work schedule?

Lesson 94: Traditional Food

Grammar Focus: Past Simple #10

Warm-up Prompt:

What food did you eat as a child?

Speaking Practice Prompts:

What food did you eat as a child?

Who taught you to cook it?

When did you eat it most often?

How did your family prepare it?

Why was it special to you?

Lesson 95: Staying Fit

Grammar Focus: Going to (future) #9

Warm-up Prompt:

What are you going to do to stay fit?

Speaking Practice Prompts:

What are you going to do to stay fit?

Are you going to start a new routine?

How are you going to track progress?

Who is going to motivate you?

When are you going to exercise?

Lesson 96: Technology at Work

Grammar Focus: Present Simple #8

Warm-up Prompt:

What technology do you use at work?

Speaking Practice Prompts:

What technology do you use at work?

How does it help you do your job?

Do you use email or chat more?

What problems do you have with technology?

How do you solve tech problems at work?

Lesson 97: Holiday Food

Grammar Focus: Some / any #4

Warm-up Prompt:

Do you eat any special food on holidays?

Speaking Practice Prompts:

Do you eat any special food on holidays?

Do you make some food at home?

Do you try any new dishes?

Is there any food you always eat?

Who makes the holiday food?

Lesson 98: Talking About Fear

Grammar Focus: Can (permission / support) #6

Warm-up Prompt:

Who can help you when you feel scared?

Speaking Practice Prompts:

Who can help you when you feel scared?

Can you call someone for support?

Can you ask someone to stay with you?

What can you do to feel safer?

What helps you overcome fear?

Lesson 99: Trying a New Sport

Grammar Focus: Present Continuous #10

Warm-up Prompt:

What new sport are you trying now?

Speaking Practice Prompts:

What new sport are you trying now?

Who are you training with?

What equipment are you using?

How are you learning the rules?

How do you feel while trying it?

Lesson 100: Describing Your Home

Grammar Focus: There is / there are + place #3

Warm-up Prompt:

What rooms are there in your home?

Speaking Practice Prompts:

What rooms are there in your home?

Is there a place you relax most?

Are there any rooms you share?

What furniture is there in your room?

How do you feel about your home?

---

## Notes

- **Warm-up prompts** are single questions designed to introduce the topic and get students thinking
- **Speaking practice prompts** (5 per lesson) provide varied practice on the lesson topic
- All prompts are designed for A2 level students and encourage personal reflection and practical communication
- Prompts align with the grammar focus of each lesson to provide natural practice opportunities
- Language is kept simple and concrete, suitable for elementary level learners
