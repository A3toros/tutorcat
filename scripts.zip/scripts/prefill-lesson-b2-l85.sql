-- ===== LESSON B2-L85 =====

-- =========================================
-- Pre-fill Database with Sample Lesson Data
-- B2-L85: Freedom of expression (limits)
-- =========================================

DELETE FROM lesson_activity_results WHERE lesson_id = 'B2-L85';
DELETE FROM user_progress WHERE lesson_id = 'B2-L85';
DELETE FROM lesson_history WHERE lesson_id = 'B2-L85';
DELETE FROM grammar_sentences WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'B2-L85');
DELETE FROM vocabulary_items WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'B2-L85');
DELETE FROM lesson_activities WHERE lesson_id = 'B2-L85';
DELETE FROM lessons WHERE id = 'B2-L85';

INSERT INTO lessons (id, level, lesson_number, topic) VALUES
('B2-L85', 'B2', 85, 'Freedom of expression (limits)')
ON CONFLICT (id) DO UPDATE SET topic = EXCLUDED.topic;

DO $$
DECLARE
    lesson_id_var TEXT := 'B2-L85';
    activity_id_var UUID;
BEGIN
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'warm_up_speaking', 1, 'Expression Boundaries', 'Talk about limits to free speech', '{"prompt": "What rule is so important you defend it?"}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_intro', 2, 'Expression Words', 'Learn words related to freedom of expression', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'express', 'แสดงออก', NULL),
    (activity_id_var, 'censor', 'ตรวจสอบเนื้อหา', NULL),
    (activity_id_var, 'nuance', 'ความแตกต่างเล็กน้อย', NULL),
    (activity_id_var, 'offend', 'ทำให้ขุ่นเคือง', NULL),
    (activity_id_var, 'debate', 'อภิปราย', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_matching_drag', 3, 'Match Expression Words', 'Match words related to free speech', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'express', 'แสดงออก', NULL),
    (activity_id_var, 'censor', 'ตรวจสอบเนื้อหา', NULL),
    (activity_id_var, 'nuance', 'ความแตกต่างเล็กน้อย', NULL),
    (activity_id_var, 'offend', 'ทำให้ขุ่นเคือง', NULL),
    (activity_id_var, 'debate', 'อภิปราย', NULL);

    -- 4. Vocabulary Fill Blanks #1
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 4, 'Complete the Sentences 1', 'Fill in the blanks with correct words', '{"text": "I want to ___ my opinion. They may ___ content. There is a ___.", "blanks": [{"id": "blank1", "text": "express", "options": ["express", "censor", "nuance", "offend"], "correctAnswer": "express"}, {"id": "blank2", "text": "censor", "options": ["censor", "express", "nuance", "debate"], "correctAnswer": "censor"}, {"id": "blank3", "text": "nuance", "options": ["nuance", "express", "censor", "offend"], "correctAnswer": "nuance"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    -- 5. Vocabulary Fill Blanks #2
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 5, 'Complete the Sentences 2', 'Fill in the blanks with correct words', '{"text": "I don''t want to ___ anyone. We need to ___. They ___.", "blanks": [{"id": "blank1", "text": "offend", "options": ["offend", "express", "censor", "nuance"], "correctAnswer": "offend"}, {"id": "blank2", "text": "debate", "options": ["debate", "express", "censor", "offend"], "correctAnswer": "debate"}, {"id": "blank3", "text": "debate", "options": ["debate", "offend", "express", "censor"], "correctAnswer": "debate"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    -- 6. Grammar Explanation
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_explanation', 6, 'Reason and Result (so/such...that)', 'Learn so/such...that for cause and effect', '{"rules": "Use so/such...that to show cause and effect:\n\n- So + adjective/adverb + that (so strict that)\n- Such + (a/an) + adjective + noun + that (such a powerful tool that)\n- Shows strong cause and effect relationship\n- So is used with adjectives/adverbs\n- Such is used with nouns\n- That introduces the result clause", "examples": ["The law is so strict that it limits expression.", "Words can be such a powerful tool that they change opinions.", "The debate was so heated that people stopped listening.", "It was such a strong argument that everyone agreed.", "I was so careful that I didn''t offend anyone."]}'::jsonb)
    RETURNING id INTO activity_id_var;

    -- 7. Grammar Sentences #1
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 7, 'Build Sentences 1', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'The law is so strict that it limits expression', 'The law is so strict that it limits expression.', '["The", "law", "is", "so", "strict", "that", "it", "limits", "expression."]'::jsonb),
    (activity_id_var, 'Words can be such a powerful tool that they change opinions', 'Words can be such a powerful tool that they change opinions.', '["Words", "can", "be", "such", "a", "powerful", "tool", "that", "they", "change", "opinions."]'::jsonb);

    -- 8. Grammar Sentences #2
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 8, 'Build Sentences 2', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'The debate was so heated that people stopped listening', 'The debate was so heated that people stopped listening.', '["The", "debate", "was", "so", "heated", "that", "people", "stopped", "listening."]'::jsonb),
    (activity_id_var, 'It was such a strong argument that everyone agreed', 'It was such a strong argument that everyone agreed.', '["It", "was", "such", "a", "strong", "argument", "that", "everyone", "agreed."]'::jsonb);

    -- 9. Speaking Practice
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'speaking_practice', 9, 'Talk About Communication', 'Practice talking about talking to people', '{"prompts": ["Do you talk to strangers?", "What do you say when you meet someone?", "How do you say goodbye?", "How do you express your opinions?", "What topics do you debate about?"]}'::jsonb)
    RETURNING id INTO activity_id_var;

    -- 10. Speaking Improvement
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'speaking_improvement', 10, 'Speaking Improvement', 'Read the improved version of your speech', '{"type": "speaking_improvement", "similarityThreshold": 70}'::jsonb)
    RETURNING id INTO activity_id_var;
END $$;