-- =========================================
-- Pre-fill Database with Sample Lesson Data
-- B1-L3: Work & Career Plans
-- =========================================

-- Clear existing sample data for B1-L3 (optional - comment out if you want to keep existing data)
DELETE FROM grammar_sentences WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'B1-L3');
DELETE FROM vocabulary_items WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'B1-L3');
DELETE FROM lesson_activities WHERE lesson_id = 'B1-L3';
DELETE FROM lessons WHERE id = 'B1-L3';

INSERT INTO lessons (id, level, lesson_number, topic) VALUES
('B1-L3', 'B1', 3, 'Work & Career Plans')
ON CONFLICT (id) DO UPDATE SET topic = EXCLUDED.topic;

DO $$
DECLARE
    lesson_id_var TEXT := 'B1-L3';
    activity_id_var UUID;
BEGIN
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content) VALUES (lesson_id_var, 'warm_up_speaking', 1, 'Career Goals', 'Talk about career plans', '{"prompt": "What are your career goals?"}'::jsonb) RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content) VALUES (lesson_id_var, 'vocabulary_intro', 2, 'Career Words', 'Learn career vocabulary', '{}'::jsonb) RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'promotion', 'การเลื่อนตำแหน่ง', NULL),
    (activity_id_var, 'salary', 'เงินเดือน', NULL),
    (activity_id_var, 'resume', 'เรซูเม่', NULL),
    (activity_id_var, 'interview', 'การสัมภาษณ์', NULL),
    (activity_id_var, 'qualification', 'คุณสมบัติ', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content) VALUES (lesson_id_var, 'vocabulary_matching_drag', 3, 'Match Career Words', 'Match English words with Thai meanings', '{}'::jsonb) RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'promotion', 'การเลื่อนตำแหน่ง', NULL),
    (activity_id_var, 'salary', 'เงินเดือน', NULL),
    (activity_id_var, 'resume', 'เรซูเม่', NULL),
    (activity_id_var, 'interview', 'การสัมภาษณ์', NULL),
    (activity_id_var, 'qualification', 'คุณสมบัติ', NULL);

    -- 4. Vocabulary Fill Blanks #1 (4 words: promotion, salary, resume, interview - qualification left out)
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content) VALUES (lesson_id_var, 'vocabulary_fill_blanks', 4, 'Complete the Sentences 1', 'Fill in the blanks with correct words', '{"text": "I got a ___. My ___ increased. I updated my ___. I had an ___.", "blanks": [{"id": "blank1", "text": "promotion", "options": ["promotion", "salary", "resume", "interview"], "correctAnswer": "promotion"}, {"id": "blank2", "text": "salary", "options": ["promotion", "salary", "resume", "interview"], "correctAnswer": "salary"}, {"id": "blank3", "text": "resume", "options": ["promotion", "salary", "resume", "interview"], "correctAnswer": "resume"}, {"id": "blank4", "text": "interview", "options": ["promotion", "salary", "resume", "interview"], "correctAnswer": "interview"}]}'::jsonb) RETURNING id INTO activity_id_var;

    -- 4. Vocabulary Fill Blanks #2 (4 words: promotion, salary, resume, qualification - interview left out)
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content) VALUES (lesson_id_var, 'vocabulary_fill_blanks', 5, 'Complete the Sentences 2', 'Fill in the blanks with correct words', '{"text": "I hope for a ___. My ___ is good. I sent my ___. I have the right ___.", "blanks": [{"id": "blank1", "text": "promotion", "options": ["promotion", "salary", "resume", "qualification"], "correctAnswer": "promotion"}, {"id": "blank2", "text": "salary", "options": ["promotion", "salary", "resume", "qualification"], "correctAnswer": "salary"}, {"id": "blank3", "text": "resume", "options": ["promotion", "salary", "resume", "qualification"], "correctAnswer": "resume"}, {"id": "blank4", "text": "qualification", "options": ["promotion", "salary", "resume", "qualification"], "correctAnswer": "qualification"}]}'::jsonb) RETURNING id INTO activity_id_var;

    -- 4. Grammar Explanation (5 examples - CEFR B1: Future plans, conditionals)
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content) VALUES (lesson_id_var, 'grammar_explanation', 6, 'Future Plans & Conditionals', 'Learn to talk about career plans', '{"rules": "Use future forms for plans:\n\n- I am going to + verb (I am going to apply)\n- I will + verb (I will work hard)\n- First conditional: If + present, will + verb (If I get the job, I will be happy)\n- Use ''hope to'' and ''plan to'' for intentions\n- Use ''might'' for possibilities", "examples": ["I am going to apply for a promotion.", "If I get the job, I will be very happy.", "I hope to increase my salary.", "I plan to update my resume.", "I might change jobs next year."]}'::jsonb) RETURNING id INTO activity_id_var;

    -- 4. Grammar Sentences #1
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content) VALUES (lesson_id_var, 'grammar_sentences', 7, 'Build Sentences 1', 'Arrange words to make sentences', '{}'::jsonb) RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'I am going to apply for a promotion', 'I am going to apply for a promotion', '["I", "am", "going", "to", "apply", "for", "a", "promotion"]'::jsonb),
    (activity_id_var, 'If I get the job I will be very happy', 'If I get the job, I will be very happy', '["If", "I", "get", "the", "job", "I", "will", "be", "very", "happy"]'::jsonb);
    -- 4. Grammar Sentences #2
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content) VALUES (lesson_id_var, 'grammar_sentences', 8, 'Build Sentences 2', 'Arrange words to make sentences', '{}'::jsonb) RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'I hope to increase my salary', 'I hope to increase my salary', '["I", "hope", "to", "increase", "my", "salary"]'::jsonb),
    (activity_id_var, 'I plan to update my resume', 'I plan to update my resume', '["I", "plan", "to", "update", "my", "resume"]'::jsonb);
    -- 4. Speaking Practice (5 prompts - CEFR B1: Career and work plans)
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content) VALUES (lesson_id_var, 'speaking_practice', 9, 'Talk About Career', 'Practice talking about career plans', '{"prompts": ["What are your career goals?", "Where do you see yourself in five years?", "Do you think education is important for your career?", "How important is salary to you?", "What qualifications do you need for your dream job?"]}'::jsonb) RETURNING id INTO activity_id_var;

END $$;
INSERT INTO lesson_activities (
  lesson_id,
  activity_type,
  activity_order,
  title,
  description,
  content
) VALUES (
  'B1-L3',
  'speaking_improvement',
  10,
  'Speaking Improvement',
  'Read the improved version of your speech',
  '{"type": "speaking_improvement", "similarityThreshold": 70}'::jsonb
);