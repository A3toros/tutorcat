-- =========================================
-- Pre-fill Database with Sample Lesson Data
-- A2-L99: Trying a New Sport
-- =========================================

DELETE FROM grammar_sentences WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'A2-L99');
DELETE FROM vocabulary_items WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'A2-L99');
DELETE FROM lesson_activities WHERE lesson_id = 'A2-L99';
DELETE FROM lessons WHERE id = 'A2-L99';

INSERT INTO lessons (id, level, lesson_number, topic) VALUES
('A2-L99', 'A2', 99, 'Trying a New Sport')
ON CONFLICT (id) DO UPDATE SET topic = EXCLUDED.topic;

DO $$
DECLARE
    lesson_id_var TEXT := 'A2-L99';
    activity_id_var UUID;
BEGIN
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'warm_up_speaking', 1, 'New Sport', 'Talk about starting a new sport', '{"prompt": "What new sport are you trying now?"}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_intro', 2, 'New Sport Words', 'Learn words for starting a sport', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'try', 'ลอง', NULL),
    (activity_id_var, 'lesson', 'บทเรียน', NULL),
    (activity_id_var, 'coach', 'โค้ช', NULL),
    (activity_id_var, 'gear', 'อุปกรณ์', NULL),
    (activity_id_var, 'safety', 'ความปลอดภัย', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_matching_drag', 3, 'Match New Sport Words', 'Match sport starter words', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'try', 'ลอง', NULL),
    (activity_id_var, 'lesson', 'บทเรียน', NULL),
    (activity_id_var, 'coach', 'โค้ช', NULL),
    (activity_id_var, 'gear', 'อุปกรณ์', NULL),
    (activity_id_var, 'safety', 'ความปลอดภัย', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 4, 'Complete the Sentences 1', 'Fill with the correct word', '{"text": "I will ___ a new sport. I booked a ___. I need a ___.", "blanks": [{"id": "blank1", "text": "try", "options": ["try", "lesson", "coach", "gear"], "correctAnswer": "try"}, {"id": "blank2", "text": "lesson", "options": ["lesson", "coach", "gear", "safety"], "correctAnswer": "lesson"}, {"id": "blank3", "text": "coach", "options": ["coach", "gear", "try", "lesson"], "correctAnswer": "coach"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 5, 'Complete the Sentences 2', 'Fill with the correct word', '{"text": "Do I need special ___? I care about ___.", "blanks": [{"id": "blank1", "text": "gear", "options": ["gear", "safety", "try", "coach"], "correctAnswer": "gear"}, {"id": "blank2", "text": "safety", "options": ["safety", "gear", "lesson", "coach"], "correctAnswer": "safety"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_explanation', 6, 'Present Continuous (plans now)', 'Talk about what you are doing to start', '{"rules": "Use am/is/are + verb-ing for actions happening now or arranged.\n- I am starting lessons this week.\n- We are getting gear today.", "examples": ["I am starting lessons this week.", "We are getting gear today.", "Are you meeting the coach now?", "She is trying a new sport this month.", "They are checking safety rules."]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 7, 'Build Sentences 1', 'Arrange words', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'I am starting lessons this week', 'I am starting lessons this week.', '["I", "am", "starting", "lessons", "this", "week."]'::jsonb),
    (activity_id_var, 'We are getting gear today', 'We are getting gear today.', '["We", "are", "getting", "gear", "today."]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 8, 'Build Sentences 2', 'Arrange words', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'Are you meeting the coach now', 'Are you meeting the coach now?', '["Are", "you", "meeting", "the", "coach", "now?"]'::jsonb),
    (activity_id_var, 'They are checking safety rules', 'They are checking safety rules.', '["They", "are", "checking", "safety", "rules."]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'speaking_practice', 9, 'Talk About New Sports', 'Practice plans for new sports', '{"prompts": ["What new sport are you trying now?", "Who are you training with?", "What equipment are you using?", "How are you learning the rules?", "How do you feel while trying it?"]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (
      lesson_id,
      activity_type,
      activity_order,
      title,
      description,
      content
    ) VALUES (
      'A2-L99',
      'speaking_improvement',
      10,
      'Speaking Improvement',
      'Read the improved version of your speech',
      '{"type": "speaking_improvement", "similarityThreshold": 70}'::jsonb
    );
END $$;

