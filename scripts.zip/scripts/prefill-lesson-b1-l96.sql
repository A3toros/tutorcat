-- =========================================
-- Pre-fill Database with Sample Lesson Data
-- B1-L96: Energy Saver at Home
-- =========================================

DELETE FROM grammar_sentences WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'B1-L96');
DELETE FROM vocabulary_items WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'B1-L96');
DELETE FROM lesson_activities WHERE lesson_id = 'B1-L96';
DELETE FROM lessons WHERE id = 'B1-L96';

INSERT INTO lessons (id, level, lesson_number, topic) VALUES
('B1-L96', 'B1', 96, 'Energy Saver at Home')
ON CONFLICT (id) DO UPDATE SET topic = EXCLUDED.topic;

DO $$
DECLARE
    lesson_id_var TEXT := 'B1-L96';
    activity_id_var UUID;
BEGIN
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'warm_up_speaking', 1, 'Cutting Energy Use', 'Talk about saving energy day to day', '{"prompt": "What change saved the most energy for you at home?"}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_intro', 2, 'Energy Saver Words', 'Learn vocabulary about energy saving', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'insulate', 'ป้องกันความร้อน/ฉนวน', NULL),
    (activity_id_var, 'seal', 'ปิด/ซีล', NULL),
    (activity_id_var, 'timer', 'ตัวจับเวลา', NULL),
    (activity_id_var, 'efficient', 'มีประสิทธิภาพ', NULL),
    (activity_id_var, 'standby', 'โหมดสแตนด์บาย', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_matching_drag', 3, 'Match Energy Saver Words', 'Match words with meanings', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'insulate', 'ป้องกันความร้อน/ฉนวน', NULL),
    (activity_id_var, 'seal', 'ปิด/ซีล', NULL),
    (activity_id_var, 'timer', 'ตัวจับเวลา', NULL),
    (activity_id_var, 'efficient', 'มีประสิทธิภาพ', NULL),
    (activity_id_var, 'standby', 'โหมดสแตนด์บาย', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 4, 'Complete the Sentences 1', 'Fill with the correct word', '{"text": "We ___ windows. A ___ turns lights off. Devices on ___ waste power.", "blanks": [{"id": "blank1", "text": "seal", "options": ["seal", "insulate", "timer", "standby"], "correctAnswer": "seal"}, {"id": "blank2", "text": "timer", "options": ["timer", "seal", "efficient", "standby"], "correctAnswer": "timer"}, {"id": "blank3", "text": "standby", "options": ["standby", "efficient", "timer", "insulate"], "correctAnswer": "standby"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 5, 'Complete the Sentences 2', 'Fill with the correct word', '{"text": "We ___ doors in summer. An ___ fridge saves power. Thick curtains help ___.", "blanks": [{"id": "blank1", "text": "insulate", "options": ["insulate", "seal", "timer", "efficient"], "correctAnswer": "insulate"}, {"id": "blank2", "text": "efficient", "options": ["efficient", "standby", "seal", "timer"], "correctAnswer": "efficient"}, {"id": "blank3", "text": "insulate", "options": ["insulate", "efficient", "seal", "standby"], "correctAnswer": "insulate"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    -- Grammar Explanation: Passive Voice (present) reinforcement
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_explanation', 6, 'Passive Voice (Present) for Energy Actions', 'Use am/is/are + past participle to focus on actions done to homes', '{"rules": "Passive present: am/is/are + past participle. Use for processes and results.\\n- Windows are sealed each year.\\n- Lights are turned off by a timer.\\nAvoid contractions.", "examples": ["Windows are sealed before summer.", "Lights are turned off by a timer.", "Walls are insulated to keep rooms cool.", "Appliances are set to standby mode.", "Old bulbs are replaced with efficient ones."]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 7, 'Build Sentences 1', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'Windows are sealed before summer', 'Windows are sealed before summer', '["Windows", "are", "sealed", "before", "summer"]'::jsonb),
    (activity_id_var, 'Lights are turned off by a timer', 'Lights are turned off by a timer', '["Lights", "are", "turned", "off", "by", "a", "timer"]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 8, 'Build Sentences 2', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'Walls are insulated to keep rooms cool', 'Walls are insulated to keep rooms cool', '["Walls", "are", "insulated", "to", "keep", "rooms", "cool"]'::jsonb),
    (activity_id_var, 'Old bulbs are replaced with efficient ones', 'Old bulbs are replaced with efficient ones', '["Old", "bulbs", "are", "replaced", "with", "efficient", "ones"]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'speaking_practice', 9, 'Talk About Saving Energy', 'Practice talking about home energy choices', '{"prompts": ["What change saved the most energy for you at home?", "How do you remind yourself to switch things off?", "Which upgrade felt worth the cost?"]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (
      lesson_id,
      activity_type,
      activity_order,
      title,
      description,
      content
    ) VALUES (
      'B1-L96',
      'speaking_improvement',
      10,
      'Speaking Improvement',
      'Read the improved version of your speech',
      '{"type": "speaking_improvement", "similarityThreshold": 70}'::jsonb
    );
END $$;

