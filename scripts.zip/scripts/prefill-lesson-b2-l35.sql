-- =========================================
-- Pre-fill Database with Sample Lesson Data
-- B2-L35: Exercise and mental focus
-- =========================================

DELETE FROM grammar_sentences WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'B2-L35');
DELETE FROM vocabulary_items WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'B2-L35');
DELETE FROM lesson_activities WHERE lesson_id = 'B2-L35';
DELETE FROM lessons WHERE id = 'B2-L35';

INSERT INTO lessons (id, level, lesson_number, topic) VALUES
('B2-L35', 'B2', 35, 'Exercise and mental focus')
ON CONFLICT (id) DO UPDATE SET topic = EXCLUDED.topic;

DO $$
DECLARE
    lesson_id_var TEXT := 'B2-L35';
    activity_id_var UUID;
BEGIN
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'warm_up_speaking', 1, 'Workout Signals', 'Talk about how exercise affects focus', '{"prompt": "How can you tell a workout helps focus, and when must you rest?"}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_intro', 2, 'Exercise Words', 'Key words for workouts and recovery', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'workout', 'การออกกำลังกาย', NULL),
    (activity_id_var, 'endorphins', 'เอ็นดอร์ฟิน', NULL),
    (activity_id_var, 'routine', 'กิจวัตร', NULL),
    (activity_id_var, 'intensity', 'ความเข้มข้น', NULL),
    (activity_id_var, 'recover', 'ฟื้นตัว', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_matching_drag', 3, 'Match Exercise Words', 'Match words with meanings', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'workout', 'การออกกำลังกาย', NULL),
    (activity_id_var, 'endorphins', 'เอ็นดอร์ฟิน', NULL),
    (activity_id_var, 'routine', 'กิจวัตร', NULL),
    (activity_id_var, 'intensity', 'ความเข้มข้น', NULL),
    (activity_id_var, 'recover', 'ฟื้นตัว', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 4, 'Complete the Sentences 1', 'Fill with the correct word', '{"text": "A good ___ boosts ___. I adjust ___.", "blanks": [{"id": "blank1", "text": "workout", "options": ["workout", "endorphins", "intensity", "routine"], "correctAnswer": "workout"}, {"id": "blank2", "text": "endorphins", "options": ["endorphins", "routine", "recover", "intensity"], "correctAnswer": "endorphins"}, {"id": "blank3", "text": "intensity", "options": ["intensity", "recover", "routine", "workout"], "correctAnswer": "intensity"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 5, 'Complete the Sentences 2', 'Fill with the correct word', '{"text": "A steady ___ keeps me on track. I plan time to ___.", "blanks": [{"id": "blank1", "text": "routine", "options": ["routine", "workout", "intensity", "endorphins"], "correctAnswer": "routine"}, {"id": "blank2", "text": "recover", "options": ["recover", "routine", "endorphins", "intensity"], "correctAnswer": "recover"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_explanation', 6, 'Modals for Deduction', 'Read signs about focus and rest', '{"rules": "Use must/might/can’t + base verb for present deduction; use modal + have + past participle for past clues.\\n- He must be sore; he trained hard.\\n- She might be fine; she looks fresh.\\n- They can’t be ready; they skipped warm-up.", "examples": ["I must be under-recovered; I can’t focus.", "She might be ready; she looks energized.", "They can’t be tired; they just started.", "He must have overtrained; he looks exhausted.", "The workout might have been too intense; focus is low."]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 7, 'Build Sentences 1', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'He must be sore; he trained hard', 'He must be sore; he trained hard.', '["He", "must", "be", "sore;", "he", "trained", "hard."]'::jsonb),
    (activity_id_var, 'She might be fine; she looks fresh', 'She might be fine; she looks fresh.', '["She", "might", "be", "fine;", "she", "looks", "fresh."]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 8, 'Build Sentences 2', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'He must have overtrained; he looks exhausted', 'He must have overtrained; he looks exhausted.', '["He", "must", "have", "overtrained;", "he", "looks", "exhausted."]'::jsonb),
    (activity_id_var, 'The workout might have been too intense; focus is low', 'The workout might have been too intense; focus is low.', '["The", "workout", "might", "have", "been", "too", "intense;", "focus", "is", "low."]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'speaking_practice', 9, 'Talk About Exercise & Focus', 'Practice deduction', '{"prompts": ["How can you tell a workout helps focus?", "When must you rest?", "Who checks your intensity when you train?"]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (
      lesson_id,
      activity_type,
      activity_order,
      title,
      description,
      content
    ) VALUES (
      'B2-L35',
      'speaking_improvement',
      10,
      'Speaking Improvement',
      'Read the improved version of your speech',
      '{"type": "speaking_improvement", "similarityThreshold": 70}'::jsonb
    );
END $$;


