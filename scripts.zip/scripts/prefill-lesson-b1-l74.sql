-- =========================================
-- Pre-fill Database with Sample Lesson Data
-- B1-L74: Work Under Pressure
-- =========================================

DELETE FROM grammar_sentences WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'B1-L74');
DELETE FROM vocabulary_items WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'B1-L74');
DELETE FROM lesson_activities WHERE lesson_id = 'B1-L74';
DELETE FROM lessons WHERE id = 'B1-L74';

INSERT INTO lessons (id, level, lesson_number, topic) VALUES
('B1-L74', 'B1', 74, 'Work Under Pressure')
ON CONFLICT (id) DO UPDATE SET topic = EXCLUDED.topic;

DO $$
DECLARE
    lesson_id_var TEXT := 'B1-L74';
    activity_id_var UUID;
BEGIN
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'warm_up_speaking', 1, 'Pressure at Work', 'Talk about handling deadlines', '{"prompt": "What helps you cope when deadlines stack up?"}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_intro', 2, 'Pressure Words', 'Learn vocabulary about working under pressure', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'multitask', 'ทำหลายงานพร้อมกัน', NULL),
    (activity_id_var, 'prioritize', 'จัดลำดับความสำคัญ', NULL),
    (activity_id_var, 'deliver', 'ส่งมอบ', NULL),
    (activity_id_var, 'cope', 'รับมือ', NULL),
    (activity_id_var, 'decompress', 'ผ่อนคลาย/ลดความกดดัน', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_matching_drag', 3, 'Match Pressure Words', 'Match words with meanings', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'multitask', 'ทำหลายงานพร้อมกัน', NULL),
    (activity_id_var, 'prioritize', 'จัดลำดับความสำคัญ', NULL),
    (activity_id_var, 'deliver', 'ส่งมอบ', NULL),
    (activity_id_var, 'cope', 'รับมือ', NULL),
    (activity_id_var, 'decompress', 'ผ่อนคลาย/ลดความกดดัน', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 4, 'Complete the Sentences 1', 'Fill with the correct word', '{"text": "I try not to ___. I always ___. We must ___ on time.", "blanks": [{"id": "blank1", "text": "multitask", "options": ["multitask", "prioritize", "deliver", "cope"], "correctAnswer": "multitask"}, {"id": "blank2", "text": "prioritize", "options": ["prioritize", "deliver", "cope", "decompress"], "correctAnswer": "prioritize"}, {"id": "blank3", "text": "deliver", "options": ["deliver", "multitask", "cope", "decompress"], "correctAnswer": "deliver"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 5, 'Complete the Sentences 2', 'Fill with the correct word', '{"text": "Short breaks help me ___. This helps me ___. We need to ___ to stay calm.", "blanks": [{"id": "blank1", "text": "cope", "options": ["cope", "decompress", "prioritize", "deliver"], "correctAnswer": "cope"}, {"id": "blank2", "text": "decompress", "options": ["decompress", "cope", "deliver", "multitask"], "correctAnswer": "decompress"}, {"id": "blank3", "text": "breathe", "options": ["breathe", "cope", "decompress", "prioritize"], "correctAnswer": "breathe"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    -- Grammar Explanation: Gerunds & Infinitives — pressure strategies
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_explanation', 6, 'Gerunds and Infinitives for Pressure', 'Use correct patterns for habits and plans under pressure', '{"rules": "Common pairs: avoid multitasking, prefer to prioritize, decide to deliver early, plan to decompress, try to cope. Keep pairs natural and clear.", "examples": ["I avoid multitasking when work piles up.", "We decided to deliver a draft early.", "She prefers to prioritize in the morning.", "They plan to decompress after big releases.", "He tries to cope by taking short breaks."]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 7, 'Build Sentences 1', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'I avoid multitasking when work piles up', 'I avoid multitasking when work piles up', '["I", "avoid", "multitasking", "when", "work", "piles", "up"]'::jsonb),
    (activity_id_var, 'We decided to deliver a draft early', 'We decided to deliver a draft early', '["We", "decided", "to", "deliver", "a", "draft", "early"]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 8, 'Build Sentences 2', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'She prefers to prioritize in the morning', 'She prefers to prioritize in the morning', '["She", "prefers", "to", "prioritize", "in", "the", "morning"]'::jsonb),
    (activity_id_var, 'They plan to decompress after big releases', 'They plan to decompress after big releases', '["They", "plan", "to", "decompress", "after", "big", "releases"]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'speaking_practice', 9, 'Talk About Pressure', 'Practice talking about working under pressure', '{"prompts": ["What helps you cope when deadlines stack up?", "What do you avoid when you are overloaded?", "Describe delivering on a tight deadline in your life."]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (
      lesson_id,
      activity_type,
      activity_order,
      title,
      description,
      content
    ) VALUES (
      'B1-L74',
      'speaking_improvement',
      10,
      'Speaking Improvement',
      'Read the improved version of your speech',
      '{"type": "speaking_improvement", "similarityThreshold": 70}'::jsonb
    );
END $$;

