-- =========================================
-- Pre-fill Database with Sample Lesson Data
-- A1-L31: Months of the Year
-- =========================================

DELETE FROM grammar_sentences WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'A1-L31');
DELETE FROM vocabulary_items WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'A1-L31');
DELETE FROM lesson_activities WHERE lesson_id = 'A1-L31';
DELETE FROM lessons WHERE id = 'A1-L31';

INSERT INTO lessons (id, level, lesson_number, topic) VALUES
('A1-L31', 'A1', 31, 'Months of the Year')
ON CONFLICT (id) DO UPDATE SET topic = EXCLUDED.topic;

DO $$
DECLARE
    lesson_id_var TEXT := 'A1-L31';
    activity_id_var UUID;
BEGIN
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'warm_up_speaking', 1, 'Birthdays', 'Talk about months', '{"prompt": "When is your birthday?"}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_intro', 2, 'Month Words', 'Learn months', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'January', 'มกราคม', NULL),
    (activity_id_var, 'February', 'กุมภาพันธ์', NULL),
    (activity_id_var, 'March', 'มีนาคม', NULL),
    (activity_id_var, 'April', 'เมษายน', NULL),
    (activity_id_var, 'May', 'พฤษภาคม', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_matching_drag', 3, 'Match Month Words', 'Match months', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'January', 'มกราคม', NULL),
    (activity_id_var, 'February', 'กุมภาพันธ์', NULL),
    (activity_id_var, 'March', 'มีนาคม', NULL),
    (activity_id_var, 'April', 'เมษายน', NULL),
    (activity_id_var, 'May', 'พฤษภาคม', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 4, 'Complete the Sentences 1', 'Fill with the correct word', '{"text": "My birthday is in ___. School starts in ___.", "blanks": [{"id": "blank1", "text": "May", "options": ["May", "March", "April", "February"], "correctAnswer": "May"}, {"id": "blank2", "text": "March", "options": ["March", "January", "May", "April"], "correctAnswer": "March"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 5, 'Complete the Sentences 2', 'Fill with the correct word', '{"text": "It is hot in ___. It is rainy in ___.", "blanks": [{"id": "blank1", "text": "April", "options": ["April", "February", "May", "January"], "correctAnswer": "April"}, {"id": "blank2", "text": "January", "options": ["January", "May", "March", "April"], "correctAnswer": "January"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_explanation', 6, 'In + Months', 'Use in with months', '{"rules": "Use in + month to talk about time.\n- My birthday is in May.\n- School starts in March.\nAsk: When is your birthday?", "examples": ["My birthday is in May.", "We travel in April.", "School starts in March.", "Is your exam in February?", "Do you rest in January?"]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 7, 'Build Sentences 1', 'Arrange words', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'My birthday is in May', 'My birthday is in May.', '["My", "birthday", "is", "in", "May."]'::jsonb),
    (activity_id_var, 'School starts in March', 'School starts in March.', '["School", "starts", "in", "March."]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 8, 'Build Sentences 2', 'Arrange words', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'Is your exam in February', 'Is your exam in February?', '["Is", "your", "exam", "in", "February?"]'::jsonb),
    (activity_id_var, 'Do you travel in April', 'Do you travel in April?', '["Do", "you", "travel", "in", "April?"]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'speaking_practice', 9, 'Talk About Months', 'Practice months with in', '{"prompts": ["When is your birthday?", "Do you travel in April?", "Is your exam in February?", "Do you rest in January?", "Is school in March?"]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (
      lesson_id,
      activity_type,
      activity_order,
      title,
      description,
      content
    ) VALUES (
      'A1-L31',
      'speaking_improvement',
      10,
      'Speaking Improvement',
      'Read the improved version of your speech',
      '{"type": "speaking_improvement", "similarityThreshold": 70}'::jsonb
    );
END $$;

