-- =========================================
-- Pre-fill Database with Sample Lesson Data
-- A2-L93: Working Hours
-- =========================================

DELETE FROM grammar_sentences WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'A2-L93');
DELETE FROM vocabulary_items WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'A2-L93');
DELETE FROM lesson_activities WHERE lesson_id = 'A2-L93';
DELETE FROM lessons WHERE id = 'A2-L93';

INSERT INTO lessons (id, level, lesson_number, topic) VALUES
('A2-L93', 'A2', 93, 'Working Hours')
ON CONFLICT (id) DO UPDATE SET topic = EXCLUDED.topic;

DO $$
DECLARE
    lesson_id_var TEXT := 'A2-L93';
    activity_id_var UUID;
BEGIN
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'warm_up_speaking', 1, 'Work Time', 'Talk about your working hours', '{"prompt": "How often do you work late?"}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_intro', 2, 'Work Hour Words', 'Learn frequency words for work', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'often', 'บ่อย', NULL),
    (activity_id_var, 'always', 'เสมอ', NULL),
    (activity_id_var, 'rarely', 'ไม่บ่อย', NULL),
    (activity_id_var, 'sometimes', 'บางครั้ง', NULL),
    (activity_id_var, 'usually', 'มักจะ', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_matching_drag', 3, 'Match Work Hour Words', 'Match frequency words', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'often', 'บ่อย', NULL),
    (activity_id_var, 'always', 'เสมอ', NULL),
    (activity_id_var, 'rarely', 'ไม่บ่อย', NULL),
    (activity_id_var, 'sometimes', 'บางครั้ง', NULL),
    (activity_id_var, 'usually', 'มักจะ', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 4, 'Complete the Sentences 1', 'Fill with the correct word', '{"text": "I ___ work late. I ___ take lunch. We ___ finish early.", "blanks": [{"id": "blank1", "text": "often", "options": ["often", "always", "rarely", "sometimes"], "correctAnswer": "often"}, {"id": "blank2", "text": "always", "options": ["always", "usually", "rarely", "sometimes"], "correctAnswer": "always"}, {"id": "blank3", "text": "sometimes", "options": ["sometimes", "rarely", "always", "often"], "correctAnswer": "sometimes"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 5, 'Complete the Sentences 2', 'Fill with the correct word', '{"text": "I ___ work on Sunday. I ___ start early on Monday.", "blanks": [{"id": "blank1", "text": "rarely", "options": ["rarely", "always", "often", "usually"], "correctAnswer": "rarely"}, {"id": "blank2", "text": "usually", "options": ["usually", "rarely", "always", "sometimes"], "correctAnswer": "usually"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_explanation', 6, 'Adverbs of Frequency', 'Describe work schedules', '{"rules": "Use always/usually/often/sometimes/rarely/never.\nPlace: before main verb; after be.\n- I often work late. Work is usually busy.", "examples": ["I often work late.", "Work is usually busy.", "We sometimes finish early.", "Do you always take lunch?", "I rarely work on Sunday."]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 7, 'Build Sentences 1', 'Arrange words', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'I often work late', 'I often work late.', '["I", "often", "work", "late."]'::jsonb),
    (activity_id_var, 'Work is usually busy', 'Work is usually busy.', '["Work", "is", "usually", "busy."]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 8, 'Build Sentences 2', 'Arrange words', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'Do you always take lunch', 'Do you always take lunch?', '["Do", "you", "always", "take", "lunch?"]'::jsonb),
    (activity_id_var, 'I rarely work on Sunday', 'I rarely work on Sunday.', '["I", "rarely", "work", "on", "Sunday."]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'speaking_practice', 9, 'Talk About Working Hours', 'Practice frequency of work', '{"prompts": ["How often do you work late?", "Do you usually take breaks?", "What day do you work the longest?", "Do you sometimes work weekends?", "How do you manage your work schedule?"]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (
      lesson_id,
      activity_type,
      activity_order,
      title,
      description,
      content
    ) VALUES (
      'A2-L93',
      'speaking_improvement',
      10,
      'Speaking Improvement',
      'Read the improved version of your speech',
      '{"type": "speaking_improvement", "similarityThreshold": 70}'::jsonb
    );
END $$;

