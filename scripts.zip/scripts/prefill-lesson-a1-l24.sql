-- =========================================
-- Pre-fill Database with Sample Lesson Data
-- A1-L24: Asking Simple Questions
-- =========================================

DELETE FROM grammar_sentences WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'A1-L24');
DELETE FROM vocabulary_items WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'A1-L24');
DELETE FROM lesson_activities WHERE lesson_id = 'A1-L24';
DELETE FROM lessons WHERE id = 'A1-L24';

INSERT INTO lessons (id, level, lesson_number, topic) VALUES
('A1-L24', 'A1', 24, 'Asking Simple Questions')
ON CONFLICT (id) DO UPDATE SET topic = EXCLUDED.topic;

DO $$
DECLARE
    lesson_id_var TEXT := 'A1-L24';
    activity_id_var UUID;
BEGIN
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'warm_up_speaking', 1, 'Questions', 'Practice short questions', '{"prompt": "What is your name?"}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_intro', 2, 'Question Words', 'Learn question words', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'what', 'อะไร', NULL),
    (activity_id_var, 'where', 'ที่ไหน', NULL),
    (activity_id_var, 'who', 'ใคร', NULL),
    (activity_id_var, 'name', 'ชื่อ', NULL),
    (activity_id_var, 'yes', 'ใช่', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_matching_drag', 3, 'Match Question Words', 'Match question words', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'what', 'อะไร', NULL),
    (activity_id_var, 'where', 'ที่ไหน', NULL),
    (activity_id_var, 'who', 'ใคร', NULL),
    (activity_id_var, 'name', 'ชื่อ', NULL),
    (activity_id_var, 'yes', 'ใช่', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 4, 'Complete the Sentences 1', 'Fill with the correct word', '{"text": "__ is your name? __ are you?", "blanks": [{"id": "blank1", "text": "What", "options": ["What", "Where", "Who", "Yes"], "correctAnswer": "What"}, {"id": "blank2", "text": "How", "options": ["How", "Who", "Where", "What"], "correctAnswer": "How"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 5, 'Complete the Sentences 2', 'Fill with the correct word', '{"text": "__ is he? __ is the bank?", "blanks": [{"id": "blank1", "text": "Who", "options": ["Who", "What", "Yes", "Name"], "correctAnswer": "Who"}, {"id": "blank2", "text": "Where", "options": ["Where", "Who", "What", "Yes"], "correctAnswer": "Where"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_explanation', 6, 'Be Questions', 'Make simple be questions', '{"rules": "Start with be for questions.\n- What is your name?\n- Where are you?\n- Who is he?\nShort answers: Yes, I am. No, I am not.", "examples": ["What is your name?", "Where are you?", "Who is he?", "Are you here?", "Is she a student?"]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 7, 'Build Sentences 1', 'Arrange words', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'What is your name', 'What is your name?', '["What", "is", "your", "name?"]'::jsonb),
    (activity_id_var, 'Where are you', 'Where are you?', '["Where", "are", "you?"]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 8, 'Build Sentences 2', 'Arrange words', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'Who is he', 'Who is he?', '["Who", "is", "he?"]'::jsonb),
    (activity_id_var, 'Is she a student', 'Is she a student?', '["Is", "she", "a", "student?"]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'speaking_practice', 9, 'Ask Simple Questions', 'Practice be questions', '{"prompts": ["What is your name?", "Where are you?", "Who is he?", "Are you here?", "Is she a student?"]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (
      lesson_id,
      activity_type,
      activity_order,
      title,
      description,
      content
    ) VALUES (
      'A1-L24',
      'speaking_improvement',
      10,
      'Speaking Improvement',
      'Read the improved version of your speech',
      '{"type": "speaking_improvement", "similarityThreshold": 70}'::jsonb
    );
END $$;

