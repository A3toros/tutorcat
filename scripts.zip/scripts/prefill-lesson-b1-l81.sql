-- =========================================
-- Pre-fill Database with Sample Lesson Data
-- B1-L81: Trust & Misinformation
-- =========================================

DELETE FROM grammar_sentences WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'B1-L81');
DELETE FROM vocabulary_items WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'B1-L81');
DELETE FROM lesson_activities WHERE lesson_id = 'B1-L81';
DELETE FROM lessons WHERE id = 'B1-L81';

INSERT INTO lessons (id, level, lesson_number, topic) VALUES
('B1-L81', 'B1', 81, 'Trust & Misinformation')
ON CONFLICT (id) DO UPDATE SET topic = EXCLUDED.topic;

DO $$
DECLARE
    lesson_id_var TEXT := 'B1-L81';
    activity_id_var UUID;
BEGIN
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'warm_up_speaking', 1, 'Trusting News', 'Talk about trusting and debunking information', '{"prompt": "Who do you actually trust for news?"}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_intro', 2, 'Trust Words', 'Learn vocabulary about misinformation', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'rumor', 'ข่าวลือ', NULL),
    (activity_id_var, 'source', 'แหล่งที่มา', NULL),
    (activity_id_var, 'claim', 'ข้ออ้าง/การกล่าวอ้าง', NULL),
    (activity_id_var, 'verify', 'ตรวจสอบ', NULL),
    (activity_id_var, 'debunk', 'หักล้าง', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_matching_drag', 3, 'Match Trust Words', 'Match words with meanings', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'rumor', 'ข่าวลือ', NULL),
    (activity_id_var, 'source', 'แหล่งที่มา', NULL),
    (activity_id_var, 'claim', 'ข้ออ้าง/การกล่าวอ้าง', NULL),
    (activity_id_var, 'verify', 'ตรวจสอบ', NULL),
    (activity_id_var, 'debunk', 'หักล้าง', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 4, 'Complete the Sentences 1', 'Fill with the correct word', '{"text": "This ___ spread fast. Check the ___. The ___ is false.", "blanks": [{"id": "blank1", "text": "rumor", "options": ["rumor", "source", "claim", "verify"], "correctAnswer": "rumor"}, {"id": "blank2", "text": "source", "options": ["source", "claim", "debunk", "verify"], "correctAnswer": "source"}, {"id": "blank3", "text": "claim", "options": ["claim", "rumor", "source", "debunk"], "correctAnswer": "claim"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 5, 'Complete the Sentences 2', 'Fill with the correct word', '{"text": "Always ___ before sharing. Help ___ wrong posts. Trust a known ___.", "blanks": [{"id": "blank1", "text": "verify", "options": ["verify", "debunk", "source", "claim"], "correctAnswer": "verify"}, {"id": "blank2", "text": "debunk", "options": ["debunk", "verify", "rumor", "claim"], "correctAnswer": "debunk"}, {"id": "blank3", "text": "source", "options": ["source", "verify", "debunk", "claim"], "correctAnswer": "source"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    -- Grammar Explanation: Relative Clauses (reinforce)
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_explanation', 6, 'Relative Clauses for Trust', 'Use who/which/that to define reliable sources and claims', '{"rules": "Use who/which/that without commas to add essential info.\\n- The source that we trust is verified.\\n- The claim that people share needs proof.\\nNo contractions.", "examples": ["The source that we trust is transparent.", "The claim that spread fastest was false.", "The person who debunked it is a doctor.", "The article that you shared lacked proof.", "The rumor that we heard yesterday was corrected."]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 7, 'Build Sentences 1', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'The source that we trust is transparent', 'The source that we trust is transparent', '["The", "source", "that", "we", "trust", "is", "transparent"]'::jsonb),
    (activity_id_var, 'The claim that spread fastest was false', 'The claim that spread fastest was false', '["The", "claim", "that", "spread", "fastest", "was", "false"]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 8, 'Build Sentences 2', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'The person who debunked it is a doctor', 'The person who debunked it is a doctor', '["The", "person", "who", "debunked", "it", "is", "a", "doctor"]'::jsonb),
    (activity_id_var, 'The article that you shared lacked proof', 'The article that you shared lacked proof', '["The", "article", "that", "you", "shared", "lacked", "proof"]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'speaking_practice', 9, 'Talk About Trust & Misinformation', 'Practice talking about trust and debunking', '{"prompts": ["Who do you actually trust for news?", "How do you debunk a rumor with friends?", "When do you just ignore a story?"]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (
      lesson_id,
      activity_type,
      activity_order,
      title,
      description,
      content
    ) VALUES (
      'B1-L81',
      'speaking_improvement',
      10,
      'Speaking Improvement',
      'Read the improved version of your speech',
      '{"type": "speaking_improvement", "similarityThreshold": 70}'::jsonb
    );
END $$;

