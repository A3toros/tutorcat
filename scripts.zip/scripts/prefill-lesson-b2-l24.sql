-- =========================================
-- Pre-fill Database with Sample Lesson Data
-- B2-L24: Making new friends
-- =========================================

DELETE FROM grammar_sentences WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'B2-L24');
DELETE FROM vocabulary_items WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'B2-L24');
DELETE FROM lesson_activities WHERE lesson_id = 'B2-L24';
DELETE FROM lessons WHERE id = 'B2-L24';

INSERT INTO lessons (id, level, lesson_number, topic) VALUES
('B2-L24', 'B2', 24, 'Making new friends')
ON CONFLICT (id) DO UPDATE SET topic = EXCLUDED.topic;

DO $$
DECLARE
    lesson_id_var TEXT := 'B2-L24';
    activity_id_var UUID;
BEGIN
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'warm_up_speaking', 1, 'First Contact', 'Talk about starting friendships', '{"prompt": "What should be shared early, and how should contact be kept?"}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_intro', 2, 'Friend-Making Words', 'Key words for meeting people', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'approach', 'เข้าหา/วิธีเข้าหา', NULL),
    (activity_id_var, 'invite', 'เชิญ', NULL),
    (activity_id_var, 'mingle', 'ปะปน/เข้าสังคม', NULL),
    (activity_id_var, 'follow up', 'ติดตาม/ติดต่อภายหลัง', NULL),
    (activity_id_var, 'intro', 'การแนะนำตัว', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_matching_drag', 3, 'Match Friend-Making Words', 'Match words with meanings', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'approach', 'เข้าหา/วิธีเข้าหา', NULL),
    (activity_id_var, 'invite', 'เชิญ', NULL),
    (activity_id_var, 'mingle', 'ปะปน/เข้าสังคม', NULL),
    (activity_id_var, 'follow up', 'ติดตาม/ติดต่อภายหลัง', NULL),
    (activity_id_var, 'intro', 'การแนะนำตัว', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 4, 'Complete the Sentences 1', 'Fill with the correct word', '{"text": "A warm ___ helps. I ___ people to coffee. I ___ at events.", "blanks": [{"id": "blank1", "text": "intro", "options": ["intro", "invite", "mingle", "approach"], "correctAnswer": "intro"}, {"id": "blank2", "text": "invite", "options": ["invite", "approach", "follow up", "mingle"], "correctAnswer": "invite"}, {"id": "blank3", "text": "mingle", "options": ["mingle", "follow up", "invite", "intro"], "correctAnswer": "mingle"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 5, 'Complete the Sentences 2', 'Fill with the correct word', '{"text": "I plan my ___. I always ___ after events.", "blanks": [{"id": "blank1", "text": "approach", "options": ["approach", "intro", "mingle", "invite"], "correctAnswer": "approach"}, {"id": "blank2", "text": "follow up", "options": ["follow up", "invite", "approach", "mingle"], "correctAnswer": "follow up"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_explanation', 6, 'Passive with Modals', 'Set expectations politely', '{"rules": "Use modal + be + past participle to emphasize action/necessity.\\n- Information should be shared early.\\n- Contact must be kept respectfully.\\nUse modal + have + been + past participle for past duties.", "examples": ["Introductions should be clear.", "Contact info must be confirmed.", "Boundaries can be stated early.", "Follow-ups should be sent within a day.", "Names must have been remembered from the intro."]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 7, 'Build Sentences 1', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'Introductions should be clear', 'Introductions should be clear.', '["Introductions", "should", "be", "clear."]'::jsonb),
    (activity_id_var, 'Contact info must be confirmed', 'Contact info must be confirmed.', '["Contact", "info", "must", "be", "confirmed."]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 8, 'Build Sentences 2', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'Follow-ups should be sent within a day', 'Follow-ups should be sent within a day.', '["Follow-ups", "should", "be", "sent", "within", "a", "day."]'::jsonb),
    (activity_id_var, 'Names must have been remembered from the intro', 'Names must have been remembered from the intro.', '["Names", "must", "have", "been", "remembered", "from", "the", "intro."]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'speaking_practice', 9, 'Talk About Meeting People', 'Practice passive with modals', '{"prompts": ["What should be shared early when you meet?", "How should contact be kept respectful?", "When must a follow-up be sent?"]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (
      lesson_id,
      activity_type,
      activity_order,
      title,
      description,
      content
    ) VALUES (
      'B2-L24',
      'speaking_improvement',
      10,
      'Speaking Improvement',
      'Read the improved version of your speech',
      '{"type": "speaking_improvement", "similarityThreshold": 70}'::jsonb
    );
END $$;


