-- =========================================
-- Pre-fill Database with Sample Lesson Data
-- B2-L45: Responsible technology use
-- =========================================

DELETE FROM grammar_sentences WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'B2-L45');
DELETE FROM vocabulary_items WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'B2-L45');
DELETE FROM lesson_activities WHERE lesson_id = 'B2-L45';
DELETE FROM lessons WHERE id = 'B2-L45';

INSERT INTO lessons (id, level, lesson_number, topic) VALUES
('B2-L45', 'B2', 45, 'Responsible technology use')
ON CONFLICT (id) DO UPDATE SET topic = EXCLUDED.topic;

DO $$
DECLARE
    lesson_id_var TEXT := 'B2-L45';
    activity_id_var UUID;
BEGIN
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'warm_up_speaking', 1, 'Rules & Reminders', 'Talk about tech rules', '{"prompt": "What rule is so clear you always follow it, and how do you remind peers?"}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_intro', 2, 'Responsible Tech Words', 'Key words for rules and compliance', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'guideline', 'แนวทาง', NULL),
    (activity_id_var, 'policy', 'นโยบาย', NULL),
    (activity_id_var, 'restrict', 'จำกัด/ห้าม', NULL),
    (activity_id_var, 'comply', 'ปฏิบัติตาม', NULL),
    (activity_id_var, 'misuse', 'การใช้งานผิดวิธี', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_matching_drag', 3, 'Match Responsible Tech Words', 'Match words with meanings', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'guideline', 'แนวทาง', NULL),
    (activity_id_var, 'policy', 'นโยบาย', NULL),
    (activity_id_var, 'restrict', 'จำกัด/ห้าม', NULL),
    (activity_id_var, 'comply', 'ปฏิบัติตาม', NULL),
    (activity_id_var, 'misuse', 'การใช้งานผิดวิธี', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 4, 'Complete the Sentences 1', 'Fill with the correct word', '{"text": "The ___ is clear. We must ___ with it. It helps prevent ___.", "blanks": [{"id": "blank1", "text": "guideline", "options": ["guideline", "policy", "restrict", "comply"], "correctAnswer": "guideline"}, {"id": "blank2", "text": "comply", "options": ["comply", "restrict", "misuse", "policy"], "correctAnswer": "comply"}, {"id": "blank3", "text": "misuse", "options": ["misuse", "restrict", "guideline", "policy"], "correctAnswer": "misuse"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 5, 'Complete the Sentences 2', 'Fill with the correct word', '{"text": "Some apps ___ certain actions. A ___ explains why.", "blanks": [{"id": "blank1", "text": "restrict", "options": ["restrict", "comply", "misuse", "guideline"], "correctAnswer": "restrict"}, {"id": "blank2", "text": "policy", "options": ["policy", "guideline", "restrict", "misuse"], "correctAnswer": "policy"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_explanation', 6, 'Reason & Result (such…that)', 'Link rules to outcomes', '{"rules": "Use such + (a/an) + adj + noun + that to show a strong cause → result. Use so + adj/adv + that similarly.\\n- It was such a clear rule that no one broke it.\\n- The policy was so strict that we changed habits.", "examples": ["It was such a clear guideline that everyone complied.", "The policy was so strict that misuse stopped.", "Reminders were so frequent that people followed.", "It was such an important rule that we repeated it.", "The limit was so firm that we adjusted quickly."]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 7, 'Build Sentences 1', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'It was such a clear guideline that everyone complied', 'It was such a clear guideline that everyone complied.', '["It", "was", "such", "a", "clear", "guideline", "that", "everyone", "complied."]'::jsonb),
    (activity_id_var, 'The policy was so strict that misuse stopped', 'The policy was so strict that misuse stopped.', '["The", "policy", "was", "so", "strict", "that", "misuse", "stopped."]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 8, 'Build Sentences 2', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'It was such an important rule that we repeated it', 'It was such an important rule that we repeated it.', '["It", "was", "such", "an", "important", "rule", "that", "we", "repeated", "it."]'::jsonb),
    (activity_id_var, 'Reminders were so frequent that people followed', 'Reminders were so frequent that people followed.', '["Reminders", "were", "so", "frequent", "that", "people", "followed."]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'speaking_practice', 9, 'Talk About Tech Rules', 'Practice cause/effect', '{"prompts": ["What rule is so clear you always follow it?", "How do you remind peers about policies?", "When is a limit so firm that you change habits?"]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (
      lesson_id,
      activity_type,
      activity_order,
      title,
      description,
      content
    ) VALUES (
      'B2-L45',
      'speaking_improvement',
      10,
      'Speaking Improvement',
      'Read the improved version of your speech',
      '{"type": "speaking_improvement", "similarityThreshold": 70}'::jsonb
    );
END $$;


