-- =========================================
-- Pre-fill Database with Sample Lesson Data
-- A2-L24: Reading a Menu
-- =========================================

DELETE FROM grammar_sentences WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'A2-L24');
DELETE FROM vocabulary_items WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'A2-L24');
DELETE FROM lesson_activities WHERE lesson_id = 'A2-L24';
DELETE FROM lessons WHERE id = 'A2-L24';

INSERT INTO lessons (id, level, lesson_number, topic) VALUES
('A2-L24', 'A2', 24, 'Reading a Menu')
ON CONFLICT (id) DO UPDATE SET topic = EXCLUDED.topic;

DO $$
DECLARE
    lesson_id_var TEXT := 'A2-L24';
    activity_id_var UUID;
BEGIN
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'warm_up_speaking', 1, 'Menu Choices', 'Talk about menus', '{"prompt": "What do you usually check first on a menu?"}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_intro', 2, 'Menu Words', 'Learn menu vocabulary', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'starter', 'อาหารเรียกน้ำย่อย', NULL),
    (activity_id_var, 'main', 'จานหลัก', NULL),
    (activity_id_var, 'dessert', 'ของหวาน', NULL),
    (activity_id_var, 'spicy', 'เผ็ด', NULL),
    (activity_id_var, 'vegetarian', 'มังสวิรัติ', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_matching_drag', 3, 'Match Menu Words', 'Match menu sections', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'starter', 'อาหารเรียกน้ำย่อย', NULL),
    (activity_id_var, 'main', 'จานหลัก', NULL),
    (activity_id_var, 'dessert', 'ของหวาน', NULL),
    (activity_id_var, 'spicy', 'เผ็ด', NULL),
    (activity_id_var, 'vegetarian', 'มังสวิรัติ', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 4, 'Complete the Sentences 1', 'Fill with the correct word', '{"text": "For a ___, I want salad. For the ___, I like pasta. I like ice cream for ___.", "blanks": [{"id": "blank1", "text": "starter", "options": ["starter", "main", "dessert", "spicy"], "correctAnswer": "starter"}, {"id": "blank2", "text": "main", "options": ["main", "starter", "dessert", "vegetarian"], "correctAnswer": "main"}, {"id": "blank3", "text": "dessert", "options": ["dessert", "main", "starter", "spicy"], "correctAnswer": "dessert"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 5, 'Complete the Sentences 2', 'Fill with the correct word', '{"text": "Is this dish ___? Do you have a ___ option? I want a non-___ main.", "blanks": [{"id": "blank1", "text": "spicy", "options": ["spicy", "vegetarian", "main", "dessert"], "correctAnswer": "spicy"}, {"id": "blank2", "text": "vegetarian", "options": ["vegetarian", "spicy", "starter", "dessert"], "correctAnswer": "vegetarian"}, {"id": "blank3", "text": "spicy", "options": ["spicy", "vegetarian", "main", "starter"], "correctAnswer": "spicy"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_explanation', 6, 'There is / There are (food)', 'Talk about items on a menu', '{"rules": "Use there is/there are to say what the menu has.\n- There is a vegetarian dish.\n- There are two spicy soups.\nQuestions: Is there a salad? Are there desserts?", "examples": ["There is a vegetarian option.", "There are two spicy soups.", "Is there a salad?", "Are there desserts today?", "There is a sweet cake."]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 7, 'Build Sentences 1', 'Arrange words', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'There is a vegetarian option', 'There is a vegetarian option.', '["There", "is", "a", "vegetarian", "option."]'::jsonb),
    (activity_id_var, 'There are two spicy soups', 'There are two spicy soups.', '["There", "are", "two", "spicy", "soups."]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 8, 'Build Sentences 2', 'Arrange words', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'Is there a salad', 'Is there a salad?', '["Is", "there", "a", "salad?"]'::jsonb),
    (activity_id_var, 'Are there desserts today', 'Are there desserts today?', '["Are", "there", "desserts", "today?"]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'speaking_practice', 9, 'Talk About Menus', 'Practice choosing food', '{"prompts": ["What do you usually check first on a menu?", "Do you ask if food is spicy?", "What desserts do you usually like?", "How do you choose what to order?", "Are there vegetarian options on the menu?"]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (
      lesson_id,
      activity_type,
      activity_order,
      title,
      description,
      content
    ) VALUES (
      'A2-L24',
      'speaking_improvement',
      10,
      'Speaking Improvement',
      'Read the improved version of your speech',
      '{"type": "speaking_improvement", "similarityThreshold": 70}'::jsonb
    );
END $$;

