-- =========================================
-- Pre-fill Database with Sample Lesson Data
-- B2-L36: Coping with failure
-- =========================================

DELETE FROM grammar_sentences WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'B2-L36');
DELETE FROM vocabulary_items WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'B2-L36');
DELETE FROM lesson_activities WHERE lesson_id = 'B2-L36';
DELETE FROM lessons WHERE id = 'B2-L36';

INSERT INTO lessons (id, level, lesson_number, topic) VALUES
('B2-L36', 'B2', 36, 'Coping with failure')
ON CONFLICT (id) DO UPDATE SET topic = EXCLUDED.topic;

DO $$
DECLARE
    lesson_id_var TEXT := 'B2-L36';
    activity_id_var UUID;
BEGIN
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'warm_up_speaking', 1, 'Lessons Learned', 'Talk about adjustments', '{"prompt": "Although it failed, what did you learn, and what did you change?"}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_intro', 2, 'Failure & Growth Words', 'Key words for reflecting and adjusting', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'attempt', 'ความพยายาม', NULL),
    (activity_id_var, 'hindsight', 'การมองย้อน/บทเรียนย้อนหลัง', NULL),
    (activity_id_var, 'adjust', 'ปรับ', NULL),
    (activity_id_var, 'redo', 'ทำใหม่', NULL),
    (activity_id_var, 'reflect', 'ไตร่ตรอง', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_matching_drag', 3, 'Match Failure & Growth Words', 'Match words with meanings', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'attempt', 'ความพยายาม', NULL),
    (activity_id_var, 'hindsight', 'การมองย้อน/บทเรียนย้อนหลัง', NULL),
    (activity_id_var, 'adjust', 'ปรับ', NULL),
    (activity_id_var, 'redo', 'ทำใหม่', NULL),
    (activity_id_var, 'reflect', 'ไตร่ตรอง', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 4, 'Complete the Sentences 1', 'Fill with the correct word', '{"text": "In ___. I decided to ___. I can ___ the project.", "blanks": [{"id": "blank1", "text": "hindsight", "options": ["hindsight", "attempt", "redo", "adjust"], "correctAnswer": "hindsight"}, {"id": "blank2", "text": "adjust", "options": ["adjust", "reflect", "redo", "attempt"], "correctAnswer": "adjust"}, {"id": "blank3", "text": "redo", "options": ["redo", "attempt", "adjust", "reflect"], "correctAnswer": "redo"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 5, 'Complete the Sentences 2', 'Fill with the correct word', '{"text": "Each ___ teaches me. I take time to ___.", "blanks": [{"id": "blank1", "text": "attempt", "options": ["attempt", "redo", "adjust", "reflect"], "correctAnswer": "attempt"}, {"id": "blank2", "text": "reflect", "options": ["reflect", "attempt", "redo", "adjust"], "correctAnswer": "reflect"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_explanation', 6, 'Contrast & Concession', 'Frame lessons with although/however', '{"rules": "Use although + clause to show contrast in one sentence. Use however to contrast sentences. Keep clauses parallel.\\n- Although the attempt failed, I learned a lot.\\n- The plan failed; however, the lesson was clear.", "examples": ["Although it failed, I found a better method.", "The task was late; however, the quality improved.", "Although I was disappointed, I adjusted fast.", "The first attempt failed; however, the redo worked.", "Although feedback was tough, it helped."]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 7, 'Build Sentences 1', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'Although it failed, I found a better method', 'Although it failed, I found a better method.', '["Although", "it", "failed,", "I", "found", "a", "better", "method."]'::jsonb),
    (activity_id_var, 'The task was late; however, the quality improved', 'The task was late; however, the quality improved.', '["The", "task", "was", "late;", "however,", "the", "quality", "improved."]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 8, 'Build Sentences 2', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'Although I was disappointed, I adjusted fast', 'Although I was disappointed, I adjusted fast.', '["Although", "I", "was", "disappointed,", "I", "adjusted", "fast."]'::jsonb),
    (activity_id_var, 'The first attempt failed; however, the redo worked', 'The first attempt failed; however, the redo worked.', '["The", "first", "attempt", "failed;", "however,", "the", "redo", "worked."]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'speaking_practice', 9, 'Talk About Failure & Learning', 'Practice contrast language', '{"prompts": ["Although it failed, what did you learn?", "What did you change after feedback?", "When did a redo work better?"]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (
      lesson_id,
      activity_type,
      activity_order,
      title,
      description,
      content
    ) VALUES (
      'B2-L36',
      'speaking_improvement',
      10,
      'Speaking Improvement',
      'Read the improved version of your speech',
      '{"type": "speaking_improvement", "similarityThreshold": 70}'::jsonb
    );
END $$;


