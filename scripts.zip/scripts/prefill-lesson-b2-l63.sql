-- =========================================
-- Pre-fill Database with Sample Lesson Data
-- B2-L63: Media and emotions
-- =========================================

DELETE FROM grammar_sentences WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'B2-L63');
DELETE FROM vocabulary_items WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'B2-L63');
DELETE FROM lesson_activities WHERE lesson_id = 'B2-L63';
DELETE FROM lessons WHERE id = 'B2-L63';

INSERT INTO lessons (id, level, lesson_number, topic) VALUES
('B2-L63', 'B2', 63, 'Media and emotions')
ON CONFLICT (id) DO UPDATE SET topic = EXCLUDED.topic;

DO $$
DECLARE
    lesson_id_var TEXT := 'B2-L63';
    activity_id_var UUID;
BEGIN
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'warm_up_speaking', 1, 'Emotional Media', 'Talk about reactions to content', '{"prompt": "What content was so intense you stopped, and what helps you reset?"}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_intro', 2, 'Emotion Words', 'Key words for media impact', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'trigger', 'สิ่งกระตุ้น', NULL),
    (activity_id_var, 'comfort', 'ความสบายใจ', NULL),
    (activity_id_var, 'detach', 'แยกตัว/เว้นระยะ', NULL),
    (activity_id_var, 'overwhelm', 'ความรู้สึกล้น', NULL),
    (activity_id_var, 'empathy', 'ความเข้าใจผู้อื่น', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_matching_drag', 3, 'Match Emotion Words', 'Match words with meanings', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'trigger', 'สิ่งกระตุ้น', NULL),
    (activity_id_var, 'comfort', 'ความสบายใจ', NULL),
    (activity_id_var, 'detach', 'แยกตัว/เว้นระยะ', NULL),
    (activity_id_var, 'overwhelm', 'ความรู้สึกล้น', NULL),
    (activity_id_var, 'empathy', 'ความเข้าใจผู้อื่น', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 4, 'Complete the Sentences 1', 'Fill with the correct word', '{"text": "That story was a ___. I stepped back to ___.", "blanks": [{"id": "blank1", "text": "trigger", "options": ["trigger", "overwhelm", "comfort", "detach"], "correctAnswer": "trigger"}, {"id": "blank2", "text": "detach", "options": ["detach", "comfort", "empathy", "trigger"], "correctAnswer": "detach"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 5, 'Complete the Sentences 2', 'Fill with the correct word', '{"text": "A call from a friend gave me ___. Too many stories caused ___.", "blanks": [{"id": "blank1", "text": "comfort", "options": ["comfort", "detach", "trigger", "empathy"], "correctAnswer": "comfort"}, {"id": "blank2", "text": "overwhelm", "options": ["overwhelm", "empathy", "comfort", "trigger"], "correctAnswer": "overwhelm"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_explanation', 6, 'Reason & Result (such…that)', 'Link media intensity to effects', '{"rules": "Use such + (a/an) + adj + noun + that for strong cause→result; use so + adj/adv + that similarly.\\n- It was such intense content that I stopped.\\n- The clip was so comforting that I relaxed.", "examples": ["The news was so heavy that I took a break.", "It was such a loud debate that I muted it.", "The story was so moving that it raised empathy.", "It was such a long thread that I felt overwhelm.", "The music was so calm that I felt comfort."]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 7, 'Build Sentences 1', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'The news was so heavy that I took a break', 'The news was so heavy that I took a break.', '["The", "news", "was", "so", "heavy", "that", "I", "took", "a", "break."]'::jsonb),
    (activity_id_var, 'It was such a long thread that I felt overwhelm', 'It was such a long thread that I felt overwhelm.', '["It", "was", "such", "a", "long", "thread", "that", "I", "felt", "overwhelm."]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 8, 'Build Sentences 2', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'The clip was so comforting that I relaxed', 'The clip was so comforting that I relaxed.', '["The", "clip", "was", "so", "comforting", "that", "I", "relaxed."]'::jsonb),
    (activity_id_var, 'The story was so moving that it raised empathy', 'The story was so moving that it raised empathy.', '["The", "story", "was", "so", "moving", "that", "it", "raised", "empathy."]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'speaking_practice', 9, 'Talk About Media & Feelings', 'Practice cause/effect', '{"prompts": ["What content was so intense you stopped?", "What helps you reset fast?", "When does media raise empathy for you?"]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (
      lesson_id,
      activity_type,
      activity_order,
      title,
      description,
      content
    ) VALUES (
      'B2-L63',
      'speaking_improvement',
      10,
      'Speaking Improvement',
      'Read the improved version of your speech',
      '{"type": "speaking_improvement", "similarityThreshold": 70}'::jsonb
    );
END $$;


