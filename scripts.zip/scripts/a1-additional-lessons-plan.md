# A1 Additional Lessons Plan (L11-L100) — Beginner, Very Simple English

## Requirements & Guidelines
- **Beginner language**: Short sentences, core vocab only; avoid abstractions.
- **No ambiguity**: One correct fill-blank answer (lesson vocab only); 3 simple distractors.
- **Grammar sentences**: Natural, short; add "?" on questions; commas before clauses; no contractions.
- **Speaking**: Friendly, personal, student life; no adult themes; keep questions 5–8 words.
- **Speaking improvement**: Include `speaking_improvement` activity with `similarityThreshold: 70`.
- **Topics spread**: Use provided 90 topics in order; keep variety across daily life/school/home.
- **Grammar spread**: Cycle A1 grammar; repeat for spaced review.

## CEFR A1 Grammar Coverage (from `cefr-grammar-requirements.md`)
- Be verbs (am/is/are) statements/questions/short answers
- Subject/object/possessive pronouns; my/your/his/her
- A / an / the; singular/plural nouns
- There is / There are (places/objects)
- This/That/These/Those
- Have got / have
- Present Simple (affirmative; basic questions with do/does only when needed)
- Imperatives (classroom/requests/directions)
- Like / don’t like (preferences)
- Can (ability/permission/simple requests)
- Basic prepositions of place/time (in/on/under/next to/at)
- Basic adjectives (colors/size) + noun order
- Numbers, time words (today/yesterday/tomorrow), days, months

### Planned Review Emphasis
- Be verbs & pronouns: 12
- There is/are + place: 8
- This/that/these/those: 6
- A/an/the; plurals: 8
- Present simple (habits/likes): 12
- Imperatives (classroom/requests): 8
- Can (ability/requests): 8
- Prepositions place/time: 10
- Like/don’t like: 8
- Colors/size adjectives: 6
- Numbers/time expressions: 6

## Lesson Plan (topics in given order; grammar spaced)
Format per lesson:
- Topic + brief theme
- Grammar focus (+review #)
- Vocab sample (5 items)
- Speaking prompts (3 short, personal)

### L11-L20
- **A1-L11 Classroom Objects** — This/That (near/far) #1; vocab: pen, pencil, book, desk, chair; speaking: “Is this your pen?”, “What is that?”, “Where is your book?”
- **A1-L12 Weather & Seasons** — Be + weather words #1; vocab: sunny, rainy, hot, cold, season; speaking: “How is the weather?”, “Do you like rain?”, “What season do you like?”
- **A1-L13 Clothes** — Plurals + a/an #1; vocab: shirt, pants, hat, shoes, jacket; speaking: “What do you wear?”, “Do you like hats?”, “Are your shoes new?”
- **A1-L14 Numbers 1–100** — Numbers + be #1; vocab: ten, twenty, thirty, forty, hundred; speaking: “How old are you?”, “What is your favorite number?”, “How many books do you have?”
- **A1-L15 Family & Friends** — Possessive adjectives #1; vocab: mother, father, sister, brother, friend; speaking: “Who is in your family?”, “Is he your brother?”, “Do you have sisters?”
- **A1-L16 Food You Like** — Like/don’t like #1; vocab: rice, chicken, soup, salad, bread; speaking: “Do you like rice?”, “What food do you like?”, “Do you cook?”
- **A1-L17 Countries & Nationalities** — Be + from #1; vocab: country, city, from, Thai, Korean; speaking: “Where are you from?”, “Are you Thai?”, “Is your friend Korean?”
- **A1-L18 Your Bedroom** — There is/are #1; vocab: bed, lamp, closet, window, door; speaking: “Is there a lamp?”, “How many windows?”, “Do you have a big bed?”
- **A1-L19 Saying Hello and Goodbye** — Greetings + be #2; vocab: hello, goodbye, morning, afternoon, night; speaking: “How do you say hello?”, “Do you wave goodbye?”, “Are you free now?”
- **A1-L20 Transport (car, bus, train)** — Can for ability #1; vocab: car, bus, train, ticket, driver; speaking: “Do you take the bus?”, “Can you drive?”, “Do you like trains?”

### L21-L30
- **A1-L21 Colors** — Adjectives + noun order #1; vocab: red, blue, green, black, white; speaking: “What is your favorite color?”, “Is your bag blue?”, “Do you like red shoes?”
- **A1-L22 Daily Routines** — Present Simple (I/you) #1; vocab: wake, eat, go, study, sleep; speaking: “When do you wake up?”, “Do you study at night?”, “Do you sleep early?”
- **A1-L23 Animals** — Plurals + be #2; vocab: cat, dog, bird, fish, rabbit; speaking: “Do you have a pet?”, “Is the cat small?”, “Do you like dogs?”
- **A1-L24 Asking Simple Questions** — Be questions #3; vocab: what, where, who, name, yes; speaking: “What is your name?”, “Where are you?”, “Who is he?”
- **A1-L25 Places in Town** — There is/are #2; vocab: park, school, bank, shop, street; speaking: “Is there a park?”, “Where is the bank?”, “Do you go to the shop?”
- **A1-L26 Fruits** — A/an + plurals #3; vocab: apple, banana, orange, mango, grape; speaking: “Do you like apples?”, “How many bananas?”, “Is mango sweet?”
- **A1-L27 Jobs (basic)** — Be + job #2; vocab: teacher, doctor, student, driver, worker; speaking: “Are you a student?”, “Is he a driver?”, “What job do you like?”
- **A1-L28 Telling the Time (basic)** — Be + time #1; vocab: o’clock, morning, afternoon, evening, now; speaking: “What time is it?”, “Is it 7 o’clock?”, “Do you wake up at 6?”
- **A1-L29 Personal Objects** — This/That + possession #2; vocab: phone, bag, keys, watch, wallet; speaking: “Is this your phone?”, “Where are your keys?”, “Is that your bag?”
- **A1-L30 Sports You Play** — Can for ability #2; vocab: soccer, run, swim, play, ball; speaking: “Can you swim?”, “Do you play soccer?”, “Do you run fast?”

### L31-L40
- **A1-L31 Months of the Year** — In + months #1; vocab: January, February, March, April, May; speaking: “When is your birthday?”, “Is it in May?”, “Do you like April?”
- **A1-L32 Home & Rooms** — There is/are #3; vocab: living room, kitchen, bathroom, bedroom, door; speaking: “Is there a kitchen?”, “How many rooms?”, “Is the door big?”
- **A1-L33 Teacher and Students** — Imperatives (classroom) #1; vocab: listen, read, write, sit, stand; speaking: “Do you listen in class?”, “Do you write notes?”, “Do you stand up?”
- **A1-L34 Shoes and Accessories** — Plurals + colors #4; vocab: shoes, socks, bag, belt, hat; speaking: “Are your shoes black?”, “Do you wear a belt?”, “Do you like hats?”
- **A1-L35 Zoo and Farm Animals** — Be + animals #3; vocab: elephant, cow, pig, tiger, monkey; speaking: “Do you like cows?”, “Is the tiger big?”, “What animal do you like?”
- **A1-L36 Prices (cheap / expensive)** — Be + adjectives #4; vocab: cheap, expensive, price, coin, money; speaking: “Is it cheap?”, “Is that expensive?”, “How much is it?”
- **A1-L37 Your Body** — Have/has got #1; vocab: head, hand, leg, eye, mouth; speaking: “Do you have big hands?”, “How many eyes?”, “Is your leg ok?”
- **A1-L38 Shopping for Clothes** — Can (requests) #3; vocab: size, try, buy, shirt, pay; speaking: “Can I try this?”, “Is this my size?”, “Can I pay now?”
- **A1-L39 Languages You Speak** — Can (ability) #4; vocab: English, Thai, speak, learn, easy; speaking: “Can you speak English?”, “Do you learn Thai?”, “Is English easy?”
- **A1-L40 Basic Directions** — Imperatives + place #2; vocab: go, turn, left, right, straight; speaking: “Go left or right?”, “Turn here?”, “Do I go straight?”

### L41-L50
- **A1-L41 Breakfast, Lunch, Dinner** — Present Simple (meals) #2; vocab: breakfast, lunch, dinner, eat, drink; speaking: “What do you eat?”, “Do you eat breakfast?”, “Do you drink milk?”
- **A1-L42 Furniture** — There is/are #4; vocab: table, chair, sofa, bed, shelf; speaking: “Is there a sofa?”, “How many chairs?”, “Do you like your bed?”
- **A1-L43 Likes and Dislikes** — Like/don’t like #2; vocab: like, love, hate, okay, favorite; speaking: “Do you like rice?”, “Do you hate rain?”, “What is your favorite?”
- **A1-L44 Days of the Week** — On + days #1; vocab: Monday, Tuesday, Wednesday, Thursday, Friday; speaking: “What day is today?”, “Do you study on Monday?”, “Is Friday fun?”
- **A1-L45 Going to School or Work** — Present Simple (routines) #3; vocab: bus, walk, late, early, bag; speaking: “Do you walk to school?”, “Are you late?”, “Do you carry a bag?”
- **A1-L46 Bathroom Objects** — This/That + there is #3; vocab: soap, towel, mirror, sink, toilet; speaking: “Is there a towel?”, “Is this the sink?”, “Where is the soap?”
- **A1-L47 Favorite Things** — Like/don’t like #3; vocab: toy, game, song, movie, book; speaking: “What toy do you like?”, “Do you like this song?”, “Is that book yours?”
- **A1-L48 Near and Far** — This/That/These/Those #3; vocab: near, far, here, there, close; speaking: “Is this near?”, “Is that far?”, “Do you sit here?”
- **A1-L49 Pets** — Have/has got #2; vocab: cat, dog, fish, bird, hamster; speaking: “Do you have a dog?”, “Is your pet small?”, “Do you feed your fish?”
- **A1-L50 Money (coins and notes)** — Numbers + price #2; vocab: coin, note, dollar, baht, pay; speaking: “How much is this?”, “Do you have coins?”, “Do you pay with cash?”

### L51-L60
- **A1-L51 Your House** — There is/are #5; vocab: house, floor, roof, garden, gate; speaking: “Is there a garden?”, “How many floors?”, “Is your gate big?”
- **A1-L52 Left and Right** — Imperatives (directions) #3; vocab: left, right, stop, turn, walk; speaking: “Turn left?”, “Do I stop here?”, “Walk right or left?”
- **A1-L53 Meat and Fish** — Count/uncount + a/some #1; vocab: chicken, beef, pork, fish, meat; speaking: “Do you eat fish?”, “Do you buy meat?”, “Do you like chicken?”
- **A1-L54 What You Are Wearing** — Be + wearing #1; vocab: wearing, shirt, pants, shoes, color; speaking: “What are you wearing?”, “Are your shoes white?”, “Is your shirt blue?”
- **A1-L55 Street Names** — Be + names #4; vocab: street, road, name, address, map; speaking: “What is the street name here?”, “Is this your address?”, “Do you have a map?”
- **A1-L56 Parts of the Face** — Have/has got #3; vocab: eyes, nose, mouth, ears, hair; speaking: “Do you have long hair?”, “Are your eyes brown?”, “Is your nose small?”
- **A1-L57 At the Supermarket** — Can (requests) #4; vocab: basket, bag, price, pay, line; speaking: “Can I have a bag?”, “Where do I pay?”, “Is this the line?”
- **A1-L58 Simple Games** — Imperatives (play) #4; vocab: play, card, ball, move, win; speaking: “Do you play cards?”, “Do I move here?”, “Do you like to win?”
- **A1-L59 Saying Hungry / Thirsty** — Be + feelings #5; vocab: hungry, thirsty, full, tired, okay; speaking: “Are you hungry?”, “Are you thirsty?”, “Are you tired now?”
    - **Note**: Keep feelings simple; avoid complex emotions.
- **A1-L60 Work Time (morning/afternoon)** — Time words + be #2; vocab: morning, afternoon, night, early, late; speaking: “Do you work in the morning?”, “Are you late?”, “Do you wake up early?”

### L61-L70
- **A1-L61 Kitchen Objects** — There is/are #6; vocab: spoon, fork, plate, cup, bowl; speaking: “Is there a spoon?”, “How many cups?”, “Do you use a bowl?”
- **A1-L62 Introducing Yourself** — Be + name/age #5; vocab: name, age, from, live, hello; speaking: “What is your name?”, “How old are you?”, “Where do you live?”
- **A1-L63 Maps (very basic)** — Imperatives + place #4; vocab: map, here, there, line, point; speaking: “Is this the right place?”, “Can you point to your home?”, “Do I go there?”
- **A1-L64 Drinks You Like** — Like/don’t like #4; vocab: water, juice, tea, coffee, milk; speaking: “Do you like juice?”, “Do you drink coffee?”, “Do you like milk?”
- **A1-L65 Cleaning and Tidying** — Imperatives (home) #5; vocab: clean, wash, sweep, tidy, trash; speaking: “Do you clean your room?”, “Do you wash dishes?”, “Do you take trash out?”
- **A1-L66 Feeling Tired / Sick / Well** — Be + feelings #6; vocab: tired, sick, well, fine, rest; speaking: “Are you tired?”, “Are you sick today?”, “Do you need rest?”
- **A1-L67 School Subjects** — Like/don’t like #5; vocab: math, English, art, music, sport; speaking: “Do you like math?”, “What subject do you like?”, “Do you like art?”
- **A1-L68 Traffic Lights** — Colors + imperatives #5; vocab: red, yellow, green, stop, go; speaking: “Red means stop?”, “Green means go?”, “Do you wait at red lights?”
- **A1-L69 Choosing Things** — Can (requests) #5; vocab: choose, want, need, this, that; speaking: “Can I choose this?”, “Do you want that?”, “Do you need this?”
- **A1-L70 Uniforms** — Be + clothes #5; vocab: uniform, shirt, skirt, pants, shoes; speaking: “Do you wear a uniform?”, “Is your shirt white?”, “Are your shoes black?”

### L71-L80
- **A1-L71 Personal Information** — Be + personal facts #6; vocab: name, phone, email, address, age; speaking: “What is your name?”, “How old are you?”, “Where do you live?”
- **A1-L72 Snacks** — Count/uncount + some #2; vocab: snack, chips, cookie, candy, fruit; speaking: “Do you like snacks?”, “Do you want some chips?”, “Do you eat fruit?”
- **A1-L73 Asking Where Something Is** — Where + be #4; vocab: where, is, here, there, near; speaking: “Where is the bag?”, “Is it here?”, “Is it near?”
- **A1-L74 Simple Preferences** — Like/don’t like #6; vocab: like, prefer, love, hate, okay; speaking: “Do you like tea or coffee?”, “Do you prefer rice?”, “Do you hate rain?”
- **A1-L75 Visiting a Doctor (very basic)** — Can (requests) #6; vocab: doctor, medicine, pain, head, arm; speaking: “Can you help me?”, “Where is the pain?”, “Do I need medicine?”
- **A1-L76 Work or Study** — Present Simple #4; vocab: work, study, job, school, busy; speaking: “Do you work?”, “Do you study?”, “Are you busy?”
- **A1-L77 Where Things Are (in/on/under)** — Prepositions place #6; vocab: in, on, under, next to, between; speaking: “Is it on the table?”, “Is it under the bed?”, “Is it next to you?”
- **A1-L78 Favorite Colors** — Colors + like #5; vocab: pink, purple, orange, brown, gray; speaking: “Do you like pink?”, “Is your bag orange?”, “What color do you like?”
- **A1-L79 Buying Tickets** — Can (requests) #7; vocab: ticket, bus, train, pay, seat; speaking: “Can I buy a ticket?”, “Is this seat free?”, “Do you take the bus?”
- **A1-L80 Simple Work Tools** — This/That + nouns #4; vocab: pen, paper, box, key, card; speaking: “Is this your pen?”, “Is that your key?”, “Do you need this card?”

### L81-L90
- **A1-L81 Sizes (big, small, long, short)** — Adjectives size #2; vocab: big, small, long, short, tall; speaking: “Is it big?”, “Is your bag small?”, “Are you tall?”
- **A1-L82 Vegetables** — Plurals + some #3; vocab: carrot, tomato, onion, potato, corn; speaking: “Do you like carrots?”, “Do you buy onions?”, “Is corn sweet?”
- **A1-L83 People at Work** — Be + jobs #3; vocab: chef, nurse, guard, clerk, farmer; speaking: “Is he a chef?”, “Is she a nurse?”, “Do you know a farmer?”
- **A1-L84 Crossing the Street** — Imperatives safety #6; vocab: cross, stop, look, left, right; speaking: “Do you look left?”, “Do you stop first?”, “Do you cross now?”
- **A1-L85 Hobbies & Free Time** — Like/don’t like #7; vocab: read, draw, sing, dance, play; speaking: “Do you like to read?”, “Do you dance?”, “Do you play games?”
- **A1-L86 Ordering Simple Food** — Can (requests) #8; vocab: menu, order, water, rice, pay; speaking: “Can I order rice?”, “Can I have water?”, “Where do I pay?”
- **A1-L87 Tidy Your Room** — Imperatives home #6; vocab: tidy, clean, pick, fold, trash; speaking: “Do you tidy your room?”, “Do you fold clothes?”, “Do you take trash out?”
- **A1-L88 Dream Job (simple)** — Be + job #4; vocab: job, dream, want, like, work; speaking: “What job do you want?”, “Do you like this job?”, “Is that your dream?”
- **A1-L89 Please, Thank You, Sorry** — Polite phrases #1; vocab: please, thank you, sorry, excuse me, welcome; speaking: “Do you say please?”, “Do you say thank you?”, “Do you say sorry?”
- **A1-L90 Describing Objects (basic)** — Adjectives + noun #3; vocab: big, small, red, old, new; speaking: “Is the bag red?”, “Is the phone new?”, “Is the box big?”

### L91-L100
- **A1-L91 Time Words (today / yesterday / tomorrow)** — Time + was/is #1; vocab: today, yesterday, tomorrow, now, later; speaking: “Is your test today?”, “Was it yesterday?”, “Is it tomorrow?”
- **A1-L92 Going Out in Bad Weather** — Can/should (simple) #1; vocab: rain, coat, umbrella, stay, go; speaking: “Do you take a coat?”, “Do you stay home?”, “Do you bring an umbrella?”
- **A1-L93 Carrying a Bag** — Can + objects #9; vocab: carry, bag, heavy, light, hold; speaking: “Is your bag heavy?”, “Can you carry it?”, “Do you hold it tight?”
- **A1-L94 What People Do at Work** — Present Simple #5; vocab: make, sell, help, build, fix; speaking: “Do you help people?”, “Do you build things?”, “Do you fix phones?”
- **A1-L95 Basic Health Problems** — Have got + symptoms #4; vocab: fever, cold, cough, hurt, pain; speaking: “Do you have a fever?”, “Does your head hurt?”, “Do you have a cold?”
- **A1-L96 Favorite Animals** — Like/don’t like #8; vocab: lion, panda, dolphin, bird, cat; speaking: “What animal do you like?”, “Do you like lions?”, “Do you like cats?”
- **A1-L97 Buying Food** — Can (requests) #9; vocab: buy, food, bag, kilo, price; speaking: “Can I buy this?”, “What is the price?”, “Can I get a bag?”
- **A1-L98 Saying Yes / No** — Yes/No + be/can #1; vocab: yes, no, sure, maybe, okay; speaking: “Do you say yes?”, “Do you say no?”, “Are you sure?”
- **A1-L99 Places of Work** — There is/are #7; vocab: office, shop, school, farm, hospital; speaking: “Is there an office?”, “Do you work at a shop?”, “Is the school near?”
- **A1-L100 Free Time Activities** — Present Simple #6; vocab: watch TV, walk, cook, read, play; speaking: “Do you watch TV?”, “Do you walk after school?”, “Do you cook?”

---

## Coverage Checkpoint (planned)
- Be verbs/pronouns: L11,17,19,21,24,27,28,31,36,44,54,55,59,62,66,71,89,91
- There is/are: L18,25,32,42,51,61,77,99,100
- This/That/These/Those: L11,29,48,80
- A/an/the; plurals: L13,23,26,34,36,53,82,90
- Present Simple (habits/likes): L22,41,45,47,60,76,85,94,96,100
- Imperatives (classroom/home/directions): L33,38,40,52,58,65,68,84,87
- Can (ability/requests): L20,30,38,39,57,69,75,79,86,93,97
- Like/Don’t like: L16,21,33,43,47,64,67,74,78,85,96
- Prepositions place/time: L18,25,31,40,46,52,63,77,91
- Colors/size adjectives: L21,34,36,81,90
- Numbers/time expressions: L14,31,41,44,50,59,71,91

