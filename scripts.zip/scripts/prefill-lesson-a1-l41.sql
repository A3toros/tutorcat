-- =========================================
-- Pre-fill Database with Sample Lesson Data
-- A1-L41: Breakfast, Lunch, Dinner
-- =========================================

DELETE FROM grammar_sentences WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'A1-L41');
DELETE FROM vocabulary_items WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'A1-L41');
DELETE FROM lesson_activities WHERE lesson_id = 'A1-L41';
DELETE FROM lessons WHERE id = 'A1-L41';

INSERT INTO lessons (id, level, lesson_number, topic) VALUES
('A1-L41', 'A1', 41, 'Breakfast, Lunch, Dinner')
ON CONFLICT (id) DO UPDATE SET topic = EXCLUDED.topic;

DO $$
DECLARE
    lesson_id_var TEXT := 'A1-L41';
    activity_id_var UUID;
BEGIN
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'warm_up_speaking', 1, 'Meals', 'Talk about meals', '{"prompt": "What do you eat for breakfast?"}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_intro', 2, 'Meal Words', 'Learn meal words', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'breakfast', 'อาหารเช้า', NULL),
    (activity_id_var, 'lunch', 'อาหารกลางวัน', NULL),
    (activity_id_var, 'dinner', 'อาหารเย็น', NULL),
    (activity_id_var, 'eat', 'กิน', NULL),
    (activity_id_var, 'drink', 'ดื่ม', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_matching_drag', 3, 'Match Meal Words', 'Match meal words', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'breakfast', 'อาหารเช้า', NULL),
    (activity_id_var, 'lunch', 'อาหารกลางวัน', NULL),
    (activity_id_var, 'dinner', 'อาหารเย็น', NULL),
    (activity_id_var, 'eat', 'กิน', NULL),
    (activity_id_var, 'drink', 'ดื่ม', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 4, 'Complete the Sentences 1', 'Fill with the correct word', '{"text": "I eat ___. I drink ___.", "blanks": [{"id": "blank1", "text": "breakfast", "options": ["breakfast", "lunch", "dinner", "water"], "correctAnswer": "breakfast"}, {"id": "blank2", "text": "water", "options": ["water", "dinner", "lunch", "breakfast"], "correctAnswer": "water"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 5, 'Complete the Sentences 2', 'Fill with the correct word', '{"text": "We eat ___. We eat ___.", "blanks": [{"id": "blank1", "text": "lunch", "options": ["lunch", "dinner", "breakfast", "eat"], "correctAnswer": "lunch"}, {"id": "blank2", "text": "dinner", "options": ["dinner", "lunch", "breakfast", "drink"], "correctAnswer": "dinner"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_explanation', 6, 'Present Simple (meals)', 'Talk about meal habits', '{"rules": "Use present simple for daily meals.\n- I eat breakfast at seven.\n- We eat dinner at six.\nAsk: Do you eat breakfast?", "examples": ["I eat breakfast at seven.", "We eat lunch at noon.", "They eat dinner at six.", "Do you eat breakfast?", "Do you drink juice in the morning?"]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 7, 'Build Sentences 1', 'Arrange words', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'I eat breakfast at seven', 'I eat breakfast at seven.', '["I", "eat", "breakfast", "at", "seven."]'::jsonb),
    (activity_id_var, 'We eat dinner at six', 'We eat dinner at six.', '["We", "eat", "dinner", "at", "six."]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 8, 'Build Sentences 2', 'Arrange words', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'Do you eat breakfast', 'Do you eat breakfast?', '["Do", "you", "eat", "breakfast?"]'::jsonb),
    (activity_id_var, 'Do you drink juice in the morning', 'Do you drink juice in the morning?', '["Do", "you", "drink", "juice", "in", "the", "morning?"]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'speaking_practice', 9, 'Talk About Meals', 'Practice meal routines', '{"prompts": ["What do you eat for breakfast?", "Do you eat breakfast?", "Do you drink juice in the morning?", "Do you eat lunch at school?", "Do you eat dinner early?"]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (
      lesson_id,
      activity_type,
      activity_order,
      title,
      description,
      content
    ) VALUES (
      'A1-L41',
      'speaking_improvement',
      10,
      'Speaking Improvement',
      'Read the improved version of your speech',
      '{"type": "speaking_improvement", "similarityThreshold": 70}'::jsonb
    );
END $$;

