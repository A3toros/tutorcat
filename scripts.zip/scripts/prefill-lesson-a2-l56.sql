-- =========================================
-- Pre-fill Database with Sample Lesson Data
-- A2-L56: Using Apps
-- =========================================

DELETE FROM grammar_sentences WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'A2-L56');
DELETE FROM vocabulary_items WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'A2-L56');
DELETE FROM lesson_activities WHERE lesson_id = 'A2-L56';
DELETE FROM lessons WHERE id = 'A2-L56';

INSERT INTO lessons (id, level, lesson_number, topic) VALUES
('A2-L56', 'A2', 56, 'Using Apps')
ON CONFLICT (id) DO UPDATE SET topic = EXCLUDED.topic;

DO $$
DECLARE
    lesson_id_var TEXT := 'A2-L56';
    activity_id_var UUID;
BEGIN
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'warm_up_speaking', 1, 'App Help', 'Talk about using apps', '{"prompt": "Can you solve simple problems with apps?"}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_intro', 2, 'App Words', 'Learn app vocabulary', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'app', 'แอป', NULL),
    (activity_id_var, 'login', 'เข้าสู่ระบบ', NULL),
    (activity_id_var, 'password', 'รหัสผ่าน', NULL),
    (activity_id_var, 'update', 'อัปเดต', NULL),
    (activity_id_var, 'bug', 'บั๊ก/ข้อผิดพลาด', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_matching_drag', 3, 'Match App Words', 'Match app words', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'app', 'แอป', NULL),
    (activity_id_var, 'login', 'เข้าสู่ระบบ', NULL),
    (activity_id_var, 'password', 'รหัสผ่าน', NULL),
    (activity_id_var, 'update', 'อัปเดต', NULL),
    (activity_id_var, 'bug', 'บั๊ก/ข้อผิดพลาด', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 4, 'Complete the Sentences 1', 'Fill with the correct word', '{"text": "Open the ___. Can you ___? Enter your ___.", "blanks": [{"id": "blank1", "text": "app", "options": ["app", "login", "password", "bug"], "correctAnswer": "app"}, {"id": "blank2", "text": "login", "options": ["login", "password", "update", "app"], "correctAnswer": "login"}, {"id": "blank3", "text": "password", "options": ["password", "bug", "update", "login"], "correctAnswer": "password"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 5, 'Complete the Sentences 2', 'Fill with the correct word', '{"text": "There is a ___. Please ___ the app.", "blanks": [{"id": "blank1", "text": "bug", "options": ["bug", "update", "login", "app"], "correctAnswer": "bug"}, {"id": "blank2", "text": "update", "options": ["update", "bug", "password", "app"], "correctAnswer": "update"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_explanation', 6, 'Can (ability)', 'Talk about what you can do with apps', '{"rules": "Use can to talk about ability.\n- I can update the app.\n- She can fix a bug.\nQuestions: Can you log in?\nShort: Yes, I can. / No, I can''t.", "examples": ["I can update the app today.", "She can fix simple bugs.", "Can you log in now?", "We can reset the password.", "He can report the problem."]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 7, 'Build Sentences 1', 'Arrange words', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'I can update the app today', 'I can update the app today.', '["I", "can", "update", "the", "app", "today."]'::jsonb),
    (activity_id_var, 'Can you log in now', 'Can you log in now?', '["Can", "you", "log", "in", "now?"]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 8, 'Build Sentences 2', 'Arrange words', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'We can reset the password', 'We can reset the password.', '["We", "can", "reset", "the", "password."]'::jsonb),
    (activity_id_var, 'He can report the problem', 'He can report the problem.', '["He", "can", "report", "the", "problem."]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'speaking_practice', 9, 'Talk About Apps', 'Practice app troubleshooting', '{"prompts": ["Can you solve simple problems with apps?", "Can you remember many passwords?", "What app can you not live without?", "Can you use apps to manage your day?", "What new app would you like to learn to use?"]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (
      lesson_id,
      activity_type,
      activity_order,
      title,
      description,
      content
    ) VALUES (
      'A2-L56',
      'speaking_improvement',
      10,
      'Speaking Improvement',
      'Read the improved version of your speech',
      '{"type": "speaking_improvement", "similarityThreshold": 70}'::jsonb
    );
END $$;

