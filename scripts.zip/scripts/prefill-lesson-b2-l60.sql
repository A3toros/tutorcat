-- ===== LESSON B2-L60 =====

-- =========================================
-- Pre-fill Database with Sample Lesson Data
-- B2-L60: Personal responsibility
-- =========================================

DELETE FROM lesson_activity_results WHERE lesson_id = 'B2-L60';
DELETE FROM user_progress WHERE lesson_id = 'B2-L60';
DELETE FROM lesson_history WHERE lesson_id = 'B2-L60';
DELETE FROM grammar_sentences WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'B2-L60');
DELETE FROM vocabulary_items WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'B2-L60');
DELETE FROM lesson_activities WHERE lesson_id = 'B2-L60';
DELETE FROM lessons WHERE id = 'B2-L60';

INSERT INTO lessons (id, level, lesson_number, topic) VALUES
('B2-L60', 'B2', 60, 'Personal responsibility')
ON CONFLICT (id) DO UPDATE SET topic = EXCLUDED.topic;

DO $$
DECLARE
    lesson_id_var TEXT := 'B2-L60';
    activity_id_var UUID;
BEGIN
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'warm_up_speaking', 1, 'Personal Responsibility', 'Talk about being responsible', '{"prompt": "What tasks do you do at home?"}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_intro', 2, 'Responsibility Words', 'Learn words related to personal accountability', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'accountable', 'รับผิดชอบ', NULL),
    (activity_id_var, 'duty', 'หน้าที่', NULL),
    (activity_id_var, 'consequence', 'ผลที่ตามมา', NULL),
    (activity_id_var, 'uphold', 'รักษา', NULL),
    (activity_id_var, 'neglect', 'ละเลย', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_matching_drag', 3, 'Match Responsibility Words', 'Match words related to accountability', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'accountable', 'รับผิดชอบ', NULL),
    (activity_id_var, 'duty', 'หน้าที่', NULL),
    (activity_id_var, 'consequence', 'ผลที่ตามมา', NULL),
    (activity_id_var, 'uphold', 'รักษา', NULL),
    (activity_id_var, 'neglect', 'ละเลย', NULL);

    -- 4. Vocabulary Fill Blanks #1
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 4, 'Complete the Sentences 1', 'Fill in the blanks with correct words', '{"text": "I am ___ for my actions. It is my ___. There are ___.", "blanks": [{"id": "blank1", "text": "accountable", "options": ["accountable", "duty", "consequence", "uphold"], "correctAnswer": "accountable"}, {"id": "blank2", "text": "duty", "options": ["duty", "accountable", "consequence", "neglect"], "correctAnswer": "duty"}, {"id": "blank3", "text": "consequences", "options": ["consequences", "accountable", "duty", "uphold"], "correctAnswer": "consequences"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    -- 5. Vocabulary Fill Blanks #2
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 5, 'Complete the Sentences 2', 'Fill in the blanks with correct words', '{"text": "We must ___ our standards. Do not ___ your duties. I will ___ my responsibilities.", "blanks": [{"id": "blank1", "text": "uphold", "options": ["uphold", "accountable", "duty", "neglect"], "correctAnswer": "uphold"}, {"id": "blank2", "text": "neglect", "options": ["neglect", "accountable", "duty", "uphold"], "correctAnswer": "neglect"}, {"id": "blank3", "text": "uphold", "options": ["uphold", "neglect", "accountable", "duty"], "correctAnswer": "uphold"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    -- 6. Grammar Explanation
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_explanation', 6, 'Passive with Modals', 'Learn passive voice with modal verbs', '{"rules": "Use passive voice with modal verbs to show obligation or possibility:\n\n- Form: modal + be + past participle (must be made, should be shared)\n- Use when the action is more important than who does it\n- Modal + be + past participle (must be, should be, can be)\n- Use by to show who does the action (by you, by everyone)\n- Common modals: must, should, can, might, could", "examples": ["The decision must be made by you.", "Responsibilities should be shared equally.", "Standards must be upheld by everyone.", "Tasks can be completed together.", "Rules should be followed by all."]}'::jsonb)
    RETURNING id INTO activity_id_var;

    -- 7. Grammar Sentences #1
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 7, 'Build Sentences 1', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'The decision must be made by you', 'The decision must be made by you.', '["The", "decision", "must", "be", "made", "by", "you."]'::jsonb),
    (activity_id_var, 'Responsibilities should be shared equally', 'Responsibilities should be shared equally.', '["Responsibilities", "should", "be", "shared", "equally."]'::jsonb);

    -- 8. Grammar Sentences #2
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 8, 'Build Sentences 2', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'Standards must be upheld by everyone', 'Standards must be upheld by everyone.', '["Standards", "must", "be", "upheld", "by", "everyone."]'::jsonb),
    (activity_id_var, 'Tasks can be completed together', 'Tasks can be completed together.', '["Tasks", "can", "be", "completed", "together."]'::jsonb);

    -- 9. Speaking Practice
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'speaking_practice', 9, 'Talk About Responsibility', 'Practice talking about being responsible', '{"prompts": ["What chores do you do?", "Who helps with family tasks?", "How do you help others?", "What are your duties at home?", "How do you uphold your responsibilities?"]}'::jsonb)
    RETURNING id INTO activity_id_var;

    -- 10. Speaking Improvement
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'speaking_improvement', 10, 'Speaking Improvement', 'Read the improved version of your speech', '{"type": "speaking_improvement", "similarityThreshold": 70}'::jsonb)
    RETURNING id INTO activity_id_var;
END $$;