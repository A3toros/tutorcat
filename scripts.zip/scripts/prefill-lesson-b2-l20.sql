-- =========================================
-- Pre-fill Database with Sample Lesson Data
-- B2-L20: Academic stress and burnout
-- =========================================

DELETE FROM grammar_sentences WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'B2-L20');
DELETE FROM vocabulary_items WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'B2-L20');
DELETE FROM lesson_activities WHERE lesson_id = 'B2-L20';
DELETE FROM lessons WHERE id = 'B2-L20';

INSERT INTO lessons (id, level, lesson_number, topic) VALUES
('B2-L20', 'B2', 20, 'Academic stress and burnout')
ON CONFLICT (id) DO UPDATE SET topic = EXCLUDED.topic;

DO $$
DECLARE
    lesson_id_var TEXT := 'B2-L20';
    activity_id_var UUID;
BEGIN
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'warm_up_speaking', 1, 'Stress Check', 'Talk about pressure and support', '{"prompt": "How long have you managed stress this way, and who checks in on you?"}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_intro', 2, 'Stress Words', 'Key words for pressure and recovery', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'overwhelm', 'ความรู้สึกล้น/ท่วมท้น', NULL),
    (activity_id_var, 'pace', 'จังหวะ/ความเร็ว', NULL),
    (activity_id_var, 'recover', 'ฟื้นตัว', NULL),
    (activity_id_var, 'boundary', 'ขอบเขต', NULL),
    (activity_id_var, 'support', 'การสนับสนุน', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_matching_drag', 3, 'Match Stress Words', 'Match words with meanings', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'overwhelm', 'ความรู้สึกล้น/ท่วมท้น', NULL),
    (activity_id_var, 'pace', 'จังหวะ/ความเร็ว', NULL),
    (activity_id_var, 'recover', 'ฟื้นตัว', NULL),
    (activity_id_var, 'boundary', 'ขอบเขต', NULL),
    (activity_id_var, 'support', 'การสนับสนุน', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 4, 'Complete the Sentences 1', 'Fill with the correct word', '{"text": "The ___ of exams can cause ___. I set a study ___ each night.", "blanks": [{"id": "blank1", "text": "pace", "options": ["pace", "overwhelm", "recover", "support"], "correctAnswer": "pace"}, {"id": "blank2", "text": "overwhelm", "options": ["overwhelm", "support", "recover", "boundary"], "correctAnswer": "overwhelm"}, {"id": "blank3", "text": "boundary", "options": ["boundary", "support", "pace", "recover"], "correctAnswer": "boundary"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 5, 'Complete the Sentences 2', 'Fill with the correct word', '{"text": "Breaks help me ___. Friends give me ___.", "blanks": [{"id": "blank1", "text": "recover", "options": ["recover", "support", "boundary", "pace"], "correctAnswer": "recover"}, {"id": "blank2", "text": "support", "options": ["support", "recover", "overwhelm", "pace"], "correctAnswer": "support"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_explanation', 6, 'Present Perfect Continuous', 'Show ongoing stress management', '{"rules": "Use have/has + been + -ing to show actions started in the past and still continuing, often with for/since.\\n- I have been managing stress with breaks.\\n- She has been setting boundaries since midterm.", "examples": ["I have been pacing my study hours carefully.", "She has been setting boundaries since last term.", "They have been taking short walks during breaks.", "We have been checking in on each other for weeks.", "He has been recovering by sleeping earlier."]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 7, 'Build Sentences 1', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'I have been pacing my study hours carefully', 'I have been pacing my study hours carefully.', '["I", "have", "been", "pacing", "my", "study", "hours", "carefully."]'::jsonb),
    (activity_id_var, 'She has been setting boundaries since last term', 'She has been setting boundaries since last term.', '["She", "has", "been", "setting", "boundaries", "since", "last", "term."]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 8, 'Build Sentences 2', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'They have been taking short walks during breaks', 'They have been taking short walks during breaks.', '["They", "have", "been", "taking", "short", "walks", "during", "breaks."]'::jsonb),
    (activity_id_var, 'He has been recovering by sleeping earlier', 'He has been recovering by sleeping earlier.', '["He", "has", "been", "recovering", "by", "sleeping", "earlier."]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'speaking_practice', 9, 'Talk About Stress Management', 'Practice present perfect continuous', '{"prompts": ["How long have you managed stress this way?", "Who checks in on you when work piles up?", "What will you change about your pace next month?"]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (
      lesson_id,
      activity_type,
      activity_order,
      title,
      description,
      content
    ) VALUES (
      'B2-L20',
      'speaking_improvement',
      10,
      'Speaking Improvement',
      'Read the improved version of your speech',
      '{"type": "speaking_improvement", "similarityThreshold": 70}'::jsonb
    );
END $$;


