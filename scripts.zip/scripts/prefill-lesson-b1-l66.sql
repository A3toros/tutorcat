-- ===== LESSON B1-L66 =====

-- =========================================
-- Pre-fill Database with Sample Lesson Data
-- B1-L66: Travel Tips
-- =========================================

DELETE FROM lesson_activity_results WHERE lesson_id = 'B1-L66';
DELETE FROM user_progress WHERE lesson_id = 'B1-L66';
DELETE FROM lesson_history WHERE lesson_id = 'B1-L66';
DELETE FROM grammar_sentences WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'B1-L66');
DELETE FROM vocabulary_items WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'B1-L66');
DELETE FROM lesson_activities WHERE lesson_id = 'B1-L66';
DELETE FROM lessons WHERE id = 'B1-L66';

INSERT INTO lessons (id, level, lesson_number, topic) VALUES
('B1-L66', 'B1', 66, 'Travel Tips')
ON CONFLICT (id) DO UPDATE SET topic = EXCLUDED.topic;

DO $$
DECLARE
    lesson_id_var TEXT := 'B1-L66';
    activity_id_var UUID;
BEGIN
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'warm_up_speaking', 1, 'Travel Experiences', 'Talk about learning from travel experiences', '{"prompt": "What were you doing when a travel tip saved you?"}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_intro', 2, 'Travel Advice Words', 'Learn words related to travel tips', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'pack', 'แพ็ค', NULL),
    (activity_id_var, 'navigate', 'นำทาง', NULL),
    (activity_id_var, 'bargain', 'ต่อราคา', NULL),
    (activity_id_var, 'warn', 'เตือน', NULL),
    (activity_id_var, 'avoid', 'หลีกเลี่ยง', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_matching_drag', 3, 'Match Travel Words', 'Match travel advice words', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'pack', 'แพ็ค', NULL),
    (activity_id_var, 'navigate', 'นำทาง', NULL),
    (activity_id_var, 'bargain', 'ต่อราคา', NULL),
    (activity_id_var, 'warn', 'เตือน', NULL),
    (activity_id_var, 'avoid', 'หลีกเลี่ยง', NULL);

    -- 4. Vocabulary Fill Blanks #1
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 4, 'Complete the Sentences 1', 'Fill in the blanks with correct words', '{"text": "I need to ___ my bags. She knows how to ___. We ___ for better prices.", "blanks": [{"id": "blank1", "text": "pack", "options": ["pack", "navigate", "bargain", "warn"], "correctAnswer": "pack"}, {"id": "blank2", "text": "navigate", "options": ["navigate", "pack", "bargain", "avoid"], "correctAnswer": "navigate"}, {"id": "blank3", "text": "bargain", "options": ["bargain", "pack", "navigate", "warn"], "correctAnswer": "bargain"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    -- 5. Vocabulary Fill Blanks #2
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 5, 'Complete the Sentences 2', 'Fill in the blanks with correct words', '{"text": "They ___ us about danger. I ___ crowded places. We ___ problems.", "blanks": [{"id": "blank1", "text": "warn", "options": ["warn", "pack", "navigate", "bargain"], "correctAnswer": "warn"}, {"id": "blank2", "text": "avoid", "options": ["avoid", "pack", "navigate", "warn"], "correctAnswer": "avoid"}, {"id": "blank3", "text": "avoid", "options": ["avoid", "warn", "pack", "navigate"], "correctAnswer": "avoid"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    -- 6. Grammar Explanation
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_explanation', 6, 'Past Continuous for Stories', 'Learn past continuous for background actions', '{"rules": "Use past continuous to describe background actions in stories:\n\n- Form: was/were + verb-ing (was packing, were bargaining)\n- Use when to show interruption (when I found, when GPS failed)\n- Past continuous = background action\n- Past simple = interrupting action\n- Use was for I/he/she/it, were for we/you/they", "examples": ["I was packing when I found my passport.", "She was navigating when the GPS failed.", "They were bargaining when the market closed.", "We were traveling when it started raining.", "He was exploring when he got lost."]}'::jsonb)
    RETURNING id INTO activity_id_var;

    -- 7. Grammar Sentences #1
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 7, 'Build Sentences 1', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'I was packing when I found my passport', 'I was packing when I found my passport.', '["I", "was", "packing", "when", "I", "found", "my", "passport."]'::jsonb),
    (activity_id_var, 'She was navigating when the GPS failed', 'She was navigating when the GPS failed.', '["She", "was", "navigating", "when", "the", "GPS", "failed."]'::jsonb);

    -- 8. Grammar Sentences #2
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 8, 'Build Sentences 2', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'They were bargaining when the market closed', 'They were bargaining when the market closed.', '["They", "were", "bargaining", "when", "the", "market", "closed."]'::jsonb),
    (activity_id_var, 'We were traveling when it started raining', 'We were traveling when it started raining.', '["We", "were", "traveling", "when", "it", "started", "raining."]'::jsonb);

    -- 9. Speaking Practice
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'speaking_practice', 9, 'Talk About Vacation', 'Practice talking about holidays and trips', '{"prompts": ["Where did you go last summer?", "Did you take pictures on your trip?", "What did you buy as a souvenir?", "What travel tips do you know?", "Have you ever gotten lost while traveling?"]}'::jsonb)
    RETURNING id INTO activity_id_var;

    -- 10. Speaking Improvement
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'speaking_improvement', 10, 'Speaking Improvement', 'Read the improved version of your speech', '{"type": "speaking_improvement", "similarityThreshold": 70}'::jsonb)
    RETURNING id INTO activity_id_var;
END $$;