-- =========================================
-- Pre-fill Database with Sample Lesson Data
-- C1-L35: Multicultural Education
-- =========================================
DELETE FROM lesson_activity_results WHERE lesson_id = 'C1-L35';
DELETE FROM user_progress WHERE lesson_id = 'C1-L35';
DELETE FROM lesson_history WHERE lesson_id = 'C1-L35';
DELETE FROM grammar_sentences WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'C1-L35');
DELETE FROM vocabulary_items WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'C1-L35');
DELETE FROM lesson_activities WHERE lesson_id = 'C1-L35';
DELETE FROM lessons WHERE id = 'C1-L35';

INSERT INTO lessons (id, level, lesson_number, topic) VALUES
('C1-L35', 'C1', 35, 'Multicultural Education')
ON CONFLICT (id) DO UPDATE SET topic = EXCLUDED.topic;

DO $$
DECLARE
    lesson_id_var TEXT := 'C1-L35';
    activity_id_var UUID;
BEGIN
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'warm_up_speaking', 1, 'Multicultural Education', 'Discuss multicultural education', '{"prompt": "What makes classrooms inclusive?"}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_intro', 2, 'Multicultural Education Vocabulary', 'Learn vocabulary about multicultural education', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'inclusion', 'การรวมเข้า', NULL),
    (activity_id_var, 'diversity', 'ความหลากหลาย', NULL),
    (activity_id_var, 'challenge', 'ความท้าทาย', NULL),
    (activity_id_var, 'support', 'การสนับสนุน', NULL),
    (activity_id_var, 'role', 'บทบาท', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_matching_drag', 3, 'Match Multicultural Education Words', 'Match English words with Thai meanings', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'inclusion', 'การรวมเข้า', NULL),
    (activity_id_var, 'diversity', 'ความหลากหลาย', NULL),
    (activity_id_var, 'challenge', 'ความท้าทาย', NULL),
    (activity_id_var, 'support', 'การสนับสนุน', NULL),
    (activity_id_var, 'role', 'บทบาท', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 4, 'Complete the Sentences 1', 'Fill with the correct word', '{"text": "Diverse classrooms promote ___. ___ arise in multicultural settings. ___ helps improve ___.", "blanks": [{"id": "blank1", "text": "inclusion", "options": ["inclusion", "diversity", "challenge", "support"], "correctAnswer": "inclusion"}, {"id": "blank2", "text": "Challenges", "options": ["Challenges", "Inclusion", "Diversity", "Support"], "correctAnswer": "Challenges"}, {"id": "blank3", "text": "Support", "options": ["Support", "Inclusion", "Diversity", "Challenge"], "correctAnswer": "Support"}, {"id": "blank4", "text": "inclusion", "options": ["inclusion", "diversity", "challenge", "support"], "correctAnswer": "inclusion"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 5, 'Complete the Sentences 2', 'Fill with the correct word', '{"text": "Teachers play a key ___. Students ___ each other. ___ benefits everyone.", "blanks": [{"id": "blank1", "text": "role", "options": ["role", "inclusion", "diversity", "support"], "correctAnswer": "role"}, {"id": "blank2", "text": "support", "options": ["support", "inclusion", "diversity", "role"], "correctAnswer": "support"}, {"id": "blank3", "text": "Diversity", "options": ["Diversity", "Inclusion", "Support", "Role"], "correctAnswer": "Diversity"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_explanation', 6, 'Cohesion and Ellipsis', 'Learn cohesion and ellipsis', '{"rules": "Cohesion and ellipsis:\n- Ellipsis: \"Diverse classrooms benefit students, and inclusive ones do too.\"\n- Substitution: \"Teachers support inclusion, and students do so as well.\"\n- Reference: \"Multicultural settings create challenges; these challenges require support.\"\n\nUse for:\n- Avoiding repetition: \"Teachers support inclusion, and students do too.\"\n- Creating flow: \"Diverse classrooms benefit everyone; such diversity enriches learning.\"\n- Connecting ideas: \"Challenges arise; these challenges need addressing.\"", "examples": ["Diverse classrooms benefit students, and inclusive ones do too.", "Teachers support inclusion, and students do so as well.", "Multicultural settings create challenges; these challenges require support.", "Inclusion improves learning; such inclusion benefits everyone.", "Students support each other; this support creates community."]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 7, 'Build Sentences 1', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'Diverse classrooms benefit students, and inclusive ones do too.', 'Diverse classrooms benefit students, and inclusive ones do too.', '["Diverse", "classrooms", "benefit", "students,", "and", "inclusive", "ones", "do", "too."]'::jsonb),
    (activity_id_var, 'Teachers support inclusion, and students do so as well.', 'Teachers support inclusion, and students do so as well.', '["Teachers", "support", "inclusion,", "and", "students", "do", "so", "as", "well."]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 8, 'Build Sentences 2', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'Multicultural settings create challenges; these challenges require support.', 'Multicultural settings create challenges; these challenges require support.', '["Multicultural", "settings", "create", "challenges;", "these", "challenges", "require", "support."]'::jsonb),
    (activity_id_var, 'Inclusion improves learning; such inclusion benefits everyone.', 'Inclusion improves learning; such inclusion benefits everyone.', '["Inclusion", "improves", "learning;", "such", "inclusion", "benefits", "everyone."]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'speaking_practice', 9, 'Discuss Multicultural Education', 'Practice speaking about multicultural education', '{"prompts": ["How do diverse classrooms benefit students?", "What challenges arise in multicultural settings?", "How can inclusion be improved?", "What role do teachers play?", "How do students support inclusion?"]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (
      lesson_id,
      activity_type,
      activity_order,
      title,
      description,
      content
    ) VALUES (
      'C1-L35',
      'speaking_improvement',
      10,
      'Speaking Improvement',
      'Read the improved version of your speech',
      '{"type": "speaking_improvement", "similarityThreshold": 70}'::jsonb
    );
END $$;
