#!/usr/bin/env python3
"""
Fix the DELETE order in all-lessons-combined.sql to handle foreign key constraints
"""

import re
from pathlib import Path

script_dir = Path(__file__).parent
sql_file = script_dir / 'all-lessons-combined.sql'

if not sql_file.exists():
    print(f"Error: {sql_file} not found")
    exit(1)

print(f"Reading {sql_file}...")
with open(sql_file, 'r', encoding='utf-8') as f:
    content = f.read()

# Pattern to match DELETE statements for a lesson
# We need to add DELETE for lesson_activity_results and user_progress before deleting lessons
pattern = r'(-- Clear existing sample data for ([A-Z0-9-]+) \(optional.*?\n)(DELETE FROM grammar_sentences WHERE activity_id IN \(SELECT id FROM lesson_activities WHERE lesson_id = \'([A-Z0-9-]+)\'\);\nDELETE FROM vocabulary_items WHERE activity_id IN \(SELECT id FROM lesson_activities WHERE lesson_id = \'([A-Z0-9-]+)\'\);\nDELETE FROM lesson_activities WHERE lesson_id = \'([A-Z0-9-]+)\';\nDELETE FROM lessons WHERE id = \'([A-Z0-9-]+)\';\n)'

def replace_delete_block(match):
    comment = match.group(1)
    lesson_id = match.group(4)  # All groups should be the same lesson_id
    
    # New DELETE order: delete dependent tables first
    new_deletes = f"""DELETE FROM lesson_activity_results WHERE lesson_id = '{lesson_id}';
DELETE FROM user_progress WHERE lesson_id = '{lesson_id}';
DELETE FROM grammar_sentences WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = '{lesson_id}');
DELETE FROM vocabulary_items WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = '{lesson_id}');
DELETE FROM lesson_activities WHERE lesson_id = '{lesson_id}';
DELETE FROM lessons WHERE id = '{lesson_id}';
"""
    
    return comment + new_deletes

# Replace all DELETE blocks
new_content = re.sub(pattern, replace_delete_block, content)

# Write back
output_file = script_dir / 'all-lessons-combined-fixed.sql'
with open(output_file, 'w', encoding='utf-8') as f:
    f.write(new_content)

print(f"✓ Fixed DELETE order")
print(f"✓ Created: {output_file}")
print(f"\nThe fixed file includes DELETE statements for:")
print(f"  1. lesson_activity_results (foreign key to lessons)")
print(f"  2. user_progress (foreign key to lessons)")
print(f"  3. grammar_sentences")
print(f"  4. vocabulary_items")
print(f"  5. lesson_activities")
print(f"  6. lessons")

