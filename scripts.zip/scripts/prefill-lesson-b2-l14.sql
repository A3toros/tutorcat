-- =========================================
-- Pre-fill Database with Sample Lesson Data
-- B2-L14: Technology in studying
-- =========================================

DELETE FROM grammar_sentences WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'B2-L14');
DELETE FROM vocabulary_items WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'B2-L14');
DELETE FROM lesson_activities WHERE lesson_id = 'B2-L14';
DELETE FROM lessons WHERE id = 'B2-L14';

INSERT INTO lessons (id, level, lesson_number, topic) VALUES
('B2-L14', 'B2', 14, 'Technology in studying')
ON CONFLICT (id) DO UPDATE SET topic = EXCLUDED.topic;

DO $$
DECLARE
    lesson_id_var TEXT := 'B2-L14';
    activity_id_var UUID;
BEGIN
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'warm_up_speaking', 1, 'Study Tech', 'Talk about tools', '{"prompt": "What tool is so helpful you rely on it, and when is tech too much?"}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_intro', 2, 'Study Tech Words', 'Key words for tech use', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'integrate', 'ผสาน/รวม', NULL),
    (activity_id_var, 'annotate', 'ใส่คำอธิบาย/ไฮไลท์', NULL),
    (activity_id_var, 'sync', 'ซิงค์', NULL),
    (activity_id_var, 'backup', 'สำรองข้อมูล', NULL),
    (activity_id_var, 'streamline', 'ทำให้ราบรื่น/ลดขั้นตอน', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_matching_drag', 3, 'Match Tech Words', 'Match words with meanings', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'integrate', 'ผสาน/รวม', NULL),
    (activity_id_var, 'annotate', 'ใส่คำอธิบาย/ไฮไลท์', NULL),
    (activity_id_var, 'sync', 'ซิงค์', NULL),
    (activity_id_var, 'backup', 'สำรองข้อมูล', NULL),
    (activity_id_var, 'streamline', 'ทำให้ราบรื่น/ลดขั้นตอน', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 4, 'Complete the Sentences 1', 'Fill with the correct word', '{"text": "I ___ notes across devices. I ___ PDFs for class. I always ___ my files.", "blanks": [{"id": "blank1", "text": "sync", "options": ["sync", "annotate", "backup", "integrate"], "correctAnswer": "sync"}, {"id": "blank2", "text": "annotate", "options": ["annotate", "streamline", "sync", "backup"], "correctAnswer": "annotate"}, {"id": "blank3", "text": "backup", "options": ["backup", "sync", "integrate", "streamline"], "correctAnswer": "backup"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 5, 'Complete the Sentences 2', 'Fill with the correct word', '{"text": "We ___ tools to cut steps. I ___ video and notes.", "blanks": [{"id": "blank1", "text": "streamline", "options": ["streamline", "integrate", "annotate", "backup"], "correctAnswer": "streamline"}, {"id": "blank2", "text": "integrate", "options": ["integrate", "streamline", "sync", "backup"], "correctAnswer": "integrate"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_explanation', 6, 'Reason & Result (so/such…that)', 'Explain effects of tech use', '{"rules": "Use so + adj/adv + that or such + (a/an) + noun + that to link cause and effect. Keep results specific.\\n- The app was so helpful that I used it daily.\\n- It was such a fast tool that my notes improved.", "examples": ["The tablet was so light that I carried it everywhere.", "It was such a smooth app that I stopped printing handouts.", "My backups were so frequent that I never lost work.", "It was such a distraction that I turned off alerts.", "My notes were so organized that studying felt easier."]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 7, 'Build Sentences 1', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'It was such a helpful app that I used it daily', 'It was such a helpful app that I used it daily.', '["It", "was", "such", "a", "helpful", "app", "that", "I", "used", "it", "daily."]'::jsonb),
    (activity_id_var, 'My notes were so organized that studying felt easier', 'My notes were so organized that studying felt easier.', '["My", "notes", "were", "so", "organized", "that", "studying", "felt", "easier."]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 8, 'Build Sentences 2', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'It was such a distraction that I turned off alerts', 'It was such a distraction that I turned off alerts.', '["It", "was", "such", "a", "distraction", "that", "I", "turned", "off", "alerts."]'::jsonb),
    (activity_id_var, 'The tablet was so light that I carried it everywhere', 'The tablet was so light that I carried it everywhere.', '["The", "tablet", "was", "so", "light", "that", "I", "carried", "it", "everywhere."]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'speaking_practice', 9, 'Talk About Study Tech', 'Practice cause/effect', '{"prompts": ["What tool is so helpful you rely on it daily?", "When is tech such a distraction you stop using it?", "How do you set limits with study apps?"]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (
      lesson_id,
      activity_type,
      activity_order,
      title,
      description,
      content
    ) VALUES (
      'B2-L14',
      'speaking_improvement',
      10,
      'Speaking Improvement',
      'Read the improved version of your speech',
      '{"type": "speaking_improvement", "similarityThreshold": 70}'::jsonb
    );
END $$;


