-- =========================================
-- Pre-fill Database with Sample Lesson Data
-- A2-L10: Describing People & Objects
-- =========================================

-- Clear existing sample data for A2-L10 (optional - comment out if you want to keep existing data)
DELETE FROM grammar_sentences WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'A2-L10');
DELETE FROM vocabulary_items WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'A2-L10');
DELETE FROM lesson_activities WHERE lesson_id = 'A2-L10';
DELETE FROM lessons WHERE id = 'A2-L10';

INSERT INTO lessons (id, level, lesson_number, topic) VALUES
('A2-L10', 'A2', 10, 'Describing People & Objects')
ON CONFLICT (id) DO UPDATE SET topic = EXCLUDED.topic;

DO $$
DECLARE
    lesson_id_var TEXT := 'A2-L10';
    activity_id_var UUID;
BEGIN
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content) VALUES (lesson_id_var, 'warm_up_speaking', 1, 'Description Talk', 'Talk about describing things', '{"prompt": "How do you describe your friends?"}'::jsonb) RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content) VALUES (lesson_id_var, 'vocabulary_intro', 2, 'Description Words', 'Learn describing vocabulary', '{}'::jsonb) RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'tall', 'สูง', NULL),
    (activity_id_var, 'short', 'เตี้ย', NULL),
    (activity_id_var, 'big', 'ใหญ่', NULL),
    (activity_id_var, 'small', 'เล็ก', NULL),
    (activity_id_var, 'beautiful', 'สวย', NULL);

    -- 3. Vocabulary Matching Drag #1 (5 pairs - same words)
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content) VALUES (lesson_id_var, 'vocabulary_matching_drag', 3, 'Match Descriptions 1', 'Match English words with Thai meanings', '{}'::jsonb) RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'tall', 'สูง', NULL),
    (activity_id_var, 'short', 'เตี้ย', NULL),
    (activity_id_var, 'big', 'ใหญ่', NULL),
    (activity_id_var, 'small', 'เล็ก', NULL),
    (activity_id_var, 'beautiful', 'สวย', NULL);


    -- 4. Vocabulary Fill Blanks #1 (4 words: tall, short, big, small - beautiful left out)
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content) VALUES (lesson_id_var, 'vocabulary_fill_blanks', 4, 'Complete the Sentences 1', 'Fill in the blanks with correct words', '{"text": "My brother is very ___. My sister is ___. This house is ___. That box is ___ and light.", "blanks": [{"id": "blank1", "text": "tall", "options": ["tall", "short", "big", "small"], "correctAnswer": "tall"}, {"id": "blank2", "text": "short", "options": ["tall", "short", "big", "small"], "correctAnswer": "short"}, {"id": "blank3", "text": "big", "options": ["tall", "short", "big", "small"], "correctAnswer": "big"}, {"id": "blank4", "text": "small", "options": ["tall", "short", "big", "small"], "correctAnswer": "small"}]}'::jsonb) RETURNING id INTO activity_id_var;

    -- 4. Vocabulary Fill Blanks #2 (4 words: tall, short, big, beautiful - small left out)
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content) VALUES (lesson_id_var, 'vocabulary_fill_blanks', 5, 'Complete the Sentences 2', 'Fill in the blanks with correct words', '{"text": "The tree is very ___. The mouse is ___. My school is ___. She has ___ long hair.", "blanks": [{"id": "blank1", "text": "tall", "options": ["tall", "short", "big", "beautiful"], "correctAnswer": "tall"}, {"id": "blank2", "text": "short", "options": ["tall", "short", "big", "beautiful"], "correctAnswer": "short"}, {"id": "blank3", "text": "big", "options": ["tall", "short", "big", "beautiful"], "correctAnswer": "big"}, {"id": "blank4", "text": "beautiful", "options": ["tall", "short", "big", "beautiful"], "correctAnswer": "beautiful"}]}'::jsonb) RETURNING id INTO activity_id_var;

    -- 4. Grammar Explanation (5 examples - CEFR A2: Physical appearance)
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content) VALUES (lesson_id_var, 'grammar_explanation', 6, 'Describing Appearance', 'Learn to describe people and things', '{"rules": "Use ''is/are + adjective'' to describe:\n\n- People: She is tall. He is short.\n- Things: It is big. They are small.\n- Questions: Is she tall? Are they big?\n- Negative: She isn''t tall. It isn''t small.\n- Very + adjective: very tall, very beautiful", "examples": ["My friend is very tall.", "The house is quite big.", "Is your sister short?", "This flower isn''t small.", "She has beautiful hair."]}'::jsonb) RETURNING id INTO activity_id_var;
    -- 4. Grammar Sentences #1
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content) VALUES (lesson_id_var, 'grammar_sentences', 7, 'Build Sentences 1', 'Arrange words to make sentences', '{}'::jsonb) RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'My friend is very tall', 'My friend is very tall', '["My", "friend", "is", "very", "tall"]'::jsonb),
    (activity_id_var, 'The house is quite big', 'The house is quite big', '["The", "house", "is", "quite", "big"]'::jsonb);
    -- 4. Grammar Sentences #2
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content) VALUES (lesson_id_var, 'grammar_sentences', 8, 'Build Sentences 2', 'Arrange words to make sentences', '{}'::jsonb) RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'Is your sister short', 'Is your sister short?', '["Is", "your", "sister", "short?"]'::jsonb),
    (activity_id_var, 'This flower isn t small', 'This flower isn''t small', '["This", "flower", "isn''t", "small"]'::jsonb);
    -- 4. Speaking Practice (5 prompts - CEFR A2: Talking about colors and shapes)
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content) VALUES (lesson_id_var, 'speaking_practice', 9, 'Talk About Descriptions', 'Practice describing people and objects', '{"prompts": ["Is your teacher tall or short?", "What color is your school bag or backpack?", "Describe your best friend.", "Is your house bigger or smaller than your friend''s?", "What does your favorite toy or object look like?"]}'::jsonb) RETURNING id INTO activity_id_var;

END $$;
