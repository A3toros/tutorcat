-- =========================================
-- Pre-fill Database with Sample Lesson Data
-- B2-L77: Social media influence
-- =========================================

DELETE FROM grammar_sentences WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'B2-L77');
DELETE FROM vocabulary_items WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'B2-L77');
DELETE FROM lesson_activities WHERE lesson_id = 'B2-L77';
DELETE FROM lessons WHERE id = 'B2-L77';

INSERT INTO lessons (id, level, lesson_number, topic) VALUES
('B2-L77', 'B2', 77, 'Social media influence')
ON CONFLICT (id) DO UPDATE SET topic = EXCLUDED.topic;

DO $$
DECLARE
    lesson_id_var TEXT := 'B2-L77';
    activity_id_var UUID;
BEGIN
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'warm_up_speaking', 1, 'Moderation & Reports', 'Talk about handling posts', '{"prompt": "What should be moderated or reported, and who enforces it?"}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_intro', 2, 'Influence Control Words', 'Key words for moderation actions', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'post', 'โพสต์', NULL),
    (activity_id_var, 'restrict', 'จำกัด', NULL),
    (activity_id_var, 'report', 'รายงาน', NULL),
    (activity_id_var, 'moderate', 'ตรวจสอบ/ควบคุมเนื้อหา', NULL),
    (activity_id_var, 'verify', 'ตรวจสอบความถูกต้อง', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_matching_drag', 3, 'Match Influence Control Words', 'Match words with meanings', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'post', 'โพสต์', NULL),
    (activity_id_var, 'restrict', 'จำกัด', NULL),
    (activity_id_var, 'report', 'รายงาน', NULL),
    (activity_id_var, 'moderate', 'ตรวจสอบ/ควบคุมเนื้อหา', NULL),
    (activity_id_var, 'verify', 'ตรวจสอบความถูกต้อง', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 4, 'Complete the Sentences 1', 'Fill with the correct word', '{"text": "That ___ was harmful. We ___ it. Mods will ___.", "blanks": [{"id": "blank1", "text": "post", "options": ["post", "restrict", "report", "verify"], "correctAnswer": "post"}, {"id": "blank2", "text": "reported", "options": ["reported", "restricted", "verified", "moderated"], "correctAnswer": "reported"}, {"id": "blank3", "text": "moderate", "options": ["moderate", "verify", "restrict", "report"], "correctAnswer": "moderate"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 5, 'Complete the Sentences 2', 'Fill with the correct word', '{"text": "Some accounts get ___. Facts should be ___.", "blanks": [{"id": "blank1", "text": "restricted", "options": ["restricted", "moderated", "reported", "verified"], "correctAnswer": "restricted"}, {"id": "blank2", "text": "verified", "options": ["verified", "reported", "restricted", "moderated"], "correctAnswer": "verified"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_explanation', 6, 'Passive with Modals', 'Assign moderation duties', '{"rules": "Use modal + be + past participle for necessity/permission.\\n- Posts should be moderated.\\n- Harmful content must be restricted.\\nUse modal + have + been + past participle for past duties.", "examples": ["Posts should be moderated before going live.", "Harmful content must be restricted quickly.", "Reports can be reviewed within a day.", "Sources should be verified before sharing.", "Old posts should have been flagged last week."]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 7, 'Build Sentences 1', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'Posts should be moderated before going live', 'Posts should be moderated before going live.', '["Posts", "should", "be", "moderated", "before", "going", "live."]'::jsonb),
    (activity_id_var, 'Harmful content must be restricted quickly', 'Harmful content must be restricted quickly.', '["Harmful", "content", "must", "be", "restricted", "quickly."]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 8, 'Build Sentences 2', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'Reports can be reviewed within a day', 'Reports can be reviewed within a day.', '["Reports", "can", "be", "reviewed", "within", "a", "day."]'::jsonb),
    (activity_id_var, 'Old posts should have been flagged last week', 'Old posts should have been flagged last week.', '["Old", "posts", "should", "have", "been", "flagged", "last", "week."]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'speaking_practice', 9, 'Talk About Moderation', 'Practice passive with modals', '{"prompts": ["What should be moderated first?", "Who enforces limits in your group?", "How fast should reports be reviewed?"]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (
      lesson_id,
      activity_type,
      activity_order,
      title,
      description,
      content
    ) VALUES (
      'B2-L77',
      'speaking_improvement',
      10,
      'Speaking Improvement',
      'Read the improved version of your speech',
      '{"type": "speaking_improvement", "similarityThreshold": 70}'::jsonb
    );
END $$;


