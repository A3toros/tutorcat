-- =========================================
-- Pre-fill Database with Sample Lesson Data
-- B2-L25: Managing money as a student
-- =========================================

DELETE FROM grammar_sentences WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'B2-L25');
DELETE FROM vocabulary_items WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'B2-L25');
DELETE FROM lesson_activities WHERE lesson_id = 'B2-L25';
DELETE FROM lessons WHERE id = 'B2-L25';

INSERT INTO lessons (id, level, lesson_number, topic) VALUES
('B2-L25', 'B2', 25, 'Managing money as a student')
ON CONFLICT (id) DO UPDATE SET topic = EXCLUDED.topic;

DO $$
DECLARE
    lesson_id_var TEXT := 'B2-L25';
    activity_id_var UUID;
BEGIN
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'warm_up_speaking', 1, 'Budget Talk', 'Discuss upcoming plans', '{"prompt": "How will you be tracking spending next month, and what will you cut?"}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_intro', 2, 'Money Words', 'Key words for student budgeting', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'budget', 'งบประมาณ', NULL),
    (activity_id_var, 'expense', 'ค่าใช้จ่าย', NULL),
    (activity_id_var, 'savings', 'เงินออม', NULL),
    (activity_id_var, 'track', 'ติดตาม', NULL),
    (activity_id_var, 'overdue', 'เกินกำหนด/ค้างชำระ', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_matching_drag', 3, 'Match Money Words', 'Match words with meanings', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'budget', 'งบประมาณ', NULL),
    (activity_id_var, 'expense', 'ค่าใช้จ่าย', NULL),
    (activity_id_var, 'savings', 'เงินออม', NULL),
    (activity_id_var, 'track', 'ติดตาม', NULL),
    (activity_id_var, 'overdue', 'เกินกำหนด/ค้างชำระ', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 4, 'Complete the Sentences 1', 'Fill with the correct word', '{"text": "I set a weekly ___. I list every ___. I ___ all receipts.", "blanks": [{"id": "blank1", "text": "budget", "options": ["budget", "expense", "track", "savings"], "correctAnswer": "budget"}, {"id": "blank2", "text": "expense", "options": ["expense", "overdue", "budget", "track"], "correctAnswer": "expense"}, {"id": "blank3", "text": "track", "options": ["track", "savings", "expense", "budget"], "correctAnswer": "track"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 5, 'Complete the Sentences 2', 'Fill with the correct word', '{"text": "I add to my ___. I pay before bills go ___.", "blanks": [{"id": "blank1", "text": "savings", "options": ["savings", "budget", "expense", "overdue"], "correctAnswer": "savings"}, {"id": "blank2", "text": "overdue", "options": ["overdue", "expense", "savings", "track"], "correctAnswer": "overdue"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_explanation', 6, 'Future Continuous', 'Talk about ongoing future money actions', '{"rules": "Use will be + -ing for actions in progress at a specific future time or over a period.\\n- I will be tracking expenses daily next month.\\n- They will be saving a little each week.", "examples": ["Next week, I will be logging every expense.", "This term, we will be cutting food costs.", "I will be watching for overdue notices daily.", "We will be adding to savings each Friday.", "I will be adjusting the budget after exams."]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 7, 'Build Sentences 1', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'Next week, I will be logging every expense', 'Next week, I will be logging every expense.', '["Next", "week,", "I", "will", "be", "logging", "every", "expense."]'::jsonb),
    (activity_id_var, 'We will be cutting food costs this term', 'We will be cutting food costs this term.', '["We", "will", "be", "cutting", "food", "costs", "this", "term."]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 8, 'Build Sentences 2', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'I will be adding to savings each Friday', 'I will be adding to savings each Friday.', '["I", "will", "be", "adding", "to", "savings", "each", "Friday."]'::jsonb),
    (activity_id_var, 'I will be watching for overdue notices daily', 'I will be watching for overdue notices daily.', '["I", "will", "be", "watching", "for", "overdue", "notices", "daily."]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'speaking_practice', 9, 'Talk About Money Plans', 'Practice future continuous', '{"prompts": ["How will you be tracking spending next month?", "What will you be cutting first?", "When will you be adding to savings?"]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (
      lesson_id,
      activity_type,
      activity_order,
      title,
      description,
      content
    ) VALUES (
      'B2-L25',
      'speaking_improvement',
      10,
      'Speaking Improvement',
      'Read the improved version of your speech',
      '{"type": "speaking_improvement", "similarityThreshold": 70}'::jsonb
    );
END $$;


