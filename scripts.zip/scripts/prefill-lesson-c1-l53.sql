-- =========================================
-- Pre-fill Database with Sample Lesson Data
-- C1-L53: Sustainable Lifestyles
-- =========================================
DELETE FROM lesson_activity_results WHERE lesson_id = 'C1-L53';
DELETE FROM user_progress WHERE lesson_id = 'C1-L53';
DELETE FROM lesson_history WHERE lesson_id = 'C1-L53';
DELETE FROM grammar_sentences WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'C1-L53');
DELETE FROM vocabulary_items WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'C1-L53');
DELETE FROM lesson_activities WHERE lesson_id = 'C1-L53';
DELETE FROM lessons WHERE id = 'C1-L53';

INSERT INTO lessons (id, level, lesson_number, topic) VALUES
('C1-L53', 'C1', 53, 'Sustainable Lifestyles')
ON CONFLICT (id) DO UPDATE SET topic = EXCLUDED.topic;

DO $$
DECLARE
    lesson_id_var TEXT := 'C1-L53';
    activity_id_var UUID;
BEGIN
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'warm_up_speaking', 1, 'Sustainable Lifestyles', 'Discuss sustainable lifestyles', '{"prompt": "What habits have you kept while trying to live sustainably?"}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_intro', 2, 'Sustainability Vocabulary', 'Learn vocabulary about sustainability', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'sustainability', 'ความยั่งยืน', NULL),
    (activity_id_var, 'habit', 'นิสัย', NULL),
    (activity_id_var, 'practice', 'การปฏิบัติ', NULL),
    (activity_id_var, 'permanent', 'ถาวร', NULL),
    (activity_id_var, 'maintenance', 'การบำรุงรักษา', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_matching_drag', 3, 'Match Sustainability Words', 'Match English words with Thai meanings', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'sustainability', 'ความยั่งยืน', NULL),
    (activity_id_var, 'habit', 'นิสัย', NULL),
    (activity_id_var, 'practice', 'การปฏิบัติ', NULL),
    (activity_id_var, 'permanent', 'ถาวร', NULL),
    (activity_id_var, 'maintenance', 'การบำรุงรักษา', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 4, 'Complete the Sentences 1', 'Fill with the correct word', '{"text": "Sustainable ___ require ___. Maintaining ___ becomes part of daily life.", "blanks": [{"id": "blank1", "text": "habits", "options": ["habits", "sustainability", "practice", "permanent"], "correctAnswer": "habits"}, {"id": "blank2", "text": "practice", "options": ["practice", "sustainability", "habit", "permanent"], "correctAnswer": "practice"}, {"id": "blank3", "text": "practices", "options": ["practices", "sustainability", "habit", "permanent"], "correctAnswer": "practices"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 5, 'Complete the Sentences 2', 'Fill with the correct word', '{"text": "Some changes become ___. ___ of sustainable habits requires effort.", "blanks": [{"id": "blank1", "text": "permanent", "options": ["permanent", "sustainability", "habit", "practice"], "correctAnswer": "permanent"}, {"id": "blank2", "text": "Maintenance", "options": ["Maintenance", "Sustainability", "Habit", "Practice"], "correctAnswer": "Maintenance"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_explanation', 6, 'Participle Clauses', 'Learn participle clauses', '{"rules": "Participle clauses:\n- Present participle (-ing): \"Maintaining sustainable habits, people live better.\"\n- Past participle (-ed): \"Shaped by sustainability, lifestyles change.\"\n- Perfect participle (having + past participle): \"Having adopted sustainable practices, people maintain them.\"\n\nUse for:\n- Showing simultaneous actions: \"Maintaining habits, you live sustainably.\"\n- Showing cause: \"Shaped by sustainability, lifestyles evolve.\"\n- Showing time sequence: \"Having kept sustainable habits, people maintain them.\"", "examples": ["Maintaining sustainable habits, people live more responsibly.", "Shaped by sustainability, lifestyles change permanently.", "Having adopted sustainable practices, people maintain them.", "Keeping sustainable habits, people reduce their impact.", "Sustaining practices over time, people create lasting change."]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 7, 'Build Sentences 1', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'Maintaining sustainable habits, people live more responsibly.', 'Maintaining sustainable habits, people live more responsibly.', '["Maintaining", "sustainable", "habits,", "people", "live", "more", "responsibly."]'::jsonb),
    (activity_id_var, 'Shaped by sustainability, lifestyles change permanently.', 'Shaped by sustainability, lifestyles change permanently.', '["Shaped", "by", "sustainability,", "lifestyles", "change", "permanently."]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 8, 'Build Sentences 2', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'Having adopted sustainable practices, people maintain them.', 'Having adopted sustainable practices, people maintain them.', '["Having", "adopted", "sustainable", "practices,", "people", "maintain", "them."]'::jsonb),
    (activity_id_var, 'Keeping sustainable habits, people reduce their impact.', 'Keeping sustainable habits, people reduce their impact.', '["Keeping", "sustainable", "habits,", "people", "reduce", "their", "impact."]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'speaking_practice', 9, 'Discuss Sustainable Lifestyles', 'Practice speaking about sustainable lifestyles', '{"prompts": ["What habits have you kept?", "What sustainable practices do you maintain?", "How do you make sustainability part of daily life?", "What changes have become permanent for you?", "What makes sustainable habits hard to maintain?"]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (
      lesson_id,
      activity_type,
      activity_order,
      title,
      description,
      content
    ) VALUES (
      'C1-L53',
      'speaking_improvement',
      10,
      'Speaking Improvement',
      'Read the improved version of your speech',
      '{"type": "speaking_improvement", "similarityThreshold": 70}'::jsonb
    );
END $$;
