-- =========================================
-- Pre-fill Database with Sample Lesson Data
-- A1-L44: Days of the Week
-- =========================================

DELETE FROM grammar_sentences WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'A1-L44');
DELETE FROM vocabulary_items WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'A1-L44');
DELETE FROM lesson_activities WHERE lesson_id = 'A1-L44');
DELETE FROM lessons WHERE id = 'A1-L44';

INSERT INTO lessons (id, level, lesson_number, topic) VALUES
('A1-L44', 'A1', 44, 'Days of the Week')
ON CONFLICT (id) DO UPDATE SET topic = EXCLUDED.topic;

DO $$
DECLARE
    lesson_id_var TEXT := 'A1-L44';
    activity_id_var UUID;
BEGIN
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'warm_up_speaking', 1, 'Days', 'Talk about days', '{"prompt": "What day is today?"}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_intro', 2, 'Day Words', 'Learn day names', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'Monday', 'วันจันทร์', NULL),
    (activity_id_var, 'Tuesday', 'วันอังคาร', NULL),
    (activity_id_var, 'Wednesday', 'วันพุธ', NULL),
    (activity_id_var, 'Thursday', 'วันพฤหัสบดี', NULL),
    (activity_id_var, 'Friday', 'วันศุกร์', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_matching_drag', 3, 'Match Day Words', 'Match day names', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'Monday', 'วันจันทร์', NULL),
    (activity_id_var, 'Tuesday', 'วันอังคาร', NULL),
    (activity_id_var, 'Wednesday', 'วันพุธ', NULL),
    (activity_id_var, 'Thursday', 'วันพฤหัสบดี', NULL),
    (activity_id_var, 'Friday', 'วันศุกร์', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 4, 'Complete the Sentences 1', 'Fill with the correct word', '{"text": "Today is ___. Tomorrow is ___.", "blanks": [{"id": "blank1", "text": "Monday", "options": ["Monday", "Tuesday", "Wednesday", "Friday"], "correctAnswer": "Monday"}, {"id": "blank2", "text": "Tuesday", "options": ["Tuesday", "Wednesday", "Thursday", "Friday"], "correctAnswer": "Tuesday"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 5, 'Complete the Sentences 2', 'Fill with the correct word', '{"text": "School starts on ___. We rest on ___.", "blanks": [{"id": "blank1", "text": "Wednesday", "options": ["Wednesday", "Thursday", "Friday", "Monday"], "correctAnswer": "Wednesday"}, {"id": "blank2", "text": "Friday", "options": ["Friday", "Monday", "Thursday", "Tuesday"], "correctAnswer": "Friday"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_explanation', 6, 'On + Days', 'Use on with days', '{"rules": "Use on + day for time.\n- On Monday I study.\n- On Friday we rest.\nAsk: Do you study on Monday?", "examples": ["On Monday I study.", "On Tuesday I work.", "On Wednesday we play.", "Do you study on Monday?", "Do you rest on Friday?"]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 7, 'Build Sentences 1', 'Arrange words', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'On Monday I study', 'On Monday I study.', '["On", "Monday", "I", "study."]'::jsonb),
    (activity_id_var, 'On Friday we rest', 'On Friday we rest.', '["On", "Friday", "we", "rest."]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 8, 'Build Sentences 2', 'Arrange words', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'Do you study on Monday', 'Do you study on Monday?', '["Do", "you", "study", "on", "Monday?"]'::jsonb),
    (activity_id_var, 'Do you rest on Friday', 'Do you rest on Friday?', '["Do", "you", "rest", "on", "Friday?"]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'speaking_practice', 9, 'Talk About Days', 'Practice days and on + day', '{"prompts": ["What day is today?", "Do you study on Monday?", "Do you work on Tuesday?", "Do you rest on Friday?", "What day do you like?"]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (
      lesson_id,
      activity_type,
      activity_order,
      title,
      description,
      content
    ) VALUES (
      'A1-L44',
      'speaking_improvement',
      10,
      'Speaking Improvement',
      'Read the improved version of your speech',
      '{"type": "speaking_improvement", "similarityThreshold": 70}'::jsonb
    );
END $$;

