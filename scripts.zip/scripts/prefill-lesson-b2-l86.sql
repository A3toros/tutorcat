-- ===== LESSON B2-L86 =====

-- =========================================
-- Pre-fill Database with Sample Lesson Data
-- B2-L86: Technology dependence
-- =========================================

DELETE FROM lesson_activity_results WHERE lesson_id = 'B2-L86';
DELETE FROM user_progress WHERE lesson_id = 'B2-L86';
DELETE FROM lesson_history WHERE lesson_id = 'B2-L86';
DELETE FROM grammar_sentences WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'B2-L86');
DELETE FROM vocabulary_items WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'B2-L86');
DELETE FROM lesson_activities WHERE lesson_id = 'B2-L86';
DELETE FROM lessons WHERE id = 'B2-L86';

INSERT INTO lessons (id, level, lesson_number, topic) VALUES
('B2-L86', 'B2', 86, 'Technology dependence')
ON CONFLICT (id) DO UPDATE SET topic = EXCLUDED.topic;

DO $$
DECLARE
    lesson_id_var TEXT := 'B2-L86';
    activity_id_var UUID;
BEGIN
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'warm_up_speaking', 1, 'Digital Reliance', 'Talk about dependence on technology', '{"prompt": "If you unplugged earlier, how would today feel?"}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_intro', 2, 'Tech Dependence Words', 'Learn words related to technology reliance', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'notification', 'การแจ้งเตือน', NULL),
    (activity_id_var, 'screen', 'หน้าจอ', NULL),
    (activity_id_var, 'focus', 'โฟกัส', NULL),
    (activity_id_var, 'limit', 'จำกัด', NULL),
    (activity_id_var, 'detox', 'ล้างพิษ', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_matching_drag', 3, 'Match Tech Dependence Words', 'Match words related to digital reliance', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'notification', 'การแจ้งเตือน', NULL),
    (activity_id_var, 'screen', 'หน้าจอ', NULL),
    (activity_id_var, 'focus', 'โฟกัส', NULL),
    (activity_id_var, 'limit', 'จำกัด', NULL),
    (activity_id_var, 'detox', 'ล้างพิษ', NULL);

    -- 4. Vocabulary Fill Blanks #1
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 4, 'Complete the Sentences 1', 'Fill in the blanks with correct words', '{"text": "I got a ___. I look at my ___. I lose ___.", "blanks": [{"id": "blank1", "text": "notification", "options": ["notification", "screen", "focus", "limit"], "correctAnswer": "notification"}, {"id": "blank2", "text": "screen", "options": ["screen", "notification", "focus", "detox"], "correctAnswer": "screen"}, {"id": "blank3", "text": "focus", "options": ["focus", "notification", "screen", "limit"], "correctAnswer": "focus"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    -- 5. Vocabulary Fill Blanks #2
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 5, 'Complete the Sentences 2', 'Fill in the blanks with correct words', '{"text": "I need to ___ my use. I should do a ___. We must ___.", "blanks": [{"id": "blank1", "text": "limit", "options": ["limit", "notification", "screen", "focus"], "correctAnswer": "limit"}, {"id": "blank2", "text": "detox", "options": ["detox", "limit", "screen", "focus"], "correctAnswer": "detox"}, {"id": "blank3", "text": "limit", "options": ["limit", "detox", "screen", "focus"], "correctAnswer": "limit"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    -- 6. Grammar Explanation
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_explanation', 6, 'Mixed Conditionals', 'Learn conditionals mixing past and present', '{"rules": "Use mixed conditionals to connect past conditions with present results:\n\n- If + past perfect, would + base verb (If I had set limits, I would be)\n- If + past simple, would + base verb (If she unplugged, her focus would improve)\n- Connects past actions/conditions to present/future results\n- Shows how past choices affect current situation\n- Combines third and second conditional patterns", "examples": ["If I had set limits earlier, I would be less dependent now.", "If she unplugged completely, her focus would improve immediately.", "If they had digital detoxes, they would sleep better.", "If I had started earlier, I would have better habits now.", "If you unplugged earlier, how would today feel?"]}'::jsonb)
    RETURNING id INTO activity_id_var;

    -- 7. Grammar Sentences #1
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 7, 'Build Sentences 1', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'If I had set limits earlier I would be less dependent now', 'If I had set limits earlier, I would be less dependent now.', '["If", "I", "had", "set", "limits", "earlier,", "I", "would", "be", "less", "dependent", "now."]'::jsonb),
    (activity_id_var, 'If she unplugged completely her focus would improve immediately', 'If she unplugged completely, her focus would improve immediately.', '["If", "she", "unplugged", "completely,", "her", "focus", "would", "improve", "immediately."]'::jsonb);

    -- 8. Grammar Sentences #2
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 8, 'Build Sentences 2', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'If they had digital detoxes they would sleep better', 'If they had digital detoxes, they would sleep better.', '["If", "they", "had", "digital", "detoxes,", "they", "would", "sleep", "better."]'::jsonb),
    (activity_id_var, 'If I had started earlier I would have better habits now', 'If I had started earlier, I would have better habits now.', '["If", "I", "had", "started", "earlier,", "I", "would", "have", "better", "habits", "now."]'::jsonb);

    -- 9. Speaking Practice
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'speaking_practice', 9, 'Talk About Technology', 'Practice talking about digital habits', '{"prompts": ["When do you put your phone away?", "What do you do without your phone?", "Who calls you on the phone?", "How do you limit your screen time?", "Have you ever done a digital detox?"]}'::jsonb)
    RETURNING id INTO activity_id_var;

    -- 10. Speaking Improvement
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'speaking_improvement', 10, 'Speaking Improvement', 'Read the improved version of your speech', '{"type": "speaking_improvement", "similarityThreshold": 70}'::jsonb)
    RETURNING id INTO activity_id_var;
END $$;