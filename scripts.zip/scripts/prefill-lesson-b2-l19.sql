-- =========================================
-- Pre-fill Database with Sample Lesson Data
-- B2-L19: Personal values
-- =========================================

DELETE FROM grammar_sentences WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'B2-L19');
DELETE FROM vocabulary_items WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'B2-L19');
DELETE FROM lesson_activities WHERE lesson_id = 'B2-L19';
DELETE FROM lessons WHERE id = 'B2-L19';

INSERT INTO lessons (id, level, lesson_number, topic) VALUES
('B2-L19', 'B2', 19, 'Personal values')
ON CONFLICT (id) DO UPDATE SET topic = EXCLUDED.topic;

DO $$
DECLARE
    lesson_id_var TEXT := 'B2-L19';
    activity_id_var UUID;
BEGIN
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'warm_up_speaking', 1, 'Values Check', 'Talk about what guides you', '{"prompt": "What value, which you keep, guides you daily, and when was it tested?"}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_intro', 2, 'Values Words', 'Key words for values and character', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'integrity', 'ความซื่อสัตย์สุจริต', NULL),
    (activity_id_var, 'empathy', 'ความเอาใจใส่/เข้าอกเข้าใจ', NULL),
    (activity_id_var, 'grit', 'ความมุ่งมั่น/อดทน', NULL),
    (activity_id_var, 'fairness', 'ความยุติธรรม', NULL),
    (activity_id_var, 'loyalty', 'ความภักดี', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_matching_drag', 3, 'Match Values Words', 'Match words with meanings', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'integrity', 'ความซื่อสัตย์สุจริต', NULL),
    (activity_id_var, 'empathy', 'ความเอาใจใส่/เข้าอกเข้าใจ', NULL),
    (activity_id_var, 'grit', 'ความมุ่งมั่น/อดทน', NULL),
    (activity_id_var, 'fairness', 'ความยุติธรรม', NULL),
    (activity_id_var, 'loyalty', 'ความภักดี', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 4, 'Complete the Sentences 1', 'Fill with the correct word', '{"text": "Her ___ showed when she admitted the mistake. ___ helps me listen. ___ keeps me finishing hard tasks.", "blanks": [{"id": "blank1", "text": "integrity", "options": ["integrity", "empathy", "grit", "loyalty"], "correctAnswer": "integrity"}, {"id": "blank2", "text": "empathy", "options": ["empathy", "grit", "fairness", "integrity"], "correctAnswer": "empathy"}, {"id": "blank3", "text": "grit", "options": ["grit", "loyalty", "fairness", "integrity"], "correctAnswer": "grit"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 5, 'Complete the Sentences 2', 'Fill with the correct word', '{"text": "___ matters in group work. I value ___.", "blanks": [{"id": "blank1", "text": "fairness", "options": ["fairness", "loyalty", "integrity", "grit"], "correctAnswer": "fairness"}, {"id": "blank2", "text": "loyalty", "options": ["loyalty", "fairness", "empathy", "grit"], "correctAnswer": "loyalty"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_explanation', 6, 'Non-defining Relative Clauses', 'Add extra info about values', '{"rules": "Use commas with who/which/where to add extra, non-essential information. Do not omit the pronoun.\\n- My mentor, who values integrity, guided me.\\n- Fairness, which matters to me, shapes decisions.", "examples": ["Integrity, which my parents taught me, guides choices.", "My sister, who shows empathy, is my model.", "Grit, which takes practice, helps me finish tasks.", "Our team, which trusts each other, works faster.", "Loyalty, which I admire, keeps friendships strong."]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 7, 'Build Sentences 1', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'Integrity, which my parents taught me, guides choices', 'Integrity, which my parents taught me, guides choices.', '["Integrity,", "which", "my", "parents", "taught", "me,", "guides", "choices."]'::jsonb),
    (activity_id_var, 'My sister, who shows empathy, is my model', 'My sister, who shows empathy, is my model.', '["My", "sister,", "who", "shows", "empathy,", "is", "my", "model."]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 8, 'Build Sentences 2', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'Grit, which takes practice, helps me finish tasks', 'Grit, which takes practice, helps me finish tasks.', '["Grit,", "which", "takes", "practice,", "helps", "me", "finish", "tasks."]'::jsonb),
    (activity_id_var, 'Our team, which trusts each other, works faster', 'Our team, which trusts each other, works faster.', '["Our", "team,", "which", "trusts", "each", "other,", "works", "faster."]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'speaking_practice', 9, 'Talk About Values', 'Practice non-defining relatives', '{"prompts": ["Which value, which you keep, guides you daily?", "Who in your life, who you admire, models that value?", "When was your value tested recently?"]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (
      lesson_id,
      activity_type,
      activity_order,
      title,
      description,
      content
    ) VALUES (
      'B2-L19',
      'speaking_improvement',
      10,
      'Speaking Improvement',
      'Read the improved version of your speech',
      '{"type": "speaking_improvement", "similarityThreshold": 70}'::jsonb
    );
END $$;


