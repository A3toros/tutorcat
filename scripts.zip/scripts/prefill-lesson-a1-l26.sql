-- =========================================
-- Pre-fill Database with Sample Lesson Data
-- A1-L26: Fruits
-- =========================================

DELETE FROM grammar_sentences WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'A1-L26');
DELETE FROM vocabulary_items WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'A1-L26');
DELETE FROM lesson_activities WHERE lesson_id = 'A1-L26';
DELETE FROM lessons WHERE id = 'A1-L26';

INSERT INTO lessons (id, level, lesson_number, topic) VALUES
('A1-L26', 'A1', 26, 'Fruits')
ON CONFLICT (id) DO UPDATE SET topic = EXCLUDED.topic;

DO $$
DECLARE
    lesson_id_var TEXT := 'A1-L26';
    activity_id_var UUID;
BEGIN
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'warm_up_speaking', 1, 'Fruits', 'Talk about fruits you like', '{"prompt": "Do you like apples?"}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_intro', 2, 'Fruit Words', 'Learn fruit words', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'apple', 'แอปเปิ้ล', NULL),
    (activity_id_var, 'banana', 'กล้วย', NULL),
    (activity_id_var, 'orange', 'ส้ม', NULL),
    (activity_id_var, 'mango', 'มะม่วง', NULL),
    (activity_id_var, 'grape', 'องุ่น', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_matching_drag', 3, 'Match Fruit Words', 'Match fruit words', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'apple', 'แอปเปิ้ล', NULL),
    (activity_id_var, 'banana', 'กล้วย', NULL),
    (activity_id_var, 'orange', 'ส้ม', NULL),
    (activity_id_var, 'mango', 'มะม่วง', NULL),
    (activity_id_var, 'grape', 'องุ่น', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 4, 'Complete the Sentences 1', 'Fill with the correct word', '{"text": "I like ___. I like ___.", "blanks": [{"id": "blank1", "text": "apple", "options": ["apple", "banana", "orange", "mango"], "correctAnswer": "apple"}, {"id": "blank2", "text": "banana", "options": ["banana", "grape", "apple", "mango"], "correctAnswer": "banana"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 5, 'Complete the Sentences 2', 'Fill with the correct word', '{"text": "This is an ___. Those are ___.", "blanks": [{"id": "blank1", "text": "orange", "options": ["orange", "apple", "mango", "grape"], "correctAnswer": "orange"}, {"id": "blank2", "text": "grapes", "options": ["grapes", "bananas", "mangos", "oranges"], "correctAnswer": "grapes"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_explanation', 6, 'A/An and Plurals', 'Use a/an and plural s for fruits', '{"rules": "Use a/an for one. Add s for many.\n- an apple, a mango, apples, oranges.\nAsk: Do you like apples?", "examples": ["This is an apple.", "That is a mango.", "These are grapes.", "Those are oranges.", "Do you like bananas?"]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 7, 'Build Sentences 1', 'Arrange words', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'This is an apple', 'This is an apple.', '["This", "is", "an", "apple."]'::jsonb),
    (activity_id_var, 'These are grapes', 'These are grapes.', '["These", "are", "grapes."]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 8, 'Build Sentences 2', 'Arrange words', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'That is a mango', 'That is a mango.', '["That", "is", "a", "mango."]'::jsonb),
    (activity_id_var, 'Do you like bananas', 'Do you like bananas?', '["Do", "you", "like", "bananas?"]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'speaking_practice', 9, 'Talk About Fruits', 'Practice fruit words', '{"prompts": ["Do you like apples?", "How many bananas do you eat?", "Do you like oranges?", "Do you like mango?", "Do you like grapes?"]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (
      lesson_id,
      activity_type,
      activity_order,
      title,
      description,
      content
    ) VALUES (
      'A1-L26',
      'speaking_improvement',
      10,
      'Speaking Improvement',
      'Read the improved version of your speech',
      '{"type": "speaking_improvement", "similarityThreshold": 70}'::jsonb
    );
END $$;

