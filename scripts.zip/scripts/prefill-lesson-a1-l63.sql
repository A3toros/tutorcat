-- =========================================
-- Pre-fill Database with Sample Lesson Data
-- A1-L63: Maps (very basic)
-- =========================================

DELETE FROM grammar_sentences WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'A1-L63');
DELETE FROM vocabulary_items WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'A1-L63');
DELETE FROM lesson_activities WHERE lesson_id = 'A1-L63';
DELETE FROM lessons WHERE id = 'A1-L63';

INSERT INTO lessons (id, level, lesson_number, topic) VALUES
('A1-L63', 'A1', 63, 'Maps (very basic)')
ON CONFLICT (id) DO UPDATE SET topic = EXCLUDED.topic;

DO $$
DECLARE
    lesson_id_var TEXT := 'A1-L63';
    activity_id_var UUID;
BEGIN
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'warm_up_speaking', 1, 'Maps', 'Talk about simple maps', '{"prompt": "Is this the right place?"}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_intro', 2, 'Map Words', 'Learn basic map words', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'map', 'แผนที่', NULL),
    (activity_id_var, 'here', 'ที่นี่', NULL),
    (activity_id_var, 'there', 'ที่นั่น', NULL),
    (activity_id_var, 'line', 'เส้น', NULL),
    (activity_id_var, 'point', 'จุด', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_matching_drag', 3, 'Match Map Words', 'Match map words', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'map', 'แผนที่', NULL),
    (activity_id_var, 'here', 'ที่นี่', NULL),
    (activity_id_var, 'there', 'ที่นั่น', NULL),
    (activity_id_var, 'line', 'เส้น', NULL),
    (activity_id_var, 'point', 'จุด', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 4, 'Complete the Sentences 1', 'Fill with the correct word', '{"text": "This is the ___. We are ___.", "blanks": [{"id": "blank1", "text": "map", "options": ["map", "line", "point", "here"], "correctAnswer": "map"}, {"id": "blank2", "text": "here", "options": ["here", "there", "line", "point"], "correctAnswer": "here"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 5, 'Complete the Sentences 2', 'Fill with the correct word', '{"text": "Go ___. Mark the ___.", "blanks": [{"id": "blank1", "text": "there", "options": ["there", "here", "map", "point"], "correctAnswer": "there"}, {"id": "blank2", "text": "point", "options": ["point", "line", "map", "here"], "correctAnswer": "point"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_explanation', 6, 'Imperatives + Place', 'Give basic map directions', '{"rules": "Use base verb for simple map steps.\n- Go here. Go there. Point here.\nAdd please for polite tone.", "examples": ["Go here.", "Go there.", "Point to the line.", "Mark this point.", "Do I go there?"]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 7, 'Build Sentences 1', 'Arrange words', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'Go here', 'Go here.', '["Go", "here."]'::jsonb),
    (activity_id_var, 'Go there', 'Go there.', '["Go", "there."]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 8, 'Build Sentences 2', 'Arrange words', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'Point to the line', 'Point to the line.', '["Point", "to", "the", "line."]'::jsonb),
    (activity_id_var, 'Mark this point', 'Mark this point.', '["Mark", "this", "point."]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'speaking_practice', 9, 'Talk About Maps', 'Practice simple map directions', '{"prompts": ["Is this the right place?", "Do I go here?", "Do I go there?", "Can you point to your home?", "Is this the line?"]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (
      lesson_id,
      activity_type,
      activity_order,
      title,
      description,
      content
    ) VALUES (
      'A1-L63',
      'speaking_improvement',
      10,
      'Speaking Improvement',
      'Read the improved version of your speech',
      '{"type": "speaking_improvement", "similarityThreshold": 70}'::jsonb
    );
END $$;

