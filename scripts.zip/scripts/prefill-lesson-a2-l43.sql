-- =========================================
-- Pre-fill Database with Sample Lesson Data
-- A2-L43: Part-Time Jobs
-- =========================================

DELETE FROM grammar_sentences WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'A2-L43');
DELETE FROM vocabulary_items WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'A2-L43');
DELETE FROM lesson_activities WHERE lesson_id = 'A2-L43';
DELETE FROM lessons WHERE id = 'A2-L43';

INSERT INTO lessons (id, level, lesson_number, topic) VALUES
('A2-L43', 'A2', 43, 'Part-Time Jobs')
ON CONFLICT (id) DO UPDATE SET topic = EXCLUDED.topic;

DO $$
DECLARE
    lesson_id_var TEXT := 'A2-L43';
    activity_id_var UUID;
BEGIN
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'warm_up_speaking', 1, 'Part-Time Work', 'Talk about part-time jobs', '{"prompt": "Have you ever had a part-time job?"}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_intro', 2, 'Job Words', 'Learn part-time job words', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'part-time', 'พาร์ตไทม์', NULL),
    (activity_id_var, 'weekend', 'สุดสัปดาห์', NULL),
    (activity_id_var, 'salary', 'เงินเดือน', NULL),
    (activity_id_var, 'boss', 'หัวหน้า', NULL),
    (activity_id_var, 'customer', 'ลูกค้า', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_matching_drag', 3, 'Match Job Words', 'Match job words', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'part-time', 'พาร์ตไทม์', NULL),
    (activity_id_var, 'weekend', 'สุดสัปดาห์', NULL),
    (activity_id_var, 'salary', 'เงินเดือน', NULL),
    (activity_id_var, 'boss', 'หัวหน้า', NULL),
    (activity_id_var, 'customer', 'ลูกค้า', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 4, 'Complete the Sentences 1', 'Fill with the correct word', '{"text": "I worked ___ on ___. My ___ paid me a small ___.", "blanks": [{"id": "blank1", "text": "part-time", "options": ["part-time", "weekend", "salary", "boss"], "correctAnswer": "part-time"}, {"id": "blank2", "text": "weekends", "options": ["weekends", "salary", "boss", "customer"], "correctAnswer": "weekends"}, {"id": "blank3", "text": "boss", "options": ["boss", "customer", "salary", "weekend"], "correctAnswer": "boss"}, {"id": "blank4", "text": "salary", "options": ["salary", "weekend", "part-time", "customer"], "correctAnswer": "salary"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 5, 'Complete the Sentences 2', 'Fill with the correct word', '{"text": "I helped a ___ with bags. My ___ asked me to work extra.", "blanks": [{"id": "blank1", "text": "customer", "options": ["customer", "boss", "weekend", "salary"], "correctAnswer": "customer"}, {"id": "blank2", "text": "boss", "options": ["boss", "customer", "salary", "part-time"], "correctAnswer": "boss"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_explanation', 6, 'Past Simple', 'Talk about past part-time jobs', '{"rules": "Use past simple for finished jobs.\nRegular: worked, helped. Irregular: went, had.\nQuestions: Did you work weekends?\nNegatives: didn''t + verb.", "examples": ["I worked part-time last year.", "I helped many customers.", "Did you work weekends?", "I didn''t earn much salary.", "My boss was kind."]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 7, 'Build Sentences 1', 'Arrange words', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'I worked part time last year', 'I worked part-time last year.', '["I", "worked", "part-time", "last", "year."]'::jsonb),
    (activity_id_var, 'Did you work weekends', 'Did you work weekends?', '["Did", "you", "work", "weekends?"]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 8, 'Build Sentences 2', 'Arrange words', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'I didn t earn much salary', 'I didn''t earn much salary.', '["I", "didn''t", "earn", "much", "salary."]'::jsonb),
    (activity_id_var, 'My boss was kind', 'My boss was kind.', '["My", "boss", "was", "kind."]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'speaking_practice', 9, 'Talk About Part-Time Jobs', 'Practice job stories', '{"prompts": ["Have you ever had a part-time job?", "What kind of work did you do?", "What skills did you learn from it?", "How much did you earn per week or month?", "Would you like to do that job again?"]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (
      lesson_id,
      activity_type,
      activity_order,
      title,
      description,
      content
    ) VALUES (
      'A2-L43',
      'speaking_improvement',
      10,
      'Speaking Improvement',
      'Read the improved version of your speech',
      '{"type": "speaking_improvement", "similarityThreshold": 70}'::jsonb
    );
END $$;

