-- ===== LESSON B2-L59 =====

-- =========================================
-- Pre-fill Database with Sample Lesson Data
-- B2-L59: Learning styles (switching)
-- =========================================

DELETE FROM lesson_activity_results WHERE lesson_id = 'B2-L59';
DELETE FROM user_progress WHERE lesson_id = 'B2-L59';
DELETE FROM lesson_history WHERE lesson_id = 'B2-L59';
DELETE FROM grammar_sentences WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'B2-L59');
DELETE FROM vocabulary_items WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'B2-L59');
DELETE FROM lesson_activities WHERE lesson_id = 'B2-L59';
DELETE FROM lessons WHERE id = 'B2-L59';

INSERT INTO lessons (id, level, lesson_number, topic) VALUES
('B2-L59', 'B2', 59, 'Learning styles (switching)')
ON CONFLICT (id) DO UPDATE SET topic = EXCLUDED.topic;

DO $$
DECLARE
    lesson_id_var TEXT := 'B2-L59';
    activity_id_var UUID;
BEGIN
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'warm_up_speaking', 1, 'Learning Styles', 'Talk about how you study best', '{"prompt": "Do you prefer reading or watching videos?"}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_intro', 2, 'Learning Style Words', 'Learn words related to different learning approaches', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'visual', 'ภาพ', NULL),
    (activity_id_var, 'auditory', 'เสียง', NULL),
    (activity_id_var, 'kinesthetic', 'การเคลื่อนไหว', NULL),
    (activity_id_var, 'adapt', 'ปรับตัว', NULL),
    (activity_id_var, 'mismatch', 'ไม่ตรงกัน', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_matching_drag', 3, 'Match Learning Style Words', 'Match words related to learning methods', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'visual', 'ภาพ', NULL),
    (activity_id_var, 'auditory', 'เสียง', NULL),
    (activity_id_var, 'kinesthetic', 'การเคลื่อนไหว', NULL),
    (activity_id_var, 'adapt', 'ปรับตัว', NULL),
    (activity_id_var, 'mismatch', 'ไม่ตรงกัน', NULL);

    -- 4. Vocabulary Fill Blanks #1
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 4, 'Complete the Sentences 1', 'Fill in the blanks with correct words', '{"text": "I am a ___ learner. I prefer ___ learning. I need ___ activities.", "blanks": [{"id": "blank1", "text": "visual", "options": ["visual", "auditory", "kinesthetic", "adapt"], "correctAnswer": "visual"}, {"id": "blank2", "text": "auditory", "options": ["auditory", "visual", "kinesthetic", "mismatch"], "correctAnswer": "auditory"}, {"id": "blank3", "text": "kinesthetic", "options": ["kinesthetic", "visual", "auditory", "adapt"], "correctAnswer": "kinesthetic"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    -- 5. Vocabulary Fill Blanks #2
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 5, 'Complete the Sentences 2', 'Fill in the blanks with correct words', '{"text": "I need to ___ to new methods. There is a ___. We must ___.", "blanks": [{"id": "blank1", "text": "adapt", "options": ["adapt", "visual", "auditory", "mismatch"], "correctAnswer": "adapt"}, {"id": "blank2", "text": "mismatch", "options": ["mismatch", "visual", "auditory", "adapt"], "correctAnswer": "mismatch"}, {"id": "blank3", "text": "adapt", "options": ["adapt", "mismatch", "visual", "auditory"], "correctAnswer": "adapt"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    -- 6. Grammar Explanation
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_explanation', 6, 'Reason and Result (so/such...that)', 'Learn so/such...that for cause and effect', '{"rules": "Use so/such...that to show cause and effect:\n\n- So + adjective/adverb + that (so effective that)\n- Such + (a/an) + adjective + noun + that (such good memory that)\n- Shows strong cause and effect relationship\n- So is used with adjectives/adverbs\n- Such is used with nouns\n- That introduces the result clause", "examples": ["The method was so effective that I improved quickly.", "She has such good memory that she learns fast.", "The style was so different that it changed my approach.", "It was such a good method that everyone improved.", "I was so focused that I finished early."]}'::jsonb)
    RETURNING id INTO activity_id_var;

    -- 7. Grammar Sentences #1
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 7, 'Build Sentences 1', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'The method was so effective that I improved quickly', 'The method was so effective that I improved quickly.', '["The", "method", "was", "so", "effective", "that", "I", "improved", "quickly."]'::jsonb),
    (activity_id_var, 'She has such good memory that she learns fast', 'She has such good memory that she learns fast.', '["She", "has", "such", "good", "memory", "that", "she", "learns", "fast."]'::jsonb);

    -- 8. Grammar Sentences #2
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 8, 'Build Sentences 2', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'The style was so different that it changed my approach', 'The style was so different that it changed my approach.', '["The", "style", "was", "so", "different", "that", "it", "changed", "my", "approach."]'::jsonb),
    (activity_id_var, 'It was such a good method that everyone improved', 'It was such a good method that everyone improved.', '["It", "was", "such", "a", "good", "method", "that", "everyone", "improved."]'::jsonb);

    -- 9. Speaking Practice
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'speaking_practice', 9, 'Discuss Study Habits', 'Practice talking about how you learn', '{"prompts": ["How do you study best?", "When do you change your study method?", "Who helps you learn?", "What learning style works for you?", "How do you adapt to different teaching methods?"]}'::jsonb)
    RETURNING id INTO activity_id_var;

    -- 10. Speaking Improvement
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'speaking_improvement', 10, 'Speaking Improvement', 'Read the improved version of your speech', '{"type": "speaking_improvement", "similarityThreshold": 70}'::jsonb)
    RETURNING id INTO activity_id_var;
END $$;