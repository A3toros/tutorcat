-- =========================================
-- Pre-fill Database with Sample Lesson Data
-- B2-L76: Media influence on youth
-- =========================================

DELETE FROM grammar_sentences WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'B2-L76');
DELETE FROM vocabulary_items WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'B2-L76');
DELETE FROM lesson_activities WHERE lesson_id = 'B2-L76';
DELETE FROM lessons WHERE id = 'B2-L76';

INSERT INTO lessons (id, level, lesson_number, topic) VALUES
('B2-L76', 'B2', 76, 'Media influence on youth')
ON CONFLICT (id) DO UPDATE SET topic = EXCLUDED.topic;

DO $$
DECLARE
    lesson_id_var TEXT := 'B2-L76';
    activity_id_var UUID;
BEGIN
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'warm_up_speaking', 1, 'Youth Trends', 'Talk about guiding younger students', '{"prompt": "Where do you set limits, and how do you counter trends?"}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_intro', 2, 'Influence Words', 'Key words for trends and safeguards', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'impressionable', 'หวั่นไหว/ง่ายต่อการได้รับอิทธิพล', NULL),
    (activity_id_var, 'trend', 'กระแส/แนวโน้ม', NULL),
    (activity_id_var, 'safeguard', 'ป้องกัน/คุ้มครอง', NULL),
    (activity_id_var, 'exposure', 'การสัมผัส/รับข้อมูล', NULL),
    (activity_id_var, 'counter', 'ต่อต้าน/รับมือ', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_matching_drag', 3, 'Match Influence Words', 'Match words with meanings', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'impressionable', 'หวั่นไหว/ง่ายต่อการได้รับอิทธิพล', NULL),
    (activity_id_var, 'trend', 'กระแส/แนวโน้ม', NULL),
    (activity_id_var, 'safeguard', 'ป้องกัน/คุ้มครอง', NULL),
    (activity_id_var, 'exposure', 'การสัมผัส/รับข้อมูล', NULL),
    (activity_id_var, 'counter', 'ต่อต้าน/รับมือ', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 4, 'Complete the Sentences 1', 'Fill with the correct word', '{"text": "Young students are ___. A strong ___ can ___ risky ___.", "blanks": [{"id": "blank1", "text": "impressionable", "options": ["impressionable", "safeguard", "counter", "trend"], "correctAnswer": "impressionable"}, {"id": "blank2", "text": "safeguard", "options": ["safeguard", "trend", "exposure", "counter"], "correctAnswer": "safeguard"}, {"id": "blank3", "text": "counter", "options": ["counter", "exposure", "safeguard", "trend"], "correctAnswer": "counter"}, {"id": "blank4", "text": "exposure", "options": ["exposure", "trend", "impressionable", "safeguard"], "correctAnswer": "exposure"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 5, 'Complete the Sentences 2', 'Fill with the correct word', '{"text": "We watch each ___.", "blanks": [{"id": "blank1", "text": "trend", "options": ["trend", "exposure", "safeguard", "counter"], "correctAnswer": "trend"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_explanation', 6, 'Contrast & Concession (whereas/however)', 'Compare limits and exposure', '{"rules": "Use whereas to contrast two subjects; however to contrast sentences.\\n- We set limits for younger students, whereas older ones self-manage.\\n- We allow discussion; however, we review sources.", "examples": ["We set stricter safeguards for younger students, whereas older ones self-manage.", "We allow open chats; however, we check sources.", "Younger students are impressionable, whereas mentors counter trends.", "We limit exposure; however, we teach critical reading.", "Trends spread fast; however, guidance slows risks."]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 7, 'Build Sentences 1', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'We set stricter safeguards for younger students, whereas older ones self-manage', 'We set stricter safeguards for younger students, whereas older ones self-manage.', '["We", "set", "stricter", "safeguards", "for", "younger", "students,", "whereas", "older", "ones", "self-manage."]'::jsonb),
    (activity_id_var, 'We allow open chats; however, we check sources', 'We allow open chats; however, we check sources.', '["We", "allow", "open", "chats;", "however,", "we", "check", "sources."]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 8, 'Build Sentences 2', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'Younger students are impressionable, whereas mentors counter trends', 'Younger students are impressionable, whereas mentors counter trends.', '["Younger", "students", "are", "impressionable,", "whereas", "mentors", "counter", "trends."]'::jsonb),
    (activity_id_var, 'We limit exposure; however, we teach critical reading', 'We limit exposure; however, we teach critical reading.', '["We", "limit", "exposure;", "however,", "we", "teach", "critical", "reading."]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'speaking_practice', 9, 'Talk About Youth Influence', 'Practice contrast', '{"prompts": ["Where do you set limits for younger students?", "How do you counter fast trends?", "When do you allow more exposure?"]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (
      lesson_id,
      activity_type,
      activity_order,
      title,
      description,
      content
    ) VALUES (
      'B2-L76',
      'speaking_improvement',
      10,
      'Speaking Improvement',
      'Read the improved version of your speech',
      '{"type": "speaking_improvement", "similarityThreshold": 70}'::jsonb
    );
END $$;


