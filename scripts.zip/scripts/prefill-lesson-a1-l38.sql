-- =========================================
-- Pre-fill Database with Sample Lesson Data
-- A1-L38: Shopping for Clothes
-- =========================================

DELETE FROM grammar_sentences WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'A1-L38');
DELETE FROM vocabulary_items WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'A1-L38');
DELETE FROM lesson_activities WHERE lesson_id = 'A1-L38';
DELETE FROM lessons WHERE id = 'A1-L38';

INSERT INTO lessons (id, level, lesson_number, topic) VALUES
('A1-L38', 'A1', 38, 'Shopping for Clothes')
ON CONFLICT (id) DO UPDATE SET topic = EXCLUDED.topic;

DO $$
DECLARE
    lesson_id_var TEXT := 'A1-L38';
    activity_id_var UUID;
BEGIN
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'warm_up_speaking', 1, 'Clothes Shop', 'Talk about buying clothes', '{"prompt": "Can I try this?"}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_intro', 2, 'Shop Words', 'Learn shopping words', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'size', 'ขนาด', NULL),
    (activity_id_var, 'try', 'ลอง', NULL),
    (activity_id_var, 'buy', 'ซื้อ', NULL),
    (activity_id_var, 'shirt', 'เสื้อ', NULL),
    (activity_id_var, 'pay', 'จ่าย', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_matching_drag', 3, 'Match Shop Words', 'Match shopping words', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'size', 'ขนาด', NULL),
    (activity_id_var, 'try', 'ลอง', NULL),
    (activity_id_var, 'buy', 'ซื้อ', NULL),
    (activity_id_var, 'shirt', 'เสื้อ', NULL),
    (activity_id_var, 'pay', 'จ่าย', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 4, 'Complete the Sentences 1', 'Fill with the correct word', '{"text": "Can I ___ this shirt? What ___ is it?", "blanks": [{"id": "blank1", "text": "try", "options": ["try", "buy", "pay", "size"], "correctAnswer": "try"}, {"id": "blank2", "text": "size", "options": ["size", "try", "buy", "pay"], "correctAnswer": "size"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 5, 'Complete the Sentences 2', 'Fill with the correct word', '{"text": "I want to ___. Where do I ___?", "blanks": [{"id": "blank1", "text": "buy", "options": ["buy", "try", "size", "shirt"], "correctAnswer": "buy"}, {"id": "blank2", "text": "pay", "options": ["pay", "buy", "try", "shirt"], "correctAnswer": "pay"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_explanation', 6, 'Can (requests)', 'Ask for help in a shop', '{"rules": "Use can to ask politely.\n- Can I try this?\n- Can I pay here?\nShort answers: Yes, you can.", "examples": ["Can I try this shirt?", "Can I see this size?", "Can I pay here?", "Can I buy this now?", "Can you help me?"]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 7, 'Build Sentences 1', 'Arrange words', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'Can I try this shirt', 'Can I try this shirt?', '["Can", "I", "try", "this", "shirt?"]'::jsonb),
    (activity_id_var, 'Can I pay here', 'Can I pay here?', '["Can", "I", "pay", "here?"]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 8, 'Build Sentences 2', 'Arrange words', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'Can I see this size', 'Can I see this size?', '["Can", "I", "see", "this", "size?"]'::jsonb),
    (activity_id_var, 'Can you help me', 'Can you help me?', '["Can", "you", "help", "me?"]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'speaking_practice', 9, 'Talk in a Clothes Shop', 'Practice polite requests', '{"prompts": ["Can I try this?", "Can I see this size?", "Can I pay here?", "Do you like this shirt?", "Do you want to buy it?"]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (
      lesson_id,
      activity_type,
      activity_order,
      title,
      description,
      content
    ) VALUES (
      'A1-L38',
      'speaking_improvement',
      10,
      'Speaking Improvement',
      'Read the improved version of your speech',
      '{"type": "speaking_improvement", "similarityThreshold": 70}'::jsonb
    );
END $$;

