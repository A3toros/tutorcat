-- =========================================
-- Pre-fill Database with Sample Lesson Data
-- B2-L78: Cultural misunderstandings
-- =========================================

DELETE FROM grammar_sentences WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'B2-L78');
DELETE FROM vocabulary_items WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'B2-L78');
DELETE FROM lesson_activities WHERE lesson_id = 'B2-L78';
DELETE FROM lessons WHERE id = 'B2-L78';

INSERT INTO lessons (id, level, lesson_number, topic) VALUES
('B2-L78', 'B2', 78, 'Cultural misunderstandings')
ON CONFLICT (id) DO UPDATE SET topic = EXCLUDED.topic;

DO $$
DECLARE
    lesson_id_var TEXT := 'B2-L78';
    activity_id_var UUID;
BEGIN
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'warm_up_speaking', 1, 'Fixing Misreads', 'Talk about clarifying culture', '{"prompt": "What could you have asked sooner, and how did you repair it?"}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_intro', 2, 'Misunderstanding Words', 'Key words for clarifying intent', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'clarify', 'ทำให้ชัดเจน', NULL),
    (activity_id_var, 'offend', 'ทำให้ไม่พอใจ', NULL),
    (activity_id_var, 'intent', 'เจตนา', NULL),
    (activity_id_var, 'repair', 'แก้ไข/ฟื้นความสัมพันธ์', NULL),
    (activity_id_var, 'apology', 'คำขอโทษ', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_matching_drag', 3, 'Match Misunderstanding Words', 'Match words with meanings', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'clarify', 'ทำให้ชัดเจน', NULL),
    (activity_id_var, 'offend', 'ทำให้ไม่พอใจ', NULL),
    (activity_id_var, 'intent', 'เจตนา', NULL),
    (activity_id_var, 'repair', 'แก้ไข/ฟื้นความสัมพันธ์', NULL),
    (activity_id_var, 'apology', 'คำขอโทษ', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 4, 'Complete the Sentences 1', 'Fill with the correct word', '{"text": "I asked to ___. I did not mean to ___. I explained my ___.", "blanks": [{"id": "blank1", "text": "clarify", "options": ["clarify", "offend", "repair", "apology"], "correctAnswer": "clarify"}, {"id": "blank2", "text": "offend", "options": ["offend", "intent", "clarify", "repair"], "correctAnswer": "offend"}, {"id": "blank3", "text": "intent", "options": ["intent", "apology", "clarify", "offend"], "correctAnswer": "intent"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 5, 'Complete the Sentences 2', 'Fill with the correct word', '{"text": "A short ___ helped ___.", "blanks": [{"id": "blank1", "text": "apology", "options": ["apology", "repair", "clarify", "offend"], "correctAnswer": "apology"}, {"id": "blank2", "text": "repair", "options": ["repair", "apology", "intent", "clarify"], "correctAnswer": "repair"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_explanation', 6, 'Past Modals (could have / should have)', 'Reflect on missed questions', '{"rules": "Use could have for missed possibilities; should have for advice/regret.\\n- I could have asked sooner.\\n- I should have clarified the gesture.\\nUse might have for uncertain past possibility.", "examples": ["I could have asked what that gesture meant.", "I should have clarified the intent earlier.", "She could have apologized sooner to repair trust.", "We should have checked before reacting.", "They might have avoided offense with a quick question."]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 7, 'Build Sentences 1', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'I could have asked what that gesture meant', 'I could have asked what that gesture meant.', '["I", "could", "have", "asked", "what", "that", "gesture", "meant."]'::jsonb),
    (activity_id_var, 'I should have clarified the intent earlier', 'I should have clarified the intent earlier.', '["I", "should", "have", "clarified", "the", "intent", "earlier."]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 8, 'Build Sentences 2', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'She could have apologized sooner to repair trust', 'She could have apologized sooner to repair trust.', '["She", "could", "have", "apologized", "sooner", "to", "repair", "trust."]'::jsonb),
    (activity_id_var, 'We should have checked before reacting', 'We should have checked before reacting.', '["We", "should", "have", "checked", "before", "reacting."]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'speaking_practice', 9, 'Talk About Misunderstandings', 'Practice past modals reflections', '{"prompts": ["What could you have asked sooner?", "When did an apology repair trust?", "How do you clarify intent when you offend someone?"]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (
      lesson_id,
      activity_type,
      activity_order,
      title,
      description,
      content
    ) VALUES (
      'B2-L78',
      'speaking_improvement',
      10,
      'Speaking Improvement',
      'Read the improved version of your speech',
      '{"type": "speaking_improvement", "similarityThreshold": 70}'::jsonb
    );
END $$;


