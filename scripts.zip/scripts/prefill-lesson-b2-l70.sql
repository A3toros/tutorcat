-- =========================================
-- Pre-fill Database with Sample Lesson Data
-- B2-L70: Travel and cultural understanding
-- =========================================

DELETE FROM grammar_sentences WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'B2-L70');
DELETE FROM vocabulary_items WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'B2-L70');
DELETE FROM lesson_activities WHERE lesson_id = 'B2-L70';
DELETE FROM lessons WHERE id = 'B2-L70';

INSERT INTO lessons (id, level, lesson_number, topic) VALUES
('B2-L70', 'B2', 70, 'Travel and cultural understanding')
ON CONFLICT (id) DO UPDATE SET topic = EXCLUDED.topic;

DO $$
DECLARE
    lesson_id_var TEXT := 'B2-L70';
    activity_id_var UUID;
BEGIN
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'warm_up_speaking', 1, 'Bridging Gaps', 'Talk about travel lessons', '{"prompt": "If you hadn’t traveled, how would views differ now, and what bridges gaps?"}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_intro', 2, 'Understanding Words', 'Key words for cultural insight', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'culture', 'วัฒนธรรม', NULL),
    (activity_id_var, 'insight', 'ข้อคิด/ความเข้าใจ', NULL),
    (activity_id_var, 'adapt', 'ปรับตัว', NULL),
    (activity_id_var, 'bridge', 'เชื่อม/เชื่อมความต่าง', NULL),
    (activity_id_var, 'misread', 'อ่านผิด/เข้าใจผิด', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_matching_drag', 3, 'Match Understanding Words', 'Match words with meanings', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'culture', 'วัฒนธรรม', NULL),
    (activity_id_var, 'insight', 'ข้อคิด/ความเข้าใจ', NULL),
    (activity_id_var, 'adapt', 'ปรับตัว', NULL),
    (activity_id_var, 'bridge', 'เชื่อม/เชื่อมความต่าง', NULL),
    (activity_id_var, 'misread', 'อ่านผิด/เข้าใจผิด', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 4, 'Complete the Sentences 1', 'Fill with the correct word', '{"text": "Travel gave me ___. I learned to ___. Stories help ___ gaps.", "blanks": [{"id": "blank1", "text": "insight", "options": ["insight", "culture", "bridge", "adapt"], "correctAnswer": "insight"}, {"id": "blank2", "text": "adapt", "options": ["adapt", "misread", "bridge", "culture"], "correctAnswer": "adapt"}, {"id": "blank3", "text": "bridge", "options": ["bridge", "culture", "insight", "adapt"], "correctAnswer": "bridge"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 5, 'Complete the Sentences 2', 'Fill with the correct word', '{"text": "I try not to ___ gestures. Each ___ has layers.", "blanks": [{"id": "blank1", "text": "misread", "options": ["misread", "adapt", "bridge", "insight"], "correctAnswer": "misread"}, {"id": "blank2", "text": "culture", "options": ["culture", "misread", "insight", "bridge"], "correctAnswer": "culture"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_explanation', 6, 'Mixed Conditionals', 'Link travel to present perspectives', '{"rules": "Use if + past perfect + would + base verb (now) to show past condition affecting present.\\n- If I hadn’t traveled, I would see things differently now.\\nUse if + past simple + would have + past participle for present condition affecting past result.", "examples": ["If I hadn’t traveled, I would miss these insights now.", "If we had stayed home, we would be less adaptable now.", "If you were less open, you would have misread more gestures.", "If they had bridged gaps earlier, they would be closer now.", "If she were abroad now, she would have learned new cues."]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 7, 'Build Sentences 1', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'If I hadn’t traveled, I would miss these insights now', 'If I hadn’t traveled, I would miss these insights now.', '["If", "I", "hadn’t", "traveled,", "I", "would", "miss", "these", "insights", "now."]'::jsonb),
    (activity_id_var, 'If we had stayed home, we would be less adaptable now', 'If we had stayed home, we would be less adaptable now.', '["If", "we", "had", "stayed", "home,", "we", "would", "be", "less", "adaptable", "now."]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 8, 'Build Sentences 2', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'If you were less open, you would have misread more gestures', 'If you were less open, you would have misread more gestures.', '["If", "you", "were", "less", "open,", "you", "would", "have", "misread", "more", "gestures."]'::jsonb),
    (activity_id_var, 'If they had bridged gaps earlier, they would be closer now', 'If they had bridged gaps earlier, they would be closer now.', '["If", "they", "had", "bridged", "gaps", "earlier,", "they", "would", "be", "closer", "now."]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'speaking_practice', 9, 'Talk About Travel Insights', 'Practice mixed conditionals', '{"prompts": ["If you hadn’t traveled, how would your views differ now?", "What bridges gaps when cultures clash?", "When do you notice you misread a gesture?"]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (
      lesson_id,
      activity_type,
      activity_order,
      title,
      description,
      content
    ) VALUES (
      'B2-L70',
      'speaking_improvement',
      10,
      'Speaking Improvement',
      'Read the improved version of your speech',
      '{"type": "speaking_improvement", "similarityThreshold": 70}'::jsonb
    );
END $$;


