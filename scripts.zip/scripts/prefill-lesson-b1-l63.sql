-- ===== LESSON B1-L63 =====

-- =========================================
-- Pre-fill Database with Sample Lesson Data
-- B1-L63: Learning New Skills
-- =========================================

DELETE FROM lesson_activity_results WHERE lesson_id = 'B1-L63';
DELETE FROM user_progress WHERE lesson_id = 'B1-L63';
DELETE FROM lesson_history WHERE lesson_id = 'B1-L63';
DELETE FROM grammar_sentences WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'B1-L63');
DELETE FROM vocabulary_items WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'B1-L63');
DELETE FROM lesson_activities WHERE lesson_id = 'B1-L63';
DELETE FROM lessons WHERE id = 'B1-L63';

INSERT INTO lessons (id, level, lesson_number, topic) VALUES
('B1-L63', 'B1', 63, 'Learning New Skills')
ON CONFLICT (id) DO UPDATE SET topic = EXCLUDED.topic;

DO $$
DECLARE
    lesson_id_var TEXT := 'B1-L63';
    activity_id_var UUID;
BEGIN
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'warm_up_speaking', 1, 'Skill Development', 'Talk about learning new abilities', '{"prompt": "What skill are you trying to master right now?"}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_intro', 2, 'Learning Process Words', 'Learn words related to skill acquisition', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'practice', 'ฝึกฝน', NULL),
    (activity_id_var, 'attempt', 'พยายาม', NULL),
    (activity_id_var, 'master', 'เชี่ยวชาญ', NULL),
    (activity_id_var, 'struggle', 'ต่อสู้', NULL),
    (activity_id_var, 'repeat', 'ทำซ้ำ', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_matching_drag', 3, 'Match Learning Words', 'Match skill development words', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'practice', 'ฝึกฝน', NULL),
    (activity_id_var, 'attempt', 'พยายาม', NULL),
    (activity_id_var, 'master', 'เชี่ยวชาญ', NULL),
    (activity_id_var, 'struggle', 'ต่อสู้', NULL),
    (activity_id_var, 'repeat', 'ทำซ้ำ', NULL);

    -- 4. Vocabulary Fill Blanks #1
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 4, 'Complete the Sentences 1', 'Fill in the blanks with correct words', '{"text": "I ___ new skills every day. She ___ to learn the guitar. We ___ difficult tasks.", "blanks": [{"id": "blank1", "text": "practice", "options": ["practice", "attempt", "master", "struggle"], "correctAnswer": "practice"}, {"id": "blank2", "text": "attempts", "options": ["attempts", "practices", "masters", "struggles"], "correctAnswer": "attempts"}, {"id": "blank3", "text": "struggle", "options": ["struggle", "practice", "attempt", "master"], "correctAnswer": "struggle"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    -- 5. Vocabulary Fill Blanks #2
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 5, 'Complete the Sentences 2', 'Fill in the blanks with correct words', '{"text": "They want to ___ the skill. I ___ the exercise many times. She tries to ___ new techniques.", "blanks": [{"id": "blank1", "text": "master", "options": ["master", "practice", "attempt", "struggle"], "correctAnswer": "master"}, {"id": "blank2", "text": "repeat", "options": ["repeat", "practice", "attempt", "master"], "correctAnswer": "repeat"}, {"id": "blank3", "text": "master", "options": ["master", "practice", "attempt", "repeat"], "correctAnswer": "master"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    -- 6. Grammar Explanation
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_explanation', 6, 'Gerunds and Infinitives', 'Learn verb forms after other verbs', '{"rules": "Some verbs are followed by gerunds (-ing), others by infinitives (to + verb):\n\n- Gerunds after: enjoy, avoid, finish (I enjoy practicing)\n- Infinitives after: hope, want, decide (She hopes to master)\n- Some verbs can use both with different meanings\n- Practice with common verb patterns", "examples": ["I enjoy practicing new skills.", "She hopes to master the guitar.", "They avoid struggling with difficult tasks.", "We want to learn quickly.", "He finishes practicing at 5pm."]}'::jsonb)
    RETURNING id INTO activity_id_var;

    -- 7. Grammar Sentences #1
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 7, 'Build Sentences 1', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'I enjoy practicing new skills', 'I enjoy practicing new skills.', '["I", "enjoy", "practicing", "new", "skills."]'::jsonb),
    (activity_id_var, 'She hopes to master the guitar', 'She hopes to master the guitar.', '["She", "hopes", "to", "master", "the", "guitar."]'::jsonb);

    -- 8. Grammar Sentences #2
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 8, 'Build Sentences 2', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'They avoid struggling with difficult tasks', 'They avoid struggling with difficult tasks.', '["They", "avoid", "struggling", "with", "difficult", "tasks."]'::jsonb),
    (activity_id_var, 'We want to learn quickly', 'We want to learn quickly.', '["We", "want", "to", "learn", "quickly."]'::jsonb);

    -- 9. Speaking Practice
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'speaking_practice', 9, 'Talk About Learning', 'Practice talking about school and studying', '{"prompts": ["What subject do you like best?", "Who helps you with homework?", "What do you do when you don''t understand?", "What skill are you trying to learn?", "How do you practice new skills?"]}'::jsonb)
    RETURNING id INTO activity_id_var;

    -- 10. Speaking Improvement
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'speaking_improvement', 10, 'Speaking Improvement', 'Read the improved version of your speech', '{"type": "speaking_improvement", "similarityThreshold": 70}'::jsonb)
    RETURNING id INTO activity_id_var;
END $$;