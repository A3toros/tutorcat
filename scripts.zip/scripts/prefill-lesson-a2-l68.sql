-- =========================================
-- Pre-fill Database with Sample Lesson Data
-- A2-L68: Talking About Stress
-- =========================================

DELETE FROM grammar_sentences WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'A2-L68');
DELETE FROM vocabulary_items WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'A2-L68');
DELETE FROM lesson_activities WHERE lesson_id = 'A2-L68';
DELETE FROM lessons WHERE id = 'A2-L68';

INSERT INTO lessons (id, level, lesson_number, topic) VALUES
('A2-L68', 'A2', 68, 'Talking About Stress')
ON CONFLICT (id) DO UPDATE SET topic = EXCLUDED.topic;

DO $$
DECLARE
    lesson_id_var TEXT := 'A2-L68';
    activity_id_var UUID;
BEGIN
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'warm_up_speaking', 1, 'Stress Talk', 'Talk about feeling stressed', '{"prompt": "Why do people feel stressed?"}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_intro', 2, 'Stress Words', 'Learn words about stress', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'stress', 'ความเครียด', NULL),
    (activity_id_var, 'reason', 'เหตุผล', NULL),
    (activity_id_var, 'because', 'เพราะว่า', NULL),
    (activity_id_var, 'so', 'ดังนั้น', NULL),
    (activity_id_var, 'break', 'พัก', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_matching_drag', 3, 'Match Stress Words', 'Match stress words', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'stress', 'ความเครียด', NULL),
    (activity_id_var, 'reason', 'เหตุผล', NULL),
    (activity_id_var, 'because', 'เพราะว่า', NULL),
    (activity_id_var, 'so', 'ดังนั้น', NULL),
    (activity_id_var, 'break', 'พัก', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 4, 'Complete the Sentences 1', 'Fill with the correct word', '{"text": "I feel ___ because of work. I take a ___.", "blanks": [{"id": "blank1", "text": "stressed", "options": ["stressed", "reason", "break", "because"], "correctAnswer": "stressed"}, {"id": "blank2", "text": "break", "options": ["break", "because", "reason", "so"], "correctAnswer": "break"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 5, 'Complete the Sentences 2', 'Fill with the correct word', '{"text": "The ___ is traffic. I feel calm ___ I breathe slowly.", "blanks": [{"id": "blank1", "text": "reason", "options": ["reason", "stress", "break", "because"], "correctAnswer": "reason"}, {"id": "blank2", "text": "because", "options": ["because", "so", "reason", "break"], "correctAnswer": "because"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_explanation', 6, 'Because / So', 'Explain reasons and results', '{"rules": "Use because for reasons; so for results.\n- I feel stressed because of work.\n- I feel stressed, so I take a break.\nDo not use because and so in the same clause.", "examples": ["I feel stressed because of work.", "It is noisy, so I can''t focus.", "I take a walk because it helps me.", "I was late, so I missed the bus.", "We rest because we are tired."]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 7, 'Build Sentences 1', 'Arrange words', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'I feel stressed because of work', 'I feel stressed because of work.', '["I", "feel", "stressed", "because", "of", "work."]'::jsonb),
    (activity_id_var, 'It is noisy so I can t focus', 'It is noisy, so I can''t focus.', '["It", "is", "noisy,", "so", "I", "can''t", "focus."]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 8, 'Build Sentences 2', 'Arrange words', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'I take a walk because it helps me', 'I take a walk because it helps me.', '["I", "take", "a", "walk", "because", "it", "helps", "me."]'::jsonb),
    (activity_id_var, 'I was late so I missed the bus', 'I was late, so I missed the bus.', '["I", "was", "late,", "so", "I", "missed", "the", "bus."]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'speaking_practice', 9, 'Talk About Stress', 'Practice reasons and results', '{"prompts": ["Why do people feel stressed?", "I feel stressed because…", "What do you do, so you feel calmer?", "Who helps you when you feel stressed?", "What situations cause stress?"]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (
      lesson_id,
      activity_type,
      activity_order,
      title,
      description,
      content
    ) VALUES (
      'A2-L68',
      'speaking_improvement',
      10,
      'Speaking Improvement',
      'Read the improved version of your speech',
      '{"type": "speaking_improvement", "similarityThreshold": 70}'::jsonb
    );
END $$;

