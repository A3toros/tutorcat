-- ===== LESSON B2-L57 =====

-- =========================================
-- Pre-fill Database with Sample Lesson Data
-- B2-L57: Daily responsibilities
-- =========================================

DELETE FROM lesson_activity_results WHERE lesson_id = 'B2-L57';
DELETE FROM user_progress WHERE lesson_id = 'B2-L57';
DELETE FROM lesson_history WHERE lesson_id = 'B2-L57';
DELETE FROM grammar_sentences WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'B2-L57');
DELETE FROM vocabulary_items WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'B2-L57');
DELETE FROM lesson_activities WHERE lesson_id = 'B2-L57';
DELETE FROM lessons WHERE id = 'B2-L57';

INSERT INTO lessons (id, level, lesson_number, topic) VALUES
('B2-L57', 'B2', 57, 'Daily responsibilities')
ON CONFLICT (id) DO UPDATE SET topic = EXCLUDED.topic;

DO $$
DECLARE
    lesson_id_var TEXT := 'B2-L57';
    activity_id_var UUID;
BEGIN
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'warm_up_speaking', 1, 'Task Management', 'Talk about managing daily responsibilities', '{"prompt": "What should you have done yesterday?"}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_intro', 2, 'Responsibility Words', 'Learn words related to daily tasks', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'assign', 'มอบหมาย', NULL),
    (activity_id_var, 'remind', 'เตือน', NULL),
    (activity_id_var, 'overdue', 'เกินกำหนด', NULL),
    (activity_id_var, 'routine', 'กิจวัตร', NULL),
    (activity_id_var, 'checklist', 'รายการตรวจสอบ', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_matching_drag', 3, 'Match Responsibility Words', 'Match words related to tasks', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'assign', 'มอบหมาย', NULL),
    (activity_id_var, 'remind', 'เตือน', NULL),
    (activity_id_var, 'overdue', 'เกินกำหนด', NULL),
    (activity_id_var, 'routine', 'กิจวัตร', NULL),
    (activity_id_var, 'checklist', 'รายการตรวจสอบ', NULL);

    -- 4. Vocabulary Fill Blanks #1
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 4, 'Complete the Sentences 1', 'Fill in the blanks with correct words', '{"text": "I will ___ you a task. Please ___ me tomorrow. This task is ___.", "blanks": [{"id": "blank1", "text": "assign", "options": ["assign", "remind", "overdue", "routine"], "correctAnswer": "assign"}, {"id": "blank2", "text": "remind", "options": ["remind", "assign", "overdue", "checklist"], "correctAnswer": "remind"}, {"id": "blank3", "text": "overdue", "options": ["overdue", "assign", "remind", "routine"], "correctAnswer": "overdue"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    -- 5. Vocabulary Fill Blanks #2
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 5, 'Complete the Sentences 2', 'Fill in the blanks with correct words', '{"text": "I have a daily ___. Check your ___. Follow the ___.", "blanks": [{"id": "blank1", "text": "routine", "options": ["routine", "assign", "remind", "overdue"], "correctAnswer": "routine"}, {"id": "blank2", "text": "checklist", "options": ["checklist", "assign", "remind", "routine"], "correctAnswer": "checklist"}, {"id": "blank3", "text": "checklist", "options": ["checklist", "routine", "assign", "remind"], "correctAnswer": "checklist"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    -- 6. Grammar Explanation
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_explanation', 6, 'Past Modals (should have/could have)', 'Learn should have/could have for past regrets', '{"rules": "Use past modals to talk about past regrets or missed opportunities:\n\n- Should have = something you should have done but didn''t (I should have completed)\n- Could have = something you could have done but didn''t (She could have reminded)\n- Form: should/could + have + past participle\n- Expresses regret or criticism about the past\n- Use for things that didn''t happen but should/could have", "examples": ["I should have completed the task yesterday.", "She could have reminded me about the deadline.", "They should have checked the checklist.", "I could have finished earlier.", "You should have asked for help."]}'::jsonb)
    RETURNING id INTO activity_id_var;

    -- 7. Grammar Sentences #1
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 7, 'Build Sentences 1', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'I should have completed the task yesterday', 'I should have completed the task yesterday.', '["I", "should", "have", "completed", "the", "task", "yesterday."]'::jsonb),
    (activity_id_var, 'She could have reminded me about the deadline', 'She could have reminded me about the deadline.', '["She", "could", "have", "reminded", "me", "about", "the", "deadline."]'::jsonb);

    -- 8. Grammar Sentences #2
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 8, 'Build Sentences 2', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'They should have checked the checklist', 'They should have checked the checklist.', '["They", "should", "have", "checked", "the", "checklist."]'::jsonb),
    (activity_id_var, 'I could have finished earlier', 'I could have finished earlier.', '["I", "could", "have", "finished", "earlier."]'::jsonb);

    -- 9. Speaking Practice
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'speaking_practice', 9, 'Talk About Tasks', 'Practice talking about daily tasks', '{"prompts": ["What do you do after school?", "Who helps you with chores?", "When do you do your homework?", "What should you have done yesterday?", "What tasks are overdue?"]}'::jsonb)
    RETURNING id INTO activity_id_var;

    -- 10. Speaking Improvement
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'speaking_improvement', 10, 'Speaking Improvement', 'Read the improved version of your speech', '{"type": "speaking_improvement", "similarityThreshold": 70}'::jsonb)
    RETURNING id INTO activity_id_var;
END $$;