# B2 Speaking Prompts

This file contains all warm-up and speaking practice prompts for B2 lessons.

---

## Lesson 1: Technology & Society

**Warm-up Prompt:**

When does technology really help you in a normal day?

**Speaking Practice Prompts:**

- When does technology help you learn faster?
- What data about you do you really want private?
- How do you limit your screen time on busy days?

---

## Lesson 2: Environment & Climate

**Warm-up Prompt:**

What small habit do you keep to be eco-friendly?

**Speaking Practice Prompts:**

- What small eco habit is easiest for you to keep?
- When did weather change your plans recently?
- How do you feel when others do not recycle?

---

## Lesson 3: Culture & Traditions

**Warm-up Prompt:**

Which family tradition do you enjoy most, and why?

**Speaking Practice Prompts:**

- Which tradition from your family do you want to keep?
- When did you last join a festival that felt special?
- How do you explain your culture to a friend from abroad?

---

## Lesson 4: Social Media & Communication

**Warm-up Prompt:**

What helps you keep messages clear online?

**Speaking Practice Prompts:**

- How do you avoid being misinterpreted online?
- When do you switch from text to a call?
- What helps you keep a healthy reach without stress?

---

## Lesson 5: Work–Life Balance

**Warm-up Prompt:**

When do you decide to stop working for the day?

**Speaking Practice Prompts:**

- When do you notice early signs of burnout?
- How do you protect downtime during exams?
- What routine helps you recharge fast?

---

## Lesson 6: Education Systems

**Warm-up Prompt:**

What school rule do you think is most helpful, and why?

**Speaking Practice Prompts:**

- What question would you ask about fees at a new school?
- How would you report a friend’s question about attendance?
- When do you ask for clearer assessment rules?

---

## Lesson 7: Global Travel & Tourism

**Warm-up Prompt:**

Where will you be traveling next, and why?

**Speaking Practice Prompts:**

- What will you be doing during your next layover?
- By the end of the trip, what will you have learned?
- How do you support the local economy when you travel?

---

## Lesson 8: Ethics in Daily Life

**Warm-up Prompt:**

When did you last choose to do the harder but right thing?

**Speaking Practice Prompts:**

- If your friend copied work, what would you do?
- When do you feel tempted to take shortcuts?
- How do you keep fairness in group projects?

---

## Lesson 9: News & Current Events

**Warm-up Prompt:**

Which source do you check first when news breaks?

**Speaking Practice Prompts:**

- How do you verify a headline before sharing?
- When have you noticed bias in a story?
- What should be done before posting news in a group chat?

---

## Lesson 10: Personal Development

**Warm-up Prompt:**

What recent habit changed you the most?

**Speaking Practice Prompts:**

- If you had more time last term, what would you have done?
- Who acted like a mentor for you, and how?
- What small milestone are you proud of?

---

## Lesson 11: Work–life balance

**Warm-up Prompt:**

Where do you see your balance in a year, and what will change?

**Speaking Practice Prompts:**

- Where will you be resting this weekend?
- What will you have changed about your pace by next month?
- Who keeps you accountable for balance?

---

## Lesson 12: Choosing a university or course

**Warm-up Prompt:**

How long have you been researching schools, and what have you ruled out?

**Speaking Practice Prompts:**

- How long have you been researching schools?
- What have you ruled out so far, and why?
- Who helps you compare prospectuses?

---

## Lesson 13: Mental health among students

**Warm-up Prompt:**

When do you switch off, and what do you drop first when stressed?

**Speaking Practice Prompts:**

- When do you switch off first?
- How do friends help you cope?
- What feels harder: asking for help or taking space?

---

## Lesson 14: Technology in studying

**Warm-up Prompt:**

What tool is so helpful you rely on it, and when is tech too much?

**Speaking Practice Prompts:**

- What tool is so helpful you rely on it daily?
- When is tech such a distraction you stop using it?
- How do you set limits with study apps?

---

## Lesson 15: Friendship in student life

**Warm-up Prompt:**

How can you tell a friend is stressed, and who notices first?

**Speaking Practice Prompts:**

- How can you tell a friend is stressed?
- Who notices your mood first?
- When do you reconnect after drifting?

---

## Lesson 16: Living independently as a student

**Warm-up Prompt:**

What had you learned before moving out, and what surprised you?

**Speaking Practice Prompts:**

- What had you prepared before moving out?
- What surprised you after you moved?
- Who helped when repairs were needed?

---

## Lesson 17: Travel experiences as a student

**Warm-up Prompt:**

If you had more time, where would you go, and with whom?

**Speaking Practice Prompts:**

- If you had one extra day, where would you go?
- Who would you travel with and why?
- What would you change on your last trip?

---

## Lesson 18: Media and student opinions

**Warm-up Prompt:**

Never have you what… when reading news, and who challenges your view?

**Speaking Practice Prompts:**

- Never have you what… when reading news?
- Who challenges your views the most?
- How do you verify before you comment?

---

## Lesson 19: Personal values

**Warm-up Prompt:**

What value, which you keep, guides you daily, and when was it tested?

**Speaking Practice Prompts:**

- Which value, which you keep, guides you daily?
- Who in your life, who you admire, models that value?
- When was your value tested recently?

---

## Lesson 20: Academic stress and burnout

**Warm-up Prompt:**

How long have you managed stress this way, and who checks in on you?

**Speaking Practice Prompts:**

- How long have you managed stress this way?
- Who checks in on you when work piles up?
- What will you change about your pace next month?

---

## Lesson 21: Studying abroad experiences

**Warm-up Prompt:**

What did you ask hosts before arriving, and who helped you settle?

**Speaking Practice Prompts:**

- What did you ask before arriving?
- Who helped you settle in the first week?
- How do you describe feeling homesick to friends?

---

## Lesson 22: Stress management strategies

**Warm-up Prompt:**

What had you tried before these stress tactics, and what worked?

**Speaking Practice Prompts:**

- What had you tried before this routine?
- Which trigger had you ignored before learning about it?
- How had you been taking breaks before exams?

---

## Lesson 23: Online research skills

**Warm-up Prompt:**

When do you trust a source, and where does bias hide?

**Speaking Practice Prompts:**

- When do you trust a source?
- Where does bias hide in your feeds?
- How do you verify before you cite?

---

## Lesson 24: Making new friends

**Warm-up Prompt:**

What should be shared early, and how should contact be kept?

**Speaking Practice Prompts:**

- What should be shared early when you meet?
- How should contact be kept respectful?
- When must a follow-up be sent?

---

## Lesson 25: Managing money as a student

**Warm-up Prompt:**

How will you be tracking spending next month, and what will you cut?

**Speaking Practice Prompts:**

- How will you be tracking spending next month?
- What will you be cutting first?
- When will you be adding to savings?

---

## Lesson 26: Cultural differences

**Warm-up Prompt:**

What difference was so big you paused, and who explained it?

**Speaking Practice Prompts:**

- What difference was so big you paused?
- Who explained a gesture to you?
- When did you adapt faster than you expected?

---

## Lesson 27: News consumption habits

**Warm-up Prompt:**

What were you told to check before sharing, and who sets your news routine?

**Speaking Practice Prompts:**

- What were you told to check before sharing?
- Who sets your news routine?
- What advice about alerts do you repeat?

---

## Lesson 28: Sleep and productivity

**Warm-up Prompt:**

How can you tell you slept well, and what might ruin your focus?

**Speaking Practice Prompts:**

- How can you tell you slept well?
- What might ruin your focus tomorrow?
- When do you decide to nap?

---

## Lesson 29: Online information reliability

**Warm-up Prompt:**

What signals, which you trust, prove credibility, and when do you flag a post?

**Speaking Practice Prompts:**

- What signals, which you trust, prove credibility?
- When do you flag a post?
- Who in your circle, who you trust, helps verify?

---

## Lesson 30: Balancing study and personal life

**Warm-up Prompt:**

If you hadn’t changed a habit, what would your balance be now?

**Speaking Practice Prompts:**

- If you hadn’t changed a habit, what would your balance be now?
- If you had planned rest sooner, what would have changed?
- If your workload had been lighter, what would you have done?

---

## Lesson 31: Healthy lifestyle for students

**Warm-up Prompt:**

How have you kept energy up lately, and what habit sticks?

**Speaking Practice Prompts:**

- What habit is so effective you keep it daily?
- When was a day so long that you crashed?
- How do you stay consistent during exams?

---

## Lesson 32: Using AI and digital tools for learning

**Warm-up Prompt:**

If AI failed mid-project, what would you do, and who would you ask for review?

**Speaking Practice Prompts:**

- If AI failed mid-project, what would you do?
- Who would you ask to review outputs?
- When would you pause a tool because of misuse?

---

## Lesson 33: Communication in groups

**Warm-up Prompt:**

What keeps meetings so clear that no one is lost, and when do you step back?

**Speaking Practice Prompts:**

- What keeps meetings so clear that no one is lost?
- When do you step back to let others speak?
- How do you clarify when consensus feels stuck?

---

## Lesson 34: Budgeting basics

**Warm-up Prompt:**

How long have you tracked spending, and what do you tweak?

**Speaking Practice Prompts:**

- How long have you tracked spending?
- What have you tweaked recently?
- Where have you been overspending?

---

## Lesson 35: Exercise and mental focus

**Warm-up Prompt:**

How can you tell a workout helps focus, and when must you rest?

**Speaking Practice Prompts:**

- How can you tell a workout helps focus?
- When must you rest?
- Who checks your intensity when you train?

---

## Lesson 36: Coping with failure

**Warm-up Prompt:**

Although it failed, what did you learn, and what did you change?

**Speaking Practice Prompts:**

- Although it failed, what did you learn?
- What did you change after feedback?
- When did a redo work better?

---

## Lesson 37: Personal achievements

**Warm-up Prompt:**

What should you have celebrated more, and what could you still improve?

**Speaking Practice Prompts:**

- What should you have celebrated more?
- What could you still improve now?
- Who could have helped you sooner?

---

## Lesson 38: Making important decisions

**Warm-up Prompt:**

Rarely do you decide fast—when did you, and who helped?

**Speaking Practice Prompts:**

- Rarely do you decide fast—when did you?
- Who helps you weigh options?
- What choice have you seldom regretted?

---

## Lesson 39: Sharing accommodation

**Warm-up Prompt:**

If chores were clearer, how would life look now, and what boundary matters?

**Speaking Practice Prompts:**

- If chores were clearer, how would life look now?
- What boundary matters most to you?
- If bills had been split fairly, how would trust be now?

---

## Lesson 40: Work–life balance (boundaries)

**Warm-up Prompt:**

What should be protected, what must be flexible, and who enforces it?

**Speaking Practice Prompts:**

- What should be protected in your schedule?
- What must stay flexible?
- Who enforces the norms in your group?

---

## Lesson 41: Screen time and concentration

**Warm-up Prompt:**

How have you managed notifications, and what keeps you focused?

**Speaking Practice Prompts:**

- How have you managed notifications this term?
- When do you do a screen detox?
- Who keeps you accountable for limits?

---

## Lesson 42: Peer pressure

**Warm-up Prompt:**

Who helps you resist, when do you feel pushback, and how do you stay assertive?

**Speaking Practice Prompts:**

- Who helps you resist?
- When do you feel pushback?
- What boundary do you keep even if others conform?

---

## Lesson 43: Sleep and productivity (signals)

**Warm-up Prompt:**

What signals poor sleep, and how can you tell you’re alert?

**Speaking Practice Prompts:**

- What signals poor sleep for you?
- How can you tell you are alert?
- When do you decide to nap?

---

## Lesson 44: Living in another country

**Warm-up Prompt:**

If you moved today, what would you do first, and who would you lean on?

**Speaking Practice Prompts:**

- If you moved today, what would you do first?
- Who would you lean on in a new country?
- How would you build a routine to avoid feeling homesick?

---

## Lesson 45: Responsible technology use

**Warm-up Prompt:**

What rule is so clear you always follow it, and how do you remind peers?

**Speaking Practice Prompts:**

- What rule is so clear you always follow it?
- How do you remind peers about policies?
- When is a limit so firm that you change habits?

---

## Lesson 46: Making new friends (habits)

**Warm-up Prompt:**

Where do you meet people, how do you keep conversations going, and what feels different online vs offline?

**Speaking Practice Prompts:**

- Where do you meet people?
- How do you keep conversations going?
- What feels different online vs offline for you?

---

## Lesson 47: Social media and distraction

**Warm-up Prompt:**

What should be limited or muted, and who keeps you accountable?

**Speaking Practice Prompts:**

- What should be limited or muted first?
- Who keeps you accountable for screen rules?
- When must alerts be turned off for you?

---

## Lesson 48: Assessments and grading systems

**Warm-up Prompt:**

How will you be graded this term, and what will you contest if unclear?

**Speaking Practice Prompts:**

- How will you be graded this term?
- What will you contest if unclear?
- When will you request a resit?

---

## Lesson 49: Cultural differences (signals)

**Warm-up Prompt:**

How can you tell you misread a norm, and who helps you adjust?

**Speaking Practice Prompts:**

- How can you tell you misread a norm?
- Who helps you adjust when you travel?
- What do you do when a gesture confuses you?

---

## Lesson 50: Group projects and teamwork

**Warm-up Prompt:**

What instructions did you get, and how do you report progress?

**Speaking Practice Prompts:**

- What instructions did you get for the project?
- How do you report progress to the group?
- What rule helps avoid overwriting work?

---

## Lesson 51: Conflict resolution among peers

**Warm-up Prompt:**

How do you solve problems with friends?

**Speaking Practice Prompts:**

- How do you solve problems with friends?
- What do you do when you disagree?
- Who helps you when you have arguments?
- How do you mediate conflicts?
- What skills have you been developing?

---

## Lesson 52: Financial responsibility

**Warm-up Prompt:**

How do you manage your money?

**Speaking Practice Prompts:**

- How do you save money?
- What do you buy with cash?
- Do you use credit cards?
- How do you track expenses?
- What financial plans do you have?

---

## Lesson 53: Travel and learning

**Warm-up Prompt:**

Tell me about an interesting place you visited.

**Speaking Practice Prompts:**

- What surprised you most when traveling?
- What new food did you try?
- Who did you meet on your trip?
- How did travel broaden your perspective?
- What insights did you gain from traveling?

---

## Lesson 54: Entertainment choices

**Warm-up Prompt:**

If you cut one platform, what changes?

**Speaking Practice Prompts:**

- What is your favorite TV show?
- Do you watch movies with your family?
- Who is your favorite movie star?
- What genre do you prefer?
- If you could only watch one show, what would it be?

---

## Lesson 55: Learning from experience

**Warm-up Prompt:**

Although it was hard, what did you learn?

**Speaking Practice Prompts:**

- What was your favorite subject?
- Who is your favorite teacher?
- What did you learn last week?
- What lesson did you learn from a difficult experience?
- How do you improve when things are hard?

---

## Lesson 56: Advertising influence

**Warm-up Prompt:**

How can you tell an ad is shaping you?

**Speaking Practice Prompts:**

- What food ads do you see?
- Do you buy things from ads?
- What drink commercials are funny?
- How do ads influence you?
- What makes an ad persuasive?

---

## Lesson 57: Daily responsibilities

**Warm-up Prompt:**

What should you have done yesterday?

**Speaking Practice Prompts:**

- What do you do after school?
- Who helps you with chores?
- When do you do your homework?
- What should you have done yesterday?
- What tasks are overdue?

---

## Lesson 58: City life vs small towns

**Warm-up Prompt:**

If you lived elsewhere, how would focus change now?

**Speaking Practice Prompts:**

- Do you live in a big city?
- Is there a farm near your town?
- What stores are in your neighborhood?
- Would you prefer city or small town life?
- How does where you live affect your lifestyle?

---

## Lesson 59: Learning styles (switching)

**Warm-up Prompt:**

Do you prefer reading or watching videos?

**Speaking Practice Prompts:**

- How do you study best?
- When do you change your study method?
- Who helps you learn?
- What learning style works for you?
- How do you adapt to different teaching methods?

---

## Lesson 60: Personal responsibility

**Warm-up Prompt:**

What tasks do you do at home?

**Speaking Practice Prompts:**

- What chores do you do?
- Who helps with family tasks?
- How do you help others?
- What are your duties at home?
- How do you uphold your responsibilities?

---

## Lesson 61: Student discounts and costs

**Warm-up Prompt:**

How have you been finding discounts, and what documents do you keep?

**Speaking Practice Prompts:**

- How have you been finding discounts?
- What documents do you keep for proof?
- When do you validate your pass?

---

## Lesson 62: City life vs small towns (deep)

**Warm-up Prompt:**

What had you underestimated about each, and what changed your mind?

**Speaking Practice Prompts:**

- What had you underestimated about city life?
- What changed your mind about small towns?
- Who helped you adjust to the pace?

---

## Lesson 63: Media and emotions

**Warm-up Prompt:**

What content was so intense you stopped, and what helps you reset?

**Speaking Practice Prompts:**

- What content was so intense you stopped?
- What helps you reset fast?
- When does media raise empathy for you?

---

## Lesson 64: Responsible media use

**Warm-up Prompt:**

Where do you draw the line, and how do you handle reports?

**Speaking Practice Prompts:**

- Where do you draw the line online?
- How do you handle reports in your groups?
- When do you ask for consent before sharing?

---

## Lesson 65: Planning for the future

**Warm-up Prompt:**

How little do others know about your plan B, and when do you pivot?

**Speaking Practice Prompts:**

- How little do others know about your plan B?
- When do you pivot your plans?
- What scenario surprised you recently?

---

## Lesson 66: Forming opinions

**Warm-up Prompt:**

How can you tell your view is solid, and what might change it?

**Speaking Practice Prompts:**

- How can you tell your view is solid?
- What might change your opinion?
- When do you revise a conclusion?

---

## Lesson 67: Online collaboration

**Warm-up Prompt:**

What must be versioned, and what should be shared early?

**Speaking Practice Prompts:**

- What must be versioned first?
- What should be shared early?
- Who must be notified of changes?

---

## Lesson 68: Freedom of expression

**Warm-up Prompt:**

What were you told about speech limits, and how do you keep nuance?

**Speaking Practice Prompts:**

- What were you told about speech limits?
- How do you keep nuance in debates?
- When do you report offensive posts?

---

## Lesson 69: Education and future success

**Warm-up Prompt:**

If you hadn’t chosen this major, then what, and what opportunity would you have missed?

**Speaking Practice Prompts:**

- If you hadn’t chosen this major, then what?
- What opportunity would you have missed?
- When would you pivot in the future?

---

## Lesson 70: Travel and cultural understanding

**Warm-up Prompt:**

If you hadn’t traveled, how would views differ now, and what bridges gaps?

**Speaking Practice Prompts:**

- If you hadn’t traveled, how would your views differ now?
- What bridges gaps when cultures clash?
- When do you notice you misread a gesture?

---

## Lesson 71: Public transport experiences

**Warm-up Prompt:**

What had you wished was announced, and how did you adapt?

**Speaking Practice Prompts:**

- What had you wished was announced sooner?
- How did you adapt when the route changed?
- When did a crowd surprise you?

---

## Lesson 72: Freedom of expression (campus)

**Warm-up Prompt:**

Share a case that, which you recall, felt fair or unfair, and who set the boundary?

**Speaking Practice Prompts:**

- Share a case that felt fair or unfair to you.
- Who set the boundary, which students debated?
- How do you keep nuance when topics offend some?

---

## Lesson 73: Handling responsibility

**Warm-up Prompt:**

How have you carried duties lately, and what keeps you consistent?

**Speaking Practice Prompts:**

- How have you carried duties lately?
- What keeps you consistent with standards?
- How do you prevent oversight in your team?

---

## Lesson 74: Long-term planning

**Warm-up Prompt:**

If plans changed tomorrow, what would you do first, and who would you call?

**Speaking Practice Prompts:**

- If plans changed tomorrow, what would you do first?
- Who would you call for help?
- What benchmark would you reset?

---

## Lesson 75: Travel challenges

**Warm-up Prompt:**

What challenge was so disruptive you changed plans, and how did you recover?

**Speaking Practice Prompts:**

- What challenge was so disruptive you changed plans?
- How did you recover after a delay?
- What backup plan kept you calm?

---

## Lesson 76: Media influence on youth

**Warm-up Prompt:**

Where do you set limits, and how do you counter trends?

**Speaking Practice Prompts:**

- Where do you set limits for younger students?
- How do you counter fast trends?
- When do you allow more exposure?

---

## Lesson 77: Social media influence

**Warm-up Prompt:**

What should be moderated or reported, and who enforces it?

**Speaking Practice Prompts:**

- What should be moderated first?
- Who enforces limits in your group?
- How fast should reports be reviewed?

---

## Lesson 78: Cultural misunderstandings

**Warm-up Prompt:**

What could you have asked sooner, and how did you repair it?

**Speaking Practice Prompts:**

- What could you have asked sooner?
- When did an apology repair trust?
- How do you clarify intent when you offend someone?

---

## Lesson 79: Media and emotions (questions)

**Warm-up Prompt:**

What did someone ask about how you felt, and what do you ask friends?

**Speaking Practice Prompts:**

- What did someone ask about how you felt?
- What do you ask friends when they look overwhelmed?
- How do you ask for comfort without oversharing?

---

## Lesson 80: Personal growth through travel

**Warm-up Prompt:**

If you hadn’t traveled, what growth would be missing, and what stayed with you?

**Speaking Practice Prompts:**

- If you hadn’t traveled, what growth would be missing?
- What lesson stayed with you from a trip?
- How did travel make you more humble?

---

## Lesson 81: Evaluating information

**Warm-up Prompt:**

How do you know if news is true?

**Speaking Practice Prompts:**

- How do you check if news is real?
- Which websites do you trust?
- When do you share information?
- How do you verify information?
- What platforms do you use for news?

---

## Lesson 82: Responsible media use (habits)

**Warm-up Prompt:**

How much time do you spend on your phone?

**Speaking Practice Prompts:**

- What apps do you use most?
- When do you take breaks from your phone?
- Who do you talk to online?
- How do you moderate your media use?
- What habits have you been developing?

---

## Lesson 83: Advertising influence (signals)

**Warm-up Prompt:**

How can you tell an ad is shaping you?

**Speaking Practice Prompts:**

- What commercials do you remember?
- Do you like funny ads?
- What product ads do you see?
- How do ads influence you?
- What makes an ad persuasive?

---

## Lesson 84: Public transport experiences (compare)

**Warm-up Prompt:**

Although delays happen, what keeps you calm?

**Speaking Practice Prompts:**

- How do you get to school?
- Do you take the bus to town?
- Who do you sit with on the bus?
- Have you ever experienced a delay?
- How do you handle crowded transport?

---

## Lesson 85: Freedom of expression (limits)

**Warm-up Prompt:**

What rule is so important you defend it?

**Speaking Practice Prompts:**

- Do you talk to strangers?
- What do you say when you meet someone?
- How do you say goodbye?
- How do you express your opinions?
- What topics do you debate about?

---

## Lesson 86: Technology dependence

**Warm-up Prompt:**

If you unplugged earlier, how would today feel?

**Speaking Practice Prompts:**

- When do you put your phone away?
- What do you do without your phone?
- Who calls you on the phone?
- How do you limit your screen time?
- Have you ever done a digital detox?

---

## Lesson 87: Cultural identity

**Warm-up Prompt:**

When do you rarely feel understood?

**Speaking Practice Prompts:**

- When do you rarely feel understood?
- How do you explain your identity?
- What do you keep?
- How do you adapt to new cultures?
- What makes you proud of your heritage?

---

## Lesson 88: Education and personal growth

**Warm-up Prompt:**

What had you learned before you grew fastest?

**Speaking Practice Prompts:**

- What had you learned before you grew fastest?
- Who guided you?
- What changed?
- What milestones have you reached?
- How do you reflect on your progress?

---

## Lesson 89: Ambition and motivation

**Warm-up Prompt:**

What do you want to achieve this year?

**Speaking Practice Prompts:**

- What job do you want in the future?
- How do you stay motivated?
- Who encourages you?
- What drives you to succeed?
- How do you handle setbacks?

---

## Lesson 90: Planning for adulthood

**Warm-up Prompt:**

If you shifted plans now, what would future you gain?

**Speaking Practice Prompts:**

- If you shifted plans now, what would future you gain?
- How do you prepare?
- Who keeps you realistic?
- What milestones do you want to reach?
- How do you anticipate challenges?

---

## Lesson 91: Life priorities

**Warm-up Prompt:**

What priority is so core you won’t drop it, and what will you postpone?

**Speaking Practice Prompts:**

- What priority is so core you won’t drop it?
- What will you postpone when things get busy?
- When did urgency make you sacrifice something else?

---

## Lesson 92: Study habits and routines

**Warm-up Prompt:**

Which habit, which you rely on, keeps you steady, and how do you tweak it?

**Speaking Practice Prompts:**

- Which habit, which you rely on, keeps you steady?
- How do you tweak your routine weekly?
- What streak motivates you now?

---

## Lesson 93: Learning styles (deep)

**Warm-up Prompt:**

How long have you used your main style, and when do you switch?

**Speaking Practice Prompts:**

- How long have you used your main style?
- When do you switch styles?
- What mix helps you when tired?

---

## Lesson 94: Personal responsibility (signals)

**Warm-up Prompt:**

How can you tell you’re slipping, and what must you do next?

**Speaking Practice Prompts:**

- How can you tell you’re slipping?
- What must you do next to uphold standards?
- Who notices when you neglect a duty?

---

## Lesson 95: Self-improvement

**Warm-up Prompt:**

What should you have changed sooner, and what could you still improve now?

**Speaking Practice Prompts:**

- What should you have changed sooner?
- What could you still improve now?
- Who helps you refine habits?

---

## Lesson 96: Belonging to a group

**Warm-up Prompt:**

If you hadn’t joined, what would you miss now, and how do you welcome others?

**Speaking Practice Prompts:**

- If you hadn’t joined, what would you miss now?
- How do you welcome new people so they belong?
- What would have helped you feel included sooner?

---

## Lesson 97: Independence and decision-making

**Warm-up Prompt:**

What must be your call, what should be shared, and who do you rely on?

**Speaking Practice Prompts:**

- What must be your call?
- What should be shared?
- Who do you rely on when you pivot?

---

## Lesson 98: Planning for the future (career)

**Warm-up Prompt:**

If you had planned differently, what would today look like, and what will you adjust now?

**Speaking Practice Prompts:**

- If you had planned differently, what would today look like?
- What milestone would change your stress now?
- How will you adjust your forecast?

---

## Lesson 99: Future Perfect wrap

**Warm-up Prompt:**

By three years out, what will you have done and prepared?

**Speaking Practice Prompts:**

- By three years out, what will you have done?
- What will you have prepared for your transition?
- How much will you have saved before moving?

---

## Lesson 100: Media influence on youth

**Warm-up Prompt:**

Hardly had a trend started when what happened, and how do you counter it?

**Speaking Practice Prompts:**

- Hardly had a trend started when what happened?
- How do you counter fast trends?
- What safeguard protects impressionable students?

---

