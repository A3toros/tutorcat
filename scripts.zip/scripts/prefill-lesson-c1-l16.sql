-- =========================================
-- Pre-fill Database with Sample Lesson Data
-- C1-L16: Standardized Testing: Benefits/Drawbacks
-- =========================================

DELETE FROM grammar_sentences WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'C1-L16');
DELETE FROM vocabulary_items WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'C1-L16');
DELETE FROM lesson_activities WHERE lesson_id = 'C1-L16';
DELETE FROM lessons WHERE id = 'C1-L16';

INSERT INTO lessons (id, level, lesson_number, topic) VALUES
('C1-L16', 'C1', 16, 'Standardized Testing: Benefits/Drawbacks')
ON CONFLICT (id) DO UPDATE SET topic = EXCLUDED.topic;

DO $$
DECLARE
    lesson_id_var TEXT := 'C1-L16';
    activity_id_var UUID;
BEGIN
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'warm_up_speaking', 1, 'Standardized Tests', 'Discuss standardized testing', '{"prompt": "How have standardized tests affected you?"}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_intro', 2, 'Testing Vocabulary', 'Learn vocabulary about standardized testing', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'standardized', 'มาตรฐาน', NULL),
    (activity_id_var, 'validity', 'ความถูกต้อง', NULL),
    (activity_id_var, 'reliability', 'ความน่าเชื่อถือ', NULL),
    (activity_id_var, 'limitation', 'ข้อจำกัด', NULL),
    (activity_id_var, 'equity', 'ความเท่าเทียม', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_matching_drag', 3, 'Match Testing Words', 'Match English words with Thai meanings', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'standardized', 'มาตรฐาน', NULL),
    (activity_id_var, 'validity', 'ความถูกต้อง', NULL),
    (activity_id_var, 'reliability', 'ความน่าเชื่อถือ', NULL),
    (activity_id_var, 'limitation', 'ข้อจำกัด', NULL),
    (activity_id_var, 'equity', 'ความเท่าเทียม', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 4, 'Complete the Sentences 1', 'Fill with the correct word', '{"text": "___ tests have both benefits and ___. Test ___ is crucial for fairness.", "blanks": [{"id": "blank1", "text": "Standardized", "options": ["Standardized", "Validity", "Reliability", "Equity"], "correctAnswer": "Standardized"}, {"id": "blank2", "text": "limitations", "options": ["limitations", "validity", "reliability", "equity"], "correctAnswer": "limitations"}, {"id": "blank3", "text": "validity", "options": ["validity", "reliability", "limitation", "equity"], "correctAnswer": "validity"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 5, 'Complete the Sentences 2', 'Fill with the correct word', '{"text": "Test ___ ensures consistent results. ___ in testing remains a challenge.", "blanks": [{"id": "blank1", "text": "reliability", "options": ["reliability", "validity", "limitation", "equity"], "correctAnswer": "reliability"}, {"id": "blank2", "text": "Equity", "options": ["Equity", "Validity", "Reliability", "Limitation"], "correctAnswer": "Equity"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_explanation', 6, 'Contrast Linking at C1 Level', 'Learn advanced contrast linking', '{"rules": "C1 contrast linking shows nuanced relationships:\n- \"While/Whereas\" (formal contrast): \"While tests measure knowledge, they may miss skills.\"\n- \"However/Nevertheless\" (concession): \"Tests are useful; however, they have limitations.\"\n- \"On the one hand... on the other hand\" (balanced contrast)\n- \"Despite/In spite of\" (contrary expectation): \"Despite benefits, tests have drawbacks.\"\n\nUse for:\n- Presenting balanced views: \"On one hand, tests are fair; on the other, they limit creativity.\"\n- Acknowledging complexity: \"While standardized tests help, they also create stress.\"\n- Showing contradiction: \"Tests measure ability; however, they may not reflect potential.\"", "examples": ["While standardized tests provide consistency, they may limit creativity.", "Tests measure knowledge; however, they may not assess skills.", "On the one hand, tests ensure fairness; on the other, they create pressure.", "Despite their benefits, standardized tests have significant limitations.", "Whereas validity is important, equity remains a concern."]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 7, 'Build Sentences 1', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'While standardized tests ensure consistency, they may limit creativity.', 'While standardized tests ensure consistency, they may limit creativity.', '["While", "standardized", "tests", "ensure", "consistency,", "they", "may", "limit", "creativity."]'::jsonb),
    (activity_id_var, 'Tests measure knowledge; however, they may not assess skills.', 'Tests measure knowledge; however, they may not assess skills.', '["Tests", "measure", "knowledge;", "however,", "they", "may", "not", "assess", "skills."]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 8, 'Build Sentences 2', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'On the one hand, tests provide validity; on the other, they lack equity.', 'On the one hand, tests provide validity; on the other, they lack equity.', '["On", "the", "one", "hand,", "tests", "provide", "validity;", "on", "the", "other,", "they", "lack", "equity."]'::jsonb),
    (activity_id_var, 'Despite their reliability, standardized tests have limitations.', 'Despite their reliability, standardized tests have limitations.', '["Despite", "their", "reliability,", "standardized", "tests", "have", "limitations."]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'speaking_practice', 9, 'Discuss Standardized Testing', 'Practice speaking about testing', '{"prompts": ["How have tests helped your learning?", "Where have they caused stress or problems?", "What are the benefits of standardized testing?", "What are the main drawbacks?", "How can testing be made more equitable?"]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (
      lesson_id,
      activity_type,
      activity_order,
      title,
      description,
      content
    ) VALUES (
      'C1-L16',
      'speaking_improvement',
      10,
      'Speaking Improvement',
      'Read the improved version of your speech',
      '{"type": "speaking_improvement", "similarityThreshold": 70}'::jsonb
    );
END $$;
