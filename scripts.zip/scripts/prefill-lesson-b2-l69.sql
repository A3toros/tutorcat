-- =========================================
-- Pre-fill Database with Sample Lesson Data
-- B2-L69: Education and future success
-- =========================================

DELETE FROM grammar_sentences WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'B2-L69');
DELETE FROM vocabulary_items WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'B2-L69');
DELETE FROM lesson_activities WHERE lesson_id = 'B2-L69';
DELETE FROM lessons WHERE id = 'B2-L69';

INSERT INTO lessons (id, level, lesson_number, topic) VALUES
('B2-L69', 'B2', 69, 'Education and future success')
ON CONFLICT (id) DO UPDATE SET topic = EXCLUDED.topic;

DO $$
DECLARE
    lesson_id_var TEXT := 'B2-L69';
    activity_id_var UUID;
BEGIN
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'warm_up_speaking', 1, 'Success Paths', 'Talk about past choices', '{"prompt": "If you hadn’t chosen this major, then what, and what opportunity would you have missed?"}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_intro', 2, 'Success Words', 'Key words for outcomes and pivots', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'outcome', 'ผลลัพธ์', NULL),
    (activity_id_var, 'opportunity', 'โอกาส', NULL),
    (activity_id_var, 'setback', 'อุปสรรค/การถอยหลัง', NULL),
    (activity_id_var, 'pathway', 'เส้นทาง/ทางเดิน', NULL),
    (activity_id_var, 'pivot', 'เปลี่ยนทิศ/หันเห', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_matching_drag', 3, 'Match Success Words', 'Match words with meanings', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'outcome', 'ผลลัพธ์', NULL),
    (activity_id_var, 'opportunity', 'โอกาส', NULL),
    (activity_id_var, 'setback', 'อุปสรรค/การถอยหลัง', NULL),
    (activity_id_var, 'pathway', 'เส้นทาง/ทางเดิน', NULL),
    (activity_id_var, 'pivot', 'เปลี่ยนทิศ/หันเห', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 4, 'Complete the Sentences 1', 'Fill with the correct word', '{"text": "This choice opened an ___. A ___ slowed me down. I picked a new ___.", "blanks": [{"id": "blank1", "text": "opportunity", "options": ["opportunity", "setback", "pathway", "pivot"], "correctAnswer": "opportunity"}, {"id": "blank2", "text": "setback", "options": ["setback", "opportunity", "pivot", "outcome"], "correctAnswer": "setback"}, {"id": "blank3", "text": "pathway", "options": ["pathway", "outcome", "setback", "pivot"], "correctAnswer": "pathway"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 5, 'Complete the Sentences 2', 'Fill with the correct word', '{"text": "I chose to ___. The ___ looks better now.", "blanks": [{"id": "blank1", "text": "pivot", "options": ["pivot", "opportunity", "pathway", "setback"], "correctAnswer": "pivot"}, {"id": "blank2", "text": "outcome", "options": ["outcome", "pathway", "setback", "opportunity"], "correctAnswer": "outcome"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_explanation', 6, 'Third Conditional', 'Reflect on past choices', '{"rules": "Use if + past perfect + would have + past participle for unreal past results; could/might have for less certain.\\n- If I had chosen another major, I would have missed this skill.", "examples": ["If I had skipped this course, I would have missed this mentor.", "If we had stayed in that pathway, we might have avoided a setback.", "If she had pivoted sooner, she could have gained more time.", "If he had spotted the opportunity, he would have applied.", "If you had planned earlier, you would have felt calmer."]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 7, 'Build Sentences 1', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'If I had chosen another major, I would have missed this skill', 'If I had chosen another major, I would have missed this skill.', '["If", "I", "had", "chosen", "another", "major,", "I", "would", "have", "missed", "this", "skill."]'::jsonb),
    (activity_id_var, 'If we had stayed in that pathway, we might have avoided a setback', 'If we had stayed in that pathway, we might have avoided a setback.', '["If", "we", "had", "stayed", "in", "that", "pathway,", "we", "might", "have", "avoided", "a", "setback."]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 8, 'Build Sentences 2', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'If she had pivoted sooner, she could have gained more time', 'If she had pivoted sooner, she could have gained more time.', '["If", "she", "had", "pivoted", "sooner,", "she", "could", "have", "gained", "more", "time."]'::jsonb),
    (activity_id_var, 'If he had spotted the opportunity, he would have applied', 'If he had spotted the opportunity, he would have applied.', '["If", "he", "had", "spotted", "the", "opportunity,", "he", "would", "have", "applied."]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'speaking_practice', 9, 'Talk About Success Choices', 'Practice third conditional', '{"prompts": ["If you hadn’t chosen this major, then what?", "What opportunity would you have missed?", "When would you pivot in the future?"]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (
      lesson_id,
      activity_type,
      activity_order,
      title,
      description,
      content
    ) VALUES (
      'B2-L69',
      'speaking_improvement',
      10,
      'Speaking Improvement',
      'Read the improved version of your speech',
      '{"type": "speaking_improvement", "similarityThreshold": 70}'::jsonb
    );
END $$;


