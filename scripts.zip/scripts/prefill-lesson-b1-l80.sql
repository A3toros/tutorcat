-- =========================================
-- Pre-fill Database with Sample Lesson Data
-- B1-L80: Social Media & Mental Health
-- =========================================

DELETE FROM grammar_sentences WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'B1-L80');
DELETE FROM vocabulary_items WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'B1-L80');
DELETE FROM lesson_activities WHERE lesson_id = 'B1-L80';
DELETE FROM lessons WHERE id = 'B1-L80';

INSERT INTO lessons (id, level, lesson_number, topic) VALUES
('B1-L80', 'B1', 80, 'Social Media & Mental Health')
ON CONFLICT (id) DO UPDATE SET topic = EXCLUDED.topic;

DO $$
DECLARE
    lesson_id_var TEXT := 'B1-L80';
    activity_id_var UUID;
BEGIN
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'warm_up_speaking', 1, 'Social Media Feelings', 'Talk about how social media affects mood', '{"prompt": "How do you deal with negative posts in your feed?"}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_intro', 2, 'Mental Health Online Words', 'Learn verb + preposition phrases about social media habits', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'log off', 'ออกจากระบบ', NULL),
    (activity_id_var, 'check on', 'ตรวจดู/ถามสารทุกข์สุขดิบ', NULL),
    (activity_id_var, 'compare to', 'เปรียบเทียบกับ', NULL),
    (activity_id_var, 'depend on', 'พึ่งพา', NULL),
    (activity_id_var, 'deal with', 'จัดการกับ', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_matching_drag', 3, 'Match Mental Health Online Phrases', 'Match phrases with meanings', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'log off', 'ออกจากระบบ', NULL),
    (activity_id_var, 'check on', 'ตรวจดู/ถามสารทุกข์สุขดิบ', NULL),
    (activity_id_var, 'compare to', 'เปรียบเทียบกับ', NULL),
    (activity_id_var, 'depend on', 'พึ่งพา', NULL),
    (activity_id_var, 'deal with', 'จัดการกับ', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 4, 'Complete the Sentences 1', 'Fill with the correct phrase', '{"text": "I need to ___ sometimes. I ___ friends to see if they are OK. I try not to ___ others too much.", "blanks": [{"id": "blank1", "text": "log off", "options": ["log off", "check on", "compare to", "depend on"], "correctAnswer": "log off"}, {"id": "blank2", "text": "check on", "options": ["check on", "log off", "depend on", "deal with"], "correctAnswer": "check on"}, {"id": "blank3", "text": "compare to", "options": ["compare to", "depend on", "log off", "deal with"], "correctAnswer": "compare to"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 5, 'Complete the Sentences 2', 'Fill with the correct phrase', '{"text": "I try not to ___ likes for self-worth. I ___ kind comments. I ___ stress by taking breaks.", "blanks": [{"id": "blank1", "text": "depend on", "options": ["depend on", "log off", "compare to", "check on"], "correctAnswer": "depend on"}, {"id": "blank2", "text": "appreciate", "options": ["appreciate", "deal with", "check on", "depend on"], "correctAnswer": "appreciate"}, {"id": "blank3", "text": "deal with", "options": ["deal with", "depend on", "log off", "compare to"], "correctAnswer": "deal with"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    -- Grammar Explanation: Verb + Preposition — social media habits
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_explanation', 6, 'Verb + Preposition for Social Media Habits', 'Use fixed verb-preposition pairs for habits and feelings online', '{"rules": "Keep pairs: log off, check on, compare to, depend on, deal with. Do not drop prepositions.\\nUse them clearly with objects.", "examples": ["I log off when the feed feels negative.", "I check on friends who post about stress.", "I try not to compare myself to others online.", "I do not depend on likes to feel good.", "I deal with stress by taking breaks."]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 7, 'Build Sentences 1', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'I log off when the feed feels negative', 'I log off when the feed feels negative', '["I", "log", "off", "when", "the", "feed", "feels", "negative"]'::jsonb),
    (activity_id_var, 'I check on friends who post about stress', 'I check on friends who post about stress', '["I", "check", "on", "friends", "who", "post", "about", "stress"]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 8, 'Build Sentences 2', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'I try not to compare myself to others online', 'I try not to compare myself to others online', '["I", "try", "not", "to", "compare", "myself", "to", "others", "online"]'::jsonb),
    (activity_id_var, 'I do not depend on likes to feel good', 'I do not depend on likes to feel good', '["I", "do", "not", "depend", "on", "likes", "to", "feel", "good"]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'speaking_practice', 9, 'Talk About Social Media & Mental Health', 'Practice talking about mood and social media', '{"prompts": ["How do you deal with negative posts in your feed?", "When do you decide to log off?", "How do you stop comparing yourself online?"]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (
      lesson_id,
      activity_type,
      activity_order,
      title,
      description,
      content
    ) VALUES (
      'B1-L80',
      'speaking_improvement',
      10,
      'Speaking Improvement',
      'Read the improved version of your speech',
      '{"type": "speaking_improvement", "similarityThreshold": 70}'::jsonb
    );
END $$;

