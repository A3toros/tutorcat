-- =========================================
-- Migration: Add active column, activity_id support, and lesson versioning
-- This migration adds support for soft deletes, activity tracking, and versioning
-- =========================================

-- Step 1: Add active column to lesson_activities (for soft deletes)
ALTER TABLE lesson_activities 
ADD COLUMN IF NOT EXISTS active BOOLEAN DEFAULT TRUE;

-- Step 2: Create index for active filtering
CREATE INDEX IF NOT EXISTS idx_lesson_activities_active 
ON lesson_activities(lesson_id, active) 
WHERE active = TRUE;

-- Step 3: Add activity_id column to lesson_activity_results (for tracking specific activities)
ALTER TABLE lesson_activity_results 
ADD COLUMN IF NOT EXISTS activity_id UUID REFERENCES lesson_activities(id);

-- Step 4: Create index for activity_id
CREATE INDEX IF NOT EXISTS idx_lesson_activity_results_activity_id 
ON lesson_activity_results(activity_id);

-- Step 5: Backfill activity_id for existing records
-- Match by lesson_id + activity_order to find the corresponding activity
UPDATE lesson_activity_results lar
SET activity_id = (
  SELECT la.id 
  FROM lesson_activities la
  WHERE la.lesson_id = lar.lesson_id 
    AND la.activity_order = lar.activity_order
    AND la.active = TRUE  -- Only match active activities
  ORDER BY la.created_at DESC  -- Get most recent if multiple matches
  LIMIT 1
)
WHERE activity_id IS NULL
  AND EXISTS (
    SELECT 1 FROM lesson_activities la
    WHERE la.lesson_id = lar.lesson_id 
      AND la.activity_order = lar.activity_order
      AND la.active = TRUE
  );

-- Step 6: Make foreign key constraints explicit with ON DELETE RESTRICT
-- Update vocabulary_items constraint
ALTER TABLE vocabulary_items
DROP CONSTRAINT IF EXISTS vocabulary_items_activity_id_fkey;

ALTER TABLE vocabulary_items
ADD CONSTRAINT vocabulary_items_activity_id_fkey
FOREIGN KEY (activity_id) REFERENCES lesson_activities(id)
ON DELETE RESTRICT;

-- Update grammar_sentences constraint
ALTER TABLE grammar_sentences
DROP CONSTRAINT IF EXISTS grammar_sentences_activity_id_fkey;

ALTER TABLE grammar_sentences
ADD CONSTRAINT grammar_sentences_activity_id_fkey
FOREIGN KEY (activity_id) REFERENCES lesson_activities(id)
ON DELETE RESTRICT;

-- Step 7: Add versioning support to lessons table
ALTER TABLE lessons 
ADD COLUMN IF NOT EXISTS version INTEGER DEFAULT 1;

ALTER TABLE lessons 
ADD COLUMN IF NOT EXISTS last_modified_at TIMESTAMP DEFAULT NOW();

-- Step 8: Create lesson_history table for audit trail
CREATE TABLE IF NOT EXISTS lesson_history (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    lesson_id VARCHAR(20) NOT NULL REFERENCES lessons(id),
    version INTEGER NOT NULL,
    changed_by UUID REFERENCES users(id),
    changes JSONB,
    changed_at TIMESTAMP DEFAULT NOW(),
    UNIQUE(lesson_id, version)
);

-- Step 9: Create index for lesson history
CREATE INDEX IF NOT EXISTS idx_lesson_history_lesson_id 
ON lesson_history(lesson_id, version DESC);

-- Step 10: Update unique constraint on lesson_activity_results to use activity_id
-- Drop old constraint if it exists
ALTER TABLE lesson_activity_results
DROP CONSTRAINT IF EXISTS unique_user_lesson_activity_order;

-- Add new constraint using activity_id
ALTER TABLE lesson_activity_results
ADD CONSTRAINT unique_user_lesson_activity_id
UNIQUE (user_id, lesson_id, activity_id);

-- =========================================
-- Migration complete
-- =========================================

-- Verification queries (run separately to check):
-- SELECT COUNT(*) as total_activities, COUNT(*) FILTER (WHERE active = TRUE) as active_activities FROM lesson_activities;
-- SELECT COUNT(*) as total_results, COUNT(activity_id) as results_with_activity_id FROM lesson_activity_results;
-- SELECT COUNT(*) as total_lessons, AVG(version) as avg_version FROM lessons;

