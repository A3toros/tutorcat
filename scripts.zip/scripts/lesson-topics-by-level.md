# Lesson Topics by Level

This document lists all lesson topics organized by CEFR level.

## A1 Level (Beginner)

1. Personal Information
2. Family & Friends
3. Daily Routines
4. Food & Drinks
5. Hobbies & Free Time
6. Places in Town
7. Home & Rooms
8. Numbers, Dates & Time
9. Weather & Seasons
10. Basic Directions

## A2 Level (Elementary)

1. Travel & Transport
2. Shopping & Prices
3. Eating Out & Restaurants
4. Work & Jobs
5. Health & Illness
6. Holidays & Celebrations
7. Technology in Daily Life
8. Feelings & Emotions
9. Sports & Activities
10. Describing People & Objects

## B1 Level (Intermediate)

1. Life Experiences
2. Education & Learning
3. Work & Career Plans
4. Health & Lifestyle Choices
5. Relationships
6. Entertainment & Media
7. Travel Experiences
8. Technology & Internet Use
9. Goals & Future Plans
10. Problems & Solutions

## B2 Level (Upper Intermediate)

1. Technology & Society
2. Environment & Climate
3. Culture & Traditions
4. Social Media & Communication
5. Work–Life Balance
6. Education Systems
7. Global Travel & Tourism
8. Ethics in Daily Life
9. News & Current Events
10. Personal Development

## C1 Level (Advanced)

1. Global Issues
2. Advanced Communication
3. Philosophy & Critical Thinking
4. Leadership & Management
5. Innovation & Technology
6. Art & Culture
7. Economics & Society
8. Science & Research
9. Literature & Analysis
10. Advanced Debates

## C2 Level (Proficiency)

1. Academic Discourse
2. Professional Communication
3. Advanced Philosophy
4. Literary Criticism
5. International Relations
6. Advanced Science & Ethics
7. Advanced Economics
8. Advanced Media & Communication
9. Advanced Research Methods
10. Mastery Synthesis

---

**Total Lessons: 60**
- A1: 10 lessons
- A2: 10 lessons
- B1: 10 lessons
- B2: 10 lessons
- C1: 10 lessons
- C2: 10 lessons

Countries and Nationalities

Languages You Speak

Jobs and Occupations

At School

Classroom Objects

At Work (Basic)

Colors and Shapes

Clothes and Accessories

Shopping Basics

Prices and Money

Ordering Food in a Café

At the Supermarket

Breakfast, Lunch, Dinner

Likes and Dislikes

Describing Objects (Size, Color)

Describing People (Basic)

Physical Appearance

Personality (Simple Adjectives)

Daily Schedule

Weekdays and Weekends

Months of the Year

Seasons and Activities

Weather Today

Transportation (Bus, Train, Car)

Getting Around Town

Asking for Directions

Giving Simple Directions

Places in a City

Public Places

Around the House

Furniture and Appliances

Household Activities

Chores

Free Time Activities

Sports (Basic)

Music and Movies

Technology Basics

Phone and Internet

Social Media Basics

Making Plans

Telling the Time

Talking About Today

Talking About Tomorrow

Talking About Yesterday

Past Activities (Very Simple)

Holidays and Celebrations

Birthdays

Festivals

Invitations

Making Requests

Asking for Help

Saying Thank You and Sorry

Polite Expressions

Agreeing and Disagreeing

Feelings and Emotions

Health and Body Parts

Feeling Sick

At the Pharmacy

At the Doctor (Very Basic)

Safety and Warnings

Rules and Signs

At the Airport

Travel Documents

Hotels and Accommodation

Booking a Room

Sightseeing

Asking for Information

Phone Calls (Basic)

Messages and Emails (Simple)

Work Schedule

Professions Around You

Tools and Objects

Numbers Above 100

Measurements (Basic)

Comparing Things

Talking About Possession

Giving Simple Opinions

Making Choices

Daily Problems

Simple Solutions

Neighbors and Community

Public Transport Rules

Traffic and Roads

Shopping Online

Paying and Receipts

Complaints (Very Simple)

Customer Service Phrases

Asking to Repeat

Clarifying Information

Review and Real-Life Practice