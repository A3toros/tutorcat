-- =========================================
-- Pre-fill Database with Sample Lesson Data
-- A2-L53: Talking About Salary (basic)
-- =========================================

DELETE FROM grammar_sentences WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'A2-L53');
DELETE FROM vocabulary_items WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'A2-L53');
DELETE FROM lesson_activities WHERE lesson_id = 'A2-L53';
DELETE FROM lessons WHERE id = 'A2-L53';

INSERT INTO lessons (id, level, lesson_number, topic) VALUES
('A2-L53', 'A2', 53, 'Talking About Salary (basic)')
ON CONFLICT (id) DO UPDATE SET topic = EXCLUDED.topic;

DO $$
DECLARE
    lesson_id_var TEXT := 'A2-L53';
    activity_id_var UUID;
BEGIN
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'warm_up_speaking', 1, 'Salary Talk', 'Talk about basic salary questions', '{"prompt": "Is a high salary more important than job happiness?"}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_intro', 2, 'Salary Words', 'Learn salary vocabulary', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'salary', 'เงินเดือน', NULL),
    (activity_id_var, 'raise', 'ขึ้นเงินเดือน', NULL),
    (activity_id_var, 'higher', 'สูงกว่า', NULL),
    (activity_id_var, 'lower', 'ต่ำกว่า', NULL),
    (activity_id_var, 'fair', 'ยุติธรรม', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_matching_drag', 3, 'Match Salary Words', 'Match salary words', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'salary', 'เงินเดือน', NULL),
    (activity_id_var, 'raise', 'ขึ้นเงินเดือน', NULL),
    (activity_id_var, 'higher', 'สูงกว่า', NULL),
    (activity_id_var, 'lower', 'ต่ำกว่า', NULL),
    (activity_id_var, 'fair', 'ยุติธรรม', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 4, 'Complete the Sentences 1', 'Fill with the correct word', '{"text": "My ___ is not ___. I want a ___.", "blanks": [{"id": "blank1", "text": "salary", "options": ["salary", "raise", "fair", "higher"], "correctAnswer": "salary"}, {"id": "blank2", "text": "fair", "options": ["fair", "higher", "lower", "raise"], "correctAnswer": "fair"}, {"id": "blank3", "text": "raise", "options": ["raise", "higher", "fair", "salary"], "correctAnswer": "raise"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 5, 'Complete the Sentences 2', 'Fill with the correct word', '{"text": "This job has a ___ salary. That job is ___.", "blanks": [{"id": "blank1", "text": "higher", "options": ["higher", "lower", "fair", "salary"], "correctAnswer": "higher"}, {"id": "blank2", "text": "lower", "options": ["lower", "higher", "fair", "salary"], "correctAnswer": "lower"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_explanation', 6, 'Comparatives', 'Compare salary amounts', '{"rules": "Use comparatives for amounts: higher/lower; more/less money.\nPattern: This salary is higher than that one.", "examples": ["This salary is higher than my last one.", "That offer is lower.", "I need a higher salary.", "Is this pay fair?", "This raise is better than before."]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 7, 'Build Sentences 1', 'Arrange words', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'This salary is higher than my last one', 'This salary is higher than my last one.', '["This", "salary", "is", "higher", "than", "my", "last", "one."]'::jsonb),
    (activity_id_var, 'That offer is lower', 'That offer is lower.', '["That", "offer", "is", "lower."]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 8, 'Build Sentences 2', 'Arrange words', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'I need a higher salary', 'I need a higher salary.', '["I", "need", "a", "higher", "salary."]'::jsonb),
    (activity_id_var, 'Is this pay fair', 'Is this pay fair?', '["Is", "this", "pay", "fair?"]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'speaking_practice', 9, 'Talk About Salary', 'Practice salary questions', '{"prompts": ["Is a high salary more important than job happiness?", "Which jobs pay better in your opinion?", "Is your salary higher or lower than you expected?", "Which is better: more money or more free time?", "What job do you think pays the most?"]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (
      lesson_id,
      activity_type,
      activity_order,
      title,
      description,
      content
    ) VALUES (
      'A2-L53',
      'speaking_improvement',
      10,
      'Speaking Improvement',
      'Read the improved version of your speech',
      '{"type": "speaking_improvement", "similarityThreshold": 70}'::jsonb
    );
END $$;

