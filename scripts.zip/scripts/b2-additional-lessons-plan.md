# B2 Additional Lessons Plan (L11–L100) — Student-Relevant Topics

## Requirements & Guidelines
- **Tone**: Student life focus; practical, relatable, human. Avoid workplace-only contexts.
- **Clarity**: One correct fill-blank answer; clear distractors; no ambiguity.
- **Grammar sentences**: Natural, varied; no robotic phrasing; include contractions where natural.
- **Speaking**: Open, personal, down-to-earth; 3 prompts per lesson.
- **Speaking improvement**: Include `speaking_improvement` with `similarityThreshold: 70`.
- **Topics**: Use the provided 90 topics in order; avoid clustering similar themes.
- **Spaced grammar**: Cycle B2 grammar across lessons; revisit for retention.

## CEFR B2 Grammar Coverage (from `cefr-grammar-requirements.md`)
- Present Perfect Continuous
- Past Perfect
- Future Continuous / Future Perfect
- Second Conditional
- Third Conditional
- Mixed Conditionals
- Modals (deduction: must/might/can’t)
- Past modals (should have / could have / might have)
- Passive with modals
- Causative: have/get something done
- Reported speech (questions & commands)
- Relative clauses (non-defining; reduced)
- Contrast & concession (although, however, whereas)
- Reason & result (so/such…that, therefore)
- Inversion with negative adverbials (Never have I…)

### Planned Review Counts (approx.)
- Present Perfect Continuous: 7
- Past Perfect: 7
- Future Continuous/Perfect: 6
- Second Conditional: 7
- Third/Mixed Conditionals: 7
- Modals (deduction): 6
- Past modals (should have/could have): 6
- Passive with modals: 5
- Causative: 4
- Reported speech (Q/Cmd): 6
- Relative clauses (non-defining/reduced): 7
- Contrast & concession: 6
- Reason & result (so/such…that): 5
- Inversion (negative adverbials): 4

## Lesson Plan (topics in given order; grammar spaced)
Format per lesson:
- Topic
- Grammar focus (+review #)
- Vocab sample (5 items)
- Speaking prompts (3 personal, student-friendly)

### L1–L10 (Foundations; seed exposures, not counted in coverage)
- **B2-L1 Technology & Society** — Modals deduction #0; vocab: algorithm, data privacy, screen time, digital divide, platform; speaking: “When does tech actually help you study?”, “What data about you must stay private?”, “How do you limit screen time on a busy day?”
- **B2-L2 Environment & Climate** — Reason/result (so/such…that) #0; vocab: carbon footprint, renewable energy, waste sorting, emissions, drought; speaking: “What small eco habit is easiest for you?”, “When was weather so bad you changed plans?”, “How do you feel when others skip recycling?”
- **B2-L3 Culture & Traditions** — Relative (non-defining) #0; vocab: heritage, ritual, custom, festival, symbol; speaking: “Which family tradition do you keep?”, “When did a festival feel special?”, “How do you explain your culture to friends?”
- **B2-L4 Social Media & Communication** — Contrast & concession (although/however/whereas) #0; vocab: misinterpret, tone, thread, reaction, reach; speaking: “How do you avoid being misinterpreted online?”, “When do you switch from text to a call?”, “What keeps your reach healthy without stress?”
- **B2-L5 Work–Life Balance** — Present Perfect Continuous #0; vocab: burnout, boundary, downtime, overtime, recharge; speaking: “How long have you been protecting your downtime?”, “When do you notice early signs of burnout?”, “What routine helps you recharge fast?”
- **B2-L6 Education Systems** — Reported Speech (questions) #0; vocab: curriculum, assessment, tuition, scholarship, attendance; speaking: “What would you ask a new school about fees?”, “How do you report a friend’s question about attendance?”, “When do you ask for clearer grading rules?”
- **B2-L7 Global Travel & Tourism** — Future Continuous/Perfect #0; vocab: itinerary, layover, tourism board, sustainable travel, local economy; speaking: “Where will you be on your next trip and why?”, “What will you have learned by the end?”, “How do you support the local economy when you travel?”
- **B2-L8 Ethics in Daily Life** — Second Conditional #0; vocab: integrity, shortcut, fairness, accountable, temptation; speaking: “If you saw cheating, what would you do?”, “When do you feel tempted to take shortcuts?”, “How do you keep fairness in group work?”
- **B2-L9 News & Current Events** — Passive with modals #0; vocab: headline, source, verify, bias, reporting; speaking: “How do you verify a headline before sharing?”, “When have you noticed bias?”, “What must be done before posting news in a group chat?”
- **B2-L10 Personal Development** — Third Conditional #0; vocab: resilience, mentor, setback, milestone, self-reflection; speaking: “If you had more time last term, what would you have done?”, “Who acted like a mentor for you?”, “What small milestone are you proud of?”

### L11–L20 (Shuffled mix 1)
- **B2-L11 Work–life balance** — Future Continuous/Perfect #1; vocab: balance, boundary, commute, pace, rest; speaking: “Where do you see your balance in a year?”, “What will you have changed by then?”, “Who keeps you accountable?”
- **B2-L12 Choosing a university or course** — Present Perfect Continuous #1; vocab: prospectus, faculty, intake, visit, shortlist; speaking: “How long have you been researching schools?”, “What have you ruled out?”, “Who helps you decide?”
- **B2-L13 Mental health among students** — Contrast (although/however) #1; vocab: cope, stigma, peer, space, recharge; speaking: “When do you switch off?”, “How do friends help you balance?”, “What breaks you fix first?”
- **B2-L14 Technology in studying** — Reason/result (so/such…that) #1; vocab: integrate, annotate, sync, backup, streamline; speaking: “What tool is so helpful you rely on it?”, “When is tech such a distraction you stop?”, “How do you set limits?”
- **B2-L15 Friendship in student life** — Modals deduction (must/might/can’t) #1; vocab: bond, trust, drift, reconnect, lean; speaking: “How can you tell a friend is stressed?”, “Who might notice first?”, “What can’t you ignore?”
- **B2-L16 Living independently as a student** — Past Perfect #1; vocab: rent, chore, grocery, repair, landlord; speaking: “What had you learned before moving out?”, “What surprised you most?”, “Who helped first?”
- **B2-L17 Travel experiences as a student** — Second Conditional #1; vocab: itinerary, hostel, detour, mishap, passport; speaking: “If you had more time, where would you go?”, “Who would you travel with?”, “What would you change next time?”
- **B2-L18 Media and student opinions** — Inversion (Never have I…) #1; vocab: headline, bias, verify, platform, comment; speaking: “Never have you what… when reading news?”, “Who challenges your view?”, “When do you stay silent?”
- **B2-L19 Personal values** — Relative (non-defining) #1; vocab: integrity, empathy, grit, fairness, loyalty; speaking: “What value, which you keep, guides you daily?”, “When was it tested?”, “Who taught it?”
- **B2-L20 Academic stress and burnout** — Present Perfect Continuous #2; vocab: overwhelm, pace, recover, boundary, support; speaking: “How long have you managed stress this way?”, “Who checks in on you?”, “What still needs change?”

### L21–L30 (Shuffled mix 2)
- **B2-L21 Studying abroad experiences** — Reported Speech (questions) #1; vocab: visa, host, adapt, homesick, buddy; speaking: “What questions did you ask hosts?”, “Who helped you settle?”, “What would you report back?”
- **B2-L22 Stress management strategies** — Past Perfect #2; vocab: breathing, break, trigger, routine, unwind; speaking: “What had you tried before?”, “What worked?”, “What would you repeat?”
- **B2-L23 Online research skills** — Contrast (whereas/however) #2; vocab: source, verify, citation, bias, archive; speaking: “When do you trust a source?”, “Where does bias hide?”, “How do you stay engaged?”
- **B2-L24 Making new friends** — Passive with modals #1; vocab: approach, invite, mingle, follow up, intro; speaking: “What should be shared early?”, “What must be respected?”, “How should contact be kept?”
- **B2-L25 Managing money as a student** — Future Continuous #2; vocab: budget, expense, savings, track, overdue; speaking: “How will you be tracking spending next month?”, “What will you cut?”, “What will you keep?”
- **B2-L26 Cultural differences** — Reason/result (so/such…that) #2; vocab: custom, gesture, norm, adapt, misread; speaking: “What difference was so big you paused?”, “What was such a surprise you adapted fast?”, “Who explained it?”
- **B2-L27 News consumption habits** — Reported Speech (commands) #1; vocab: skim, alert, mute, digest, review; speaking: “What were you told to check before sharing?”, “What commands do you give yourself?”, “Who guides your news habits?”
- **B2-L28 Sleep and productivity** — Modals deduction #2; vocab: bedtime, nap, circadian, alert, groggy; speaking: “How can you tell you slept well?”, “What might ruin focus?”, “What must you avoid?”
- **B2-L29 Online information reliability** — Relative (non-defining) #2; vocab: credible, cross-check, rumor, flag, verify; speaking: “What signals, which you trust, prove credibility?”, “When do you flag a post?”, “Who do you ask?”
- **B2-L30 Balancing study and personal life** — Third Conditional #1; vocab: boundary, prioritize, recharge, workload, pace; speaking: “If you hadn’t changed a habit, what would balance be now?”, “What would you keep?”, “Who would you ask for help?”

### L31–L40 (Shuffled mix 3)
- **B2-L31 Healthy lifestyle for students** — Present Perfect Continuous #3; vocab: nutrition, hydrate, stamina, consistent, crash; speaking: “How have you kept energy up?”, “What habit sticks?”, “What will you tweak?”
- **B2-L32 Using AI and digital tools for learning** — Second Conditional #2; vocab: prompt, iterate, refine, constraint, misuse; speaking: “If AI failed mid-project, what would you do?”, “Who would you ask for review?”, “When would you stop?”
- **B2-L33 Communication in groups** — Reason/result (so…that) #3; vocab: cue, interrupt, facilitate, consensus, clarify; speaking: “What keeps meetings so clear that no one is lost?”, “When do you step back?”, “Who keeps order?”
- **B2-L34 Budgeting basics** — Present Perfect Continuous #4; vocab: allocate, fixed, variable, cushion, overspend; speaking: “How long have you tracked spending?”, “What do you tweak?”, “When do you overspend?”
- **B2-L35 Exercise and mental focus** — Modals deduction #3; vocab: workout, endorphins, routine, intensity, recover; speaking: “How can you tell a workout helps focus?”, “When must you rest?”, “What might be overtraining?”
- **B2-L36 Coping with failure** — Contrast (although/however) #3; vocab: attempt, hindsight, adjust, redo, reflect; speaking: “Although it failed, what did you learn?”, “However you felt, what did you change?”, “Who helped?”
- **B2-L37 Personal achievements** — Past modals (should have/could have) #1; vocab: milestone, effort, celebrate, mentor, revise; speaking: “What should you have celebrated more?”, “What could you still improve?”, “Who guided you?”
- **B2-L38 Making important decisions** — Inversion (Rarely do I…) #2; vocab: weigh, option, risk, decisive, regret; speaking: “Rarely do you decide fast—when did you?”, “Who helps?”, “What do you regret?”
- **B2-L39 Sharing accommodation** — Mixed conditionals #1; vocab: shared, split, chore list, utility, quiet hours; speaking: “If chores were clearer, how would life look now?”, “What boundary matters?”, “Who sets rules?”
- **B2-L40 Work–life balance (boundaries)** — Passive with modals #2; vocab: boundary, overtime, response time, expectation, norm; speaking: “What should be protected?”, “What must be flexible?”, “Who enforces?”

### L41–L50 (Shuffled mix 4)
- **B2-L41 Screen time and concentration** — Present Perfect Continuous #5; vocab: focus, notification, detox, block, limit; speaking: “How have you managed notifications?”, “What keeps you focused?”, “When do you detox?”
- **B2-L42 Peer pressure** — Relative (reduced) #3; vocab: conform, resist, assertive, boundary, consequence; speaking: “Who helps you resist?”, “When do you feel pushback?”, “How do you stay assertive?”
- **B2-L43 Sleep and productivity (signals)** — Modals deduction #4; vocab: alert, groggy, nap, routine, cycle; speaking: “What signals poor sleep?”, “How can you tell you’re alert?”, “What must you avoid late?”
- **B2-L44 Living in another country** — Second Conditional #3; vocab: settle, adapt, routine, network, homesick; speaking: “If you moved today, what would you do first?”, “Who would you lean on?”, “What comfort would you bring?”
- **B2-L45 Responsible technology use** — Reason/result (such…that) #4; vocab: guideline, policy, restrict, comply, misuse; speaking: “What rule is so clear you always follow it?”, “When is misuse such a risk you stop?”, “How do you remind peers?”
- **B2-L46 Making new friends (habits)** — Contrast (whereas/however) #4; vocab: intro, approach, invite, mingle, follow-up; speaking: “Where do you meet people?”, “How do you keep conversations going?”, “What feels different online vs offline?”
- **B2-L47 Social media and distraction** — Passive with modals #3; vocab: scroll, trigger, blocklist, limit, notification; speaking: “What should be limited?”, “What must be muted?”, “Who keeps you accountable?”
- **B2-L48 Assessments and grading systems** — Future Continuous #3; vocab: rubric, curve, resit, criteria, transparency; speaking: “How will you be graded this term?”, “What will you contest?”, “Who will you ask for clarity?”
- **B2-L49 Cultural differences (signals)** — Modals deduction #5; vocab: norm, gesture, misread, adapt, explain; speaking: “How can you tell you misread a norm?”, “Who helps you adjust?”, “What might be offensive?”
- **B2-L50 Group projects and teamwork** — Reported Speech (commands) #2; vocab: assigned, delegated, accountability, merge, deadline; speaking: “What instructions did you get?”, “How do you report progress?”, “Who owns decisions?”

### L51–L60 (Shuffled mix 5)
- **B2-L51 Conflict resolution among peers** — Present Perfect Continuous #6; vocab: mediate, compromise, tension, pause, resolve; speaking: “How have your approaches evolved?”, “What works fastest?”, “Who cools things down?”
- **B2-L52 Financial responsibility** — Future Continuous #4; vocab: due, obligation, arrears, mindful, plan; speaking: “How will you stay on top of bills?”, “What reminders will you set?”, “Who keeps you honest?”
- **B2-L53 Travel and learning** — Relative (non-defining) #4; vocab: immerse, exposure, insight, broaden, curiosity; speaking: “Which trip, which changed you, do you recall?”, “What insight stayed?”, “How did it broaden you?”
- **B2-L54 Entertainment choices** — Second Conditional #4; vocab: genre, binge, mood, uplift, resonate; speaking: “If you cut one platform, what changes?”, “What would you keep?”, “Who chooses with you?”
- **B2-L55 Learning from experience** — Contrast (although/however) #5; vocab: lesson, revise, iterate, hindsight, improve; speaking: “Although it was hard, what did you learn?”, “However you felt, what did you change?”, “Who helped?”
- **B2-L56 Advertising influence** — Modals deduction #6; vocab: persuasive, subtle, impulse, sponsorship, trigger; speaking: “How can you tell an ad is shaping you?”, “What might be misleading?”, “How do you stay skeptical?”
- **B2-L57 Daily responsibilities** — Past modals (should have) #2; vocab: assign, remind, overdue, routine, checklist; speaking: “What should you have done yesterday?”, “What could you still do now?”, “Who nudges you?”
- **B2-L58 City life vs small towns** — Mixed conditionals #2; vocab: commute, pace, noise, tight-knit, amenities; speaking: “If you lived elsewhere, how would focus change now?”, “What would you miss?”, “What would improve?”
- **B2-L59 Learning styles (switching)** — Reason/result (so/such…that) #5; vocab: visual, auditory, kinesthetic, adapt, mismatch; speaking: “What habit is so effective you keep it?”, “When do you switch styles?”, “Who learns differently?”
- **B2-L60 Personal responsibility** — Passive with modals #4; vocab: accountable, duty, consequence, uphold, neglect; speaking: “What must be yours?”, “What should be delegated?”, “How do you uphold standards?”

### L61–L70 (Shuffled mix 6)
- **B2-L61 Student discounts and costs** — Present Perfect Continuous #7; vocab: discount, validate, fare, receipt, proof; speaking: “How have you been finding discounts?”, “What documents do you keep?”, “Where do you save most?”
- **B2-L62 City life vs small towns (deep)** — Past Perfect #3; vocab: pace, commute, tight-knit, amenities, quiet; speaking: “What had you underestimated about each?”, “What changed your mind?”, “What would you redo?”
- **B2-L63 Media and emotions** — Reason/result (such…that) #6; vocab: trigger, comfort, detach, overwhelm, empathy; speaking: “What content was so intense you stopped?”, “What helps you reset?”, “When does media build empathy?”
- **B2-L64 Responsible media use** — Contrast (whereas/however) #6; vocab: moderate, report, restrict, verify, consent; speaking: “Where do you draw the line?”, “How do you handle reports?”, “Who checks you?”
- **B2-L65 Planning for the future** — Inversion (Little do…) #3; vocab: contingency, scenario, fallback, adjust, forecast; speaking: “How little do others know about your plan B?”, “When do you pivot?”, “Who do you trust?”
- **B2-L66 Forming opinions** — Modals deduction #7; vocab: assumption, evidence, revise, conclude, bias; speaking: “How can you tell your view is solid?”, “What might change it?”, “Who challenges you?”
- **B2-L67 Online collaboration** — Passive with modals #5; vocab: assign, version, merge, notify, editable; speaking: “What must be versioned?”, “What should be shared early?”, “How should feedback be sent?”
- **B2-L68 Freedom of expression** — Reported Speech (commands) #3; vocab: express, censor, debate, offend, nuance; speaking: “What were you told about speech limits?”, “How do you keep nuance?”, “Who mediates?”
- **B2-L69 Education and future success** — Third Conditional #2; vocab: outcome, opportunity, setback, pathway, pivot; speaking: “If you hadn’t chosen this major, then what?”, “What would you have missed?”, “Who helped you pivot?”
- **B2-L70 Travel and cultural understanding** — Mixed conditionals #3; vocab: culture, insight, adapt, bridge, misread; speaking: “If you hadn’t traveled, how would views differ now?”, “What bridges gaps?”, “Who explains?”

### L71–L80 (Shuffled mix 7)
- **B2-L71 Public transport experiences** — Past Perfect #4; vocab: validate, delay, announcement, route, crowd; speaking: “What had you wished was announced?”, “How did you adapt?”, “Who helped?”
- **B2-L72 Freedom of expression (campus)** — Relative (non-defining) #5; vocab: express, censor, nuance, offend, debate; speaking: “Share a case that, which you recall, felt fair/unfair.”, “Who set the boundary?”, “How did you respond?”
- **B2-L73 Handling responsibility** — Present Perfect Continuous #8; vocab: entrusted, obligation, deadline, oversight, standard; speaking: “How have you carried duties lately?”, “What keeps you consistent?”, “What will you adjust?”
- **B2-L74 Long-term planning** — Second Conditional #5; vocab: fallback, contingency, timeline, adjust, benchmark; speaking: “If plans changed tomorrow, what would you do first?”, “Who would you call?”, “What comfort would you bring?”
- **B2-L75 Travel challenges** — Reason/result (so/such…that) #7; vocab: delay, backup, refund, reschedule, lost; speaking: “What challenge was so disruptive you changed plans?”, “How did you recover?”, “What backup will you keep?”
- **B2-L76 Media influence on youth** — Contrast (whereas/however) #7; vocab: impressionable, trend, safeguard, exposure, counter; speaking: “Where do you set limits?”, “How do you counter trends?”, “Who models balance?”
- **B2-L77 Social media influence** — Passive with modals #6; vocab: post, restrict, report, moderate, verify; speaking: “What should be moderated?”, “What must be reported?”, “Who enforces?”
- **B2-L78 Cultural misunderstandings** — Past modals (could have) #3; vocab: clarify, offend, intent, repair, apology; speaking: “What could you have asked sooner?”, “How did you repair it?”, “Who helped?”
- **B2-L79 Media and emotions (questions)** — Reported Speech (questions) #2; vocab: trigger, detach, empathy, overwhelm, comfort; speaking: “What did someone ask about how you felt?”, “What do you ask friends?”, “How do you clarify intent?”
- **B2-L80 Personal growth through travel** — Third Conditional #3; vocab: perspective, humble, resilience, adapt, lesson; speaking: “If you hadn’t traveled, what growth would be missing?”, “What stayed with you?”, “Who influenced you?”

### L81–L90 (Shuffled mix 8)
- **B2-L81 Forming opinions (brevity)** — Relative (reduced) #6; vocab: opinion, bias, headline, verify, platform; speaking: “How do you verify quickly?”, “Which platform do you trust?”, “When do you ignore news?”
- **B2-L82 Responsible media use (habits)** — Present Perfect Continuous #9; vocab: moderate, report, restrict, verify, consent; speaking: “How have you handled moderation lately?”, “What have you reported?”, “Who checks you?”
- **B2-L83 Advertising influence (signals)** — Modals deduction #8; vocab: persuasive, subtle, impulse, sponsorship, trigger; speaking: “How can you tell an ad is shaping you?”, “What might be misleading?”, “When do you switch off?”
- **B2-L84 Public transport experiences (compare)** — Contrast (although/however) #8; vocab: delay, route, announcement, crowd, validate; speaking: “Although delays happen, what keeps you calm?”, “However bad it gets, what do you do?”, “Who do you travel with?”
- **B2-L85 Freedom of expression (limits)** — Reason/result (so/such…that) #8; vocab: express, censor, nuance, offend, debate; speaking: “What rule is so important you defend it?”, “When is offense such a risk you pause?”, “How do you frame nuance?”
- **B2-L86 Technology dependence** — Mixed conditionals #4; vocab: notification, screen, focus, limit, detox; speaking: “If you unplugged earlier, how would today feel?”, “What habit would change?”, “Who keeps you on track?”
- **B2-L87 Cultural identity** — Inversion (Rarely/Seldom) #4; vocab: heritage, adapt, stereotype, pride, blend; speaking: “When do you rarely feel understood?”, “How do you explain your identity?”, “What do you keep?”
- **B2-L88 Education and personal growth** — Past Perfect #5; vocab: milestone, mentor, feedback, reflect, progress; speaking: “What had you learned before you grew fastest?”, “Who guided you?”, “What changed?”
- **B2-L89 Ambition and motivation** — Passive with modals #7; vocab: drive, plateau, spark, momentum, setback; speaking: “What should be sustained?”, “What must be adjusted when plateauing?”, “Who helps you restart?”
- **B2-L90 Planning for adulthood** — Second Conditional #6; vocab: milestone, stable, anticipate, prepare, transition; speaking: “If you shifted plans now, what would future you gain?”, “How do you prepare?”, “Who keeps you realistic?”

### L91–L100 (Shuffled mix 9)
- **B2-L91 Life priorities** — Reason/result (so/such…that) #9; vocab: priority, urgent, sacrifice, align, postpone; speaking: “What priority is so core you won’t drop it?”, “What will you postpone?”, “Who helps you align?”
- **B2-L92 Study habits and routines** — Relative (non-defining) #7; vocab: streak, tweak, routine, track, habit; speaking: “Which habit, which you rely on, keeps you steady?”, “How do you tweak it?”, “Who keeps you on track?”
- **B2-L93 Learning styles (deep)** — Present Perfect Continuous #10; vocab: visual, auditory, kinesthetic, adapt, match; speaking: “How long have you used your main style?”, “When do you switch?”, “Who learns differently?”
- **B2-L94 Personal responsibility (signals)** — Modals deduction #9; vocab: accountable, duty, consequence, uphold, neglect; speaking: “How can you tell you’re slipping?”, “What must you do next?”, “Who holds you accountable?”
- **B2-L95 Self-improvement** — Past modals (should have/could have) #4; vocab: refine, habit, feedback, adjust, reflect; speaking: “What should you have changed sooner?”, “What could you still improve?”, “What feedback helps most?”
- **B2-L96 Belonging to a group** — Third Conditional #4; vocab: include, isolate, welcome, cohesion, belong; speaking: “If you hadn’t joined, what would you miss now?”, “How do you welcome others?”, “When do you feel included?”
- **B2-L97 Independence and decision-making** — Passive with modals #8; vocab: autonomous, rely, consequence, maturity, pivot; speaking: “What must be your call?”, “What should be shared?”, “Who do you rely on?”
- **B2-L98 Planning for the future (career)** — Mixed conditionals #5; vocab: forecast, scenario, fallback, adjust, milestone; speaking: “If you had planned differently, what would today look like?”, “What will you adjust now?”, “Who advises you?”
- **B2-L99 Preparing for adulthood (milestones)** — Future Perfect #4; vocab: achieve, prepare, anticipate, transition, save; speaking: “By three years out, what will you have done?”, “What will you have prepared?”, “Who will you have thanked?”
- **B2-L100 Media influence on youth** — Inversion (Hardly/Scarcely) #5; vocab: trend, safeguard, exposure, counter, impressionable; speaking: “Hardly had a trend started when what happened?”, “How do you counter it?”, “Who do you guide?”

---

## Coverage Checkpoint (planned)
- Present Perfect Continuous: L12,20,31,34,41,51,61,73,82,93
- Past Perfect: L16,22,30,71,88
- Future Continuous/Perfect: L11,25,44,48,52,99
- Second Conditional: L17,32,44,54,74,90
- Third/Mixed Conditionals: L30,39,69,78,80,86,96,98
- Modals (deduction): L15,28,35,43,49,56,66,83,94
- Past modals (should/could have): L37,78,95
- Passive with modals: L24,40,47,60,67,77,89,97
- Causative (have/get done): reserve flex slots if needed in SQL
- Reported speech (Q/Cmd): L21,27,50,68,79
- Relatives (non-defining/reduced): L19,29,42,53,72,81,92
- Contrast & concession: L13,23,36,46,55,76,84
- Reason & result (so/such…that): L14,26,33,45,59,63,75,85,91
- Inversion (negative adverbials): L18,38,65,87,100

