-- =========================================
-- Pre-fill Database with Sample Lesson Data
-- B1-L18: Environmental Problems
-- =========================================

DELETE FROM grammar_sentences WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'B1-L18');
DELETE FROM vocabulary_items WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'B1-L18');
DELETE FROM lesson_activities WHERE lesson_id = 'B1-L18';
DELETE FROM lessons WHERE id = 'B1-L18';

INSERT INTO lessons (id, level, lesson_number, topic) VALUES
('B1-L18', 'B1', 18, 'Environmental Problems')
ON CONFLICT (id) DO UPDATE SET topic = EXCLUDED.topic;

DO $$
DECLARE
    lesson_id_var TEXT := 'B1-L18';
    activity_id_var UUID;
BEGIN
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'warm_up_speaking', 1, 'Local Environment', 'Talk about environmental problems near you', '{"prompt": "What local issue bothers you most?"}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_intro', 2, 'Environment Words', 'Learn vocabulary about environmental problems', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'pollution', 'มลพิษ', NULL),
    (activity_id_var, 'waste', 'ของเสีย', NULL),
    (activity_id_var, 'emit', 'ปล่อย', NULL),
    (activity_id_var, 'reduce', 'ลด', NULL),
    (activity_id_var, 'protect', 'ปกป้อง', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_matching_drag', 3, 'Match Environment Words', 'Match words with meanings', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'pollution', 'มลพิษ', NULL),
    (activity_id_var, 'waste', 'ของเสีย', NULL),
    (activity_id_var, 'emit', 'ปล่อย', NULL),
    (activity_id_var, 'reduce', 'ลด', NULL),
    (activity_id_var, 'protect', 'ปกป้อง', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 4, 'Complete the Sentences 1', 'Fill with the correct word', '{"text": "Air ___ is increasing. Factories ___ smoke. We must ___ waste.", "blanks": [{"id": "blank1", "text": "pollution", "options": ["pollution", "emit", "reduce", "protect"], "correctAnswer": "pollution"}, {"id": "blank2", "text": "emit", "options": ["emit", "pollution", "protect", "waste"], "correctAnswer": "emit"}, {"id": "blank3", "text": "reduce", "options": ["reduce", "protect", "emit", "pollution"], "correctAnswer": "reduce"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 5, 'Complete the Sentences 2', 'Fill with the correct word', '{"text": "We should ___ natural areas. Less ___ makes cities cleaner. Communities can ___ single-use items.", "blanks": [{"id": "blank1", "text": "protect", "options": ["protect", "waste", "emit", "reduce"], "correctAnswer": "protect"}, {"id": "blank2", "text": "waste", "options": ["waste", "protect", "reduce", "emit"], "correctAnswer": "waste"}, {"id": "blank3", "text": "reduce", "options": ["reduce", "protect", "waste", "emit"], "correctAnswer": "reduce"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    -- Grammar Explanation: Passive voice (present) for processes and impacts
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_explanation', 6, 'Passive Voice (Present)', 'Use passive to describe processes and impacts', '{"rules": "Passive present: am/is/are + past participle. Use to focus on the action or result.\\n- Waste is collected weekly.\\n- Air is polluted by traffic.\\nAvoid contractions and keep commas with preceding words in words_array.", "examples": ["Waste is collected every morning.", "Air is polluted by heavy traffic.", "Water is protected in this area.", "Plastic is reduced by new rules.", "Trees are protected by local law."]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 7, 'Build Sentences 1', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'Waste is collected every morning', 'Waste is collected every morning', '["Waste", "is", "collected", "every", "morning"]'::jsonb),
    (activity_id_var, 'Air is polluted by heavy traffic', 'Air is polluted by heavy traffic', '["Air", "is", "polluted", "by", "heavy", "traffic"]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 8, 'Build Sentences 2', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'Plastic is reduced by new rules', 'Plastic is reduced by new rules', '["Plastic", "is", "reduced", "by", "new", "rules"]'::jsonb),
    (activity_id_var, 'Trees are protected by local law', 'Trees are protected by local law', '["Trees", "are", "protected", "by", "local", "law"]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'speaking_practice', 9, 'Talk About Environment', 'Practice talking about environmental problems', '{"prompts": ["What local issue bothers you most?", "How is trash actually handled where you live?", "What small action did you take that felt impactful?"]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (
      lesson_id,
      activity_type,
      activity_order,
      title,
      description,
      content
    ) VALUES (
      'B1-L18',
      'speaking_improvement',
      10,
      'Speaking Improvement',
      'Read the improved version of your speech',
      '{"type": "speaking_improvement", "similarityThreshold": 70}'::jsonb
    );
END $$;
