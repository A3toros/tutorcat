-- =========================================
-- Pre-fill Database with Sample Lesson Data
-- B1-L30: Food Cultures
-- =========================================

DELETE FROM grammar_sentences WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'B1-L30');
DELETE FROM vocabulary_items WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'B1-L30');
DELETE FROM lesson_activities WHERE lesson_id = 'B1-L30';
DELETE FROM lessons WHERE id = 'B1-L30';

INSERT INTO lessons (id, level, lesson_number, topic) VALUES
('B1-L30', 'B1', 30, 'Food Cultures')
ON CONFLICT (id) DO UPDATE SET topic = EXCLUDED.topic;

DO $$
DECLARE
    lesson_id_var TEXT := 'B1-L30';
    activity_id_var UUID;
BEGIN
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'warm_up_speaking', 1, 'New Dishes', 'Talk about trying new foods', '{"prompt": "What new dish have you tried lately?"}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_intro', 2, 'Food Culture Words', 'Learn vocabulary about food cultures', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'cuisine', 'อาหารพื้นเมือง/อาหารชาติ', NULL),
    (activity_id_var, 'spice', 'เครื่องเทศ', NULL),
    (activity_id_var, 'recipe', 'สูตรอาหาร', NULL),
    (activity_id_var, 'flavor', 'รสชาติ', NULL),
    (activity_id_var, 'tradition', 'ประเพณี', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_matching_drag', 3, 'Match Food Words', 'Match words with meanings', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'cuisine', 'อาหารพื้นเมือง/อาหารชาติ', NULL),
    (activity_id_var, 'spice', 'เครื่องเทศ', NULL),
    (activity_id_var, 'recipe', 'สูตรอาหาร', NULL),
    (activity_id_var, 'flavor', 'รสชาติ', NULL),
    (activity_id_var, 'tradition', 'ประเพณี', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 4, 'Complete the Sentences 1', 'Fill with the correct word', '{"text": "This ___ mixes many ___s. I learned a new ___.", "blanks": [{"id": "blank1", "text": "cuisine", "options": ["cuisine", "flavor", "spice", "recipe"], "correctAnswer": "cuisine"}, {"id": "blank2", "text": "spice", "options": ["spice", "recipe", "tradition", "flavor"], "correctAnswer": "spice"}, {"id": "blank3", "text": "recipe", "options": ["recipe", "cuisine", "flavor", "tradition"], "correctAnswer": "recipe"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 5, 'Complete the Sentences 2', 'Fill with the correct word', '{"text": "The ___ is rich. Food is part of our ___. I love this unique ___.", "blanks": [{"id": "blank1", "text": "flavor", "options": ["flavor", "spice", "cuisine", "recipe"], "correctAnswer": "flavor"}, {"id": "blank2", "text": "tradition", "options": ["tradition", "flavor", "recipe", "spice"], "correctAnswer": "tradition"}, {"id": "blank3", "text": "cuisine", "options": ["cuisine", "tradition", "flavor", "recipe"], "correctAnswer": "cuisine"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    -- Grammar Explanation: Present Perfect (food experiences)
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_explanation', 6, 'Present Perfect for Food Experiences', 'Use have/has + past participle to share food experiences', '{"rules": "Present perfect to share food experiences without exact time.\\n- I have tried new cuisine.\\n- She has learned a recipe.\\nUse for life experience and recent results.", "examples": ["I have tried a new cuisine this month.", "She has learned a family recipe.", "We have tasted many flavors on this trip.", "They have shared food traditions with us.", "He has cooked with fresh spices lately."]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 7, 'Build Sentences 1', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'I have tried a new cuisine this month', 'I have tried a new cuisine this month', '["I", "have", "tried", "a", "new", "cuisine", "this", "month"]'::jsonb),
    (activity_id_var, 'She has learned a family recipe', 'She has learned a family recipe', '["She", "has", "learned", "a", "family", "recipe"]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 8, 'Build Sentences 2', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'We have tasted many flavors on this trip', 'We have tasted many flavors on this trip', '["We", "have", "tasted", "many", "flavors", "on", "this", "trip"]'::jsonb),
    (activity_id_var, 'They have shared food traditions with us', 'They have shared food traditions with us', '["They", "have", "shared", "food", "traditions", "with", "us"]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'speaking_practice', 9, 'Talk About Food Cultures', 'Practice talking about food experiences', '{"prompts": ["What new dish have you tried lately?", "Which food memory sticks with you?", "How do you talk yourself into trying new food?"]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (
      lesson_id,
      activity_type,
      activity_order,
      title,
      description,
      content
    ) VALUES (
      'B1-L30',
      'speaking_improvement',
      10,
      'Speaking Improvement',
      'Read the improved version of your speech',
      '{"type": "speaking_improvement", "similarityThreshold": 70}'::jsonb
    );
END $$;

