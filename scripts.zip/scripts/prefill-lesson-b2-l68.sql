-- =========================================
-- Pre-fill Database with Sample Lesson Data
-- B2-L68: Freedom of expression
-- =========================================

DELETE FROM grammar_sentences WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'B2-L68');
DELETE FROM vocabulary_items WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'B2-L68');
DELETE FROM lesson_activities WHERE lesson_id = 'B2-L68';
DELETE FROM lessons WHERE id = 'B2-L68';

INSERT INTO lessons (id, level, lesson_number, topic) VALUES
('B2-L68', 'B2', 68, 'Freedom of expression')
ON CONFLICT (id) DO UPDATE SET topic = EXCLUDED.topic;

DO $$
DECLARE
    lesson_id_var TEXT := 'B2-L68';
    activity_id_var UUID;
BEGIN
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'warm_up_speaking', 1, 'Speech Rules', 'Talk about what you were told', '{"prompt": "What were you told about speech limits, and how do you keep nuance?"}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_intro', 2, 'Expression Words', 'Key words for debate and limits', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'express', 'แสดงออก', NULL),
    (activity_id_var, 'censor', 'เซ็นเซอร์/ปิดกั้น', NULL),
    (activity_id_var, 'debate', 'อภิปราย/ถกเถียง', NULL),
    (activity_id_var, 'offend', 'ทำให้ไม่พอใจ', NULL),
    (activity_id_var, 'nuance', 'ความละเอียดอ่อนของความหมาย', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_matching_drag', 3, 'Match Expression Words', 'Match words with meanings', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'express', 'แสดงออก', NULL),
    (activity_id_var, 'censor', 'เซ็นเซอร์/ปิดกั้น', NULL),
    (activity_id_var, 'debate', 'อภิปราย/ถกเถียง', NULL),
    (activity_id_var, 'offend', 'ทำให้ไม่พอใจ', NULL),
    (activity_id_var, 'nuance', 'ความละเอียดอ่อนของความหมาย', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 4, 'Complete the Sentences 1', 'Fill with the correct word', '{"text": "We ___ ideas. Some posts may be ___. We keep ___.", "blanks": [{"id": "blank1", "text": "express", "options": ["express", "censor", "debate", "nuance"], "correctAnswer": "express"}, {"id": "blank2", "text": "censored", "options": ["censored", "debated", "expressed", "nuance"], "correctAnswer": "censored"}, {"id": "blank3", "text": "nuance", "options": ["nuance", "offend", "debate", "censor"], "correctAnswer": "nuance"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 5, 'Complete the Sentences 2', 'Fill with the correct word', '{"text": "We ___ tough topics. We avoid posts that ___.", "blanks": [{"id": "blank1", "text": "debate", "options": ["debate", "express", "censor", "nuance"], "correctAnswer": "debate"}, {"id": "blank2", "text": "offend", "options": ["offend", "nuance", "debate", "censor"], "correctAnswer": "offend"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_explanation', 6, 'Reported Speech (commands)', 'Report rules about speech', '{"rules": "Use tell/ask + object + to-infinitive for commands; not to for negatives. Backshift if needed.\\n- \"Respect all voices\" → They told us to respect all voices.\\n- \"Don’t post insults\" → She told me not to post insults.", "examples": ["They told us to respect speech limits.", "She told me not to post offensive comments.", "He asked us to add nuance to debates.", "The moderator told us to avoid censoring without reason.", "They asked me not to ignore consent before sharing."]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 7, 'Build Sentences 1', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'They told us to respect speech limits', 'They told us to respect speech limits.', '["They", "told", "us", "to", "respect", "speech", "limits."]'::jsonb),
    (activity_id_var, 'She told me not to post offensive comments', 'She told me not to post offensive comments.', '["She", "told", "me", "not", "to", "post", "offensive", "comments."]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 8, 'Build Sentences 2', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'He asked us to add nuance to debates', 'He asked us to add nuance to debates.', '["He", "asked", "us", "to", "add", "nuance", "to", "debates."]'::jsonb),
    (activity_id_var, 'They asked me not to ignore consent before sharing', 'They asked me not to ignore consent before sharing.', '["They", "asked", "me", "not", "to", "ignore", "consent", "before", "sharing."]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'speaking_practice', 9, 'Talk About Speech Rules', 'Practice reported commands', '{"prompts": ["What were you told about speech limits?", "How do you keep nuance in debates?", "When do you report offensive posts?"]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (
      lesson_id,
      activity_type,
      activity_order,
      title,
      description,
      content
    ) VALUES (
      'B2-L68',
      'speaking_improvement',
      10,
      'Speaking Improvement',
      'Read the improved version of your speech',
      '{"type": "speaking_improvement", "similarityThreshold": 70}'::jsonb
    );
END $$;


