-- ===== LESSON A1-L48 =====

-- =========================================
-- Pre-fill Database with Sample Lesson Data
-- A1-L48: Near and Far
-- =========================================

DELETE FROM grammar_sentences WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'A1-L48');
DELETE FROM vocabulary_items WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'A1-L48');
DELETE FROM lesson_activities WHERE lesson_id = 'A1-L48';
DELETE FROM lessons WHERE id = 'A1-L48';

INSERT INTO lessons (id, level, lesson_number, topic) VALUES
('A1-L48', 'A1', 48, 'Near and Far')
ON CONFLICT (id) DO UPDATE SET topic = EXCLUDED.topic;

DO $$
DECLARE
    lesson_id_var TEXT := 'A1-L48';
    activity_id_var UUID;
BEGIN
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'warm_up_speaking', 1, 'Near or far?', 'Talk about near and far', '{"prompt": "Is this near?"}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_intro', 2, 'Position Words', 'Learn position words', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'near', 'ใกล้', NULL),
    (activity_id_var, 'far', 'ไกล', NULL),
    (activity_id_var, 'here', 'ที่นี่', NULL),
    (activity_id_var, 'there', 'ที่นั่น', NULL),
    (activity_id_var, 'close', 'ใกล้ชิด', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_matching_drag', 3, 'Match Position Words', 'Match position words', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'near', 'ใกล้', NULL),
    (activity_id_var, 'far', 'ไกล', NULL),
    (activity_id_var, 'here', 'ที่นี่', NULL),
    (activity_id_var, 'there', 'ที่นั่น', NULL),
    (activity_id_var, 'close', 'ใกล้ชิด', NULL);

    -- 4. Vocabulary Fill Blanks #1
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 4, 'Complete the Sentences 1', 'Fill in the blanks with correct words', '{"text": "The school is ___ my house. The park is ___. I am ___.", "blanks": [{"id": "blank1", "text": "near", "options": ["near", "far", "here", "there"], "correctAnswer": "near"}, {"id": "blank2", "text": "far", "options": ["far", "near", "here", "close"], "correctAnswer": "far"}, {"id": "blank3", "text": "here", "options": ["here", "there", "near", "far"], "correctAnswer": "here"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    -- 5. Vocabulary Fill Blanks #2
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 5, 'Complete the Sentences 2', 'Fill in the blanks with correct words', '{"text": "The store is ___. My friend is ___. We are ___.", "blanks": [{"id": "blank1", "text": "there", "options": ["there", "here", "near", "far"], "correctAnswer": "there"}, {"id": "blank2", "text": "close", "options": ["close", "far", "here", "there"], "correctAnswer": "close"}, {"id": "blank3", "text": "near", "options": ["near", "far", "here", "there"], "correctAnswer": "near"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    -- 6. Grammar Explanation
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_explanation', 6, 'This/That/These/Those', 'Learn this/that/these/those', '{"rules": "Use this/that/these/those to point to things:\n\n- This (near, singular): This is near\n- That (far, singular): That is far\n- These (near, plural): These are close\n- Those (far, plural): Those are far\n- Use is with this/that, are with these/those", "examples": ["This is near.", "That is far.", "These are close.", "Those are far.", "This is here."]}'::jsonb)
    RETURNING id INTO activity_id_var;

    -- 7. Grammar Sentences #1
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 7, 'Build Sentences 1', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'This is near', 'This is near.', '["This", "is", "near."]'::jsonb),
    (activity_id_var, 'That is far', 'That is far.', '["That", "is", "far."]'::jsonb);

    -- 8. Grammar Sentences #2
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 8, 'Build Sentences 2', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'These are close', 'These are close.', '["These", "are", "close."]'::jsonb),
    (activity_id_var, 'That is there', 'That is there.', '["That", "is", "there."]'::jsonb);

    -- 9. Speaking Practice
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'speaking_practice', 9, 'Talk About Positions', 'Practice talking about positions', '{"prompts": ["Where is your school?", "Is your home near the school?", "What is near your house?", "What is far from your house?", "Where are you now?"]}'::jsonb)
    RETURNING id INTO activity_id_var;

    -- 10. Speaking Improvement
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'speaking_improvement', 10, 'Speaking Improvement', 'Read the improved version of your speech', '{"type": "speaking_improvement", "similarityThreshold": 70}'::jsonb)
    RETURNING id INTO activity_id_var;
END $$;