-- =========================================
-- Pre-fill Database with Sample Lesson Data
-- B2-L74: Long-term planning
-- =========================================

DELETE FROM grammar_sentences WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'B2-L74');
DELETE FROM vocabulary_items WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'B2-L74');
DELETE FROM lesson_activities WHERE lesson_id = 'B2-L74';
DELETE FROM lessons WHERE id = 'B2-L74';

INSERT INTO lessons (id, level, lesson_number, topic) VALUES
('B2-L74', 'B2', 74, 'Long-term planning')
ON CONFLICT (id) DO UPDATE SET topic = EXCLUDED.topic;

DO $$
DECLARE
    lesson_id_var TEXT := 'B2-L74';
    activity_id_var UUID;
BEGIN
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'warm_up_speaking', 1, 'Plan Shifts', 'Talk about pivots', '{"prompt": "If plans changed tomorrow, what would you do first, and who would you call?"}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_intro', 2, 'Planning Words', 'Key words for pivots and benchmarks', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'fallback', 'ทางเลือกสำรอง', NULL),
    (activity_id_var, 'contingency', 'แผนสำรอง', NULL),
    (activity_id_var, 'timeline', 'ไทม์ไลน์', NULL),
    (activity_id_var, 'adjust', 'ปรับ', NULL),
    (activity_id_var, 'benchmark', 'ตัวชี้วัด/หลักไมล์', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_matching_drag', 3, 'Match Planning Words', 'Match words with meanings', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'fallback', 'ทางเลือกสำรอง', NULL),
    (activity_id_var, 'contingency', 'แผนสำรอง', NULL),
    (activity_id_var, 'timeline', 'ไทม์ไลน์', NULL),
    (activity_id_var, 'adjust', 'ปรับ', NULL),
    (activity_id_var, 'benchmark', 'ตัวชี้วัด/หลักไมล์', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 4, 'Complete the Sentences 1', 'Fill with the correct word', '{"text": "I keep a ___. I set a ___. I can ___ when needed.", "blanks": [{"id": "blank1", "text": "fallback", "options": ["fallback", "timeline", "contingency", "adjust"], "correctAnswer": "fallback"}, {"id": "blank2", "text": "timeline", "options": ["timeline", "benchmark", "fallback", "adjust"], "correctAnswer": "timeline"}, {"id": "blank3", "text": "adjust", "options": ["adjust", "benchmark", "timeline", "contingency"], "correctAnswer": "adjust"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 5, 'Complete the Sentences 2', 'Fill with the correct word', '{"text": "Each ___ is shared with the team. A ___ is ready if needed.", "blanks": [{"id": "blank1", "text": "benchmark", "options": ["benchmark", "timeline", "fallback", "contingency"], "correctAnswer": "benchmark"}, {"id": "blank2", "text": "contingency", "options": ["contingency", "benchmark", "fallback", "adjust"], "correctAnswer": "contingency"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_explanation', 6, 'Second Conditional', 'Plan for sudden changes', '{"rules": "Use if + past simple + would + base verb for unreal/hypothetical present/future.\\n- If plans changed tomorrow, I would call the team.\\nUse were after I/he/she/it in formal style.", "examples": ["If plans changed, I would adjust the timeline first.", "If I were unsure, I would ask a mentor.", "If the fallback failed, we would use the contingency.", "If benchmarks slipped, we would reset dates.", "If the budget were cut, we would pivot scope."]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 7, 'Build Sentences 1', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'If plans changed, I would adjust the timeline first', 'If plans changed, I would adjust the timeline first.', '["If", "plans", "changed,", "I", "would", "adjust", "the", "timeline", "first."]'::jsonb),
    (activity_id_var, 'If I were unsure, I would ask a mentor', 'If I were unsure, I would ask a mentor.', '["If", "I", "were", "unsure,", "I", "would", "ask", "a", "mentor."]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 8, 'Build Sentences 2', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'If the fallback failed, we would use the contingency', 'If the fallback failed, we would use the contingency.', '["If", "the", "fallback", "failed,", "we", "would", "use", "the", "contingency."]'::jsonb),
    (activity_id_var, 'If benchmarks slipped, we would reset dates', 'If benchmarks slipped, we would reset dates.', '["If", "benchmarks", "slipped,", "we", "would", "reset", "dates."]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'speaking_practice', 9, 'Talk About Long-term Plans', 'Practice second conditional', '{"prompts": ["If plans changed tomorrow, what would you do first?", "Who would you call for help?", "What benchmark would you reset?"]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (
      lesson_id,
      activity_type,
      activity_order,
      title,
      description,
      content
    ) VALUES (
      'B2-L74',
      'speaking_improvement',
      10,
      'Speaking Improvement',
      'Read the improved version of your speech',
      '{"type": "speaking_improvement", "similarityThreshold": 70}'::jsonb
    );
END $$;


