-- =========================================
-- Pre-fill Database with Sample Lesson Data
-- B1-L10: Problems & Solutions
-- =========================================

-- Clear existing sample data for B1-L10 (optional - comment out if you want to keep existing data)
DELETE FROM grammar_sentences WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'B1-L10');
DELETE FROM vocabulary_items WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'B1-L10');
DELETE FROM lesson_activities WHERE lesson_id = 'B1-L10';
DELETE FROM lessons WHERE id = 'B1-L10';

INSERT INTO lessons (id, level, lesson_number, topic) VALUES
('B1-L10', 'B1', 10, 'Problems & Solutions')
ON CONFLICT (id) DO UPDATE SET topic = EXCLUDED.topic;

DO $$
DECLARE
    lesson_id_var TEXT := 'B1-L10';
    activity_id_var UUID;
BEGIN
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content) VALUES (lesson_id_var, 'warm_up_speaking', 1, 'Problem Solving', 'Talk about problems', '{"prompt": "What is a problem you have solved recently?"}'::jsonb) RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content) VALUES (lesson_id_var, 'vocabulary_intro', 2, 'Problem Words', 'Learn problem-solving vocabulary', '{}'::jsonb) RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'issue', 'ปัญหา', NULL),
    (activity_id_var, 'solution', 'วิธีแก้ไข', NULL),
    (activity_id_var, 'challenge', 'ความท้าทาย', NULL),
    (activity_id_var, 'approach', 'วิธีการ', NULL),
    (activity_id_var, 'resolve', 'แก้ไข', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content) VALUES (lesson_id_var, 'vocabulary_matching_drag', 3, 'Match Problem Words', 'Match English words with Thai meanings', '{}'::jsonb) RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'issue', 'ปัญหา', NULL),
    (activity_id_var, 'solution', 'วิธีแก้ไข', NULL),
    (activity_id_var, 'challenge', 'ความท้าทาย', NULL),
    (activity_id_var, 'approach', 'วิธีการ', NULL),
    (activity_id_var, 'resolve', 'แก้ไข', NULL);

    -- 4. Vocabulary Fill Blanks #1 (4 words: issue, solution, challenge, approach - resolve left out)
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content) VALUES (lesson_id_var, 'vocabulary_fill_blanks', 4, 'Complete the Sentences 1', 'Fill in the blanks with correct words', '{"text": "We have an ___. We found a ___. It was a ___. We tried a new ___.", "blanks": [{"id": "blank1", "text": "issue", "options": ["issue", "solution", "challenge", "approach"], "correctAnswer": "issue"}, {"id": "blank2", "text": "solution", "options": ["issue", "solution", "challenge", "approach"], "correctAnswer": "solution"}, {"id": "blank3", "text": "challenge", "options": ["issue", "solution", "challenge", "approach"], "correctAnswer": "challenge"}, {"id": "blank4", "text": "approach", "options": ["issue", "solution", "challenge", "approach"], "correctAnswer": "approach"}]}'::jsonb) RETURNING id INTO activity_id_var;

    -- 4. Vocabulary Fill Blanks #2 (4 words: issue, solution, challenge, resolve - approach left out)
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content) VALUES (lesson_id_var, 'vocabulary_fill_blanks', 5, 'Complete the Sentences 2', 'Fill in the blanks with correct words', '{"text": "The ___ is serious. The ___ works. It is a big ___. We need to ___.", "blanks": [{"id": "blank1", "text": "issue", "options": ["issue", "solution", "challenge", "resolve"], "correctAnswer": "issue"}, {"id": "blank2", "text": "solution", "options": ["issue", "solution", "challenge", "resolve"], "correctAnswer": "solution"}, {"id": "blank3", "text": "challenge", "options": ["issue", "solution", "challenge", "resolve"], "correctAnswer": "challenge"}, {"id": "blank4", "text": "resolve", "options": ["issue", "solution", "challenge", "resolve"], "correctAnswer": "resolve"}]}'::jsonb) RETURNING id INTO activity_id_var;

    -- 4. Grammar Explanation (5 examples - CEFR B1: Conditionals, problem-solving)
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content) VALUES (lesson_id_var, 'grammar_explanation', 6, 'Conditionals - Problem Solving', 'Learn to discuss problems and solutions', '{"rules": "Use conditionals for problem-solving:\n\n- First conditional: If + present, will + verb (If we try this, it will work)\n- Second conditional: If + past, would + verb (If I had time, I would help)\n- Use ''should'' for suggestions (You should try...)\n- Use ''could'' for possibilities (We could try...)\n- Use ''might'' for uncertain solutions (This might work)", "examples": ["If we try this approach, it will solve the problem.", "If I had more time, I would help you.", "You should try a different solution.", "We could ask for help.", "This might resolve the issue."]}'::jsonb) RETURNING id INTO activity_id_var;

    -- 4. Grammar Sentences #1
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content) VALUES (lesson_id_var, 'grammar_sentences', 7, 'Build Sentences 1', 'Arrange words to make sentences', '{}'::jsonb) RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'If we try this approach it will solve the problem', 'If we try this approach, it will solve the problem', '["If", "we", "try", "this", "approach", "it", "will", "solve", "the", "problem"]'::jsonb),
    (activity_id_var, 'If I had more time I would help you', 'If I had more time, I would help you', '["If", "I", "had", "more", "time", "I", "would", "help", "you"]'::jsonb);
    -- 4. Grammar Sentences #2
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content) VALUES (lesson_id_var, 'grammar_sentences', 8, 'Build Sentences 2', 'Arrange words to make sentences', '{}'::jsonb) RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'You should try a different solution', 'You should try a different solution', '["You", "should", "try", "a", "different", "solution"]'::jsonb),
    (activity_id_var, 'We could ask for help', 'We could ask for help', '["We", "could", "ask", "for", "help"]'::jsonb);
    -- 4. Speaking Practice (5 prompts - CEFR B1: Problems and solutions)
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content) VALUES (lesson_id_var, 'speaking_practice', 9, 'Talk About Problems', 'Practice discussing solutions', '{"prompts": ["What is a problem you have solved recently?", "How do you usually approach problems?", "What would you do if you faced a difficult challenge?", "What solutions have worked for you in the past?", "How do you help others solve problems?"]}'::jsonb) RETURNING id INTO activity_id_var;

END $$;
