-- =========================================
-- Pre-fill Database with Sample Lesson Data
-- C1-L11: Ethics in Education
-- =========================================

DELETE FROM grammar_sentences WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'C1-L11');
DELETE FROM vocabulary_items WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'C1-L11');
DELETE FROM lesson_activities WHERE lesson_id = 'C1-L11';
DELETE FROM lessons WHERE id = 'C1-L11';

INSERT INTO lessons (id, level, lesson_number, topic) VALUES
('C1-L11', 'C1', 11, 'Ethics in Education')
ON CONFLICT (id) DO UPDATE SET topic = EXCLUDED.topic;

DO $$
DECLARE
    lesson_id_var TEXT := 'C1-L11';
    activity_id_var UUID;
BEGIN
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'warm_up_speaking', 1, 'Ethics Discussion', 'Discuss ethics in education', '{"prompt": "When should rules be flexible in education?"}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_intro', 2, 'Ethics Vocabulary', 'Learn vocabulary about ethics', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'integrity', 'ความซื่อสัตย์', NULL),
    (activity_id_var, 'principle', 'หลักการ', NULL),
    (activity_id_var, 'dilemma', 'สถานการณ์ที่ยากลำบาก', NULL),
    (activity_id_var, 'accountability', 'ความรับผิดชอบ', NULL),
    (activity_id_var, 'transparency', 'ความโปร่งใส', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_matching_drag', 3, 'Match Ethics Words', 'Match English words with Thai meanings', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'integrity', 'ความซื่อสัตย์', NULL),
    (activity_id_var, 'principle', 'หลักการ', NULL),
    (activity_id_var, 'dilemma', 'สถานการณ์ที่ยากลำบาก', NULL),
    (activity_id_var, 'accountability', 'ความรับผิดชอบ', NULL),
    (activity_id_var, 'transparency', 'ความโปร่งใส', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 4, 'Complete the Sentences 1', 'Fill with the correct word', '{"text": "Academic ___ requires honesty in all work. Students must follow ethical ___.", "blanks": [{"id": "blank1", "text": "integrity", "options": ["integrity", "principle", "dilemma", "accountability"], "correctAnswer": "integrity"}, {"id": "blank2", "text": "principles", "options": ["principles", "transparency", "dilemma", "integrity"], "correctAnswer": "principles"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 5, 'Complete the Sentences 2', 'Fill with the correct word', '{"text": "Teachers face an ethical ___ when grading. ___ is essential for trust.", "blanks": [{"id": "blank1", "text": "dilemma", "options": ["dilemma", "principle", "integrity", "transparency"], "correctAnswer": "dilemma"}, {"id": "blank2", "text": "Transparency", "options": ["Transparency", "Accountability", "Integrity", "Dilemma"], "correctAnswer": "Transparency"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_explanation', 6, 'Articles: Abstract and Stylistic Use', 'Learn about articles with abstract concepts', '{"rules": "Articles with abstract nouns:\n- Use \"the\" when referring to a specific abstract concept: \"the ethics of education\"\n- Omit article for general abstract concepts: \"ethics is important\"\n- Use \"a/an\" when classifying: \"an ethical dilemma\"\n\nStylistic use:\n- \"The\" can emphasize importance: \"the principle of fairness\"\n- Zero article for broad concepts: \"education requires integrity\"", "examples": ["The ethics of academic work are complex.", "Ethics is a fundamental concern.", "A dilemma arose during the exam.", "The principle of fairness must be upheld.", "Education requires integrity from all parties."]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 7, 'Build Sentences 1', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'The ethics of education require careful consideration.', 'The ethics of education require careful consideration.', '["The", "ethics", "of", "education", "require", "careful", "consideration."]'::jsonb),
    (activity_id_var, 'A dilemma often arises when principles conflict.', 'A dilemma often arises when principles conflict.', '["A", "dilemma", "often", "arises", "when", "principles", "conflict."]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 8, 'Build Sentences 2', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'Transparency builds trust in academic institutions.', 'Transparency builds trust in academic institutions.', '["Transparency", "builds", "trust", "in", "academic", "institutions."]'::jsonb),
    (activity_id_var, 'The principle of accountability must be maintained.', 'The principle of accountability must be maintained.', '["The", "principle", "of", "accountability", "must", "be", "maintained."]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'speaking_practice', 9, 'Discuss Ethics', 'Practice speaking about ethics', '{"prompts": ["Is ethics fixed or changeable in your view?", "When, if ever, is it acceptable to bend rules?", "How do you define academic integrity?", "What ethical dilemmas can students face at school?", "Why is transparency important in education?"]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (
      lesson_id,
      activity_type,
      activity_order,
      title,
      description,
      content
    ) VALUES (
      'C1-L11',
      'speaking_improvement',
      10,
      'Speaking Improvement',
      'Read the improved version of your speech',
      '{"type": "speaking_improvement", "similarityThreshold": 70}'::jsonb
    );
END $$;
