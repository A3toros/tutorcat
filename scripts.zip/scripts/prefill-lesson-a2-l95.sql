-- =========================================
-- Pre-fill Database with Sample Lesson Data
-- A2-L95: Staying Fit
-- =========================================

DELETE FROM grammar_sentences WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'A2-L95');
DELETE FROM vocabulary_items WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'A2-L95');
DELETE FROM lesson_activities WHERE lesson_id = 'A2-L95';
DELETE FROM lessons WHERE id = 'A2-L95';

INSERT INTO lessons (id, level, lesson_number, topic) VALUES
('A2-L95', 'A2', 95, 'Staying Fit')
ON CONFLICT (id) DO UPDATE SET topic = EXCLUDED.topic;

DO $$
DECLARE
    lesson_id_var TEXT := 'A2-L95';
    activity_id_var UUID;
BEGIN
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'warm_up_speaking', 1, 'Fitness Plans', 'Talk about plans to stay fit', '{"prompt": "What are you going to do to stay fit?"}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_intro', 2, 'Fit Plans Words', 'Learn words about fitness plans', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'plan', 'แผน', NULL),
    (activity_id_var, 'goal', 'เป้าหมาย', NULL),
    (activity_id_var, 'routine', 'กิจวัตร', NULL),
    (activity_id_var, 'track', 'ติดตาม', NULL),
    (activity_id_var, 'improve', 'พัฒนา', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_matching_drag', 3, 'Match Fit Plans Words', 'Match fitness plan words', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'plan', 'แผน', NULL),
    (activity_id_var, 'goal', 'เป้าหมาย', NULL),
    (activity_id_var, 'routine', 'กิจวัตร', NULL),
    (activity_id_var, 'track', 'ติดตาม', NULL),
    (activity_id_var, 'improve', 'พัฒนา', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 4, 'Complete the Sentences 1', 'Fill with the correct word', '{"text": "I have a fitness ___. My ___ is to get stronger. I need a new ___.", "blanks": [{"id": "blank1", "text": "plan", "options": ["plan", "goal", "routine", "track"], "correctAnswer": "plan"}, {"id": "blank2", "text": "goal", "options": ["goal", "plan", "improve", "track"], "correctAnswer": "goal"}, {"id": "blank3", "text": "routine", "options": ["routine", "track", "plan", "goal"], "correctAnswer": "routine"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 5, 'Complete the Sentences 2', 'Fill with the correct word', '{"text": "I will ___ my progress. I want to ___ each week.", "blanks": [{"id": "blank1", "text": "track", "options": ["track", "improve", "plan", "goal"], "correctAnswer": "track"}, {"id": "blank2", "text": "improve", "options": ["improve", "track", "routine", "goal"], "correctAnswer": "improve"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_explanation', 6, 'Going to (Future Plans)', 'Talk about future fitness actions', '{"rules": "Use am/is/are + going to + verb for plans.\n- I am going to track my steps.\n- We are going to start a new routine.", "examples": ["I am going to start a new routine.", "We are going to track our steps.", "She is going to set a new goal.", "Are you going to improve your diet?", "They are going to work out together."]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 7, 'Build Sentences 1', 'Arrange words', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'I am going to start a new routine', 'I am going to start a new routine.', '["I", "am", "going", "to", "start", "a", "new", "routine."]'::jsonb),
    (activity_id_var, 'We are going to track our steps', 'We are going to track our steps.', '["We", "are", "going", "to", "track", "our", "steps."]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 8, 'Build Sentences 2', 'Arrange words', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'Are you going to improve your diet', 'Are you going to improve your diet?', '["Are", "you", "going", "to", "improve", "your", "diet?"]'::jsonb),
    (activity_id_var, 'They are going to work out together', 'They are going to work out together.', '["They", "are", "going", "to", "work", "out", "together."]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'speaking_practice', 9, 'Talk About Staying Fit', 'Practice future fitness plans', '{"prompts": ["What are you going to do to stay fit?", "Are you going to start a new routine?", "How are you going to track progress?", "Who is going to motivate you?", "When are you going to exercise?"]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (
      lesson_id,
      activity_type,
      activity_order,
      title,
      description,
      content
    ) VALUES (
      'A2-L95',
      'speaking_improvement',
      10,
      'Speaking Improvement',
      'Read the improved version of your speech',
      '{"type": "speaking_improvement", "similarityThreshold": 70}'::jsonb
    );
END $$;

