-- =========================================
-- Pre-fill Database with Sample Lesson Data
-- B1-L78: Volunteering
-- =========================================

DELETE FROM grammar_sentences WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'B1-L78');
DELETE FROM vocabulary_items WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'B1-L78');
DELETE FROM lesson_activities WHERE lesson_id = 'B1-L78';
DELETE FROM lessons WHERE id = 'B1-L78';

INSERT INTO lessons (id, level, lesson_number, topic) VALUES
('B1-L78', 'B1', 78, 'Volunteering')
ON CONFLICT (id) DO UPDATE SET topic = EXCLUDED.topic;

DO $$
DECLARE
    lesson_id_var TEXT := 'B1-L78';
    activity_id_var UUID;
BEGIN
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'warm_up_speaking', 1, 'Volunteer Stories', 'Talk about volunteering experiences', '{"prompt": "What have you learned from volunteering?"}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_intro', 2, 'Volunteer Words', 'Learn vocabulary about volunteering', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'volunteer', 'อาสาสมัคร', NULL),
    (activity_id_var, 'mentor', 'พี่เลี้ยง/ให้คำปรึกษา', NULL),
    (activity_id_var, 'donate', 'บริจาค', NULL),
    (activity_id_var, 'organize', 'จัดงาน/จัดระเบียบ', NULL),
    (activity_id_var, 'impact', 'ผลกระทบ', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_matching_drag', 3, 'Match Volunteer Words', 'Match words with meanings', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'volunteer', 'อาสาสมัคร', NULL),
    (activity_id_var, 'mentor', 'พี่เลี้ยง/ให้คำปรึกษา', NULL),
    (activity_id_var, 'donate', 'บริจาค', NULL),
    (activity_id_var, 'organize', 'จัดงาน/จัดระเบียบ', NULL),
    (activity_id_var, 'impact', 'ผลกระทบ', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 4, 'Complete the Sentences 1', 'Fill with the correct word', '{"text": "I ___ on weekends. I help to ___. We ___ supplies often.", "blanks": [{"id": "blank1", "text": "volunteer", "options": ["volunteer", "mentor", "donate", "organize"], "correctAnswer": "volunteer"}, {"id": "blank2", "text": "organize", "options": ["organize", "donate", "mentor", "impact"], "correctAnswer": "organize"}, {"id": "blank3", "text": "donate", "options": ["donate", "volunteer", "mentor", "impact"], "correctAnswer": "donate"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 5, 'Complete the Sentences 2', 'Fill with the correct word', '{"text": "I try to ___ younger members. We measure ___. These projects create ___.", "blanks": [{"id": "blank1", "text": "mentor", "options": ["mentor", "organize", "donate", "volunteer"], "correctAnswer": "mentor"}, {"id": "blank2", "text": "impact", "options": ["impact", "donation", "support", "mentor"], "correctAnswer": "impact"}, {"id": "blank3", "text": "impact", "options": ["impact", "organize", "donate", "volunteer"], "correctAnswer": "impact"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    -- Grammar Explanation: Present Perfect (volunteering experiences)
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_explanation', 6, 'Present Perfect for Volunteering', 'Use have/has + past participle to describe volunteering experiences', '{"rules": "Present perfect for experiences and impact up to now.\\n- I have volunteered for years.\\n- She has mentored many students.\\nAvoid exact past times.", "examples": ["I have volunteered for three years.", "She has mentored many students.", "They have donated supplies monthly.", "We have organized two big events.", "He has seen real impact from these projects."]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 7, 'Build Sentences 1', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'I have volunteered for three years', 'I have volunteered for three years', '["I", "have", "volunteered", "for", "three", "years"]'::jsonb),
    (activity_id_var, 'She has mentored many students', 'She has mentored many students', '["She", "has", "mentored", "many", "students"]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 8, 'Build Sentences 2', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'They have donated supplies monthly', 'They have donated supplies monthly', '["They", "have", "donated", "supplies", "monthly"]'::jsonb),
    (activity_id_var, 'We have organized two big events', 'We have organized two big events', '["We", "have", "organized", "two", "big", "events"]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'speaking_practice', 9, 'Talk About Volunteering', 'Practice talking about volunteering impact', '{"prompts": ["What have you learned from volunteering?", "Which cause matters most to you?", "How has volunteering changed your outlook?"]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (
      lesson_id,
      activity_type,
      activity_order,
      title,
      description,
      content
    ) VALUES (
      'B1-L78',
      'speaking_improvement',
      10,
      'Speaking Improvement',
      'Read the improved version of your speech',
      '{"type": "speaking_improvement", "similarityThreshold": 70}'::jsonb
    );
END $$;

