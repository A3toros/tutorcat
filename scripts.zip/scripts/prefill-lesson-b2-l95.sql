-- =========================================
-- Pre-fill Database with Sample Lesson Data
-- B2-L95: Self-improvement
-- =========================================

DELETE FROM grammar_sentences WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'B2-L95');
DELETE FROM vocabulary_items WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'B2-L95');
DELETE FROM lesson_activities WHERE lesson_id = 'B2-L95';
DELETE FROM lessons WHERE id = 'B2-L95';

INSERT INTO lessons (id, level, lesson_number, topic) VALUES
('B2-L95', 'B2', 95, 'Self-improvement')
ON CONFLICT (id) DO UPDATE SET topic = EXCLUDED.topic;

DO $$
DECLARE
    lesson_id_var TEXT := 'B2-L95';
    activity_id_var UUID;
BEGIN
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'warm_up_speaking', 1, 'Better Habits', 'Talk about changes you’d make', '{"prompt": "What should you have changed sooner, and what could you still improve now?"}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_intro', 2, 'Improvement Words', 'Key words for self-growth', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'refine', 'ขัดเกลา/ทำให้ดีขึ้น', NULL),
    (activity_id_var, 'habit', 'นิสัย', NULL),
    (activity_id_var, 'feedback', 'ความคิดเห็น/ข้อเสนอแนะ', NULL),
    (activity_id_var, 'adjust', 'ปรับ', NULL),
    (activity_id_var, 'reflect', 'ไตร่ตรอง', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_matching_drag', 3, 'Match Improvement Words', 'Match words with meanings', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'refine', 'ขัดเกลา/ทำให้ดีขึ้น', NULL),
    (activity_id_var, 'habit', 'นิสัย', NULL),
    (activity_id_var, 'feedback', 'ความคิดเห็น/ข้อเสนอแนะ', NULL),
    (activity_id_var, 'adjust', 'ปรับ', NULL),
    (activity_id_var, 'reflect', 'ไตร่ตรอง', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 4, 'Complete the Sentences 1', 'Fill with the correct word', '{"text": "I want to ___ this ___. I listen to ___.", "blanks": [{"id": "blank1", "text": "refine", "options": ["refine", "habit", "adjust", "reflect"], "correctAnswer": "refine"}, {"id": "blank2", "text": "habit", "options": ["habit", "feedback", "adjust", "reflect"], "correctAnswer": "habit"}, {"id": "blank3", "text": "feedback", "options": ["feedback", "refine", "adjust", "reflect"], "correctAnswer": "feedback"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 5, 'Complete the Sentences 2', 'Fill with the correct word', '{"text": "I ___ weekly and ___ when needed.", "blanks": [{"id": "blank1", "text": "reflect", "options": ["reflect", "refine", "habit", "feedback"], "correctAnswer": "reflect"}, {"id": "blank2", "text": "adjust", "options": ["adjust", "reflect", "feedback", "habit"], "correctAnswer": "adjust"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_explanation', 6, 'Past Modals (should have / could have)', 'Reflect on missed changes', '{"rules": "Use should have + past participle for regrets/advice about the past; could have for missed possibilities.\\n- I should have adjusted sooner.\\n- I could have refined that habit earlier.", "examples": ["I should have asked for feedback last term.", "I could have adjusted my schedule sooner.", "We should have refined the process before exams.", "She could have reflected weekly to improve faster.", "He should have changed that habit earlier."]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 7, 'Build Sentences 1', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'I should have asked for feedback last term', 'I should have asked for feedback last term.', '["I", "should", "have", "asked", "for", "feedback", "last", "term."]'::jsonb),
    (activity_id_var, 'I could have adjusted my schedule sooner', 'I could have adjusted my schedule sooner.', '["I", "could", "have", "adjusted", "my", "schedule", "sooner."]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 8, 'Build Sentences 2', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'We should have refined the process before exams', 'We should have refined the process before exams.', '["We", "should", "have", "refined", "the", "process", "before", "exams."]'::jsonb),
    (activity_id_var, 'She could have reflected weekly to improve faster', 'She could have reflected weekly to improve faster.', '["She", "could", "have", "reflected", "weekly", "to", "improve", "faster."]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'speaking_practice', 9, 'Talk About Self-Improvement', 'Practice past modals', '{"prompts": ["What should you have changed sooner?", "What could you still improve now?", "Who helps you refine habits?"]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (
      lesson_id,
      activity_type,
      activity_order,
      title,
      description,
      content
    ) VALUES (
      'B2-L95',
      'speaking_improvement',
      10,
      'Speaking Improvement',
      'Read the improved version of your speech',
      '{"type": "speaking_improvement", "similarityThreshold": 70}'::jsonb
    );
END $$;


