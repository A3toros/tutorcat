-- =========================================
-- Pre-fill Database with Sample Lesson Data
-- B2-L8: Ethics in Daily Life
-- =========================================

DELETE FROM grammar_sentences WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'B2-L8');
DELETE FROM vocabulary_items WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'B2-L8');
DELETE FROM lesson_activities WHERE lesson_id = 'B2-L8';
DELETE FROM lessons WHERE id = 'B2-L8';

INSERT INTO lessons (id, level, lesson_number, topic) VALUES
('B2-L8', 'B2', 8, 'Ethics in Daily Life')
ON CONFLICT (id) DO UPDATE SET topic = EXCLUDED.topic;

DO $$
DECLARE
    lesson_id_var TEXT := 'B2-L8';
    activity_id_var UUID;
BEGIN
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'warm_up_speaking', 1, 'Small Choices', 'Talk about everyday ethics', '{"prompt": "When did you last choose to do the harder but right thing?"}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_intro', 2, 'Ethics Words', 'Key words for daily ethics', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'integrity', 'ความซื่อสัตย์สุจริต', NULL),
    (activity_id_var, 'shortcut', 'ทางลัด', NULL),
    (activity_id_var, 'fairness', 'ความยุติธรรม', NULL),
    (activity_id_var, 'accountable', 'รับผิดชอบ', NULL),
    (activity_id_var, 'temptation', 'การล่อลวง/สิ่งยั่วยวน', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_matching_drag', 3, 'Match Ethics Words', 'Match words with meanings', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'integrity', 'ความซื่อสัตย์สุจริต', NULL),
    (activity_id_var, 'shortcut', 'ทางลัด', NULL),
    (activity_id_var, 'fairness', 'ความยุติธรรม', NULL),
    (activity_id_var, 'accountable', 'รับผิดชอบ', NULL),
    (activity_id_var, 'temptation', 'การล่อลวง/สิ่งยั่วยวน', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 4, 'Complete the Sentences 1', 'Fill with the correct word', '{"text": "He stayed late out of ___. We kept ___ by sharing tasks. She avoided a quick ___ to finish early.", "blanks": [{"id": "blank1", "text": "integrity", "options": ["integrity", "fairness", "shortcut", "accountable"], "correctAnswer": "integrity"}, {"id": "blank2", "text": "fairness", "options": ["fairness", "shortcut", "temptation", "integrity"], "correctAnswer": "fairness"}, {"id": "blank3", "text": "shortcut", "options": ["shortcut", "integrity", "accountable", "fairness"], "correctAnswer": "shortcut"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 5, 'Complete the Sentences 2', 'Fill with the correct word', '{"text": "Group leaders are ___. I felt ___ to copy answers. We set rules to keep ___.", "blanks": [{"id": "blank1", "text": "accountable", "options": ["accountable", "temptation", "fairness", "integrity"], "correctAnswer": "accountable"}, {"id": "blank2", "text": "temptation", "options": ["temptation", "shortcut", "accountable", "fairness"], "correctAnswer": "temptation"}, {"id": "blank3", "text": "fairness", "options": ["fairness", "integrity", "accountable", "temptation"], "correctAnswer": "fairness"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_explanation', 6, 'Second Conditional', 'Talk about hypothetical ethical choices', '{"rules": "Use if + past simple + would + base verb to talk about unreal or hypothetical situations now/future.\\n- If I saw cheating, I would report it.\\nUse was/were (were is formal) after if for all persons.", "examples": ["If I were unsure, I would ask a teacher.", "If they saw a shortcut, they would discuss it.", "If you felt temptation, what would you do?", "If we shared the work fairly, we would finish faster.", "If the rule was unclear, we would clarify it."]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 7, 'Build Sentences 1', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'If I saw cheating, I would report it', 'If I saw cheating, I would report it.', '["If", "I", "saw", "cheating,", "I", "would", "report", "it."]'::jsonb),
    (activity_id_var, 'If you felt temptation, what would you do', 'If you felt temptation, what would you do?', '["If", "you", "felt", "temptation,", "what", "would", "you", "do?"]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 8, 'Build Sentences 2', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'If the rule was unclear, we would clarify it', 'If the rule was unclear, we would clarify it.', '["If", "the", "rule", "was", "unclear,", "we", "would", "clarify", "it."]'::jsonb),
    (activity_id_var, 'If we shared the work fairly, we would finish faster', 'If we shared the work fairly, we would finish faster.', '["If", "we", "shared", "the", "work", "fairly,", "we", "would", "finish", "faster."]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'speaking_practice', 9, 'Talk About Daily Ethics', 'Practice hypothetical choices', '{"prompts": ["If your friend copied work, what would you do?", "When do you feel tempted to take shortcuts?", "How do you keep fairness in group projects?"]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (
      lesson_id,
      activity_type,
      activity_order,
      title,
      description,
      content
    ) VALUES (
      'B2-L8',
      'speaking_improvement',
      10,
      'Speaking Improvement',
      'Read the improved version of your speech',
      '{"type": "speaking_improvement", "similarityThreshold": 70}'::jsonb
    );
END $$;


