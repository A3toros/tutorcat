-- =========================================
-- Pre-fill Database with Sample Lesson Data
-- A2-L26: Sending Messages
-- =========================================

DELETE FROM grammar_sentences WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'A2-L26');
DELETE FROM vocabulary_items WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'A2-L26');
DELETE FROM lesson_activities WHERE lesson_id = 'A2-L26';
DELETE FROM lessons WHERE id = 'A2-L26';

INSERT INTO lessons (id, level, lesson_number, topic) VALUES
('A2-L26', 'A2', 26, 'Sending Messages')
ON CONFLICT (id) DO UPDATE SET topic = EXCLUDED.topic;

DO $$
DECLARE
    lesson_id_var TEXT := 'A2-L26';
    activity_id_var UUID;
BEGIN
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'warm_up_speaking', 1, 'Messaging', 'Talk about sending messages', '{"prompt": "Do you usually reply to messages quickly?"}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_intro', 2, 'Message Words', 'Learn messaging vocabulary', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'message', 'ข้อความ', NULL),
    (activity_id_var, 'reply', 'ตอบกลับ', NULL),
    (activity_id_var, 'emoji', 'อีโมจิ', NULL),
    (activity_id_var, 'send', 'ส่ง', NULL),
    (activity_id_var, 'receive', 'ได้รับ', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_matching_drag', 3, 'Match Message Words', 'Match chat words', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'message', 'ข้อความ', NULL),
    (activity_id_var, 'reply', 'ตอบกลับ', NULL),
    (activity_id_var, 'emoji', 'อีโมจิ', NULL),
    (activity_id_var, 'send', 'ส่ง', NULL),
    (activity_id_var, 'receive', 'ได้รับ', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 4, 'Complete the Sentences 1', 'Fill with the correct word', '{"text": "Did you get my ___? I did not ___ yet. I will ___ it now.", "blanks": [{"id": "blank1", "text": "message", "options": ["message", "reply", "send", "receive"], "correctAnswer": "message"}, {"id": "blank2", "text": "reply", "options": ["reply", "receive", "send", "message"], "correctAnswer": "reply"}, {"id": "blank3", "text": "send", "options": ["send", "reply", "message", "receive"], "correctAnswer": "send"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 5, 'Complete the Sentences 2', 'Fill with the correct word', '{"text": "I did not ___ your note. I like to ___ with an ___.", "blanks": [{"id": "blank1", "text": "receive", "options": ["receive", "reply", "send", "emoji"], "correctAnswer": "receive"}, {"id": "blank2", "text": "reply", "options": ["reply", "emoji", "receive", "send"], "correctAnswer": "reply"}, {"id": "blank3", "text": "emoji", "options": ["emoji", "reply", "send", "message"], "correctAnswer": "emoji"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_explanation', 6, 'Questions with Do/Does', 'Ask about messages', '{"rules": "Use do/does for present simple questions.\n- Do you reply fast?\n- Does he use emojis?\nNegatives: don''t/doesn''t.", "examples": ["Do you reply fast?", "Does she read messages at night?", "I don''t check often.", "He doesn''t send long texts.", "Do we need to answer now?"]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 7, 'Build Sentences 1', 'Arrange words', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'Do you reply fast', 'Do you reply fast?', '["Do", "you", "reply", "fast?"]'::jsonb),
    (activity_id_var, 'Does he use emojis', 'Does he use emojis?', '["Does", "he", "use", "emojis?"]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 8, 'Build Sentences 2', 'Arrange words', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'I don t check messages often', 'I don''t check messages often.', '["I", "don''t", "check", "messages", "often."]'::jsonb),
    (activity_id_var, 'He doesn t send long texts', 'He doesn''t send long texts.', '["He", "doesn''t", "send", "long", "texts."]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'speaking_practice', 9, 'Talk About Messages', 'Practice talking about messaging habits', '{"prompts": ["Do you usually reply to messages quickly?", "Do you use emojis when you message?", "How do you feel about voice messages?", "What apps do you use most for messaging?", "When do you usually send messages?"]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (
      lesson_id,
      activity_type,
      activity_order,
      title,
      description,
      content
    ) VALUES (
      'A2-L26',
      'speaking_improvement',
      10,
      'Speaking Improvement',
      'Read the improved version of your speech',
      '{"type": "speaking_improvement", "similarityThreshold": 70}'::jsonb
    );
END $$;

