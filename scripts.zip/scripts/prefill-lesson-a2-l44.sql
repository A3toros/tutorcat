-- =========================================
-- Pre-fill Database with Sample Lesson Data
-- A2-L44: Ordering Takeaway Food
-- =========================================

DELETE FROM grammar_sentences WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'A2-L44');
DELETE FROM vocabulary_items WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'A2-L44');
DELETE FROM lesson_activities WHERE lesson_id = 'A2-L44';
DELETE FROM lessons WHERE id = 'A2-L44';

INSERT INTO lessons (id, level, lesson_number, topic) VALUES
('A2-L44', 'A2', 44, 'Ordering Takeaway Food')
ON CONFLICT (id) DO UPDATE SET topic = EXCLUDED.topic;

DO $$
DECLARE
    lesson_id_var TEXT := 'A2-L44';
    activity_id_var UUID;
BEGIN
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'warm_up_speaking', 1, 'Takeaway', 'Talk about ordering food', '{"prompt": "How do you usually order takeaway food?"}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_intro', 2, 'Takeaway Words', 'Learn takeaway vocabulary', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'takeaway', 'อาหารนำกลับ', NULL),
    (activity_id_var, 'delivery', 'ส่งถึงบ้าน', NULL),
    (activity_id_var, 'menu', 'เมนู', NULL),
    (activity_id_var, 'order', 'สั่ง', NULL),
    (activity_id_var, 'tip', 'ทิป', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_matching_drag', 3, 'Match Takeaway Words', 'Match takeaway words', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'takeaway', 'อาหารนำกลับ', NULL),
    (activity_id_var, 'delivery', 'ส่งถึงบ้าน', NULL),
    (activity_id_var, 'menu', 'เมนู', NULL),
    (activity_id_var, 'order', 'สั่ง', NULL),
    (activity_id_var, 'tip', 'ทิป', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 4, 'Complete the Sentences 1', 'Fill with the correct word', '{"text": "Can I see the ___? I want to ___ food for ___.", "blanks": [{"id": "blank1", "text": "menu", "options": ["menu", "order", "delivery", "tip"], "correctAnswer": "menu"}, {"id": "blank2", "text": "order", "options": ["order", "takeaway", "delivery", "tip"], "correctAnswer": "order"}, {"id": "blank3", "text": "delivery", "options": ["delivery", "takeaway", "menu", "tip"], "correctAnswer": "delivery"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 5, 'Complete the Sentences 2', 'Fill with the correct word', '{"text": "Is this for ___ or ___. Do you leave a ___?", "blanks": [{"id": "blank1", "text": "takeaway", "options": ["takeaway", "delivery", "order", "tip"], "correctAnswer": "takeaway"}, {"id": "blank2", "text": "delivery", "options": ["delivery", "takeaway", "menu", "tip"], "correctAnswer": "delivery"}, {"id": "blank3", "text": "tip", "options": ["tip", "delivery", "order", "takeaway"], "correctAnswer": "tip"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_explanation', 6, 'Imperatives / Requests', 'Order food politely', '{"rules": "Use imperatives for simple requests; add please for politeness.\n- Please show me the menu.\n- Add extra rice, please.\nUse Can I/Can you for soft requests.", "examples": ["Please show me the menu.", "Add extra rice, please.", "Can I order for delivery?", "Can you remove spicy sauce?", "Please bring the bill."]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 7, 'Build Sentences 1', 'Arrange words', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'Please show me the menu', 'Please show me the menu.', '["Please", "show", "me", "the", "menu."]'::jsonb),
    (activity_id_var, 'Can I order for delivery', 'Can I order for delivery?', '["Can", "I", "order", "for", "delivery?"]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 8, 'Build Sentences 2', 'Arrange words', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'Add extra rice please', 'Add extra rice, please.', '["Add", "extra", "rice,", "please."]'::jsonb),
    (activity_id_var, 'Can you remove spicy sauce', 'Can you remove spicy sauce?', '["Can", "you", "remove", "spicy", "sauce?"]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'speaking_practice', 9, 'Talk About Takeaway', 'Practice ordering politely', '{"prompts": ["How do you usually order takeaway food?", "What app or phone service do you use?", "What food do you order most often?", "How long does delivery usually take?", "What do you say when you place an order?"]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (
      lesson_id,
      activity_type,
      activity_order,
      title,
      description,
      content
    ) VALUES (
      'A2-L44',
      'speaking_improvement',
      10,
      'Speaking Improvement',
      'Read the improved version of your speech',
      '{"type": "speaking_improvement", "similarityThreshold": 70}'::jsonb
    );
END $$;

