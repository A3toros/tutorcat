-- =========================================
-- Pre-fill Database with Sample Lesson Data
-- A2-L80: Describing Objects You Use Daily
-- =========================================

DELETE FROM grammar_sentences WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'A2-L80');
DELETE FROM vocabulary_items WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'A2-L80');
DELETE FROM lesson_activities WHERE lesson_id = 'A2-L80';
DELETE FROM lessons WHERE id = 'A2-L80';

INSERT INTO lessons (id, level, lesson_number, topic) VALUES
('A2-L80', 'A2', 80, 'Describing Objects You Use Daily')
ON CONFLICT (id) DO UPDATE SET topic = EXCLUDED.topic;

DO $$
DECLARE
    lesson_id_var TEXT := 'A2-L80';
    activity_id_var UUID;
BEGIN
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'warm_up_speaking', 1, 'Daily Objects', 'Talk about things you use every day', '{"prompt": "What is in your bag right now?"}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_intro', 2, 'Object Words', 'Learn words for daily objects', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'phone', 'โทรศัพท์', NULL),
    (activity_id_var, 'bag', 'กระเป๋า', NULL),
    (activity_id_var, 'keys', 'กุญแจ', NULL),
    (activity_id_var, 'wallet', 'กระเป๋าสตางค์', NULL),
    (activity_id_var, 'watch', 'นาฬิกา', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_matching_drag', 3, 'Match Object Words', 'Match daily object words', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'phone', 'โทรศัพท์', NULL),
    (activity_id_var, 'bag', 'กระเป๋า', NULL),
    (activity_id_var, 'keys', 'กุญแจ', NULL),
    (activity_id_var, 'wallet', 'กระเป๋าสตางค์', NULL),
    (activity_id_var, 'watch', 'นาฬิกา', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 4, 'Complete the Sentences 1', 'Fill with the correct word', '{"text": "My ___ is in my ___. I carry my ___.", "blanks": [{"id": "blank1", "text": "phone", "options": ["phone", "bag", "wallet", "keys"], "correctAnswer": "phone"}, {"id": "blank2", "text": "bag", "options": ["bag", "wallet", "keys", "phone"], "correctAnswer": "bag"}, {"id": "blank3", "text": "wallet", "options": ["wallet", "keys", "watch", "bag"], "correctAnswer": "wallet"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 5, 'Complete the Sentences 2', 'Fill with the correct word', '{"text": "These ___ are mine. This ___ is yours.", "blanks": [{"id": "blank1", "text": "keys", "options": ["keys", "phone", "wallet", "watch"], "correctAnswer": "keys"}, {"id": "blank2", "text": "watch", "options": ["watch", "bag", "wallet", "keys"], "correctAnswer": "watch"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_explanation', 6, 'This / That + Adjectives', 'Point to and describe objects', '{"rules": "Use this/that + noun to point; add adjectives for detail.\n- This phone is new.\n- That bag is heavy.\nQuestions: Is this yours? Is that new?", "examples": ["This phone is new.", "That bag is heavy.", "Is this yours?", "Is that watch old?", "These keys are mine."]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 7, 'Build Sentences 1', 'Arrange words', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'This phone is new', 'This phone is new.', '["This", "phone", "is", "new."]'::jsonb),
    (activity_id_var, 'That bag is heavy', 'That bag is heavy.', '["That", "bag", "is", "heavy."]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 8, 'Build Sentences 2', 'Arrange words', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'Is this yours', 'Is this yours?', '["Is", "this", "yours?"]'::jsonb),
    (activity_id_var, 'Is that watch old', 'Is that watch old?', '["Is", "that", "watch", "old?"]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'speaking_practice', 9, 'Talk About Daily Objects', 'Practice describing and pointing', '{"prompts": ["What is this object you use every day?", "What is that item used for?", "How would you describe your phone?", "Which object is most important to you?", "How do you describe everyday items clearly?"]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (
      lesson_id,
      activity_type,
      activity_order,
      title,
      description,
      content
    ) VALUES (
      'A2-L80',
      'speaking_improvement',
      10,
      'Speaking Improvement',
      'Read the improved version of your speech',
      '{"type": "speaking_improvement", "similarityThreshold": 70}'::jsonb
    );
END $$;

