-- =========================================
-- Pre-fill Database with Sample Lesson Data
-- A2-L54: Paying the Bill
-- =========================================

DELETE FROM grammar_sentences WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'A2-L54');
DELETE FROM vocabulary_items WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'A2-L54');
DELETE FROM lesson_activities WHERE lesson_id = 'A2-L54';
DELETE FROM lessons WHERE id = 'A2-L54';

INSERT INTO lessons (id, level, lesson_number, topic) VALUES
('A2-L54', 'A2', 54, 'Paying the Bill')
ON CONFLICT (id) DO UPDATE SET topic = EXCLUDED.topic;

DO $$
DECLARE
    lesson_id_var TEXT := 'A2-L54';
    activity_id_var UUID;
BEGIN
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'warm_up_speaking', 1, 'Splitting Bills', 'Talk about paying in restaurants', '{"prompt": "When did you last pay a bill with friends?"}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_intro', 2, 'Bill Words', 'Learn paying-the-bill vocabulary', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'bill', 'บิล/ใบเสร็จ', NULL),
    (activity_id_var, 'receipt', 'ใบเสร็จ', NULL),
    (activity_id_var, 'split', 'แยก/หารจ่าย', NULL),
    (activity_id_var, 'paid', 'จ่ายแล้ว', NULL),
    (activity_id_var, 'forgot', 'ลืม', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_matching_drag', 3, 'Match Bill Words', 'Match bill words', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'bill', 'บิล/ใบเสร็จ', NULL),
    (activity_id_var, 'receipt', 'ใบเสร็จ', NULL),
    (activity_id_var, 'split', 'แยก/หารจ่าย', NULL),
    (activity_id_var, 'paid', 'จ่ายแล้ว', NULL),
    (activity_id_var, 'forgot', 'ลืม', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 4, 'Complete the Sentences 1', 'Fill with the correct word', '{"text": "Can we ___ the ___? I ___ my ___ at home.", "blanks": [{"id": "blank1", "text": "split", "options": ["split", "bill", "forgot", "receipt"], "correctAnswer": "split"}, {"id": "blank2", "text": "bill", "options": ["bill", "receipt", "paid", "forgot"], "correctAnswer": "bill"}, {"id": "blank3", "text": "forgot", "options": ["forgot", "paid", "bill", "receipt"], "correctAnswer": "forgot"}, {"id": "blank4", "text": "receipt", "options": ["receipt", "bill", "paid", "split"], "correctAnswer": "receipt"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 5, 'Complete the Sentences 2', 'Fill with the correct word', '{"text": "I already ___. Do you need the ___?", "blanks": [{"id": "blank1", "text": "paid", "options": ["paid", "split", "bill", "receipt"], "correctAnswer": "paid"}, {"id": "blank2", "text": "receipt", "options": ["receipt", "bill", "forgot", "split"], "correctAnswer": "receipt"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_explanation', 6, 'Past Simple', 'Talk about paying and splitting', '{"rules": "Use past simple for finished actions.\n- I paid the bill.\n- We split the check.\nQuestions: Did you pay? Did you split?\nNegatives: didn''t + verb.", "examples": ["I paid the bill yesterday.", "We split the check.", "Did you keep the receipt?", "I didn''t forget to pay.", "They paid in cash."]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 7, 'Build Sentences 1', 'Arrange words', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'I paid the bill yesterday', 'I paid the bill yesterday.', '["I", "paid", "the", "bill", "yesterday."]'::jsonb),
    (activity_id_var, 'We split the check', 'We split the check.', '["We", "split", "the", "check."]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 8, 'Build Sentences 2', 'Arrange words', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'Did you keep the receipt', 'Did you keep the receipt?', '["Did", "you", "keep", "the", "receipt?"]'::jsonb),
    (activity_id_var, 'I didn t forget to pay', 'I didn''t forget to pay.', '["I", "didn''t", "forget", "to", "pay."]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'speaking_practice', 9, 'Talk About Paying Bills', 'Practice bill situations', '{"prompts": ["When did you last pay a bill with friends?", "Did you split the bill or pay together?", "Who paid for the meal last time?", "Did you ever forget to pay your share?", "What did you do when the bill was wrong?"]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (
      lesson_id,
      activity_type,
      activity_order,
      title,
      description,
      content
    ) VALUES (
      'A2-L54',
      'speaking_improvement',
      10,
      'Speaking Improvement',
      'Read the improved version of your speech',
      '{"type": "speaking_improvement", "similarityThreshold": 70}'::jsonb
    );
END $$;

