-- =========================================
-- Pre-fill Database with Sample Lesson Data
-- A2-L76: Internet Problems
-- =========================================

DELETE FROM grammar_sentences WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'A2-L76');
DELETE FROM vocabulary_items WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'A2-L76');
DELETE FROM lesson_activities WHERE lesson_id = 'A2-L76';
DELETE FROM lessons WHERE id = 'A2-L76';

INSERT INTO lessons (id, level, lesson_number, topic) VALUES
('A2-L76', 'A2', 76, 'Internet Problems')
ON CONFLICT (id) DO UPDATE SET topic = EXCLUDED.topic;

DO $$
DECLARE
    lesson_id_var TEXT := 'A2-L76';
    activity_id_var UUID;
BEGIN
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'warm_up_speaking', 1, 'Bad Connection', 'Talk about internet issues', '{"prompt": "When was the last time your internet stopped working?"}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_intro', 2, 'Internet Problem Words', 'Learn words about internet issues', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'offline', 'ออฟไลน์', NULL),
    (activity_id_var, 'slow', 'ช้า', NULL),
    (activity_id_var, 'error', 'ข้อผิดพลาด', NULL),
    (activity_id_var, 'fixed', 'แก้ไขแล้ว', NULL),
    (activity_id_var, 'reset', 'รีเซ็ต', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_matching_drag', 3, 'Match Internet Words', 'Match internet problem words', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'offline', 'ออฟไลน์', NULL),
    (activity_id_var, 'slow', 'ช้า', NULL),
    (activity_id_var, 'error', 'ข้อผิดพลาด', NULL),
    (activity_id_var, 'fixed', 'แก้ไขแล้ว', NULL),
    (activity_id_var, 'reset', 'รีเซ็ต', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 4, 'Complete the Sentences 1', 'Fill with the correct word', '{"text": "The internet was ___. I saw an ___. I was ___.", "blanks": [{"id": "blank1", "text": "slow", "options": ["slow", "offline", "error", "reset"], "correctAnswer": "slow"}, {"id": "blank2", "text": "error", "options": ["error", "offline", "fixed", "reset"], "correctAnswer": "error"}, {"id": "blank3", "text": "offline", "options": ["offline", "fixed", "reset", "slow"], "correctAnswer": "offline"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 5, 'Complete the Sentences 2', 'Fill with the correct word', '{"text": "I ___ the router. It is ___.", "blanks": [{"id": "blank1", "text": "reset", "options": ["reset", "fixed", "slow", "offline"], "correctAnswer": "reset"}, {"id": "blank2", "text": "fixed", "options": ["fixed", "reset", "error", "offline"], "correctAnswer": "fixed"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_explanation', 6, 'Past Simple', 'Explain past internet issues', '{"rules": "Use past simple for finished events.\n- The internet was slow.\n- I reset the router.\nQuestions: Did it work? Negatives: didn''t + verb.", "examples": ["The internet was slow yesterday.", "I reset the router.", "Did the error stop?", "It didn''t work at first.", "They fixed it later."]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 7, 'Build Sentences 1', 'Arrange words', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'The internet was slow yesterday', 'The internet was slow yesterday.', '["The", "internet", "was", "slow", "yesterday."]'::jsonb),
    (activity_id_var, 'I reset the router', 'I reset the router.', '["I", "reset", "the", "router."]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 8, 'Build Sentences 2', 'Arrange words', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'Did the error stop', 'Did the error stop?', '["Did", "the", "error", "stop?"]'::jsonb),
    (activity_id_var, 'It didn t work at first', 'It didn''t work at first.', '["It", "didn''t", "work", "at", "first."]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'speaking_practice', 9, 'Talk About Internet Problems', 'Practice describing fixes', '{"prompts": ["When did the problem start?", "What did you do first?", "Did you restart the router?", "Who helped you fix the problem?", "How did you solve it?"]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (
      lesson_id,
      activity_type,
      activity_order,
      title,
      description,
      content
    ) VALUES (
      'A2-L76',
      'speaking_improvement',
      10,
      'Speaking Improvement',
      'Read the improved version of your speech',
      '{"type": "speaking_improvement", "similarityThreshold": 70}'::jsonb
    );
END $$;

