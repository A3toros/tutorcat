-- =========================================
-- Pre-fill Database with Sample Lesson Data
-- A2-L89: Talking About Fitness Goals
-- =========================================

DELETE FROM grammar_sentences WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'A2-L89');
DELETE FROM vocabulary_items WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'A2-L89');
DELETE FROM lesson_activities WHERE lesson_id = 'A2-L89';
DELETE FROM lessons WHERE id = 'A2-L89';

INSERT INTO lessons (id, level, lesson_number, topic) VALUES
('A2-L89', 'A2', 89, 'Talking About Fitness Goals')
ON CONFLICT (id) DO UPDATE SET topic = EXCLUDED.topic;

DO $$
DECLARE
    lesson_id_var TEXT := 'A2-L89';
    activity_id_var UUID;
BEGIN
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'warm_up_speaking', 1, 'Fitness Goals', 'Talk about health goals', '{"prompt": "What fitness goal do you have?"}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_intro', 2, 'Fitness Goal Words', 'Learn words about goals', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'goal', 'เป้าหมาย', NULL),
    (activity_id_var, 'improve', 'พัฒนา', NULL),
    (activity_id_var, 'healthy', 'สุขภาพดี', NULL),
    (activity_id_var, 'strong', 'แข็งแรง', NULL),
    (activity_id_var, 'routine', 'กิจวัตร', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_matching_drag', 3, 'Match Fitness Goal Words', 'Match fitness goal words', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'goal', 'เป้าหมาย', NULL),
    (activity_id_var, 'improve', 'พัฒนา', NULL),
    (activity_id_var, 'healthy', 'สุขภาพดี', NULL),
    (activity_id_var, 'strong', 'แข็งแรง', NULL),
    (activity_id_var, 'routine', 'กิจวัตร', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 4, 'Complete the Sentences 1', 'Fill with the correct word', '{"text": "My ___ is to get ___. I want to ___ my routine.", "blanks": [{"id": "blank1", "text": "goal", "options": ["goal", "healthy", "strong", "improve"], "correctAnswer": "goal"}, {"id": "blank2", "text": "healthy", "options": ["healthy", "strong", "routine", "goal"], "correctAnswer": "healthy"}, {"id": "blank3", "text": "improve", "options": ["improve", "routine", "strong", "healthy"], "correctAnswer": "improve"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 5, 'Complete the Sentences 2', 'Fill with the correct word', '{"text": "I want a strong ___. This plan makes me ___.", "blanks": [{"id": "blank1", "text": "routine", "options": ["routine", "goal", "healthy", "improve"], "correctAnswer": "routine"}, {"id": "blank2", "text": "strong", "options": ["strong", "healthy", "routine", "goal"], "correctAnswer": "strong"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_explanation', 6, 'Because / So', 'Explain reasons for goals', '{"rules": "Use because for reasons; so for results.\n- I want to be healthy because I feel better.\n- I want to be strong, so I work out.", "examples": ["I want to be healthy because I feel better.", "I want to be strong, so I work out.", "I have a goal because I need a routine.", "I stretch daily, so I avoid pain.", "I eat well because I want energy."]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 7, 'Build Sentences 1', 'Arrange words', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'I want to be healthy because I feel better', 'I want to be healthy because I feel better.', '["I", "want", "to", "be", "healthy", "because", "I", "feel", "better."]'::jsonb),
    (activity_id_var, 'I want to be strong so I work out', 'I want to be strong, so I work out.', '["I", "want", "to", "be", "strong,", "so", "I", "work", "out."]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 8, 'Build Sentences 2', 'Arrange words', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'I have a goal because I need a routine', 'I have a goal because I need a routine.', '["I", "have", "a", "goal", "because", "I", "need", "a", "routine."]'::jsonb),
    (activity_id_var, 'I stretch daily so I avoid pain', 'I stretch daily, so I avoid pain.', '["I", "stretch", "daily,", "so", "I", "avoid", "pain."]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'speaking_practice', 9, 'Talk About Fitness Goals', 'Practice reasons and plans', '{"prompts": ["What fitness goal do you have, and why?", "Why is this goal important to you?", "What will you do so you can reach it?", "How do you stay motivated?", "Who supports you because they care about your health?"]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (
      lesson_id,
      activity_type,
      activity_order,
      title,
      description,
      content
    ) VALUES (
      'A2-L89',
      'speaking_improvement',
      10,
      'Speaking Improvement',
      'Read the improved version of your speech',
      '{"type": "speaking_improvement", "similarityThreshold": 70}'::jsonb
    );
END $$;

