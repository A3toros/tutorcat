-- =========================================
-- Pre-fill Database with Sample Lesson Data
-- A2-L2: Shopping & Prices
-- =========================================

-- Clear existing sample data for A2-L2 (optional - comment out if you want to keep existing data)
DELETE FROM grammar_sentences WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'A2-L2');
DELETE FROM vocabulary_items WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'A2-L2');
DELETE FROM lesson_activities WHERE lesson_id = 'A2-L2';
DELETE FROM lessons WHERE id = 'A2-L2';

INSERT INTO lessons (id, level, lesson_number, topic) VALUES
('A2-L2', 'A2', 2, 'Shopping & Prices')
ON CONFLICT (id) DO UPDATE SET topic = EXCLUDED.topic;

DO $$
DECLARE
    lesson_id_var TEXT := 'A2-L2';
    activity_id_var UUID;
BEGIN
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content) VALUES (lesson_id_var, 'warm_up_speaking', 1, 'Shopping Habits', 'Do you like shopping?', '{"prompt": "What do you usually buy when you go shopping?"}'::jsonb) RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content) VALUES (lesson_id_var, 'vocabulary_intro', 2, 'Shopping Words', 'Learn shopping vocabulary', '{}'::jsonb) RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'price', 'ราคา', NULL),
    (activity_id_var, 'discount', 'ส่วนลด', NULL),
    (activity_id_var, 'cash', 'เงินสด', NULL),
    (activity_id_var, 'credit card', 'บัตรเครดิต', NULL),
    (activity_id_var, 'receipt', 'ใบเสร็จ', NULL);

    -- 3. Vocabulary Matching Drag #1 (5 pairs - same words)
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content) VALUES (lesson_id_var, 'vocabulary_matching_drag', 3, 'Match Shopping Words 1', 'Match English words with Thai meanings', '{}'::jsonb) RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'price', 'ราคา', NULL),
    (activity_id_var, 'discount', 'ส่วนลด', NULL),
    (activity_id_var, 'cash', 'เงินสด', NULL),
    (activity_id_var, 'credit card', 'บัตรเครดิต', NULL),
    (activity_id_var, 'receipt', 'ใบเสร็จ', NULL);

    

    -- 4. Vocabulary Fill Blanks #1 (4 words: price, discount, cash, credit card - receipt left out)
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content) VALUES (lesson_id_var, 'vocabulary_fill_blanks', 4, 'Complete the Sentences 1', 'Fill in the blanks with correct words', '{"text": "What is the ___ of this shirt? Do you have a ___ for students? I will pay with ___. I don''t have a ___ with me.", "blanks": [{"id": "blank1", "text": "price", "options": ["price", "discount", "cash", "credit card"], "correctAnswer": "price"}, {"id": "blank2", "text": "discount", "options": ["price", "discount", "cash", "credit card"], "correctAnswer": "discount"}, {"id": "blank3", "text": "cash", "options": ["price", "discount", "cash", "credit card"], "correctAnswer": "cash"}, {"id": "blank4", "text": "credit card", "options": ["price", "discount", "cash", "credit card"], "correctAnswer": "credit card"}]}'::jsonb) RETURNING id INTO activity_id_var;

    -- 4. Vocabulary Fill Blanks #2 (4 words: price, discount, cash, receipt - credit card left out)
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content) VALUES (lesson_id_var, 'vocabulary_fill_blanks', 5, 'Complete the Sentences 2', 'Fill in the blanks with correct words', '{"text": "The original ___ was 500 baht. I got a 10% ___, so I paid less. I paid with ___. Can I have a ___ for my records, please?", "blanks": [{"id": "blank1", "text": "price", "options": ["price", "discount", "cash", "receipt"], "correctAnswer": "price"}, {"id": "blank2", "text": "discount", "options": ["price", "discount", "cash", "receipt"], "correctAnswer": "discount"}, {"id": "blank3", "text": "cash", "options": ["price", "discount", "cash", "receipt"], "correctAnswer": "cash"}, {"id": "blank4", "text": "receipt", "options": ["price", "discount", "cash", "receipt"], "correctAnswer": "receipt"}]}'::jsonb) RETURNING id INTO activity_id_var;

    -- 4. Grammar Explanation (5 examples - CEFR A2: How much/many, comparatives)
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content) VALUES (lesson_id_var, 'grammar_explanation', 6, 'How much / How many', 'Learn to ask about prices', '{"rules": "Use ''How much'' for uncountable nouns and prices:\n\n- How much + is/are? (How much is this?)\n- Use ''How many'' for countable nouns (How many apples?)\n- Use ''cost'' for prices (It costs 100 baht)\n- Use ''expensive'' and ''cheap'' to describe prices", "examples": ["How much is this shirt?", "How much does it cost?", "How many apples do you want?", "It costs 500 baht.", "How much are these shoes?"]}'::jsonb) RETURNING id INTO activity_id_var;

    -- 4. Grammar Sentences #1
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content) VALUES (lesson_id_var, 'grammar_sentences', 7, 'Build Sentences 1', 'Arrange words to make sentences', '{}'::jsonb) RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'How much is this shirt', 'How much is this shirt?', '["How", "much", "is", "this", "shirt?"]'::jsonb),
    (activity_id_var, 'It costs five hundred baht', 'It costs 500 baht', '["It", "costs", "500", "baht"]'::jsonb);
    -- 4. Grammar Sentences #2
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content) VALUES (lesson_id_var, 'grammar_sentences', 8, 'Build Sentences 2', 'Arrange words to make sentences', '{}'::jsonb) RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'How many apples do you want', 'How many apples do you want?', '["How", "many", "apples", "do", "you", "want?"]'::jsonb),
    (activity_id_var, 'I prefer cash to credit card', 'I prefer cash to credit card', '["I", "prefer", "cash", "to", "credit", "card"]'::jsonb);
    -- 4. Speaking Practice (5 prompts - CEFR A2: Shopping conversations)
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content) VALUES (lesson_id_var, 'speaking_practice', 9, 'Talk About Shopping', 'Practice talking about shopping', '{"prompts": ["How much does a T-shirt cost in your area?", "Do you prefer to pay by cash or card?", "Have you ever received a discount in a shop?", "What did you buy last time you went shopping?", "Where do you usually shop for food or clothes?"]}'::jsonb) RETURNING id INTO activity_id_var;

    -- 10. Speaking Improvement
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content) VALUES (lesson_id_var, 'speaking_improvement', 10, 'Speaking Improvement', 'Read the improved version of your speech', '{"type": "speaking_improvement", "similarityThreshold": 70}'::jsonb);

END $$;
