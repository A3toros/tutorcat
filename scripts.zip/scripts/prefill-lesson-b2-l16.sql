-- =========================================
-- Pre-fill Database with Sample Lesson Data
-- B2-L16: Living independently as a student
-- =========================================

DELETE FROM grammar_sentences WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'B2-L16');
DELETE FROM vocabulary_items WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'B2-L16');
DELETE FROM lesson_activities WHERE lesson_id = 'B2-L16';
DELETE FROM lessons WHERE id = 'B2-L16';

INSERT INTO lessons (id, level, lesson_number, topic) VALUES
('B2-L16', 'B2', 16, 'Living independently as a student')
ON CONFLICT (id) DO UPDATE SET topic = EXCLUDED.topic;

DO $$
DECLARE
    lesson_id_var TEXT := 'B2-L16';
    activity_id_var UUID;
BEGIN
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'warm_up_speaking', 1, 'Moving Out', 'Talk about first steps', '{"prompt": "What had you learned before moving out, and what surprised you?"}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_intro', 2, 'Independent Living Words', 'Key words for solo living', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'rent', 'ค่าเช่า', NULL),
    (activity_id_var, 'chore', 'งานบ้าน', NULL),
    (activity_id_var, 'grocery', 'ของใช้/ของกินประจำบ้าน', NULL),
    (activity_id_var, 'repair', 'ซ่อมแซม', NULL),
    (activity_id_var, 'landlord', 'เจ้าของบ้าน/ผู้ให้เช่า', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_matching_drag', 3, 'Match Living Words', 'Match words with meanings', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'rent', 'ค่าเช่า', NULL),
    (activity_id_var, 'chore', 'งานบ้าน', NULL),
    (activity_id_var, 'grocery', 'ของใช้/ของกินประจำบ้าน', NULL),
    (activity_id_var, 'repair', 'ซ่อมแซม', NULL),
    (activity_id_var, 'landlord', 'เจ้าของบ้าน/ผู้ให้เช่า', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 4, 'Complete the Sentences 1', 'Fill with the correct word', '{"text": "The ___ is due monthly. I list each ___. I track every ___.", "blanks": [{"id": "blank1", "text": "rent", "options": ["rent", "chore", "grocery", "repair"], "correctAnswer": "rent"}, {"id": "blank2", "text": "chore", "options": ["chore", "repair", "rent", "landlord"], "correctAnswer": "chore"}, {"id": "blank3", "text": "grocery", "options": ["grocery", "rent", "chore", "repair"], "correctAnswer": "grocery"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 5, 'Complete the Sentences 2', 'Fill with the correct word', '{"text": "I call the ___ when something needs ___.", "blanks": [{"id": "blank1", "text": "landlord", "options": ["landlord", "rent", "chore", "grocery"], "correctAnswer": "landlord"}, {"id": "blank2", "text": "repair", "options": ["repair", "landlord", "grocery", "chore"], "correctAnswer": "repair"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_explanation', 6, 'Past Perfect', 'Talk about what was true before moving', '{"rules": "Use had + past participle to show an action completed before another past point.\\n- I had saved money before I moved.\\n- She had never fixed a sink before living alone.", "examples": ["I had planned a budget before signing the lease.", "We had listed chores before moving in.", "He had never spoken to a landlord before last year.", "She had saved enough before paying rent.", "They had fixed small repairs before calling help."]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 7, 'Build Sentences 1', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'I had planned a budget before signing the lease', 'I had planned a budget before signing the lease.', '["I", "had", "planned", "a", "budget", "before", "signing", "the", "lease."]'::jsonb),
    (activity_id_var, 'He had never spoken to a landlord before last year', 'He had never spoken to a landlord before last year.', '["He", "had", "never", "spoken", "to", "a", "landlord", "before", "last", "year."]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 8, 'Build Sentences 2', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'She had saved enough before paying rent', 'She had saved enough before paying rent.', '["She", "had", "saved", "enough", "before", "paying", "rent."]'::jsonb),
    (activity_id_var, 'We had listed chores before moving in', 'We had listed chores before moving in.', '["We", "had", "listed", "chores", "before", "moving", "in."]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'speaking_practice', 9, 'Talk About Moving Out', 'Practice past perfect', '{"prompts": ["What had you prepared before moving out?", "What surprised you after you moved?", "Who helped when repairs were needed?" ]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (
      lesson_id,
      activity_type,
      activity_order,
      title,
      description,
      content
    ) VALUES (
      'B2-L16',
      'speaking_improvement',
      10,
      'Speaking Improvement',
      'Read the improved version of your speech',
      '{"type": "speaking_improvement", "similarityThreshold": 70}'::jsonb
    );
END $$;


