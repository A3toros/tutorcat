-- =========================================
-- Pre-fill Database with Sample Lesson Data
-- B2-L3: Culture & Traditions
-- =========================================

DELETE FROM grammar_sentences WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'B2-L3');
DELETE FROM vocabulary_items WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'B2-L3');
DELETE FROM lesson_activities WHERE lesson_id = 'B2-L3';
DELETE FROM lessons WHERE id = 'B2-L3';

INSERT INTO lessons (id, level, lesson_number, topic) VALUES
('B2-L3', 'B2', 3, 'Culture & Traditions')
ON CONFLICT (id) DO UPDATE SET topic = EXCLUDED.topic;

DO $$
DECLARE
    lesson_id_var TEXT := 'B2-L3';
    activity_id_var UUID;
BEGIN
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'warm_up_speaking', 1, 'Traditions You Keep', 'Talk about customs you follow', '{"prompt": "Which family tradition do you enjoy most, and why?"}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_intro', 2, 'Culture Words', 'Key words for culture and tradition', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'heritage', 'มรดกทางวัฒนธรรม', NULL),
    (activity_id_var, 'ritual', 'พิธีกรรม', NULL),
    (activity_id_var, 'custom', 'ธรรมเนียม', NULL),
    (activity_id_var, 'festival', 'เทศกาล', NULL),
    (activity_id_var, 'symbol', 'สัญลักษณ์', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_matching_drag', 3, 'Match Culture Words', 'Match words with meanings', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'heritage', 'มรดกทางวัฒนธรรม', NULL),
    (activity_id_var, 'ritual', 'พิธีกรรม', NULL),
    (activity_id_var, 'custom', 'ธรรมเนียม', NULL),
    (activity_id_var, 'festival', 'เทศกาล', NULL),
    (activity_id_var, 'symbol', 'สัญลักษณ์', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 4, 'Complete the Sentences 1', 'Fill with the correct word', '{"text": "This food is part of our ___. We perform a small ___ before meals. The lantern is a cultural ___.", "blanks": [{"id": "blank1", "text": "heritage", "options": ["heritage", "ritual", "symbol", "festival"], "correctAnswer": "heritage"}, {"id": "blank2", "text": "ritual", "options": ["ritual", "custom", "symbol", "heritage"], "correctAnswer": "ritual"}, {"id": "blank3", "text": "symbol", "options": ["symbol", "festival", "heritage", "ritual"], "correctAnswer": "symbol"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 5, 'Complete the Sentences 2', 'Fill with the correct word', '{"text": "The city hosts a music ___. This ___ started in my grandparents'' village. People share the story as a ___.", "blanks": [{"id": "blank1", "text": "festival", "options": ["festival", "custom", "symbol", "heritage"], "correctAnswer": "festival"}, {"id": "blank2", "text": "custom", "options": ["custom", "festival", "ritual", "heritage"], "correctAnswer": "custom"}, {"id": "blank3", "text": "heritage", "options": ["heritage", "symbol", "custom", "festival"], "correctAnswer": "heritage"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_explanation', 6, 'Relative Clauses (non-defining)', 'Add extra information smoothly', '{"rules": "Non-defining relative clauses add extra information and are set off by commas. Use who/which/where. Do not omit the relative pronoun.\\n- My aunt, who teaches history, loves rituals.\\n- The festival, which takes place in July, draws crowds.", "examples": ["The custom, which is very old, still feels fresh.", "My father, who cooks for the festival, loves the work.", "That village, where the ritual began, is famous now.", "The story, which my grandma tells, is moving.", "Our flag, which is a symbol, is treated with respect."]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 7, 'Build Sentences 1', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'My aunt, who teaches history, loves rituals', 'My aunt, who teaches history, loves rituals.', '["My", "aunt,", "who", "teaches", "history,", "loves", "rituals."]'::jsonb),
    (activity_id_var, 'The festival, which takes place in July, draws crowds', 'The festival, which takes place in July, draws crowds.', '["The", "festival,", "which", "takes", "place", "in", "July,", "draws", "crowds."]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 8, 'Build Sentences 2', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'That village, where the ritual began, is famous now', 'That village, where the ritual began, is famous now.', '["That", "village,", "where", "the", "ritual", "began,", "is", "famous", "now."]'::jsonb),
    (activity_id_var, 'The story, which my grandma tells, is moving', 'The story, which my grandma tells, is moving.', '["The", "story,", "which", "my", "grandma", "tells,", "is", "moving."]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'speaking_practice', 9, 'Talk About Traditions', 'Practice sharing traditions', '{"prompts": ["Which tradition from your family do you want to keep?", "When did you last join a festival that felt special?", "How do you explain your culture to a friend from abroad?"]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (
      lesson_id,
      activity_type,
      activity_order,
      title,
      description,
      content
    ) VALUES (
      'B2-L3',
      'speaking_improvement',
      10,
      'Speaking Improvement',
      'Read the improved version of your speech',
      '{"type": "speaking_improvement", "similarityThreshold": 70}'::jsonb
    );
END $$;


