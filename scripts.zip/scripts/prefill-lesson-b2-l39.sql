-- =========================================
-- Pre-fill Database with Sample Lesson Data
-- B2-L39: Sharing accommodation
-- =========================================

DELETE FROM grammar_sentences WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'B2-L39');
DELETE FROM vocabulary_items WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'B2-L39');
DELETE FROM lesson_activities WHERE lesson_id = 'B2-L39';
DELETE FROM lessons WHERE id = 'B2-L39';

INSERT INTO lessons (id, level, lesson_number, topic) VALUES
('B2-L39', 'B2', 39, 'Sharing accommodation')
ON CONFLICT (id) DO UPDATE SET topic = EXCLUDED.topic;

DO $$
DECLARE
    lesson_id_var TEXT := 'B2-L39';
    activity_id_var UUID;
BEGIN
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'warm_up_speaking', 1, 'Roommate Life', 'Talk about living with others', '{"prompt": "If chores were clearer, how would life look now, and what boundary matters?"}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_intro', 2, 'Roommate Words', 'Key words for shared housing', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'shared', 'ที่ใช้ร่วมกัน', NULL),
    (activity_id_var, 'split', 'แบ่ง/หาร', NULL),
    (activity_id_var, 'chore list', 'รายการงานบ้าน', NULL),
    (activity_id_var, 'utility', 'ค่าสาธารณูปโภค', NULL),
    (activity_id_var, 'quiet hours', 'เวลาห้ามเสียงดัง', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_matching_drag', 3, 'Match Roommate Words', 'Match words with meanings', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'shared', 'ที่ใช้ร่วมกัน', NULL),
    (activity_id_var, 'split', 'แบ่ง/หาร', NULL),
    (activity_id_var, 'chore list', 'รายการงานบ้าน', NULL),
    (activity_id_var, 'utility', 'ค่าสาธารณูปโภค', NULL),
    (activity_id_var, 'quiet hours', 'เวลาห้ามเสียงดัง', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 4, 'Complete the Sentences 1', 'Fill with the correct word', '{"text": "We keep a ___ on the fridge. We ___ rent and ___.", "blanks": [{"id": "blank1", "text": "chore list", "options": ["chore list", "utility", "split", "shared"], "correctAnswer": "chore list"}, {"id": "blank2", "text": "split", "options": ["split", "shared", "utility", "quiet hours"], "correctAnswer": "split"}, {"id": "blank3", "text": "utilities", "options": ["utilities", "split", "quiet hours", "shared"], "correctAnswer": "utilities"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 5, 'Complete the Sentences 2', 'Fill with the correct word', '{"text": "We set ___ for rest. The kitchen is ___.", "blanks": [{"id": "blank1", "text": "quiet hours", "options": ["quiet hours", "shared", "utility", "split"], "correctAnswer": "quiet hours"}, {"id": "blank2", "text": "shared", "options": ["shared", "quiet hours", "utility", "chore list"], "correctAnswer": "shared"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_explanation', 6, 'Mixed Conditionals', 'Link past conditions to present results', '{"rules": "Use mixed conditionals to connect past condition with present result: If + past perfect, would + base verb (now).\\n- If I had set clear chores, we would be calmer now.\\nFor present condition affecting past result: If + past simple, would have + past participle.", "examples": ["If we had set quiet hours earlier, we would be resting better now.", "If I had clarified utilities, we would be arguing less now.", "If we were clearer now, we would have avoided past fights.", "If chores were fair now, we would have saved time before.", "If they had split bills fairly, we would be trusting more now."]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 7, 'Build Sentences 1', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'If we had set quiet hours earlier, we would be resting better now', 'If we had set quiet hours earlier, we would be resting better now.', '["If", "we", "had", "set", "quiet", "hours", "earlier,", "we", "would", "be", "resting", "better", "now."]'::jsonb),
    (activity_id_var, 'If I had clarified utilities, we would be arguing less now', 'If I had clarified utilities, we would be arguing less now.', '["If", "I", "had", "clarified", "utilities,", "we", "would", "be", "arguing", "less", "now."]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 8, 'Build Sentences 2', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'If chores were fair now, we would have avoided past fights', 'If chores were fair now, we would have avoided past fights.', '["If", "chores", "were", "fair", "now,", "we", "would", "have", "avoided", "past", "fights."]'::jsonb),
    (activity_id_var, 'If they had split bills fairly, we would be trusting more now', 'If they had split bills fairly, we would be trusting more now.', '["If", "they", "had", "split", "bills", "fairly,", "we", "would", "be", "trusting", "more", "now."]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'speaking_practice', 9, 'Talk About Shared Living', 'Practice mixed conditionals', '{"prompts": ["If chores were clearer, how would life look now?", "What boundary matters most to you?", "If bills had been split fairly, how would trust be now?"]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (
      lesson_id,
      activity_type,
      activity_order,
      title,
      description,
      content
    ) VALUES (
      'B2-L39',
      'speaking_improvement',
      10,
      'Speaking Improvement',
      'Read the improved version of your speech',
      '{"type": "speaking_improvement", "similarityThreshold": 70}'::jsonb
    );
END $$;


