-- =========================================
-- Pre-fill Database with Sample Lesson Data
-- A2-L79: Traveling With Friends
-- =========================================

DELETE FROM grammar_sentences WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'A2-L79');
DELETE FROM vocabulary_items WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'A2-L79');
DELETE FROM lesson_activities WHERE lesson_id = 'A2-L79';
DELETE FROM lessons WHERE id = 'A2-L79';

INSERT INTO lessons (id, level, lesson_number, topic) VALUES
('A2-L79', 'A2', 79, 'Traveling With Friends')
ON CONFLICT (id) DO UPDATE SET topic = EXCLUDED.topic;

DO $$
DECLARE
    lesson_id_var TEXT := 'A2-L79';
    activity_id_var UUID;
BEGIN
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'warm_up_speaking', 1, 'Trips With Friends', 'Talk about traveling with friends', '{"prompt": "Who plans your trips with friends?"}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_intro', 2, 'Friends Travel Words', 'Learn words for traveling with friends', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'share', 'แบ่งปัน', NULL),
    (activity_id_var, 'ours', 'ของพวกเรา', NULL),
    (activity_id_var, 'yours', 'ของคุณ', NULL),
    (activity_id_var, 'together', 'ด้วยกัน', NULL),
    (activity_id_var, 'plan', 'แผน', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_matching_drag', 3, 'Match Friends Travel Words', 'Match travel-with-friends words', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'share', 'แบ่งปัน', NULL),
    (activity_id_var, 'ours', 'ของพวกเรา', NULL),
    (activity_id_var, 'yours', 'ของคุณ', NULL),
    (activity_id_var, 'together', 'ด้วยกัน', NULL),
    (activity_id_var, 'plan', 'แผน', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 4, 'Complete the Sentences 1', 'Fill with the correct word', '{"text": "We ___ costs. The room is ___. We travel ___.", "blanks": [{"id": "blank1", "text": "share", "options": ["share", "ours", "together", "plan"], "correctAnswer": "share"}, {"id": "blank2", "text": "ours", "options": ["ours", "yours", "share", "plan"], "correctAnswer": "ours"}, {"id": "blank3", "text": "together", "options": ["together", "share", "plan", "yours"], "correctAnswer": "together"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 5, 'Complete the Sentences 2', 'Fill with the correct word', '{"text": "Is this bag ___ or mine? Who makes the ___?", "blanks": [{"id": "blank1", "text": "yours", "options": ["yours", "ours", "share", "together"], "correctAnswer": "yours"}, {"id": "blank2", "text": "plan", "options": ["plan", "share", "together", "ours"], "correctAnswer": "plan"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_explanation', 6, 'Object/Possessive Pronouns', 'Talk about sharing and belonging', '{"rules": "Use object pronouns (me, you, us, them) and possessive pronouns (mine, yours, ours, theirs).\n- This ticket is mine.\n- We share costs between us.", "examples": ["This ticket is mine.", "Is this bag yours?", "We share costs between us.", "The plan is ours.", "That room is theirs."]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 7, 'Build Sentences 1', 'Arrange words', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'This ticket is mine', 'This ticket is mine.', '["This", "ticket", "is", "mine."]'::jsonb),
    (activity_id_var, 'Is this bag yours', 'Is this bag yours?', '["Is", "this", "bag", "yours?"]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 8, 'Build Sentences 2', 'Arrange words', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'We share costs between us', 'We share costs between us.', '["We", "share", "costs", "between", "us."]'::jsonb),
    (activity_id_var, 'The plan is ours', 'The plan is ours.', '["The", "plan", "is", "ours."]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'speaking_practice', 9, 'Talk About Travel With Friends', 'Practice sharing and planning', '{"prompts": ["Who plans the trip, and who helps them?", "Do friends share costs, or does one person pay?", "How do you divide tasks between you?", "Do you book hotels yourselves or ask someone else?", "How do you organize trips together?"]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (
      lesson_id,
      activity_type,
      activity_order,
      title,
      description,
      content
    ) VALUES (
      'A2-L79',
      'speaking_improvement',
      10,
      'Speaking Improvement',
      'Read the improved version of your speech',
      '{"type": "speaking_improvement", "similarityThreshold": 70}'::jsonb
    );
END $$;

