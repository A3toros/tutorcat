-- =========================================
-- Pre-fill Database with Sample Lesson Data
-- A2-L96: Technology at Work
-- =========================================

DELETE FROM grammar_sentences WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'A2-L96');
DELETE FROM vocabulary_items WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'A2-L96');
DELETE FROM lesson_activities WHERE lesson_id = 'A2-L96';
DELETE FROM lessons WHERE id = 'A2-L96';

INSERT INTO lessons (id, level, lesson_number, topic) VALUES
('A2-L96', 'A2', 96, 'Technology at Work')
ON CONFLICT (id) DO UPDATE SET topic = EXCLUDED.topic;

DO $$
DECLARE
    lesson_id_var TEXT := 'A2-L96';
    activity_id_var UUID;
BEGIN
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'warm_up_speaking', 1, 'Work Tech', 'Talk about tech you use at work', '{"prompt": "What technology do you use at work?"}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_intro', 2, 'Work Tech Words', 'Learn tech words for office use', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'printer', 'เครื่องพิมพ์', NULL),
    (activity_id_var, 'file', 'ไฟล์', NULL),
    (activity_id_var, 'upload', 'อัปโหลด', NULL),
    (activity_id_var, 'download', 'ดาวน์โหลด', NULL),
    (activity_id_var, 'share', 'แชร์', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_matching_drag', 3, 'Match Work Tech Words', 'Match tech words', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'printer', 'เครื่องพิมพ์', NULL),
    (activity_id_var, 'file', 'ไฟล์', NULL),
    (activity_id_var, 'upload', 'อัปโหลด', NULL),
    (activity_id_var, 'download', 'ดาวน์โหลด', NULL),
    (activity_id_var, 'share', 'แชร์', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 4, 'Complete the Sentences 1', 'Fill with the correct word', '{"text": "Send the ___. Please ___ it. Can you ___ it to the server?", "blanks": [{"id": "blank1", "text": "file", "options": ["file", "upload", "printer", "share"], "correctAnswer": "file"}, {"id": "blank2", "text": "print", "options": ["print", "share", "upload", "download"], "correctAnswer": "print"}, {"id": "blank3", "text": "upload", "options": ["upload", "download", "print", "file"], "correctAnswer": "upload"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 5, 'Complete the Sentences 2', 'Fill with the correct word', '{"text": "I will ___ it later. Please ___ the link.", "blanks": [{"id": "blank1", "text": "download", "options": ["download", "upload", "share", "file"], "correctAnswer": "download"}, {"id": "blank2", "text": "share", "options": ["share", "print", "upload", "download"], "correctAnswer": "share"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_explanation', 6, 'Present Simple', 'Describe regular tech use at work', '{"rules": "Use present simple for habits and routines.\n- I print reports every day.\n- We share files online.\nQuestions: Do you upload files? Negatives: don''t/doesn''t.", "examples": ["I print reports every day.", "We share files online.", "Do you upload files to the server?", "She doesn''t download large files.", "They use the printer in the morning."]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 7, 'Build Sentences 1', 'Arrange words', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'I print reports every day', 'I print reports every day.', '["I", "print", "reports", "every", "day."]'::jsonb),
    (activity_id_var, 'We share files online', 'We share files online.', '["We", "share", "files", "online."]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 8, 'Build Sentences 2', 'Arrange words', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'Do you upload files to the server', 'Do you upload files to the server?', '["Do", "you", "upload", "files", "to", "the", "server?"]'::jsonb),
    (activity_id_var, 'She doesn t download large files', 'She doesn''t download large files.', '["She", "doesn''t", "download", "large", "files."]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'speaking_practice', 9, 'Talk About Work Tech', 'Practice daily tech use', '{"prompts": ["What technology do you use at work?", "How does it help you do your job?", "Do you use email or chat more?", "What problems do you have with technology?", "How do you solve tech problems at work?"]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (
      lesson_id,
      activity_type,
      activity_order,
      title,
      description,
      content
    ) VALUES (
      'A2-L96',
      'speaking_improvement',
      10,
      'Speaking Improvement',
      'Read the improved version of your speech',
      '{"type": "speaking_improvement", "similarityThreshold": 70}'::jsonb
    );
END $$;

