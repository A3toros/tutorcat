-- =========================================
-- Pre-fill Database with Sample Lesson Data
-- B2-L12: Choosing a university or course
-- =========================================

DELETE FROM grammar_sentences WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'B2-L12');
DELETE FROM vocabulary_items WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'B2-L12');
DELETE FROM lesson_activities WHERE lesson_id = 'B2-L12';
DELETE FROM lessons WHERE id = 'B2-L12';

INSERT INTO lessons (id, level, lesson_number, topic) VALUES
('B2-L12', 'B2', 12, 'Choosing a university or course')
ON CONFLICT (id) DO UPDATE SET topic = EXCLUDED.topic;

DO $$
DECLARE
    lesson_id_var TEXT := 'B2-L12';
    activity_id_var UUID;
BEGIN
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'warm_up_speaking', 1, 'Shortlist Talk', 'Discuss your options', '{"prompt": "How long have you been researching schools, and what have you ruled out?"}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_intro', 2, 'University Words', 'Key words for picking courses', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'prospectus', 'โพรสเปกตัส/เอกสารหลักสูตร', NULL),
    (activity_id_var, 'faculty', 'คณะ/อาจารย์', NULL),
    (activity_id_var, 'intake', 'รอบรับเข้า', NULL),
    (activity_id_var, 'visit', 'การเยี่ยมชม', NULL),
    (activity_id_var, 'shortlist', 'รายชื่อสั้น/คัดเลือก', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_matching_drag', 3, 'Match University Words', 'Match words with meanings', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'prospectus', 'โพรสเปกตัส/เอกสารหลักสูตร', NULL),
    (activity_id_var, 'faculty', 'คณะ/อาจารย์', NULL),
    (activity_id_var, 'intake', 'รอบรับเข้า', NULL),
    (activity_id_var, 'visit', 'การเยี่ยมชม', NULL),
    (activity_id_var, 'shortlist', 'รายชื่อสั้น/คัดเลือก', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 4, 'Complete the Sentences 1', 'Fill with the correct word', '{"text": "I read the ___. The ___ impressed me. The next ___ is in August.", "blanks": [{"id": "blank1", "text": "prospectus", "options": ["prospectus", "faculty", "visit", "shortlist"], "correctAnswer": "prospectus"}, {"id": "blank2", "text": "faculty", "options": ["faculty", "intake", "prospectus", "shortlist"], "correctAnswer": "faculty"}, {"id": "blank3", "text": "intake", "options": ["intake", "visit", "prospectus", "shortlist"], "correctAnswer": "intake"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 5, 'Complete the Sentences 2', 'Fill with the correct word', '{"text": "I will ___ two campuses. My ___ now has three schools. I like the ___ who teach languages.", "blanks": [{"id": "blank1", "text": "visit", "options": ["visit", "shortlist", "faculty", "intake"], "correctAnswer": "visit"}, {"id": "blank2", "text": "shortlist", "options": ["shortlist", "visit", "prospectus", "intake"], "correctAnswer": "shortlist"}, {"id": "blank3", "text": "faculty", "options": ["faculty", "shortlist", "visit", "intake"], "correctAnswer": "faculty"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_explanation', 6, 'Present Perfect Continuous', 'Show ongoing research and choices', '{"rules": "Use have/has + been + -ing to show actions that started in the past and continue now, often with for/since.\\n- I have been comparing courses for weeks.\\n- She has been visiting campuses since March.", "examples": ["I have been reading prospectuses all month.", "She has been shortlisting schools since January.", "We have been visiting campuses for two weeks.", "They have been asking faculty about courses.", "He has been revising his shortlist lately."]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 7, 'Build Sentences 1', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'I have been comparing courses for weeks', 'I have been comparing courses for weeks.', '["I", "have", "been", "comparing", "courses", "for", "weeks."]'::jsonb),
    (activity_id_var, 'She has been shortlisting schools since January', 'She has been shortlisting schools since January.', '["She", "has", "been", "shortlisting", "schools", "since", "January."]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 8, 'Build Sentences 2', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'We have been visiting campuses for two weeks', 'We have been visiting campuses for two weeks.', '["We", "have", "been", "visiting", "campuses", "for", "two", "weeks."]'::jsonb),
    (activity_id_var, 'They have been asking faculty about courses', 'They have been asking faculty about courses.', '["They", "have", "been", "asking", "faculty", "about", "courses."]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'speaking_practice', 9, 'Talk About Choices', 'Practice ongoing decisions', '{"prompts": ["How long have you been researching schools?", "What have you ruled out so far, and why?", "Who helps you compare prospectuses?" ]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (
      lesson_id,
      activity_type,
      activity_order,
      title,
      description,
      content
    ) VALUES (
      'B2-L12',
      'speaking_improvement',
      10,
      'Speaking Improvement',
      'Read the improved version of your speech',
      '{"type": "speaking_improvement", "similarityThreshold": 70}'::jsonb
    );
END $$;


