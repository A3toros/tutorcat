-- =========================================
-- Pre-fill Database with Sample Lesson Data
-- B2-L2: Environment & Climate
-- =========================================

DELETE FROM grammar_sentences WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'B2-L2');
DELETE FROM vocabulary_items WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'B2-L2');
DELETE FROM lesson_activities WHERE lesson_id = 'B2-L2';
DELETE FROM lessons WHERE id = 'B2-L2';

INSERT INTO lessons (id, level, lesson_number, topic) VALUES
('B2-L2', 'B2', 2, 'Environment & Climate')
ON CONFLICT (id) DO UPDATE SET topic = EXCLUDED.topic;

DO $$
DECLARE
    lesson_id_var TEXT := 'B2-L2';
    activity_id_var UUID;
BEGIN
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'warm_up_speaking', 1, 'Climate in Daily Life', 'Talk about weather and choices', '{"prompt": "What small habit do you keep to be eco-friendly?"}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_intro', 2, 'Environment Words', 'Key words for climate and action', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'carbon footprint', 'รอยเท้าคาร์บอน', NULL),
    (activity_id_var, 'renewable energy', 'พลังงานหมุนเวียน', NULL),
    (activity_id_var, 'waste sorting', 'การคัดแยกขยะ', NULL),
    (activity_id_var, 'emissions', 'การปล่อยก๊าซ', NULL),
    (activity_id_var, 'drought', 'ภัยแล้ง', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_matching_drag', 3, 'Match Environment Words', 'Match words with meanings', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'carbon footprint', 'รอยเท้าคาร์บอน', NULL),
    (activity_id_var, 'renewable energy', 'พลังงานหมุนเวียน', NULL),
    (activity_id_var, 'waste sorting', 'การคัดแยกขยะ', NULL),
    (activity_id_var, 'emissions', 'การปล่อยก๊าซ', NULL),
    (activity_id_var, 'drought', 'ภัยแล้ง', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 4, 'Complete the Sentences 1', 'Fill with the correct word', '{"text": "My ___ drops when I bike to class. The city tracks car ___. We practice ___ at home.", "blanks": [{"id": "blank1", "text": "carbon footprint", "options": ["carbon footprint", "emissions", "renewable energy", "waste sorting"], "correctAnswer": "carbon footprint"}, {"id": "blank2", "text": "emissions", "options": ["emissions", "drought", "waste sorting", "renewable energy"], "correctAnswer": "emissions"}, {"id": "blank3", "text": "waste sorting", "options": ["waste sorting", "carbon footprint", "renewable energy", "drought"], "correctAnswer": "waste sorting"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 5, 'Complete the Sentences 2', 'Fill with the correct word', '{"text": "The school now uses ___ for lights. Farmers worry about ___. I check my ___ each month.", "blanks": [{"id": "blank1", "text": "renewable energy", "options": ["renewable energy", "carbon footprint", "emissions", "drought"], "correctAnswer": "renewable energy"}, {"id": "blank2", "text": "drought", "options": ["drought", "emissions", "waste sorting", "carbon footprint"], "correctAnswer": "drought"}, {"id": "blank3", "text": "carbon footprint", "options": ["carbon footprint", "renewable energy", "drought", "emissions"], "correctAnswer": "carbon footprint"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_explanation', 6, 'Reason & Result (so/such…that)', 'Link causes and effects clearly', '{"rules": "Use so + adjective/adverb + that or such + (a/an) + noun + that to show results.\\n- The air was so polluted that schools closed.\\n- It was such a hot day that we stayed inside.\\nKeep result clauses clear and specific.", "examples": ["It was so dry that local farms struggled.", "The city used such clear rules that recycling improved.", "They were so worried about emissions that they changed buses.", "It was such a long drought that prices rose.", "We were so motivated that we reduced waste quickly."]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 7, 'Build Sentences 1', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'It was so hot that classes moved online', 'It was so hot that classes moved online.', '["It", "was", "so", "hot", "that", "classes", "moved", "online."]'::jsonb),
    (activity_id_var, 'The rules were so clear that recycling improved', 'The rules were so clear that recycling improved.', '["The", "rules", "were", "so", "clear", "that", "recycling", "improved."]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 8, 'Build Sentences 2', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'It was such a long drought that prices rose', 'It was such a long drought that prices rose.', '["It", "was", "such", "a", "long", "drought", "that", "prices", "rose."]'::jsonb),
    (activity_id_var, 'They were so worried about emissions that they biked', 'They were so worried about emissions that they biked.', '["They", "were", "so", "worried", "about", "emissions", "that", "they", "biked."]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'speaking_practice', 9, 'Talk About Climate', 'Practice sharing climate actions', '{"prompts": ["What small eco habit is easiest for you to keep?", "When did weather change your plans recently?", "How do you feel when others do not recycle?" ]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (
      lesson_id,
      activity_type,
      activity_order,
      title,
      description,
      content
    ) VALUES (
      'B2-L2',
      'speaking_improvement',
      10,
      'Speaking Improvement',
      'Read the improved version of your speech',
      '{"type": "speaking_improvement", "similarityThreshold": 70}'::jsonb
    );
END $$;


