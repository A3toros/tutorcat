-- =========================================
-- Pre-fill Database with Sample Lesson Data
-- A2-L85: Rest & Sleep
-- =========================================

DELETE FROM grammar_sentences WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'A2-L85');
DELETE FROM vocabulary_items WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'A2-L85');
DELETE FROM lesson_activities WHERE lesson_id = 'A2-L85';
DELETE FROM lessons WHERE id = 'A2-L85';

INSERT INTO lessons (id, level, lesson_number, topic) VALUES
('A2-L85', 'A2', 85, 'Rest & Sleep')
ON CONFLICT (id) DO UPDATE SET topic = EXCLUDED.topic;

DO $$
DECLARE
    lesson_id_var TEXT := 'A2-L85';
    activity_id_var UUID;
BEGIN
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'warm_up_speaking', 1, 'Sleep Habits', 'Talk about sleeping habits', '{"prompt": "What time do you usually go to sleep?"}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_intro', 2, 'Sleep Words', 'Learn words about rest and sleep', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'bedtime', 'เวลานอน', NULL),
    (activity_id_var, 'nap', 'งีบหลับ', NULL),
    (activity_id_var, 'early', 'เช้า/เร็ว', NULL),
    (activity_id_var, 'late', 'ดึก/ช้า', NULL),
    (activity_id_var, 'alarm', 'นาฬิกาปลุก', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_matching_drag', 3, 'Match Sleep Words', 'Match sleep words', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'bedtime', 'เวลานอน', NULL),
    (activity_id_var, 'nap', 'งีบหลับ', NULL),
    (activity_id_var, 'early', 'เช้า/เร็ว', NULL),
    (activity_id_var, 'late', 'ดึก/ช้า', NULL),
    (activity_id_var, 'alarm', 'นาฬิกาปลุก', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 4, 'Complete the Sentences 1', 'Fill with the correct word', '{"text": "My ___ is at 11 p.m. I set an ___. I take a ___ in the afternoon.", "blanks": [{"id": "blank1", "text": "bedtime", "options": ["bedtime", "alarm", "nap", "early"], "correctAnswer": "bedtime"}, {"id": "blank2", "text": "alarm", "options": ["alarm", "bedtime", "nap", "late"], "correctAnswer": "alarm"}, {"id": "blank3", "text": "nap", "options": ["nap", "late", "early", "alarm"], "correctAnswer": "nap"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 5, 'Complete the Sentences 2', 'Fill with the correct word', '{"text": "I sleep ___ on weekdays and ___ on weekends.", "blanks": [{"id": "blank1", "text": "early", "options": ["early", "late", "bedtime", "nap"], "correctAnswer": "early"}, {"id": "blank2", "text": "late", "options": ["late", "early", "alarm", "nap"], "correctAnswer": "late"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_explanation', 6, 'Prepositions of Time', 'Describe sleep schedules', '{"rules": "Use at for clock times; on for days; in for parts of day.\n- I sleep at 11 p.m.\n- I take a nap in the afternoon.\n- On Sundays I sleep late.", "examples": ["I sleep at 11 p.m.", "I wake up at 6 a.m.", "I nap in the afternoon.", "On weekends I sleep late.", "We meet in the morning."]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 7, 'Build Sentences 1', 'Arrange words', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'I sleep at eleven p m', 'I sleep at 11 p.m.', '["I", "sleep", "at", "11", "p.m."]'::jsonb),
    (activity_id_var, 'I nap in the afternoon', 'I nap in the afternoon.', '["I", "nap", "in", "the", "afternoon."]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 8, 'Build Sentences 2', 'Arrange words', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'On weekends I sleep late', 'On weekends I sleep late.', '["On", "weekends", "I", "sleep", "late."]'::jsonb),
    (activity_id_var, 'We meet in the morning', 'We meet in the morning.', '["We", "meet", "in", "the", "morning."]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'speaking_practice', 9, 'Talk About Sleep', 'Practice sleep routines', '{"prompts": ["What time do you usually go to sleep?", "Do you sleep early on weekdays?", "Do you wake up at the same time every day?", "How many hours do you sleep at night?", "What do you do before bedtime?"]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (
      lesson_id,
      activity_type,
      activity_order,
      title,
      description,
      content
    ) VALUES (
      'A2-L85',
      'speaking_improvement',
      10,
      'Speaking Improvement',
      'Read the improved version of your speech',
      '{"type": "speaking_improvement", "similarityThreshold": 70}'::jsonb
    );
END $$;

