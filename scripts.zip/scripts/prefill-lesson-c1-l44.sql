-- =========================================
-- Pre-fill Database with Sample Lesson Data
-- C1-L44: Digital Dependency
-- =========================================
DELETE FROM lesson_activity_results WHERE lesson_id = 'C1-L44';
DELETE FROM user_progress WHERE lesson_id = 'C1-L44';
DELETE FROM lesson_history WHERE lesson_id = 'C1-L44';
DELETE FROM grammar_sentences WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'C1-L44');
DELETE FROM vocabulary_items WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'C1-L44');
DELETE FROM lesson_activities WHERE lesson_id = 'C1-L44';
DELETE FROM lessons WHERE id = 'C1-L44';

INSERT INTO lessons (id, level, lesson_number, topic) VALUES
('C1-L44', 'C1', 44, 'Digital Dependency')
ON CONFLICT (id) DO UPDATE SET topic = EXCLUDED.topic;

DO $$
DECLARE
    lesson_id_var TEXT := 'C1-L44';
    activity_id_var UUID;
BEGIN
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'warm_up_speaking', 1, 'Digital Dependency', 'Discuss digital dependency', '{"prompt": "How dependent are you on digital devices?"}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_intro', 2, 'Digital Dependency Vocabulary', 'Learn vocabulary about digital dependency', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'dependency', 'การพึ่งพา', NULL),
    (activity_id_var, 'disconnect', 'การตัดการเชื่อมต่อ', NULL),
    (activity_id_var, 'sign', 'สัญญาณ', NULL),
    (activity_id_var, 'benefit', 'ประโยชน์', NULL),
    (activity_id_var, 'balance', 'ความสมดุล', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_matching_drag', 3, 'Match Digital Dependency Words', 'Match English words with Thai meanings', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'dependency', 'การพึ่งพา', NULL),
    (activity_id_var, 'disconnect', 'การตัดการเชื่อมต่อ', NULL),
    (activity_id_var, 'sign', 'สัญญาณ', NULL),
    (activity_id_var, 'benefit', 'ประโยชน์', NULL),
    (activity_id_var, 'balance', 'ความสมดุล', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 4, 'Complete the Sentences 1', 'Fill with the correct word', '{"text": "Digital ___ creates challenges. ___ from devices requires ___.", "blanks": [{"id": "blank1", "text": "dependency", "options": ["dependency", "disconnect", "sign", "benefit"], "correctAnswer": "dependency"}, {"id": "blank2", "text": "Disconnection", "options": ["Disconnection", "Dependency", "Sign", "Benefit"], "correctAnswer": "Disconnection"}, {"id": "blank3", "text": "balance", "options": ["balance", "dependency", "sign", "benefit"], "correctAnswer": "balance"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 5, 'Complete the Sentences 2', 'Fill with the correct word', '{"text": "Warning ___ indicate ___. Technology provides ___. Maintaining ___ is essential.", "blanks": [{"id": "blank1", "text": "signs", "options": ["signs", "dependency", "disconnect", "benefit"], "correctAnswer": "signs"}, {"id": "blank2", "text": "dependency", "options": ["dependency", "sign", "disconnect", "benefit"], "correctAnswer": "dependency"}, {"id": "blank3", "text": "benefits", "options": ["benefits", "dependency", "sign", "balance"], "correctAnswer": "benefits"}, {"id": "blank4", "text": "balance", "options": ["balance", "dependency", "sign", "benefit"], "correctAnswer": "balance"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_explanation', 6, 'Inversion: Hardly/Rarely', 'Learn inversion with hardly and rarely', '{"rules": "Inversion with hardly/rarely:\n- \"Hardly ever am I offline.\" (formal emphasis)\n- \"Rarely do I disconnect.\" (emphasis on infrequency)\n- \"Hardly had I disconnected when I felt anxious.\" (past emphasis)\n\nStructure:\n- Hardly/Rarely + auxiliary + subject + verb\n- Used for emphasis and formal tone\n\nUse for:\n- Emphasizing rarity: \"Rarely am I offline.\"\n- Formal statements: \"Hardly ever do I disconnect.\"\n- Highlighting infrequency: \"Rarely do people manage without devices.\"", "examples": ["Hardly ever am I offline during the day.", "Rarely do I disconnect from digital devices.", "Hardly had I disconnected when I felt anxious.", "Rarely are people completely offline.", "Hardly ever do students manage without technology."]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 7, 'Build Sentences 1', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'Hardly ever am I offline during the day.', 'Hardly ever am I offline during the day.', '["Hardly", "ever", "am", "I", "offline", "during", "the", "day."]'::jsonb),
    (activity_id_var, 'Rarely do I disconnect from digital devices.', 'Rarely do I disconnect from digital devices.', '["Rarely", "do", "I", "disconnect", "from", "digital", "devices."]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 8, 'Build Sentences 2', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'Hardly had I disconnected when I felt anxious.', 'Hardly had I disconnected when I felt anxious.', '["Hardly", "had", "I", "disconnected", "when", "I", "felt", "anxious."]'::jsonb),
    (activity_id_var, 'Rarely are people completely offline.', 'Rarely are people completely offline.', '["Rarely", "are", "people", "completely", "offline."]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'speaking_practice', 9, 'Discuss Digital Dependency', 'Practice speaking about digital dependency', '{"prompts": ["How often are you offline?", "What happens when you disconnect?", "What signs show dependency?", "What benefits does technology provide?", "How can balance be maintained?"]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (
      lesson_id,
      activity_type,
      activity_order,
      title,
      description,
      content
    ) VALUES (
      'C1-L44',
      'speaking_improvement',
      10,
      'Speaking Improvement',
      'Read the improved version of your speech',
      '{"type": "speaking_improvement", "similarityThreshold": 70}'::jsonb
    );
END $$;
