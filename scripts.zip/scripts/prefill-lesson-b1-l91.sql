-- =========================================
-- Pre-fill Database with Sample Lesson Data
-- B1-L91: Community Safety
-- =========================================

DELETE FROM grammar_sentences WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'B1-L91');
DELETE FROM vocabulary_items WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'B1-L91');
DELETE FROM lesson_activities WHERE lesson_id = 'B1-L91';
DELETE FROM lessons WHERE id = 'B1-L91';

INSERT INTO lessons (id, level, lesson_number, topic) VALUES
('B1-L91', 'B1', 91, 'Community Safety')
ON CONFLICT (id) DO UPDATE SET topic = EXCLUDED.topic;

DO $$
DECLARE
    lesson_id_var TEXT := 'B1-L91';
    activity_id_var UUID;
BEGIN
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'warm_up_speaking', 1, 'Feeling Safe', 'Talk about keeping your area safe', '{"prompt": "Who do you call first when there is a problem on your street?"}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_intro', 2, 'Safety Words', 'Learn vocabulary about community safety', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'patrol', 'ลาดตระเวน', NULL),
    (activity_id_var, 'report', 'รายงาน', NULL),
    (activity_id_var, 'alert', 'แจ้งเตือน', NULL),
    (activity_id_var, 'incident', 'เหตุการณ์', NULL),
    (activity_id_var, 'cooperate', 'ร่วมมือ', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_matching_drag', 3, 'Match Safety Words', 'Match words with meanings', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'patrol', 'ลาดตระเวน', NULL),
    (activity_id_var, 'report', 'รายงาน', NULL),
    (activity_id_var, 'alert', 'แจ้งเตือน', NULL),
    (activity_id_var, 'incident', 'เหตุการณ์', NULL),
    (activity_id_var, 'cooperate', 'ร่วมมือ', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 4, 'Complete the Sentences 1', 'Fill with the correct word', '{"text": "We ___ at night. Neighbors ___ issues fast. An ___ was minor.", "blanks": [{"id": "blank1", "text": "patrol", "options": ["patrol", "report", "alert", "incident"], "correctAnswer": "patrol"}, {"id": "blank2", "text": "report", "options": ["report", "cooperate", "alert", "incident"], "correctAnswer": "report"}, {"id": "blank3", "text": "incident", "options": ["incident", "report", "alert", "cooperate"], "correctAnswer": "incident"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 5, 'Complete the Sentences 2', 'Fill with the correct word', '{"text": "We share an ___. People ___ well. We ___ each other quickly.", "blanks": [{"id": "blank1", "text": "alert", "options": ["alert", "cooperate", "patrol", "incident"], "correctAnswer": "alert"}, {"id": "blank2", "text": "cooperate", "options": ["cooperate", "report", "alert", "patrol"], "correctAnswer": "cooperate"}, {"id": "blank3", "text": "alert", "options": ["alert", "cooperate", "incident", "patrol"], "correctAnswer": "alert"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    -- Grammar Explanation: Relative Clauses (defining) review
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_explanation', 6, 'Relative Clauses for Safety', 'Use who/which/that to identify people/things clearly', '{"rules": "Use who/which/that without commas to add essential info.\\n- The neighbor who reports quickly helps everyone.\\n- The app that sends alerts is reliable.", "examples": ["The neighbor who reports quickly helps everyone.", "The app that sends alerts is reliable.", "The patrol that we joined started last year.", "The rule that everyone follows keeps us safe.", "The incident that we discussed was minor."]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 7, 'Build Sentences 1', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'The neighbor who reports quickly helps everyone', 'The neighbor who reports quickly helps everyone', '["The", "neighbor", "who", "reports", "quickly", "helps", "everyone"]'::jsonb),
    (activity_id_var, 'The app that sends alerts is reliable', 'The app that sends alerts is reliable', '["The", "app", "that", "sends", "alerts", "is", "reliable"]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 8, 'Build Sentences 2', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'The rule that everyone follows keeps us safe', 'The rule that everyone follows keeps us safe', '["The", "rule", "that", "everyone", "follows", "keeps", "us", "safe"]'::jsonb),
    (activity_id_var, 'The patrol that we joined started last year', 'The patrol that we joined started last year', '["The", "patrol", "that", "we", "joined", "started", "last", "year"]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'speaking_practice', 9, 'Talk About Safety', 'Practice talking about community safety', '{"prompts": ["Who do you actually trust for quick help?", "How do you share alerts with neighbors?", "When do you decide to step in?"]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (
      lesson_id,
      activity_type,
      activity_order,
      title,
      description,
      content
    ) VALUES (
      'B1-L91',
      'speaking_improvement',
      10,
      'Speaking Improvement',
      'Read the improved version of your speech',
      '{"type": "speaking_improvement", "similarityThreshold": 70}'::jsonb
    );
END $$;

