# C2 Additional Lessons Plan (L1–L100) — Student-Focused

## Requirements & Guidelines (same core as A2)
- **No ambiguity:** One clear fill-blank answer (lesson vocab only); 3 unrelated distractors.
- **Grammar sentences:** Natural, concise; avoid swap-ambiguous pairs; questions end with “?”; commas placed correctly; contractions acceptable if natural.
- **Speaking:** Student-friendly, personal, concrete but intellectually rich; avoid workplace-only/adult-only contexts; keep academic/student lens.
- **Speaking improvement:** Include `speaking_improvement` with `similarityThreshold: 70`.
- **Topics spread:** Use the provided 100 topics in order; avoid clustering similar sub-themes in adjacent lessons.
- **Grammar spread:** Cycle C2 grammar points with spaced reviews.

## CEFR C2 Grammar Coverage (from `cefr-grammar-requirements.md`)
- Register-based grammar choices; formal vs informal syntax
- Ellipsis & substitution; reference chains; information structure
- Advanced subordination; multiple embedding; fronting/postposing
- Narrative tense nuance; time-shifting & emphasis; advanced perfect forms
- Advanced mixed/implied conditionals; hypothetical past discourse
- Subtle modal distinctions (speculation/stance/criticism)
- Complex passives; transformations; clefting; fronting; postposing
- Full inversion range; embedded questions; nominal/participle clauses
- Cohesion & coherence devices; discourse markers; stylistic articles
- Idiomatic/fixed grammatical phrases; meaning-preserving rewrites

### Planned Review Counts (approx.)
- Advanced perfect / narrative shift: 8
- Advanced mixed/implied conditionals: 8
- Subtle modals (speculation/stance/criticism): 8
- Complex passives / transformations: 8
- Ellipsis/substitution/reference chains: 8
- Fronting/postposing/clefting: 8
- Inversion (full range): 7
- Embedded/nominal/participle clauses: 8
- Information structure / given–new / theme–rheme: 7
- Discourse markers & register shifts: 7
- Stylistic article use / abstraction: 6
- Idiomatic/fixed grammatical phrases: 7

## Lesson Map (topics in given order; grammar spaced)
Format per lesson:
- Topic
- Grammar focus (+review #)
- Two personal/reflective speaking prompts

1. Ethical consumerism — Subtle modals (stance) #1; prompts: How certain are you about “ethical” in your buys? What proof do you need?
2. Cultural stereotypes — Inversion (rarely/never) #1; prompts: When did you overturn a stereotype? What made you doubt it?
3. Automation and employment — Advanced passives #1; prompts: What roles should be automated? Who should decide?
4. Freedom of artistic expression — Cleft/fronting #1; prompts: What is it that art must stay free to do? When should limits apply?
5. Climate change responsibility — Mixed conditionals #1; prompts: If you had acted sooner, how would you feel now? What will you change first?
6. Bias in news reporting — Ellipsis/substitution #1; prompts: How do you track bias? What signals matter most to you?
7. Individual freedom vs social control — Contrast discourse markers #1; prompts: Where do you draw your line? When has it shifted?
8. Mental health awareness — Information structure #1; prompts: What do you foreground when you talk about mental health? What stays unsaid?
9. Artificial intelligence — Subtle modals (speculation) #2; prompts: How might AI reshape your field? What could go wrong?
10. Trust in institutions — Advanced perfect (erosion/gain) #1; prompts: How has your trust changed over time? What restored or broke it?
11. Cultural identity — Participle/nominal clauses #1; prompts: How do you define identity for yourself? Who names it for you?
12. Digital privacy — Complex passives #2; prompts: How should data be protected? What must never be stored?
13. Work–life balance — Clefting #2; prompts: What is it that tips your balance? When do you reclaim time?
14. Equality and discrimination — Inversion (little/rarely) #2; prompts: How rarely do you see fairness? What moments proved otherwise?
15. Surveillance technology — Fronting/postposing #1; prompts: Which risks do you place first? What details do you push to the end?
16. Role of government — Mixed conditionals #2; prompts: If policy had changed earlier, what would your life be now?
17. Lifelong learning — Advanced perfect #2; prompts: What have you kept learning for years? How has it evolved?
18. Misinformation and fake news — Ellipsis/reference #2; prompts: How do you collapse repeated claims? What shorthand do you use?
19. Environmental policy — Subtle modals (critique) #3; prompts: What should have been stricter? What might still shift?
20. Globalisation and culture — Contrast markers #2; prompts: Where does culture blend smoothly? Where does it clash?
21. Job satisfaction — Idiomatic/fixed phrases #1; prompts: What keeps you “in the zone”? When do you burn out?
22. Role of art in society — Cleft/fronting #3; prompts: What is it that art changes in you? Whose art moves you?
23. Ethical limits of science — Inversion (hardly/scarcely) #3; prompts: When is “because we can” not enough? What threshold stops you?
24. Social responsibility — Complex passives #3; prompts: How should responsibility be shared? Who gets held?
25. Media influence on public opinion — Information structure #2; prompts: What do you put first when persuading? What stays implicit?
26. Online education — Advanced perfect #3; prompts: How has online study reshaped your habits? What will remain?
27. Renewable energy — Mixed conditionals #3; prompts: If adoption had been faster, what would change now?
28. Generational differences — Discourse markers/register #2; prompts: How do you adjust tone across ages? When do you fail?
29. Corporate responsibility — Subtle modals (obligation) #4; prompts: What must firms do beyond law? What could they do now?
30. Freedom of speech — Fronting/postposing #2; prompts: Which caveats belong upfront? Which at the end?
31. Automation and jobs — Advanced passives #4; prompts: What work should be shielded? Who should retrain?
32. Healthcare systems — Ellipsis/substitution #3; prompts: How do you summarise complex options? What do you omit?
33. Cultural preservation — Participle clauses #2; prompts: How do you keep traditions while moving? What gets adapted?
34. Privacy in the digital age — Subtle modals (risk) #5; prompts: How might privacy be rebuilt? What could you accept?
35. Economic inequality — Inversion (little/rarely) #4; prompts: How rarely do you see mobility? What blocks it?
36. Multicultural societies — Information structure #3; prompts: What do you foreground when bridging groups? What do you background?
37. Scientific responsibility — Complex passives #5; prompts: How should findings be released? Who oversees?
38. Political participation — Cleft/fronting #4; prompts: What is it that gets you to act? What stalls you?
39. Social media and identity — Mixed conditionals #4; prompts: If you had been offline younger, who would you be now?
40. Education and social mobility — Advanced perfect #4; prompts: How has education shifted your path? What long effects remain?
41. Environmental activism — Subtle modals (criticism past) #6; prompts: What should movements have done differently? What still can?
42. Power and accountability — Inversion (never) #5; prompts: When have you seen power checked? When has it escaped?
43. Digital literacy — Ellipsis/reference #4; prompts: How do you teach literacy fast? What shortcuts work?
44. Cultural change over time — Narrative tense nuance #1; prompts: Tell a change story: what shifted first? What followed?
45. Entrepreneurship — Idiomatic/fixed phrases #2; prompts: What “makes or breaks” a venture for you? How do you “pivot”?
46. Sustainable lifestyles — Information structure #4; prompts: What do you foreground to persuade? What do you downplay?
47. National traditions — Advanced passives #6; prompts: How should traditions be presented? Who curates them?
48. Public health responsibility — Subtle modals (certainty) #7; prompts: How sure are you about mandates? What would sway you?
49. Ethics of progress — Fronting/postposing #3; prompts: Which gains must be highlighted? What costs get delayed?
50. Technology and human relationships — Mixed conditionals #5; prompts: If tech vanished tomorrow, what would change now?
51. Human rights — Inversion (seldom/rarely) #6; prompts: When have rights been visible to you? When unseen?
52. Influence of advertising — Ellipsis/substitution #5; prompts: How do you strip slogans to meaning? What sticks?
53. Meaning of success — Cleft/fronting #5; prompts: What is it that defines success for you now? How has it evolved?
54. Conservation vs development — Contrast markers #3; prompts: Where do you compromise? Where is your red line?
55. Academic pressure — Advanced perfect #5; prompts: How long have you carried pressure? What changed it?
56. Populism — Subtle modals (speculation) #8; prompts: What might fuel it where you are? What could defuse it?
57. Creativity vs commerce — Fronting/postposing #4; prompts: Which comes first for you? What can wait?
58. Lifestyle choices — Information structure #5; prompts: What do you signal first about your choices? What do you keep private?
59. Global labour markets — Complex passives #7; prompts: How are workers positioned? Who sets terms?
60. Justice and fairness — Inversion (hardly) #7; prompts: When did you barely accept a verdict? Why?
61. Digital divide — Ellipsis/reference #6; prompts: How do you speak to both connected and not? What do you leave implicit?
62. Stress in modern life — Idiomatic/fixed phrases #3; prompts: What phrases capture your stress? How do you “switch off”?
63. Education funding — Subtle modals (obligation) #9; prompts: Who must pay? What could be reformed?
64. Language and identity — Participle/nominal clauses #3; prompts: How does language name you? When does it misname you?
65. Responsibility for health — Mixed conditionals #6; prompts: If you had built habits earlier, how would you feel now?
66. Corporate ethics — Advanced passives #8; prompts: How should ethics be enforced? By whom?
67. Purpose of higher education — Cleft/fronting #6; prompts: What is it that higher ed should deliver now?
68. Ageing populations — Contrast markers #4; prompts: What pressures do you see? Where are gains?
69. Global crises — Advanced perfect #6; prompts: How have crises reshaped your plans? What lingers?
70. Innovation vs regulation — Inversion (little/rarely) #7; prompts: How rarely do you see balance? What proves it?
71. Moral responsibility of governments — Complex passives #9; prompts: How should moral duties be enacted? Who watches?
72. Cultural appropriation — Subtle modals (critique) #10; prompts: What should have been done differently? What now?
73. Leadership and authority — Inversion (never/rarely) #8; prompts: When did authority earn trust? When not?
74. Technology dependence — Information structure #6; prompts: What do you reveal about your dependence? What do you hide?
75. Journalism ethics — Ellipsis/substitution #7; prompts: How do you compress standards into practice? What do you cut?
76. Happiness and fulfilment — Idiomatic/fixed phrases #4; prompts: What “keeps you going”? What “wears you down”?
77. Environmental responsibility — Mixed conditionals #7; prompts: If policy had shifted earlier, what now?
78. Work ethics — Advanced passives #9; prompts: How should work norms be enforced? Who defines them?
79. Freedom of the press — Fronting/postposing #5; prompts: Which limits belong upfront? Which later?
80. Urbanisation and the environment — Contrast markers #5; prompts: Where is the trade-off clearest? How do you weigh it?
81. Decision-making under pressure — Information structure #7; prompts: What do you surface first? What stays hidden?
82. Arts and cultural representation — Cleft/fronting #7; prompts: What is it that art represents best? Who decides?
83. Individual ambition — Subtle modals (speculation) #9; prompts: What might ambition cost you? What could it unlock?
84. Consumer society — Ellipsis/reference #8; prompts: How do you talk about consumption without naming brands?
85. Social cohesion — Inversion (seldom) #9; prompts: When do you feel unity? When does it fracture?
86. Ethics in daily life — Idiomatic/fixed phrases #5; prompts: What “lines” won’t you cross? When have you “looked the other way”?
87. Preventive medicine — Advanced passives #10; prompts: How should prevention be prioritized? Who leads?
88. Risk in modern life — Mixed conditionals #8; prompts: If you had taken fewer risks before, where now?
89. Education systems — Contrast markers #6; prompts: What works where you are? What fails?
90. Political leadership — Subtle modals (criticism) #11; prompts: What should leaders have done? What can they still do?
91. Social change — Narrative tense nuance #2; prompts: Tell a shift you witnessed. What catalyzed it?
92. Ethics of technology — Complex passives #11; prompts: How should tech be governed? Who enforces?
93. Global travel and tourism — Ellipsis/substitution #9; prompts: How do you discuss travel impacts succinctly?
94. The future of work — Advanced perfect #7; prompts: How will your work have changed in 10 years?
95. International cooperation — Inversion (hardly/scarcely) #8; prompts: When has cooperation barely held? Why?
96. Cultural misunderstandings — Participle clauses #4; prompts: How do you repair quickly? What do you clarify first?
97. Personal development — Information structure #8; prompts: What do you highlight about your growth? What do you downplay?
98. Accountability — Cleft/fronting #8; prompts: What is it that accountability demands from you?
99. Philosophy and life views — Subtle modals (stance) #12; prompts: How certain are you about your worldview? What could shift it?
100. Human values in the modern world — Inversion/cleft wrap #9; prompts: What values will you hold regardless? When have they been tested?

## Coverage Checkpoint (indicative)
- Advanced perfect / narrative shift: L10,17,24,40,44,55,69,94
- Advanced mixed/implied conditionals: L5,16,27,39,50,65,77,88
- Subtle modals (speculation/stance/critique): L1,9,19,29,34,41,56,63,70,83,90,99
- Complex passives / transformations: L3,12,24,31,37,47,59,66,78,87,92
- Ellipsis/substitution/reference: L6,18,32,43,52,61,75,84,93
- Fronting/postposing/clefting: L4,13,22,30,38,49,57,67,79,82,98
- Inversion (full range): L2,14,23,25,35,42,51,60,70,73,85,95,100
- Participle/nominal/embedded clauses: L11,33,64,96
- Information structure / theme–rheme: L8,25,36,46,58,74,81,97
- Discourse markers & register: L7,20,28,45,57,68,80,89
- Stylistic articles / abstraction: L11,19,30,38,45,72
- Idiomatic / fixed grammatical phrases: L21,45,62,76,86
- Future-facing perfect/forward look: L48,94

