-- =========================================
-- Pre-fill Database with Sample Lesson Data
-- A1-L17: Countries & Nationalities
-- =========================================

DELETE FROM grammar_sentences WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'A1-L17');
DELETE FROM vocabulary_items WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'A1-L17');
DELETE FROM lesson_activities WHERE lesson_id = 'A1-L17';
DELETE FROM lessons WHERE id = 'A1-L17';

INSERT INTO lessons (id, level, lesson_number, topic) VALUES
('A1-L17', 'A1', 17, 'Countries & Nationalities')
ON CONFLICT (id) DO UPDATE SET topic = EXCLUDED.topic;

DO $$
DECLARE
    lesson_id_var TEXT := 'A1-L17';
    activity_id_var UUID;
BEGIN
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'warm_up_speaking', 1, 'Where You Are From', 'Talk about your country', '{"prompt": "Where are you from?"}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_intro', 2, 'Country Words', 'Learn country words', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'country', 'ประเทศ', NULL),
    (activity_id_var, 'city', 'เมือง', NULL),
    (activity_id_var, 'from', 'จาก', NULL),
    (activity_id_var, 'Thai', 'คนไทย', NULL),
    (activity_id_var, 'Korean', 'คนเกาหลี', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_matching_drag', 3, 'Match Country Words', 'Match country words', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'country', 'ประเทศ', NULL),
    (activity_id_var, 'city', 'เมือง', NULL),
    (activity_id_var, 'from', 'จาก', NULL),
    (activity_id_var, 'Thai', 'คนไทย', NULL),
    (activity_id_var, 'Korean', 'คนเกาหลี', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 4, 'Complete the Sentences 1', 'Fill with the correct word', '{"text": "I am ___. I am from ___.", "blanks": [{"id": "blank1", "text": "Thai", "options": ["Thai", "Korean", "city", "country"], "correctAnswer": "Thai"}, {"id": "blank2", "text": "Thailand", "options": ["Thailand", "Korea", "city", "from"], "correctAnswer": "Thailand"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 5, 'Complete the Sentences 2', 'Fill with the correct word', '{"text": "He is ___. He is from ___.", "blanks": [{"id": "blank1", "text": "Korean", "options": ["Korean", "Thai", "city", "country"], "correctAnswer": "Korean"}, {"id": "blank2", "text": "Korea", "options": ["Korea", "Thailand", "city", "from"], "correctAnswer": "Korea"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_explanation', 6, 'Be + From', 'Say where you are from', '{"rules": "Use be + from + place.\n- I am from Thailand.\n- She is from Korea.\nAsk: Where are you from?", "examples": ["I am from Thailand.", "She is from Korea.", "He is from a small city.", "Where are you from?", "Are you from Bangkok?"]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 7, 'Build Sentences 1', 'Arrange words', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'I am from Thailand', 'I am from Thailand.', '["I", "am", "from", "Thailand."]'::jsonb),
    (activity_id_var, 'She is from Korea', 'She is from Korea.', '["She", "is", "from", "Korea."]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 8, 'Build Sentences 2', 'Arrange words', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'Where are you from', 'Where are you from?', '["Where", "are", "you", "from?"]'::jsonb),
    (activity_id_var, 'Are you from Bangkok', 'Are you from Bangkok?', '["Are", "you", "from", "Bangkok?"]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'speaking_practice', 9, 'Talk About Countries', 'Practice saying where you are from', '{"prompts": ["Where are you from?", "Are you from Thailand?", "What city are you from?", "Is your friend Thai?", "Is he from Korea?"]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (
      lesson_id,
      activity_type,
      activity_order,
      title,
      description,
      content
    ) VALUES (
      'A1-L17',
      'speaking_improvement',
      10,
      'Speaking Improvement',
      'Read the improved version of your speech',
      '{"type": "speaking_improvement", "similarityThreshold": 70}'::jsonb
    );
END $$;

