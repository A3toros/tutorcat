-- =========================================
-- Pre-fill Database with Sample Lesson Data
-- B2-L5: Work–Life Balance
-- =========================================

DELETE FROM grammar_sentences WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'B2-L5');
DELETE FROM vocabulary_items WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'B2-L5');
DELETE FROM lesson_activities WHERE lesson_id = 'B2-L5';
DELETE FROM lessons WHERE id = 'B2-L5';

INSERT INTO lessons (id, level, lesson_number, topic) VALUES
('B2-L5', 'B2', 5, 'Work–Life Balance')
ON CONFLICT (id) DO UPDATE SET topic = EXCLUDED.topic;

DO $$
DECLARE
    lesson_id_var TEXT := 'B2-L5';
    activity_id_var UUID;
BEGIN
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'warm_up_speaking', 1, 'Balancing Your Week', 'Talk about balance choices', '{"prompt": "When do you decide to stop working for the day?"}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_intro', 2, 'Balance Words', 'Key words for managing time', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'burnout', 'ภาวะหมดไฟ', NULL),
    (activity_id_var, 'boundary', 'ขอบเขต', NULL),
    (activity_id_var, 'downtime', 'เวลาพัก', NULL),
    (activity_id_var, 'overtime', 'การทำงานล่วงเวลา', NULL),
    (activity_id_var, 'recharge', 'ชาร์จพลัง/พักฟื้น', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_matching_drag', 3, 'Match Balance Words', 'Match words with meanings', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'burnout', 'ภาวะหมดไฟ', NULL),
    (activity_id_var, 'boundary', 'ขอบเขต', NULL),
    (activity_id_var, 'downtime', 'เวลาพัก', NULL),
    (activity_id_var, 'overtime', 'การทำงานล่วงเวลา', NULL),
    (activity_id_var, 'recharge', 'ชาร์จพลัง/พักฟื้น', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 4, 'Complete the Sentences 1', 'Fill with the correct word', '{"text": "I set a clear ___. Too much ___ leads to stress. I schedule ___ on Sundays.", "blanks": [{"id": "blank1", "text": "boundary", "options": ["boundary", "overtime", "burnout", "downtime"], "correctAnswer": "boundary"}, {"id": "blank2", "text": "overtime", "options": ["overtime", "burnout", "recharge", "boundary"], "correctAnswer": "overtime"}, {"id": "blank3", "text": "downtime", "options": ["downtime", "recharge", "burnout", "overtime"], "correctAnswer": "downtime"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 5, 'Complete the Sentences 2', 'Fill with the correct word', '{"text": "After exams I need to ___. Ignoring signs can cause ___. A small ___ helps me reset.", "blanks": [{"id": "blank1", "text": "recharge", "options": ["recharge", "burnout", "boundary", "downtime"], "correctAnswer": "recharge"}, {"id": "blank2", "text": "burnout", "options": ["burnout", "overtime", "recharge", "downtime"], "correctAnswer": "burnout"}, {"id": "blank3", "text": "break", "options": ["downtime", "boundary", "recharge", "burnout"], "correctAnswer": "downtime"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_explanation', 6, 'Present Perfect Continuous', 'Show ongoing actions and effects', '{"rules": "Use have/has + been + -ing to show actions that started in the past and continue now, often with duration.\\n- I have been working since 8 a.m.\\n- She has been balancing classes and work for months.\\nUse for + period or since + point in time.", "examples": ["I have been studying late all week.", "She has been setting boundaries with her boss.", "They have been taking short breaks every day.", "We have been avoiding overtime this month.", "He has been recharging by walking daily."]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 7, 'Build Sentences 1', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'I have been studying late all week', 'I have been studying late all week.', '["I", "have", "been", "studying", "late", "all", "week."]'::jsonb),
    (activity_id_var, 'She has been setting boundaries with her boss', 'She has been setting boundaries with her boss.', '["She", "has", "been", "setting", "boundaries", "with", "her", "boss."]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 8, 'Build Sentences 2', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'They have been taking short breaks every day', 'They have been taking short breaks every day.', '["They", "have", "been", "taking", "short", "breaks", "every", "day."]'::jsonb),
    (activity_id_var, 'We have been avoiding overtime this month', 'We have been avoiding overtime this month.', '["We", "have", "been", "avoiding", "overtime", "this", "month."]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'speaking_practice', 9, 'Talk About Balance', 'Practice sharing balance choices', '{"prompts": ["When do you notice early signs of burnout?", "How do you protect downtime during exams?", "What routine helps you recharge fast?"]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (
      lesson_id,
      activity_type,
      activity_order,
      title,
      description,
      content
    ) VALUES (
      'B2-L5',
      'speaking_improvement',
      10,
      'Speaking Improvement',
      'Read the improved version of your speech',
      '{"type": "speaking_improvement", "similarityThreshold": 70}'::jsonb
    );
END $$;


