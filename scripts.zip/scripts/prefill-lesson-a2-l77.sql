-- =========================================
-- Pre-fill Database with Sample Lesson Data
-- A2-L77: Favorite Celebrations
-- =========================================

DELETE FROM grammar_sentences WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'A2-L77');
DELETE FROM vocabulary_items WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'A2-L77');
DELETE FROM lesson_activities WHERE lesson_id = 'A2-L77';
DELETE FROM lessons WHERE id = 'A2-L77';

INSERT INTO lessons (id, level, lesson_number, topic) VALUES
('A2-L77', 'A2', 77, 'Favorite Celebrations')
ON CONFLICT (id) DO UPDATE SET topic = EXCLUDED.topic;

DO $$
DECLARE
    lesson_id_var TEXT := 'A2-L77';
    activity_id_var UUID;
BEGIN
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'warm_up_speaking', 1, 'Best Celebration', 'Talk about your best celebration', '{"prompt": "What celebrations have you enjoyed?"}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_intro', 2, 'Celebration Words', 'Learn celebration vocabulary', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'favorite', 'ที่ชอบที่สุด', NULL),
    (activity_id_var, 'celebrate', 'ฉลอง', NULL),
    (activity_id_var, 'enjoyed', 'สนุก/เพลิดเพลิน', NULL),
    (activity_id_var, 'remember', 'จำได้', NULL),
    (activity_id_var, 'time', 'เวลา/ช่วงเวลา', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_matching_drag', 3, 'Match Celebration Words', 'Match celebration words', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'favorite', 'ที่ชอบที่สุด', NULL),
    (activity_id_var, 'celebrate', 'ฉลอง', NULL),
    (activity_id_var, 'enjoyed', 'สนุก/เพลิดเพลิน', NULL),
    (activity_id_var, 'remember', 'จำได้', NULL),
    (activity_id_var, 'time', 'เวลา/ช่วงเวลา', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 4, 'Complete the Sentences 1', 'Fill with the correct word', '{"text": "My ___ holiday is New Year. We ___ together. I ___ it well.", "blanks": [{"id": "blank1", "text": "favorite", "options": ["favorite", "celebrate", "remember", "enjoyed"], "correctAnswer": "favorite"}, {"id": "blank2", "text": "celebrate", "options": ["celebrate", "enjoyed", "remember", "time"], "correctAnswer": "celebrate"}, {"id": "blank3", "text": "remember", "options": ["remember", "enjoyed", "celebrate", "time"], "correctAnswer": "remember"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 5, 'Complete the Sentences 2', 'Fill with the correct word', '{"text": "We ___ that ___ with family.", "blanks": [{"id": "blank1", "text": "enjoyed", "options": ["enjoyed", "celebrate", "remember", "favorite"], "correctAnswer": "enjoyed"}, {"id": "blank2", "text": "time", "options": ["time", "holiday", "favorite", "remember"], "correctAnswer": "time"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_explanation', 6, 'Present Perfect (experience)', 'Talk about experiences', '{"rules": "Use present perfect for life experiences.\n- I have celebrated New Year in another country.\nForm: have/has + past participle.\nQuestions: Have you ever…?", "examples": ["I have celebrated New Year abroad.", "She has enjoyed many festivals.", "Have you ever joined a big parade?", "We have eaten special holiday food.", "They have celebrated together for years."]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 7, 'Build Sentences 1', 'Arrange words', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'I have celebrated New Year abroad', 'I have celebrated New Year abroad.', '["I", "have", "celebrated", "New", "Year", "abroad."]'::jsonb),
    (activity_id_var, 'She has enjoyed many festivals', 'She has enjoyed many festivals.', '["She", "has", "enjoyed", "many", "festivals."]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 8, 'Build Sentences 2', 'Arrange words', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'Have you ever joined a big parade', 'Have you ever joined a big parade?', '["Have", "you", "ever", "joined", "a", "big", "parade?"]'::jsonb),
    (activity_id_var, 'We have eaten special holiday food', 'We have eaten special holiday food.', '["We", "have", "eaten", "special", "holiday", "food."]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'speaking_practice', 9, 'Talk About Celebrations', 'Practice sharing favorite celebrations', '{"prompts": ["What celebrations have you enjoyed?", "Have you celebrated with family or friends?", "Which celebration have you liked the most?", "How have you celebrated it?", "Why has it been special for you?"]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (
      lesson_id,
      activity_type,
      activity_order,
      title,
      description,
      content
    ) VALUES (
      'A2-L77',
      'speaking_improvement',
      10,
      'Speaking Improvement',
      'Read the improved version of your speech',
      '{"type": "speaking_improvement", "similarityThreshold": 70}'::jsonb
    );
END $$;

