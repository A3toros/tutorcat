-- Migration: Fix progress calculation for score_average achievements
-- The progress was incorrectly calculated as AVG(score) / requirement_value * 100
-- It should be calculated as lessons_completed / requirement_count * 100

-- Update the get_user_achievements_with_progress function to fix progress calculation
CREATE OR REPLACE FUNCTION get_user_achievements_with_progress(p_user_id UUID)
RETURNS TABLE (
    achievement_id UUID,
    code VARCHAR(50),
    name VARCHAR(255),
    description TEXT,
    icon VARCHAR(50),
    category VARCHAR(50),
    rarity VARCHAR(20),
    points INTEGER,
    earned_at TIMESTAMP,
    current_progress INTEGER,
    target_progress INTEGER,
    progress_percentage NUMERIC
) AS $$
BEGIN
    RETURN QUERY
    SELECT 
        a.id,
        a.code,
        a.name,
        a.description,
        a.icon,
        a.category,
        a.rarity,
        a.points,
        ua.earned_at,
        -- Calculate current progress on-the-fly based on requirement_type
        CASE a.requirement_type
            WHEN 'lesson_count' THEN
                (SELECT COUNT(*)::INTEGER FROM user_progress WHERE user_id = p_user_id AND completed = true)
            WHEN 'perfect_score_count' THEN
                (SELECT COUNT(*)::INTEGER FROM user_progress WHERE user_id = p_user_id AND completed = true AND score >= 100)
            WHEN 'score_average' THEN
                -- For score_average, return the number of completed lessons (progress toward requirement_count)
                (SELECT COUNT(*)::INTEGER FROM user_progress WHERE user_id = p_user_id AND completed = true)
            WHEN 'score_threshold_count' THEN
                (SELECT COUNT(*)::INTEGER FROM user_progress WHERE user_id = p_user_id AND completed = true AND score >= a.requirement_value)
            WHEN 'stars' THEN
                (SELECT total_stars FROM users WHERE id = p_user_id)
            WHEN 'level_complete' THEN
                -- For level completion, calculate based on level in code
                CASE 
                    WHEN a.code LIKE 'a1_master' THEN get_user_completed_lessons_in_level(p_user_id, 'A1')
                    WHEN a.code LIKE 'a2_master' THEN get_user_completed_lessons_in_level(p_user_id, 'A2')
                    WHEN a.code LIKE 'b1_master' THEN get_user_completed_lessons_in_level(p_user_id, 'B1')
                    WHEN a.code LIKE 'b2_master' THEN get_user_completed_lessons_in_level(p_user_id, 'B2')
                    WHEN a.code LIKE 'c1_master' THEN get_user_completed_lessons_in_level(p_user_id, 'C1')
                    WHEN a.code LIKE 'c2_master' THEN get_user_completed_lessons_in_level(p_user_id, 'C2')
                    ELSE 0
                END
            WHEN 'distinct_levels' THEN
                (SELECT COUNT(DISTINCT l.level)::INTEGER
                 FROM user_progress up
                 JOIN lessons l ON up.lesson_id = l.id
                 WHERE up.user_id = p_user_id AND up.completed = true)
            ELSE 0
        END as current_progress,
        -- Target progress: for level_complete, use dynamic total; otherwise use requirement_value
        CASE 
            WHEN a.requirement_type = 'level_complete' THEN
                CASE 
                    WHEN a.code LIKE 'a1_master' THEN get_total_lessons_in_level('A1')
                    WHEN a.code LIKE 'a2_master' THEN get_total_lessons_in_level('A2')
                    WHEN a.code LIKE 'b1_master' THEN get_total_lessons_in_level('B1')
                    WHEN a.code LIKE 'b2_master' THEN get_total_lessons_in_level('B2')
                    WHEN a.code LIKE 'c1_master' THEN get_total_lessons_in_level('C1')
                    WHEN a.code LIKE 'c2_master' THEN get_total_lessons_in_level('C2')
                    ELSE 0
                END
            WHEN a.requirement_type = 'score_threshold_count' THEN
                COALESCE(a.requirement_count, a.requirement_value)
            WHEN a.requirement_type = 'score_average' THEN
                -- For score_average, target is the number of lessons needed (requirement_count)
                COALESCE(a.requirement_count, a.requirement_value)
            WHEN a.requirement_type = 'distinct_levels' THEN
                a.requirement_value
            WHEN a.requirement_type = 'stars' THEN
                -- For stars, target is the number of stars needed (requirement_value)
                a.requirement_value
            ELSE a.requirement_value
        END as target_progress,
        CASE 
            WHEN a.requirement_type = 'level_complete' THEN
                -- For level completion, use dynamic total
                CASE 
                    WHEN a.code LIKE 'a1_master' THEN 
                        ROUND((get_user_completed_lessons_in_level(p_user_id, 'A1')::NUMERIC / NULLIF(get_total_lessons_in_level('A1'), 0)) * 100, 1)
                    WHEN a.code LIKE 'a2_master' THEN 
                        ROUND((get_user_completed_lessons_in_level(p_user_id, 'A2')::NUMERIC / NULLIF(get_total_lessons_in_level('A2'), 0)) * 100, 1)
                    WHEN a.code LIKE 'b1_master' THEN 
                        ROUND((get_user_completed_lessons_in_level(p_user_id, 'B1')::NUMERIC / NULLIF(get_total_lessons_in_level('B1'), 0)) * 100, 1)
                    WHEN a.code LIKE 'b2_master' THEN 
                        ROUND((get_user_completed_lessons_in_level(p_user_id, 'B2')::NUMERIC / NULLIF(get_total_lessons_in_level('B2'), 0)) * 100, 1)
                    WHEN a.code LIKE 'c1_master' THEN 
                        ROUND((get_user_completed_lessons_in_level(p_user_id, 'C1')::NUMERIC / NULLIF(get_total_lessons_in_level('C1'), 0)) * 100, 1)
                    WHEN a.code LIKE 'c2_master' THEN 
                        ROUND((get_user_completed_lessons_in_level(p_user_id, 'C2')::NUMERIC / NULLIF(get_total_lessons_in_level('C2'), 0)) * 100, 1)
                    ELSE 0
                END
            WHEN a.requirement_type = 'score_threshold_count' THEN
                ROUND((SELECT COUNT(*)::NUMERIC FROM user_progress WHERE user_id = p_user_id AND completed = true AND score >= a.requirement_value) / NULLIF(COALESCE(a.requirement_count, a.requirement_value), 0) * 100, 1)
            WHEN a.requirement_type = 'score_average' THEN
                -- For score_average, calculate progress based on lessons completed vs requirement_count
                -- Progress is: lessons_completed / requirement_count * 100
                CASE 
                    WHEN COALESCE(a.requirement_count, a.requirement_value) > 0 THEN
                        ROUND(
                            (SELECT COUNT(*)::NUMERIC FROM user_progress WHERE user_id = p_user_id AND completed = true) 
                            / NULLIF(COALESCE(a.requirement_count, a.requirement_value), 0) * 100, 
                            1
                        )
                    ELSE 0
                END
            WHEN a.requirement_type = 'distinct_levels' THEN
                -- For distinct_levels, calculate progress based on distinct levels completed
                ROUND(
                    (SELECT COUNT(DISTINCT l.level)::NUMERIC
                     FROM user_progress up
                     JOIN lessons l ON up.lesson_id = l.id
                     WHERE up.user_id = p_user_id AND up.completed = true)
                    / NULLIF(a.requirement_value, 0) * 100,
                    1
                )
            WHEN a.requirement_type = 'stars' THEN
                -- For stars, calculate progress as: current_stars / required_stars * 100
                ROUND(
                    (SELECT COALESCE(total_stars, 0)::NUMERIC FROM users WHERE id = p_user_id)
                    / NULLIF(a.requirement_value, 0) * 100,
                    1
                )
            WHEN a.requirement_value > 0 THEN
                ROUND((CASE a.requirement_type
                    WHEN 'lesson_count' THEN (SELECT COUNT(*)::NUMERIC FROM user_progress WHERE user_id = p_user_id AND completed = true)
                    WHEN 'perfect_score_count' THEN (SELECT COUNT(*)::NUMERIC FROM user_progress WHERE user_id = p_user_id AND completed = true AND score >= 100)
                    ELSE 0
                END / a.requirement_value::NUMERIC) * 100, 1)
            ELSE 0
        END as progress_percentage
    FROM achievements a
    LEFT JOIN user_achievements ua ON a.id = ua.achievement_id AND ua.user_id = p_user_id
    ORDER BY 
        CASE WHEN ua.earned_at IS NOT NULL THEN 0 ELSE 1 END,
        a.category,
        a.points DESC;
END;
$$ LANGUAGE plpgsql;

-- Note: This migration fixes the progress calculation for:
-- 
-- 1. score_average achievements:
--    - "High Achiever" (average 90%+ across 25 lessons) - will show 5/25 = 20% if 5 lessons completed (not 181%)
--    - "Excellence" (average 90%+ across 50 lessons) - will show 5/50 = 10% if 5 lessons completed (not 181%)
--    - "Master Student" (average 95%+ across 25 lessons) - will show 5/25 = 20% if 5 lessons completed (not 171%)
--    - "Top Performer" (average 95%+ across 10 lessons) - will show correct progress
--    - "Good Start" (average 70%+ on first lesson) - will show correct progress
--    Bug: progress was calculated as AVG(score) / requirement_value * 100
--    Fix: progress is now calculated as lessons_completed / requirement_count * 100
--
-- 2. stars achievements:
--    - "Star Collector" (earn 10 stars) - will show 4/10 = 40% if 4 stars earned (not 90%)
--    - All other star achievements will show correct progress
--    Fix: Added explicit CASE for 'stars' type to ensure correct calculation

