-- ===== LESSON B2-L55 =====

-- =========================================
-- Pre-fill Database with Sample Lesson Data
-- B2-L55: Learning from experience
-- =========================================

DELETE FROM lesson_activity_results WHERE lesson_id = 'B2-L55';
DELETE FROM user_progress WHERE lesson_id = 'B2-L55';
DELETE FROM lesson_history WHERE lesson_id = 'B2-L55';
DELETE FROM grammar_sentences WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'B2-L55');
DELETE FROM vocabulary_items WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'B2-L55');
DELETE FROM lesson_activities WHERE lesson_id = 'B2-L55';
DELETE FROM lessons WHERE id = 'B2-L55';

INSERT INTO lessons (id, level, lesson_number, topic) VALUES
('B2-L55', 'B2', 55, 'Learning from experience')
ON CONFLICT (id) DO UPDATE SET topic = EXCLUDED.topic;

DO $$
DECLARE
    lesson_id_var TEXT := 'B2-L55';
    activity_id_var UUID;
BEGIN
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'warm_up_speaking', 1, 'Life Lessons', 'Talk about what you learned from experiences', '{"prompt": "Although it was hard, what did you learn?"}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_intro', 2, 'Learning Words', 'Learn words related to learning from experience', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'lesson', 'บทเรียน', NULL),
    (activity_id_var, 'revise', 'แก้ไข', NULL),
    (activity_id_var, 'iterate', 'ทำซ้ำ', NULL),
    (activity_id_var, 'hindsight', 'มองย้อนหลัง', NULL),
    (activity_id_var, 'improve', 'ปรับปรุง', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_matching_drag', 3, 'Match Learning Words', 'Match words related to learning from experience', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'lesson', 'บทเรียน', NULL),
    (activity_id_var, 'revise', 'แก้ไข', NULL),
    (activity_id_var, 'iterate', 'ทำซ้ำ', NULL),
    (activity_id_var, 'hindsight', 'มองย้อนหลัง', NULL),
    (activity_id_var, 'improve', 'ปรับปรุง', NULL);

    -- 4. Vocabulary Fill Blanks #1
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 4, 'Complete the Sentences 1', 'Fill in the blanks with correct words', '{"text": "I learned a valuable ___. I need to ___ my work. We ___ the process.", "blanks": [{"id": "blank1", "text": "lesson", "options": ["lesson", "revise", "iterate", "hindsight"], "correctAnswer": "lesson"}, {"id": "blank2", "text": "revise", "options": ["revise", "lesson", "iterate", "improve"], "correctAnswer": "revise"}, {"id": "blank3", "text": "iterate", "options": ["iterate", "lesson", "revise", "hindsight"], "correctAnswer": "iterate"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    -- 5. Vocabulary Fill Blanks #2
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 5, 'Complete the Sentences 2', 'Fill in the blanks with correct words', '{"text": "In ___, I see my mistakes. I want to ___ my skills. We ___ our approach.", "blanks": [{"id": "blank1", "text": "hindsight", "options": ["hindsight", "lesson", "revise", "improve"], "correctAnswer": "hindsight"}, {"id": "blank2", "text": "improve", "options": ["improve", "lesson", "revise", "hindsight"], "correctAnswer": "improve"}, {"id": "blank3", "text": "improve", "options": ["improve", "hindsight", "revise", "iterate"], "correctAnswer": "improve"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    -- 6. Grammar Explanation
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_explanation', 6, 'Contrast with Although/However', 'Learn although/however for contrast', '{"rules": "Use although and however to show contrast:\n\n- Although = at the start of a clause (Although it was difficult, I learned)\n- However = between sentences or clauses (I failed; however, I studied harder)\n- But = in the middle of a sentence (It was hard, but I learned)\n- All show contrast between two ideas\n- Although and but are similar, but different positions", "examples": ["Although it was difficult, I learned a valuable lesson.", "I failed the test; however, I studied harder next time.", "The project was challenging, but I improved my skills.", "Although I struggled, I didn''t give up.", "It was hard; however, I succeeded in the end."]}'::jsonb)
    RETURNING id INTO activity_id_var;

    -- 7. Grammar Sentences #1
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 7, 'Build Sentences 1', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'Although it was difficult I learned a valuable lesson', 'Although it was difficult, I learned a valuable lesson.', '["Although", "it", "was", "difficult,", "I", "learned", "a", "valuable", "lesson."]'::jsonb),
    (activity_id_var, 'I failed the test however I studied harder next time', 'I failed the test; however, I studied harder next time.', '["I", "failed", "the", "test;", "however,", "I", "studied", "harder", "next", "time."]'::jsonb);

    -- 8. Grammar Sentences #2
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 8, 'Build Sentences 2', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'The project was challenging but I improved my skills', 'The project was challenging, but I improved my skills.', '["The", "project", "was", "challenging,", "but", "I", "improved", "my", "skills."]'::jsonb),
    (activity_id_var, 'Although I struggled I did not give up', 'Although I struggled, I didn''t give up.', '["Although", "I", "struggled,", "I", "didn''t", "give", "up."]'::jsonb);

    -- 9. Speaking Practice
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'speaking_practice', 9, 'Talk About School', 'Practice talking about learning experiences', '{"prompts": ["What was your favorite subject?", "Who is your favorite teacher?", "What did you learn last week?", "What lesson did you learn from a difficult experience?", "How do you improve when things are hard?"]}'::jsonb)
    RETURNING id INTO activity_id_var;

    -- 10. Speaking Improvement
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'speaking_improvement', 10, 'Speaking Improvement', 'Read the improved version of your speech', '{"type": "speaking_improvement", "similarityThreshold": 70}'::jsonb)
    RETURNING id INTO activity_id_var;
END $$;