-- =========================================
-- Pre-fill Database with Sample Lesson Data
-- B2-L17: Travel experiences as a student
-- =========================================

DELETE FROM grammar_sentences WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'B2-L17');
DELETE FROM vocabulary_items WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'B2-L17');
DELETE FROM lesson_activities WHERE lesson_id = 'B2-L17';
DELETE FROM lessons WHERE id = 'B2-L17';

INSERT INTO lessons (id, level, lesson_number, topic) VALUES
('B2-L17', 'B2', 17, 'Travel experiences as a student')
ON CONFLICT (id) DO UPDATE SET topic = EXCLUDED.topic;

DO $$
DECLARE
    lesson_id_var TEXT := 'B2-L17';
    activity_id_var UUID;
BEGIN
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'warm_up_speaking', 1, 'Student Trips', 'Talk about travel choices', '{"prompt": "If you had more time, where would you go, and with whom?"}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_intro', 2, 'Travel Words', 'Key words for student travel', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'itinerary', 'กำหนดการเดินทาง', NULL),
    (activity_id_var, 'hostel', 'โฮสเทล', NULL),
    (activity_id_var, 'detour', 'ทางอ้อม/เปลี่ยนเส้นทาง', NULL),
    (activity_id_var, 'mishap', 'เหตุไม่คาดคิด/อุบัติเหตุเล็ก', NULL),
    (activity_id_var, 'passport', 'หนังสือเดินทาง', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_matching_drag', 3, 'Match Travel Words', 'Match words with meanings', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'itinerary', 'กำหนดการเดินทาง', NULL),
    (activity_id_var, 'hostel', 'โฮสเทล', NULL),
    (activity_id_var, 'detour', 'ทางอ้อม/เปลี่ยนเส้นทาง', NULL),
    (activity_id_var, 'mishap', 'เหตุไม่คาดคิด/อุบัติเหตุเล็ก', NULL),
    (activity_id_var, 'passport', 'หนังสือเดินทาง', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 4, 'Complete the Sentences 1', 'Fill with the correct word', '{"text": "I shared the ___. We stayed at a ___. A small ___ changed our route.", "blanks": [{"id": "blank1", "text": "itinerary", "options": ["itinerary", "hostel", "detour", "mishap"], "correctAnswer": "itinerary"}, {"id": "blank2", "text": "hostel", "options": ["hostel", "detour", "passport", "itinerary"], "correctAnswer": "hostel"}, {"id": "blank3", "text": "mishap", "options": ["mishap", "detour", "hostel", "passport"], "correctAnswer": "mishap"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 5, 'Complete the Sentences 2', 'Fill with the correct word', '{"text": "We took a ___ and saw a new town. I keep my ___ ready.", "blanks": [{"id": "blank1", "text": "detour", "options": ["detour", "hostel", "passport", "itinerary"], "correctAnswer": "detour"}, {"id": "blank2", "text": "passport", "options": ["passport", "detour", "mishap", "hostel"], "correctAnswer": "passport"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_explanation', 6, 'Second Conditional', 'Talk about unreal travel choices', '{"rules": "Use if + past simple + would + base verb for hypothetical present/future.\\n- If I had more time, I would travel more.\\nUse were after I/he/she/it in formal style.", "examples": ["If I had more savings, I would book a longer trip.", "If we missed a train, we would take a bus.", "If you lost your passport, what would you do?", "If I were less nervous, I would try solo travel.", "If they had a detour, they would explore new places."]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 7, 'Build Sentences 1', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'If I had more savings, I would book a longer trip', 'If I had more savings, I would book a longer trip.', '["If", "I", "had", "more", "savings,", "I", "would", "book", "a", "longer", "trip."]'::jsonb),
    (activity_id_var, 'If you lost your passport, what would you do', 'If you lost your passport, what would you do?', '["If", "you", "lost", "your", "passport,", "what", "would", "you", "do?"]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 8, 'Build Sentences 2', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'If I were less nervous, I would try solo travel', 'If I were less nervous, I would try solo travel.', '["If", "I", "were", "less", "nervous,", "I", "would", "try", "solo", "travel."]'::jsonb),
    (activity_id_var, 'If we missed a train, we would take a bus', 'If we missed a train, we would take a bus.', '["If", "we", "missed", "a", "train,", "we", "would", "take", "a", "bus."]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'speaking_practice', 9, 'Talk About Travel Choices', 'Practice hypotheticals', '{"prompts": ["If you had one extra day, where would you go?", "Who would you travel with and why?", "What would you change on your last trip?"]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (
      lesson_id,
      activity_type,
      activity_order,
      title,
      description,
      content
    ) VALUES (
      'B2-L17',
      'speaking_improvement',
      10,
      'Speaking Improvement',
      'Read the improved version of your speech',
      '{"type": "speaking_improvement", "similarityThreshold": 70}'::jsonb
    );
END $$;


