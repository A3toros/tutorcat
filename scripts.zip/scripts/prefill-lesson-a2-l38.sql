-- =========================================
-- Pre-fill Database with Sample Lesson Data
-- A2-L38: Being Nervous
-- =========================================

DELETE FROM grammar_sentences WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'A2-L38');
DELETE FROM vocabulary_items WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'A2-L38');
DELETE FROM lesson_activities WHERE lesson_id = 'A2-L38';
DELETE FROM lessons WHERE id = 'A2-L38';

INSERT INTO lessons (id, level, lesson_number, topic) VALUES
('A2-L38', 'A2', 38, 'Being Nervous')
ON CONFLICT (id) DO UPDATE SET topic = EXCLUDED.topic;

DO $$
DECLARE
    lesson_id_var TEXT := 'A2-L38';
    activity_id_var UUID;
BEGIN
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'warm_up_speaking', 1, 'Nervous Moments', 'Talk about feeling nervous', '{"prompt": "When do you feel nervous?"}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_intro', 2, 'Nervous Words', 'Learn words about being nervous', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'nervous', 'ประหม่า', NULL),
    (activity_id_var, 'waiting', 'กำลังรอ', NULL),
    (activity_id_var, 'interview', 'สัมภาษณ์', NULL),
    (activity_id_var, 'test', 'สอบ', NULL),
    (activity_id_var, 'breathe', 'หายใจ', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_matching_drag', 3, 'Match Nervous Words', 'Match nervous situation words', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'nervous', 'ประหม่า', NULL),
    (activity_id_var, 'waiting', 'กำลังรอ', NULL),
    (activity_id_var, 'interview', 'สัมภาษณ์', NULL),
    (activity_id_var, 'test', 'สอบ', NULL),
    (activity_id_var, 'breathe', 'หายใจ', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 4, 'Complete the Sentences 1', 'Fill with the correct word', '{"text": "I feel ___ before a ___. I am ___ in the hall. I ___ slowly.", "blanks": [{"id": "blank1", "text": "nervous", "options": ["nervous", "test", "waiting", "breathe"], "correctAnswer": "nervous"}, {"id": "blank2", "text": "test", "options": ["test", "interview", "nervous", "breathe"], "correctAnswer": "test"}, {"id": "blank3", "text": "waiting", "options": ["waiting", "breathe", "nervous", "test"], "correctAnswer": "waiting"}, {"id": "blank4", "text": "breathe", "options": ["breathe", "waiting", "test", "nervous"], "correctAnswer": "breathe"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 5, 'Complete the Sentences 2', 'Fill with the correct word', '{"text": "Before an ___, I ___ to calm down. Are you ___ now?", "blanks": [{"id": "blank1", "text": "interview", "options": ["interview", "breathe", "nervous", "test"], "correctAnswer": "interview"}, {"id": "blank2", "text": "breathe", "options": ["breathe", "interview", "test", "waiting"], "correctAnswer": "breathe"}, {"id": "blank3", "text": "nervous", "options": ["nervous", "interview", "waiting", "test"], "correctAnswer": "nervous"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_explanation', 6, 'Present Continuous (now)', 'Talk about feelings happening now', '{"rules": "Use am/is/are + verb-ing for actions/feelings now.\n- I am waiting outside.\n- She is feeling nervous.\nQuestions: Are you feeling nervous?", "examples": ["I am waiting for the test.", "She is feeling nervous now.", "Are you breathing slowly?", "He is taking a deep breath.", "We are talking before the interview."]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 7, 'Build Sentences 1', 'Arrange words', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'I am waiting for the test', 'I am waiting for the test.', '["I", "am", "waiting", "for", "the", "test."]'::jsonb),
    (activity_id_var, 'She is feeling nervous now', 'She is feeling nervous now.', '["She", "is", "feeling", "nervous", "now."]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 8, 'Build Sentences 2', 'Arrange words', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'Are you breathing slowly', 'Are you breathing slowly?', '["Are", "you", "breathing", "slowly?"]'::jsonb),
    (activity_id_var, 'We are talking before the interview', 'We are talking before the interview.', '["We", "are", "talking", "before", "the", "interview."]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'speaking_practice', 9, 'Talk About Nerves', 'Practice talking about feeling nervous', '{"prompts": ["When do you feel nervous?", "What are you doing to feel calmer?", "Who is helping or supporting you?", "How are you preparing for the situation?", "What situations make you nervous?"]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (
      lesson_id,
      activity_type,
      activity_order,
      title,
      description,
      content
    ) VALUES (
      'A2-L38',
      'speaking_improvement',
      10,
      'Speaking Improvement',
      'Read the improved version of your speech',
      '{"type": "speaking_improvement", "similarityThreshold": 70}'::jsonb
    );
END $$;

