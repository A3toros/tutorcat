-- =========================================
-- Pre-fill Database with Sample Lesson Data
-- B1-L52: Work Responsibilities
-- =========================================

DELETE FROM grammar_sentences WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'B1-L52');
DELETE FROM vocabulary_items WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'B1-L52');
DELETE FROM lesson_activities WHERE lesson_id = 'B1-L52';
DELETE FROM lessons WHERE id = 'B1-L52';

INSERT INTO lessons (id, level, lesson_number, topic) VALUES
('B1-L52', 'B1', 52, 'Work Responsibilities')
ON CONFLICT (id) DO UPDATE SET topic = EXCLUDED.topic;

DO $$
DECLARE
    lesson_id_var TEXT := 'B1-L52';
    activity_id_var UUID;
BEGIN
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'warm_up_speaking', 1, 'Owning Tasks', 'Talk about sharing work fairly', '{"prompt": "Who is someone that supports you most at work?"}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_intro', 2, 'Responsibility Words', 'Learn vocabulary about work responsibilities', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'assign', 'มอบหมาย', NULL),
    (activity_id_var, 'own', 'รับผิดชอบ', NULL),
    (activity_id_var, 'accountable', 'รับผิดชอบต่อ', NULL),
    (activity_id_var, 'supervise', 'กำกับดูแล', NULL),
    (activity_id_var, 'deliver', 'ส่งมอบ', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_matching_drag', 3, 'Match Responsibility Words', 'Match words with meanings', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'assign', 'มอบหมาย', NULL),
    (activity_id_var, 'own', 'รับผิดชอบ', NULL),
    (activity_id_var, 'accountable', 'รับผิดชอบต่อ', NULL),
    (activity_id_var, 'supervise', 'กำกับดูแล', NULL),
    (activity_id_var, 'deliver', 'ส่งมอบ', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 4, 'Complete the Sentences 1', 'Fill with the correct word', '{"text": "Leads ___ tasks. I ___ my part. We stay ___ for results.", "blanks": [{"id": "blank1", "text": "assign", "options": ["assign", "own", "accountable", "deliver"], "correctAnswer": "assign"}, {"id": "blank2", "text": "own", "options": ["own", "deliver", "assign", "supervise"], "correctAnswer": "own"}, {"id": "blank3", "text": "accountable", "options": ["accountable", "deliver", "assign", "own"], "correctAnswer": "accountable"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 5, 'Complete the Sentences 2', 'Fill with the correct word', '{"text": "Managers ___ teams. We must ___ on time. Everyone should ___ what they start.", "blanks": [{"id": "blank1", "text": "supervise", "options": ["supervise", "assign", "deliver", "own"], "correctAnswer": "supervise"}, {"id": "blank2", "text": "deliver", "options": ["deliver", "supervise", "own", "assign"], "correctAnswer": "deliver"}, {"id": "blank3", "text": "own", "options": ["own", "deliver", "supervise", "assign"], "correctAnswer": "own"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    -- Grammar Explanation: Relative Clauses (defining) — work roles
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_explanation', 6, 'Relative Clauses (who/which/that) for Work Roles', 'Use defining clauses to identify people/tasks', '{"rules": "Use who/which/that without commas to add essential info.\\n- The person who owns the task reports weekly.\\n- The task that we assigned is due Friday.", "examples": ["The person who owns this task reports weekly.", "The task that we assigned is due Friday.", "The teammate who delivers early builds trust.", "The process that we follow keeps us aligned.", "The tool that you chose works well."]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 7, 'Build Sentences 1', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'The person who owns this task reports weekly', 'The person who owns this task reports weekly', '["The", "person", "who", "owns", "this", "task", "reports", "weekly"]'::jsonb),
    (activity_id_var, 'The task that we assigned is due Friday', 'The task that we assigned is due Friday', '["The", "task", "that", "we", "assigned", "is", "due", "Friday"]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 8, 'Build Sentences 2', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'The teammate who delivers early builds trust', 'The teammate who delivers early builds trust', '["The", "teammate", "who", "delivers", "early", "builds", "trust"]'::jsonb),
    (activity_id_var, 'The process that we follow keeps us aligned', 'The process that we follow keeps us aligned', '["The", "process", "that", "we", "follow", "keeps", "us", "aligned"]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'speaking_practice', 9, 'Talk About Responsibilities', 'Practice talking about sharing work', '{"prompts": ["Who is someone that supports you most at work?", "Which tasks drain you the most?", "How do you share responsibility fairly?"]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (
      lesson_id,
      activity_type,
      activity_order,
      title,
      description,
      content
    ) VALUES (
      'B1-L52',
      'speaking_improvement',
      10,
      'Speaking Improvement',
      'Read the improved version of your speech',
      '{"type": "speaking_improvement", "similarityThreshold": 70}'::jsonb
    );
END $$;

