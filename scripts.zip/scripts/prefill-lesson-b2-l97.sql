-- =========================================
-- Pre-fill Database with Sample Lesson Data
-- B2-L97: Independence and decision-making
-- =========================================

DELETE FROM grammar_sentences WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'B2-L97');
DELETE FROM vocabulary_items WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'B2-L97');
DELETE FROM lesson_activities WHERE lesson_id = 'B2-L97';
DELETE FROM lessons WHERE id = 'B2-L97';

INSERT INTO lessons (id, level, lesson_number, topic) VALUES
('B2-L97', 'B2', 97, 'Independence and decision-making')
ON CONFLICT (id) DO UPDATE SET topic = EXCLUDED.topic;

DO $$
DECLARE
    lesson_id_var TEXT := 'B2-L97';
    activity_id_var UUID;
BEGIN
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'warm_up_speaking', 1, 'Own Your Call', 'Talk about delegating vs owning', '{"prompt": "What must be your call, what should be shared, and who do you rely on?"}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_intro', 2, 'Independence Words', 'Key words for autonomy', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'autonomous', 'อิสระ/ทำได้เอง', NULL),
    (activity_id_var, 'rely', 'พึ่งพา', NULL),
    (activity_id_var, 'consequence', 'ผลลัพธ์', NULL),
    (activity_id_var, 'maturity', 'ความเป็นผู้ใหญ่', NULL),
    (activity_id_var, 'pivot', 'เปลี่ยนทิศ/หันเห', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_matching_drag', 3, 'Match Independence Words', 'Match words with meanings', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'autonomous', 'อิสระ/ทำได้เอง', NULL),
    (activity_id_var, 'rely', 'พึ่งพา', NULL),
    (activity_id_var, 'consequence', 'ผลลัพธ์', NULL),
    (activity_id_var, 'maturity', 'ความเป็นผู้ใหญ่', NULL),
    (activity_id_var, 'pivot', 'เปลี่ยนทิศ/หันเห', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 4, 'Complete the Sentences 1', 'Fill with the correct word', '{"text": "Some choices must be ___. I ___ on mentors less now. Every ___ matters.", "blanks": [{"id": "blank1", "text": "autonomous", "options": ["autonomous", "rely", "consequence", "pivot"], "correctAnswer": "autonomous"}, {"id": "blank2", "text": "rely", "options": ["rely", "pivot", "autonomous", "maturity"], "correctAnswer": "rely"}, {"id": "blank3", "text": "consequence", "options": ["consequence", "maturity", "rely", "pivot"], "correctAnswer": "consequence"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 5, 'Complete the Sentences 2', 'Fill with the correct word', '{"text": "Growing ___ guides me. I can ___ if needed.", "blanks": [{"id": "blank1", "text": "maturity", "options": ["maturity", "pivot", "consequence", "rely"], "correctAnswer": "maturity"}, {"id": "blank2", "text": "pivot", "options": ["pivot", "rely", "maturity", "consequence"], "correctAnswer": "pivot"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_explanation', 6, 'Passive with Modals', 'Assign what must/should be owned', '{"rules": "Use modal + be + past participle to set responsibilities.\\n- Decisions must be owned by you.\\n- Some tasks should be delegated.\\nUse modal + have + been + past participle for past duties.", "examples": ["Key decisions must be made by you.", "Some calls should be shared with the team.", "Risks can be flagged early.", "Deadlines must be respected.", "Hand-offs should have been clarified yesterday."]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 7, 'Build Sentences 1', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'Key decisions must be made by you', 'Key decisions must be made by you.', '["Key", "decisions", "must", "be", "made", "by", "you."]'::jsonb),
    (activity_id_var, 'Some calls should be shared with the team', 'Some calls should be shared with the team.', '["Some", "calls", "should", "be", "shared", "with", "the", "team."]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 8, 'Build Sentences 2', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'Hand-offs should have been clarified yesterday', 'Hand-offs should have been clarified yesterday.', '["Hand-offs", "should", "have", "been", "clarified", "yesterday."]'::jsonb),
    (activity_id_var, 'Risks can be flagged early', 'Risks can be flagged early.', '["Risks", "can", "be", "flagged", "early."]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'speaking_practice', 9, 'Talk About Owning Decisions', 'Practice passive with modals', '{"prompts": ["What must be your call?", "What should be shared?", "Who do you rely on when you pivot?"]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (
      lesson_id,
      activity_type,
      activity_order,
      title,
      description,
      content
    ) VALUES (
      'B2-L97',
      'speaking_improvement',
      10,
      'Speaking Improvement',
      'Read the improved version of your speech',
      '{"type": "speaking_improvement", "similarityThreshold": 70}'::jsonb
    );
END $$;


