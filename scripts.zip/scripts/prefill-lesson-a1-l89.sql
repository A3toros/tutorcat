-- =========================================
-- Pre-fill Database with Sample Lesson Data
-- A1-L89: Please, Thank You, Sorry
-- =========================================

DELETE FROM grammar_sentences WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'A1-L89');
DELETE FROM vocabulary_items WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'A1-L89');
DELETE FROM lesson_activities WHERE lesson_id = 'A1-L89';
DELETE FROM lessons WHERE id = 'A1-L89';

INSERT INTO lessons (id, level, lesson_number, topic) VALUES
('A1-L89', 'A1', 89, 'Please, Thank You, Sorry')
ON CONFLICT (id) DO UPDATE SET topic = EXCLUDED.topic;

DO $$
DECLARE
    lesson_id_var TEXT := 'A1-L89';
    activity_id_var UUID;
BEGIN
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'warm_up_speaking', 1, 'Polite Words', 'Talk about polite words', '{"prompt": "Do you say please?"}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_intro', 2, 'Polite Words', 'Learn polite words', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'please', 'กรุณา', NULL),
    (activity_id_var, 'thank you', 'ขอบคุณ', NULL),
    (activity_id_var, 'sorry', 'ขอโทษ', NULL),
    (activity_id_var, 'excuse me', 'ขออนุญาต/ขอโทษ', NULL),
    (activity_id_var, 'welcome', 'ยินดีต้อนรับ', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_matching_drag', 3, 'Match Polite Words', 'Match polite words', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'please', 'กรุณา', NULL),
    (activity_id_var, 'thank you', 'ขอบคุณ', NULL),
    (activity_id_var, 'sorry', 'ขอโทษ', NULL),
    (activity_id_var, 'excuse me', 'ขออนุญาต/ขอโทษ', NULL),
    (activity_id_var, 'welcome', 'ยินดีต้อนรับ', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 4, 'Complete the Sentences 1', 'Fill with the correct word', '{"text": "\"___\" for help. \"___\" after help.", "blanks": [{"id": "blank1", "text": "Please", "options": ["Please", "Sorry", "Welcome", "Thank you"], "correctAnswer": "Please"}, {"id": "blank2", "text": "Thank you", "options": ["Thank you", "Please", "Sorry", "Excuse me"], "correctAnswer": "Thank you"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 5, 'Complete the Sentences 2', 'Fill with the correct word', '{"text": "\"___\" when you make a mistake. \"___\" to enter.", "blanks": [{"id": "blank1", "text": "Sorry", "options": ["Sorry", "Welcome", "Please", "Thank you"], "correctAnswer": "Sorry"}, {"id": "blank2", "text": "Excuse me", "options": ["Excuse me", "Sorry", "Thank you", "Please"], "correctAnswer": "Excuse me"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_explanation', 6, 'Polite Phrases', 'Use polite words', '{"rules": "Use please to ask kindly; thank you after help; sorry for mistakes; excuse me to pass/ask; welcome to greet.\nKeep sentences short.", "examples": ["Please help me.", "Thank you for your help.", "Sorry for the mistake.", "Excuse me, can I pass?", "Welcome to my home."]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 7, 'Build Sentences 1', 'Arrange words', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'Please help me', 'Please help me.', '["Please", "help", "me."]'::jsonb),
    (activity_id_var, 'Thank you for your help', 'Thank you for your help.', '["Thank", "you", "for", "your", "help."]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 8, 'Build Sentences 2', 'Arrange words', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'Sorry for the mistake', 'Sorry for the mistake.', '["Sorry", "for", "the", "mistake."]'::jsonb),
    (activity_id_var, 'Excuse me can I pass', 'Excuse me, can I pass?', '["Excuse", "me,", "can", "I", "pass?"]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'speaking_practice', 9, 'Practice Polite Words', 'Use polite phrases', '{"prompts": ["Do you say please?", "Do you say thank you?", "Do you say sorry?", "Do you say excuse me?", "Do you say welcome?"]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (
      lesson_id,
      activity_type,
      activity_order,
      title,
      description,
      content
    ) VALUES (
      'A1-L89',
      'speaking_improvement',
      10,
      'Speaking Improvement',
      'Read the improved version of your speech',
      '{"type": "speaking_improvement", "similarityThreshold": 70}'::jsonb
    );
END $$;

