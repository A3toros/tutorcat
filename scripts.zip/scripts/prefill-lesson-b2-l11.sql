-- =========================================
-- Pre-fill Database with Sample Lesson Data
-- B2-L11: Work–life balance
-- =========================================

DELETE FROM grammar_sentences WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'B2-L11');
DELETE FROM vocabulary_items WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'B2-L11');
DELETE FROM lesson_activities WHERE lesson_id = 'B2-L11';
DELETE FROM lessons WHERE id = 'B2-L11';

INSERT INTO lessons (id, level, lesson_number, topic) VALUES
('B2-L11', 'B2', 11, 'Work–life balance')
ON CONFLICT (id) DO UPDATE SET topic = EXCLUDED.topic;

DO $$
DECLARE
    lesson_id_var TEXT := 'B2-L11';
    activity_id_var UUID;
BEGIN
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'warm_up_speaking', 1, 'Balance Check-in', 'Talk about your routine', '{"prompt": "Where do you see your balance in a year, and what will change?"}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_intro', 2, 'Balance Words', 'Key words for balance', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'balance', 'ความสมดุล', NULL),
    (activity_id_var, 'boundary', 'ขอบเขต', NULL),
    (activity_id_var, 'commute', 'การเดินทางไปกลับ', NULL),
    (activity_id_var, 'pace', 'จังหวะ/ความเร็ว', NULL),
    (activity_id_var, 'rest', 'พักผ่อน', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_matching_drag', 3, 'Match Balance Words', 'Match words with meanings', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'balance', 'ความสมดุล', NULL),
    (activity_id_var, 'boundary', 'ขอบเขต', NULL),
    (activity_id_var, 'commute', 'การเดินทางไปกลับ', NULL),
    (activity_id_var, 'pace', 'จังหวะ/ความเร็ว', NULL),
    (activity_id_var, 'rest', 'พักผ่อน', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 4, 'Complete the Sentences 1', 'Fill with the correct word', '{"text": "I set a ___ for study hours. A long ___ can change my ___. I schedule true ___.", "blanks": [{"id": "blank1", "text": "boundary", "options": ["boundary", "commute", "balance", "pace"], "correctAnswer": "boundary"}, {"id": "blank2", "text": "commute", "options": ["commute", "rest", "pace", "balance"], "correctAnswer": "commute"}, {"id": "blank3", "text": "pace", "options": ["pace", "rest", "balance", "boundary"], "correctAnswer": "pace"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 5, 'Complete the Sentences 2', 'Fill with the correct word', '{"text": "Good ___ needs planned ___. After exams I will ___ more.", "blanks": [{"id": "blank1", "text": "balance", "options": ["balance", "rest", "boundary", "commute"], "correctAnswer": "balance"}, {"id": "blank2", "text": "rest", "options": ["rest", "pace", "balance", "commute"], "correctAnswer": "rest"}, {"id": "blank3", "text": "rest", "options": ["rest", "balance", "boundary", "pace"], "correctAnswer": "rest"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_explanation', 6, 'Future Continuous & Future Perfect', 'Talk about balance at future times', '{"rules": "Use will be + -ing for actions in progress at a future time; use will have + past participle for actions finished before a future point.\\n- At 8 p.m. tomorrow, I will be resting.\\n- By next month, I will have fixed my schedule.", "examples": ["This time next week, I will be keeping stricter boundaries.", "By summer, I will have reduced my commute.", "At 10 p.m., I will be offline.", "By exam week, I will have planned my rest days.", "Next month, I will be pacing my mornings better."]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 7, 'Build Sentences 1', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'This time next week, I will be keeping stricter boundaries', 'This time next week, I will be keeping stricter boundaries.', '["This", "time", "next", "week,", "I", "will", "be", "keeping", "stricter", "boundaries."]'::jsonb),
    (activity_id_var, 'By summer, I will have reduced my commute', 'By summer, I will have reduced my commute.', '["By", "summer,", "I", "will", "have", "reduced", "my", "commute."]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 8, 'Build Sentences 2', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'By exam week, I will have planned my rest days', 'By exam week, I will have planned my rest days.', '["By", "exam", "week,", "I", "will", "have", "planned", "my", "rest", "days."]'::jsonb),
    (activity_id_var, 'At 10 p.m., I will be offline and resting', 'At 10 p.m., I will be offline and resting.', '["At", "10", "p.m.,", "I", "will", "be", "offline", "and", "resting."]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'speaking_practice', 9, 'Talk About Future Balance', 'Practice future continuous/perfect', '{"prompts": ["Where will you be resting this weekend?", "What will you have changed about your pace by next month?", "Who keeps you accountable for balance?" ]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (
      lesson_id,
      activity_type,
      activity_order,
      title,
      description,
      content
    ) VALUES (
      'B2-L11',
      'speaking_improvement',
      10,
      'Speaking Improvement',
      'Read the improved version of your speech',
      '{"type": "speaking_improvement", "similarityThreshold": 70}'::jsonb
    );
END $$;


