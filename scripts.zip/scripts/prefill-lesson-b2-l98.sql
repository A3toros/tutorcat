-- =========================================
-- Pre-fill Database with Sample Lesson Data
-- B2-L98: Planning for the future (career)
-- =========================================

DELETE FROM grammar_sentences WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'B2-L98');
DELETE FROM vocabulary_items WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'B2-L98');
DELETE FROM lesson_activities WHERE lesson_id = 'B2-L98';
DELETE FROM lessons WHERE id = 'B2-L98';

INSERT INTO lessons (id, level, lesson_number, topic) VALUES
('B2-L98', 'B2', 98, 'Planning for the future (career)')
ON CONFLICT (id) DO UPDATE SET topic = EXCLUDED.topic;

DO $$
DECLARE
    lesson_id_var TEXT := 'B2-L98';
    activity_id_var UUID;
BEGIN
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'warm_up_speaking', 1, 'Career What-Ifs', 'Talk about pivots and scenarios', '{"prompt": "If you had planned differently, what would today look like, and what will you adjust now?"}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_intro', 2, 'Career Planning Words', 'Key words for scenarios and pivots', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'forecast', 'การคาดการณ์', NULL),
    (activity_id_var, 'scenario', 'สถานการณ์สมมติ', NULL),
    (activity_id_var, 'fallback', 'ทางเลือกสำรอง', NULL),
    (activity_id_var, 'adjust', 'ปรับ', NULL),
    (activity_id_var, 'milestone', 'เหตุการณ์สำคัญ/หลักไมล์', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_matching_drag', 3, 'Match Career Planning Words', 'Match words with meanings', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'forecast', 'การคาดการณ์', NULL),
    (activity_id_var, 'scenario', 'สถานการณ์สมมติ', NULL),
    (activity_id_var, 'fallback', 'ทางเลือกสำรอง', NULL),
    (activity_id_var, 'adjust', 'ปรับ', NULL),
    (activity_id_var, 'milestone', 'เหตุการณ์สำคัญ/หลักไมล์', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 4, 'Complete the Sentences 1', 'Fill with the correct word', '{"text": "We map each ___. We keep a ___. We can ___ the plan.", "blanks": [{"id": "blank1", "text": "scenario", "options": ["scenario", "forecast", "fallback", "milestone"], "correctAnswer": "scenario"}, {"id": "blank2", "text": "fallback", "options": ["fallback", "forecast", "adjust", "scenario"], "correctAnswer": "fallback"}, {"id": "blank3", "text": "adjust", "options": ["adjust", "milestone", "scenario", "forecast"], "correctAnswer": "adjust"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 5, 'Complete the Sentences 2', 'Fill with the correct word', '{"text": "Our ___ informs each ___.", "blanks": [{"id": "blank1", "text": "forecast", "options": ["forecast", "milestone", "fallback", "adjust"], "correctAnswer": "forecast"}, {"id": "blank2", "text": "milestone", "options": ["milestone", "scenario", "adjust", "forecast"], "correctAnswer": "milestone"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_explanation', 6, 'Mixed Conditionals', 'Link past plans to present and present to past', '{"rules": "Use if + past perfect + would + base verb for past condition → present result. Use if + past simple + would have + past participle for present condition → past result.\\n- If I had planned differently, I would be in another role now.\\n- If I were clearer now, I would have avoided past detours.", "examples": ["If I had chosen another path, I would be working abroad now.", "If we had hit that milestone, we would be calmer today.", "If you were clearer now, you would have saved time last year.", "If they had set a fallback, they would be less stressed now.", "If the forecast were better, we would have planned differently."]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 7, 'Build Sentences 1', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'If I had planned differently, I would be in another role now', 'If I had planned differently, I would be in another role now.', '["If", "I", "had", "planned", "differently,", "I", "would", "be", "in", "another", "role", "now."]'::jsonb),
    (activity_id_var, 'If we had hit that milestone, we would be calmer today', 'If we had hit that milestone, we would be calmer today.', '["If", "we", "had", "hit", "that", "milestone,", "we", "would", "be", "calmer", "today."]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 8, 'Build Sentences 2', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'If you were clearer now, you would have saved time last year', 'If you were clearer now, you would have saved time last year.', '["If", "you", "were", "clearer", "now,", "you", "would", "have", "saved", "time", "last", "year."]'::jsonb),
    (activity_id_var, 'If they had set a fallback, they would be less stressed now', 'If they had set a fallback, they would be less stressed now.', '["If", "they", "had", "set", "a", "fallback,", "they", "would", "be", "less", "stressed", "now."]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'speaking_practice', 9, 'Talk About Career Plans', 'Practice mixed conditionals', '{"prompts": ["If you had planned differently, what would today look like?", "What milestone would change your stress now?", "How will you adjust your forecast?"]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (
      lesson_id,
      activity_type,
      activity_order,
      title,
      description,
      content
    ) VALUES (
      'B2-L98',
      'speaking_improvement',
      10,
      'Speaking Improvement',
      'Read the improved version of your speech',
      '{"type": "speaking_improvement", "similarityThreshold": 70}'::jsonb
    );
END $$;


