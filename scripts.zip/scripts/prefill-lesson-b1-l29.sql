-- =========================================
-- Pre-fill Database with Sample Lesson Data
-- B1-L29: Dealing with Stress
-- =========================================

DELETE FROM grammar_sentences WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'B1-L29');
DELETE FROM vocabulary_items WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'B1-L29');
DELETE FROM lesson_activities WHERE lesson_id = 'B1-L29';
DELETE FROM lessons WHERE id = 'B1-L29';

INSERT INTO lessons (id, level, lesson_number, topic) VALUES
('B1-L29', 'B1', 29, 'Dealing with Stress')
ON CONFLICT (id) DO UPDATE SET topic = EXCLUDED.topic;

DO $$
DECLARE
    lesson_id_var TEXT := 'B1-L29';
    activity_id_var UUID;
BEGIN
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'warm_up_speaking', 1, 'Stress Response', 'Talk about first steps when stressed', '{"prompt": "What must you do first when stress hits?"}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_intro', 2, 'Stress Words', 'Learn vocabulary about dealing with stress', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'pause', 'หยุดชั่วคราว', NULL),
    (activity_id_var, 'breathe', 'หายใจ', NULL),
    (activity_id_var, 'prioritize', 'จัดลำดับความสำคัญ', NULL),
    (activity_id_var, 'postpone', 'เลื่อนออกไป', NULL),
    (activity_id_var, 'cope', 'รับมือ', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_matching_drag', 3, 'Match Stress Words', 'Match words with meanings', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'pause', 'หยุดชั่วคราว', NULL),
    (activity_id_var, 'breathe', 'หายใจ', NULL),
    (activity_id_var, 'prioritize', 'จัดลำดับความสำคัญ', NULL),
    (activity_id_var, 'postpone', 'เลื่อนออกไป', NULL),
    (activity_id_var, 'cope', 'รับมือ', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 4, 'Complete the Sentences 1', 'Fill with the correct word', '{"text": "I ___ to think. Then I ___ deeply. I ___ the most urgent tasks.", "blanks": [{"id": "blank1", "text": "pause", "options": ["pause", "breathe", "prioritize", "cope"], "correctAnswer": "pause"}, {"id": "blank2", "text": "breathe", "options": ["breathe", "pause", "cope", "postpone"], "correctAnswer": "breathe"}, {"id": "blank3", "text": "prioritize", "options": ["prioritize", "postpone", "pause", "breathe"], "correctAnswer": "prioritize"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 5, 'Complete the Sentences 2', 'Fill with the correct word', '{"text": "If possible, I ___ less urgent work. These steps help me ___. I can ___ better later.", "blanks": [{"id": "blank1", "text": "postpone", "options": ["postpone", "breathe", "prioritize", "cope"], "correctAnswer": "postpone"}, {"id": "blank2", "text": "cope", "options": ["cope", "pause", "postpone", "prioritize"], "correctAnswer": "cope"}, {"id": "blank3", "text": "breathe", "options": ["breathe", "prioritize", "postpone", "cope"], "correctAnswer": "breathe"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    -- Grammar Explanation: Modals (must / should) for stress strategies
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_explanation', 6, 'Modals for Stress Strategies', 'Use must/should to state necessity and advice', '{"rules": "Use must for strong necessity. Use should for advice. Keep statements clear.\\n- You must pause before reacting.\\n- You should breathe slowly.\\n- We must prioritize urgent tasks.", "examples": ["You must pause before you respond.", "You should breathe slowly to calm down.", "We must prioritize the urgent tasks first.", "You should postpone low-value work when possible.", "They must cope with pressure as a team."]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 7, 'Build Sentences 1', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'You must pause before you respond', 'You must pause before you respond', '["You", "must", "pause", "before", "you", "respond"]'::jsonb),
    (activity_id_var, 'You should breathe slowly to calm down', 'You should breathe slowly to calm down', '["You", "should", "breathe", "slowly", "to", "calm", "down"]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 8, 'Build Sentences 2', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'We must prioritize the urgent tasks first', 'We must prioritize the urgent tasks first', '["We", "must", "prioritize", "the", "urgent", "tasks", "first"]'::jsonb),
    (activity_id_var, 'You should postpone low value work when possible', 'You should postpone low value work when possible', '["You", "should", "postpone", "low", "value", "work", "when", "possible"]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'speaking_practice', 9, 'Talk About Stress', 'Practice talking about stress strategies', '{"prompts": ["What must you do first when stress hits?", "What should schools actually teach about stress?", "Describe your go-to coping move."]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (
      lesson_id,
      activity_type,
      activity_order,
      title,
      description,
      content
    ) VALUES (
      'B1-L29',
      'speaking_improvement',
      10,
      'Speaking Improvement',
      'Read the improved version of your speech',
      '{"type": "speaking_improvement", "similarityThreshold": 70}'::jsonb
    );
END $$;

