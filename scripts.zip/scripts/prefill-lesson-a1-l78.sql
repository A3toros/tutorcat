-- =========================================
-- Pre-fill Database with Sample Lesson Data
-- A1-L78: Favorite Colors
-- =========================================

DELETE FROM grammar_sentences WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'A1-L78');
DELETE FROM vocabulary_items WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'A1-L78');
DELETE FROM lesson_activities WHERE lesson_id = 'A1-L78';
DELETE FROM lessons WHERE id = 'A1-L78';

INSERT INTO lessons (id, level, lesson_number, topic) VALUES
('A1-L78', 'A1', 78, 'Favorite Colors')
ON CONFLICT (id) DO UPDATE SET topic = EXCLUDED.topic;

DO $$
DECLARE
    lesson_id_var TEXT := 'A1-L78';
    activity_id_var UUID;
BEGIN
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'warm_up_speaking', 1, 'Colors You Like', 'Talk about colors', '{"prompt": "Do you like pink?"}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_intro', 2, 'Color Words', 'Learn more color words', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'pink', 'สีชมพู', NULL),
    (activity_id_var, 'purple', 'สีม่วง', NULL),
    (activity_id_var, 'orange', 'สีส้ม', NULL),
    (activity_id_var, 'brown', 'สีน้ำตาล', NULL),
    (activity_id_var, 'gray', 'สีเทา', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_matching_drag', 3, 'Match Color Words', 'Match color words', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'pink', 'สีชมพู', NULL),
    (activity_id_var, 'purple', 'สีม่วง', NULL),
    (activity_id_var, 'orange', 'สีส้ม', NULL),
    (activity_id_var, 'brown', 'สีน้ำตาล', NULL),
    (activity_id_var, 'gray', 'สีเทา', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 4, 'Complete the Sentences 1', 'Fill with the correct word', '{"text": "My bag is ___. My hat is ___.", "blanks": [{"id": "blank1", "text": "orange", "options": ["orange", "pink", "purple", "brown"], "correctAnswer": "orange"}, {"id": "blank2", "text": "pink", "options": ["pink", "gray", "brown", "purple"], "correctAnswer": "pink"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 5, 'Complete the Sentences 2', 'Fill with the correct word', '{"text": "The bag is ___. The shoes are ___.", "blanks": [{"id": "blank1", "text": "brown", "options": ["brown", "gray", "purple", "orange"], "correctAnswer": "brown"}, {"id": "blank2", "text": "gray", "options": ["gray", "pink", "brown", "orange"], "correctAnswer": "gray"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_explanation', 6, 'Adjectives + Like', 'Use color adjectives with like', '{"rules": "Use like with colors; put color before noun.\n- I like pink bags.\n- This is a brown bag.", "examples": ["I like pink bags.", "This is a brown bag.", "That shirt is orange.", "Are your shoes gray?", "Do you like purple?"]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 7, 'Build Sentences 1', 'Arrange words', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'I like pink bags', 'I like pink bags.', '["I", "like", "pink", "bags."]'::jsonb),
    (activity_id_var, 'This is a brown bag', 'This is a brown bag.', '["This", "is", "a", "brown", "bag."]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 8, 'Build Sentences 2', 'Arrange words', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'That shirt is orange', 'That shirt is orange.', '["That", "shirt", "is", "orange."]'::jsonb),
    (activity_id_var, 'Are your shoes gray', 'Are your shoes gray?', '["Are", "your", "shoes", "gray?"]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'speaking_practice', 9, 'Talk About Colors You Like', 'Practice color preferences', '{"prompts": ["Do you like pink?", "Do you like purple?", "Is your bag orange?", "Is your shirt gray?", "What color do you like?"]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (
      lesson_id,
      activity_type,
      activity_order,
      title,
      description,
      content
    ) VALUES (
      'A1-L78',
      'speaking_improvement',
      10,
      'Speaking Improvement',
      'Read the improved version of your speech',
      '{"type": "speaking_improvement", "similarityThreshold": 70}'::jsonb
    );
END $$;

