-- =========================================
-- Pre-fill Database with Sample Lesson Data
-- A2-L61: Taxi Rides
-- =========================================

DELETE FROM grammar_sentences WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'A2-L61');
DELETE FROM vocabulary_items WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'A2-L61');
DELETE FROM lesson_activities WHERE lesson_id = 'A2-L61';
DELETE FROM lessons WHERE id = 'A2-L61';

INSERT INTO lessons (id, level, lesson_number, topic) VALUES
('A2-L61', 'A2', 61, 'Taxi Rides')
ON CONFLICT (id) DO UPDATE SET topic = EXCLUDED.topic;

DO $$
DECLARE
    lesson_id_var TEXT := 'A2-L61';
    activity_id_var UUID;
BEGIN
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'warm_up_speaking', 1, 'Taxi Trips', 'Talk about taxi rides', '{"prompt": "How can you ask a driver to stop?"}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_intro', 2, 'Taxi Words', 'Learn taxi vocabulary', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'taxi', 'แท็กซี่', NULL),
    (activity_id_var, 'fare', 'ค่าโดยสาร', NULL),
    (activity_id_var, 'meter', 'มิเตอร์', NULL),
    (activity_id_var, 'drop off', 'ส่งลง', NULL),
    (activity_id_var, 'change', 'เงินทอน', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_matching_drag', 3, 'Match Taxi Words', 'Match taxi words', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'taxi', 'แท็กซี่', NULL),
    (activity_id_var, 'fare', 'ค่าโดยสาร', NULL),
    (activity_id_var, 'meter', 'มิเตอร์', NULL),
    (activity_id_var, 'drop off', 'ส่งลง', NULL),
    (activity_id_var, 'change', 'เงินทอน', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 4, 'Complete the Sentences 1', 'Fill with the correct word', '{"text": "The ___ shows the ___. Please ___ me at the corner.", "blanks": [{"id": "blank1", "text": "meter", "options": ["meter", "fare", "drop off", "change"], "correctAnswer": "meter"}, {"id": "blank2", "text": "fare", "options": ["fare", "change", "meter", "taxi"], "correctAnswer": "fare"}, {"id": "blank3", "text": "drop off", "options": ["drop off", "change", "meter", "fare"], "correctAnswer": "drop off"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 5, 'Complete the Sentences 2', 'Fill with the correct word', '{"text": "Do you have ___. The ___ is not working. I will take a ___.", "blanks": [{"id": "blank1", "text": "change", "options": ["change", "meter", "fare", "taxi"], "correctAnswer": "change"}, {"id": "blank2", "text": "meter", "options": ["meter", "change", "fare", "drop off"], "correctAnswer": "meter"}, {"id": "blank3", "text": "taxi", "options": ["taxi", "fare", "meter", "change"], "correctAnswer": "taxi"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_explanation', 6, 'Can for Requests', 'Ask drivers politely', '{"rules": "Use can to make simple requests.\n- Can you stop here?\n- Can you turn on the meter?\nShort answers: Sure. / Sorry, no.", "examples": ["Can you stop at the next street?", "Can you turn on the meter?", "Can you drop me off at the corner?", "Can you break this bill?"]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 7, 'Build Sentences 1', 'Arrange words', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'Can you stop at the next street', 'Can you stop at the next street?', '["Can", "you", "stop", "at", "the", "next", "street?"]'::jsonb),
    (activity_id_var, 'Can you turn on the meter', 'Can you turn on the meter?', '["Can", "you", "turn", "on", "the", "meter?"]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 8, 'Build Sentences 2', 'Arrange words', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'Can you drop me off at the corner', 'Can you drop me off at the corner?', '["Can", "you", "drop", "me", "off", "at", "the", "corner?"]'::jsonb),
    (activity_id_var, 'Can you give me change', 'Can you give me change?', '["Can", "you", "give", "me", "change?"]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'speaking_practice', 9, 'Talk About Taxis', 'Practice taxi requests', '{"prompts": ["How can you ask a driver to stop?", "Can you ask the driver to slow down?", "Can you tell the driver where to go?", "Can you share a taxi with others?", "What can you say to the driver politely?"]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (
      lesson_id,
      activity_type,
      activity_order,
      title,
      description,
      content
    ) VALUES (
      'A2-L61',
      'speaking_improvement',
      10,
      'Speaking Improvement',
      'Read the improved version of your speech',
      '{"type": "speaking_improvement", "similarityThreshold": 70}'::jsonb
    );
END $$;

