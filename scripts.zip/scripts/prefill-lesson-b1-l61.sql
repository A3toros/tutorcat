-- ===== LESSON B1-L61 =====

-- =========================================
-- Pre-fill Database with Sample Lesson Data
-- B1-L61: Social Responsibilities
-- =========================================

DELETE FROM lesson_activity_results WHERE lesson_id = 'B1-L61';
DELETE FROM user_progress WHERE lesson_id = 'B1-L61';
DELETE FROM lesson_history WHERE lesson_id = 'B1-L61';
DELETE FROM grammar_sentences WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'B1-L61');
DELETE FROM vocabulary_items WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'B1-L61');
DELETE FROM lesson_activities WHERE lesson_id = 'B1-L61';
DELETE FROM lessons WHERE id = 'B1-L61';

INSERT INTO lessons (id, level, lesson_number, topic) VALUES
('B1-L61', 'B1', 61, 'Social Responsibilities')
ON CONFLICT (id) DO UPDATE SET topic = EXCLUDED.topic;

DO $$
DECLARE
    lesson_id_var TEXT := 'B1-L61';
    activity_id_var UUID;
BEGIN
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'warm_up_speaking', 1, 'Community Involvement', 'Talk about helping others in your community', '{"prompt": "Who inspires you to help others?"}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_intro', 2, 'Community Action Words', 'Learn words related to community service', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'volunteer', 'อาสาสมัคร', NULL),
    (activity_id_var, 'donate', 'บริจาค', NULL),
    (activity_id_var, 'organize', 'จัดระเบียบ', NULL),
    (activity_id_var, 'advocate', 'สนับสนุน', NULL),
    (activity_id_var, 'participate', 'เข้าร่วม', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_matching_drag', 3, 'Match Community Words', 'Match community action words', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'volunteer', 'อาสาสมัคร', NULL),
    (activity_id_var, 'donate', 'บริจาค', NULL),
    (activity_id_var, 'organize', 'จัดระเบียบ', NULL),
    (activity_id_var, 'advocate', 'สนับสนุน', NULL),
    (activity_id_var, 'participate', 'เข้าร่วม', NULL);

    -- 4. Vocabulary Fill Blanks #1
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 4, 'Complete the Sentences 1', 'Fill in the blanks with correct words', '{"text": "I ___ at the community center. We ___ money to help others. They ___ events for the neighborhood.", "blanks": [{"id": "blank1", "text": "volunteer", "options": ["volunteer", "donate", "organize", "advocate"], "correctAnswer": "volunteer"}, {"id": "blank2", "text": "donate", "options": ["donate", "volunteer", "organize", "participate"], "correctAnswer": "donate"}, {"id": "blank3", "text": "organize", "options": ["organize", "volunteer", "donate", "advocate"], "correctAnswer": "organize"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    -- 5. Vocabulary Fill Blanks #2
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 5, 'Complete the Sentences 2', 'Fill in the blanks with correct words', '{"text": "She ___ for better schools. We ___ in community activities. They ___ for change.", "blanks": [{"id": "blank1", "text": "advocates", "options": ["advocates", "volunteers", "donates", "organizes"], "correctAnswer": "advocates"}, {"id": "blank2", "text": "participate", "options": ["participate", "volunteer", "donate", "organize"], "correctAnswer": "participate"}, {"id": "blank3", "text": "advocate", "options": ["advocate", "volunteer", "donate", "organize"], "correctAnswer": "advocate"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    -- 6. Grammar Explanation
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_explanation', 6, 'Defining Relative Clauses', 'Learn who/which/that in relative clauses', '{"rules": "Use relative clauses to give more information about nouns:\n\n- Who for people (a person who helps)\n- Which for things (a group which helps)\n- That for people or things (a place that needs help)\n- Relative clauses come after the noun they describe", "examples": ["This is a person who helps others.", "I support a group which helps children.", "She volunteers at a place that needs help.", "People who volunteer make a difference.", "Organizations which help others are important."]}'::jsonb)
    RETURNING id INTO activity_id_var;

    -- 7. Grammar Sentences #1
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 7, 'Build Sentences 1', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'This is a person who helps others', 'This is a person who helps others.', '["This", "is", "a", "person", "who", "helps", "others."]'::jsonb),
    (activity_id_var, 'I support a group which helps children', 'I support a group which helps children.', '["I", "support", "a", "group", "which", "helps", "children."]'::jsonb);

    -- 8. Grammar Sentences #2
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 8, 'Build Sentences 2', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'She volunteers at a place that needs help', 'She volunteers at a place that needs help.', '["She", "volunteers", "at", "a", "place", "that", "needs", "help."]'::jsonb),
    (activity_id_var, 'People who volunteer make a difference', 'People who volunteer make a difference.', '["People", "who", "volunteer", "make", "a", "difference."]'::jsonb);

    -- 9. Speaking Practice
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'speaking_practice', 9, 'Talk About Helping Others', 'Practice talking about helping people', '{"prompts": ["Do you help people in your neighborhood?", "What do you do to help your family?", "Who is your favorite person to help?", "Do you volunteer anywhere?", "What causes do you support?"]}'::jsonb)
    RETURNING id INTO activity_id_var;

    -- 10. Speaking Improvement
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'speaking_improvement', 10, 'Speaking Improvement', 'Read the improved version of your speech', '{"type": "speaking_improvement", "similarityThreshold": 70}'::jsonb)
    RETURNING id INTO activity_id_var;
END $$;