-- =========================================
-- Pre-fill Database with Sample Lesson Data
-- B1-L57: Making Complaints
-- =========================================

DELETE FROM grammar_sentences WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'B1-L57');
DELETE FROM vocabulary_items WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'B1-L57');
DELETE FROM lesson_activities WHERE lesson_id = 'B1-L57';
DELETE FROM lessons WHERE id = 'B1-L57';

INSERT INTO lessons (id, level, lesson_number, topic) VALUES
('B1-L57', 'B1', 57, 'Making Complaints')
ON CONFLICT (id) DO UPDATE SET topic = EXCLUDED.topic;

DO $$
DECLARE
    lesson_id_var TEXT := 'B1-L57';
    activity_id_var UUID;
BEGIN
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'warm_up_speaking', 1, 'Complaints', 'Talk about real complaints you made', '{"prompt": "Describe a complaint you actually made."}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_intro', 2, 'Complaint Words', 'Learn vocabulary about making complaints', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'damaged', 'เสียหาย', NULL),
    (activity_id_var, 'delayed', 'ล่าช้า', NULL),
    (activity_id_var, 'mishandled', 'จัดการผิดพลาด', NULL),
    (activity_id_var, 'resolved', 'ถูกแก้ไข', NULL),
    (activity_id_var, 'escalated', 'ถูกยกระดับ', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_matching_drag', 3, 'Match Complaint Words', 'Match words with meanings', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'damaged', 'เสียหาย', NULL),
    (activity_id_var, 'delayed', 'ล่าช้า', NULL),
    (activity_id_var, 'mishandled', 'จัดการผิดพลาด', NULL),
    (activity_id_var, 'resolved', 'ถูกแก้ไข', NULL),
    (activity_id_var, 'escalated', 'ถูกยกระดับ', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 4, 'Complete the Sentences 1', 'Fill with the correct word', '{"text": "The item was ___. Delivery was ___. The request was ___.", "blanks": [{"id": "blank1", "text": "damaged", "options": ["damaged", "delayed", "mishandled", "resolved"], "correctAnswer": "damaged"}, {"id": "blank2", "text": "delayed", "options": ["delayed", "escalated", "resolved", "damaged"], "correctAnswer": "delayed"}, {"id": "blank3", "text": "mishandled", "options": ["mishandled", "damaged", "delayed", "resolved"], "correctAnswer": "mishandled"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 5, 'Complete the Sentences 2', 'Fill with the correct word', '{"text": "The case was quickly ___. It was ___ to a manager. The issue was finally ___.", "blanks": [{"id": "blank1", "text": "resolved", "options": ["resolved", "escalated", "damaged", "delayed"], "correctAnswer": "resolved"}, {"id": "blank2", "text": "escalated", "options": ["escalated", "resolved", "mishandled", "delayed"], "correctAnswer": "escalated"}, {"id": "blank3", "text": "resolved", "options": ["resolved", "escalated", "damaged", "mishandled"], "correctAnswer": "resolved"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    -- Grammar Explanation: Passive Voice (Past) — complaints
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_explanation', 6, 'Passive Voice (Past) for Complaints', 'Use was/were + past participle to describe what happened to items/requests', '{"rules": "Passive past: was/were + past participle to focus on the object.\\n- The shipment was delayed.\\n- The case was resolved yesterday.\\nAvoid contractions.", "examples": ["The shipment was delayed for two days.", "The package was damaged in transit.", "The complaint was escalated to a manager.", "The request was mishandled at first.", "The issue was resolved by support."]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 7, 'Build Sentences 1', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'The shipment was delayed for two days', 'The shipment was delayed for two days', '["The", "shipment", "was", "delayed", "for", "two", "days"]'::jsonb),
    (activity_id_var, 'The package was damaged in transit', 'The package was damaged in transit', '["The", "package", "was", "damaged", "in", "transit"]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 8, 'Build Sentences 2', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'The complaint was escalated to a manager', 'The complaint was escalated to a manager', '["The", "complaint", "was", "escalated", "to", "a", "manager"]'::jsonb),
    (activity_id_var, 'The issue was resolved by support', 'The issue was resolved by support', '["The", "issue", "was", "resolved", "by", "support"]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'speaking_practice', 9, 'Talk About Complaints', 'Practice talking about complaints and resolutions', '{"prompts": ["Describe a complaint you actually made.", "What finally got resolved?", "How should staff respond to you?"]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (
      lesson_id,
      activity_type,
      activity_order,
      title,
      description,
      content
    ) VALUES (
      'B1-L57',
      'speaking_improvement',
      10,
      'Speaking Improvement',
      'Read the improved version of your speech',
      '{"type": "speaking_improvement", "similarityThreshold": 70}'::jsonb
    );
END $$;

