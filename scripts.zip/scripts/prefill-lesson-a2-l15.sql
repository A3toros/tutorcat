-- =========================================
-- Pre-fill Database with Sample Lesson Data
-- A2-L15: Booking a Table
-- =========================================

DELETE FROM grammar_sentences WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'A2-L15');
DELETE FROM vocabulary_items WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'A2-L15');
DELETE FROM lesson_activities WHERE lesson_id = 'A2-L15';
DELETE FROM lessons WHERE id = 'A2-L15';

INSERT INTO lessons (id, level, lesson_number, topic) VALUES
('A2-L15', 'A2', 15, 'Booking a Table')
ON CONFLICT (id) DO UPDATE SET topic = EXCLUDED.topic;

DO $$
DECLARE
    lesson_id_var TEXT := 'A2-L15';
    activity_id_var UUID;
BEGIN
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'warm_up_speaking', 1, 'Make a Booking', 'Talk about reserving a table', '{"prompt": "How do you usually book a table at a restaurant?"}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_intro', 2, 'Restaurant Booking Words', 'Learn booking vocabulary', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'book', 'จอง', NULL),
    (activity_id_var, 'table', 'โต๊ะ', NULL),
    (activity_id_var, 'reservation', 'การจอง', NULL),
    (activity_id_var, 'tonight', 'คืนนี้', NULL),
    (activity_id_var, 'time', 'เวลา', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_matching_drag', 3, 'Match Booking Words', 'Match restaurant booking words', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'book', 'จอง', NULL),
    (activity_id_var, 'table', 'โต๊ะ', NULL),
    (activity_id_var, 'reservation', 'การจอง', NULL),
    (activity_id_var, 'tonight', 'คืนนี้', NULL),
    (activity_id_var, 'time', 'เวลา', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 4, 'Complete the Sentences 1', 'Fill with the correct word', '{"text": "I want to ___ a ___ for two. The ___ is at 7 p.m.", "blanks": [{"id": "blank1", "text": "book", "options": ["book", "table", "reservation", "time"], "correctAnswer": "book"}, {"id": "blank2", "text": "table", "options": ["table", "book", "reservation", "time"], "correctAnswer": "table"}, {"id": "blank3", "text": "reservation", "options": ["reservation", "time", "book", "table"], "correctAnswer": "reservation"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 5, 'Complete the Sentences 2', 'Fill with the correct word', '{"text": "Is there a table ___? Can I move the ___ to 8 p.m.? I would like a window table ___.", "blanks": [{"id": "blank1", "text": "tonight", "options": ["tonight", "time", "book", "table"], "correctAnswer": "tonight"}, {"id": "blank2", "text": "time", "options": ["time", "reservation", "tonight", "book"], "correctAnswer": "time"}, {"id": "blank3", "text": "reservation", "options": ["reservation", "tonight", "table", "book"], "correctAnswer": "reservation"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_explanation', 6, 'Present Continuous for Plans', 'Talk about near future plans', '{"rules": "Use present continuous for fixed plans.\n- I am booking a table.\n- We are eating at seven.\nForm: am/is/are + verb-ing.\nQuestions: Are you booking for tonight?", "examples": ["I am booking a table now.", "We are eating at 7 p.m.", "Are you coming tonight?", "She is choosing a time.", "They are waiting for a confirmation."]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 7, 'Build Sentences 1', 'Arrange words', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'I am booking a table now', 'I am booking a table now.', '["I", "am", "booking", "a", "table", "now."]'::jsonb),
    (activity_id_var, 'We are eating at seven', 'We are eating at seven.', '["We", "are", "eating", "at", "seven."]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 8, 'Build Sentences 2', 'Arrange words', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'Are you coming tonight', 'Are you coming tonight?', '["Are", "you", "coming", "tonight?"]'::jsonb),
    (activity_id_var, 'She is choosing a time', 'She is choosing a time.', '["She", "is", "choosing", "a", "time."]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'speaking_practice', 9, 'Talk About Booking', 'Practice booking a table', '{"prompts": ["How do you book a table at a restaurant?", "Do you prefer an early dinner or a late dinner?", "Who do you usually eat out with?", "What information do you give when booking a table?", "Have you ever forgotten a restaurant reservation?"]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (
      lesson_id,
      activity_type,
      activity_order,
      title,
      description,
      content
    ) VALUES (
      'A2-L15',
      'speaking_improvement',
      10,
      'Speaking Improvement',
      'Read the improved version of your speech',
      '{"type": "speaking_improvement", "similarityThreshold": 70}'::jsonb
    );
END $$;

