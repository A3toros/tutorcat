-- =========================================
-- Pre-fill Database with Sample Lesson Data
-- B1-L2: Education & Learning
-- =========================================

-- Clear existing sample data for B1-L2 (optional - comment out if you want to keep existing data)
DELETE FROM grammar_sentences WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'B1-L2');
DELETE FROM vocabulary_items WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'B1-L2');
DELETE FROM lesson_activities WHERE lesson_id = 'B1-L2';
DELETE FROM lessons WHERE id = 'B1-L2';

INSERT INTO lessons (id, level, lesson_number, topic) VALUES
('B1-L2', 'B1', 2, 'Education & Learning')
ON CONFLICT (id) DO UPDATE SET topic = EXCLUDED.topic;

DO $$
DECLARE
    lesson_id_var TEXT := 'B1-L2';
    activity_id_var UUID;
BEGIN
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content) VALUES (lesson_id_var, 'warm_up_speaking', 1, 'Learning Experiences', 'Talk about education', '{"prompt": "What is the most important thing you have learned?"}'::jsonb) RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content) VALUES (lesson_id_var, 'vocabulary_intro', 2, 'Education Words', 'Learn education vocabulary', '{}'::jsonb) RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'knowledge', 'ความรู้', NULL),
    (activity_id_var, 'skill', 'ทักษะ', NULL),
    (activity_id_var, 'degree', 'ปริญญา', NULL),
    (activity_id_var, 'course', 'หลักสูตร', NULL),
    (activity_id_var, 'research', 'การวิจัย', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content) VALUES (lesson_id_var, 'vocabulary_matching_drag', 3, 'Match Education Words', 'Match English words with Thai meanings', '{}'::jsonb) RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'knowledge', 'ความรู้', NULL),
    (activity_id_var, 'skill', 'ทักษะ', NULL),
    (activity_id_var, 'degree', 'ปริญญา', NULL),
    (activity_id_var, 'course', 'หลักสูตร', NULL),
    (activity_id_var, 'research', 'การวิจัย', NULL);

    -- 4. Vocabulary Fill Blanks #1 (4 words: knowledge, skill, degree, course - research left out)
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content) VALUES (lesson_id_var, 'vocabulary_fill_blanks', 4, 'Complete the Sentences 1', 'Fill in the blanks with correct words', '{"text": "I gained new ___ about history from reading books. I developed a new ___ in programming. I earned my ___ in engineering. I completed the English ___ last semester.", "blanks": [{"id": "blank1", "text": "knowledge", "options": ["knowledge", "skill", "degree", "course"], "correctAnswer": "knowledge"}, {"id": "blank2", "text": "skill", "options": ["knowledge", "skill", "degree", "course"], "correctAnswer": "skill"}, {"id": "blank3", "text": "degree", "options": ["knowledge", "skill", "degree", "course"], "correctAnswer": "degree"}, {"id": "blank4", "text": "course", "options": ["knowledge", "skill", "degree", "course"], "correctAnswer": "course"}]}'::jsonb) RETURNING id INTO activity_id_var;

    -- 4. Vocabulary Fill Blanks #2 (4 words: knowledge, skill, degree, research - course left out)
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content) VALUES (lesson_id_var, 'vocabulary_fill_blanks', 5, 'Complete the Sentences 2', 'Fill in the blanks with correct words', '{"text": "I have ___ about many subjects. I learned a new ___ in cooking. I got my ___ from university. I did ___ for my thesis.", "blanks": [{"id": "blank1", "text": "knowledge", "options": ["knowledge", "skill", "degree", "research"], "correctAnswer": "knowledge"}, {"id": "blank2", "text": "skill", "options": ["knowledge", "skill", "degree", "research"], "correctAnswer": "skill"}, {"id": "blank3", "text": "degree", "options": ["knowledge", "skill", "degree", "research"], "correctAnswer": "degree"}, {"id": "blank4", "text": "research", "options": ["knowledge", "skill", "degree", "research"], "correctAnswer": "research"}]}'::jsonb) RETURNING id INTO activity_id_var;

    -- 4. Grammar Explanation (5 examples - CEFR B1: Present perfect, expressing opinions)
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content) VALUES (lesson_id_var, 'grammar_explanation', 6, 'Present Perfect - Learning', 'Learn to talk about learning experiences', '{"rules": "Use present perfect for learning experiences:\n\n- I have learned + noun (I have learned English)\n- I have gained + noun (I have gained knowledge)\n- I have developed + noun (I have developed skills)\n- Use ''for'' and ''since'' with present perfect (I have studied for 3 years)\n- Express opinions: I think/believe/feel that...", "examples": ["I have learned many things in this course.", "She has gained valuable knowledge.", "We have developed new skills.", "I have studied English for five years.", "I think education is very important."]}'::jsonb) RETURNING id INTO activity_id_var;

    -- 4. Grammar Sentences #1
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content) VALUES (lesson_id_var, 'grammar_sentences', 7, 'Build Sentences 1', 'Arrange words to make sentences', '{}'::jsonb) RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'I have learned many things in this course', 'I have learned many things in this course', '["I", "have", "learned", "many", "things", "in", "this", "course"]'::jsonb),
    (activity_id_var, 'She has gained valuable knowledge', 'She has gained valuable knowledge', '["She", "has", "gained", "valuable", "knowledge"]'::jsonb);
    -- 4. Grammar Sentences #2
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content) VALUES (lesson_id_var, 'grammar_sentences', 8, 'Build Sentences 2', 'Arrange words to make sentences', '{}'::jsonb) RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'We have developed new skills', 'We have developed new skills', '["We", "have", "developed", "new", "skills"]'::jsonb),
    (activity_id_var, 'I think education is very important', 'I think education is very important', '["I", "think", "education", "is", "very", "important"]'::jsonb);
    -- 4. Speaking Practice (5 prompts - CEFR B1: Education and learning)
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content) VALUES (lesson_id_var, 'speaking_practice', 9, 'Talk About Education', 'Practice talking about learning', '{"prompts": ["What is the most important thing you have learned?", "What skills have you developed recently?", "How has education changed your life?", "What course would you like to take?", "Do you think formal education is necessary?"]}'::jsonb) RETURNING id INTO activity_id_var;

END $$;
INSERT INTO lesson_activities (
  lesson_id,
  activity_type,
  activity_order,
  title,
  description,
  content
) VALUES (
  'B1-L2',
  'speaking_improvement',
  10,
  'Speaking Improvement',
  'Read the improved version of your speech',
  '{"type": "speaking_improvement", "similarityThreshold": 70}'::jsonb
);