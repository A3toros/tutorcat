-- =========================================
-- Pre-fill Database with Sample Lesson Data
-- B1-L12: Social Media Influence
-- =========================================

DELETE FROM grammar_sentences WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'B1-L12');
DELETE FROM vocabulary_items WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'B1-L12');
DELETE FROM lesson_activities WHERE lesson_id = 'B1-L12';
DELETE FROM lessons WHERE id = 'B1-L12';

INSERT INTO lessons (id, level, lesson_number, topic) VALUES
('B1-L12', 'B1', 12, 'Social Media Influence')
ON CONFLICT (id) DO UPDATE SET topic = EXCLUDED.topic;

DO $$
DECLARE
    lesson_id_var TEXT := 'B1-L12';
    activity_id_var UUID;
BEGIN
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'warm_up_speaking', 1, 'Online Influence', 'Talk about how social media affects you', '{"prompt": "When did social media pull you in for too long?"}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_intro', 2, 'Influence Words', 'Learn vocabulary about social media influence', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'feed', 'ฟีด', NULL),
    (activity_id_var, 'trend', 'กระแส', NULL),
    (activity_id_var, 'influence', 'อิทธิพล', NULL),
    (activity_id_var, 'scroll', 'เลื่อนดู', NULL),
    (activity_id_var, 'distract', 'รบกวนสมาธิ', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_matching_drag', 3, 'Match Influence Words', 'Match words with meanings', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'feed', 'ฟีด', NULL),
    (activity_id_var, 'trend', 'กระแส', NULL),
    (activity_id_var, 'influence', 'อิทธิพล', NULL),
    (activity_id_var, 'scroll', 'เลื่อนดู', NULL),
    (activity_id_var, 'distract', 'รบกวนสมาธิ', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 4, 'Complete the Sentences 1', 'Fill with the correct word', '{"text": "I kept ___ for an hour. The new ___ spread fast. That post had a big ___.", "blanks": [{"id": "blank1", "text": "scrolling", "options": ["scrolling", "trend", "influence", "feed"], "correctAnswer": "scrolling"}, {"id": "blank2", "text": "trend", "options": ["trend", "feed", "distract", "influence"], "correctAnswer": "trend"}, {"id": "blank3", "text": "influence", "options": ["influence", "trend", "feed", "scroll"], "correctAnswer": "influence"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 5, 'Complete the Sentences 2', 'Fill with the correct word', '{"text": "My ___ was full of videos. Long scrolling can ___ me. A small post can ___ many people.", "blanks": [{"id": "blank1", "text": "feed", "options": ["feed", "trend", "scroll", "influence"], "correctAnswer": "feed"}, {"id": "blank2", "text": "distract", "options": ["distract", "influence", "scroll", "trend"], "correctAnswer": "distract"}, {"id": "blank3", "text": "influence", "options": ["influence", "trend", "feed", "scroll"], "correctAnswer": "influence"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    -- Grammar Explanation: Past Continuous
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_explanation', 6, 'Past Continuous for Ongoing Actions', 'Use was/were + verb-ing to describe actions in progress in the past', '{"rules": "Past continuous: was/were + verb-ing to show an action in progress at a past time or when another action happened.\\n- I was scrolling when I fell asleep.\\n- They were watching when the trend started.\\nUse for background actions and interrupted actions.", "examples": ["I was scrolling my feed when I lost track of time.", "She was watching videos while eating dinner.", "They were discussing a trend last night.", "We were following a live stream during the event.", "He was checking comments when his phone died."]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 7, 'Build Sentences 1', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'I was scrolling my feed when I fell asleep', 'I was scrolling my feed when I fell asleep', '["I", "was", "scrolling", "my", "feed", "when", "I", "fell", "asleep"]'::jsonb),
    (activity_id_var, 'She was watching videos while eating dinner', 'She was watching videos while eating dinner', '["She", "was", "watching", "videos", "while", "eating", "dinner"]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 8, 'Build Sentences 2', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'They were discussing a trend last night', 'They were discussing a trend last night', '["They", "were", "discussing", "a", "trend", "last", "night"]'::jsonb),
    (activity_id_var, 'We were following a live stream during the event', 'We were following a live stream during the event', '["We", "were", "following", "a", "live", "stream", "during", "the", "event"]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'speaking_practice', 9, 'Talk About Social Media Influence', 'Practice talking about social media influence', '{"prompts": ["When did social media pull you in for too long?", "Which trend actually changed what you did?", "Describe a post that genuinely inspired you."]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (
      lesson_id,
      activity_type,
      activity_order,
      title,
      description,
      content
    ) VALUES (
      'B1-L12',
      'speaking_improvement',
      10,
      'Speaking Improvement',
      'Read the improved version of your speech',
      '{"type": "speaking_improvement", "similarityThreshold": 70}'::jsonb
    );
END $$;


