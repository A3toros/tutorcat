-- =========================================
-- Pre-fill Database with Sample Lesson Data
-- C1-L20: Meritocracy in Education
-- =========================================

DELETE FROM grammar_sentences WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'C1-L20');
DELETE FROM vocabulary_items WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'C1-L20');
DELETE FROM lesson_activities WHERE lesson_id = 'C1-L20';
DELETE FROM lessons WHERE id = 'C1-L20';

INSERT INTO lessons (id, level, lesson_number, topic) VALUES
('C1-L20', 'C1', 20, 'Meritocracy in Education')
ON CONFLICT (id) DO UPDATE SET topic = EXCLUDED.topic;

DO $$
DECLARE
    lesson_id_var TEXT := 'C1-L20';
    activity_id_var UUID;
BEGIN
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'warm_up_speaking', 1, 'Meritocracy', 'Discuss meritocracy in education', '{"prompt": "Does effort always lead to success in education?"}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_intro', 2, 'Meritocracy Vocabulary', 'Learn vocabulary about meritocracy', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'meritocracy', 'ระบบคุณธรรม', NULL),
    (activity_id_var, 'merit', 'คุณความดี', NULL),
    (activity_id_var, 'achievement', 'ความสำเร็จ', NULL),
    (activity_id_var, 'equity', 'ความเท่าเทียม', NULL),
    (activity_id_var, 'fairness', 'ความยุติธรรม', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_matching_drag', 3, 'Match Meritocracy Words', 'Match English words with Thai meanings', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'meritocracy', 'ระบบคุณธรรม', NULL),
    (activity_id_var, 'merit', 'คุณความดี', NULL),
    (activity_id_var, 'achievement', 'ความสำเร็จ', NULL),
    (activity_id_var, 'equity', 'ความเท่าเทียม', NULL),
    (activity_id_var, 'fairness', 'ความยุติธรรม', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 4, 'Complete the Sentences 1', 'Fill with the correct word', '{"text": "A ___ rewards ___ and ___. True ___ requires equal starting points.", "blanks": [{"id": "blank1", "text": "meritocracy", "options": ["meritocracy", "merit", "achievement", "equity"], "correctAnswer": "meritocracy"}, {"id": "blank2", "text": "merit", "options": ["merit", "meritocracy", "achievement", "fairness"], "correctAnswer": "merit"}, {"id": "blank3", "text": "achievement", "options": ["achievement", "merit", "equity", "fairness"], "correctAnswer": "achievement"}, {"id": "blank4", "text": "equity", "options": ["equity", "merit", "achievement", "fairness"], "correctAnswer": "equity"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 5, 'Complete the Sentences 2', 'Fill with the correct word', '{"text": "___ in meritocracy means equal opportunity. ___ ensures rewards match effort.", "blanks": [{"id": "blank1", "text": "Fairness", "options": ["Fairness", "Merit", "Achievement", "Equity"], "correctAnswer": "Fairness"}, {"id": "blank2", "text": "Fairness", "options": ["Fairness", "Merit", "Achievement", "Equity"], "correctAnswer": "Fairness"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_explanation', 6, 'Mixed and Implied Conditionals', 'Learn advanced conditional structures', '{"rules": "Mixed and implied conditionals:\n- Mixed 2/3: \"If meritocracy worked (now), campuses would look different (now).\"\n- Mixed 3/2: \"If meritocracy had worked (past), campuses would look different (now).\"\n- Implied: \"Had meritocracy worked, campuses would be fairer.\" (omitted if)\n\nStructures:\n- If + past perfect, would + base form (past condition, present result)\n- If + past simple, would + base form (present condition, present result)\n- Had + past participle, would + base form (implied conditional)\n\nUse for:\n- Hypothetical past affecting present: \"If merit had mattered, access would be fairer.\"\n- Unreal present: \"If meritocracy worked, achievement would determine success.\"\n- Implied conditions: \"Had equity existed, merit would matter more.\"", "examples": ["If meritocracy had truly worked, campuses would look different now.", "If merit determined success, achievement would be rewarded fairly.", "Had equity been ensured, merit would matter more.", "If meritocracy worked, fairness would be visible everywhere.", "Had starting points been equal, merit would determine outcomes."]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 7, 'Build Sentences 1', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'If meritocracy had truly worked, campuses would look different now.', 'If meritocracy had truly worked, campuses would look different now.', '["If", "meritocracy", "had", "truly", "worked,", "campuses", "would", "look", "different", "now."]'::jsonb),
    (activity_id_var, 'If merit determined success, achievement would be rewarded fairly.', 'If merit determined success, achievement would be rewarded fairly.', '["If", "merit", "determined", "success,", "achievement", "would", "be", "rewarded", "fairly."]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 8, 'Build Sentences 2', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'Had equity been ensured, merit would matter more.', 'Had equity been ensured, merit would matter more.', '["Had", "equity", "been", "ensured,", "merit", "would", "matter", "more."]'::jsonb),
    (activity_id_var, 'If fairness existed, achievement would reflect true merit.', 'If fairness existed, achievement would reflect true merit.', '["If", "fairness", "existed,", "achievement", "would", "reflect", "true", "merit."]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'speaking_practice', 9, 'Discuss Meritocracy', 'Practice speaking about meritocracy', '{"prompts": ["If meritocracy worked perfectly, what would change?", "What limits fair competition in education?", "Does talent matter more than opportunity?", "How can systems reward effort fairly?", "What role does support play in achievement?"]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (
      lesson_id,
      activity_type,
      activity_order,
      title,
      description,
      content
    ) VALUES (
      'C1-L20',
      'speaking_improvement',
      10,
      'Speaking Improvement',
      'Read the improved version of your speech',
      '{"type": "speaking_improvement", "similarityThreshold": 70}'::jsonb
    );
END $$;
