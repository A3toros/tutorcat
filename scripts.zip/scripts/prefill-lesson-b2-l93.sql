-- =========================================
-- Pre-fill Database with Sample Lesson Data
-- B2-L93: Learning styles (deep)
-- =========================================

DELETE FROM grammar_sentences WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'B2-L93');
DELETE FROM vocabulary_items WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'B2-L93');
DELETE FROM lesson_activities WHERE lesson_id = 'B2-L93';
DELETE FROM lessons WHERE id = 'B2-L93';

INSERT INTO lessons (id, level, lesson_number, topic) VALUES
('B2-L93', 'B2', 93, 'Learning styles (deep)')
ON CONFLICT (id) DO UPDATE SET topic = EXCLUDED.topic;

DO $$
DECLARE
    lesson_id_var TEXT := 'B2-L93';
    activity_id_var UUID;
BEGIN
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'warm_up_speaking', 1, 'Style Check', 'Talk about your main style', '{"prompt": "How long have you used your main style, and when do you switch?"}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_intro', 2, 'Style Words', 'Key words for styles and adapting', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'visual', 'สายตา/ใช้ภาพ', NULL),
    (activity_id_var, 'auditory', 'การฟัง', NULL),
    (activity_id_var, 'kinesthetic', 'การเคลื่อนไหว/ลงมือทำ', NULL),
    (activity_id_var, 'adapt', 'ปรับตัว', NULL),
    (activity_id_var, 'match', 'เข้ากัน/ตรงกัน', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_matching_drag', 3, 'Match Style Words', 'Match words with meanings', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'visual', 'สายตา/ใช้ภาพ', NULL),
    (activity_id_var, 'auditory', 'การฟัง', NULL),
    (activity_id_var, 'kinesthetic', 'การเคลื่อนไหว/ลงมือทำ', NULL),
    (activity_id_var, 'adapt', 'ปรับตัว', NULL),
    (activity_id_var, 'match', 'เข้ากัน/ตรงกัน', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 4, 'Complete the Sentences 1', 'Fill with the correct word', '{"text": "I’m mainly ___. I can ___ styles to ___.", "blanks": [{"id": "blank1", "text": "visual", "options": ["visual", "auditory", "match", "adapt"], "correctAnswer": "visual"}, {"id": "blank2", "text": "adapt", "options": ["adapt", "match", "visual", "kinesthetic"], "correctAnswer": "adapt"}, {"id": "blank3", "text": "match", "options": ["match", "adapt", "auditory", "kinesthetic"], "correctAnswer": "match"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 5, 'Complete the Sentences 2', 'Fill with the correct word', '{"text": "___ practice helps me move. I switch to ___ when tired.", "blanks": [{"id": "blank1", "text": "Kinesthetic", "options": ["Kinesthetic", "Visual", "Auditory", "Adapt"], "correctAnswer": "Kinesthetic"}, {"id": "blank2", "text": "auditory", "options": ["auditory", "visual", "kinesthetic", "match"], "correctAnswer": "auditory"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_explanation', 6, 'Present Perfect Continuous', 'Show duration of style use', '{"rules": "Use have/has + been + -ing for actions started in the past and continuing now, often with for/since.\\n- I have been using a visual style for years.\\n- She has been switching styles since last term.", "examples": ["I have been relying on visual notes for two years.", "She has been mixing auditory practice since January.", "They have been adapting styles for group work.", "We have been matching tasks to styles lately.", "He has been using kinesthetic practice all week."]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 7, 'Build Sentences 1', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'I have been relying on visual notes for two years', 'I have been relying on visual notes for two years.', '["I", "have", "been", "relying", "on", "visual", "notes", "for", "two", "years."]'::jsonb),
    (activity_id_var, 'She has been mixing auditory practice since January', 'She has been mixing auditory practice since January.', '["She", "has", "been", "mixing", "auditory", "practice", "since", "January."]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 8, 'Build Sentences 2', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'They have been adapting styles for group work', 'They have been adapting styles for group work.', '["They", "have", "been", "adapting", "styles", "for", "group", "work."]'::jsonb),
    (activity_id_var, 'He has been using kinesthetic practice all week', 'He has been using kinesthetic practice all week.', '["He", "has", "been", "using", "kinesthetic", "practice", "all", "week."]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'speaking_practice', 9, 'Talk About Styles', 'Practice present perfect continuous', '{"prompts": ["How long have you used your main style?", "When do you switch styles?", "What mix helps you when tired?"]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (
      lesson_id,
      activity_type,
      activity_order,
      title,
      description,
      content
    ) VALUES (
      'B2-L93',
      'speaking_improvement',
      10,
      'Speaking Improvement',
      'Read the improved version of your speech',
      '{"type": "speaking_improvement", "similarityThreshold": 70}'::jsonb
    );
END $$;


