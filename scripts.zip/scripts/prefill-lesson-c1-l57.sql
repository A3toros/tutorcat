-- =========================================
-- Pre-fill Database with Sample Lesson Data
-- C1-L57: Green Technology Promises & Limits
-- =========================================
DELETE FROM lesson_activity_results WHERE lesson_id = 'C1-L57';
DELETE FROM user_progress WHERE lesson_id = 'C1-L57';
DELETE FROM lesson_history WHERE lesson_id = 'C1-L57';
DELETE FROM grammar_sentences WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'C1-L57');
DELETE FROM vocabulary_items WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'C1-L57');
DELETE FROM lesson_activities WHERE lesson_id = 'C1-L57';
DELETE FROM lessons WHERE id = 'C1-L57';

INSERT INTO lessons (id, level, lesson_number, topic) VALUES
('C1-L57', 'C1', 57, 'Green Technology Promises & Limits')
ON CONFLICT (id) DO UPDATE SET topic = EXCLUDED.topic;

DO $$
DECLARE
    lesson_id_var TEXT := 'C1-L57';
    activity_id_var UUID;
BEGIN
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'warm_up_speaking', 1, 'Green Technology', 'Discuss green technology', '{"prompt": "What hopes do you have for green technology?"}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_intro', 2, 'Green Technology Vocabulary', 'Learn vocabulary about green technology', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'promise', 'คำสัญญา', NULL),
    (activity_id_var, 'hope', 'ความหวัง', NULL),
    (activity_id_var, 'hype', 'การโฆษณาเกินจริง', NULL),
    (activity_id_var, 'limitation', 'ข้อจำกัด', NULL),
    (activity_id_var, 'realism', 'ความสมจริง', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_matching_drag', 3, 'Match Green Technology Words', 'Match English words with Thai meanings', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'promise', 'คำสัญญา', NULL),
    (activity_id_var, 'hope', 'ความหวัง', NULL),
    (activity_id_var, 'hype', 'การโฆษณาเกินจริง', NULL),
    (activity_id_var, 'limitation', 'ข้อจำกัด', NULL),
    (activity_id_var, 'realism', 'ความสมจริง', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 4, 'Complete the Sentences 1', 'Fill with the correct word', '{"text": "Green technology offers ___. ___ for innovation drives progress.", "blanks": [{"id": "blank1", "text": "promises", "options": ["promises", "hope", "hype", "limitation"], "correctAnswer": "promises"}, {"id": "blank2", "text": "Hope", "options": ["Hope", "Promise", "Hype", "Limitation"], "correctAnswer": "Hope"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 5, 'Complete the Sentences 2', 'Fill with the correct word', '{"text": "Excessive ___ creates false expectations. Understanding ___ requires ___.", "blanks": [{"id": "blank1", "text": "hype", "options": ["hype", "promise", "hope", "limitation"], "correctAnswer": "hype"}, {"id": "blank2", "text": "limitations", "options": ["limitations", "promise", "hope", "hype"], "correctAnswer": "limitations"}, {"id": "blank3", "text": "realism", "options": ["realism", "promise", "hope", "hype"], "correctAnswer": "realism"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_explanation', 6, 'Contrast Linking', 'Learn contrast linking devices', '{"rules": "Contrast linking devices:\n- \"While green technology offers promise, it has limitations.\"\n- \"However, hype can create false expectations.\"\n- \"On the other hand, realism is important.\"\n- \"Whereas some technologies excite, others concern.\"\n\nUse for:\n- Showing contrast: \"While hope exists, limitations remain.\"\n- Balancing views: \"On one hand, technology promises much; on the other, it has limits.\"\n- Comparing: \"Whereas some see promise, others see hype.\"", "examples": ["While green technology offers promise, it has limitations.", "However, hype can create false expectations.", "On the other hand, realism is important for progress.", "Whereas some technologies excite, others concern.", "While hope drives innovation, realism ensures success."]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 7, 'Build Sentences 1', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'While green technology offers promise, it has limitations.', 'While green technology offers promise, it has limitations.', '["While", "green", "technology", "offers", "promise,", "it", "has", "limitations."]'::jsonb),
    (activity_id_var, 'However, hype can create false expectations.', 'However, hype can create false expectations.', '["However,", "hype", "can", "create", "false", "expectations."]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 8, 'Build Sentences 2', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'On the other hand, realism is important for progress.', 'On the other hand, realism is important for progress.', '["On", "the", "other", "hand,", "realism", "is", "important", "for", "progress."]'::jsonb),
    (activity_id_var, 'Whereas some technologies excite, others concern.', 'Whereas some technologies excite, others concern.', '["Whereas", "some", "technologies", "excite,", "others", "concern."]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'speaking_practice', 9, 'Discuss Green Technology', 'Practice speaking about green technology', '{"prompts": ["What hopes do you have for green technology?", "Where do you see exaggeration or hype?", "What green technologies excite you?", "What limitations concern you?", "How do you balance optimism with realism?"]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (
      lesson_id,
      activity_type,
      activity_order,
      title,
      description,
      content
    ) VALUES (
      'C1-L57',
      'speaking_improvement',
      10,
      'Speaking Improvement',
      'Read the improved version of your speech',
      '{"type": "speaking_improvement", "similarityThreshold": 70}'::jsonb
    );
END $$;
