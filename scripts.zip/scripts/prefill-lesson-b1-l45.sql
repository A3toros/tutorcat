-- =========================================
-- Pre-fill Database with Sample Lesson Data
-- B1-L45: Giving Opinions Politely
-- =========================================

DELETE FROM grammar_sentences WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'B1-L45');
DELETE FROM vocabulary_items WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'B1-L45');
DELETE FROM lesson_activities WHERE lesson_id = 'B1-L45';
DELETE FROM lessons WHERE id = 'B1-L45';

INSERT INTO lessons (id, level, lesson_number, topic) VALUES
('B1-L45', 'B1', 45, 'Giving Opinions Politely')
ON CONFLICT (id) DO UPDATE SET topic = EXCLUDED.topic;

DO $$
DECLARE
    lesson_id_var TEXT := 'B1-L45';
    activity_id_var UUID;
BEGIN
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'warm_up_speaking', 1, 'Sharing Opinions', 'Talk about softening opinions', '{"prompt": "How do you share a tough opinion without sounding rude?"}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_intro', 2, 'Opinion Words', 'Learn vocabulary about giving opinions politely', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'suggest', 'แนะนำ', NULL),
    (activity_id_var, 'recommend', 'แนะนำ (เป็นพิเศษ)', NULL),
    (activity_id_var, 'agree', 'เห็นด้วย', NULL),
    (activity_id_var, 'disagree', 'ไม่เห็นด้วย', NULL),
    (activity_id_var, 'consider', 'พิจารณา', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_matching_drag', 3, 'Match Opinion Words', 'Match words with meanings', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'suggest', 'แนะนำ', NULL),
    (activity_id_var, 'recommend', 'แนะนำ (เป็นพิเศษ)', NULL),
    (activity_id_var, 'agree', 'เห็นด้วย', NULL),
    (activity_id_var, 'disagree', 'ไม่เห็นด้วย', NULL),
    (activity_id_var, 'consider', 'พิจารณา', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 4, 'Complete the Sentences 1', 'Fill with the correct word', '{"text": "May I ___ something? I would ___ this idea. I ___ partly.", "blanks": [{"id": "blank1", "text": "suggest", "options": ["suggest", "recommend", "agree", "consider"], "correctAnswer": "suggest"}, {"id": "blank2", "text": "recommend", "options": ["recommend", "consider", "disagree", "suggest"], "correctAnswer": "recommend"}, {"id": "blank3", "text": "agree", "options": ["agree", "disagree", "recommend", "suggest"], "correctAnswer": "agree"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 5, 'Complete the Sentences 2', 'Fill with the correct word', '{"text": "I ___ politely. Please ___ the timing. I want to ___ everyone''s view.", "blanks": [{"id": "blank1", "text": "disagree", "options": ["disagree", "agree", "consider", "suggest"], "correctAnswer": "disagree"}, {"id": "blank2", "text": "consider", "options": ["consider", "disagree", "recommend", "suggest"], "correctAnswer": "consider"}, {"id": "blank3", "text": "consider", "options": ["consider", "agree", "disagree", "recommend"], "correctAnswer": "consider"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    -- Grammar Explanation: Modals (should) for polite opinions
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_explanation', 6, 'Modals: Should for Polite Opinions', 'Use should to give gentle advice and opinions', '{"rules": "Use should to give polite suggestions and opinions.\\n- We should consider both sides.\\n- You should add a reason.\\nKeep tone soft; avoid contractions.", "examples": ["We should consider both sides before deciding.", "You should explain your view calmly.", "They should add reasons, not just feelings.", "I think we should wait for more data.", "You should disagree politely when needed."]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 7, 'Build Sentences 1', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'We should consider both sides before deciding', 'We should consider both sides before deciding', '["We", "should", "consider", "both", "sides", "before", "deciding"]'::jsonb),
    (activity_id_var, 'You should explain your view calmly', 'You should explain your view calmly', '["You", "should", "explain", "your", "view", "calmly"]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 8, 'Build Sentences 2', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'They should add reasons not just feelings', 'They should add reasons, not just feelings', '["They", "should", "add", "reasons,", "not", "just", "feelings"]'::jsonb),
    (activity_id_var, 'I think we should wait for more data', 'I think we should wait for more data', '["I", "think", "we", "should", "wait", "for", "more", "data"]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'speaking_practice', 9, 'Talk About Opinions', 'Practice giving polite opinions', '{"prompts": ["How do you share a tough opinion without sounding rude?", "When do you soften your words?", "Describe a polite disagreement you had."]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (
      lesson_id,
      activity_type,
      activity_order,
      title,
      description,
      content
    ) VALUES (
      'B1-L45',
      'speaking_improvement',
      10,
      'Speaking Improvement',
      'Read the improved version of your speech',
      '{"type": "speaking_improvement", "similarityThreshold": 70}'::jsonb
    );
END $$;

