-- =========================================
-- Pre-fill Database with Sample Lesson Data
-- B1-L51: Online Shopping
-- =========================================

DELETE FROM grammar_sentences WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'B1-L51');
DELETE FROM vocabulary_items WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'B1-L51');
DELETE FROM lesson_activities WHERE lesson_id = 'B1-L51';
DELETE FROM lessons WHERE id = 'B1-L51';

INSERT INTO lessons (id, level, lesson_number, topic) VALUES
('B1-L51', 'B1', 51, 'Online Shopping')
ON CONFLICT (id) DO UPDATE SET topic = EXCLUDED.topic;

DO $$
DECLARE
    lesson_id_var TEXT := 'B1-L51';
    activity_id_var UUID;
BEGIN
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'warm_up_speaking', 1, 'Buying Online', 'Talk about recent online purchases', '{"prompt": "What have you bought online recently that you loved?"}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_intro', 2, 'Online Shopping Words', 'Learn vocabulary about shopping online', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'cart', 'ตะกร้าสินค้า', NULL),
    (activity_id_var, 'checkout', 'ชำระเงิน', NULL),
    (activity_id_var, 'return', 'คืนสินค้า', NULL),
    (activity_id_var, 'warranty', 'การรับประกัน', NULL),
    (activity_id_var, 'review', 'รีวิว', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_matching_drag', 3, 'Match Online Shopping Words', 'Match words with meanings', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'cart', 'ตะกร้าสินค้า', NULL),
    (activity_id_var, 'checkout', 'ชำระเงิน', NULL),
    (activity_id_var, 'return', 'คืนสินค้า', NULL),
    (activity_id_var, 'warranty', 'การรับประกัน', NULL),
    (activity_id_var, 'review', 'รีวิว', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 4, 'Complete the Sentences 1', 'Fill with the correct word', '{"text": "Add items to the ___. Go to ___. You can ___ if it is broken.", "blanks": [{"id": "blank1", "text": "cart", "options": ["cart", "checkout", "return", "review"], "correctAnswer": "cart"}, {"id": "blank2", "text": "checkout", "options": ["checkout", "cart", "warranty", "return"], "correctAnswer": "checkout"}, {"id": "blank3", "text": "return", "options": ["return", "warranty", "review", "cart"], "correctAnswer": "return"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 5, 'Complete the Sentences 2', 'Fill with the correct word', '{"text": "Check the ___. Read each ___. Keep the ___ for repairs.", "blanks": [{"id": "blank1", "text": "warranty", "options": ["warranty", "checkout", "cart", "return"], "correctAnswer": "warranty"}, {"id": "blank2", "text": "review", "options": ["review", "warranty", "cart", "return"], "correctAnswer": "review"}, {"id": "blank3", "text": "receipt", "options": ["receipt", "warranty", "review", "cart"], "correctAnswer": "receipt"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    -- Grammar Explanation: Present Perfect (online shopping experiences)
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_explanation', 6, 'Present Perfect for Online Shopping', 'Use have/has + past participle to talk about recent purchases and experiences', '{"rules": "Present perfect for experiences and recent results without exact time.\\n- I have bought a new laptop online.\\n- She has returned three items this year.\\nAvoid specific past times; use past simple for finished events.", "examples": ["I have bought a new laptop online.", "She has returned three items this year.", "They have read many reviews before buying.", "We have used the warranty once.", "He has checked out on this site often."]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 7, 'Build Sentences 1', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'I have bought a new laptop online', 'I have bought a new laptop online', '["I", "have", "bought", "a", "new", "laptop", "online"]'::jsonb),
    (activity_id_var, 'She has returned three items this year', 'She has returned three items this year', '["She", "has", "returned", "three", "items", "this", "year"]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 8, 'Build Sentences 2', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'They have read many reviews before buying', 'They have read many reviews before buying', '["They", "have", "read", "many", "reviews", "before", "buying"]'::jsonb),
    (activity_id_var, 'We have used the warranty once', 'We have used the warranty once', '["We", "have", "used", "the", "warranty", "once"]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'speaking_practice', 9, 'Talk About Online Shopping', 'Practice talking about buying online', '{"prompts": ["What have you bought online recently that you loved?", "When did a review save you from a bad buy?", "Describe your smoothest delivery ever."]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (
      lesson_id,
      activity_type,
      activity_order,
      title,
      description,
      content
    ) VALUES (
      'B1-L51',
      'speaking_improvement',
      10,
      'Speaking Improvement',
      'Read the improved version of your speech',
      '{"type": "speaking_improvement", "similarityThreshold": 70}'::jsonb
    );
END $$;

