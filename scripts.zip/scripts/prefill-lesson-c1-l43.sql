-- =========================================
-- Pre-fill Database with Sample Lesson Data
-- C1-L43: Data Privacy and Consent
-- =========================================
DELETE FROM lesson_activity_results WHERE lesson_id = 'C1-L43';
DELETE FROM user_progress WHERE lesson_id = 'C1-L43';
DELETE FROM lesson_history WHERE lesson_id = 'C1-L43';
DELETE FROM grammar_sentences WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'C1-L43');
DELETE FROM vocabulary_items WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'C1-L43');
DELETE FROM lesson_activities WHERE lesson_id = 'C1-L43';
DELETE FROM lessons WHERE id = 'C1-L43';

INSERT INTO lessons (id, level, lesson_number, topic) VALUES
('C1-L43', 'C1', 43, 'Data Privacy and Consent')
ON CONFLICT (id) DO UPDATE SET topic = EXCLUDED.topic;

DO $$
DECLARE
    lesson_id_var TEXT := 'C1-L43';
    activity_id_var UUID;
BEGIN
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'warm_up_speaking', 1, 'Data Privacy', 'Discuss data privacy and consent', '{"prompt": "What does consent mean online?"}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_intro', 2, 'Data Privacy Vocabulary', 'Learn vocabulary about data privacy', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'consent', 'ความยินยอม', NULL),
    (activity_id_var, 'privacy', 'ความเป็นส่วนตัว', NULL),
    (activity_id_var, 'ownership', 'ความเป็นเจ้าของ', NULL),
    (activity_id_var, 'sharing', 'การแบ่งปัน', NULL),
    (activity_id_var, 'protection', 'การป้องกัน', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_matching_drag', 3, 'Match Data Privacy Words', 'Match English words with Thai meanings', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'consent', 'ความยินยอม', NULL),
    (activity_id_var, 'privacy', 'ความเป็นส่วนตัว', NULL),
    (activity_id_var, 'ownership', 'ความเป็นเจ้าของ', NULL),
    (activity_id_var, 'sharing', 'การแบ่งปัน', NULL),
    (activity_id_var, 'protection', 'การป้องกัน', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 4, 'Complete the Sentences 1', 'Fill with the correct word', '{"text": "Informed ___ protects ___. Data ___ determines ___.", "blanks": [{"id": "blank1", "text": "consent", "options": ["consent", "privacy", "ownership", "sharing"], "correctAnswer": "consent"}, {"id": "blank2", "text": "privacy", "options": ["privacy", "consent", "ownership", "protection"], "correctAnswer": "privacy"}, {"id": "blank3", "text": "ownership", "options": ["ownership", "consent", "privacy", "sharing"], "correctAnswer": "ownership"}, {"id": "blank4", "text": "sharing", "options": ["sharing", "consent", "privacy", "ownership"], "correctAnswer": "sharing"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 5, 'Complete the Sentences 2', 'Fill with the correct word', '{"text": "Data ___ requires user ___. Privacy ___ prevents unauthorized access.", "blanks": [{"id": "blank1", "text": "sharing", "options": ["sharing", "consent", "privacy", "ownership"], "correctAnswer": "sharing"}, {"id": "blank2", "text": "consent", "options": ["consent", "privacy", "ownership", "protection"], "correctAnswer": "consent"}, {"id": "blank3", "text": "protection", "options": ["protection", "consent", "privacy", "ownership"], "correctAnswer": "protection"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_explanation', 6, 'Nominal Clauses', 'Learn about nominal clauses', '{"rules": "Nominal clauses function as nouns:\n- Subject: \"What consent means matters online.\"\n- Object: \"I believe that data ownership is important.\"\n- Complement: \"The question is who owns your data.\"\n\nTypes:\n- That-clauses: \"I think that consent is crucial.\"\n- Wh-clauses: \"What you share determines privacy.\"\n- Whether/if: \"The issue is whether consent is clear.\"\n\nUse for:\n- Expressing opinions: \"What I think is that consent matters.\"\n- Asking questions: \"Who owns your data?\"\n- Making statements: \"That privacy matters is clear.\"", "examples": ["What consent means online is often unclear.", "I believe that data ownership is important.", "The question is who owns your personal data.", "Whether consent is truly informed remains uncertain.", "That privacy matters is widely accepted."]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 7, 'Build Sentences 1', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'What consent means online is often unclear.', 'What consent means online is often unclear.', '["What", "consent", "means", "online", "is", "often", "unclear."]'::jsonb),
    (activity_id_var, 'I believe that data ownership is important.', 'I believe that data ownership is important.', '["I", "believe", "that", "data", "ownership", "is", "important."]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 8, 'Build Sentences 2', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'The question is who owns your personal data.', 'The question is who owns your personal data.', '["The", "question", "is", "who", "owns", "your", "personal", "data."]'::jsonb),
    (activity_id_var, 'Whether consent is truly informed remains uncertain.', 'Whether consent is truly informed remains uncertain.', '["Whether", "consent", "is", "truly", "informed", "remains", "uncertain."]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'speaking_practice', 9, 'Discuss Data Privacy', 'Practice speaking about data privacy', '{"prompts": ["Who owns personal data?", "What data do you share knowingly?", "How do you protect your privacy?", "When is consent unclear?", "How should companies handle user data?"]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (
      lesson_id,
      activity_type,
      activity_order,
      title,
      description,
      content
    ) VALUES (
      'C1-L43',
      'speaking_improvement',
      10,
      'Speaking Improvement',
      'Read the improved version of your speech',
      '{"type": "speaking_improvement", "similarityThreshold": 70}'::jsonb
    );
END $$;
