-- =========================================
-- Pre-fill Database with Sample Lesson Data
-- B1-L15: Personal Finances
-- =========================================

DELETE FROM grammar_sentences WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'B1-L15');
DELETE FROM vocabulary_items WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'B1-L15');
DELETE FROM lesson_activities WHERE lesson_id = 'B1-L15';
DELETE FROM lessons WHERE id = 'B1-L15';

INSERT INTO lessons (id, level, lesson_number, topic) VALUES
('B1-L15', 'B1', 15, 'Personal Finances')
ON CONFLICT (id) DO UPDATE SET topic = EXCLUDED.topic;

DO $$
DECLARE
    lesson_id_var TEXT := 'B1-L15';
    activity_id_var UUID;
BEGIN
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'warm_up_speaking', 1, 'Money Habits', 'Talk about tracking spending and saving', '{"prompt": "How do you keep track of your money in real life?"}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_intro', 2, 'Finance Words', 'Learn vocabulary about personal finances', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'expense', 'ค่าใช้จ่าย', NULL),
    (activity_id_var, 'income', 'รายได้', NULL),
    (activity_id_var, 'bill', 'บิล', NULL),
    (activity_id_var, 'budget', 'งบประมาณ', NULL),
    (activity_id_var, 'wallet', 'กระเป๋าสตางค์', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_matching_drag', 3, 'Match Finance Words', 'Match words with meanings', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'expense', 'ค่าใช้จ่าย', NULL),
    (activity_id_var, 'income', 'รายได้', NULL),
    (activity_id_var, 'bill', 'บิล', NULL),
    (activity_id_var, 'budget', 'งบประมาณ', NULL),
    (activity_id_var, 'wallet', 'กระเป๋าสตางค์', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 4, 'Complete the Sentences 1', 'Fill with the correct word', '{"text": "I track each ___. My monthly ___ is clear. I pay every ___.", "blanks": [{"id": "blank1", "text": "expense", "options": ["expense", "income", "bill", "budget"], "correctAnswer": "expense"}, {"id": "blank2", "text": "budget", "options": ["budget", "wallet", "income", "expense"], "correctAnswer": "budget"}, {"id": "blank3", "text": "bill", "options": ["bill", "budget", "income", "wallet"], "correctAnswer": "bill"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 5, 'Complete the Sentences 2', 'Fill with the correct word', '{"text": "My ___ comes on Friday. I keep cash in my ___. A clear ___ helps me save.", "blanks": [{"id": "blank1", "text": "income", "options": ["income", "expense", "bill", "budget"], "correctAnswer": "income"}, {"id": "blank2", "text": "wallet", "options": ["wallet", "budget", "bill", "expense"], "correctAnswer": "wallet"}, {"id": "blank3", "text": "budget", "options": ["budget", "income", "expense", "bill"], "correctAnswer": "budget"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    -- Grammar Explanation: Articles (definite vs zero) in finance contexts
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_explanation', 6, 'Articles in Finance', 'Use the/zero article with general vs specific finance items', '{"rules": "Use the for specific known items: the bill, the budget. Use zero article for general concepts: pay bills, track expenses, make budgets.\\n- I paid the electricity bill.\\n- I track expenses in a sheet.\\n- The budget for this month is tight.", "examples": ["I paid the phone bill yesterday.", "I track expenses in a spreadsheet.", "The budget for this trip is small.", "She keeps cash in a wallet.", "They reviewed the income for the project."]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 7, 'Build Sentences 1', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'I paid the phone bill yesterday', 'I paid the phone bill yesterday', '["I", "paid", "the", "phone", "bill", "yesterday"]'::jsonb),
    (activity_id_var, 'I track expenses in a spreadsheet', 'I track expenses in a spreadsheet', '["I", "track", "expenses", "in", "a", "spreadsheet"]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 8, 'Build Sentences 2', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'The budget for this trip is small', 'The budget for this trip is small', '["The", "budget", "for", "this", "trip", "is", "small"]'::jsonb),
    (activity_id_var, 'She keeps cash in a wallet', 'She keeps cash in a wallet', '["She", "keeps", "cash", "in", "a", "wallet"]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'speaking_practice', 9, 'Talk About Money Habits', 'Practice talking about personal finances', '{"prompts": ["How do you keep track of your money in real life?", "What is the smartest purchase you have made?", "When do you decide to save instead of spend?"]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (
      lesson_id,
      activity_type,
      activity_order,
      title,
      description,
      content
    ) VALUES (
      'B1-L15',
      'speaking_improvement',
      10,
      'Speaking Improvement',
      'Read the improved version of your speech',
      '{"type": "speaking_improvement", "similarityThreshold": 70}'::jsonb
    );
END $$;


