-- =========================================
-- Pre-fill Database with Sample Lesson Data
-- C1-L54: Climate Anxiety
-- =========================================
DELETE FROM lesson_activity_results WHERE lesson_id = 'C1-L54';
DELETE FROM user_progress WHERE lesson_id = 'C1-L54';
DELETE FROM lesson_history WHERE lesson_id = 'C1-L54';
DELETE FROM grammar_sentences WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'C1-L54');
DELETE FROM vocabulary_items WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'C1-L54');
DELETE FROM lesson_activities WHERE lesson_id = 'C1-L54';
DELETE FROM lessons WHERE id = 'C1-L54';

INSERT INTO lessons (id, level, lesson_number, topic) VALUES
('C1-L54', 'C1', 54, 'Climate Anxiety')
ON CONFLICT (id) DO UPDATE SET topic = EXCLUDED.topic;

DO $$
DECLARE
    lesson_id_var TEXT := 'C1-L54';
    activity_id_var UUID;
BEGIN
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'warm_up_speaking', 1, 'Climate Anxiety', 'Discuss climate anxiety', '{"prompt": "What helps you stay calm when thinking about the future?"}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_intro', 2, 'Climate Anxiety Vocabulary', 'Learn vocabulary about climate anxiety', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'anxiety', 'ความวิตกกังวล', NULL),
    (activity_id_var, 'calm', 'ความสงบ', NULL),
    (activity_id_var, 'management', 'การจัดการ', NULL),
    (activity_id_var, 'hope', 'ความหวัง', NULL),
    (activity_id_var, 'balance', 'ความสมดุล', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_matching_drag', 3, 'Match Climate Anxiety Words', 'Match English words with Thai meanings', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'anxiety', 'ความวิตกกังวล', NULL),
    (activity_id_var, 'calm', 'ความสงบ', NULL),
    (activity_id_var, 'management', 'การจัดการ', NULL),
    (activity_id_var, 'hope', 'ความหวัง', NULL),
    (activity_id_var, 'balance', 'ความสมดุล', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 4, 'Complete the Sentences 1', 'Fill with the correct word', '{"text": "Climate ___ affects many. Finding ___ requires ___.", "blanks": [{"id": "blank1", "text": "anxiety", "options": ["anxiety", "calm", "management", "hope"], "correctAnswer": "anxiety"}, {"id": "blank2", "text": "calm", "options": ["calm", "anxiety", "management", "hope"], "correctAnswer": "calm"}, {"id": "blank3", "text": "management", "options": ["management", "anxiety", "calm", "hope"], "correctAnswer": "management"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 5, 'Complete the Sentences 2', 'Fill with the correct word', '{"text": "Maintaining ___ helps. Balancing concern with ___ is important.", "blanks": [{"id": "blank1", "text": "hope", "options": ["hope", "anxiety", "calm", "management"], "correctAnswer": "hope"}, {"id": "blank2", "text": "action", "options": ["action", "anxiety", "calm", "management"], "correctAnswer": "action"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_explanation', 6, 'Nominal Clauses', 'Learn about nominal clauses', '{"rules": "Nominal clauses function as nouns:\n- Subject: \"What you tell yourself affects anxiety.\"\n- Object: \"I believe that hope matters.\"\n- Complement: \"The question is what helps you stay calm.\"\n\nTypes:\n- That-clauses: \"I think that anxiety is manageable.\"\n- Wh-clauses: \"What you tell yourself shapes your response.\"\n- Whether/if: \"The issue is whether hope is possible.\"\n\nUse for:\n- Expressing thoughts: \"What I tell myself is that action helps.\"\n- Asking questions: \"What helps you stay calm?\"\n- Making statements: \"That anxiety exists is understandable.\"", "examples": ["What you tell yourself about the future affects anxiety.", "I believe that hope helps manage climate anxiety.", "The question is what helps you stay calm.", "Whether hope is possible remains debated.", "That anxiety exists is widely recognized."]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 7, 'Build Sentences 1', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'What you tell yourself about the future affects anxiety.', 'What you tell yourself about the future affects anxiety.', '["What", "you", "tell", "yourself", "about", "the", "future", "affects", "anxiety."]'::jsonb),
    (activity_id_var, 'I believe that hope helps manage climate anxiety.', 'I believe that hope helps manage climate anxiety.', '["I", "believe", "that", "hope", "helps", "manage", "climate", "anxiety."]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 8, 'Build Sentences 2', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'The question is what helps you stay calm.', 'The question is what helps you stay calm.', '["The", "question", "is", "what", "helps", "you", "stay", "calm."]'::jsonb),
    (activity_id_var, 'Whether hope is possible remains debated.', 'Whether hope is possible remains debated.', '["Whether", "hope", "is", "possible", "remains", "debated."]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'speaking_practice', 9, 'Discuss Climate Anxiety', 'Practice speaking about climate anxiety', '{"prompts": ["What do you tell yourself about the future?", "What helps you feel calmer?", "How do you manage climate anxiety?", "What helps you stay hopeful?", "How do you balance concern with action?"]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (
      lesson_id,
      activity_type,
      activity_order,
      title,
      description,
      content
    ) VALUES (
      'C1-L54',
      'speaking_improvement',
      10,
      'Speaking Improvement',
      'Read the improved version of your speech',
      '{"type": "speaking_improvement", "similarityThreshold": 70}'::jsonb
    );
END $$;
