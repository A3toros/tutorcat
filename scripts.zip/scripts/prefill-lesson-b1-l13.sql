-- =========================================
-- Pre-fill Database with Sample Lesson Data
-- B1-L13: Travel Planning
-- =========================================

DELETE FROM grammar_sentences WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'B1-L13');
DELETE FROM vocabulary_items WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'B1-L13');
DELETE FROM lesson_activities WHERE lesson_id = 'B1-L13';
DELETE FROM lessons WHERE id = 'B1-L13';

INSERT INTO lessons (id, level, lesson_number, topic) VALUES
('B1-L13', 'B1', 13, 'Travel Planning')
ON CONFLICT (id) DO UPDATE SET topic = EXCLUDED.topic;

DO $$
DECLARE
    lesson_id_var TEXT := 'B1-L13';
    activity_id_var UUID;
BEGIN
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'warm_up_speaking', 1, 'Plan a Trip', 'Talk about how you plan trips', '{"prompt": "How do you actually plan a trip step by step?"}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_intro', 2, 'Travel Plan Words', 'Learn vocabulary about planning travel', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'itinerary', 'แผนการเดินทาง', NULL),
    (activity_id_var, 'budget', 'งบประมาณ', NULL),
    (activity_id_var, 'booking', 'การจอง', NULL),
    (activity_id_var, 'reserve', 'จอง', NULL),
    (activity_id_var, 'cancel', 'ยกเลิก', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_matching_drag', 3, 'Match Travel Words', 'Match words with meanings', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'itinerary', 'แผนการเดินทาง', NULL),
    (activity_id_var, 'budget', 'งบประมาณ', NULL),
    (activity_id_var, 'booking', 'การจอง', NULL),
    (activity_id_var, 'reserve', 'จอง', NULL),
    (activity_id_var, 'cancel', 'ยกเลิก', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 4, 'Complete the Sentences 1', 'Fill with the correct word', '{"text": "I planned an ___. We set a ___. I made a hotel ___.", "blanks": [{"id": "blank1", "text": "itinerary", "options": ["itinerary", "budget", "booking", "reserve"], "correctAnswer": "itinerary"}, {"id": "blank2", "text": "budget", "options": ["budget", "booking", "cancel", "reserve"], "correctAnswer": "budget"}, {"id": "blank3", "text": "booking", "options": ["booking", "itinerary", "budget", "cancel"], "correctAnswer": "booking"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 5, 'Complete the Sentences 2', 'Fill with the correct word', '{"text": "I need to ___ seats today. We may ___ if plans change. Check the ___ to save money.", "blanks": [{"id": "blank1", "text": "reserve", "options": ["reserve", "cancel", "budget", "booking"], "correctAnswer": "reserve"}, {"id": "blank2", "text": "cancel", "options": ["cancel", "reserve", "booking", "itinerary"], "correctAnswer": "cancel"}, {"id": "blank3", "text": "budget", "options": ["budget", "booking", "reserve", "cancel"], "correctAnswer": "budget"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    -- Grammar Explanation: Future (will vs going to)
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_explanation', 6, 'Future: Will vs Going To', 'Use will for decisions/uncertainty, going to for plans/intentions', '{"rules": "Use will for instant decisions or uncertain plans. Use going to for intentions and planned actions.\\n- I will book that flight now.\\n- I am going to follow this itinerary.\\n- We will see if we can upgrade.\\n- We are going to reserve seats tonight.", "examples": ["I am going to book the hotel this evening.", "We will decide the route later.", "She is going to follow the itinerary closely.", "They will check prices tomorrow.", "He is going to reserve tickets online."]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 7, 'Build Sentences 1', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'I am going to book the hotel this evening', 'I am going to book the hotel this evening', '["I", "am", "going", "to", "book", "the", "hotel", "this", "evening"]'::jsonb),
    (activity_id_var, 'We will decide the route later', 'We will decide the route later', '["We", "will", "decide", "the", "route", "later"]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 8, 'Build Sentences 2', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'She is going to follow the itinerary closely', 'She is going to follow the itinerary closely', '["She", "is", "going", "to", "follow", "the", "itinerary", "closely"]'::jsonb),
    (activity_id_var, 'They will check prices tomorrow', 'They will check prices tomorrow', '["They", "will", "check", "prices", "tomorrow"]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'speaking_practice', 9, 'Talk About Travel Planning', 'Practice talking about planning trips', '{"prompts": ["How do you actually plan a trip step by step?", "When do you change plans mid-trip?", "What makes you pick one destination over another?"]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (
      lesson_id,
      activity_type,
      activity_order,
      title,
      description,
      content
    ) VALUES (
      'B1-L13',
      'speaking_improvement',
      10,
      'Speaking Improvement',
      'Read the improved version of your speech',
      '{"type": "speaking_improvement", "similarityThreshold": 70}'::jsonb
    );
END $$;


