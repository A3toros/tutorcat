-- =========================================
-- Pre-fill Database with Sample Lesson Data
-- B1-L28: Tech: Pros/Cons
-- =========================================

DELETE FROM grammar_sentences WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'B1-L28');
DELETE FROM vocabulary_items WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'B1-L28');
DELETE FROM lesson_activities WHERE lesson_id = 'B1-L28';
DELETE FROM lessons WHERE id = 'B1-L28';

INSERT INTO lessons (id, level, lesson_number, topic) VALUES
('B1-L28', 'B1', 28, 'Tech: Pros/Cons')
ON CONFLICT (id) DO UPDATE SET topic = EXCLUDED.topic;

DO $$
DECLARE
    lesson_id_var TEXT := 'B1-L28';
    activity_id_var UUID;
BEGIN
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'warm_up_speaking', 1, 'Tech Balance', 'Talk about limits with technology', '{"prompt": "At what point do you put your phone away?"}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_intro', 2, 'Tech Pros/Cons Words', 'Learn vocabulary about technology pros and cons', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'fast enough', 'เร็วพอ', NULL),
    (activity_id_var, 'too distracting', 'รบกวนสมาธิมากเกินไป', NULL),
    (activity_id_var, 'efficient', 'มีประสิทธิภาพ', NULL),
    (activity_id_var, 'reliable', 'เชื่อถือได้', NULL),
    (activity_id_var, 'secure', 'ปลอดภัย', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_matching_drag', 3, 'Match Tech Words', 'Match words with meanings', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'fast enough', 'เร็วพอ', NULL),
    (activity_id_var, 'too distracting', 'รบกวนสมาธิมากเกินไป', NULL),
    (activity_id_var, 'efficient', 'มีประสิทธิภาพ', NULL),
    (activity_id_var, 'reliable', 'เชื่อถือได้', NULL),
    (activity_id_var, 'secure', 'ปลอดภัย', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 4, 'Complete the Sentences 1', 'Fill with the correct word', '{"text": "The app is not ___. My phone is ___. This tool is very ___.", "blanks": [{"id": "blank1", "text": "fast enough", "options": ["fast enough", "too distracting", "efficient", "reliable"], "correctAnswer": "fast enough"}, {"id": "blank2", "text": "too distracting", "options": ["too distracting", "secure", "reliable", "efficient"], "correctAnswer": "too distracting"}, {"id": "blank3", "text": "efficient", "options": ["efficient", "fast enough", "secure", "reliable"], "correctAnswer": "efficient"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 5, 'Complete the Sentences 2', 'Fill with the correct word', '{"text": "Our network is ___. Is this payment method ___? The service is ___ for daily use.", "blanks": [{"id": "blank1", "text": "reliable", "options": ["reliable", "efficient", "too distracting", "secure"], "correctAnswer": "reliable"}, {"id": "blank2", "text": "secure", "options": ["secure", "fast enough", "reliable", "efficient"], "correctAnswer": "secure"}, {"id": "blank3", "text": "fast enough", "options": ["fast enough", "reliable", "secure", "too distracting"], "correctAnswer": "fast enough"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    -- Grammar Explanation: Too / Enough
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_explanation', 6, 'Too / Enough for Tech Limits', 'Use too + adjective for excess; adjective + enough for sufficiency', '{"rules": "Use too + adjective for more than needed: too distracting. Use adjective + enough for sufficiency: fast enough. Use enough + noun: enough security. Keep usage natural.\\n- The screen is too bright.\\n- The Wi-Fi is fast enough.\\n- We have enough storage.", "examples": ["This app is too distracting for study.", "The laptop is fast enough for editing.", "We have enough storage for the project.", "The system is not reliable enough yet.", "The password is secure enough for work."]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 7, 'Build Sentences 1', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'This app is too distracting for study', 'This app is too distracting for study', '["This", "app", "is", "too", "distracting", "for", "study"]'::jsonb),
    (activity_id_var, 'The laptop is fast enough for editing', 'The laptop is fast enough for editing', '["The", "laptop", "is", "fast", "enough", "for", "editing"]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 8, 'Build Sentences 2', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'We have enough storage for the project', 'We have enough storage for the project', '["We", "have", "enough", "storage", "for", "the", "project"]'::jsonb),
    (activity_id_var, 'The system is not reliable enough yet', 'The system is not reliable enough yet', '["The", "system", "is", "not", "reliable", "enough", "yet"]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'speaking_practice', 9, 'Talk About Tech Balance', 'Practice talking about tech pros and cons', '{"prompts": ["At what point do you put your phone away?", "Is 3 hours of scrolling TikTok too much for you? Why?", "Tell me about a day when tech made things worse for you."]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (
      lesson_id,
      activity_type,
      activity_order,
      title,
      description,
      content
    ) VALUES (
      'B1-L28',
      'speaking_improvement',
      10,
      'Speaking Improvement',
      'Read the improved version of your speech',
      '{"type": "speaking_improvement", "similarityThreshold": 70}'::jsonb
    );
END $$;

