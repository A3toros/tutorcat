-- =========================================
-- Pre-fill Database with Sample Lesson Data
-- B1-L35: Customer Service Experiences
-- =========================================

DELETE FROM grammar_sentences WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'B1-L35');
DELETE FROM vocabulary_items WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'B1-L35');
DELETE FROM lesson_activities WHERE lesson_id = 'B1-L35';
DELETE FROM lessons WHERE id = 'B1-L35';

INSERT INTO lessons (id, level, lesson_number, topic) VALUES
('B1-L35', 'B1', 35, 'Customer Service Experiences')
ON CONFLICT (id) DO UPDATE SET topic = EXCLUDED.topic;

DO $$
DECLARE
    lesson_id_var TEXT := 'B1-L35';
    activity_id_var UUID;
BEGIN
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'warm_up_speaking', 1, 'Service Moments', 'Talk about good and bad service', '{"prompt": "What service experience really impressed you?"}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_intro', 2, 'Service Words', 'Learn vocabulary about customer service', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'serve', 'ให้บริการ', NULL),
    (activity_id_var, 'resolve', 'แก้ไข', NULL),
    (activity_id_var, 'deliver', 'ส่งมอบ', NULL),
    (activity_id_var, 'apologize', 'ขอโทษ', NULL),
    (activity_id_var, 'refund', 'คืนเงิน', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_matching_drag', 3, 'Match Service Words', 'Match words with meanings', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'serve', 'ให้บริการ', NULL),
    (activity_id_var, 'resolve', 'แก้ไข', NULL),
    (activity_id_var, 'deliver', 'ส่งมอบ', NULL),
    (activity_id_var, 'apologize', 'ขอโทษ', NULL),
    (activity_id_var, 'refund', 'คืนเงิน', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 4, 'Complete the Sentences 1', 'Fill with the correct word', '{"text": "Staff tried to ___. They wanted to ___. They finally ___ the product.", "blanks": [{"id": "blank1", "text": "serve", "options": ["serve", "resolve", "deliver", "refund"], "correctAnswer": "serve"}, {"id": "blank2", "text": "resolve", "options": ["resolve", "apologize", "deliver", "serve"], "correctAnswer": "resolve"}, {"id": "blank3", "text": "deliver", "options": ["deliver", "refund", "serve", "resolve"], "correctAnswer": "deliver"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 5, 'Complete the Sentences 2', 'Fill with the correct word', '{"text": "They had to ___. We asked for a ___. The manager will ___ tomorrow.", "blanks": [{"id": "blank1", "text": "apologize", "options": ["apologize", "resolve", "deliver", "serve"], "correctAnswer": "apologize"}, {"id": "blank2", "text": "refund", "options": ["refund", "apologize", "resolve", "deliver"], "correctAnswer": "refund"}, {"id": "blank3", "text": "call back", "options": ["call back", "refund", "deliver", "serve"], "correctAnswer": "call back"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    -- Grammar Explanation: Passive Voice (Present) — service processes
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_explanation', 6, 'Passive Voice (Present) for Service', 'Use am/is/are + past participle to focus on actions, not actor', '{"rules": "Passive present: am/is/are + past participle. Focus on the action/result.\\n- Orders are delivered on time.\\n- Complaints are handled by support.\\nAvoid contractions; keep commas on preceding words in words_array.", "examples": ["Orders are delivered on time.", "Complaints are handled by the support team.", "Refunds are approved within a week.", "Customers are served in order.", "Damaged items are replaced quickly."]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 7, 'Build Sentences 1', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'Orders are delivered on time', 'Orders are delivered on time', '["Orders", "are", "delivered", "on", "time"]'::jsonb),
    (activity_id_var, 'Complaints are handled by the support team', 'Complaints are handled by the support team', '["Complaints", "are", "handled", "by", "the", "support", "team"]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 8, 'Build Sentences 2', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'Refunds are approved within a week', 'Refunds are approved within a week', '["Refunds", "are", "approved", "within", "a", "week"]'::jsonb),
    (activity_id_var, 'Damaged items are replaced quickly', 'Damaged items are replaced quickly', '["Damaged", "items", "are", "replaced", "quickly"]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'speaking_practice', 9, 'Talk About Service', 'Practice talking about service experiences', '{"prompts": ["What service experience really impressed you?", "How should a complaint be handled?", "Describe a fair solution you received."]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (
      lesson_id,
      activity_type,
      activity_order,
      title,
      description,
      content
    ) VALUES (
      'B1-L35',
      'speaking_improvement',
      10,
      'Speaking Improvement',
      'Read the improved version of your speech',
      '{"type": "speaking_improvement", "similarityThreshold": 70}'::jsonb
    );
END $$;

