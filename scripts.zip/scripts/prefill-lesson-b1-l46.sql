-- =========================================
-- Pre-fill Database with Sample Lesson Data
-- B1-L46: Trusting Information Online
-- =========================================

DELETE FROM grammar_sentences WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'B1-L46');
DELETE FROM vocabulary_items WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'B1-L46');
DELETE FROM lesson_activities WHERE lesson_id = 'B1-L46';
DELETE FROM lessons WHERE id = 'B1-L46';

INSERT INTO lessons (id, level, lesson_number, topic) VALUES
('B1-L46', 'B1', 46, 'Trusting Information Online')
ON CONFLICT (id) DO UPDATE SET topic = EXCLUDED.topic;

DO $$
DECLARE
    lesson_id_var TEXT := 'B1-L46';
    activity_id_var UUID;
BEGIN
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'warm_up_speaking', 1, 'Check the Source', 'Talk about deciding if posts are real', '{"prompt": "If a post feels fake, what do you do?"}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_intro', 2, 'Source Words', 'Learn vocabulary about checking online information', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'verify', 'ตรวจสอบ', NULL),
    (activity_id_var, 'source', 'แหล่งที่มา', NULL),
    (activity_id_var, 'fact-check', 'ตรวจสอบข้อเท็จจริง', NULL),
    (activity_id_var, 'claim', 'อ้าง', NULL),
    (activity_id_var, 'cite', 'อ้างอิง', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_matching_drag', 3, 'Match Source Words', 'Match words with meanings', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'verify', 'ตรวจสอบ', NULL),
    (activity_id_var, 'source', 'แหล่งที่มา', NULL),
    (activity_id_var, 'fact-check', 'ตรวจสอบข้อเท็จจริง', NULL),
    (activity_id_var, 'claim', 'อ้าง', NULL),
    (activity_id_var, 'cite', 'อ้างอิง', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 4, 'Complete the Sentences 1', 'Fill with the correct word', '{"text": "We must ___. Check the ___. The post makes a big ___.", "blanks": [{"id": "blank1", "text": "verify", "options": ["verify", "source", "claim", "cite"], "correctAnswer": "verify"}, {"id": "blank2", "text": "source", "options": ["source", "verify", "claim", "fact-check"], "correctAnswer": "source"}, {"id": "blank3", "text": "claim", "options": ["claim", "cite", "source", "verify"], "correctAnswer": "claim"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 5, 'Complete the Sentences 2', 'Fill with the correct word', '{"text": "We should ___ with trusted sites. Always ___ your data. Ask if they can ___ proof.", "blanks": [{"id": "blank1", "text": "fact-check", "options": ["fact-check", "verify", "claim", "cite"], "correctAnswer": "fact-check"}, {"id": "blank2", "text": "cite", "options": ["cite", "fact-check", "source", "verify"], "correctAnswer": "cite"}, {"id": "blank3", "text": "cite", "options": ["cite", "verify", "claim", "source"], "correctAnswer": "cite"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    -- Grammar Explanation: First Conditional (online trust)
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_explanation', 6, 'First Conditional for Online Trust', 'Use if + present, will + base verb for likely actions when checking info', '{"rules": "If + present simple, will + base verb to talk about likely actions.\\n- If a post feels fake, I will verify it.\\n- If the source is unclear, I will wait.\\nNo contractions.", "examples": ["If a post feels fake, I will verify it.", "If the source is unclear, I will check another site.", "If I cannot fact-check it, I will not share it.", "If they cite nothing, I will ignore the claim.", "If the claim is proven, I will discuss it."]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 7, 'Build Sentences 1', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'If a post feels fake I will verify it', 'If a post feels fake, I will verify it', '["If", "a", "post", "feels", "fake,", "I", "will", "verify", "it"]'::jsonb),
    (activity_id_var, 'If the source is unclear I will check another site', 'If the source is unclear, I will check another site', '["If", "the", "source", "is", "unclear,", "I", "will", "check", "another", "site"]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 8, 'Build Sentences 2', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'If I cannot fact check it I will not share it', 'If I cannot fact-check it, I will not share it', '["If", "I", "cannot", "fact-check", "it,", "I", "will", "not", "share", "it"]'::jsonb),
    (activity_id_var, 'If they cite nothing I will ignore the claim', 'If they cite nothing, I will ignore the claim', '["If", "they", "cite", "nothing,", "I", "will", "ignore", "the", "claim"]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'speaking_practice', 9, 'Talk About Online Trust', 'Practice talking about checking online information', '{"prompts": ["If a post feels fake, what do you do?", "How do you decide a source is trustworthy?", "What makes you doubt information?"]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (
      lesson_id,
      activity_type,
      activity_order,
      title,
      description,
      content
    ) VALUES (
      'B1-L46',
      'speaking_improvement',
      10,
      'Speaking Improvement',
      'Read the improved version of your speech',
      '{"type": "speaking_improvement", "similarityThreshold": 70}'::jsonb
    );
END $$;

