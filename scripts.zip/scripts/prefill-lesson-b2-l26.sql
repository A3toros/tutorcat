-- =========================================
-- Pre-fill Database with Sample Lesson Data
-- B2-L26: Cultural differences
-- =========================================

DELETE FROM grammar_sentences WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'B2-L26');
DELETE FROM vocabulary_items WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'B2-L26');
DELETE FROM lesson_activities WHERE lesson_id = 'B2-L26';
DELETE FROM lessons WHERE id = 'B2-L26';

INSERT INTO lessons (id, level, lesson_number, topic) VALUES
('B2-L26', 'B2', 26, 'Cultural differences')
ON CONFLICT (id) DO UPDATE SET topic = EXCLUDED.topic;

DO $$
DECLARE
    lesson_id_var TEXT := 'B2-L26';
    activity_id_var UUID;
BEGIN
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'warm_up_speaking', 1, 'Noticing Differences', 'Talk about surprises abroad', '{"prompt": "What difference was so big you paused, and who explained it?"}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_intro', 2, 'Culture Words', 'Key words for differences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'custom', 'ธรรมเนียม', NULL),
    (activity_id_var, 'gesture', 'ท่าทาง/ภาษากาย', NULL),
    (activity_id_var, 'norm', 'บรรทัดฐาน', NULL),
    (activity_id_var, 'adapt', 'ปรับตัว', NULL),
    (activity_id_var, 'misread', 'อ่านผิด/เข้าใจผิด', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_matching_drag', 3, 'Match Culture Words', 'Match words with meanings', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'custom', 'ธรรมเนียม', NULL),
    (activity_id_var, 'gesture', 'ท่าทาง/ภาษากาย', NULL),
    (activity_id_var, 'norm', 'บรรทัดฐาน', NULL),
    (activity_id_var, 'adapt', 'ปรับตัว', NULL),
    (activity_id_var, 'misread', 'อ่านผิด/เข้าใจผิด', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 4, 'Complete the Sentences 1', 'Fill with the correct word', '{"text": "That ___ surprised me. I didn’t want to ___ the ___.", "blanks": [{"id": "blank1", "text": "custom", "options": ["custom", "gesture", "adapt", "norm"], "correctAnswer": "custom"}, {"id": "blank2", "text": "misread", "options": ["misread", "adapt", "norm", "gesture"], "correctAnswer": "misread"}, {"id": "blank3", "text": "gesture", "options": ["gesture", "custom", "adapt", "norm"], "correctAnswer": "gesture"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 5, 'Complete the Sentences 2', 'Fill with the correct word', '{"text": "I tried to ___ fast. That is the local ___.", "blanks": [{"id": "blank1", "text": "adapt", "options": ["adapt", "norm", "gesture", "custom"], "correctAnswer": "adapt"}, {"id": "blank2", "text": "norm", "options": ["norm", "custom", "adapt", "misread"], "correctAnswer": "norm"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_explanation', 6, 'Reason & Result (so/such…that)', 'Show impact of cultural differences', '{"rules": "Use so + adj/adv + that or such + (a/an) + noun + that to show a clear result. Keep results specific.\\n- The gesture was so different that I paused.\\n- It was such a strict norm that I changed quickly.", "examples": ["The custom was so new that I asked for help.", "It was such a quiet norm that I lowered my voice.", "The gesture was so confusing that I hesitated.", "It was such a strict rule that everyone followed it.", "The difference was so big that I adapted fast."]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 7, 'Build Sentences 1', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'The custom was so new that I asked for help', 'The custom was so new that I asked for help.', '["The", "custom", "was", "so", "new", "that", "I", "asked", "for", "help."]'::jsonb),
    (activity_id_var, 'It was such a quiet norm that I lowered my voice', 'It was such a quiet norm that I lowered my voice.', '["It", "was", "such", "a", "quiet", "norm", "that", "I", "lowered", "my", "voice."]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 8, 'Build Sentences 2', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'The gesture was so confusing that I hesitated', 'The gesture was so confusing that I hesitated.', '["The", "gesture", "was", "so", "confusing", "that", "I", "hesitated."]'::jsonb),
    (activity_id_var, 'The difference was so big that I adapted fast', 'The difference was so big that I adapted fast.', '["The", "difference", "was", "so", "big", "that", "I", "adapted", "fast."]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'speaking_practice', 9, 'Talk About Differences', 'Practice cause/effect', '{"prompts": ["What difference was so big you paused?", "Who explained a gesture to you?", "When did you adapt faster than you expected?"]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (
      lesson_id,
      activity_type,
      activity_order,
      title,
      description,
      content
    ) VALUES (
      'B2-L26',
      'speaking_improvement',
      10,
      'Speaking Improvement',
      'Read the improved version of your speech',
      '{"type": "speaking_improvement", "similarityThreshold": 70}'::jsonb
    );
END $$;


