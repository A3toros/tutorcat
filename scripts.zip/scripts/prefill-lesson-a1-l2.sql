-- =========================================
-- Pre-fill Database with Sample Lesson Data
-- A1-L2: Family & Friends
-- =========================================

-- Clear existing sample data for A1-L2 (optional - comment out if you want to keep existing data)
DELETE FROM grammar_sentences WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'A1-L2');
DELETE FROM vocabulary_items WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'A1-L2');
DELETE FROM lesson_activities WHERE lesson_id = 'A1-L2';
DELETE FROM lessons WHERE id = 'A1-L2';

INSERT INTO lessons (id, level, lesson_number, topic) VALUES
('A1-L2', 'A1', 2, 'Family & Friends')
ON CONFLICT (id) DO UPDATE SET topic = EXCLUDED.topic;

DO $$
DECLARE
    lesson_id_var TEXT := 'A1-L2';
    activity_id_var UUID;
BEGIN
    -- 1. Warm-up Speaking
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content) VALUES (lesson_id_var, 'warm_up_speaking', 1, 'Talk About Family', 'Describe your family', '{"prompt": "Tell me about your family."}'::jsonb) RETURNING id INTO activity_id_var;

    -- 2. Vocabulary Introduction (5 words)
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content) VALUES (lesson_id_var, 'vocabulary_intro', 2, 'Family Words', 'Learn family vocabulary', '{}'::jsonb) RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'mother', 'แม่', NULL),
    (activity_id_var, 'father', 'พ่อ', NULL),
    (activity_id_var, 'sister', 'พี่สาว/น้องสาว', NULL),
    (activity_id_var, 'brother', 'พี่ชาย/น้องชาย', NULL),
    (activity_id_var, 'friend', 'เพื่อน', NULL);

    -- 3. Vocabulary Matching Drag #1 (5 pairs - same words)
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content) VALUES (lesson_id_var, 'vocabulary_matching_drag', 3, 'Match Family Words 1', 'Match English words (left) with Thai meanings (right)', '{}'::jsonb) RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'mother', 'แม่', NULL),
    (activity_id_var, 'father', 'พ่อ', NULL),
    (activity_id_var, 'sister', 'พี่สาว/น้องสาว', NULL),
    (activity_id_var, 'brother', 'พี่ชาย/น้องชาย', NULL),
    (activity_id_var, 'friend', 'เพื่อน', NULL);

    

    -- 4. Vocabulary Fill Blanks #1 (4 words: mother, father, sister, brother - friend left out)
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content) VALUES (lesson_id_var, 'vocabulary_fill_blanks', 4, 'Complete the Sentences 1', 'Fill in the blanks with correct words', '{"text": "My ___ is kind and cooks dinner every day. My ___ works hard at his job. I have one older ___ and one younger ___.", "blanks": [{"id": "blank1", "text": "mother", "options": ["mother", "car", "snow", "go"], "correctAnswer": "mother"}, {"id": "blank2", "text": "father", "options": ["father", "book", "water", "run"], "correctAnswer": "father"}, {"id": "blank3", "text": "sister", "options": ["sister", "table", "blue", "eat"], "correctAnswer": "sister"}, {"id": "blank4", "text": "brother", "options": ["brother", "door", "red", "sleep"], "correctAnswer": "brother"}]}'::jsonb) RETURNING id INTO activity_id_var;

    -- 5. Vocabulary Fill Blanks #2 (4 words: mother, father, sister, friend - brother left out)
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content) VALUES (lesson_id_var, 'vocabulary_fill_blanks', 5, 'Complete the Sentences 2', 'Fill in the blanks with correct words', '{"text": "I love my ___ very much. My ___ is my best ___. I have one older ___.", "blanks": [{"id": "blank1", "text": "mother", "options": ["mother", "tree", "yellow", "jump"], "correctAnswer": "mother"}, {"id": "blank2", "text": "father", "options": ["father", "chair", "green", "walk"], "correctAnswer": "father"}, {"id": "blank3", "text": "friend", "options": ["friend", "window", "black", "sing"], "correctAnswer": "friend"}, {"id": "blank4", "text": "sister", "options": ["sister", "phone", "white", "dance"], "correctAnswer": "sister"}]}'::jsonb) RETURNING id INTO activity_id_var;

    -- 4. Grammar Explanation (5 examples)
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content) VALUES (lesson_id_var, 'grammar_explanation', 6, 'Possessive Adjectives', 'Learn my, your, his, her', '{"rules": "We use possessive adjectives to show ownership:\n\n- my (ของฉัน)\n- your (ของคุณ)\n- his (ของเขา - ชาย)\n- her (ของเธอ - หญิง)\n- our (ของเรา)\n- their (ของพวกเขา)", "examples": ["My mother is kind.", "Your father works hard.", "Her brother is tall.", "Our house is big.", "Their car is red."]}'::jsonb) RETURNING id INTO activity_id_var;

    -- 4. Grammar Sentences #1
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content) VALUES (lesson_id_var, 'grammar_sentences', 7, 'Build Sentences 1', 'Arrange words to make sentences', '{}'::jsonb) RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'My mother is a teacher', 'My mother is a teacher', '["My", "mother", "is", "a", "teacher"]'::jsonb),
    (activity_id_var, 'I have two sisters', 'I have two sisters', '["I", "have", "two", "sisters"]'::jsonb);
    -- 4. Grammar Sentences #2
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content) VALUES (lesson_id_var, 'grammar_sentences', 8, 'Build Sentences 2', 'Arrange words to make sentences', '{}'::jsonb) RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'His father is a doctor', 'His father is a doctor', '["His", "father", "is", "a", "doctor"]'::jsonb),
    (activity_id_var, 'She is my best friend', 'She is my best friend', '["She", "is", "my", "best", "friend"]'::jsonb);
    -- 4. Speaking Practice (5 prompts)
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content) VALUES (lesson_id_var, 'speaking_practice', 9, 'Describe Your Family', 'Talk about your family members', '{"prompts": ["How many people are there in your family?", "What does your mother do?", "Do you have brothers or sisters?", "What does your father do?", "Who is your best friend?"]}'::jsonb) RETURNING id INTO activity_id_var;

END $$;
