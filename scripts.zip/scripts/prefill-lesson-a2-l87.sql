-- =========================================
-- Pre-fill Database with Sample Lesson Data
-- A2-L87: Family Celebrations
-- =========================================

DELETE FROM grammar_sentences WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'A2-L87');
DELETE FROM vocabulary_items WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'A2-L87');
DELETE FROM lesson_activities WHERE lesson_id = 'A2-L87';
DELETE FROM lessons WHERE id = 'A2-L87';

INSERT INTO lessons (id, level, lesson_number, topic) VALUES
('A2-L87', 'A2', 87, 'Family Celebrations')
ON CONFLICT (id) DO UPDATE SET topic = EXCLUDED.topic;

DO $$
DECLARE
    lesson_id_var TEXT := 'A2-L87';
    activity_id_var UUID;
BEGIN
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'warm_up_speaking', 1, 'Family Events', 'Talk about family celebrations', '{"prompt": "Who organizes family celebrations?"}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_intro', 2, 'Family Event Words', 'Learn family celebration words', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'family', 'ครอบครัว', NULL),
    (activity_id_var, 'cousin', 'ลูกพี่ลูกน้อง', NULL),
    (activity_id_var, 'aunt', 'ป้า/น้า/อา (หญิง)', NULL),
    (activity_id_var, 'uncle', 'ลุง/น้า/อา (ชาย)', NULL),
    (activity_id_var, 'ours', 'ของพวกเรา', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_matching_drag', 3, 'Match Family Event Words', 'Match family celebration words', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'family', 'ครอบครัว', NULL),
    (activity_id_var, 'cousin', 'ลูกพี่ลูกน้อง', NULL),
    (activity_id_var, 'aunt', 'ป้า/น้า/อา (หญิง)', NULL),
    (activity_id_var, 'uncle', 'ลุง/น้า/อา (ชาย)', NULL),
    (activity_id_var, 'ours', 'ของพวกเรา', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 4, 'Complete the Sentences 1', 'Fill with the correct word', '{"text": "My ___ cooks. My ___ visits. That house is ___.", "blanks": [{"id": "blank1", "text": "aunt", "options": ["aunt", "uncle", "cousin", "family"], "correctAnswer": "aunt"}, {"id": "blank2", "text": "uncle", "options": ["uncle", "cousin", "family", "aunt"], "correctAnswer": "uncle"}, {"id": "blank3", "text": "ours", "options": ["ours", "family", "uncle", "cousin"], "correctAnswer": "ours"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 5, 'Complete the Sentences 2', 'Fill with the correct word', '{"text": "My ___ is close to me. I love my ___.", "blanks": [{"id": "blank1", "text": "cousin", "options": ["cousin", "aunt", "uncle", "family"], "correctAnswer": "cousin"}, {"id": "blank2", "text": "family", "options": ["family", "cousin", "uncle", "aunt"], "correctAnswer": "family"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_explanation', 6, 'Object & Possessive Pronouns', 'Show belonging in the family', '{"rules": "Use object pronouns after verbs: me, you, him, her, us, them.\nUse possessive pronouns: mine, yours, his, hers, ours, theirs.\n- This house is ours. We love it.", "examples": ["I visit them every year.", "This house is ours.", "Is that seat yours?", "We invite her to dinner.", "The photos are theirs."]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 7, 'Build Sentences 1', 'Arrange words', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'This house is ours', 'This house is ours.', '["This", "house", "is", "ours."]'::jsonb),
    (activity_id_var, 'I visit them every year', 'I visit them every year.', '["I", "visit", "them", "every", "year."]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 8, 'Build Sentences 2', 'Arrange words', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'Is that seat yours', 'Is that seat yours?', '["Is", "that", "seat", "yours?"]'::jsonb),
    (activity_id_var, 'We invite her to dinner', 'We invite her to dinner.', '["We", "invite", "her", "to", "dinner."]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'speaking_practice', 9, 'Talk About Family Celebrations', 'Practice family celebration talk', '{"prompts": ["Who organizes family celebrations, and how do they do it?", "Do you help them prepare food?", "Do you share photos with relatives?", "What traditions are important to your family?", "What makes family celebrations special?"]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (
      lesson_id,
      activity_type,
      activity_order,
      title,
      description,
      content
    ) VALUES (
      'A2-L87',
      'speaking_improvement',
      10,
      'Speaking Improvement',
      'Read the improved version of your speech',
      '{"type": "speaking_improvement", "similarityThreshold": 70}'::jsonb
    );
END $$;

