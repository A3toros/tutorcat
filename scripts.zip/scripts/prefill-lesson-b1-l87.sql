-- =========================================
-- Pre-fill Database with Sample Lesson Data
-- B1-L87: Travel Mishaps
-- =========================================

DELETE FROM grammar_sentences WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'B1-L87');
DELETE FROM vocabulary_items WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'B1-L87');
DELETE FROM lesson_activities WHERE lesson_id = 'B1-L87';
DELETE FROM lessons WHERE id = 'B1-L87';

INSERT INTO lessons (id, level, lesson_number, topic) VALUES
('B1-L87', 'B1', 87, 'Travel Mishaps')
ON CONFLICT (id) DO UPDATE SET topic = EXCLUDED.topic;

DO $$
DECLARE
    lesson_id_var TEXT := 'B1-L87';
    activity_id_var UUID;
BEGIN
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'warm_up_speaking', 1, 'When Trips Fail', 'Talk about travel mishaps', '{"prompt": "What were you doing when your travel plans failed?"}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_intro', 2, 'Mishap Words', 'Learn vocabulary about travel mishaps', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'lost', 'หลงทาง', NULL),
    (activity_id_var, 'delayed', 'ล่าช้า', NULL),
    (activity_id_var, 'rerouted', 'เปลี่ยนเส้นทาง', NULL),
    (activity_id_var, 'explained', 'อธิบายแล้ว', NULL),
    (activity_id_var, 'apologized', 'ขอโทษแล้ว', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_matching_drag', 3, 'Match Mishap Words', 'Match words with meanings', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'lost', 'หลงทาง', NULL),
    (activity_id_var, 'delayed', 'ล่าช้า', NULL),
    (activity_id_var, 'rerouted', 'เปลี่ยนเส้นทาง', NULL),
    (activity_id_var, 'explained', 'อธิบายแล้ว', NULL),
    (activity_id_var, 'apologized', 'ขอโทษแล้ว', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 4, 'Complete the Sentences 1', 'Fill with the correct word', '{"text": "The flight was ___. We were ___. The driver was ___.", "blanks": [{"id": "blank1", "text": "delayed", "options": ["delayed", "lost", "rerouted", "explained"], "correctAnswer": "delayed"}, {"id": "blank2", "text": "rerouted", "options": ["rerouted", "lost", "apologized", "explained"], "correctAnswer": "rerouted"}, {"id": "blank3", "text": "lost", "options": ["lost", "explained", "apologized", "delayed"], "correctAnswer": "lost"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 5, 'Complete the Sentences 2', 'Fill with the correct word', '{"text": "Staff ___ the issue. They ___ to everyone. Bags were ___ again.", "blanks": [{"id": "blank1", "text": "explained", "options": ["explained", "apologized", "delayed", "lost"], "correctAnswer": "explained"}, {"id": "blank2", "text": "apologized", "options": ["apologized", "explained", "rerouted", "lost"], "correctAnswer": "apologized"}, {"id": "blank3", "text": "rerouted", "options": ["rerouted", "delayed", "explained", "apologized"], "correctAnswer": "rerouted"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    -- Grammar Explanation: Past Continuous + Reported Speech (light)
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_explanation', 6, 'Past Continuous and Reported Speech', 'Use was/were + verb-ing for background; report what was said', '{"rules": "Past continuous for actions in progress: was/were + verb-ing. Reported speech: said/told + that for statements.\\n- I was waiting when they said that the flight was delayed.\\nKeep tense shifts clear; no contractions.", "examples": ["I was waiting when they said that the flight was delayed.", "We were boarding when staff told us that the gate had changed.", "She was calling home when the bus was rerouted.", "They were walking when a guide said that the tour was cancelled.", "He was looking for help when the driver explained that he was lost."]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 7, 'Build Sentences 1', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'I was waiting when they said that the flight was delayed', 'I was waiting when they said that the flight was delayed', '["I", "was", "waiting", "when", "they", "said", "that", "the", "flight", "was", "delayed"]'::jsonb),
    (activity_id_var, 'We were boarding when staff told us that the gate had changed', 'We were boarding when staff told us that the gate had changed', '["We", "were", "boarding", "when", "staff", "told", "us", "that", "the", "gate", "had", "changed"]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 8, 'Build Sentences 2', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'She was calling home when the bus was rerouted', 'She was calling home when the bus was rerouted', '["She", "was", "calling", "home", "when", "the", "bus", "was", "rerouted"]'::jsonb),
    (activity_id_var, 'They were walking when a guide said that the tour was cancelled', 'They were walking when a guide said that the tour was cancelled', '["They", "were", "walking", "when", "a", "guide", "said", "that", "the", "tour", "was", "cancelled"]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'speaking_practice', 9, 'Talk About Travel Mishaps', 'Practice talking about mishaps and responses', '{"prompts": ["What were you doing when your travel plans failed?", "How did staff explain it to you?", "What lesson did you take away?"]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (
      lesson_id,
      activity_type,
      activity_order,
      title,
      description,
      content
    ) VALUES (
      'B1-L87',
      'speaking_improvement',
      10,
      'Speaking Improvement',
      'Read the improved version of your speech',
      '{"type": "speaking_improvement", "similarityThreshold": 70}'::jsonb
    );
END $$;

