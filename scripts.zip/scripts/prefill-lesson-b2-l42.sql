-- =========================================
-- Pre-fill Database with Sample Lesson Data
-- B2-L42: Peer pressure
-- =========================================

DELETE FROM grammar_sentences WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'B2-L42');
DELETE FROM vocabulary_items WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'B2-L42');
DELETE FROM lesson_activities WHERE lesson_id = 'B2-L42';
DELETE FROM lessons WHERE id = 'B2-L42';

INSERT INTO lessons (id, level, lesson_number, topic) VALUES
('B2-L42', 'B2', 42, 'Peer pressure')
ON CONFLICT (id) DO UPDATE SET topic = EXCLUDED.topic;

DO $$
DECLARE
    lesson_id_var TEXT := 'B2-L42';
    activity_id_var UUID;
BEGIN
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'warm_up_speaking', 1, 'Pressure Check', 'Talk about resisting pressure', '{"prompt": "Who helps you resist, when do you feel pushback, and how do you stay assertive?"}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_intro', 2, 'Pressure Words', 'Key words for peer pressure', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'conform', 'ทำตาม/ปรับตัวให้เหมือน', NULL),
    (activity_id_var, 'resist', 'ต้าน/ต่อต้าน', NULL),
    (activity_id_var, 'assertive', 'กล้าแสดงออก/ยืนยันสิทธิ', NULL),
    (activity_id_var, 'boundary', 'ขอบเขต', NULL),
    (activity_id_var, 'consequence', 'ผลลัพธ์/ผลกระทบ', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_matching_drag', 3, 'Match Pressure Words', 'Match words with meanings', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'conform', 'ทำตาม/ปรับตัวให้เหมือน', NULL),
    (activity_id_var, 'resist', 'ต้าน/ต่อต้าน', NULL),
    (activity_id_var, 'assertive', 'กล้าแสดงออก/ยืนยันสิทธิ', NULL),
    (activity_id_var, 'boundary', 'ขอบเขต', NULL),
    (activity_id_var, 'consequence', 'ผลลัพธ์/ผลกระทบ', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 4, 'Complete the Sentences 1', 'Fill with the correct word', '{"text": "I set a ___. I ___ when friends push. I stay ___ but kind.", "blanks": [{"id": "blank1", "text": "boundary", "options": ["boundary", "conform", "resist", "assertive"], "correctAnswer": "boundary"}, {"id": "blank2", "text": "resist", "options": ["resist", "conform", "assertive", "boundary"], "correctAnswer": "resist"}, {"id": "blank3", "text": "assertive", "options": ["assertive", "resist", "consequence", "boundary"], "correctAnswer": "assertive"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 5, 'Complete the Sentences 2', 'Fill with the correct word', '{"text": "If I just ___, the ___ might be stress.", "blanks": [{"id": "blank1", "text": "conform", "options": ["conform", "resist", "assertive", "boundary"], "correctAnswer": "conform"}, {"id": "blank2", "text": "consequence", "options": ["consequence", "boundary", "resist", "assertive"], "correctAnswer": "consequence"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_explanation', 6, 'Relative Clauses (reduced)', 'Describe peers and behaviors concisely', '{"rules": "Reduced relative clauses omit the pronoun/auxiliary when subject is same.\\n- Students facing pressure → students who are facing pressure.\\n- Friends pushing too hard → friends who push too hard.\\nUse present participle for active, past participle for passive.", "examples": ["Friends supporting you help you resist.", "Peers pushing too hard can cause stress.", "Rules shared early reduce conflict.", "Consequences explained clearly guide choices.", "Students balancing boundaries stay calmer."]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 7, 'Build Sentences 1', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'Friends supporting you help you resist', 'Friends supporting you help you resist.', '["Friends", "supporting", "you", "help", "you", "resist."]'::jsonb),
    (activity_id_var, 'Peers pushing too hard can cause stress', 'Peers pushing too hard can cause stress.', '["Peers", "pushing", "too", "hard", "can", "cause", "stress."]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 8, 'Build Sentences 2', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'Rules shared early reduce conflict', 'Rules shared early reduce conflict.', '["Rules", "shared", "early", "reduce", "conflict."]'::jsonb),
    (activity_id_var, 'Consequences explained clearly guide choices', 'Consequences explained clearly guide choices.', '["Consequences", "explained", "clearly", "guide", "choices."]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'speaking_practice', 9, 'Talk About Peer Pressure', 'Practice reduced relatives', '{"prompts": ["Who helps you resist?", "When do you feel pushback?", "What boundary do you keep even if others conform?"]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (
      lesson_id,
      activity_type,
      activity_order,
      title,
      description,
      content
    ) VALUES (
      'B2-L42',
      'speaking_improvement',
      10,
      'Speaking Improvement',
      'Read the improved version of your speech',
      '{"type": "speaking_improvement", "similarityThreshold": 70}'::jsonb
    );
END $$;


