#!/usr/bin/env python3
"""
Convert lesson SQL files from DELETE+INSERT to safe UPSERT approach
This preserves student data when updating lessons
"""

import re
from pathlib import Path

script_dir = Path(__file__).parent

# List of all lesson SQL files
lesson_files = [
    f"prefill-lesson-{level}-l{num}.sql"
    for level in ['a1', 'a2', 'b1', 'b2', 'c1', 'c2']
    for num in range(1, 11)
]

def convert_lesson_file(file_path):
    """Convert a single lesson file from DELETE to UPSERT"""
    if not file_path.exists():
        print(f"  [SKIP] File not found: {file_path.name}")
        return False
    
    with open(file_path, 'r', encoding='utf-8') as f:
        content = f.read()
    
    original_content = content
    lesson_id = None
    
    # Extract lesson_id from the file
    lesson_id_match = re.search(r"lesson_id_var TEXT := '([A-Z0-9-]+)'", content)
    if lesson_id_match:
        lesson_id = lesson_id_match.group(1)
    else:
        # Try to find it in DELETE statements
        lesson_id_match = re.search(r"DELETE FROM lessons WHERE id = '([A-Z0-9-]+)'", content)
        if lesson_id_match:
            lesson_id = lesson_id_match.group(1)
    
    if not lesson_id:
        print(f"  [ERROR] Could not find lesson_id in {file_path.name}")
        return False
    
    # Replace DELETE FROM lessons with UPSERT
    content = re.sub(
        r"DELETE FROM lessons WHERE id = '([A-Z0-9-]+)';",
        lambda m: f"-- Lesson metadata will be updated via UPSERT below",
        content
    )
    
    # Replace INSERT INTO lessons with UPSERT
    content = re.sub(
        r"INSERT INTO lessons \(id, level, lesson_number, topic\) VALUES\s*\('([A-Z0-9-]+)',\s*'([A-Z0-9-]+)',\s*(\d+),\s*'([^']+)'\)\s*ON CONFLICT \(id\) DO UPDATE SET topic = EXCLUDED\.topic;",
        lambda m: f"INSERT INTO lessons (id, level, lesson_number, topic, updated_at) VALUES ('{m.group(1)}', '{m.group(2)}', {m.group(3)}, '{m.group(4)}', NOW()) ON CONFLICT (id) DO UPDATE SET level = EXCLUDED.level, lesson_number = EXCLUDED.lesson_number, topic = EXCLUDED.topic, updated_at = NOW();",
        content
    )
    
    # Remove DELETE statements for dependent tables (but keep comments)
    # We'll handle these more carefully - only delete if no student data exists
    content = re.sub(
        r"DELETE FROM grammar_sentences WHERE activity_id IN \(SELECT id FROM lesson_activities WHERE lesson_id = '([A-Z0-9-]+)'\);",
        lambda m: f"-- Grammar sentences will be updated (preserving those with student data)",
        content
    )
    
    content = re.sub(
        r"DELETE FROM vocabulary_items WHERE activity_id IN \(SELECT id FROM lesson_activities WHERE lesson_id = '([A-Z0-9-]+)'\);",
        lambda m: f"-- Vocabulary items will be updated (preserving those with student data)",
        content
    )
    
    content = re.sub(
        r"DELETE FROM lesson_activities WHERE lesson_id = '([A-Z0-9-]+)';",
        lambda m: f"-- Lesson activities will be updated via UPSERT (preserving those with student data)",
        content
    )
    
    # Add warning comment at the top
    warning = f"""-- =========================================
-- IMPORTANT: This script uses UPSERT to preserve student data
-- Student results (lesson_activity_results) will NOT be deleted
-- Only lesson content will be updated
-- =========================================

"""
    
    # Only add warning if content changed
    if content != original_content:
        # Check if warning already exists
        if "IMPORTANT: This script uses UPSERT" not in content:
            content = warning + content
    
    # Write to new file with -safe suffix
    safe_file = file_path.parent / f"{file_path.stem}-safe.sql"
    with open(safe_file, 'w', encoding='utf-8') as f:
        f.write(content)
    
    return True

def main():
    print("=" * 60)
    print("Converting Lesson SQL Files to Safe Update Format")
    print("=" * 60)
    print()
    print("This will create new files with '-safe.sql' suffix")
    print("that use UPSERT instead of DELETE to preserve student data.")
    print()
    
    success_count = 0
    error_count = 0
    
    for lesson_file in lesson_files:
        file_path = script_dir / lesson_file
        print(f"Processing: {lesson_file}...", end=" ")
        
        if convert_lesson_file(file_path):
            print("[OK]")
            success_count += 1
        else:
            print("[ERROR]")
            error_count += 1
    
    print()
    print("=" * 60)
    print("Summary")
    print("=" * 60)
    print(f"Total files: {len(lesson_files)}")
    print(f"Successfully converted: {success_count}")
    print(f"Errors: {error_count}")
    print()
    print("Next steps:")
    print("1. Review the generated '-safe.sql' files")
    print("2. Test on a development database with sample student data")
    print("3. Once verified, replace original files or use safe versions")
    print()
    print("Note: The safe versions preserve student data but may need")
    print("additional logic for handling removed activities/items.")

if __name__ == "__main__":
    main()

