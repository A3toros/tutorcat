-- =========================================
-- Pre-fill Database with Sample Lesson Data
-- B2-L34: Budgeting basics
-- =========================================

DELETE FROM grammar_sentences WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'B2-L34');
DELETE FROM vocabulary_items WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'B2-L34');
DELETE FROM lesson_activities WHERE lesson_id = 'B2-L34';
DELETE FROM lessons WHERE id = 'B2-L34';

INSERT INTO lessons (id, level, lesson_number, topic) VALUES
('B2-L34', 'B2', 34, 'Budgeting basics')
ON CONFLICT (id) DO UPDATE SET topic = EXCLUDED.topic;

DO $$
DECLARE
    lesson_id_var TEXT := 'B2-L34';
    activity_id_var UUID;
BEGIN
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'warm_up_speaking', 1, 'Budget Tweaks', 'Talk about tracking habits', '{"prompt": "How long have you tracked spending, and what do you tweak?"}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_intro', 2, 'Budget Words', 'Key words for budgeting', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'allocate', 'จัดสรร', NULL),
    (activity_id_var, 'fixed', 'คงที่', NULL),
    (activity_id_var, 'variable', 'ผันแปร', NULL),
    (activity_id_var, 'cushion', 'เงินสำรอง/กันชน', NULL),
    (activity_id_var, 'overspend', 'ใช้จ่ายเกิน', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_matching_drag', 3, 'Match Budget Words', 'Match words with meanings', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'allocate', 'จัดสรร', NULL),
    (activity_id_var, 'fixed', 'คงที่', NULL),
    (activity_id_var, 'variable', 'ผันแปร', NULL),
    (activity_id_var, 'cushion', 'เงินสำรอง/กันชน', NULL),
    (activity_id_var, 'overspend', 'ใช้จ่ายเกิน', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 4, 'Complete the Sentences 1', 'Fill with the correct word', '{"text": "I ___ cash for bills. I track ___ costs. I keep a small ___.", "blanks": [{"id": "blank1", "text": "allocate", "options": ["allocate", "fixed", "variable", "cushion"], "correctAnswer": "allocate"}, {"id": "blank2", "text": "fixed", "options": ["fixed", "variable", "cushion", "overspend"], "correctAnswer": "fixed"}, {"id": "blank3", "text": "cushion", "options": ["cushion", "variable", "allocate", "fixed"], "correctAnswer": "cushion"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 5, 'Complete the Sentences 2', 'Fill with the correct word', '{"text": "Food is a ___ cost. I try not to ___.", "blanks": [{"id": "blank1", "text": "variable", "options": ["variable", "fixed", "allocate", "cushion"], "correctAnswer": "variable"}, {"id": "blank2", "text": "overspend", "options": ["overspend", "cushion", "variable", "fixed"], "correctAnswer": "overspend"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_explanation', 6, 'Present Perfect Continuous', 'Show ongoing budgeting actions', '{"rules": "Use have/has + been + -ing for actions that started in the past and continue now, often with for/since.\\n- I have been tracking spending for months.\\n- She has been allocating a cushion each week.", "examples": ["I have been logging every receipt this term.", "She has been allocating a cushion since January.", "They have been watching variable costs closely.", "We have been adjusting fixed costs where possible.", "He has been avoiding overspending on weekends."]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 7, 'Build Sentences 1', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'I have been logging every receipt this term', 'I have been logging every receipt this term.', '["I", "have", "been", "logging", "every", "receipt", "this", "term."]'::jsonb),
    (activity_id_var, 'She has been allocating a cushion since January', 'She has been allocating a cushion since January.', '["She", "has", "been", "allocating", "a", "cushion", "since", "January."]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 8, 'Build Sentences 2', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'They have been watching variable costs closely', 'They have been watching variable costs closely.', '["They", "have", "been", "watching", "variable", "costs", "closely."]'::jsonb),
    (activity_id_var, 'He has been avoiding overspending on weekends', 'He has been avoiding overspending on weekends.', '["He", "has", "been", "avoiding", "overspending", "on", "weekends."]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'speaking_practice', 9, 'Talk About Budgeting', 'Practice present perfect continuous', '{"prompts": ["How long have you tracked spending?", "What have you tweaked recently?", "Where have you been overspending?" ]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (
      lesson_id,
      activity_type,
      activity_order,
      title,
      description,
      content
    ) VALUES (
      'B2-L34',
      'speaking_improvement',
      10,
      'Speaking Improvement',
      'Read the improved version of your speech',
      '{"type": "speaking_improvement", "similarityThreshold": 70}'::jsonb
    );
END $$;


