-- =========================================
-- Pre-fill Database with Sample Lesson Data
-- A2-L37: Holiday Traditions
-- =========================================

DELETE FROM grammar_sentences WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'A2-L37');
DELETE FROM vocabulary_items WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'A2-L37');
DELETE FROM lesson_activities WHERE lesson_id = 'A2-L37';
DELETE FROM lessons WHERE id = 'A2-L37';

INSERT INTO lessons (id, level, lesson_number, topic) VALUES
('A2-L37', 'A2', 37, 'Holiday Traditions')
ON CONFLICT (id) DO UPDATE SET topic = EXCLUDED.topic;

DO $$
DECLARE
    lesson_id_var TEXT := 'A2-L37';
    activity_id_var UUID;
BEGIN
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'warm_up_speaking', 1, 'Holidays', 'Talk about holidays you enjoy', '{"prompt": "What holiday do you enjoy most?"}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_intro', 2, 'Holiday Words', 'Learn holiday tradition words', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'holiday', 'วันหยุด', NULL),
    (activity_id_var, 'parade', 'ขบวนพาเหรด', NULL),
    (activity_id_var, 'flag', 'ธง', NULL),
    (activity_id_var, 'day off', 'วันหยุดพัก', NULL),
    (activity_id_var, 'celebrate', 'ฉลอง', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_matching_drag', 3, 'Match Holiday Words', 'Match holiday words', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'holiday', 'วันหยุด', NULL),
    (activity_id_var, 'parade', 'ขบวนพาเหรด', NULL),
    (activity_id_var, 'flag', 'ธง', NULL),
    (activity_id_var, 'day off', 'วันหยุดพัก', NULL),
    (activity_id_var, 'celebrate', 'ฉลอง', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 4, 'Complete the Sentences 1', 'Fill with the correct word', '{"text": "We have a ___ on Monday. People carry the ___. Families ___ together.", "blanks": [{"id": "blank1", "text": "day off", "options": ["day off", "flag", "parade", "celebrate"], "correctAnswer": "day off"}, {"id": "blank2", "text": "flag", "options": ["flag", "parade", "holiday", "celebrate"], "correctAnswer": "flag"}, {"id": "blank3", "text": "celebrate", "options": ["celebrate", "flag", "parade", "holiday"], "correctAnswer": "celebrate"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 5, 'Complete the Sentences 2', 'Fill with the correct word', '{"text": "The city has a big ___. We watch with our ___. It is my favorite ___.", "blanks": [{"id": "blank1", "text": "parade", "options": ["parade", "holiday", "flag", "day off"], "correctAnswer": "parade"}, {"id": "blank2", "text": "family", "options": ["family", "parade", "holiday", "flag"], "correctAnswer": "family"}, {"id": "blank3", "text": "holiday", "options": ["holiday", "parade", "flag", "day off"], "correctAnswer": "holiday"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_explanation', 6, 'Present Simple (habits)', 'Talk about regular holiday habits', '{"rules": "Use present simple for habits and facts.\n- We celebrate every year.\n- The parade starts at nine.\nQuestions: Do you celebrate this holiday?\nNegatives: don''t/doesn''t + verb.", "examples": ["We celebrate every year.", "The parade starts at nine.", "Do you watch the parade?", "We don''t work on this day.", "She cooks special food."]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 7, 'Build Sentences 1', 'Arrange words', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'We celebrate every year', 'We celebrate every year.', '["We", "celebrate", "every", "year."]'::jsonb),
    (activity_id_var, 'The parade starts at nine', 'The parade starts at nine.', '["The", "parade", "starts", "at", "nine."]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 8, 'Build Sentences 2', 'Arrange words', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'Do you watch the parade', 'Do you watch the parade?', '["Do", "you", "watch", "the", "parade?"]'::jsonb),
    (activity_id_var, 'We don t work on this day', 'We don''t work on this day.', '["We", "don''t", "work", "on", "this", "day."]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'speaking_practice', 9, 'Talk About Holidays', 'Practice holiday traditions', '{"prompts": ["What holiday do you enjoy most?", "What do people usually do on that day?", "Do you get time off work or school?", "What food do people usually eat?", "Who do you celebrate with?"]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (
      lesson_id,
      activity_type,
      activity_order,
      title,
      description,
      content
    ) VALUES (
      'A2-L37',
      'speaking_improvement',
      10,
      'Speaking Improvement',
      'Read the improved version of your speech',
      '{"type": "speaking_improvement", "similarityThreshold": 70}'::jsonb
    );
END $$;

