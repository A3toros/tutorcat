-- =========================================
-- Pre-fill Database with Sample Lesson Data
-- A1-L67: School Subjects
-- =========================================

DELETE FROM grammar_sentences WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'A1-L67');
DELETE FROM vocabulary_items WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'A1-L67');
DELETE FROM lesson_activities WHERE lesson_id = 'A1-L67');
DELETE FROM lessons WHERE id = 'A1-L67';

INSERT INTO lessons (id, level, lesson_number, topic) VALUES
('A1-L67', 'A1', 67, 'School Subjects')
ON CONFLICT (id) DO UPDATE SET topic = EXCLUDED.topic;

DO $$
DECLARE
    lesson_id_var TEXT := 'A1-L67';
    activity_id_var UUID;
BEGIN
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'warm_up_speaking', 1, 'Subjects', 'Talk about school subjects', '{"prompt": "Do you like math?"}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_intro', 2, 'Subject Words', 'Learn subject words', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'math', 'คณิตศาสตร์', NULL),
    (activity_id_var, 'English', 'ภาษาอังกฤษ', NULL),
    (activity_id_var, 'art', 'ศิลปะ', NULL),
    (activity_id_var, 'music', 'ดนตรี', NULL),
    (activity_id_var, 'sport', 'กีฬา', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_matching_drag', 3, 'Match Subject Words', 'Match subject words', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'math', 'คณิตศาสตร์', NULL),
    (activity_id_var, 'English', 'ภาษาอังกฤษ', NULL),
    (activity_id_var, 'art', 'ศิลปะ', NULL),
    (activity_id_var, 'music', 'ดนตรี', NULL),
    (activity_id_var, 'sport', 'กีฬา', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 4, 'Complete the Sentences 1', 'Fill with the correct word', '{"text": "I like ___. I like ___.", "blanks": [{"id": "blank1", "text": "math", "options": ["math", "English", "art", "music"], "correctAnswer": "math"}, {"id": "blank2", "text": "English", "options": ["English", "sport", "music", "math"], "correctAnswer": "English"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 5, 'Complete the Sentences 2', 'Fill with the correct word', '{"text": "I like ___. I do not like ___.", "blanks": [{"id": "blank1", "text": "art", "options": ["art", "music", "sport", "math"], "correctAnswer": "art"}, {"id": "blank2", "text": "sport", "options": ["sport", "math", "English", "art"], "correctAnswer": "sport"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_explanation', 6, 'Like / Don’t Like', 'Talk about subjects you like', '{"rules": "Use like/don''t like + subject.\n- I like math.\n- I don''t like sport.\nAsk: Do you like art?", "examples": ["I like math.", "I like English.", "I don''t like sport.", "Do you like art?", "Do you like music?"]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 7, 'Build Sentences 1', 'Arrange words', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'I like math', 'I like math.', '["I", "like", "math."]'::jsonb),
    (activity_id_var, 'I don t like sport', 'I don''t like sport.', '["I", "don''t", "like", "sport."]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 8, 'Build Sentences 2', 'Arrange words', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'Do you like art', 'Do you like art?', '["Do", "you", "like", "art?"]'::jsonb),
    (activity_id_var, 'Do you like music', 'Do you like music?', '["Do", "you", "like", "music?"]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'speaking_practice', 9, 'Talk About Subjects', 'Practice subject likes', '{"prompts": ["Do you like math?", "Do you like English?", "Do you like art?", "Do you like music?", "Do you like sport?"]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (
      lesson_id,
      activity_type,
      activity_order,
      title,
      description,
      content
    ) VALUES (
      'A1-L67',
      'speaking_improvement',
      10,
      'Speaking Improvement',
      'Read the improved version of your speech',
      '{"type": "speaking_improvement", "similarityThreshold": 70}'::jsonb
    );
END $$;

