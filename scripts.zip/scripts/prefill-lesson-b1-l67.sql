-- ===== LESSON B1-L67 =====

-- =========================================
-- Pre-fill Database with Sample Lesson Data
-- B1-L67: Language Learning & Barriers
-- =========================================

DELETE FROM lesson_activity_results WHERE lesson_id = 'B1-L67';
DELETE FROM user_progress WHERE lesson_id = 'B1-L67';
DELETE FROM lesson_history WHERE lesson_id = 'B1-L67';
DELETE FROM grammar_sentences WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'B1-L67');
DELETE FROM vocabulary_items WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'B1-L67');
DELETE FROM lesson_activities WHERE lesson_id = 'B1-L67';
DELETE FROM lessons WHERE id = 'B1-L67';

INSERT INTO lessons (id, level, lesson_number, topic) VALUES
('B1-L67', 'B1', 67, 'Language Learning & Barriers')
ON CONFLICT (id) DO UPDATE SET topic = EXCLUDED.topic;

DO $$
DECLARE
    lesson_id_var TEXT := 'B1-L67';
    activity_id_var UUID;
BEGIN
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'warm_up_speaking', 1, 'Language Challenges', 'Talk about overcoming language barriers', '{"prompt": "How do you repeat instructions for friends?"}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_intro', 2, 'Communication Words', 'Learn words related to language barriers', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'explain', 'อธิบาย', NULL),
    (activity_id_var, 'repeat', 'ทำซ้ำ', NULL),
    (activity_id_var, 'clarify', 'ชี้แจง', NULL),
    (activity_id_var, 'translate', 'แปล', NULL),
    (activity_id_var, 'interpret', 'ตีความ', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_matching_drag', 3, 'Match Communication Words', 'Match language barrier words', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'explain', 'อธิบาย', NULL),
    (activity_id_var, 'repeat', 'ทำซ้ำ', NULL),
    (activity_id_var, 'clarify', 'ชี้แจง', NULL),
    (activity_id_var, 'translate', 'แปล', NULL),
    (activity_id_var, 'interpret', 'ตีความ', NULL);

    -- 4. Vocabulary Fill Blanks #1
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 4, 'Complete the Sentences 1', 'Fill in the blanks with correct words', '{"text": "Can you ___ this for me? Please ___ what you said. I need to ___ the meaning.", "blanks": [{"id": "blank1", "text": "explain", "options": ["explain", "repeat", "clarify", "translate"], "correctAnswer": "explain"}, {"id": "blank2", "text": "repeat", "options": ["repeat", "explain", "clarify", "translate"], "correctAnswer": "repeat"}, {"id": "blank3", "text": "clarify", "options": ["clarify", "explain", "repeat", "translate"], "correctAnswer": "clarify"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    -- 5. Vocabulary Fill Blanks #2
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 5, 'Complete the Sentences 2', 'Fill in the blanks with correct words', '{"text": "I can ___ this text. She helps to ___ between languages. They ___ the message.", "blanks": [{"id": "blank1", "text": "translate", "options": ["translate", "explain", "repeat", "clarify"], "correctAnswer": "translate"}, {"id": "blank2", "text": "interpret", "options": ["interpret", "translate", "explain", "repeat"], "correctAnswer": "interpret"}, {"id": "blank3", "text": "interpret", "options": ["interpret", "translate", "explain", "clarify"], "correctAnswer": "interpret"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    -- 6. Grammar Explanation
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_explanation', 6, 'Reported Speech for Communication', 'Learn reporting what others said', '{"rules": "Use reported speech to tell what someone said:\n\n- Change pronouns (I → she, my → her)\n- Change tenses (need → needed, is → was)\n- Use that after said/told (She said that...)\n- Change word order in questions (Where is → where...was)\n- Use asked for questions, said/told for statements", "examples": ["She said that she needed help.", "He asked where the station was.", "They explained that I should turn left.", "I told him that I understood.", "She asked if I spoke English."]}'::jsonb)
    RETURNING id INTO activity_id_var;

    -- 7. Grammar Sentences #1
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 7, 'Build Sentences 1', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'She said that she needed help', 'She said that she needed help.', '["She", "said", "that", "she", "needed", "help."]'::jsonb),
    (activity_id_var, 'He asked where the station was', 'He asked where the station was.', '["He", "asked", "where", "the", "station", "was."]'::jsonb);

    -- 8. Grammar Sentences #2
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 8, 'Build Sentences 2', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'They explained that I should turn left', 'They explained that I should turn left.', '["They", "explained", "that", "I", "should", "turn", "left."]'::jsonb),
    (activity_id_var, 'I told him that I understood', 'I told him that I understood.', '["I", "told", "him", "that", "I", "understood."]'::jsonb);

    -- 9. Speaking Practice
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'speaking_practice', 9, 'Talk About Languages', 'Practice talking about speaking other languages', '{"prompts": ["Can you speak English?", "What language does your family speak?", "Do you learn Chinese at school?", "How do you practice speaking English?", "Have you ever needed a translator?"]}'::jsonb)
    RETURNING id INTO activity_id_var;

    -- 10. Speaking Improvement
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'speaking_improvement', 10, 'Speaking Improvement', 'Read the improved version of your speech', '{"type": "speaking_improvement", "similarityThreshold": 70}'::jsonb)
    RETURNING id INTO activity_id_var;
END $$;