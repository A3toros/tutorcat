-- =========================================
-- Pre-fill Database with Sample Lesson Data
-- B1-L44: Sleep & Energy
-- =========================================

DELETE FROM grammar_sentences WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'B1-L44');
DELETE FROM vocabulary_items WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'B1-L44');
DELETE FROM lesson_activities WHERE lesson_id = 'B1-L44';
DELETE FROM lessons WHERE id = 'B1-L44';

INSERT INTO lessons (id, level, lesson_number, topic) VALUES
('B1-L44', 'B1', 44, 'Sleep & Energy')
ON CONFLICT (id) DO UPDATE SET topic = EXCLUDED.topic;

DO $$
DECLARE
    lesson_id_var TEXT := 'B1-L44';
    activity_id_var UUID;
BEGIN
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'warm_up_speaking', 1, 'Sleep Habits', 'Talk about how sleep affects your day', '{"prompt": "What happens to you if you sleep too little?"}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_intro', 2, 'Sleep & Energy Words', 'Learn vocabulary about sleep and energy', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'rest', 'พักผ่อน', NULL),
    (activity_id_var, 'nap', 'งีบ', NULL),
    (activity_id_var, 'caffeine', 'คาเฟอีน', NULL),
    (activity_id_var, 'routine', 'กิจวัตร', NULL),
    (activity_id_var, 'alert', 'ตื่นตัว', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_matching_drag', 3, 'Match Sleep Words', 'Match words with meanings', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'rest', 'พักผ่อน', NULL),
    (activity_id_var, 'nap', 'งีบ', NULL),
    (activity_id_var, 'caffeine', 'คาเฟอีน', NULL),
    (activity_id_var, 'routine', 'กิจวัตร', NULL),
    (activity_id_var, 'alert', 'ตื่นตัว', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 4, 'Complete the Sentences 1', 'Fill with the correct word', '{"text": "I need more ___. A short ___ helps. Too much ___ keeps me awake.", "blanks": [{"id": "blank1", "text": "rest", "options": ["rest", "nap", "caffeine", "routine"], "correctAnswer": "rest"}, {"id": "blank2", "text": "nap", "options": ["nap", "rest", "routine", "alert"], "correctAnswer": "nap"}, {"id": "blank3", "text": "caffeine", "options": ["caffeine", "rest", "nap", "alert"], "correctAnswer": "caffeine"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 5, 'Complete the Sentences 2', 'Fill with the correct word', '{"text": "A steady ___ helps. I feel ___ after lunch. Good sleep keeps me ___.", "blanks": [{"id": "blank1", "text": "routine", "options": ["routine", "nap", "rest", "caffeine"], "correctAnswer": "routine"}, {"id": "blank2", "text": "sleepy", "options": ["sleepy", "alert", "rest", "nap"], "correctAnswer": "sleepy"}, {"id": "blank3", "text": "alert", "options": ["alert", "sleepy", "routine", "rest"], "correctAnswer": "alert"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    -- Grammar Explanation: Zero Conditional (sleep effects)
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_explanation', 6, 'Zero Conditional for Sleep Effects', 'Use if + present, present to describe general results', '{"rules": "Zero conditional: If + present simple, present simple for general truths.\\n- If I sleep too little, I feel weak.\\n- If I nap, I recover energy.\\nNo contractions.", "examples": ["If I sleep too little, I feel weak.", "If I drink coffee late, I stay awake.", "If I nap at noon, I feel alert later.", "If I keep a routine, I wake up on time.", "If I exercise, I sleep better."]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 7, 'Build Sentences 1', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'If I sleep too little I feel weak', 'If I sleep too little, I feel weak', '["If", "I", "sleep", "too", "little,", "I", "feel", "weak"]'::jsonb),
    (activity_id_var, 'If I drink coffee late I stay awake', 'If I drink coffee late, I stay awake', '["If", "I", "drink", "coffee", "late,", "I", "stay", "awake"]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 8, 'Build Sentences 2', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'If I nap at noon I feel alert later', 'If I nap at noon, I feel alert later', '["If", "I", "nap", "at", "noon,", "I", "feel", "alert", "later"]'::jsonb),
    (activity_id_var, 'If I keep a routine I wake up on time', 'If I keep a routine, I wake up on time', '["If", "I", "keep", "a", "routine,", "I", "wake", "up", "on", "time"]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'speaking_practice', 9, 'Talk About Sleep & Energy', 'Practice talking about sleep and daily energy', '{"prompts": ["What happens to you if you sleep too little?", "What keeps you awake on a rough day?", "Describe a daily routine that really works for you."]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (
      lesson_id,
      activity_type,
      activity_order,
      title,
      description,
      content
    ) VALUES (
      'B1-L44',
      'speaking_improvement',
      10,
      'Speaking Improvement',
      'Read the improved version of your speech',
      '{"type": "speaking_improvement", "similarityThreshold": 70}'::jsonb
    );
END $$;

