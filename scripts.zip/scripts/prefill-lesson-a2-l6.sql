-- =========================================
-- Pre-fill Database with Sample Lesson Data
-- A2-L6: Holidays & Celebrations
-- =========================================

-- Clear existing sample data for A2-L6 (optional - comment out if you want to keep existing data)
DELETE FROM grammar_sentences WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'A2-L6');
DELETE FROM vocabulary_items WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'A2-L6');
DELETE FROM lesson_activities WHERE lesson_id = 'A2-L6';
DELETE FROM lessons WHERE id = 'A2-L6';

INSERT INTO lessons (id, level, lesson_number, topic) VALUES
('A2-L6', 'A2', 6, 'Holidays & Celebrations')
ON CONFLICT (id) DO UPDATE SET topic = EXCLUDED.topic;

DO $$
DECLARE
    lesson_id_var TEXT := 'A2-L6';
    activity_id_var UUID;
BEGIN
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content) VALUES (lesson_id_var, 'warm_up_speaking', 1, 'Celebration Talk', 'Talk about holidays', '{"prompt": "What holidays do you celebrate each year?"}'::jsonb) RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content) VALUES (lesson_id_var, 'vocabulary_intro', 2, 'Holiday Words', 'Learn holiday vocabulary', '{}'::jsonb) RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'party', 'งานเลี้ยง', NULL),
    (activity_id_var, 'cake', 'เค้ก', NULL),
    (activity_id_var, 'present', 'ของขวัญ', NULL),
    (activity_id_var, 'celebrate', 'ฉลอง', NULL),
    (activity_id_var, 'tradition', 'ประเพณี', NULL);

    -- 3. Vocabulary Matching Drag #1 (5 pairs - same words)
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content) VALUES (lesson_id_var, 'vocabulary_matching_drag', 3, 'Match Holiday 1', 'Match English words with Thai meanings', '{}'::jsonb) RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'party', 'งานเลี้ยง', NULL),
    (activity_id_var, 'cake', 'เค้ก', NULL),
    (activity_id_var, 'present', 'ของขวัญ', NULL),
    (activity_id_var, 'celebrate', 'ฉลอง', NULL),
    (activity_id_var, 'tradition', 'ประเพณี', NULL);


    -- 4. Vocabulary Fill Blanks #1 (4 words: party, cake, present, celebrate - tradition left out)
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content) VALUES (lesson_id_var, 'vocabulary_fill_blanks', 4, 'Complete the Sentences 1', 'Fill in the blanks with correct words', '{"text": "We have a birthday ___. I eat chocolate ___. I give my friend a ___. We ___ New Year together.", "blanks": [{"id": "blank1", "text": "party", "options": ["party", "cake", "present", "celebrate"], "correctAnswer": "party"}, {"id": "blank2", "text": "cake", "options": ["party", "cake", "present", "celebrate"], "correctAnswer": "cake"}, {"id": "blank3", "text": "present", "options": ["party", "cake", "present", "celebrate"], "correctAnswer": "present"}, {"id": "blank4", "text": "celebrate", "options": ["party", "cake", "present", "celebrate"], "correctAnswer": "celebrate"}]}'::jsonb) RETURNING id INTO activity_id_var;

    -- 4. Vocabulary Fill Blanks #2 (4 words: party, cake, present, tradition - celebrate left out)
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content) VALUES (lesson_id_var, 'vocabulary_fill_blanks', 5, 'Complete the Sentences 2', 'Fill in the blanks with correct words', '{"text": "The birthday ___ is fun. We eat a big ___. I open my ___. It is a family ___ to eat together.", "blanks": [{"id": "blank1", "text": "party", "options": ["party", "cake", "present", "tradition"], "correctAnswer": "party"}, {"id": "blank2", "text": "cake", "options": ["party", "cake", "present", "tradition"], "correctAnswer": "cake"}, {"id": "blank3", "text": "present", "options": ["party", "cake", "present", "tradition"], "correctAnswer": "present"}, {"id": "blank4", "text": "tradition", "options": ["party", "cake", "present", "tradition"], "correctAnswer": "tradition"}]}'::jsonb) RETURNING id INTO activity_id_var;

    -- 4. Grammar Explanation (5 examples - CEFR A2: Future with going to)
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content) VALUES (lesson_id_var, 'grammar_explanation', 6, 'Future Plans - Holidays', 'Learn to talk about future celebrations', '{"rules": "Use ''going to'' for future plans:\n\n- I am going to + verb (I am going to celebrate)\n- We are going to + verb (We are going to have a party)\n- Questions: Are you going to...? (Are you going to come?)\n- Negative: I''m not going to... (I''m not going to eat cake)\n- Time expressions: tomorrow, next week, next month", "examples": ["I am going to celebrate my birthday.", "We are going to have a party next week.", "Are you going to bring a present?", "She is not going to eat chocolate cake.", "They are going to visit family tomorrow."]}'::jsonb) RETURNING id INTO activity_id_var;
    -- 4. Grammar Sentences #1
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content) VALUES (lesson_id_var, 'grammar_sentences', 7, 'Build Sentences 1', 'Arrange words to make sentences', '{}'::jsonb) RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'I am going to celebrate my birthday', 'I am going to celebrate my birthday', '["I", "am", "going", "to", "celebrate", "my", "birthday"]'::jsonb),
    (activity_id_var, 'We are going to have a party next week', 'We are going to have a party next week', '["We", "are", "going", "to", "have", "a", "party", "next", "week"]'::jsonb);
    -- 4. Grammar Sentences #2
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content) VALUES (lesson_id_var, 'grammar_sentences', 8, 'Build Sentences 2', 'Arrange words to make sentences', '{}'::jsonb) RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'Are you going to bring a present', 'Are you going to bring a present?', '["Are", "you", "going", "to", "bring", "a", "present?"]'::jsonb),
    (activity_id_var, 'She is not going to eat chocolate cake', 'She is not going to eat chocolate cake', '["She", "is", "not", "going", "to", "eat", "chocolate", "cake"]'::jsonb);
    -- 4. Speaking Practice (5 prompts - CEFR A2: Holidays and celebrations)
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content) VALUES (lesson_id_var, 'speaking_practice', 9, 'Talk About Celebrations', 'Practice talking about holidays', '{"prompts": ["What is your favorite holiday?", "Are you going to have a birthday party this year?", "Do you give presents to friends or family?", "What traditions do you follow during holidays?", "What are you going to eat for New Year or a festival?"]}'::jsonb) RETURNING id INTO activity_id_var;

END $$;
