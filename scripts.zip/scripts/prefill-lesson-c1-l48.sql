-- =========================================
-- Pre-fill Database with Sample Lesson Data
-- C1-L48: Future of Human Communication
-- =========================================
DELETE FROM lesson_activity_results WHERE lesson_id = 'C1-L48';
DELETE FROM user_progress WHERE lesson_id = 'C1-L48';
DELETE FROM lesson_history WHERE lesson_id = 'C1-L48';
DELETE FROM grammar_sentences WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'C1-L48');
DELETE FROM vocabulary_items WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'C1-L48');
DELETE FROM lesson_activities WHERE lesson_id = 'C1-L48';
DELETE FROM lessons WHERE id = 'C1-L48';

INSERT INTO lessons (id, level, lesson_number, topic) VALUES
('C1-L48', 'C1', 48, 'Future of Human Communication')
ON CONFLICT (id) DO UPDATE SET topic = EXCLUDED.topic;

DO $$
DECLARE
    lesson_id_var TEXT := 'C1-L48';
    activity_id_var UUID;
BEGIN
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'warm_up_speaking', 1, 'Future Communication', 'Discuss future of communication', '{"prompt": "How will communication change in the future?"}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_intro', 2, 'Future Communication Vocabulary', 'Learn vocabulary about future communication', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'evolution', 'วิวัฒนาการ', NULL),
    (activity_id_var, 'trend', 'แนวโน้ม', NULL),
    (activity_id_var, 'interaction', 'การโต้ตอบ', NULL),
    (activity_id_var, 'adaptation', 'การปรับตัว', NULL),
    (activity_id_var, 'prediction', 'การทำนาย', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_matching_drag', 3, 'Match Future Communication Words', 'Match English words with Thai meanings', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'evolution', 'วิวัฒนาการ', NULL),
    (activity_id_var, 'trend', 'แนวโน้ม', NULL),
    (activity_id_var, 'interaction', 'การโต้ตอบ', NULL),
    (activity_id_var, 'adaptation', 'การปรับตัว', NULL),
    (activity_id_var, 'prediction', 'การทำนาย', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 4, 'Complete the Sentences 1', 'Fill with the correct word', '{"text": "Communication ___ continues. Future ___ will shape ___.", "blanks": [{"id": "blank1", "text": "evolution", "options": ["evolution", "trend", "interaction", "adaptation"], "correctAnswer": "evolution"}, {"id": "blank2", "text": "trends", "options": ["trends", "evolution", "interaction", "adaptation"], "correctAnswer": "trends"}, {"id": "blank3", "text": "interaction", "options": ["interaction", "evolution", "trend", "adaptation"], "correctAnswer": "interaction"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 5, 'Complete the Sentences 2', 'Fill with the correct word', '{"text": "Making ___ about communication requires ___. Successful ___ enables ___.", "blanks": [{"id": "blank1", "text": "predictions", "options": ["predictions", "evolution", "trend", "interaction"], "correctAnswer": "predictions"}, {"id": "blank2", "text": "insight", "options": ["insight", "evolution", "trend", "interaction"], "correctAnswer": "insight"}, {"id": "blank3", "text": "adaptation", "options": ["adaptation", "evolution", "trend", "interaction"], "correctAnswer": "adaptation"}, {"id": "blank4", "text": "growth", "options": ["growth", "evolution", "trend", "interaction"], "correctAnswer": "growth"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_explanation', 6, 'Advanced Perfect Aspect', 'Learn advanced perfect forms', '{"rules": "Advanced perfect aspect:\n- Future perfect: \"I will have adapted to new communication by 2030.\"\n- Future perfect continuous: \"I will have been communicating differently for years.\"\n- Perfect in conditional: \"If I had adapted, I would have communicated better.\"\n\nUse for:\n- Future completion: \"I will have changed my communication style by then.\"\n- Duration up to future point: \"I will have been using new tools for a decade.\"\n- Hypothetical past: \"If I had adapted earlier, I would have communicated better.\"", "examples": ["I will have adapted to new communication by 2030.", "I will have been communicating differently for years.", "By next decade, communication will have evolved significantly.", "I will have changed my communication style by then.", "Having adapted to new tools, people will communicate better."]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 7, 'Build Sentences 1', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'I will have adapted to new communication by 2030.', 'I will have adapted to new communication by 2030.', '["I", "will", "have", "adapted", "to", "new", "communication", "by", "2030."]'::jsonb),
    (activity_id_var, 'I will have been communicating differently for years.', 'I will have been communicating differently for years.', '["I", "will", "have", "been", "communicating", "differently", "for", "years."]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 8, 'Build Sentences 2', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'By next decade, communication will have evolved significantly.', 'By next decade, communication will have evolved significantly.', '["By", "next", "decade,", "communication", "will", "have", "evolved", "significantly."]'::jsonb),
    (activity_id_var, 'Having adapted to new tools, people will communicate better.', 'Having adapted to new tools, people will communicate better.', '["Having", "adapted", "to", "new", "tools,", "people", "will", "communicate", "better."]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'speaking_practice', 9, 'Discuss Future Communication', 'Practice speaking about future communication', '{"prompts": ["How will communication have evolved in 10 years?", "What trends do you predict?", "What will remain the same?", "How will technology shape interaction?", "How should people adapt?"]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (
      lesson_id,
      activity_type,
      activity_order,
      title,
      description,
      content
    ) VALUES (
      'C1-L48',
      'speaking_improvement',
      10,
      'Speaking Improvement',
      'Read the improved version of your speech',
      '{"type": "speaking_improvement", "similarityThreshold": 70}'::jsonb
    );
END $$;
