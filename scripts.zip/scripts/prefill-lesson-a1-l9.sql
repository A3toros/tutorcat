-- =========================================
-- Pre-fill Database with Sample Lesson Data
-- A1-L9: Weather & Seasons
-- =========================================

-- Clear existing sample data for A1-L9 (optional - comment out if you want to keep existing data)
DELETE FROM grammar_sentences WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'A1-L9');
DELETE FROM vocabulary_items WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'A1-L9');
DELETE FROM lesson_activities WHERE lesson_id = 'A1-L9';
DELETE FROM lessons WHERE id = 'A1-L9';

INSERT INTO lessons (id, level, lesson_number, topic) VALUES
('A1-L9', 'A1', 9, 'Weather & Seasons')
ON CONFLICT (id) DO UPDATE SET topic = EXCLUDED.topic;

DO $$
DECLARE
    lesson_id_var TEXT := 'A1-L9';
    activity_id_var UUID;
BEGIN
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content) VALUES (lesson_id_var, 'warm_up_speaking', 1, 'The Weather', 'Talk about weather', '{"prompt": "What is the weather like today?"}'::jsonb) RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content) VALUES (lesson_id_var, 'vocabulary_intro', 2, 'Weather Words', 'Learn weather vocabulary', '{}'::jsonb) RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'sunny', 'แดดออก', NULL),
    (activity_id_var, 'rainy', 'ฝนตก', NULL),
    (activity_id_var, 'cloudy', 'มีเมฆ', NULL),
    (activity_id_var, 'hot', 'ร้อน', NULL),
    (activity_id_var, 'cold', 'หนาว', NULL);

    -- 3. Vocabulary Matching Drag #1 (5 pairs - same words)
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content) VALUES (lesson_id_var, 'vocabulary_matching_drag', 3, 'Match Weather Words 1', 'Match English words with Thai meanings', '{}'::jsonb) RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'sunny', 'แดดออก', NULL),
    (activity_id_var, 'rainy', 'ฝนตก', NULL),
    (activity_id_var, 'cloudy', 'มีเมฆ', NULL),
    (activity_id_var, 'hot', 'ร้อน', NULL),
    (activity_id_var, 'cold', 'หนาว', NULL);

    

    -- 4. Vocabulary Fill Blanks #1 (4 words: sunny, rainy, cloudy, hot - cold left out)
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content) VALUES (lesson_id_var, 'vocabulary_fill_blanks', 4, 'Complete the Sentences 1', 'Fill in the blanks with correct words', '{"text": "Today it is ___ and bright. Yesterday it was ___ and wet. Tomorrow it will be ___ and dark. It is very ___ today, so I need water.", "blanks": [{"id": "blank1", "text": "sunny", "options": ["sunny", "rainy", "cloudy", "hot"], "correctAnswer": "sunny"}, {"id": "blank2", "text": "rainy", "options": ["sunny", "rainy", "cloudy", "hot"], "correctAnswer": "rainy"}, {"id": "blank3", "text": "cloudy", "options": ["sunny", "rainy", "cloudy", "hot"], "correctAnswer": "cloudy"}, {"id": "blank4", "text": "hot", "options": ["sunny", "rainy", "cloudy", "hot"], "correctAnswer": "hot"}]}'::jsonb) RETURNING id INTO activity_id_var;

    -- 4. Vocabulary Fill Blanks #2 (4 words: sunny, rainy, cloudy, cold - hot left out)
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content) VALUES (lesson_id_var, 'vocabulary_fill_blanks', 5, 'Complete the Sentences 2', 'Fill in the blanks with correct words', '{"text": "I like ___ days with blue sky. I don''t like ___ days with heavy rain. It is ___ today, so I can''t see the sun. In winter, it is ___ and I need a jacket.", "blanks": [{"id": "blank1", "text": "sunny", "options": ["sunny", "rainy", "cloudy", "cold"], "correctAnswer": "sunny"}, {"id": "blank2", "text": "rainy", "options": ["sunny", "rainy", "cloudy", "cold"], "correctAnswer": "rainy"}, {"id": "blank3", "text": "cloudy", "options": ["sunny", "rainy", "cloudy", "cold"], "correctAnswer": "cloudy"}, {"id": "blank4", "text": "cold", "options": ["sunny", "rainy", "cloudy", "cold"], "correctAnswer": "cold"}]}'::jsonb) RETURNING id INTO activity_id_var;

    -- 4. Grammar Explanation (5 examples)
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content) VALUES (lesson_id_var, 'grammar_explanation', 6, 'Describing Weather', 'Learn to describe weather', '{"rules": "Use ''It is'' or ''It''''s'' to describe weather:\n\n- It is + adjective (It is sunny)\n- It is + verb + ing (It is raining)\n- Use ''today'' or ''now'' for current weather\n- Use ''very'' for emphasis (It is very hot)", "examples": ["It is sunny today.", "It is raining now.", "It is very hot.", "It is cold in winter.", "It is cloudy this morning."]}'::jsonb) RETURNING id INTO activity_id_var;

    -- 4. Grammar Sentences #1
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content) VALUES (lesson_id_var, 'grammar_sentences', 7, 'Build Sentences 1', 'Arrange words to make sentences', '{}'::jsonb) RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'It is sunny today', 'It is sunny today', '["It", "is", "sunny", "today"]'::jsonb),
    (activity_id_var, 'It is raining now', 'It is raining now', '["It", "is", "raining", "now"]'::jsonb);
    -- 4. Grammar Sentences #2
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content) VALUES (lesson_id_var, 'grammar_sentences', 8, 'Build Sentences 2', 'Arrange words to make sentences', '{}'::jsonb) RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'It is very hot today', 'It is very hot today', '["It", "is", "very", "hot", "today"]'::jsonb),
    (activity_id_var, 'It is cold in winter', 'It is cold in winter', '["It", "is", "cold", "in", "winter"]'::jsonb);
    -- 4. Speaking Practice (5 prompts - CEFR A1)
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content) VALUES (lesson_id_var, 'speaking_practice', 9, 'Talk About Weather', 'Practice talking about weather', '{"prompts": ["What is the weather like today?", "Do you like sunny weather?", "What weather do you prefer?", "What do you do when it is cold?", "What do you do when it rains?"]}'::jsonb) RETURNING id INTO activity_id_var;

END $$;
