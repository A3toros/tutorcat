-- =========================================
-- Pre-fill Database with Sample Lesson Data
-- C1-L28: Responsibility of Content Creators
-- =========================================
DELETE FROM lesson_activity_results WHERE lesson_id = 'C1-L28';
DELETE FROM user_progress WHERE lesson_id = 'C1-L28';
DELETE FROM lesson_history WHERE lesson_id = 'C1-L28';
DELETE FROM grammar_sentences WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'C1-L28');
DELETE FROM vocabulary_items WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'C1-L28');
DELETE FROM lesson_activities WHERE lesson_id = 'C1-L28';
DELETE FROM lessons WHERE id = 'C1-L28';

INSERT INTO lessons (id, level, lesson_number, topic) VALUES
('C1-L28', 'C1', 28, 'Responsibility of Content Creators')
ON CONFLICT (id) DO UPDATE SET topic = EXCLUDED.topic;

DO $$
DECLARE
    lesson_id_var TEXT := 'C1-L28';
    activity_id_var UUID;
BEGIN
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'warm_up_speaking', 1, 'Content Creator Responsibility', 'Discuss content creator responsibility', '{"prompt": "What responsibilities come with a large audience?"}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_intro', 2, 'Content Creator Vocabulary', 'Learn vocabulary about content creators', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'responsibility', 'ความรับผิดชอบ', NULL),
    (activity_id_var, 'accountability', 'ความรับผิดชอบ', NULL),
    (activity_id_var, 'harm', 'อันตราย', NULL),
    (activity_id_var, 'platform', 'แพลตฟอร์ม', NULL),
    (activity_id_var, 'standard', 'มาตรฐาน', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_matching_drag', 3, 'Match Content Creator Words', 'Match English words with Thai meanings', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'responsibility', 'ความรับผิดชอบ', NULL),
    (activity_id_var, 'accountability', 'ความรับผิดชอบ', NULL),
    (activity_id_var, 'harm', 'อันตราย', NULL),
    (activity_id_var, 'platform', 'แพลตฟอร์ม', NULL),
    (activity_id_var, 'standard', 'มาตรฐาน', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 4, 'Complete the Sentences 1', 'Fill with the correct word', '{"text": "Content creators have ___. ___ must be addressed when ___.", "blanks": [{"id": "blank1", "text": "responsibility", "options": ["responsibility", "accountability", "harm", "platform"], "correctAnswer": "responsibility"}, {"id": "blank2", "text": "Harm", "options": ["Harm", "Responsibility", "Accountability", "Platform"], "correctAnswer": "Harm"}, {"id": "blank3", "text": "harm", "options": ["harm", "responsibility", "accountability", "platform"], "correctAnswer": "harm"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 5, 'Complete the Sentences 2', 'Fill with the correct word', '{"text": "___ requires ___. ___ set ethical ___.", "blanks": [{"id": "blank1", "text": "Accountability", "options": ["Accountability", "Responsibility", "Harm", "Platform"], "correctAnswer": "Accountability"}, {"id": "blank2", "text": "responsibility", "options": ["responsibility", "accountability", "harm", "standard"], "correctAnswer": "responsibility"}, {"id": "blank3", "text": "Platforms", "options": ["Platforms", "Responsibility", "Accountability", "Harm"], "correctAnswer": "Platforms"}, {"id": "blank4", "text": "standards", "options": ["standards", "responsibility", "accountability", "harm"], "correctAnswer": "standards"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_explanation', 6, 'Advanced Passives', 'Learn advanced passive structures', '{"rules": "Advanced passive forms:\n- \"Creators should be held accountable.\" (obligation)\n- \"Harm must be addressed.\" (necessity)\n- \"Standards are being established.\" (continuous)\n- \"Misinformation has been corrected.\" (perfect)\n- \"Content will be reviewed.\" (future)\n\nUse when:\n- Focus is on action, not actor: \"Harm should be prevented.\"\n- Actor is unknown/unimportant: \"Misinformation was spread.\"\n- Formal/impersonal tone: \"It is required that standards be followed.\"", "examples": ["Creators should be held accountable for their content.", "Harm must be addressed when it occurs.", "Standards are being established by platforms.", "Misinformation has been corrected by fact-checkers.", "Content will be reviewed regularly."]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 7, 'Build Sentences 1', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'Creators should be held accountable for their content.', 'Creators should be held accountable for their content.', '["Creators", "should", "be", "held", "accountable", "for", "their", "content."]'::jsonb),
    (activity_id_var, 'Harm must be addressed when it occurs.', 'Harm must be addressed when it occurs.', '["Harm", "must", "be", "addressed", "when", "it", "occurs."]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 8, 'Build Sentences 2', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'Standards are being established by platforms.', 'Standards are being established by platforms.', '["Standards", "are", "being", "established", "by", "platforms."]'::jsonb),
    (activity_id_var, 'Misinformation has been corrected by fact-checkers.', 'Misinformation has been corrected by fact-checkers.', '["Misinformation", "has", "been", "corrected", "by", "fact-checkers."]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'speaking_practice', 9, 'Discuss Content Creators', 'Practice speaking about content creators', '{"prompts": ["What should creators be accountable for?", "How should harm be addressed?", "What role do platforms play?", "How should misinformation be corrected?", "What ethical standards should creators follow?"]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (
      lesson_id,
      activity_type,
      activity_order,
      title,
      description,
      content
    ) VALUES (
      'C1-L28',
      'speaking_improvement',
      10,
      'Speaking Improvement',
      'Read the improved version of your speech',
      '{"type": "speaking_improvement", "similarityThreshold": 70}'::jsonb
    );
END $$;
