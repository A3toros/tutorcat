-- =========================================
-- Pre-fill Database with Sample Lesson Data
-- A2-L94: Traditional Food
-- =========================================

DELETE FROM grammar_sentences WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'A2-L94');
DELETE FROM vocabulary_items WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'A2-L94');
DELETE FROM lesson_activities WHERE lesson_id = 'A2-L94';
DELETE FROM lessons WHERE id = 'A2-L94';

INSERT INTO lessons (id, level, lesson_number, topic) VALUES
('A2-L94', 'A2', 94, 'Traditional Food')
ON CONFLICT (id) DO UPDATE SET topic = EXCLUDED.topic;

DO $$
DECLARE
    lesson_id_var TEXT := 'A2-L94';
    activity_id_var UUID;
BEGIN
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'warm_up_speaking', 1, 'Family Dishes', 'Talk about traditional food', '{"prompt": "What food did you eat as a child?"}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_intro', 2, 'Traditional Food Words', 'Learn words about traditional food', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'traditional', 'ดั้งเดิม', NULL),
    (activity_id_var, 'recipe', 'สูตรอาหาร', NULL),
    (activity_id_var, 'festival', 'เทศกาล', NULL),
    (activity_id_var, 'holiday', 'วันหยุด', NULL),
    (activity_id_var, 'taste', 'รสชาติ', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_matching_drag', 3, 'Match Traditional Food Words', 'Match traditional food words', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'traditional', 'ดั้งเดิม', NULL),
    (activity_id_var, 'recipe', 'สูตรอาหาร', NULL),
    (activity_id_var, 'festival', 'เทศกาล', NULL),
    (activity_id_var, 'holiday', 'วันหยุด', NULL),
    (activity_id_var, 'taste', 'รสชาติ', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 4, 'Complete the Sentences 1', 'Fill with the correct word', '{"text": "This is a ___ dish. The ___ is from my aunt. We cook it on a ___.", "blanks": [{"id": "blank1", "text": "traditional", "options": ["traditional", "recipe", "holiday", "taste"], "correctAnswer": "traditional"}, {"id": "blank2", "text": "recipe", "options": ["recipe", "taste", "festival", "holiday"], "correctAnswer": "recipe"}, {"id": "blank3", "text": "holiday", "options": ["holiday", "festival", "traditional", "taste"], "correctAnswer": "holiday"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 5, 'Complete the Sentences 2', 'Fill with the correct word', '{"text": "We eat it at the ___. The ___ is sweet.", "blanks": [{"id": "blank1", "text": "festival", "options": ["festival", "holiday", "recipe", "taste"], "correctAnswer": "festival"}, {"id": "blank2", "text": "taste", "options": ["taste", "recipe", "festival", "traditional"], "correctAnswer": "taste"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_explanation', 6, 'Past Simple', 'Talk about food memories', '{"rules": "Use past simple for finished events.\n- We cooked this last weekend.\n- I learned the recipe from my aunt.\nQuestions: Did you try it? Negatives: didn''t + verb.", "examples": ["We cooked this last weekend.", "I learned the recipe from my aunt.", "Did you try it at the festival?", "I didn''t taste it before.", "She made it for a holiday."]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 7, 'Build Sentences 1', 'Arrange words', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'We cooked this last weekend', 'We cooked this last weekend.', '["We", "cooked", "this", "last", "weekend."]'::jsonb),
    (activity_id_var, 'I learned the recipe from my aunt', 'I learned the recipe from my aunt.', '["I", "learned", "the", "recipe", "from", "my", "aunt."]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 8, 'Build Sentences 2', 'Arrange words', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'Did you try it at the festival', 'Did you try it at the festival?', '["Did", "you", "try", "it", "at", "the", "festival?"]'::jsonb),
    (activity_id_var, 'She made it for a holiday', 'She made it for a holiday.', '["She", "made", "it", "for", "a", "holiday."]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'speaking_practice', 9, 'Talk About Traditional Food', 'Practice food memories', '{"prompts": ["What food did you eat as a child?", "Who taught you to cook it?", "When did you eat it most often?", "How did your family prepare it?", "Why was it special to you?"]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (
      lesson_id,
      activity_type,
      activity_order,
      title,
      description,
      content
    ) VALUES (
      'A2-L94',
      'speaking_improvement',
      10,
      'Speaking Improvement',
      'Read the improved version of your speech',
      '{"type": "speaking_improvement", "similarityThreshold": 70}'::jsonb
    );
END $$;

