-- =========================================
-- Pre-fill Database with Sample Lesson Data
-- A2-L1: Travel & Transport
-- =========================================

-- Clear existing sample data for A2-L1 (optional - comment out if you want to keep existing data)
DELETE FROM grammar_sentences WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'A2-L1');
DELETE FROM vocabulary_items WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'A2-L1');
DELETE FROM lesson_activities WHERE lesson_id = 'A2-L1';
DELETE FROM lessons WHERE id = 'A2-L1';

INSERT INTO lessons (id, level, lesson_number, topic) VALUES
('A2-L1', 'A2', 1, 'Travel & Transport')
ON CONFLICT (id) DO UPDATE SET topic = EXCLUDED.topic;

DO $$
DECLARE
    lesson_id_var TEXT := 'A2-L1';
    activity_id_var UUID;
BEGIN
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content) VALUES (lesson_id_var, 'warm_up_speaking', 1, 'Travel Plans', 'How do you travel?', '{"prompt": "How do you usually travel to school or work?"}'::jsonb) RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content) VALUES (lesson_id_var, 'vocabulary_intro', 2, 'Transport Words', 'Learn transport vocabulary', '{}'::jsonb) RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'airplane', 'เครื่องบิน', NULL),
    (activity_id_var, 'train', 'รถไฟ', NULL),
    (activity_id_var, 'bus', 'รถบัส', NULL),
    (activity_id_var, 'taxi', 'แท็กซี่', NULL),
    (activity_id_var, 'bicycle', 'จักรยาน', NULL);

    -- 3. Vocabulary Matching Drag #1 (5 pairs - same words)
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content) VALUES (lesson_id_var, 'vocabulary_matching_drag', 3, 'Match Transport 1', 'Match English words with Thai meanings', '{}'::jsonb) RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'airplane', 'เครื่องบิน', NULL),
    (activity_id_var, 'train', 'รถไฟ', NULL),
    (activity_id_var, 'bus', 'รถบัส', NULL),
    (activity_id_var, 'taxi', 'แท็กซี่', NULL),
    (activity_id_var, 'bicycle', 'จักรยาน', NULL);

    

    -- 4. Vocabulary Fill Blanks #1 (4 words: airplane, train, bus, taxi - bicycle left out)
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content) VALUES (lesson_id_var, 'vocabulary_fill_blanks', 4, 'Complete the Sentences 1', 'Fill in the blanks with correct words', '{"text": "I flew by ___ from Bangkok to Phuket. I took a ___ from the airport to the city center. I also used a city ___ to explore. I called a ___ to go home.", "blanks": [{"id": "blank1", "text": "airplane", "options": ["airplane", "train", "bus", "taxi"], "correctAnswer": "airplane"}, {"id": "blank2", "text": "train", "options": ["airplane", "train", "bus", "taxi"], "correctAnswer": "train"}, {"id": "blank3", "text": "bus", "options": ["airplane", "train", "bus", "taxi"], "correctAnswer": "bus"}, {"id": "blank4", "text": "taxi", "options": ["airplane", "train", "bus", "taxi"], "correctAnswer": "taxi"}]}'::jsonb) RETURNING id INTO activity_id_var;

    -- 4. Vocabulary Fill Blanks #2 (4 words: airplane, train, bus, bicycle - taxi left out)
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content) VALUES (lesson_id_var, 'vocabulary_fill_blanks', 5, 'Complete the Sentences 2', 'Fill in the blanks with correct words', '{"text": "I flew on an ___ from Bangkok to Phuket. I took a ___ from the station to the hotel. I rode a ___ around the island. I also took a city ___ to the beach.", "blanks": [{"id": "blank1", "text": "airplane", "options": ["airplane", "train", "bus", "bicycle"], "correctAnswer": "airplane"}, {"id": "blank2", "text": "train", "options": ["airplane", "train", "bus", "bicycle"], "correctAnswer": "train"}, {"id": "blank3", "text": "bicycle", "options": ["airplane", "train", "bus", "bicycle"], "correctAnswer": "bicycle"}, {"id": "blank4", "text": "bus", "options": ["airplane", "train", "bus", "bicycle"], "correctAnswer": "bus"}]}'::jsonb) RETURNING id INTO activity_id_var;

    -- 4. Grammar Explanation (5 examples - CEFR A2: Past simple)
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content) VALUES (lesson_id_var, 'grammar_explanation', 6, 'Past Simple - Travel', 'Learn to talk about past travel', '{"rules": "Use past simple for completed actions:\n\n- Regular verbs: verb + ed (I traveled)\n- Irregular verbs: special form (I went)\n- Questions: Did + subject + verb? (Did you travel?)\n- Negative: didn''t + verb (I didn''t go)\n- Time expressions: yesterday, last week, two years ago", "examples": ["I traveled to Bangkok last year.", "She went by train yesterday.", "Did you fly to Phuket?", "We didn''t take a taxi.", "He rode a bicycle last week."]}'::jsonb) RETURNING id INTO activity_id_var;
    -- 4. Grammar Sentences #1
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content) VALUES (lesson_id_var, 'grammar_sentences', 7, 'Build Sentences 1', 'Arrange words to make sentences', '{}'::jsonb) RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'I traveled to Bangkok last year', 'I traveled to Bangkok last year', '["I", "traveled", "to", "Bangkok", "last", "year"]'::jsonb),
    (activity_id_var, 'She went by train yesterday', 'She went by train yesterday', '["She", "went", "by", "train", "yesterday"]'::jsonb);
    -- 4. Grammar Sentences #2
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content) VALUES (lesson_id_var, 'grammar_sentences', 8, 'Build Sentences 2', 'Arrange words to make sentences', '{}'::jsonb) RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'Did you fly to Phuket', 'Did you fly to Phuket?', '["Did", "you", "fly", "to", "Phuket?"]'::jsonb),
    (activity_id_var, 'We didn t take a taxi', 'We didn''t take a taxi', '["We", "didn''t", "take", "a", "taxi"]'::jsonb);
    -- 4. Speaking Practice (5 prompts - CEFR A2: Past experiences, preferences)
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content) VALUES (lesson_id_var, 'speaking_practice', 9, 'Talk About Travel', 'Practice talking about travel', '{"prompts": ["Do you like traveling by bus or taxi?", "What is your favorite way to travel in your city?", "Have you ever been on a long train trip?", "Do you prefer flying or driving for holidays?", "Where did you go on your last trip?"]}'::jsonb) RETURNING id INTO activity_id_var;

    -- 10. Speaking Improvement
    INSERT INTO lesson_activities (
      lesson_id,
      activity_type,
      activity_order,
      title,
      description,
      content
    ) VALUES (
      lesson_id_var,
      'speaking_improvement',
      10,
      'Speaking Improvement',
      'Read the improved version of your speech',
      '{"type": "speaking_improvement", "similarityThreshold": 70}'::jsonb
    );

END $$;
