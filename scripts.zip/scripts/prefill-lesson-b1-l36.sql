-- =========================================
-- Pre-fill Database with Sample Lesson Data
-- B1-L36: Fitness Routines
-- =========================================

DELETE FROM grammar_sentences WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'B1-L36');
DELETE FROM vocabulary_items WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'B1-L36');
DELETE FROM lesson_activities WHERE lesson_id = 'B1-L36';
DELETE FROM lessons WHERE id = 'B1-L36';

INSERT INTO lessons (id, level, lesson_number, topic) VALUES
('B1-L36', 'B1', 36, 'Fitness Routines')
ON CONFLICT (id) DO UPDATE SET topic = EXCLUDED.topic;

DO $$
DECLARE
    lesson_id_var TEXT := 'B1-L36';
    activity_id_var UUID;
BEGIN
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'warm_up_speaking', 1, 'Working Out', 'Talk about exercise that motivates you', '{"prompt": "What makes a workout so motivating for you?"}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_intro', 2, 'Fitness Words', 'Learn vocabulary about fitness routines', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'routine', 'กิจวัตร', NULL),
    (activity_id_var, 'stamina', 'ความอึด', NULL),
    (activity_id_var, 'stretch', 'ยืดกล้ามเนื้อ', NULL),
    (activity_id_var, 'rest', 'พัก', NULL),
    (activity_id_var, 'hydrate', 'ดื่มน้ำให้เพียงพอ', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_matching_drag', 3, 'Match Fitness Words', 'Match words with meanings', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'routine', 'กิจวัตร', NULL),
    (activity_id_var, 'stamina', 'ความอึด', NULL),
    (activity_id_var, 'stretch', 'ยืดกล้ามเนื้อ', NULL),
    (activity_id_var, 'rest', 'พัก', NULL),
    (activity_id_var, 'hydrate', 'ดื่มน้ำให้เพียงพอ', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 4, 'Complete the Sentences 1', 'Fill with the correct word', '{"text": "A steady ___ helps. I build ___. I always ___ before running.", "blanks": [{"id": "blank1", "text": "routine", "options": ["routine", "stamina", "stretch", "rest"], "correctAnswer": "routine"}, {"id": "blank2", "text": "stamina", "options": ["stamina", "routine", "rest", "hydrate"], "correctAnswer": "stamina"}, {"id": "blank3", "text": "stretch", "options": ["stretch", "rest", "hydrate", "routine"], "correctAnswer": "stretch"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 5, 'Complete the Sentences 2', 'Fill with the correct word', '{"text": "I plan ___ days. I always ___ after workouts. I drink to ___.", "blanks": [{"id": "blank1", "text": "rest", "options": ["rest", "hydrate", "stamina", "routine"], "correctAnswer": "rest"}, {"id": "blank2", "text": "rest", "options": ["rest", "stretch", "hydrate", "stamina"], "correctAnswer": "rest"}, {"id": "blank3", "text": "hydrate", "options": ["hydrate", "stretch", "rest", "stamina"], "correctAnswer": "hydrate"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    -- Grammar Explanation: So / Such (fitness emphasis)
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_explanation', 6, 'So / Such for Fitness Emphasis', 'Use so + adjective and such a/an + adjective + noun to emphasize workouts', '{"rules": "Use so + adjective: so motivating. Use such a/an + adjective + noun: such a tiring session. Keep natural and concise.\\n- It was such a hard workout.\\n- I felt so strong after it.", "examples": ["It was such a tiring session yesterday.", "I felt so motivated by the playlist.", "She had such a steady routine last month.", "He was so exhausted after the run.", "We had such a supportive group class."]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 7, 'Build Sentences 1', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'It was such a tiring session yesterday', 'It was such a tiring session yesterday', '["It", "was", "such", "a", "tiring", "session", "yesterday"]'::jsonb),
    (activity_id_var, 'I felt so motivated by the playlist', 'I felt so motivated by the playlist', '["I", "felt", "so", "motivated", "by", "the", "playlist"]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 8, 'Build Sentences 2', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'She had such a steady routine last month', 'She had such a steady routine last month', '["She", "had", "such", "a", "steady", "routine", "last", "month"]'::jsonb),
    (activity_id_var, 'He was so exhausted after the run', 'He was so exhausted after the run', '["He", "was", "so", "exhausted", "after", "the", "run"]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'speaking_practice', 9, 'Talk About Fitness', 'Practice talking about workouts and routines', '{"prompts": ["What makes a workout so motivating for you?", "What is such a tiring exercise that you still do?", "How do you keep a routine when you are busy?"]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (
      lesson_id,
      activity_type,
      activity_order,
      title,
      description,
      content
    ) VALUES (
      'B1-L36',
      'speaking_improvement',
      10,
      'Speaking Improvement',
      'Read the improved version of your speech',
      '{"type": "speaking_improvement", "similarityThreshold": 70}'::jsonb
    );
END $$;

