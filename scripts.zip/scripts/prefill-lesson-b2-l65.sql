-- =========================================
-- Pre-fill Database with Sample Lesson Data
-- B2-L65: Planning for the future
-- =========================================

DELETE FROM grammar_sentences WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'B2-L65');
DELETE FROM vocabulary_items WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'B2-L65');
DELETE FROM lesson_activities WHERE lesson_id = 'B2-L65';
DELETE FROM lessons WHERE id = 'B2-L65';

INSERT INTO lessons (id, level, lesson_number, topic) VALUES
('B2-L65', 'B2', 65, 'Planning for the future')
ON CONFLICT (id) DO UPDATE SET topic = EXCLUDED.topic;

DO $$
DECLARE
    lesson_id_var TEXT := 'B2-L65';
    activity_id_var UUID;
BEGIN
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'warm_up_speaking', 1, 'Plan B Moments', 'Talk about backup plans', '{"prompt": "How little do others know about your plan B, and when do you pivot?"}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_intro', 2, 'Planning Words', 'Key words for scenarios and pivots', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'contingency', 'แผนสำรอง', NULL),
    (activity_id_var, 'scenario', 'สถานการณ์สมมติ', NULL),
    (activity_id_var, 'fallback', 'ทางเลือกสำรอง', NULL),
    (activity_id_var, 'adjust', 'ปรับ', NULL),
    (activity_id_var, 'forecast', 'การคาดการณ์', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_matching_drag', 3, 'Match Planning Words', 'Match words with meanings', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'contingency', 'แผนสำรอง', NULL),
    (activity_id_var, 'scenario', 'สถานการณ์สมมติ', NULL),
    (activity_id_var, 'fallback', 'ทางเลือกสำรอง', NULL),
    (activity_id_var, 'adjust', 'ปรับ', NULL),
    (activity_id_var, 'forecast', 'การคาดการณ์', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 4, 'Complete the Sentences 1', 'Fill with the correct word', '{"text": "We map each ___. We keep a ___. We ___ plans when needed.", "blanks": [{"id": "blank1", "text": "scenario", "options": ["scenario", "fallback", "contingency", "forecast"], "correctAnswer": "scenario"}, {"id": "blank2", "text": "fallback", "options": ["fallback", "forecast", "scenario", "adjust"], "correctAnswer": "fallback"}, {"id": "blank3", "text": "adjust", "options": ["adjust", "forecast", "contingency", "fallback"], "correctAnswer": "adjust"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 5, 'Complete the Sentences 2', 'Fill with the correct word', '{"text": "Our ___ guides budgets. Each ___ is shared quietly.", "blanks": [{"id": "blank1", "text": "forecast", "options": ["forecast", "scenario", "fallback", "contingency"], "correctAnswer": "forecast"}, {"id": "blank2", "text": "contingency", "options": ["contingency", "forecast", "fallback", "adjust"], "correctAnswer": "contingency"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_explanation', 6, 'Inversion (Little do…)', 'Emphasize hidden plans', '{"rules": "For emphasis with negative adverbials: Little do/does/did + subject + base verb. Use present for current truths; past for past events.\\n- Little do they know about my plan B.\\n- Little did we expect this scenario.", "examples": ["Little do others know how often I adjust plans.", "Little does the team see our fallback options.", "Little did we expect to pivot this early.", "Little do you realize the forecast changed.", "Little did they prepare for that scenario."]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 7, 'Build Sentences 1', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'Little do others know how often I adjust plans', 'Little do others know how often I adjust plans.', '["Little", "do", "others", "know", "how", "often", "I", "adjust", "plans."]'::jsonb),
    (activity_id_var, 'Little does the team see our fallback options', 'Little does the team see our fallback options.', '["Little", "does", "the", "team", "see", "our", "fallback", "options."]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 8, 'Build Sentences 2', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'Little did we expect to pivot this early', 'Little did we expect to pivot this early.', '["Little", "did", "we", "expect", "to", "pivot", "this", "early."]'::jsonb),
    (activity_id_var, 'Little did they prepare for that scenario', 'Little did they prepare for that scenario.', '["Little", "did", "they", "prepare", "for", "that", "scenario."]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'speaking_practice', 9, 'Talk About Future Plans', 'Practice inversion emphasis', '{"prompts": ["How little do others know about your plan B?", "When do you pivot your plans?", "What scenario surprised you recently?"]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (
      lesson_id,
      activity_type,
      activity_order,
      title,
      description,
      content
    ) VALUES (
      'B2-L65',
      'speaking_improvement',
      10,
      'Speaking Improvement',
      'Read the improved version of your speech',
      '{"type": "speaking_improvement", "similarityThreshold": 70}'::jsonb
    );
END $$;


