-- =========================================
-- Pre-fill Database with Sample Lesson Data
-- A1-L57: At the Supermarket
-- =========================================

DELETE FROM grammar_sentences WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'A1-L57');
DELETE FROM vocabulary_items WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'A1-L57');
DELETE FROM lesson_activities WHERE lesson_id = 'A1-L57';
DELETE FROM lessons WHERE id = 'A1-L57';

INSERT INTO lessons (id, level, lesson_number, topic) VALUES
('A1-L57', 'A1', 57, 'At the Supermarket')
ON CONFLICT (id) DO UPDATE SET topic = EXCLUDED.topic;

DO $$
DECLARE
    lesson_id_var TEXT := 'A1-L57';
    activity_id_var UUID;
BEGIN
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'warm_up_speaking', 1, 'Shopping Help', 'Talk about supermarket requests', '{"prompt": "Can I have a bag?"}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_intro', 2, 'Supermarket Words', 'Learn supermarket words', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'basket', 'ตะกร้า', NULL),
    (activity_id_var, 'bag', 'ถุง', NULL),
    (activity_id_var, 'price', 'ราคา', NULL),
    (activity_id_var, 'pay', 'จ่าย', NULL),
    (activity_id_var, 'line', 'แถว', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_matching_drag', 3, 'Match Supermarket Words', 'Match supermarket words', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'basket', 'ตะกร้า', NULL),
    (activity_id_var, 'bag', 'ถุง', NULL),
    (activity_id_var, 'price', 'ราคา', NULL),
    (activity_id_var, 'pay', 'จ่าย', NULL),
    (activity_id_var, 'line', 'แถว', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 4, 'Complete the Sentences 1', 'Fill with the correct word', '{"text": "The ___ is full. I need a ___.", "blanks": [{"id": "blank1", "text": "basket", "options": ["basket", "bag", "price", "line"], "correctAnswer": "basket"}, {"id": "blank2", "text": "bag", "options": ["bag", "price", "pay", "line"], "correctAnswer": "bag"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 5, 'Complete the Sentences 2', 'Fill with the correct word', '{"text": "What is the ___? Where do I ___?", "blanks": [{"id": "blank1", "text": "price", "options": ["price", "bag", "line", "basket"], "correctAnswer": "price"}, {"id": "blank2", "text": "pay", "options": ["pay", "line", "price", "bag"], "correctAnswer": "pay"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_explanation', 6, 'Can (requests)', 'Ask for help in a supermarket', '{"rules": "Use can to ask politely.\n- Can I have a bag?\n- Can I pay here?\nShort answers: Yes, you can.", "examples": ["Can I have a bag?", "Can I pay here?", "Can you show the price?", "Can I stand in this line?", "Can I use this basket?"]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 7, 'Build Sentences 1', 'Arrange words', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'Can I have a bag', 'Can I have a bag?', '["Can", "I", "have", "a", "bag?"]'::jsonb),
    (activity_id_var, 'Can I pay here', 'Can I pay here?', '["Can", "I", "pay", "here?"]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 8, 'Build Sentences 2', 'Arrange words', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'Can you show the price', 'Can you show the price?', '["Can", "you", "show", "the", "price?"]'::jsonb),
    (activity_id_var, 'Can I stand in this line', 'Can I stand in this line?', '["Can", "I", "stand", "in", "this", "line?"]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'speaking_practice', 9, 'Talk in a Supermarket', 'Practice requests', '{"prompts": ["Can I have a bag?", "What is the price?", "Where do I pay?", "Can I stand in this line?", "Can you show the price?"]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (
      lesson_id,
      activity_type,
      activity_order,
      title,
      description,
      content
    ) VALUES (
      'A1-L57',
      'speaking_improvement',
      10,
      'Speaking Improvement',
      'Read the improved version of your speech',
      '{"type": "speaking_improvement", "similarityThreshold": 70}'::jsonb
    );
END $$;

