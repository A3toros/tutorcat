-- =========================================
-- Pre-fill Database with Sample Lesson Data
-- A2-L78: Feeling Bored
-- =========================================

DELETE FROM grammar_sentences WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'A2-L78');
DELETE FROM vocabulary_items WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'A2-L78');
DELETE FROM lesson_activities WHERE lesson_id = 'A2-L78';
DELETE FROM lessons WHERE id = 'A2-L78';

INSERT INTO lessons (id, level, lesson_number, topic) VALUES
('A2-L78', 'A2', 78, 'Feeling Bored')
ON CONFLICT (id) DO UPDATE SET topic = EXCLUDED.topic;

DO $$
DECLARE
    lesson_id_var TEXT := 'A2-L78';
    activity_id_var UUID;
BEGIN
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'warm_up_speaking', 1, 'Boredom', 'Talk about being bored', '{"prompt": "What things make you feel bored?"}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_intro', 2, 'Bored Words', 'Learn words about boredom', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'boring', 'น่าเบื่อ', NULL),
    (activity_id_var, 'bored', 'เบื่อ', NULL),
    (activity_id_var, 'same', 'เหมือนเดิม', NULL),
    (activity_id_var, 'change', 'เปลี่ยน', NULL),
    (activity_id_var, 'new', 'ใหม่', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_matching_drag', 3, 'Match Bored Words', 'Match boredom words', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'boring', 'น่าเบื่อ', NULL),
    (activity_id_var, 'bored', 'เบื่อ', NULL),
    (activity_id_var, 'same', 'เหมือนเดิม', NULL),
    (activity_id_var, 'change', 'เปลี่ยน', NULL),
    (activity_id_var, 'new', 'ใหม่', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 4, 'Complete the Sentences 1', 'Fill with the correct word', '{"text": "This show is ___. I feel ___. Every day is the ___.", "blanks": [{"id": "blank1", "text": "boring", "options": ["boring", "bored", "same", "new"], "correctAnswer": "boring"}, {"id": "blank2", "text": "bored", "options": ["bored", "boring", "same", "change"], "correctAnswer": "bored"}, {"id": "blank3", "text": "same", "options": ["same", "new", "boring", "bored"], "correctAnswer": "same"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 5, 'Complete the Sentences 2', 'Fill with the correct word', '{"text": "I want a ___. I need a ___.", "blanks": [{"id": "blank1", "text": "change", "options": ["change", "new", "same", "bored"], "correctAnswer": "change"}, {"id": "blank2", "text": "new", "options": ["new", "change", "boring", "bored"], "correctAnswer": "new"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_explanation', 6, 'Present Simple (feelings/habits)', 'Talk about what is boring', '{"rules": "Use present simple for feelings and habits.\n- I feel bored at home.\n- This show is boring.\nQuestions: Do you feel bored? Negatives: don''t/doesn''t.", "examples": ["I feel bored at home.", "This show is boring.", "We do the same thing every day.", "Do you feel bored at work?", "She doesn''t like the same routine."]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 7, 'Build Sentences 1', 'Arrange words', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'I feel bored at home', 'I feel bored at home.', '["I", "feel", "bored", "at", "home."]'::jsonb),
    (activity_id_var, 'This show is boring', 'This show is boring.', '["This", "show", "is", "boring."]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 8, 'Build Sentences 2', 'Arrange words', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'Do you feel bored at work', 'Do you feel bored at work?', '["Do", "you", "feel", "bored", "at", "work?"]'::jsonb),
    (activity_id_var, 'She doesn t like the same routine', 'She doesn''t like the same routine.', '["She", "doesn''t", "like", "the", "same", "routine."]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'speaking_practice', 9, 'Talk About Boredom', 'Practice talking about boredom', '{"prompts": ["What activities feel boring to you?", "When do you usually feel bored?", "What do you do when you feel bored?", "How do you make boring days better?", "What hobbies help you avoid boredom?"]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (
      lesson_id,
      activity_type,
      activity_order,
      title,
      description,
      content
    ) VALUES (
      'A2-L78',
      'speaking_improvement',
      10,
      'Speaking Improvement',
      'Read the improved version of your speech',
      '{"type": "speaking_improvement", "similarityThreshold": 70}'::jsonb
    );
END $$;

