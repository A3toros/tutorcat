-- =========================================
-- Pre-fill Database with Sample Lesson Data
-- A1-L54: What You Are Wearing
-- =========================================

DELETE FROM grammar_sentences WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'A1-L54');
DELETE FROM vocabulary_items WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'A1-L54');
DELETE FROM lesson_activities WHERE lesson_id = 'A1-L54');
DELETE FROM lessons WHERE id = 'A1-L54';

INSERT INTO lessons (id, level, lesson_number, topic) VALUES
('A1-L54', 'A1', 54, 'What You Are Wearing')
ON CONFLICT (id) DO UPDATE SET topic = EXCLUDED.topic;

DO $$
DECLARE
    lesson_id_var TEXT := 'A1-L54';
    activity_id_var UUID;
BEGIN
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'warm_up_speaking', 1, 'Clothes Now', 'Talk about clothes now', '{"prompt": "What are you wearing?"}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_intro', 2, 'Clothes Now Words', 'Learn clothes now words', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'wearing', 'กำลังสวมใส่', NULL),
    (activity_id_var, 'shirt', 'เสื้อเชิ้ต', NULL),
    (activity_id_var, 'pants', 'กางเกง', NULL),
    (activity_id_var, 'shoes', 'รองเท้า', NULL),
    (activity_id_var, 'color', 'สี', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_matching_drag', 3, 'Match Clothes Now Words', 'Match clothes-now words', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'wearing', 'กำลังสวมใส่', NULL),
    (activity_id_var, 'shirt', 'เสื้อเชิ้ต', NULL),
    (activity_id_var, 'pants', 'กางเกง', NULL),
    (activity_id_var, 'shoes', 'รองเท้า', NULL),
    (activity_id_var, 'color', 'สี', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 4, 'Complete the Sentences 1', 'Fill with the correct word', '{"text": "I am ___ a ___. I am wearing ___ shoes.", "blanks": [{"id": "blank1", "text": "wearing", "options": ["wearing", "color", "shirt", "pants"], "correctAnswer": "wearing"}, {"id": "blank2", "text": "shirt", "options": ["shirt", "pants", "color", "shoes"], "correctAnswer": "shirt"}, {"id": "blank3", "text": "black", "options": ["black", "wearing", "pants", "color"], "correctAnswer": "black"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 5, 'Complete the Sentences 2', 'Fill with the correct word', '{"text": "I am wearing ___. They are ___.", "blanks": [{"id": "blank1", "text": "pants", "options": ["pants", "shirt", "shoes", "color"], "correctAnswer": "pants"}, {"id": "blank2", "text": "blue", "options": ["blue", "black", "wearing", "shirt"], "correctAnswer": "blue"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_explanation', 6, 'Be + Wearing (present)', 'Say what you wear now', '{"rules": "Use am/is/are + wearing + item.\n- I am wearing a shirt.\n- She is wearing shoes.\nAsk: What are you wearing?", "examples": ["I am wearing a shirt.", "She is wearing black shoes.", "We are wearing blue pants.", "Are you wearing a hat?", "Is he wearing a coat?"]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 7, 'Build Sentences 1', 'Arrange words', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'I am wearing a shirt', 'I am wearing a shirt.', '["I", "am", "wearing", "a", "shirt."]'::jsonb),
    (activity_id_var, 'She is wearing black shoes', 'She is wearing black shoes.', '["She", "is", "wearing", "black", "shoes."]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 8, 'Build Sentences 2', 'Arrange words', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'Are you wearing a hat', 'Are you wearing a hat?', '["Are", "you", "wearing", "a", "hat?"]'::jsonb),
    (activity_id_var, 'Is he wearing a coat', 'Is he wearing a coat?', '["Is", "he", "wearing", "a", "coat?"]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'speaking_practice', 9, 'Talk About Clothes Now', 'Practice present wearing', '{"prompts": ["What are you wearing?", "Are you wearing shoes?", "Is your shirt blue?", "Are your pants black?", "Is he wearing a hat?"]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (
      lesson_id,
      activity_type,
      activity_order,
      title,
      description,
      content
    ) VALUES (
      'A1-L54',
      'speaking_improvement',
      10,
      'Speaking Improvement',
      'Read the improved version of your speech',
      '{"type": "speaking_improvement", "similarityThreshold": 70}'::jsonb
    );
END $$;

