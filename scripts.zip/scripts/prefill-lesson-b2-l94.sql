-- =========================================
-- Pre-fill Database with Sample Lesson Data
-- B2-L94: Personal responsibility (signals)
-- =========================================

DELETE FROM grammar_sentences WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'B2-L94');
DELETE FROM vocabulary_items WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'B2-L94');
DELETE FROM lesson_activities WHERE lesson_id = 'B2-L94';
DELETE FROM lessons WHERE id = 'B2-L94';

INSERT INTO lessons (id, level, lesson_number, topic) VALUES
('B2-L94', 'B2', 94, 'Personal responsibility (signals)')
ON CONFLICT (id) DO UPDATE SET topic = EXCLUDED.topic;

DO $$
DECLARE
    lesson_id_var TEXT := 'B2-L94';
    activity_id_var UUID;
BEGIN
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'warm_up_speaking', 1, 'Accountability Signals', 'Talk about noticing slips', '{"prompt": "How can you tell you’re slipping, and what must you do next?"}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_intro', 2, 'Accountability Words', 'Key words for duty signals', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'accountable', 'รับผิดชอบ', NULL),
    (activity_id_var, 'duty', 'หน้าที่', NULL),
    (activity_id_var, 'consequence', 'ผลลัพธ์', NULL),
    (activity_id_var, 'uphold', 'รักษา/คงไว้', NULL),
    (activity_id_var, 'neglect', 'ละเลย', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_matching_drag', 3, 'Match Accountability Words', 'Match words with meanings', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'accountable', 'รับผิดชอบ', NULL),
    (activity_id_var, 'duty', 'หน้าที่', NULL),
    (activity_id_var, 'consequence', 'ผลลัพธ์', NULL),
    (activity_id_var, 'uphold', 'รักษา/คงไว้', NULL),
    (activity_id_var, 'neglect', 'ละเลย', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 4, 'Complete the Sentences 1', 'Fill with the correct word', '{"text": "I stay ___. Each ___ has a ___.", "blanks": [{"id": "blank1", "text": "accountable", "options": ["accountable", "duty", "consequence", "neglect"], "correctAnswer": "accountable"}, {"id": "blank2", "text": "duty", "options": ["duty", "accountable", "uphold", "neglect"], "correctAnswer": "duty"}, {"id": "blank3", "text": "consequence", "options": ["consequence", "neglect", "accountable", "duty"], "correctAnswer": "consequence"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 5, 'Complete the Sentences 2', 'Fill with the correct word', '{"text": "I must ___ standards. I avoid ___.", "blanks": [{"id": "blank1", "text": "uphold", "options": ["uphold", "accountable", "duty", "neglect"], "correctAnswer": "uphold"}, {"id": "blank2", "text": "neglect", "options": ["neglect", "consequence", "uphold", "duty"], "correctAnswer": "neglect"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_explanation', 6, 'Modals for Deduction', 'Notice signs of slipping', '{"rules": "Use must/might/can’t + base verb for present deduction; modal + have + past participle for past clues.\\n- I must be slipping; I missed a deadline.\\n- This might be a small neglect.\\n- It can’t be fine; standards dropped.", "examples": ["I must be slipping; my tasks are late.", "There might be a gap; the checklist is empty.", "It can’t be acceptable; we ignored duty.", "He must have neglected a step; errors piled up.", "She might have upheld the standard; the result is solid."]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 7, 'Build Sentences 1', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'I must be slipping; my tasks are late', 'I must be slipping; my tasks are late.', '["I", "must", "be", "slipping;", "my", "tasks", "are", "late."]'::jsonb),
    (activity_id_var, 'There might be a gap; the checklist is empty', 'There might be a gap; the checklist is empty.', '["There", "might", "be", "a", "gap;", "the", "checklist", "is", "empty."]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 8, 'Build Sentences 2', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'He must have neglected a step; errors piled up', 'He must have neglected a step; errors piled up.', '["He", "must", "have", "neglected", "a", "step;", "errors", "piled", "up."]'::jsonb),
    (activity_id_var, 'She might have upheld the standard; the result is solid', 'She might have upheld the standard; the result is solid.', '["She", "might", "have", "upheld", "the", "standard;", "the", "result", "is", "solid."]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'speaking_practice', 9, 'Talk About Responsibility Signals', 'Practice deduction', '{"prompts": ["How can you tell you’re slipping?", "What must you do next to uphold standards?", "Who notices when you neglect a duty?"]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (
      lesson_id,
      activity_type,
      activity_order,
      title,
      description,
      content
    ) VALUES (
      'B2-L94',
      'speaking_improvement',
      10,
      'Speaking Improvement',
      'Read the improved version of your speech',
      '{"type": "speaking_improvement", "similarityThreshold": 70}'::jsonb
    );
END $$;


