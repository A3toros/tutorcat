-- Script to check and award achievements for existing user progress
-- This will award achievements that users should have earned based on their current progress
-- Run this for a specific user or all users

DO $$
DECLARE
    v_user_record RECORD;
    v_earned_count INTEGER := 0;
BEGIN
    -- Loop through all users
    FOR v_user_record IN 
        SELECT id FROM users
    LOOP
        -- Check and award achievements for this user
        -- The function will only award achievements that haven't been earned yet
        PERFORM check_achievements_on_lesson_complete(v_user_record.id);
        
        -- Count how many achievements were just earned (this is approximate)
        SELECT COUNT(*) INTO v_earned_count
        FROM user_achievements
        WHERE user_id = v_user_record.id;
        
        RAISE NOTICE 'Checked achievements for user % - Total earned: %', v_user_record.id, v_earned_count;
    END LOOP;
    
    RAISE NOTICE 'Finished checking achievements for all users!';
END $$;

-- Alternative: Check achievements for a specific user
-- Replace 'USER_UUID_HERE' with the actual user ID
/*
DO $$
DECLARE
    v_user_id UUID := 'USER_UUID_HERE';
    v_earned_achievements RECORD;
BEGIN
    -- Check and award achievements
    FOR v_earned_achievements IN 
        SELECT * FROM check_achievements_on_lesson_complete(v_user_id)
    LOOP
        RAISE NOTICE 'Awarded achievement: % (%)', v_earned_achievements.achievement_name, v_earned_achievements.achievement_code;
    END LOOP;
END $$;
*/

