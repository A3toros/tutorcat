-- =========================================
-- Pre-fill Database with Sample Lesson Data
-- A1-L61: Kitchen Objects
-- =========================================

DELETE FROM grammar_sentences WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'A1-L61');
DELETE FROM vocabulary_items WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'A1-L61');
DELETE FROM lesson_activities WHERE lesson_id = 'A1-L61';
DELETE FROM lessons WHERE id = 'A1-L61';

INSERT INTO lessons (id, level, lesson_number, topic) VALUES
('A1-L61', 'A1', 61, 'Kitchen Objects')
ON CONFLICT (id) DO UPDATE SET topic = EXCLUDED.topic;

DO $$
DECLARE
    lesson_id_var TEXT := 'A1-L61';
    activity_id_var UUID;
BEGIN
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'warm_up_speaking', 1, 'In the Kitchen', 'Talk about kitchen things', '{"prompt": "Is there a spoon?"}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_intro', 2, 'Kitchen Words', 'Learn kitchen objects', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'spoon', 'ช้อน', NULL),
    (activity_id_var, 'fork', 'ส้อม', NULL),
    (activity_id_var, 'plate', 'จาน', NULL),
    (activity_id_var, 'cup', 'ถ้วย', NULL),
    (activity_id_var, 'bowl', 'ชาม', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_matching_drag', 3, 'Match Kitchen Words', 'Match kitchen words', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'spoon', 'ช้อน', NULL),
    (activity_id_var, 'fork', 'ส้อม', NULL),
    (activity_id_var, 'plate', 'จาน', NULL),
    (activity_id_var, 'cup', 'ถ้วย', NULL),
    (activity_id_var, 'bowl', 'ชาม', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 4, 'Complete the Sentences 1', 'Fill with the correct word', '{"text": "There is a ___. There is a ___.", "blanks": [{"id": "blank1", "text": "spoon", "options": ["spoon", "fork", "plate", "cup"], "correctAnswer": "spoon"}, {"id": "blank2", "text": "fork", "options": ["fork", "bowl", "plate", "cup"], "correctAnswer": "fork"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 5, 'Complete the Sentences 2', 'Fill with the correct word', '{"text": "There is a ___. There are two ___.", "blanks": [{"id": "blank1", "text": "plate", "options": ["plate", "cup", "bowl", "spoon"], "correctAnswer": "plate"}, {"id": "blank2", "text": "cups", "options": ["cups", "bowls", "plates", "forks"], "correctAnswer": "cups"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_explanation', 6, 'There is / There are', 'Talk about items in the kitchen', '{"rules": "Use there is for one; there are for many.\n- There is a spoon.\n- There are two cups.\nAsk: Is there a bowl?", "examples": ["There is a spoon.", "There is a plate.", "There are two cups.", "Is there a bowl?", "Are there two forks?"]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 7, 'Build Sentences 1', 'Arrange words', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'There is a spoon', 'There is a spoon.', '["There", "is", "a", "spoon."]'::jsonb),
    (activity_id_var, 'There are two cups', 'There are two cups.', '["There", "are", "two", "cups."]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 8, 'Build Sentences 2', 'Arrange words', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'Is there a bowl', 'Is there a bowl?', '["Is", "there", "a", "bowl?"]'::jsonb),
    (activity_id_var, 'Are there two forks', 'Are there two forks?', '["Are", "there", "two", "forks?"]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'speaking_practice', 9, 'Talk About Kitchen Items', 'Practice there is/are', '{"prompts": ["Is there a spoon?", "How many cups?", "Is there a bowl?", "Do you have a plate?", "Is there a fork?"]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (
      lesson_id,
      activity_type,
      activity_order,
      title,
      description,
      content
    ) VALUES (
      'A1-L61',
      'speaking_improvement',
      10,
      'Speaking Improvement',
      'Read the improved version of your speech',
      '{"type": "speaking_improvement", "similarityThreshold": 70}'::jsonb
    );
END $$;

