-- =========================================
-- Pre-fill Database with Sample Lesson Data
-- B2-L22: Stress management strategies
-- =========================================

DELETE FROM grammar_sentences WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'B2-L22');
DELETE FROM vocabulary_items WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'B2-L22');
DELETE FROM lesson_activities WHERE lesson_id = 'B2-L22';
DELETE FROM lessons WHERE id = 'B2-L22';

INSERT INTO lessons (id, level, lesson_number, topic) VALUES
('B2-L22', 'B2', 22, 'Stress management strategies')
ON CONFLICT (id) DO UPDATE SET topic = EXCLUDED.topic;

DO $$
DECLARE
    lesson_id_var TEXT := 'B2-L22';
    activity_id_var UUID;
BEGIN
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'warm_up_speaking', 1, 'Coping Review', 'Talk about past tactics', '{"prompt": "What had you tried before these stress tactics, and what worked?"}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_intro', 2, 'Stress Strategy Words', 'Key words for coping', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'breathing', 'การหายใจผ่อนคลาย', NULL),
    (activity_id_var, 'break', 'การพัก', NULL),
    (activity_id_var, 'trigger', 'สิ่งกระตุ้น', NULL),
    (activity_id_var, 'routine', 'กิจวัตร', NULL),
    (activity_id_var, 'unwind', 'ผ่อนคลาย', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_matching_drag', 3, 'Match Strategy Words', 'Match words with meanings', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'breathing', 'การหายใจผ่อนคลาย', NULL),
    (activity_id_var, 'break', 'การพัก', NULL),
    (activity_id_var, 'trigger', 'สิ่งกระตุ้น', NULL),
    (activity_id_var, 'routine', 'กิจวัตร', NULL),
    (activity_id_var, 'unwind', 'ผ่อนคลาย', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 4, 'Complete the Sentences 1', 'Fill with the correct word', '{"text": "A short ___ helps me ___. I track my stress ___.", "blanks": [{"id": "blank1", "text": "break", "options": ["break", "unwind", "breathing", "routine"], "correctAnswer": "break"}, {"id": "blank2", "text": "unwind", "options": ["unwind", "routine", "trigger", "breathing"], "correctAnswer": "unwind"}, {"id": "blank3", "text": "triggers", "options": ["triggers", "routine", "break", "breathing"], "correctAnswer": "triggers"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 5, 'Complete the Sentences 2', 'Fill with the correct word', '{"text": "Deep ___ calms me. A steady ___ keeps me balanced.", "blanks": [{"id": "blank1", "text": "breathing", "options": ["breathing", "break", "trigger", "unwind"], "correctAnswer": "breathing"}, {"id": "blank2", "text": "routine", "options": ["routine", "breathing", "trigger", "unwind"], "correctAnswer": "routine"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_explanation', 6, 'Past Perfect', 'Show what was tried before new strategies', '{"rules": "Use had + past participle to show an earlier past action before another past point.\\n- I had tried music before using breathing exercises.\\n- She had taken breaks before exams started.", "examples": ["I had relied on long breaks before I learned short pauses work.", "They had ignored triggers before the workshop.", "She had never practiced breathing until last term.", "We had tested many routines before this one.", "He had pushed through stress before he burned out."]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 7, 'Build Sentences 1', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'I had relied on long breaks before I learned short pauses work', 'I had relied on long breaks before I learned short pauses work.', '["I", "had", "relied", "on", "long", "breaks", "before", "I", "learned", "short", "pauses", "work."]'::jsonb),
    (activity_id_var, 'She had never practiced breathing until last term', 'She had never practiced breathing until last term.', '["She", "had", "never", "practiced", "breathing", "until", "last", "term."]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 8, 'Build Sentences 2', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'They had ignored triggers before the workshop', 'They had ignored triggers before the workshop.', '["They", "had", "ignored", "triggers", "before", "the", "workshop."]'::jsonb),
    (activity_id_var, 'We had tested many routines before this one', 'We had tested many routines before this one.', '["We", "had", "tested", "many", "routines", "before", "this", "one."]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'speaking_practice', 9, 'Talk About Stress Strategies', 'Practice past perfect reflections', '{"prompts": ["What had you tried before this routine?", "Which trigger had you ignored before learning about it?", "How had you been taking breaks before exams?"]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (
      lesson_id,
      activity_type,
      activity_order,
      title,
      description,
      content
    ) VALUES (
      'B2-L22',
      'speaking_improvement',
      10,
      'Speaking Improvement',
      'Read the improved version of your speech',
      '{"type": "speaking_improvement", "similarityThreshold": 70}'::jsonb
    );
END $$;


