-- =========================================
-- Pre-fill Database with Sample Lesson Data
-- B1-L86: Community Volunteering
-- =========================================

DELETE FROM grammar_sentences WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'B1-L86');
DELETE FROM vocabulary_items WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'B1-L86');
DELETE FROM lesson_activities WHERE lesson_id = 'B1-L86';
DELETE FROM lessons WHERE id = 'B1-L86';

INSERT INTO lessons (id, level, lesson_number, topic) VALUES
('B1-L86', 'B1', 86, 'Community Volunteering')
ON CONFLICT (id) DO UPDATE SET topic = EXCLUDED.topic;

DO $$
DECLARE
    lesson_id_var TEXT := 'B1-L86';
    activity_id_var UUID;
BEGIN
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'warm_up_speaking', 1, 'Local Volunteering', 'Talk about how community projects run', '{"prompt": "How are local events organized where you live?"}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_intro', 2, 'Volunteer Process Words', 'Learn vocabulary about community volunteering', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'organized', 'จัดขึ้น/ถูกจัด', NULL),
    (activity_id_var, 'supported', 'ได้รับการสนับสนุน', NULL),
    (activity_id_var, 'funded', 'ได้รับทุน', NULL),
    (activity_id_var, 'staffed', 'มีเจ้าหน้าที่/อาสา', NULL),
    (activity_id_var, 'appreciated', 'ได้รับการยกย่อง/ชื่นชม', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_matching_drag', 3, 'Match Volunteer Process Words', 'Match words with meanings', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'organized', 'จัดขึ้น/ถูกจัด', NULL),
    (activity_id_var, 'supported', 'ได้รับการสนับสนุน', NULL),
    (activity_id_var, 'funded', 'ได้รับทุน', NULL),
    (activity_id_var, 'staffed', 'มีเจ้าหน้าที่/อาสา', NULL),
    (activity_id_var, 'appreciated', 'ได้รับการยกย่อง/ชื่นชม', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 4, 'Complete the Sentences 1', 'Fill with the correct word', '{"text": "The fair was ___. It was ___ by the city. It was ___ by volunteers.", "blanks": [{"id": "blank1", "text": "organized", "options": ["organized", "supported", "funded", "staffed"], "correctAnswer": "organized"}, {"id": "blank2", "text": "supported", "options": ["supported", "funded", "organized", "appreciated"], "correctAnswer": "supported"}, {"id": "blank3", "text": "staffed", "options": ["staffed", "organized", "funded", "supported"], "correctAnswer": "staffed"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 5, 'Complete the Sentences 2', 'Fill with the correct word', '{"text": "The project was ___. Helpers felt ___. Guests ___ the effort.", "blanks": [{"id": "blank1", "text": "funded", "options": ["funded", "organized", "supported", "staffed"], "correctAnswer": "funded"}, {"id": "blank2", "text": "appreciated", "options": ["appreciated", "supported", "funded", "organized"], "correctAnswer": "appreciated"}, {"id": "blank3", "text": "appreciated", "options": ["appreciated", "staffed", "supported", "funded"], "correctAnswer": "appreciated"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    -- Grammar Explanation: Passive Voice (present) light
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_explanation', 6, 'Passive Voice (Present) for Volunteering', 'Use am/is/are + past participle to describe ongoing processes', '{"rules": "Passive present: am/is/are + past participle. Focus on process/results.\\n- Events are organized by volunteers.\\n- Projects are funded by donations.\\nAvoid contractions.", "examples": ["Events are organized by neighbors.", "Projects are funded by donations.", "Spaces are staffed by volunteers.", "Meals are supported by sponsors.", "Volunteers are appreciated by the community."]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 7, 'Build Sentences 1', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'Events are organized by neighbors', 'Events are organized by neighbors', '["Events", "are", "organized", "by", "neighbors"]'::jsonb),
    (activity_id_var, 'Projects are funded by donations', 'Projects are funded by donations', '["Projects", "are", "funded", "by", "donations"]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 8, 'Build Sentences 2', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'Spaces are staffed by volunteers', 'Spaces are staffed by volunteers', '["Spaces", "are", "staffed", "by", "volunteers"]'::jsonb),
    (activity_id_var, 'Volunteers are appreciated by the community', 'Volunteers are appreciated by the community', '["Volunteers", "are", "appreciated", "by", "the", "community"]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'speaking_practice', 9, 'Talk About Volunteering', 'Practice talking about community volunteering', '{"prompts": ["How are local events organized where you live?", "Who is being helped right now?", "What makes volunteers feel appreciated?"]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (
      lesson_id,
      activity_type,
      activity_order,
      title,
      description,
      content
    ) VALUES (
      'B1-L86',
      'speaking_improvement',
      10,
      'Speaking Improvement',
      'Read the improved version of your speech',
      '{"type": "speaking_improvement", "similarityThreshold": 70}'::jsonb
    );
END $$;

