-- =========================================
-- Pre-fill Database with Sample Lesson Data
-- B1-L22: Teamwork
-- =========================================

DELETE FROM grammar_sentences WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'B1-L22');
DELETE FROM vocabulary_items WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'B1-L22');
DELETE FROM lesson_activities WHERE lesson_id = 'B1-L22';
DELETE FROM lessons WHERE id = 'B1-L22';

INSERT INTO lessons (id, level, lesson_number, topic) VALUES
('B1-L22', 'B1', 22, 'Teamwork')
ON CONFLICT (id) DO UPDATE SET topic = EXCLUDED.topic;

DO $$
DECLARE
    lesson_id_var TEXT := 'B1-L22';
    activity_id_var UUID;
BEGIN
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'warm_up_speaking', 1, 'Sharing News', 'Talk about passing messages in teams', '{"prompt": "How do you pass on feedback without drama?"}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_intro', 2, 'Team Words', 'Learn vocabulary about teamwork', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'assign', 'มอบหมาย', NULL),
    (activity_id_var, 'delegate', 'มอบหมายงาน', NULL),
    (activity_id_var, 'align', 'ปรับให้ตรงกัน', NULL),
    (activity_id_var, 'decide', 'ตัดสินใจ', NULL),
    (activity_id_var, 'update', 'อัปเดต', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_matching_drag', 3, 'Match Team Words', 'Match words with meanings', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'assign', 'มอบหมาย', NULL),
    (activity_id_var, 'delegate', 'มอบหมายงาน', NULL),
    (activity_id_var, 'align', 'ปรับให้ตรงกัน', NULL),
    (activity_id_var, 'decide', 'ตัดสินใจ', NULL),
    (activity_id_var, 'update', 'อัปเดต', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 4, 'Complete the Sentences 1', 'Fill with the correct word', '{"text": "Leads ___ tasks. We ___ work fairly. Teams ___ on goals.", "blanks": [{"id": "blank1", "text": "assign", "options": ["assign", "delegate", "align", "update"], "correctAnswer": "assign"}, {"id": "blank2", "text": "delegate", "options": ["delegate", "align", "decide", "update"], "correctAnswer": "delegate"}, {"id": "blank3", "text": "align", "options": ["align", "assign", "delegate", "decide"], "correctAnswer": "align"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 5, 'Complete the Sentences 2', 'Fill with the correct word', '{"text": "We ___ together after feedback. Someone must ___ quickly. Please ___ the team often.", "blanks": [{"id": "blank1", "text": "align", "options": ["align", "delegate", "decide", "update"], "correctAnswer": "align"}, {"id": "blank2", "text": "decide", "options": ["decide", "assign", "update", "delegate"], "correctAnswer": "decide"}, {"id": "blank3", "text": "update", "options": ["update", "align", "decide", "delegate"], "correctAnswer": "update"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    -- Grammar Explanation: Reported Speech (statements, basic)
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_explanation', 6, 'Reported Speech (Statements)', 'Use said/told + object + that to report statements; shift tenses as needed', '{"rules": "Reported speech for statements: subject + said/told + (object) + that + clause. Shift tenses when reporting past statements.\\n- She said that the tasks were clear.\\n- He told us that the deadline was Friday.\\nUse told + object; said + that + clause.", "examples": ["She said that the update was ready.", "He told us that the deadline was Friday.", "They said that the team was aligned.", "I told them that we needed to decide today.", "The lead said that we would share feedback later."]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 7, 'Build Sentences 1', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'She said that the update was ready', 'She said that the update was ready', '["She", "said", "that", "the", "update", "was", "ready"]'::jsonb),
    (activity_id_var, 'He told us that the deadline was Friday', 'He told us that the deadline was Friday', '["He", "told", "us", "that", "the", "deadline", "was", "Friday"]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 8, 'Build Sentences 2', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'They said that the team was aligned', 'They said that the team was aligned', '["They", "said", "that", "the", "team", "was", "aligned"]'::jsonb),
    (activity_id_var, 'I told them that we needed to decide today', 'I told them that we needed to decide today', '["I", "told", "them", "that", "we", "needed", "to", "decide", "today"]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'speaking_practice', 9, 'Talk About Teamwork', 'Practice talking about teamwork and sharing news', '{"prompts": ["How do you pass on feedback without drama?", "Tell me about sharing news with your team.", "When does teamwork feel great for you?"]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (
      lesson_id,
      activity_type,
      activity_order,
      title,
      description,
      content
    ) VALUES (
      'B1-L22',
      'speaking_improvement',
      10,
      'Speaking Improvement',
      'Read the improved version of your speech',
      '{"type": "speaking_improvement", "similarityThreshold": 70}'::jsonb
    );
END $$;

