-- =========================================
-- Pre-fill Database with Sample Lesson Data
-- B2-L21: Studying abroad experiences
-- =========================================

DELETE FROM grammar_sentences WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'B2-L21');
DELETE FROM vocabulary_items WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'B2-L21');
DELETE FROM lesson_activities WHERE lesson_id = 'B2-L21';
DELETE FROM lessons WHERE id = 'B2-L21';

INSERT INTO lessons (id, level, lesson_number, topic) VALUES
('B2-L21', 'B2', 21, 'Studying abroad experiences')
ON CONFLICT (id) DO UPDATE SET topic = EXCLUDED.topic;

DO $$
DECLARE
    lesson_id_var TEXT := 'B2-L21';
    activity_id_var UUID;
BEGIN
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'warm_up_speaking', 1, 'First Week Abroad', 'Talk about expectations', '{"prompt": "What did you ask hosts before arriving, and who helped you settle?"}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_intro', 2, 'Abroad Words', 'Key words for living abroad', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'visa', 'วีซ่า', NULL),
    (activity_id_var, 'host', 'เจ้าบ้าน/เจ้าภาพ', NULL),
    (activity_id_var, 'adapt', 'ปรับตัว', NULL),
    (activity_id_var, 'homesick', 'คิดถึงบ้าน', NULL),
    (activity_id_var, 'buddy', 'เพื่อนคู่หู', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_matching_drag', 3, 'Match Abroad Words', 'Match words with meanings', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'visa', 'วีซ่า', NULL),
    (activity_id_var, 'host', 'เจ้าบ้าน/เจ้าภาพ', NULL),
    (activity_id_var, 'adapt', 'ปรับตัว', NULL),
    (activity_id_var, 'homesick', 'คิดถึงบ้าน', NULL),
    (activity_id_var, 'buddy', 'เพื่อนคู่หู', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 4, 'Complete the Sentences 1', 'Fill with the correct word', '{"text": "I asked my ___ about the dorm. It took time to ___. My ___ checked on me daily.", "blanks": [{"id": "blank1", "text": "host", "options": ["host", "visa", "adapt", "buddy"], "correctAnswer": "host"}, {"id": "blank2", "text": "adapt", "options": ["adapt", "homesick", "buddy", "visa"], "correctAnswer": "adapt"}, {"id": "blank3", "text": "buddy", "options": ["buddy", "host", "visa", "homesick"], "correctAnswer": "buddy"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 5, 'Complete the Sentences 2', 'Fill with the correct word', '{"text": "I felt ___ the first week. My ___ paperwork was slow.", "blanks": [{"id": "blank1", "text": "homesick", "options": ["homesick", "adapt", "buddy", "host"], "correctAnswer": "homesick"}, {"id": "blank2", "text": "visa", "options": ["visa", "homesick", "adapt", "host"], "correctAnswer": "visa"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_explanation', 6, 'Reported Speech (questions)', 'Report questions you asked abroad', '{"rules": "When reporting questions, use statement word order and backshift if needed. Use ask + wh- for information questions; ask + if/whether for yes/no. Drop do/does/did.\\n- \"Where will I stay?\" → I asked where I would stay.\\n- \"Is the visa ready?\" → They asked if the visa was ready.", "examples": ["I asked where I would stay the first night.", "They asked if my visa was approved.", "She asked how long adaptation takes.", "We asked whether buddies meet us at the airport.", "My buddy asked what food I missed."]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 7, 'Build Sentences 1', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'I asked where I would stay the first night', 'I asked where I would stay the first night.', '["I", "asked", "where", "I", "would", "stay", "the", "first", "night."]'::jsonb),
    (activity_id_var, 'They asked if my visa was approved', 'They asked if my visa was approved.', '["They", "asked", "if", "my", "visa", "was", "approved."]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 8, 'Build Sentences 2', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'She asked how long adaptation takes', 'She asked how long adaptation takes.', '["She", "asked", "how", "long", "adaptation", "takes."]'::jsonb),
    (activity_id_var, 'We asked whether buddies meet us at the airport', 'We asked whether buddies meet us at the airport.', '["We", "asked", "whether", "buddies", "meet", "us", "at", "the", "airport."]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'speaking_practice', 9, 'Talk About Studying Abroad', 'Practice reporting questions', '{"prompts": ["What did you ask before arriving?", "Who helped you settle in the first week?", "How do you describe feeling homesick to friends?"]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (
      lesson_id,
      activity_type,
      activity_order,
      title,
      description,
      content
    ) VALUES (
      'B2-L21',
      'speaking_improvement',
      10,
      'Speaking Improvement',
      'Read the improved version of your speech',
      '{"type": "speaking_improvement", "similarityThreshold": 70}'::jsonb
    );
END $$;


