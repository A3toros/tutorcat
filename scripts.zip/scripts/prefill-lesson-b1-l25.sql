-- =========================================
-- Pre-fill Database with Sample Lesson Data
-- B1-L25: Family Roles
-- =========================================

DELETE FROM grammar_sentences WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'B1-L25');
DELETE FROM vocabulary_items WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'B1-L25');
DELETE FROM lesson_activities WHERE lesson_id = 'B1-L25';
DELETE FROM lessons WHERE id = 'B1-L25';

INSERT INTO lessons (id, level, lesson_number, topic) VALUES
('B1-L25', 'B1', 25, 'Family Roles')
ON CONFLICT (id) DO UPDATE SET topic = EXCLUDED.topic;

DO $$
DECLARE
    lesson_id_var TEXT := 'B1-L25';
    activity_id_var UUID;
BEGIN
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'warm_up_speaking', 1, 'Home Roles', 'Talk about family responsibilities', '{"prompt": "How do you split chores at home?"}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_intro', 2, 'Family Role Words', 'Learn vocabulary about family roles', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'rely on', 'พึ่งพา', NULL),
    (activity_id_var, 'care for', 'ดูแล', NULL),
    (activity_id_var, 'argue with', 'โต้เถียงกับ', NULL),
    (activity_id_var, 'agree on', 'เห็นพ้องใน', NULL),
    (activity_id_var, 'provide for', 'เลี้ยงดู', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_matching_drag', 3, 'Match Family Role Words', 'Match words with meanings', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'rely on', 'พึ่งพา', NULL),
    (activity_id_var, 'care for', 'ดูแล', NULL),
    (activity_id_var, 'argue with', 'โต้เถียงกับ', NULL),
    (activity_id_var, 'agree on', 'เห็นพ้องใน', NULL),
    (activity_id_var, 'provide for', 'เลี้ยงดู', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 4, 'Complete the Sentences 1', 'Fill with the correct word', '{"text": "We ___ each other for help. Parents often ___ children. We try to ___ chores.", "blanks": [{"id": "blank1", "text": "rely on", "options": ["rely on", "care for", "argue with", "agree on"], "correctAnswer": "rely on"}, {"id": "blank2", "text": "care for", "options": ["care for", "provide for", "rely on", "agree on"], "correctAnswer": "care for"}, {"id": "blank3", "text": "agree on", "options": ["agree on", "argue with", "provide for", "rely on"], "correctAnswer": "agree on"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 5, 'Complete the Sentences 2', 'Fill with the correct word', '{"text": "Sometimes we ___ small things. Adults ___ the family. Kids can ___ younger siblings.", "blanks": [{"id": "blank1", "text": "argue with", "options": ["argue with", "rely on", "agree on", "care for"], "correctAnswer": "argue with"}, {"id": "blank2", "text": "provide for", "options": ["provide for", "care for", "argue with", "rely on"], "correctAnswer": "provide for"}, {"id": "blank3", "text": "care for", "options": ["care for", "provide for", "agree on", "rely on"], "correctAnswer": "care for"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    -- Grammar Explanation: Verb + Preposition patterns
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_explanation', 6, 'Verb + Preposition', 'Use correct prepositions after verbs for family roles', '{"rules": "Some verbs take fixed prepositions: rely on, care for, argue with, agree on, provide for. Keep the pair together to sound natural.\\nUse them with objects clearly. Do not drop the preposition.", "examples": ["We rely on each other for help.", "Parents care for their children.", "Siblings sometimes argue with each other.", "We agree on shared rules.", "She provides for her family."]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 7, 'Build Sentences 1', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'We rely on each other for help', 'We rely on each other for help', '["We", "rely", "on", "each", "other", "for", "help"]'::jsonb),
    (activity_id_var, 'Parents care for their children', 'Parents care for their children', '["Parents", "care", "for", "their", "children"]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 8, 'Build Sentences 2', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'We agree on shared rules', 'We agree on shared rules', '["We", "agree", "on", "shared", "rules"]'::jsonb),
    (activity_id_var, 'She provides for her family', 'She provides for her family', '["She", "provides", "for", "her", "family"]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'speaking_practice', 9, 'Talk About Family Roles', 'Practice talking about responsibilities at home', '{"prompts": ["How do you split chores at home?", "When do you rely on family most?", "What do you try to teach younger relatives?"]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (
      lesson_id,
      activity_type,
      activity_order,
      title,
      description,
      content
    ) VALUES (
      'B1-L25',
      'speaking_improvement',
      10,
      'Speaking Improvement',
      'Read the improved version of your speech',
      '{"type": "speaking_improvement", "similarityThreshold": 70}'::jsonb
    );
END $$;

