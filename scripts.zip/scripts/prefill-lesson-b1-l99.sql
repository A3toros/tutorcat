-- =========================================
-- Pre-fill Database with Sample Lesson Data
-- B1-L99: Career Decisions
-- =========================================

DELETE FROM grammar_sentences WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'B1-L99');
DELETE FROM vocabulary_items WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'B1-L99');
DELETE FROM lesson_activities WHERE lesson_id = 'B1-L99';
DELETE FROM lessons WHERE id = 'B1-L99';

INSERT INTO lessons (id, level, lesson_number, topic) VALUES
('B1-L99', 'B1', 99, 'Career Decisions')
ON CONFLICT (id) DO UPDATE SET topic = EXCLUDED.topic;

DO $$
DECLARE
    lesson_id_var TEXT := 'B1-L99';
    activity_id_var UUID;
BEGIN
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'warm_up_speaking', 1, 'Choosing Work', 'Talk about career choices and changes', '{"prompt": "When do you decide it is time to change jobs?"}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_intro', 2, 'Career Words', 'Learn vocabulary about career decisions', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'promotion', 'การเลื่อนตำแหน่ง', NULL),
    (activity_id_var, 'offer', 'ข้อเสนองาน', NULL),
    (activity_id_var, 'resign', 'ลาออก', NULL),
    (activity_id_var, 'benefits', 'สวัสดิการ', NULL),
    (activity_id_var, 'growth', 'การเติบโต', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_matching_drag', 3, 'Match Career Words', 'Match words with meanings', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'promotion', 'การเลื่อนตำแหน่ง', NULL),
    (activity_id_var, 'offer', 'ข้อเสนองาน', NULL),
    (activity_id_var, 'resign', 'ลาออก', NULL),
    (activity_id_var, 'benefits', 'สวัสดิการ', NULL),
    (activity_id_var, 'growth', 'การเติบโต', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 4, 'Complete the Sentences 1', 'Fill with the correct word', '{"text": "I aim for a ___. I just got an ___. The ___ look strong.", "blanks": [{"id": "blank1", "text": "promotion", "options": ["promotion", "offer", "benefits", "growth"], "correctAnswer": "promotion"}, {"id": "blank2", "text": "offer", "options": ["offer", "growth", "resign", "benefits"], "correctAnswer": "offer"}, {"id": "blank3", "text": "benefits", "options": ["benefits", "promotion", "growth", "offer"], "correctAnswer": "benefits"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 5, 'Complete the Sentences 2', 'Fill with the correct word', '{"text": "I may ___. I need more ___. This role offers career ___.", "blanks": [{"id": "blank1", "text": "resign", "options": ["resign", "offer", "promotion", "benefits"], "correctAnswer": "resign"}, {"id": "blank2", "text": "growth", "options": ["growth", "benefits", "offer", "resign"], "correctAnswer": "growth"}, {"id": "blank3", "text": "growth", "options": ["growth", "benefits", "promotion", "offer"], "correctAnswer": "growth"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    -- Grammar Explanation: Reported Speech (statements) reinforcement
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_explanation', 6, 'Reported Speech for Career Talks', 'Use said/told + that to share what others said about jobs', '{"rules": "Reported speech: subject + said/told + (object) + that + clause. Shift tenses when needed.\\n- She said that the offer was fair.\\n- He told me that growth mattered more.\\nUse told + object.", "examples": ["She said that the offer was fair.", "He told me that growth mattered more.", "They said that benefits were improving.", "I told them that I might resign soon.", "My manager said that promotion would take a year."]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 7, 'Build Sentences 1', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'She said that the offer was fair', 'She said that the offer was fair', '["She", "said", "that", "the", "offer", "was", "fair"]'::jsonb),
    (activity_id_var, 'He told me that growth mattered more', 'He told me that growth mattered more', '["He", "told", "me", "that", "growth", "mattered", "more"]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 8, 'Build Sentences 2', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'They said that benefits were improving', 'They said that benefits were improving', '["They", "said", "that", "benefits", "were", "improving"]'::jsonb),
    (activity_id_var, 'I told them that I might resign soon', 'I told them that I might resign soon', '["I", "told", "them", "that", "I", "might", "resign", "soon"]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'speaking_practice', 9, 'Talk About Careers', 'Practice talking about job decisions', '{"prompts": ["When do you decide it is time to change jobs?", "What matters more to you: benefits or growth?", "How do you discuss offers with friends or family?"]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (
      lesson_id,
      activity_type,
      activity_order,
      title,
      description,
      content
    ) VALUES (
      'B1-L99',
      'speaking_improvement',
      10,
      'Speaking Improvement',
      'Read the improved version of your speech',
      '{"type": "speaking_improvement", "similarityThreshold": 70}'::jsonb
    );
END $$;

