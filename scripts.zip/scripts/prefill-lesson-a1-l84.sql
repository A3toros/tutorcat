-- =========================================
-- Pre-fill Database with Sample Lesson Data
-- A1-L84: Crossing the Street
-- =========================================

DELETE FROM grammar_sentences WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'A1-L84');
DELETE FROM vocabulary_items WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'A1-L84');
DELETE FROM lesson_activities WHERE lesson_id = 'A1-L84';
DELETE FROM lessons WHERE id = 'A1-L84';

INSERT INTO lessons (id, level, lesson_number, topic) VALUES
('A1-L84', 'A1', 84, 'Crossing the Street')
ON CONFLICT (id) DO UPDATE SET topic = EXCLUDED.topic;

DO $$
DECLARE
    lesson_id_var TEXT := 'A1-L84';
    activity_id_var UUID;
BEGIN
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'warm_up_speaking', 1, 'Street Safety', 'Talk about crossing', '{"prompt": "Do you look left?"}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_intro', 2, 'Crossing Words', 'Learn crossing words', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'cross', 'ข้าม', NULL),
    (activity_id_var, 'stop', 'หยุด', NULL),
    (activity_id_var, 'look', 'มอง', NULL),
    (activity_id_var, 'left', 'ซ้าย', NULL),
    (activity_id_var, 'right', 'ขวา', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_matching_drag', 3, 'Match Crossing Words', 'Match crossing words', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'cross', 'ข้าม', NULL),
    (activity_id_var, 'stop', 'หยุด', NULL),
    (activity_id_var, 'look', 'มอง', NULL),
    (activity_id_var, 'left', 'ซ้าย', NULL),
    (activity_id_var, 'right', 'ขวา', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 4, 'Complete the Sentences 1', 'Fill with the correct word', '{"text": "__ and __. Then __.", "blanks": [{"id": "blank1", "text": "Stop", "options": ["Stop", "Look", "Cross", "Left"], "correctAnswer": "Stop"}, {"id": "blank2", "text": "look", "options": ["look", "cross", "stop", "right"], "correctAnswer": "look"}, {"id": "blank3", "text": "cross", "options": ["cross", "stop", "look", "left"], "correctAnswer": "cross"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 5, 'Complete the Sentences 2', 'Fill with the correct word', '{"text": "Look ___. Look ___.", "blanks": [{"id": "blank1", "text": "left", "options": ["left", "right", "stop", "cross"], "correctAnswer": "left"}, {"id": "blank2", "text": "right", "options": ["right", "left", "stop", "cross"], "correctAnswer": "right"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_explanation', 6, 'Imperatives (safety)', 'Give street safety commands', '{"rules": "Use base verb to give safe steps.\n- Stop. Look left. Look right. Cross now.\nAdd please for polite tone.", "examples": ["Stop at the road.", "Look left.", "Look right.", "Cross now.", "Do not run."]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 7, 'Build Sentences 1', 'Arrange words', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'Stop at the road', 'Stop at the road.', '["Stop", "at", "the", "road."]'::jsonb),
    (activity_id_var, 'Look left', 'Look left.', '["Look", "left."]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 8, 'Build Sentences 2', 'Arrange words', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'Look right', 'Look right.', '["Look", "right."]'::jsonb),
    (activity_id_var, 'Do not run', 'Do not run.', '["Do", "not", "run."]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'speaking_practice', 9, 'Talk About Crossing', 'Practice safety commands', '{"prompts": ["Do you look left?", "Do you look right?", "Do you stop first?", "Do you run or walk?", "Do you cross now?"]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (
      lesson_id,
      activity_type,
      activity_order,
      title,
      description,
      content
    ) VALUES (
      'A1-L84',
      'speaking_improvement',
      10,
      'Speaking Improvement',
      'Read the improved version of your speech',
      '{"type": "speaking_improvement", "similarityThreshold": 70}'::jsonb
    );
END $$;

