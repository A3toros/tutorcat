-- =========================================
-- Pre-fill Database with Sample Lesson Data
-- B2-L23: Online research skills
-- =========================================

DELETE FROM grammar_sentences WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'B2-L23');
DELETE FROM vocabulary_items WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'B2-L23');
DELETE FROM lesson_activities WHERE lesson_id = 'B2-L23';
DELETE FROM lessons WHERE id = 'B2-L23';

INSERT INTO lessons (id, level, lesson_number, topic) VALUES
('B2-L23', 'B2', 23, 'Online research skills')
ON CONFLICT (id) DO UPDATE SET topic = EXCLUDED.topic;

DO $$
DECLARE
    lesson_id_var TEXT := 'B2-L23';
    activity_id_var UUID;
BEGIN
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'warm_up_speaking', 1, 'Sources You Trust', 'Talk about verifying info', '{"prompt": "When do you trust a source, and where does bias hide?"}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_intro', 2, 'Research Words', 'Key words for checking sources', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'source', 'แหล่งข้อมูล', NULL),
    (activity_id_var, 'verify', 'ตรวจสอบ', NULL),
    (activity_id_var, 'citation', 'การอ้างอิง', NULL),
    (activity_id_var, 'bias', 'อคติ', NULL),
    (activity_id_var, 'archive', 'คลังเก็บ/เอกสารเก่า', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_matching_drag', 3, 'Match Research Words', 'Match words with meanings', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'source', 'แหล่งข้อมูล', NULL),
    (activity_id_var, 'verify', 'ตรวจสอบ', NULL),
    (activity_id_var, 'citation', 'การอ้างอิง', NULL),
    (activity_id_var, 'bias', 'อคติ', NULL),
    (activity_id_var, 'archive', 'คลังเก็บ/เอกสารเก่า', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 4, 'Complete the Sentences 1', 'Fill with the correct word', '{"text": "Check the ___. Always ___ claims. Add a proper ___.", "blanks": [{"id": "blank1", "text": "source", "options": ["source", "verify", "citation", "archive"], "correctAnswer": "source"}, {"id": "blank2", "text": "verify", "options": ["verify", "bias", "archive", "citation"], "correctAnswer": "verify"}, {"id": "blank3", "text": "citation", "options": ["citation", "archive", "verify", "bias"], "correctAnswer": "citation"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 5, 'Complete the Sentences 2', 'Fill with the correct word', '{"text": "Watch for ___. Older studies sit in the ___.", "blanks": [{"id": "blank1", "text": "bias", "options": ["bias", "source", "citation", "verify"], "correctAnswer": "bias"}, {"id": "blank2", "text": "archive", "options": ["archive", "bias", "source", "verify"], "correctAnswer": "archive"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_explanation', 6, 'Contrast & Concession', 'Use whereas/however/although when evaluating sources', '{"rules": "Use although to contrast in one sentence; use however to connect contrasting sentences; use whereas to compare two subjects. Keep parallel structure.\\n- Although the source is popular, it lacks citations.\\n- The article is detailed; however, it shows bias.\\n- This site is peer-reviewed, whereas that blog is not.", "examples": ["Although the headline is strong, the data is weak.", "The author is clear; however, the sources are old.", "This study is peer-reviewed, whereas that post is opinion.", "Although I trust the platform, I still verify quotes.", "The bias is subtle; however, it changes the tone."]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 7, 'Build Sentences 1', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'Although the headline is strong, the data is weak', 'Although the headline is strong, the data is weak.', '["Although", "the", "headline", "is", "strong,", "the", "data", "is", "weak."]'::jsonb),
    (activity_id_var, 'The author is clear; however, the sources are old', 'The author is clear; however, the sources are old.', '["The", "author", "is", "clear;", "however,", "the", "sources", "are", "old."]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 8, 'Build Sentences 2', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'This study is peer-reviewed, whereas that post is opinion', 'This study is peer-reviewed, whereas that post is opinion.', '["This", "study", "is", "peer-reviewed,", "whereas", "that", "post", "is", "opinion."]'::jsonb),
    (activity_id_var, 'Although I trust the platform, I still verify quotes', 'Although I trust the platform, I still verify quotes.', '["Although", "I", "trust", "the", "platform,", "I", "still", "verify", "quotes."]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'speaking_practice', 9, 'Talk About Source Checking', 'Practice contrasts in research', '{"prompts": ["When do you trust a source?", "Where does bias hide in your feeds?", "How do you verify before you cite?"]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (
      lesson_id,
      activity_type,
      activity_order,
      title,
      description,
      content
    ) VALUES (
      'B2-L23',
      'speaking_improvement',
      10,
      'Speaking Improvement',
      'Read the improved version of your speech',
      '{"type": "speaking_improvement", "similarityThreshold": 70}'::jsonb
    );
END $$;


