-- =========================================
-- Pre-fill Database with Sample Lesson Data
-- A1-L72: Snacks
-- =========================================

DELETE FROM grammar_sentences WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'A1-L72');
DELETE FROM vocabulary_items WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'A1-L72');
DELETE FROM lesson_activities WHERE lesson_id = 'A1-L72';
DELETE FROM lessons WHERE id = 'A1-L72';

INSERT INTO lessons (id, level, lesson_number, topic) VALUES
('A1-L72', 'A1', 72, 'Snacks')
ON CONFLICT (id) DO UPDATE SET topic = EXCLUDED.topic;

DO $$
DECLARE
    lesson_id_var TEXT := 'A1-L72';
    activity_id_var UUID;
BEGIN
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'warm_up_speaking', 1, 'Snacks', 'Talk about snacks', '{"prompt": "Do you like snacks?"}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_intro', 2, 'Snack Words', 'Learn snack words', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'snack', 'ของว่าง', NULL),
    (activity_id_var, 'chips', 'มันฝรั่งทอด', NULL),
    (activity_id_var, 'cookie', 'คุกกี้', NULL),
    (activity_id_var, 'candy', 'ลูกอม', NULL),
    (activity_id_var, 'fruit', 'ผลไม้', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_matching_drag', 3, 'Match Snack Words', 'Match snack words', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'snack', 'ของว่าง', NULL),
    (activity_id_var, 'chips', 'มันฝรั่งทอด', NULL),
    (activity_id_var, 'cookie', 'คุกกี้', NULL),
    (activity_id_var, 'candy', 'ลูกอม', NULL),
    (activity_id_var, 'fruit', 'ผลไม้', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 4, 'Complete the Sentences 1', 'Fill with the correct word', '{"text": "Do you want some ___? Do you want some ___?", "blanks": [{"id": "blank1", "text": "chips", "options": ["chips", "snack", "cookie", "candy"], "correctAnswer": "chips"}, {"id": "blank2", "text": "fruit", "options": ["fruit", "candy", "cookie", "snack"], "correctAnswer": "fruit"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 5, 'Complete the Sentences 2', 'Fill with the correct word', '{"text": "I like ___. I do not like ___.", "blanks": [{"id": "blank1", "text": "cookies", "options": ["cookies", "chips", "fruit", "candy"], "correctAnswer": "cookies"}, {"id": "blank2", "text": "candy", "options": ["candy", "chips", "cookie", "fruit"], "correctAnswer": "candy"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_explanation', 6, 'Some + Count/Uncount', 'Offer snacks politely', '{"rules": "Use some for offers and positives.\n- Do you want some chips?\n- I have some fruit.", "examples": ["Do you want some chips?", "Do you want some fruit?", "I have some cookies.", "We have some candy.", "I want some snacks."]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 7, 'Build Sentences 1', 'Arrange words', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'Do you want some chips', 'Do you want some chips?', '["Do", "you", "want", "some", "chips?"]'::jsonb),
    (activity_id_var, 'I have some fruit', 'I have some fruit.', '["I", "have", "some", "fruit."]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 8, 'Build Sentences 2', 'Arrange words', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'We have some candy', 'We have some candy.', '["We", "have", "some", "candy."]'::jsonb),
    (activity_id_var, 'Do you want some fruit', 'Do you want some fruit?', '["Do", "you", "want", "some", "fruit?"]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'speaking_practice', 9, 'Talk About Snacks', 'Practice snack offers', '{"prompts": ["Do you like snacks?", "Do you want some chips?", "Do you like cookies?", "Do you like candy?", "Do you eat fruit?"]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (
      lesson_id,
      activity_type,
      activity_order,
      title,
      description,
      content
    ) VALUES (
      'A1-L72',
      'speaking_improvement',
      10,
      'Speaking Improvement',
      'Read the improved version of your speech',
      '{"type": "speaking_improvement", "similarityThreshold": 70}'::jsonb
    );
END $$;

