-- =========================================
-- Pre-fill Database with Sample Lesson Data
-- A2-L9: Sports & Activities
-- =========================================

-- Clear existing sample data for A2-L9 (optional - comment out if you want to keep existing data)
DELETE FROM grammar_sentences WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'A2-L9');
DELETE FROM vocabulary_items WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'A2-L9');
DELETE FROM lesson_activities WHERE lesson_id = 'A2-L9';
DELETE FROM lessons WHERE id = 'A2-L9';

INSERT INTO lessons (id, level, lesson_number, topic) VALUES
('A2-L9', 'A2', 9, 'Sports & Activities')
ON CONFLICT (id) DO UPDATE SET topic = EXCLUDED.topic;

DO $$
DECLARE
    lesson_id_var TEXT := 'A2-L9';
    activity_id_var UUID;
BEGIN
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content) VALUES (lesson_id_var, 'warm_up_speaking', 1, 'Sports Talk', 'Talk about sports and activities', '{"prompt": "What sports do you like?"}'::jsonb) RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content) VALUES (lesson_id_var, 'vocabulary_intro', 2, 'Sports Words', 'Learn sports vocabulary', '{}'::jsonb) RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'football', 'ฟุตบอล', NULL),
    (activity_id_var, 'basketball', 'บาสเก็ตบอล', NULL),
    (activity_id_var, 'swimming', 'ว่ายน้ำ', NULL),
    (activity_id_var, 'running', 'วิ่ง', NULL),
    (activity_id_var, 'playing', 'เล่น', NULL);

    -- 3. Vocabulary Matching Drag #1 (5 pairs - same words)
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content) VALUES (lesson_id_var, 'vocabulary_matching_drag', 3, 'Match Sports 1', 'Match English words with Thai meanings', '{}'::jsonb) RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'football', 'ฟุตบอล', NULL),
    (activity_id_var, 'basketball', 'บาสเก็ตบอล', NULL),
    (activity_id_var, 'swimming', 'ว่ายน้ำ', NULL),
    (activity_id_var, 'running', 'วิ่ง', NULL),
    (activity_id_var, 'playing', 'เล่น', NULL);


    -- 4. Vocabulary Fill Blanks #1 (4 words: football, basketball, swimming, running - playing left out)
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content) VALUES (lesson_id_var, 'vocabulary_fill_blanks', 4, 'Complete the Sentences 1', 'Fill in the blanks with correct words', '{"text": "I like to play ___. He plays ___ in the park. She goes ___ in the pool. I enjoy ___ every morning.", "blanks": [{"id": "blank1", "text": "football", "options": ["football", "basketball", "swimming", "running"], "correctAnswer": "football"}, {"id": "blank2", "text": "basketball", "options": ["football", "basketball", "swimming", "running"], "correctAnswer": "basketball"}, {"id": "blank3", "text": "swimming", "options": ["football", "basketball", "swimming", "running"], "correctAnswer": "swimming"}, {"id": "blank4", "text": "running", "options": ["football", "basketball", "swimming", "running"], "correctAnswer": "running"}]}'::jsonb) RETURNING id INTO activity_id_var;

    -- 4. Vocabulary Fill Blanks #2 (4 words: football, basketball, swimming, playing - running left out)
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content) VALUES (lesson_id_var, 'vocabulary_fill_blanks', 5, 'Complete the Sentences 2', 'Fill in the blanks with correct words', '{"text": "My favorite sport is ___. We play ___ at school. I go ___ on holidays. She enjoys ___ with friends.", "blanks": [{"id": "blank1", "text": "football", "options": ["football", "basketball", "swimming", "playing"], "correctAnswer": "football"}, {"id": "blank2", "text": "basketball", "options": ["football", "basketball", "swimming", "playing"], "correctAnswer": "basketball"}, {"id": "blank3", "text": "swimming", "options": ["football", "basketball", "swimming", "playing"], "correctAnswer": "swimming"}, {"id": "blank4", "text": "playing", "options": ["football", "basketball", "swimming", "playing"], "correctAnswer": "playing"}]}'::jsonb) RETURNING id INTO activity_id_var;

    -- 4. Grammar Explanation (5 examples - CEFR A2: Play/Go/Do with sports)
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content) VALUES (lesson_id_var, 'grammar_explanation', 6, 'Sports Verbs - Play/Go/Do', 'Learn sports verbs', '{"rules": "Use the right verb with sports and activities:\n\n- Play + ball sports (play football, play basketball)\n- Go + -ing sports (go swimming, go running)\n- Do + other activities (do exercise, do homework)\n- Questions: Do you play...? (Do you play tennis?)\n- Negative: I don''t play... (I don''t play football)", "examples": ["I play football every week.", "She goes swimming at the pool.", "We do exercise in the morning.", "Do you play basketball?", "He doesn''t play tennis."]}'::jsonb) RETURNING id INTO activity_id_var;
    -- 4. Grammar Sentences #1
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content) VALUES (lesson_id_var, 'grammar_sentences', 7, 'Build Sentences 1', 'Arrange words to make sentences', '{}'::jsonb) RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'I play football every week', 'I play football every week', '["I", "play", "football", "every", "week"]'::jsonb),
    (activity_id_var, 'She goes swimming at the pool', 'She goes swimming at the pool', '["She", "goes", "swimming", "at", "the", "pool"]'::jsonb);
    -- 4. Grammar Sentences #2
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content) VALUES (lesson_id_var, 'grammar_sentences', 8, 'Build Sentences 2', 'Arrange words to make sentences', '{}'::jsonb) RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'Do you play basketball', 'Do you play basketball?', '["Do", "you", "play", "basketball?"]'::jsonb),
    (activity_id_var, 'He doesn t play tennis', 'He doesn''t play tennis', '["He", "doesn''t", "play", "tennis"]'::jsonb);
    -- 4. Speaking Practice (5 prompts - CEFR A2: Sports and activities)
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content) VALUES (lesson_id_var, 'speaking_practice', 9, 'Talk About Sports', 'Practice talking about sports', '{"prompts": ["What sports can you play?", "Can you go swimming? Where?", "What games do you like to play?", "Can you play football or another team sport?", "What activities do you do with friends in your free time?"]}'::jsonb) RETURNING id INTO activity_id_var;

END $$;
