-- =========================================
-- Pre-fill Database with Sample Lesson Data
-- B1-L84: Giving Health Advice
-- =========================================

DELETE FROM grammar_sentences WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'B1-L84');
DELETE FROM vocabulary_items WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'B1-L84');
DELETE FROM lesson_activities WHERE lesson_id = 'B1-L84';
DELETE FROM lessons WHERE id = 'B1-L84';

INSERT INTO lessons (id, level, lesson_number, topic) VALUES
('B1-L84', 'B1', 84, 'Giving Health Advice')
ON CONFLICT (id) DO UPDATE SET topic = EXCLUDED.topic;

DO $$
DECLARE
    lesson_id_var TEXT := 'B1-L84';
    activity_id_var UUID;
BEGIN
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'warm_up_speaking', 1, 'Advice for Friends', 'Talk about giving health tips', '{"prompt": "If a friend feels ill, what do you say first?"}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_intro', 2, 'Health Advice Words', 'Learn vocabulary about giving health advice', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'hydrate', 'ดื่มน้ำให้เพียงพอ', NULL),
    (activity_id_var, 'rest', 'พักผ่อน', NULL),
    (activity_id_var, 'consult', 'ปรึกษา', NULL),
    (activity_id_var, 'prevent', 'ป้องกัน', NULL),
    (activity_id_var, 'recover', 'ฟื้นตัว', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_matching_drag', 3, 'Match Health Advice Words', 'Match words with meanings', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'hydrate', 'ดื่มน้ำให้เพียงพอ', NULL),
    (activity_id_var, 'rest', 'พักผ่อน', NULL),
    (activity_id_var, 'consult', 'ปรึกษา', NULL),
    (activity_id_var, 'prevent', 'ป้องกัน', NULL),
    (activity_id_var, 'recover', 'ฟื้นตัว', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 4, 'Complete the Sentences 1', 'Fill with the correct word', '{"text": "Drink water to ___. Take a day to ___. If unsure, ___ a doctor.", "blanks": [{"id": "blank1", "text": "hydrate", "options": ["hydrate", "rest", "consult", "recover"], "correctAnswer": "hydrate"}, {"id": "blank2", "text": "rest", "options": ["rest", "prevent", "recover", "consult"], "correctAnswer": "rest"}, {"id": "blank3", "text": "consult", "options": ["consult", "hydrate", "recover", "prevent"], "correctAnswer": "consult"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 5, 'Complete the Sentences 2', 'Fill with the correct word', '{"text": "Wash hands to ___. Sleep helps you ___. Good habits speed ___.", "blanks": [{"id": "blank1", "text": "prevent", "options": ["prevent", "recover", "hydrate", "rest"], "correctAnswer": "prevent"}, {"id": "blank2", "text": "recover", "options": ["recover", "prevent", "rest", "consult"], "correctAnswer": "recover"}, {"id": "blank3", "text": "recovery", "options": ["recovery", "prevent", "rest", "hydrate"], "correctAnswer": "recovery"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    -- Grammar Explanation: Zero + First Conditional blend (health advice)
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_explanation', 6, 'Zero and First Conditional for Health Advice', 'Use zero for general truths; first for likely results if action is taken', '{"rules": "Zero conditional: If + present, present for general truths. First conditional: If + present, will + base verb for likely results.\\n- If you rest, you recover faster.\\n- If you feel dizzy, you will call a doctor.\\nNo contractions.", "examples": ["If you rest, you recover faster.", "If you drink water, you feel better.", "If symptoms stay, you will consult a doctor.", "If you prevent germs, you stay healthy.", "If you take advice early, you will recover sooner."]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 7, 'Build Sentences 1', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'If you rest you recover faster', 'If you rest, you recover faster', '["If", "you", "rest,", "you", "recover", "faster"]'::jsonb),
    (activity_id_var, 'If you drink water you feel better', 'If you drink water, you feel better', '["If", "you", "drink", "water,", "you", "feel", "better"]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 8, 'Build Sentences 2', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'If symptoms stay you will consult a doctor', 'If symptoms stay, you will consult a doctor', '["If", "symptoms", "stay,", "you", "will", "consult", "a", "doctor"]'::jsonb),
    (activity_id_var, 'If you take advice early you will recover sooner', 'If you take advice early, you will recover sooner', '["If", "you", "take", "advice", "early,", "you", "will", "recover", "sooner"]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'speaking_practice', 9, 'Talk About Health Advice', 'Practice talking about giving health tips', '{"prompts": ["If a friend feels ill, what do you say first?", "What advice always seems to work for you?", "When should someone see a doctor?"]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (
      lesson_id,
      activity_type,
      activity_order,
      title,
      description,
      content
    ) VALUES (
      'B1-L84',
      'speaking_improvement',
      10,
      'Speaking Improvement',
      'Read the improved version of your speech',
      '{"type": "speaking_improvement", "similarityThreshold": 70}'::jsonb
    );
END $$;

