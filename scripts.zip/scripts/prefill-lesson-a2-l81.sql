-- =========================================
-- Pre-fill Database with Sample Lesson Data
-- A2-L81: Asking for Directions
-- =========================================

DELETE FROM grammar_sentences WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'A2-L81');
DELETE FROM vocabulary_items WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'A2-L81');
DELETE FROM lesson_activities WHERE lesson_id = 'A2-L81';
DELETE FROM lessons WHERE id = 'A2-L81';

INSERT INTO lessons (id, level, lesson_number, topic) VALUES
('A2-L81', 'A2', 81, 'Asking for Directions')
ON CONFLICT (id) DO UPDATE SET topic = EXCLUDED.topic;

DO $$
DECLARE
    lesson_id_var TEXT := 'A2-L81';
    activity_id_var UUID;
BEGIN
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'warm_up_speaking', 1, 'Direction Help', 'Talk about asking for places', '{"prompt": "How do you ask for directions?"}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_intro', 2, 'Direction Words', 'Learn basic direction words', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'left', 'ซ้าย', NULL),
    (activity_id_var, 'right', 'ขวา', NULL),
    (activity_id_var, 'straight', 'ตรงไป', NULL),
    (activity_id_var, 'corner', 'มุม', NULL),
    (activity_id_var, 'across', 'ข้าม/ตรงข้าม', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_matching_drag', 3, 'Match Direction Words', 'Match direction words', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'left', 'ซ้าย', NULL),
    (activity_id_var, 'right', 'ขวา', NULL),
    (activity_id_var, 'straight', 'ตรงไป', NULL),
    (activity_id_var, 'corner', 'มุม', NULL),
    (activity_id_var, 'across', 'ข้าม/ตรงข้าม', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 4, 'Complete the Sentences 1', 'Fill with the correct word', '{"text": "Go ___. Turn ___. The shop is on the ___.", "blanks": [{"id": "blank1", "text": "straight", "options": ["straight", "left", "right", "corner"], "correctAnswer": "straight"}, {"id": "blank2", "text": "left", "options": ["left", "right", "straight", "across"], "correctAnswer": "left"}, {"id": "blank3", "text": "corner", "options": ["corner", "across", "left", "right"], "correctAnswer": "corner"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 5, 'Complete the Sentences 2', 'Fill with the correct word', '{"text": "The bank is ___. The cafe is ___.", "blanks": [{"id": "blank1", "text": "across", "options": ["across", "straight", "corner", "left"], "correctAnswer": "across"}, {"id": "blank2", "text": "right", "options": ["right", "left", "across", "corner"], "correctAnswer": "right"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_explanation', 6, 'Imperatives for Directions', 'Give simple direction commands', '{"rules": "Use base verb for directions; add please for polite tone.\n- Go straight. Turn left. Stop at the corner.\nUse prepositions: across from, next to, on the right.", "examples": ["Go straight and turn left.", "Stop at the second corner.", "The bank is across from the park.", "Walk to the end of the street.", "Turn right at the light."]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 7, 'Build Sentences 1', 'Arrange words', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'Go straight and turn left', 'Go straight and turn left.', '["Go", "straight", "and", "turn", "left."]'::jsonb),
    (activity_id_var, 'Stop at the second corner', 'Stop at the second corner.', '["Stop", "at", "the", "second", "corner."]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 8, 'Build Sentences 2', 'Arrange words', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'The bank is across from the park', 'The bank is across from the park.', '["The", "bank", "is", "across", "from", "the", "park."]'::jsonb),
    (activity_id_var, 'Turn right at the light', 'Turn right at the light.', '["Turn", "right", "at", "the", "light."]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'speaking_practice', 9, 'Ask for Directions', 'Practice direction questions', '{"prompts": ["How do you ask for directions politely?", "Can you say: \"Turn left\" or \"Go straight\"?", "How do you explain where a place is?", "Do you use landmarks when giving directions?", "What do you do if you get lost?"]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (
      lesson_id,
      activity_type,
      activity_order,
      title,
      description,
      content
    ) VALUES (
      'A2-L81',
      'speaking_improvement',
      10,
      'Speaking Improvement',
      'Read the improved version of your speech',
      '{"type": "speaking_improvement", "similarityThreshold": 70}'::jsonb
    );
END $$;

