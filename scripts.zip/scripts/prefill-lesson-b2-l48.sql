-- =========================================
-- Pre-fill Database with Sample Lesson Data
-- B2-L48: Assessments and grading systems
-- =========================================

DELETE FROM grammar_sentences WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'B2-L48');
DELETE FROM vocabulary_items WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'B2-L48');
DELETE FROM lesson_activities WHERE lesson_id = 'B2-L48';
DELETE FROM lessons WHERE id = 'B2-L48';

INSERT INTO lessons (id, level, lesson_number, topic) VALUES
('B2-L48', 'B2', 48, 'Assessments and grading systems')
ON CONFLICT (id) DO UPDATE SET topic = EXCLUDED.topic;

DO $$
DECLARE
    lesson_id_var TEXT := 'B2-L48';
    activity_id_var UUID;
BEGIN
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'warm_up_speaking', 1, 'Assessment Plans', 'Talk about how grading works', '{"prompt": "How will you be graded this term, and what will you contest if unclear?"}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_intro', 2, 'Assessment Words', 'Key words for grading', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'rubric', 'เกณฑ์การให้คะแนน', NULL),
    (activity_id_var, 'curve', 'การปรับคะแนนแบบโค้ง', NULL),
    (activity_id_var, 'resit', 'สอบซ่อม/สอบใหม่', NULL),
    (activity_id_var, 'criteria', 'เกณฑ์', NULL),
    (activity_id_var, 'transparency', 'ความโปร่งใส', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_matching_drag', 3, 'Match Assessment Words', 'Match words with meanings', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'rubric', 'เกณฑ์การให้คะแนน', NULL),
    (activity_id_var, 'curve', 'การปรับคะแนนแบบโค้ง', NULL),
    (activity_id_var, 'resit', 'สอบซ่อม/สอบใหม่', NULL),
    (activity_id_var, 'criteria', 'เกณฑ์', NULL),
    (activity_id_var, 'transparency', 'ความโปร่งใส', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 4, 'Complete the Sentences 1', 'Fill with the correct word', '{"text": "The ___ shows the ___. A ___ may change scores.", "blanks": [{"id": "blank1", "text": "rubric", "options": ["rubric", "criteria", "curve", "resit"], "correctAnswer": "rubric"}, {"id": "blank2", "text": "criteria", "options": ["criteria", "curve", "transparency", "resit"], "correctAnswer": "criteria"}, {"id": "blank3", "text": "curve", "options": ["curve", "rubric", "resit", "criteria"], "correctAnswer": "curve"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 5, 'Complete the Sentences 2', 'Fill with the correct word', '{"text": "I want ___. I plan a ___ if needed.", "blanks": [{"id": "blank1", "text": "transparency", "options": ["transparency", "curve", "rubric", "resit"], "correctAnswer": "transparency"}, {"id": "blank2", "text": "resit", "options": ["resit", "criteria", "curve", "transparency"], "correctAnswer": "resit"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_explanation', 6, 'Future Continuous', 'Discuss grading in progress', '{"rules": "Use will be + -ing for actions in progress at a future time or over a period.\\n- This term, we will be grading with a new rubric.\\n- At midterm, they will be reviewing criteria.", "examples": ["This term, the course will be using a clearer rubric.", "At midterm, teachers will be reviewing transparency concerns.", "We will be applying the curve after all scores are in.", "Students will be requesting resits next month.", "The team will be updating criteria this week."]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 7, 'Build Sentences 1', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'This term, the course will be using a clearer rubric', 'This term, the course will be using a clearer rubric.', '["This", "term,", "the", "course", "will", "be", "using", "a", "clearer", "rubric."]'::jsonb),
    (activity_id_var, 'At midterm, teachers will be reviewing transparency concerns', 'At midterm, teachers will be reviewing transparency concerns.', '["At", "midterm,", "teachers", "will", "be", "reviewing", "transparency", "concerns."]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 8, 'Build Sentences 2', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'We will be applying the curve after all scores are in', 'We will be applying the curve after all scores are in.', '["We", "will", "be", "applying", "the", "curve", "after", "all", "scores", "are", "in."]'::jsonb),
    (activity_id_var, 'Students will be requesting resits next month', 'Students will be requesting resits next month.', '["Students", "will", "be", "requesting", "resits", "next", "month."]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'speaking_practice', 9, 'Talk About Grading', 'Practice future continuous', '{"prompts": ["How will you be graded this term?", "What will you contest if unclear?", "When will you request a resit?"]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (
      lesson_id,
      activity_type,
      activity_order,
      title,
      description,
      content
    ) VALUES (
      'B2-L48',
      'speaking_improvement',
      10,
      'Speaking Improvement',
      'Read the improved version of your speech',
      '{"type": "speaking_improvement", "similarityThreshold": 70}'::jsonb
    );
END $$;


