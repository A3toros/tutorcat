-- =========================================
-- Pre-fill Database with Sample Lesson Data
-- A2-L98: Talking About Fear
-- =========================================

DELETE FROM grammar_sentences WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'A2-L98');
DELETE FROM vocabulary_items WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'A2-L98');
DELETE FROM lesson_activities WHERE lesson_id = 'A2-L98';
DELETE FROM lessons WHERE id = 'A2-L98';

INSERT INTO lessons (id, level, lesson_number, topic) VALUES
('A2-L98', 'A2', 98, 'Talking About Fear')
ON CONFLICT (id) DO UPDATE SET topic = EXCLUDED.topic;

DO $$
DECLARE
    lesson_id_var TEXT := 'A2-L98';
    activity_id_var UUID;
BEGIN
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'warm_up_speaking', 1, 'Feeling Scared', 'Talk about fear and support', '{"prompt": "Who can help you when you feel scared?"}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_intro', 2, 'Fear Words', 'Learn words about fear and safety', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'scared', 'กลัว', NULL),
    (activity_id_var, 'safe', 'ปลอดภัย', NULL),
    (activity_id_var, 'help', 'ช่วยเหลือ', NULL),
    (activity_id_var, 'stay', 'อยู่/พัก', NULL),
    (activity_id_var, 'call', 'โทร', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_matching_drag', 3, 'Match Fear Words', 'Match fear and safety words', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'scared', 'กลัว', NULL),
    (activity_id_var, 'safe', 'ปลอดภัย', NULL),
    (activity_id_var, 'help', 'ช่วยเหลือ', NULL),
    (activity_id_var, 'stay', 'อยู่/พัก', NULL),
    (activity_id_var, 'call', 'โทร', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 4, 'Complete the Sentences 1', 'Fill with the correct word', '{"text": "I feel ___. Please ___ with me. I want to feel ___.", "blanks": [{"id": "blank1", "text": "scared", "options": ["scared", "safe", "help", "call"], "correctAnswer": "scared"}, {"id": "blank2", "text": "stay", "options": ["stay", "help", "call", "safe"], "correctAnswer": "stay"}, {"id": "blank3", "text": "safe", "options": ["safe", "scared", "help", "call"], "correctAnswer": "safe"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 5, 'Complete the Sentences 2', 'Fill with the correct word', '{"text": "Can you ___ someone? I need ___.", "blanks": [{"id": "blank1", "text": "call", "options": ["call", "stay", "safe", "scared"], "correctAnswer": "call"}, {"id": "blank2", "text": "help", "options": ["help", "call", "stay", "safe"], "correctAnswer": "help"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_explanation', 6, 'Can for Permission/Support', 'Ask for help and safety', '{"rules": "Use can to ask for help/support politely.\n- Can you stay with me?\n- Can you call someone?\nUse short answers: Yes, I can. No, I can''t.", "examples": ["Can you stay with me?", "Can you call someone?", "Can you help me feel safe?", "Can I sit here?", "Can I call my friend now?"]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 7, 'Build Sentences 1', 'Arrange words', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'Can you stay with me', 'Can you stay with me?', '["Can", "you", "stay", "with", "me?"]'::jsonb),
    (activity_id_var, 'Can you call someone', 'Can you call someone?', '["Can", "you", "call", "someone?"]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 8, 'Build Sentences 2', 'Arrange words', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'Can you help me feel safe', 'Can you help me feel safe?', '["Can", "you", "help", "me", "feel", "safe?"]'::jsonb),
    (activity_id_var, 'Can I call my friend now', 'Can I call my friend now?', '["Can", "I", "call", "my", "friend", "now?"]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'speaking_practice', 9, 'Talk About Fear', 'Practice asking for support', '{"prompts": ["Who can help you when you feel scared?", "Can you call someone for support?", "Can you ask someone to stay with you?", "What can you do to feel safer?", "What helps you overcome fear?"]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (
      lesson_id,
      activity_type,
      activity_order,
      title,
      description,
      content
    ) VALUES (
      'A2-L98',
      'speaking_improvement',
      10,
      'Speaking Improvement',
      'Read the improved version of your speech',
      '{"type": "speaking_improvement", "similarityThreshold": 70}'::jsonb
    );
END $$;

