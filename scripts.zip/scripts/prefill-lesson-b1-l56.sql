-- =========================================
-- Pre-fill Database with Sample Lesson Data
-- B1-L56: Remote Learning
-- =========================================

DELETE FROM grammar_sentences WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'B1-L56');
DELETE FROM vocabulary_items WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'B1-L56');
DELETE FROM lesson_activities WHERE lesson_id = 'B1-L56';
DELETE FROM lessons WHERE id = 'B1-L56';

INSERT INTO lessons (id, level, lesson_number, topic) VALUES
('B1-L56', 'B1', 56, 'Remote Learning')
ON CONFLICT (id) DO UPDATE SET topic = EXCLUDED.topic;

DO $$
DECLARE
    lesson_id_var TEXT := 'B1-L56';
    activity_id_var UUID;
BEGIN
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'warm_up_speaking', 1, 'Studying Online', 'Talk about how online study affects you', '{"prompt": "How will online learning change your study life?"}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_intro', 2, 'Learning Words', 'Learn vocabulary about remote learning', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'platform', 'แพลตฟอร์ม', NULL),
    (activity_id_var, 'module', 'หน่วยการเรียน', NULL),
    (activity_id_var, 'submit', 'ส่ง', NULL),
    (activity_id_var, 'access', 'เข้าถึง', NULL),
    (activity_id_var, 'interact', 'โต้ตอบ', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_matching_drag', 3, 'Match Learning Words', 'Match words with meanings', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'platform', 'แพลตฟอร์ม', NULL),
    (activity_id_var, 'module', 'หน่วยการเรียน', NULL),
    (activity_id_var, 'submit', 'ส่ง', NULL),
    (activity_id_var, 'access', 'เข้าถึง', NULL),
    (activity_id_var, 'interact', 'โต้ตอบ', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 4, 'Complete the Sentences 1', 'Fill with the correct word', '{"text": "The course ___ is stable. This ___ covers week one. We must ___ homework online.", "blanks": [{"id": "blank1", "text": "platform", "options": ["platform", "module", "submit", "access"], "correctAnswer": "platform"}, {"id": "blank2", "text": "module", "options": ["module", "platform", "access", "interact"], "correctAnswer": "module"}, {"id": "blank3", "text": "submit", "options": ["submit", "access", "platform", "interact"], "correctAnswer": "submit"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 5, 'Complete the Sentences 2', 'Fill with the correct word', '{"text": "We ___ files easily. Students ___ in live sessions. I can ___ lessons anytime.", "blanks": [{"id": "blank1", "text": "access", "options": ["access", "submit", "module", "platform"], "correctAnswer": "access"}, {"id": "blank2", "text": "interact", "options": ["interact", "access", "submit", "platform"], "correctAnswer": "interact"}, {"id": "blank3", "text": "access", "options": ["access", "interact", "submit", "platform"], "correctAnswer": "access"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    -- Grammar Explanation: Future (will vs going to) — online learning plans
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_explanation', 6, 'Future: Will vs Going To (Remote Learning)', 'Use will for quick decisions/uncertainty; going to for planned changes', '{"rules": "Use will for quick decisions or uncertainty. Use going to for planned actions and intentions.\\n- I am going to block time for online classes.\\n- We will see if this platform works better.\\nAvoid contractions.", "examples": ["I am going to block time for online classes.", "We will see if this platform works better.", "She is going to submit assignments earlier.", "They will decide on live sessions later.", "He is going to interact more in discussions."]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 7, 'Build Sentences 1', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'I am going to block time for online classes', 'I am going to block time for online classes', '["I", "am", "going", "to", "block", "time", "for", "online", "classes"]'::jsonb),
    (activity_id_var, 'We will see if this platform works better', 'We will see if this platform works better', '["We", "will", "see", "if", "this", "platform", "works", "better"]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 8, 'Build Sentences 2', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'She is going to submit assignments earlier', 'She is going to submit assignments earlier', '["She", "is", "going", "to", "submit", "assignments", "earlier"]'::jsonb),
    (activity_id_var, 'They will decide on live sessions later', 'They will decide on live sessions later', '["They", "will", "decide", "on", "live", "sessions", "later"]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'speaking_practice', 9, 'Talk About Remote Learning', 'Practice talking about studying online', '{"prompts": ["How will online learning change your study life?", "What are you going to improve in your habits?", "When do you still prefer in-person classes?"]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (
      lesson_id,
      activity_type,
      activity_order,
      title,
      description,
      content
    ) VALUES (
      'B1-L56',
      'speaking_improvement',
      10,
      'Speaking Improvement',
      'Read the improved version of your speech',
      '{"type": "speaking_improvement", "similarityThreshold": 70}'::jsonb
    );
END $$;

