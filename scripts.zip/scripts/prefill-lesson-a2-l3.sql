-- =========================================
-- Pre-fill Database with Sample Lesson Data
-- A2-L3: Eating Out & Restaurants
-- =========================================

-- Clear existing sample data for A2-L3 (optional - comment out if you want to keep existing data)
DELETE FROM grammar_sentences WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'A2-L3');
DELETE FROM vocabulary_items WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'A2-L3');
DELETE FROM lesson_activities WHERE lesson_id = 'A2-L3';
DELETE FROM lessons WHERE id = 'A2-L3';

INSERT INTO lessons (id, level, lesson_number, topic) VALUES
('A2-L3', 'A2', 3, 'Eating Out & Restaurants')
ON CONFLICT (id) DO UPDATE SET topic = EXCLUDED.topic;

DO $$
DECLARE
    lesson_id_var TEXT := 'A2-L3';
    activity_id_var UUID;
BEGIN
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content) VALUES (lesson_id_var, 'warm_up_speaking', 1, 'Restaurant Visits', 'Talk about eating out', '{"prompt": "When do you usually eat at restaurants?"}'::jsonb) RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content) VALUES (lesson_id_var, 'vocabulary_intro', 2, 'Restaurant Words', 'Learn restaurant vocabulary', '{}'::jsonb) RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'menu', 'เมนู', NULL),
    (activity_id_var, 'waiter', 'พนักงานเสิร์ฟ', NULL),
    (activity_id_var, 'table', 'โต๊ะ', NULL),
    (activity_id_var, 'order', 'สั่ง', NULL),
    (activity_id_var, 'bill', 'ใบเสร็จ', NULL);

    -- 3. Vocabulary Matching Drag #1 (5 pairs - same words)
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content) VALUES (lesson_id_var, 'vocabulary_matching_drag', 3, 'Match Restaurant 1', 'Match English words with Thai meanings', '{}'::jsonb) RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'menu', 'เมนู', NULL),
    (activity_id_var, 'waiter', 'พนักงานเสิร์ฟ', NULL),
    (activity_id_var, 'table', 'โต๊ะ', NULL),
    (activity_id_var, 'order', 'สั่ง', NULL),
    (activity_id_var, 'bill', 'ใบเสร็จ', NULL);


    -- 4. Vocabulary Fill Blanks #1 (4 words: menu, waiter, table, order - bill left out)
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content) VALUES (lesson_id_var, 'vocabulary_fill_blanks', 4, 'Complete the Sentences 1', 'Fill in the blanks with correct words', '{"text": "I read the ___ to choose food. The ___ brings water to the table. We sit at a clean ___. I ___ chicken for dinner.", "blanks": [{"id": "blank1", "text": "menu", "options": ["menu", "waiter", "table", "order"], "correctAnswer": "menu"}, {"id": "blank2", "text": "waiter", "options": ["menu", "waiter", "table", "order"], "correctAnswer": "waiter"}, {"id": "blank3", "text": "table", "options": ["menu", "waiter", "table", "order"], "correctAnswer": "table"}, {"id": "blank4", "text": "order", "options": ["menu", "waiter", "table", "order"], "correctAnswer": "order"}]}'::jsonb) RETURNING id INTO activity_id_var;

    -- 4. Vocabulary Fill Blanks #2 (4 words: menu, waiter, table, bill - order left out)
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content) VALUES (lesson_id_var, 'vocabulary_fill_blanks', 5, 'Complete the Sentences 2', 'Fill in the blanks with correct words', '{"text": "The ___ shows all the food. I ask the ___ for help. We reserve a ___ for four people. We pay the ___ after eating.", "blanks": [{"id": "blank1", "text": "menu", "options": ["menu", "waiter", "table", "bill"], "correctAnswer": "menu"}, {"id": "blank2", "text": "waiter", "options": ["menu", "waiter", "table", "bill"], "correctAnswer": "waiter"}, {"id": "blank3", "text": "table", "options": ["menu", "waiter", "table", "bill"], "correctAnswer": "table"}, {"id": "blank4", "text": "bill", "options": ["menu", "waiter", "table", "bill"], "correctAnswer": "bill"}]}'::jsonb) RETURNING id INTO activity_id_var;

    -- 4. Grammar Explanation (5 examples - CEFR A2: Polite requests)
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content) VALUES (lesson_id_var, 'grammar_explanation', 6, 'Polite Requests - Restaurants', 'Learn polite ways to ask', '{"rules": "Use polite requests in restaurants:\n\n- Can I have...? (Can I have the menu?)\n- Could you...? (Could you bring water?)\n- I would like... (I would like pasta)\n- May I...? (May I see the dessert menu?)\n- Please + verb (Please bring the bill)", "examples": ["Can I have the menu, please?", "Could you bring some water?", "I would like chicken with rice.", "May I see the dessert menu?", "Please bring the bill."]}'::jsonb) RETURNING id INTO activity_id_var;
    -- 4. Grammar Sentences #1
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content) VALUES (lesson_id_var, 'grammar_sentences', 7, 'Build Sentences 1', 'Arrange words to make sentences', '{}'::jsonb) RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'Can I have the menu please', 'Can I have the menu, please?', '["Can", "I", "have", "the", "menu,", "please?"]'::jsonb),
    (activity_id_var, 'Could you bring some water', 'Could you bring some water?', '["Could", "you", "bring", "some", "water?"]'::jsonb);
    -- 4. Grammar Sentences #2
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content) VALUES (lesson_id_var, 'grammar_sentences', 8, 'Build Sentences 2', 'Arrange words to make sentences', '{}'::jsonb) RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'I would like pasta for dinner', 'I would like pasta for dinner', '["I", "would", "like", "pasta", "for", "dinner"]'::jsonb),
    (activity_id_var, 'May I see the dessert menu', 'May I see the dessert menu?', '["May", "I", "see", "the", "dessert", "menu?"]'::jsonb);
    -- 4. Speaking Practice (5 prompts - CEFR A2: Restaurant conversations)
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content) VALUES (lesson_id_var, 'speaking_practice', 9, 'Talk About Restaurants', 'Practice restaurant conversations', '{"prompts": ["What is your favorite restaurant near your home?", "What do you usually order when you eat out?", "Have you ever complained about food in a restaurant?", "Do you leave tips for waiters in your country?", "What restaurant would you recommend to a friend?"]}'::jsonb) RETURNING id INTO activity_id_var;

END $$;