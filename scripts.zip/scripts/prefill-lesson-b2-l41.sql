-- =========================================
-- Pre-fill Database with Sample Lesson Data
-- B2-L41: Screen time and concentration
-- =========================================

DELETE FROM grammar_sentences WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'B2-L41');
DELETE FROM vocabulary_items WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'B2-L41');
DELETE FROM lesson_activities WHERE lesson_id = 'B2-L41';
DELETE FROM lessons WHERE id = 'B2-L41';

INSERT INTO lessons (id, level, lesson_number, topic) VALUES
('B2-L41', 'B2', 41, 'Screen time and concentration')
ON CONFLICT (id) DO UPDATE SET topic = EXCLUDED.topic;

DO $$
DECLARE
    lesson_id_var TEXT := 'B2-L41';
    activity_id_var UUID;
BEGIN
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'warm_up_speaking', 1, 'Notifications & Focus', 'Talk about managing screens', '{"prompt": "How have you managed notifications, and what keeps you focused?"}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_intro', 2, 'Screen Time Words', 'Key words for digital focus', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'focus', 'โฟกัส/สมาธิ', NULL),
    (activity_id_var, 'notification', 'การแจ้งเตือน', NULL),
    (activity_id_var, 'detox', 'การล้าง/พักจากหน้าจอ', NULL),
    (activity_id_var, 'block', 'บล็อก/ปิดกั้น', NULL),
    (activity_id_var, 'limit', 'ขีดจำกัด', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_matching_drag', 3, 'Match Screen Time Words', 'Match words with meanings', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'focus', 'โฟกัส/สมาธิ', NULL),
    (activity_id_var, 'notification', 'การแจ้งเตือน', NULL),
    (activity_id_var, 'detox', 'การล้าง/พักจากหน้าจอ', NULL),
    (activity_id_var, 'block', 'บล็อก/ปิดกั้น', NULL),
    (activity_id_var, 'limit', 'ขีดจำกัด', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 4, 'Complete the Sentences 1', 'Fill with the correct word', '{"text": "I set a screen ___. I ___ alerts at night. A weekend ___ helps me reset.", "blanks": [{"id": "blank1", "text": "limit", "options": ["limit", "block", "detox", "focus"], "correctAnswer": "limit"}, {"id": "blank2", "text": "block", "options": ["block", "notification", "focus", "detox"], "correctAnswer": "block"}, {"id": "blank3", "text": "detox", "options": ["detox", "limit", "block", "notification"], "correctAnswer": "detox"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 5, 'Complete the Sentences 2', 'Fill with the correct word', '{"text": "My ___ improves when alerts are off. A single ___ can break ___.", "blanks": [{"id": "blank1", "text": "focus", "options": ["focus", "notification", "detox", "limit"], "correctAnswer": "focus"}, {"id": "blank2", "text": "notification", "options": ["notification", "focus", "block", "detox"], "correctAnswer": "notification"}, {"id": "blank3", "text": "focus", "options": ["focus", "notification", "limit", "detox"], "correctAnswer": "focus"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_explanation', 6, 'Present Perfect Continuous', 'Show ongoing screen habits', '{"rules": "Use have/has + been + -ing to show actions started in the past and continuing now, often with for/since.\\n- I have been turning off notifications at night.\\n- They have been limiting screen time for exams.", "examples": ["I have been blocking alerts after 9 p.m.", "She has been doing a weekend detox since May.", "They have been setting app limits for weeks.", "We have been tracking focus while studying.", "He has been muting group chats during class."]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 7, 'Build Sentences 1', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'I have been blocking alerts after 9 p.m.', 'I have been blocking alerts after 9 p.m.', '["I", "have", "been", "blocking", "alerts", "after", "9", "p.m."]'::jsonb),
    (activity_id_var, 'She has been doing a weekend detox since May', 'She has been doing a weekend detox since May.', '["She", "has", "been", "doing", "a", "weekend", "detox", "since", "May."]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 8, 'Build Sentences 2', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'They have been setting app limits for weeks', 'They have been setting app limits for weeks.', '["They", "have", "been", "setting", "app", "limits", "for", "weeks."]'::jsonb),
    (activity_id_var, 'We have been tracking focus while studying', 'We have been tracking focus while studying.', '["We", "have", "been", "tracking", "focus", "while", "studying."]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'speaking_practice', 9, 'Talk About Screen Habits', 'Practice present perfect continuous', '{"prompts": ["How have you managed notifications this term?", "When do you do a screen detox?", "Who keeps you accountable for limits?"]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (
      lesson_id,
      activity_type,
      activity_order,
      title,
      description,
      content
    ) VALUES (
      'B2-L41',
      'speaking_improvement',
      10,
      'Speaking Improvement',
      'Read the improved version of your speech',
      '{"type": "speaking_improvement", "similarityThreshold": 70}'::jsonb
    );
END $$;


