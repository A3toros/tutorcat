-- =========================================
-- Pre-fill Database with Sample Lesson Data
-- A2-L52: Shopping at a Market
-- =========================================

DELETE FROM grammar_sentences WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'A2-L52');
DELETE FROM vocabulary_items WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'A2-L52');
DELETE FROM lesson_activities WHERE lesson_id = 'A2-L52';
DELETE FROM lessons WHERE id = 'A2-L52';

INSERT INTO lessons (id, level, lesson_number, topic) VALUES
('A2-L52', 'A2', 52, 'Shopping at a Market')
ON CONFLICT (id) DO UPDATE SET topic = EXCLUDED.topic;

DO $$
DECLARE
    lesson_id_var TEXT := 'A2-L52';
    activity_id_var UUID;
BEGIN
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'warm_up_speaking', 1, 'Market Shopping', 'Talk about shopping at markets', '{"prompt": "What are you usually buying at markets?"}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_intro', 2, 'Market Words', 'Learn market vocabulary', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'stall', 'แผง/ร้าน', NULL),
    (activity_id_var, 'bargain', 'ต่อราคา', NULL),
    (activity_id_var, 'fresh', 'สด', NULL),
    (activity_id_var, 'vendor', 'พ่อค้า/แม่ค้า', NULL),
    (activity_id_var, 'basket', 'ตะกร้า', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_matching_drag', 3, 'Match Market Words', 'Match market words', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'stall', 'แผง/ร้าน', NULL),
    (activity_id_var, 'bargain', 'ต่อราคา', NULL),
    (activity_id_var, 'fresh', 'สด', NULL),
    (activity_id_var, 'vendor', 'พ่อค้า/แม่ค้า', NULL),
    (activity_id_var, 'basket', 'ตะกร้า', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 4, 'Complete the Sentences 1', 'Fill with the correct word', '{"text": "This ___ sells fruit. The food is ___. I use a ___.", "blanks": [{"id": "blank1", "text": "stall", "options": ["stall", "fresh", "basket", "vendor"], "correctAnswer": "stall"}, {"id": "blank2", "text": "fresh", "options": ["fresh", "vendor", "basket", "bargain"], "correctAnswer": "fresh"}, {"id": "blank3", "text": "basket", "options": ["basket", "stall", "vendor", "fresh"], "correctAnswer": "basket"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 5, 'Complete the Sentences 2', 'Fill with the correct word', '{"text": "I like to ___ with the ___.", "blanks": [{"id": "blank1", "text": "bargain", "options": ["bargain", "vendor", "stall", "fresh"], "correctAnswer": "bargain"}, {"id": "blank2", "text": "vendor", "options": ["vendor", "stall", "basket", "fresh"], "correctAnswer": "vendor"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_explanation', 6, 'Present Continuous (happening now)', 'Talk about shopping now', '{"rules": "Use am/is/are + verb-ing for actions happening now.\n- I am buying vegetables.\n- She is bargaining now.\nQuestions: Are you waiting at the stall?", "examples": ["I am buying vegetables.", "She is bargaining now.", "We are walking through the market.", "Are you waiting at the stall?", "They are choosing fresh fruit."]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 7, 'Build Sentences 1', 'Arrange words', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'I am buying vegetables', 'I am buying vegetables.', '["I", "am", "buying", "vegetables."]'::jsonb),
    (activity_id_var, 'She is bargaining now', 'She is bargaining now.', '["She", "is", "bargaining", "now."]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 8, 'Build Sentences 2', 'Arrange words', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'Are you waiting at the stall', 'Are you waiting at the stall?', '["Are", "you", "waiting", "at", "the", "stall?"]'::jsonb),
    (activity_id_var, 'They are choosing fresh fruit', 'They are choosing fresh fruit.', '["They", "are", "choosing", "fresh", "fruit."]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'speaking_practice', 9, 'Talk About Markets', 'Practice talking about markets', '{"prompts": ["What are you usually buying at markets?", "Are people selling food or clothes there?", "Are you bargaining with sellers now or usually?", "What are people doing at the market?", "How is shopping at a market different from a mall?"]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (
      lesson_id,
      activity_type,
      activity_order,
      title,
      description,
      content
    ) VALUES (
      'A2-L52',
      'speaking_improvement',
      10,
      'Speaking Improvement',
      'Read the improved version of your speech',
      '{"type": "speaking_improvement", "similarityThreshold": 70}'::jsonb
    );
END $$;

