-- =========================================
-- Pre-fill Database with Sample Lesson Data
-- B2-L71: Public transport experiences
-- =========================================

DELETE FROM grammar_sentences WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'B2-L71');
DELETE FROM vocabulary_items WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'B2-L71');
DELETE FROM lesson_activities WHERE lesson_id = 'B2-L71';
DELETE FROM lessons WHERE id = 'B2-L71';

INSERT INTO lessons (id, level, lesson_number, topic) VALUES
('B2-L71', 'B2', 71, 'Public transport experiences')
ON CONFLICT (id) DO UPDATE SET topic = EXCLUDED.topic;

DO $$
DECLARE
    lesson_id_var TEXT := 'B2-L71';
    activity_id_var UUID;
BEGIN
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'warm_up_speaking', 1, 'Commute Stories', 'Talk about past transport surprises', '{"prompt": "What had you wished was announced, and how did you adapt?"}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_intro', 2, 'Transport Words', 'Key words for public transport', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'validate', 'ตรวจ/ประทับตรา/ยืนยันตั๋ว', NULL),
    (activity_id_var, 'delay', 'ความล่าช้า', NULL),
    (activity_id_var, 'announcement', 'ประกาศ', NULL),
    (activity_id_var, 'route', 'เส้นทาง', NULL),
    (activity_id_var, 'crowd', 'ฝูงชน/คนแน่น', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_matching_drag', 3, 'Match Transport Words', 'Match words with meanings', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'validate', 'ตรวจ/ประทับตรา/ยืนยันตั๋ว', NULL),
    (activity_id_var, 'delay', 'ความล่าช้า', NULL),
    (activity_id_var, 'announcement', 'ประกาศ', NULL),
    (activity_id_var, 'route', 'เส้นทาง', NULL),
    (activity_id_var, 'crowd', 'ฝูงชน/คนแน่น', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 4, 'Complete the Sentences 1', 'Fill with the correct word', '{"text": "I wish the ___ was clearer. The ___ changed the ___.", "blanks": [{"id": "blank1", "text": "announcement", "options": ["announcement", "route", "delay", "crowd"], "correctAnswer": "announcement"}, {"id": "blank2", "text": "delay", "options": ["delay", "announcement", "crowd", "route"], "correctAnswer": "delay"}, {"id": "blank3", "text": "route", "options": ["route", "crowd", "delay", "validate"], "correctAnswer": "route"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 5, 'Complete the Sentences 2', 'Fill with the correct word', '{"text": "I had to ___ my ticket. The ___ was huge.", "blanks": [{"id": "blank1", "text": "validate", "options": ["validate", "announcement", "route", "delay"], "correctAnswer": "validate"}, {"id": "blank2", "text": "crowd", "options": ["crowd", "delay", "route", "validate"], "correctAnswer": "crowd"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_explanation', 6, 'Past Perfect', 'Reflect on expectations before trips', '{"rules": "Use had + past participle for actions before another past point.\\n- I had planned the route before the delay.\\n- We had wished for announcements before the change.", "examples": ["I had validated my ticket before boarding.", "We had checked the route before the bus changed.", "They had expected a delay before they left home.", "She had never faced such a crowd before that day.", "He had relied on announcements before missing the stop."]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 7, 'Build Sentences 1', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'I had validated my ticket before boarding', 'I had validated my ticket before boarding.', '["I", "had", "validated", "my", "ticket", "before", "boarding."]'::jsonb),
    (activity_id_var, 'We had checked the route before the bus changed', 'We had checked the route before the bus changed.', '["We", "had", "checked", "the", "route", "before", "the", "bus", "changed."]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 8, 'Build Sentences 2', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'They had expected a delay before they left home', 'They had expected a delay before they left home.', '["They", "had", "expected", "a", "delay", "before", "they", "left", "home."]'::jsonb),
    (activity_id_var, 'She had never faced such a crowd before that day', 'She had never faced such a crowd before that day.', '["She", "had", "never", "faced", "such", "a", "crowd", "before", "that", "day."]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'speaking_practice', 9, 'Talk About Transport', 'Practice past perfect reflections', '{"prompts": ["What had you wished was announced sooner?", "How did you adapt when the route changed?", "When did a crowd surprise you?"]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (
      lesson_id,
      activity_type,
      activity_order,
      title,
      description,
      content
    ) VALUES (
      'B2-L71',
      'speaking_improvement',
      10,
      'Speaking Improvement',
      'Read the improved version of your speech',
      '{"type": "speaking_improvement", "similarityThreshold": 70}'::jsonb
    );
END $$;


