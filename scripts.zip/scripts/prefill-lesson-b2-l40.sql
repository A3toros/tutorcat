-- =========================================
-- Pre-fill Database with Sample Lesson Data
-- B2-L40: Work–life balance (boundaries)
-- =========================================

DELETE FROM grammar_sentences WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'B2-L40');
DELETE FROM vocabulary_items WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'B2-L40');
DELETE FROM lesson_activities WHERE lesson_id = 'B2-L40';
DELETE FROM lessons WHERE id = 'B2-L40';

INSERT INTO lessons (id, level, lesson_number, topic) VALUES
('B2-L40', 'B2', 40, 'Work–life balance (boundaries)')
ON CONFLICT (id) DO UPDATE SET topic = EXCLUDED.topic;

DO $$
DECLARE
    lesson_id_var TEXT := 'B2-L40';
    activity_id_var UUID;
BEGIN
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'warm_up_speaking', 1, 'Boundary Check', 'Talk about ownership and flexibility', '{"prompt": "What should be protected, what must be flexible, and who enforces it?"}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_intro', 2, 'Boundary Words', 'Key words for rules and duties', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'boundary', 'ขอบเขต', NULL),
    (activity_id_var, 'overtime', 'การทำงานล่วงเวลา', NULL),
    (activity_id_var, 'response time', 'เวลาตอบกลับ', NULL),
    (activity_id_var, 'expectation', 'ความคาดหวัง', NULL),
    (activity_id_var, 'norm', 'บรรทัดฐาน', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_matching_drag', 3, 'Match Boundary Words', 'Match words with meanings', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'boundary', 'ขอบเขต', NULL),
    (activity_id_var, 'overtime', 'การทำงานล่วงเวลา', NULL),
    (activity_id_var, 'response time', 'เวลาตอบกลับ', NULL),
    (activity_id_var, 'expectation', 'ความคาดหวัง', NULL),
    (activity_id_var, 'norm', 'บรรทัดฐาน', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 4, 'Complete the Sentences 1', 'Fill with the correct word', '{"text": "We set a clear ___. __ is limited. We define ___.", "blanks": [{"id": "blank1", "text": "boundary", "options": ["boundary", "overtime", "norm", "expectation"], "correctAnswer": "boundary"}, {"id": "blank2", "text": "Overtime", "options": ["Overtime", "Expectation", "Norm", "Response time"], "correctAnswer": "Overtime"}, {"id": "blank3", "text": "expectations", "options": ["expectations", "boundary", "overtime", "norm"], "correctAnswer": "expectations"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 5, 'Complete the Sentences 2', 'Fill with the correct word', '{"text": "We agree on ___. We set a quick ___.", "blanks": [{"id": "blank1", "text": "norms", "options": ["norms", "boundaries", "response time", "overtime"], "correctAnswer": "norms"}, {"id": "blank2", "text": "response time", "options": ["response time", "expectations", "boundary", "norm"], "correctAnswer": "response time"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_explanation', 6, 'Passive with Modals', 'Assign duties politely', '{"rules": "Use modal + be + past participle for necessity/permission.\\n- Boundaries must be respected.\\n- Overtime should be limited.\\nFor past references, use modal + have + been + past participle.", "examples": ["Boundaries must be respected by everyone.", "Response times should be agreed on.", "Expectations can be clarified early.", "Overtime must be approved first.", "Norms should have been shared at onboarding."]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 7, 'Build Sentences 1', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'Boundaries must be respected by everyone', 'Boundaries must be respected by everyone.', '["Boundaries", "must", "be", "respected", "by", "everyone."]'::jsonb),
    (activity_id_var, 'Overtime should be limited', 'Overtime should be limited.', '["Overtime", "should", "be", "limited."]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 8, 'Build Sentences 2', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'Expectations can be clarified early', 'Expectations can be clarified early.', '["Expectations", "can", "be", "clarified", "early."]'::jsonb),
    (activity_id_var, 'Norms should have been shared at onboarding', 'Norms should have been shared at onboarding.', '["Norms", "should", "have", "been", "shared", "at", "onboarding."]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'speaking_practice', 9, 'Talk About Boundaries', 'Practice passive with modals', '{"prompts": ["What should be protected in your schedule?", "What must stay flexible?", "Who enforces the norms in your group?"]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (
      lesson_id,
      activity_type,
      activity_order,
      title,
      description,
      content
    ) VALUES (
      'B2-L40',
      'speaking_improvement',
      10,
      'Speaking Improvement',
      'Read the improved version of your speech',
      '{"type": "speaking_improvement", "similarityThreshold": 70}'::jsonb
    );
END $$;


