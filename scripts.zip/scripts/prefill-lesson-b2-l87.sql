-- ===== LESSON B2-L87 =====

-- =========================================
-- Pre-fill Database with Sample Lesson Data
-- B2-L87: Cultural identity
-- =========================================

DELETE FROM lesson_activity_results WHERE lesson_id = 'B2-L87';
DELETE FROM user_progress WHERE lesson_id = 'B2-L87';
DELETE FROM lesson_history WHERE lesson_id = 'B2-L87';
DELETE FROM grammar_sentences WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'B2-L87');
DELETE FROM vocabulary_items WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'B2-L87');
DELETE FROM lesson_activities WHERE lesson_id = 'B2-L87';
DELETE FROM lessons WHERE id = 'B2-L87';

INSERT INTO lessons (id, level, lesson_number, topic) VALUES
('B2-L87', 'B2', 87, 'Cultural identity')
ON CONFLICT (id) DO UPDATE SET topic = EXCLUDED.topic;

DO $$
DECLARE
    lesson_id_var TEXT := 'B2-L87';
    activity_id_var UUID;
BEGIN
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'warm_up_speaking', 1, 'Identity Exploration', 'Talk about cultural background and identity', '{"prompt": "When do you rarely feel understood?"}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_intro', 2, 'Identity Words', 'Learn words related to cultural identity', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'heritage', 'มรดก', NULL),
    (activity_id_var, 'adapt', 'ปรับตัว', NULL),
    (activity_id_var, 'stereotype', 'ภาพเหมารวม', NULL),
    (activity_id_var, 'pride', 'ความภาคภูมิใจ', NULL),
    (activity_id_var, 'blend', 'ผสมผสาน', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_matching_drag', 3, 'Match Identity Words', 'Match words related to cultural identity', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'heritage', 'มรดก', NULL),
    (activity_id_var, 'adapt', 'ปรับตัว', NULL),
    (activity_id_var, 'stereotype', 'ภาพเหมารวม', NULL),
    (activity_id_var, 'pride', 'ความภาคภูมิใจ', NULL),
    (activity_id_var, 'blend', 'ผสมผสาน', NULL);

    -- 4. Vocabulary Fill Blanks #1
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 4, 'Complete the Sentences 1', 'Fill in the blanks with correct words', '{"text": "I value my ___. I need to ___. I don''t like ___.", "blanks": [{"id": "blank1", "text": "heritage", "options": ["heritage", "adapt", "stereotype", "pride"], "correctAnswer": "heritage"}, {"id": "blank2", "text": "adapt", "options": ["adapt", "heritage", "stereotype", "blend"], "correctAnswer": "adapt"}, {"id": "blank3", "text": "stereotypes", "options": ["stereotypes", "heritage", "adapt", "pride"], "correctAnswer": "stereotypes"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    -- 5. Vocabulary Fill Blanks #2
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 5, 'Complete the Sentences 2', 'Fill in the blanks with correct words', '{"text": "I feel ___. We need to ___. They ___.", "blanks": [{"id": "blank1", "text": "pride", "options": ["pride", "heritage", "adapt", "stereotype"], "correctAnswer": "pride"}, {"id": "blank2", "text": "blend", "options": ["blend", "heritage", "adapt", "pride"], "correctAnswer": "blend"}, {"id": "blank3", "text": "blend", "options": ["blend", "pride", "heritage", "adapt"], "correctAnswer": "blend"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    -- 6. Grammar Explanation
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_explanation', 6, 'Inversion with Negative Adverbials', 'Learn inversion with rarely/seldom/hardly', '{"rules": "Use inversion with negative adverbials for emphasis:\n\n- Rarely/Seldom/Hardly ever + auxiliary + subject + verb\n- Rarely do I feel (not I rarely feel)\n- Seldom have I questioned (not I seldom have questioned)\n- Hardly ever do stereotypes apply (not Stereotypes hardly ever apply)\n- Inversion makes the statement more formal and emphatic\n- Use do/does/did for present/past simple, have/has for present perfect", "examples": ["Rarely do I feel misunderstood in my culture.", "Seldom have I questioned my heritage.", "Hardly ever do stereotypes apply to me.", "Rarely have I felt so proud.", "Seldom do I see such understanding."]}'::jsonb)
    RETURNING id INTO activity_id_var;

    -- 7. Grammar Sentences #1
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 7, 'Build Sentences 1', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'Rarely do I feel misunderstood in my culture', 'Rarely do I feel misunderstood in my culture.', '["Rarely", "do", "I", "feel", "misunderstood", "in", "my", "culture."]'::jsonb),
    (activity_id_var, 'Seldom have I questioned my heritage', 'Seldom have I questioned my heritage.', '["Seldom", "have", "I", "questioned", "my", "heritage."]'::jsonb);

    -- 8. Grammar Sentences #2
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 8, 'Build Sentences 2', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'Hardly ever do stereotypes apply to me', 'Hardly ever do stereotypes apply to me.', '["Hardly", "ever", "do", "stereotypes", "apply", "to", "me."]'::jsonb),
    (activity_id_var, 'Rarely have I felt so proud', 'Rarely have I felt so proud.', '["Rarely", "have", "I", "felt", "so", "proud."]'::jsonb);

    -- 9. Speaking Practice
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'speaking_practice', 9, 'Discuss Cultural Identity', 'Practice talking about cultural background', '{"prompts": ["When do you rarely feel understood?", "How do you explain your identity?", "What do you keep?", "How do you adapt to new cultures?", "What makes you proud of your heritage?"]}'::jsonb)
    RETURNING id INTO activity_id_var;

    -- 10. Speaking Improvement
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'speaking_improvement', 10, 'Speaking Improvement', 'Read the improved version of your speech', '{"type": "speaking_improvement", "similarityThreshold": 70}'::jsonb)
    RETURNING id INTO activity_id_var;
END $$;