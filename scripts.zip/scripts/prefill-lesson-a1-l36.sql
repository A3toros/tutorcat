-- =========================================
-- Pre-fill Database with Sample Lesson Data
-- A1-L36: Prices (cheap / expensive)
-- =========================================

DELETE FROM grammar_sentences WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'A1-L36');
DELETE FROM vocabulary_items WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'A1-L36');
DELETE FROM lesson_activities WHERE lesson_id = 'A1-L36';
DELETE FROM lessons WHERE id = 'A1-L36';

INSERT INTO lessons (id, level, lesson_number, topic) VALUES
('A1-L36', 'A1', 36, 'Prices (cheap / expensive)')
ON CONFLICT (id) DO UPDATE SET topic = EXCLUDED.topic;

DO $$
DECLARE
    lesson_id_var TEXT := 'A1-L36';
    activity_id_var UUID;
BEGIN
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'warm_up_speaking', 1, 'Prices', 'Talk about prices', '{"prompt": "Is it cheap?"}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_intro', 2, 'Price Words', 'Learn price words', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'cheap', 'ถูก', NULL),
    (activity_id_var, 'expensive', 'แพง', NULL),
    (activity_id_var, 'price', 'ราคา', NULL),
    (activity_id_var, 'coin', 'เหรียญ', NULL),
    (activity_id_var, 'money', 'เงิน', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_matching_drag', 3, 'Match Price Words', 'Match price words', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'cheap', 'ถูก', NULL),
    (activity_id_var, 'expensive', 'แพง', NULL),
    (activity_id_var, 'price', 'ราคา', NULL),
    (activity_id_var, 'coin', 'เหรียญ', NULL),
    (activity_id_var, 'money', 'เงิน', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 4, 'Complete the Sentences 1', 'Fill with the correct word', '{"text": "This is ___. That is ___.", "blanks": [{"id": "blank1", "text": "cheap", "options": ["cheap", "expensive", "price", "coin"], "correctAnswer": "cheap"}, {"id": "blank2", "text": "expensive", "options": ["expensive", "cheap", "money", "coin"], "correctAnswer": "expensive"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 5, 'Complete the Sentences 2', 'Fill with the correct word', '{"text": "What is the ___? Do you have a ___?", "blanks": [{"id": "blank1", "text": "price", "options": ["price", "money", "coin", "cheap"], "correctAnswer": "price"}, {"id": "blank2", "text": "coin", "options": ["coin", "money", "price", "expensive"], "correctAnswer": "coin"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_explanation', 6, 'Be + Adjectives', 'Use be with price adjectives', '{"rules": "Use be with cheap/expensive.\n- It is cheap.\n- It is expensive.\nAsk: Is it cheap?", "examples": ["It is cheap.", "It is expensive.", "The price is low.", "Is it cheap?", "Is it expensive?"]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 7, 'Build Sentences 1', 'Arrange words', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'It is cheap', 'It is cheap.', '["It", "is", "cheap."]'::jsonb),
    (activity_id_var, 'It is expensive', 'It is expensive.', '["It", "is", "expensive."]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 8, 'Build Sentences 2', 'Arrange words', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'The price is low', 'The price is low.', '["The", "price", "is", "low."]'::jsonb),
    (activity_id_var, 'Is it cheap', 'Is it cheap?', '["Is", "it", "cheap?"]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'speaking_practice', 9, 'Talk About Prices', 'Practice cheap/expensive', '{"prompts": ["Is it cheap?", "Is it expensive?", "What is the price?", "Do you have coins?", "Do you pay with cash?"]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (
      lesson_id,
      activity_type,
      activity_order,
      title,
      description,
      content
    ) VALUES (
      'A1-L36',
      'speaking_improvement',
      10,
      'Speaking Improvement',
      'Read the improved version of your speech',
      '{"type": "speaking_improvement", "similarityThreshold": 70}'::jsonb
    );
END $$;

