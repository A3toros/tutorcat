-- =========================================
-- Pre-fill Database with Sample Lesson Data
-- A2-L58: Expressing Likes & Dislikes
-- =========================================

DELETE FROM grammar_sentences WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'A2-L58');
DELETE FROM vocabulary_items WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'A2-L58');
DELETE FROM lesson_activities WHERE lesson_id = 'A2-L58';
DELETE FROM lessons WHERE id = 'A2-L58';

INSERT INTO lessons (id, level, lesson_number, topic) VALUES
('A2-L58', 'A2', 58, 'Expressing Likes & Dislikes')
ON CONFLICT (id) DO UPDATE SET topic = EXCLUDED.topic;

DO $$
DECLARE
    lesson_id_var TEXT := 'A2-L58';
    activity_id_var UUID;
BEGIN
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'warm_up_speaking', 1, 'Likes and Dislikes', 'Talk about your preferences', '{"prompt": "What activities do you enjoy doing?"}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_intro', 2, 'Preference Words', 'Learn words for likes and dislikes', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'like', 'ชอบ', NULL),
    (activity_id_var, 'dislike', 'ไม่ชอบ', NULL),
    (activity_id_var, 'love', 'รัก/ชอบมาก', NULL),
    (activity_id_var, 'hate', 'เกลียด', NULL),
    (activity_id_var, 'prefer', 'ชอบมากกว่า', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_matching_drag', 3, 'Match Preference Words', 'Match like/dislike words', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'like', 'ชอบ', NULL),
    (activity_id_var, 'dislike', 'ไม่ชอบ', NULL),
    (activity_id_var, 'love', 'รัก/ชอบมาก', NULL),
    (activity_id_var, 'hate', 'เกลียด', NULL),
    (activity_id_var, 'prefer', 'ชอบมากกว่า', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 4, 'Complete the Sentences 1', 'Fill with the correct word', '{"text": "I ___ coffee. I ___ tea. I ___ water.", "blanks": [{"id": "blank1", "text": "like", "options": ["like", "love", "hate", "prefer"], "correctAnswer": "like"}, {"id": "blank2", "text": "prefer", "options": ["prefer", "like", "hate", "love"], "correctAnswer": "prefer"}, {"id": "blank3", "text": "love", "options": ["love", "hate", "prefer", "like"], "correctAnswer": "love"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 5, 'Complete the Sentences 2', 'Fill with the correct word', '{"text": "I ___ waiting in long lines. I ___ cooking.", "blanks": [{"id": "blank1", "text": "hate", "options": ["hate", "dislike", "like", "love"], "correctAnswer": "hate"}, {"id": "blank2", "text": "dislike", "options": ["dislike", "hate", "like", "prefer"], "correctAnswer": "dislike"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_explanation', 6, 'Object Pronouns', 'Use pronouns after like/love/hate', '{"rules": "Use object pronouns after verbs: me, you, him, her, us, them.\n- I like him.\n- She loves us.\nNegatives: don''t/doesn''t + like.", "examples": ["I like him.", "She loves them.", "We don''t hate it.", "Do you like her?", "They prefer us."]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 7, 'Build Sentences 1', 'Arrange words', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'I like him', 'I like him.', '["I", "like", "him."]'::jsonb),
    (activity_id_var, 'She loves them', 'She loves them.', '["She", "loves", "them."]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 8, 'Build Sentences 2', 'Arrange words', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'We don t hate it', 'We don''t hate it.', '["We", "don''t", "hate", "it."]'::jsonb),
    (activity_id_var, 'Do you like her', 'Do you like her?', '["Do", "you", "like", "her?"]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'speaking_practice', 9, 'Talk About Likes', 'Practice preferences', '{"prompts": ["What activities do you enjoy doing?", "What food do you dislike eating?", "What music do you like listening to?", "Is there anything you love doing every day?", "What activities do you really hate doing?"]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (
      lesson_id,
      activity_type,
      activity_order,
      title,
      description,
      content
    ) VALUES (
      'A2-L58',
      'speaking_improvement',
      10,
      'Speaking Improvement',
      'Read the improved version of your speech',
      '{"type": "speaking_improvement", "similarityThreshold": 70}'::jsonb
    );
END $$;

