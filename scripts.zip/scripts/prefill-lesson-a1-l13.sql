-- =========================================
-- Pre-fill Database with Sample Lesson Data
-- A1-L13: Clothes
-- =========================================

DELETE FROM grammar_sentences WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'A1-L13');
DELETE FROM vocabulary_items WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'A1-L13');
DELETE FROM lesson_activities WHERE lesson_id = 'A1-L13';
DELETE FROM lessons WHERE id = 'A1-L13';

INSERT INTO lessons (id, level, lesson_number, topic) VALUES
('A1-L13', 'A1', 13, 'Clothes')
ON CONFLICT (id) DO UPDATE SET topic = EXCLUDED.topic;

DO $$
DECLARE
    lesson_id_var TEXT := 'A1-L13';
    activity_id_var UUID;
BEGIN
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'warm_up_speaking', 1, 'Clothes You Wear', 'Talk about clothes', '{"prompt": "What do you wear today?"}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_intro', 2, 'Clothes Words', 'Learn clothes words', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'shirt', 'เสื้อเชิ้ต', NULL),
    (activity_id_var, 'pants', 'กางเกง', NULL),
    (activity_id_var, 'hat', 'หมวก', NULL),
    (activity_id_var, 'shoes', 'รองเท้า', NULL),
    (activity_id_var, 'jacket', 'เสื้อแจ็คเก็ต', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_matching_drag', 3, 'Match Clothes Words', 'Match clothes words', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'shirt', 'เสื้อเชิ้ต', NULL),
    (activity_id_var, 'pants', 'กางเกง', NULL),
    (activity_id_var, 'hat', 'หมวก', NULL),
    (activity_id_var, 'shoes', 'รองเท้า', NULL),
    (activity_id_var, 'jacket', 'เสื้อแจ็คเก็ต', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 4, 'Complete the Sentences 1', 'Fill with the correct word', '{"text": "I wear a ___. I wear ___ shoes.", "blanks": [{"id": "blank1", "text": "shirt", "options": ["shirt", "pants", "hat", "jacket"], "correctAnswer": "shirt"}, {"id": "blank2", "text": "shoes", "options": ["shoes", "hat", "pants", "shirt"], "correctAnswer": "shoes"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 5, 'Complete the Sentences 2', 'Fill with the correct word', '{"text": "This is a ___. These are ___.", "blanks": [{"id": "blank1", "text": "hat", "options": ["hat", "shirt", "pants", "jacket"], "correctAnswer": "hat"}, {"id": "blank2", "text": "pants", "options": ["pants", "shoes", "hat", "jacket"], "correctAnswer": "pants"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_explanation', 6, 'A / An and Plurals', 'Use a/an and plural s', '{"rules": "Use a/an for one item. Add s for many.\n- a hat, an apple, two hats, three shirts.", "examples": ["This is a hat.", "I have a jacket.", "These are shoes.", "Those are pants.", "Is this a shirt?"]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 7, 'Build Sentences 1', 'Arrange words', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'This is a hat', 'This is a hat.', '["This", "is", "a", "hat."]'::jsonb),
    (activity_id_var, 'These are shoes', 'These are shoes.', '["These", "are", "shoes."]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 8, 'Build Sentences 2', 'Arrange words', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'Is this a shirt', 'Is this a shirt?', '["Is", "this", "a", "shirt?"]'::jsonb),
    (activity_id_var, 'Are those your pants', 'Are those your pants?', '["Are", "those", "your", "pants?"]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'speaking_practice', 9, 'Talk About Clothes', 'Practice clothes words', '{"prompts": ["What do you wear today?", "Do you like hats?", "Are your shoes new?", "Is this your jacket?", "Do you wear pants or a skirt?"]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (
      lesson_id,
      activity_type,
      activity_order,
      title,
      description,
      content
    ) VALUES (
      'A1-L13',
      'speaking_improvement',
      10,
      'Speaking Improvement',
      'Read the improved version of your speech',
      '{"type": "speaking_improvement", "similarityThreshold": 70}'::jsonb
    );
END $$;

