-- =========================================
-- Pre-fill Database with Sample Lesson Data
-- A1-L43: Likes and Dislikes
-- =========================================

DELETE FROM grammar_sentences WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'A1-L43');
DELETE FROM vocabulary_items WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'A1-L43');
DELETE FROM lesson_activities WHERE lesson_id = 'A1-L43';
DELETE FROM lessons WHERE id = 'A1-L43';

INSERT INTO lessons (id, level, lesson_number, topic) VALUES
('A1-L43', 'A1', 43, 'Likes and Dislikes')
ON CONFLICT (id) DO UPDATE SET topic = EXCLUDED.topic;

DO $$
DECLARE
    lesson_id_var TEXT := 'A1-L43';
    activity_id_var UUID;
BEGIN
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'warm_up_speaking', 1, 'What You Like', 'Talk about likes', '{"prompt": "What do you like?"}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_intro', 2, 'Feeling Words', 'Learn like/love/hate words', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'like', 'ชอบ', NULL),
    (activity_id_var, 'love', 'รัก/ชอบมาก', NULL),
    (activity_id_var, 'hate', 'เกลียด', NULL),
    (activity_id_var, 'okay', 'โอเค', NULL),
    (activity_id_var, 'favorite', 'ที่ชอบที่สุด', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_matching_drag', 3, 'Match Feeling Words', 'Match like/hate words', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'like', 'ชอบ', NULL),
    (activity_id_var, 'love', 'รัก/ชอบมาก', NULL),
    (activity_id_var, 'hate', 'เกลียด', NULL),
    (activity_id_var, 'okay', 'โอเค', NULL),
    (activity_id_var, 'favorite', 'ที่ชอบที่สุด', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 4, 'Complete the Sentences 1', 'Fill with the correct word', '{"text": "I ___ rice. I ___ soup.", "blanks": [{"id": "blank1", "text": "like", "options": ["like", "love", "hate", "okay"], "correctAnswer": "like"}, {"id": "blank2", "text": "love", "options": ["love", "like", "hate", "okay"], "correctAnswer": "love"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 5, 'Complete the Sentences 2', 'Fill with the correct word', '{"text": "I ___ spicy food. It is ___.", "blanks": [{"id": "blank1", "text": "hate", "options": ["hate", "love", "like", "okay"], "correctAnswer": "hate"}, {"id": "blank2", "text": "okay", "options": ["okay", "favorite", "love", "hate"], "correctAnswer": "okay"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_explanation', 6, 'Like / Don’t Like', 'Express likes and dislikes', '{"rules": "Use like/love/hate + noun. Use don''t like for negatives.\n- I like rice. I don''t like spicy food.\nAsk: Do you like...?", "examples": ["I like rice.", "I love soup.", "I hate spicy food.", "Do you like tea?", "Do you like rain?"]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 7, 'Build Sentences 1', 'Arrange words', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'I like rice', 'I like rice.', '["I", "like", "rice."]'::jsonb),
    (activity_id_var, 'I don t like spicy food', 'I don''t like spicy food.', '["I", "don''t", "like", "spicy", "food."]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 8, 'Build Sentences 2', 'Arrange words', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'Do you like tea', 'Do you like tea?', '["Do", "you", "like", "tea?"]'::jsonb),
    (activity_id_var, 'Do you like rain', 'Do you like rain?', '["Do", "you", "like", "rain?"]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'speaking_practice', 9, 'Talk About Likes', 'Practice likes and dislikes', '{"prompts": ["What do you like?", "Do you like rice?", "Do you like tea?", "Do you hate rain?", "What is your favorite food?"]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (
      lesson_id,
      activity_type,
      activity_order,
      title,
      description,
      content
    ) VALUES (
      'A1-L43',
      'speaking_improvement',
      10,
      'Speaking Improvement',
      'Read the improved version of your speech',
      '{"type": "speaking_improvement", "similarityThreshold": 70}'::jsonb
    );
END $$;

