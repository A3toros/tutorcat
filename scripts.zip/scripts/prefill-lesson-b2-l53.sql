-- ===== LESSON B2-L53 =====

-- =========================================
-- Pre-fill Database with Sample Lesson Data
-- B2-L53: Travel and learning
-- =========================================

DELETE FROM lesson_activity_results WHERE lesson_id = 'B2-L53';
DELETE FROM user_progress WHERE lesson_id = 'B2-L53';
DELETE FROM lesson_history WHERE lesson_id = 'B2-L53';
DELETE FROM grammar_sentences WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'B2-L53');
DELETE FROM vocabulary_items WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'B2-L53');
DELETE FROM lesson_activities WHERE lesson_id = 'B2-L53';
DELETE FROM lessons WHERE id = 'B2-L53';

INSERT INTO lessons (id, level, lesson_number, topic) VALUES
('B2-L53', 'B2', 53, 'Travel and learning')
ON CONFLICT (id) DO UPDATE SET topic = EXCLUDED.topic;

DO $$
DECLARE
    lesson_id_var TEXT := 'B2-L53';
    activity_id_var UUID;
BEGIN
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'warm_up_speaking', 1, 'Travel Stories', 'Talk about your travel experiences', '{"prompt": "Tell me about an interesting place you visited."}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_intro', 2, 'Travel Learning Words', 'Learn words for travel and personal growth', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'immerse', 'ดำดิ่ง', NULL),
    (activity_id_var, 'exposure', 'การเปิดรับ', NULL),
    (activity_id_var, 'insight', 'ความเข้าใจ', NULL),
    (activity_id_var, 'broaden', 'ขยาย', NULL),
    (activity_id_var, 'curiosity', 'ความอยากรู้', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_matching_drag', 3, 'Match Travel Learning Words', 'Match words related to travel and learning', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'immerse', 'ดำดิ่ง', NULL),
    (activity_id_var, 'exposure', 'การเปิดรับ', NULL),
    (activity_id_var, 'insight', 'ความเข้าใจ', NULL),
    (activity_id_var, 'broaden', 'ขยาย', NULL),
    (activity_id_var, 'curiosity', 'ความอยากรู้', NULL);

    -- 4. Vocabulary Fill Blanks #1
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 4, 'Complete the Sentences 1', 'Fill in the blanks with correct words', '{"text": "I want to ___ myself in the culture. Travel gives me ___. I gained new ___.", "blanks": [{"id": "blank1", "text": "immerse", "options": ["immerse", "exposure", "insight", "broaden"], "correctAnswer": "immerse"}, {"id": "blank2", "text": "exposure", "options": ["exposure", "immerse", "insight", "curiosity"], "correctAnswer": "exposure"}, {"id": "blank3", "text": "insight", "options": ["insight", "immerse", "exposure", "broaden"], "correctAnswer": "insight"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    -- 5. Vocabulary Fill Blanks #2
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 5, 'Complete the Sentences 2', 'Fill in the blanks with correct words', '{"text": "Travel helps ___ my mind. I have ___ about new places. My ___ grows with travel.", "blanks": [{"id": "blank1", "text": "broaden", "options": ["broaden", "immerse", "exposure", "insight"], "correctAnswer": "broaden"}, {"id": "blank2", "text": "insight", "options": ["insight", "immerse", "exposure", "curiosity"], "correctAnswer": "insight"}, {"id": "blank3", "text": "curiosity", "options": ["curiosity", "immerse", "exposure", "broaden"], "correctAnswer": "curiosity"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    -- 6. Grammar Explanation
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_explanation', 6, 'Non-defining Relative Clauses', 'Learn relative clauses that add extra information', '{"rules": "Use non-defining relative clauses to add extra information:\n\n- Use commas before and after the clause\n- Use which for things, who for people\n- The information is extra, not essential\n- Can be removed without changing main meaning\n- Use which/who (not that) in non-defining clauses", "examples": ["The trip, which lasted two weeks, completely changed my perspective.", "My friend, who speaks three languages, helped me navigate.", "The culture, which values community, taught me important lessons.", "The city, which I visited last year, was beautiful.", "My teacher, who traveled a lot, shared many stories."]}'::jsonb)
    RETURNING id INTO activity_id_var;

    -- 7. Grammar Sentences #1
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 7, 'Build Sentences 1', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'The trip which lasted two weeks completely changed my perspective', 'The trip, which lasted two weeks, completely changed my perspective.', '["The", "trip,", "which", "lasted", "two", "weeks,", "completely", "changed", "my", "perspective."]'::jsonb),
    (activity_id_var, 'My friend who speaks three languages helped me navigate', 'My friend, who speaks three languages, helped me navigate.', '["My", "friend,", "who", "speaks", "three", "languages,", "helped", "me", "navigate."]'::jsonb);

    -- 8. Grammar Sentences #2
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 8, 'Build Sentences 2', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'The culture which values community taught me important lessons', 'The culture, which values community, taught me important lessons.', '["The", "culture,", "which", "values", "community,", "taught", "me", "important", "lessons."]'::jsonb),
    (activity_id_var, 'The city which I visited last year was beautiful', 'The city, which I visited last year, was beautiful.', '["The", "city,", "which", "I", "visited", "last", "year,", "was", "beautiful."]'::jsonb);

    -- 9. Speaking Practice
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'speaking_practice', 9, 'Share Travel Stories', 'Practice talking about travel experiences', '{"prompts": ["What surprised you most when traveling?", "What new food did you try?", "Who did you meet on your trip?", "How did travel broaden your perspective?", "What insights did you gain from traveling?"]}'::jsonb)
    RETURNING id INTO activity_id_var;

    -- 10. Speaking Improvement
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'speaking_improvement', 10, 'Speaking Improvement', 'Read the improved version of your speech', '{"type": "speaking_improvement", "similarityThreshold": 70}'::jsonb)
    RETURNING id INTO activity_id_var;
END $$;