-- =========================================
-- Pre-fill Database with Sample Lesson Data
-- A2-L50: Talking About Family Members
-- =========================================

DELETE FROM grammar_sentences WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'A2-L50');
DELETE FROM vocabulary_items WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'A2-L50');
DELETE FROM lesson_activities WHERE lesson_id = 'A2-L50';
DELETE FROM lessons WHERE id = 'A2-L50';

INSERT INTO lessons (id, level, lesson_number, topic) VALUES
('A2-L50', 'A2', 50, 'Talking About Family Members')
ON CONFLICT (id) DO UPDATE SET topic = EXCLUDED.topic;

DO $$
DECLARE
    lesson_id_var TEXT := 'A2-L50';
    activity_id_var UUID;
BEGIN
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'warm_up_speaking', 1, 'Family', 'Talk about your family', '{"prompt": "Who are you closest to in your family?"}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_intro', 2, 'Family Words', 'Learn family member words', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'mother', 'แม่', NULL),
    (activity_id_var, 'father', 'พ่อ', NULL),
    (activity_id_var, 'sister', 'พี่สาว/น้องสาว', NULL),
    (activity_id_var, 'brother', 'พี่ชาย/น้องชาย', NULL),
    (activity_id_var, 'mine', 'ของฉัน', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_matching_drag', 3, 'Match Family Words', 'Match family words', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'mother', 'แม่', NULL),
    (activity_id_var, 'father', 'พ่อ', NULL),
    (activity_id_var, 'sister', 'พี่สาว/น้องสาว', NULL),
    (activity_id_var, 'brother', 'พี่ชาย/น้องชาย', NULL),
    (activity_id_var, 'mine', 'ของฉัน', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 4, 'Complete the Sentences 1', 'Fill with the correct word', '{"text": "My ___ is kind. His ___ is funny. Her ___ is younger than ___.", "blanks": [{"id": "blank1", "text": "mother", "options": ["mother", "father", "brother", "sister"], "correctAnswer": "mother"}, {"id": "blank2", "text": "father", "options": ["father", "brother", "mother", "sister"], "correctAnswer": "father"}, {"id": "blank3", "text": "brother", "options": ["brother", "sister", "mother", "father"], "correctAnswer": "brother"}, {"id": "blank4", "text": "mine", "options": ["mine", "father", "mother", "brother"], "correctAnswer": "mine"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 5, 'Complete the Sentences 2', 'Fill with the correct word', '{"text": "My ___ is older than me. This house is ___.", "blanks": [{"id": "blank1", "text": "sister", "options": ["sister", "brother", "mother", "father"], "correctAnswer": "sister"}, {"id": "blank2", "text": "mine", "options": ["mine", "yours", "ours", "his"], "correctAnswer": "mine"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_explanation', 6, 'Object & Possessive Pronouns', 'Refer to family members', '{"rules": "Use object pronouns (me, you, him, her, us, them) and possessive (mine, yours, his, hers, ours, theirs).\n- This is my brother. He is kind to me.\n- This house is mine.", "examples": ["This is my sister. I love her.", "My parents live with us.", "Is this yours or mine?", "I visited him yesterday.", "The car is theirs."]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 7, 'Build Sentences 1', 'Arrange words', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'This house is mine', 'This house is mine.', '["This", "house", "is", "mine."]'::jsonb),
    (activity_id_var, 'Is this yours or mine', 'Is this yours or mine?', '["Is", "this", "yours", "or", "mine?"]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 8, 'Build Sentences 2', 'Arrange words', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'I visited him yesterday', 'I visited him yesterday.', '["I", "visited", "him", "yesterday."]'::jsonb),
    (activity_id_var, 'My parents live with us', 'My parents live with us.', '["My", "parents", "live", "with", "us."]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'speaking_practice', 9, 'Talk About Family', 'Practice family descriptions', '{"prompts": ["Who are you closest to in your family?", "Who do you live with now?", "Which family member do you talk to most?", "How many people are there in your family?", "What do you usually do with them?"]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (
      lesson_id,
      activity_type,
      activity_order,
      title,
      description,
      content
    ) VALUES (
      'A2-L50',
      'speaking_improvement',
      10,
      'Speaking Improvement',
      'Read the improved version of your speech',
      '{"type": "speaking_improvement", "similarityThreshold": 70}'::jsonb
    );
END $$;

