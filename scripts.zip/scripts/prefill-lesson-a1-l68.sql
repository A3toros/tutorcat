-- =========================================
-- Pre-fill Database with Sample Lesson Data
-- A1-L68: Traffic Lights
-- =========================================

DELETE FROM grammar_sentences WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'A1-L68');
DELETE FROM vocabulary_items WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'A1-L68');
DELETE FROM lesson_activities WHERE lesson_id = 'A1-L68';
DELETE FROM lessons WHERE id = 'A1-L68';

INSERT INTO lessons (id, level, lesson_number, topic) VALUES
('A1-L68', 'A1', 68, 'Traffic Lights')
ON CONFLICT (id) DO UPDATE SET topic = EXCLUDED.topic;

DO $$
DECLARE
    lesson_id_var TEXT := 'A1-L68';
    activity_id_var UUID;
BEGIN
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'warm_up_speaking', 1, 'Traffic Lights', 'Talk about lights', '{"prompt": "Do you wait at red lights?"}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_intro', 2, 'Light Words', 'Learn traffic light words', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'red', 'แดง', NULL),
    (activity_id_var, 'yellow', 'เหลือง', NULL),
    (activity_id_var, 'green', 'เขียว', NULL),
    (activity_id_var, 'stop', 'หยุด', NULL),
    (activity_id_var, 'go', 'ไป', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_matching_drag', 3, 'Match Light Words', 'Match traffic light words', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'red', 'แดง', NULL),
    (activity_id_var, 'yellow', 'เหลือง', NULL),
    (activity_id_var, 'green', 'เขียว', NULL),
    (activity_id_var, 'stop', 'หยุด', NULL),
    (activity_id_var, 'go', 'ไป', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 4, 'Complete the Sentences 1', 'Fill with the correct word', '{"text": "___ means stop. ___ means go.", "blanks": [{"id": "blank1", "text": "Red", "options": ["Red", "Green", "Yellow", "Go"], "correctAnswer": "Red"}, {"id": "blank2", "text": "Green", "options": ["Green", "Red", "Yellow", "Stop"], "correctAnswer": "Green"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 5, 'Complete the Sentences 2', 'Fill with the correct word', '{"text": "___ is slow. Do not ___.", "blanks": [{"id": "blank1", "text": "Yellow", "options": ["Yellow", "Red", "Green", "Stop"], "correctAnswer": "Yellow"}, {"id": "blank2", "text": "go", "options": ["go", "stop", "run", "red"], "correctAnswer": "go"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_explanation', 6, 'Imperatives + Colors', 'Give simple traffic commands', '{"rules": "Use go/stop with colors.\n- Red means stop. Green means go.\nUse imperatives: Stop. Go. Wait.", "examples": ["Red means stop.", "Green means go.", "Yellow means slow.", "Stop here, please.", "Go when it is green."]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 7, 'Build Sentences 1', 'Arrange words', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'Red means stop', 'Red means stop.', '["Red", "means", "stop."]'::jsonb),
    (activity_id_var, 'Green means go', 'Green means go.', '["Green", "means", "go."]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 8, 'Build Sentences 2', 'Arrange words', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'Yellow means slow', 'Yellow means slow.', '["Yellow", "means", "slow."]'::jsonb),
    (activity_id_var, 'Stop here please', 'Stop here, please.', '["Stop", "here,", "please."]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'speaking_practice', 9, 'Talk About Traffic Lights', 'Practice traffic rules', '{"prompts": ["Do you wait at red lights?", "Do you go on green?", "Is yellow slow?", "Do you stop here?", "Do you run on red?"]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (
      lesson_id,
      activity_type,
      activity_order,
      title,
      description,
      content
    ) VALUES (
      'A1-L68',
      'speaking_improvement',
      10,
      'Speaking Improvement',
      'Read the improved version of your speech',
      '{"type": "speaking_improvement", "similarityThreshold": 70}'::jsonb
    );
END $$;

