-- =========================================
-- Pre-fill Database with Sample Lesson Data
-- B1-L94: Tech Boundaries
-- =========================================

DELETE FROM grammar_sentences WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'B1-L94');
DELETE FROM vocabulary_items WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'B1-L94');
DELETE FROM lesson_activities WHERE lesson_id = 'B1-L94';
DELETE FROM lessons WHERE id = 'B1-L94';

INSERT INTO lessons (id, level, lesson_number, topic) VALUES
('B1-L94', 'B1', 94, 'Tech Boundaries')
ON CONFLICT (id) DO UPDATE SET topic = EXCLUDED.topic;

DO $$
DECLARE
    lesson_id_var TEXT := 'B1-L94';
    activity_id_var UUID;
BEGIN
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'warm_up_speaking', 1, 'Setting Limits', 'Talk about setting tech boundaries', '{"prompt": "When do you log off even if you do not want to?"}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_intro', 2, 'Boundary Words', 'Learn vocabulary about tech limits', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'limit', 'จำกัด', NULL),
    (activity_id_var, 'schedule', 'ตารางเวลา', NULL),
    (activity_id_var, 'mute', 'ปิดเสียง', NULL),
    (activity_id_var, 'notify', 'แจ้งเตือน', NULL),
    (activity_id_var, 'balance', 'สมดุล', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_matching_drag', 3, 'Match Boundary Words', 'Match words with meanings', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'limit', 'จำกัด', NULL),
    (activity_id_var, 'schedule', 'ตารางเวลา', NULL),
    (activity_id_var, 'mute', 'ปิดเสียง', NULL),
    (activity_id_var, 'notify', 'แจ้งเตือน', NULL),
    (activity_id_var, 'balance', 'สมดุล', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 4, 'Complete the Sentences 1', 'Fill with the correct word', '{"text": "I set a time ___. I keep a screen ___. I often ___ group chats.", "blanks": [{"id": "blank1", "text": "limit", "options": ["limit", "schedule", "mute", "notify"], "correctAnswer": "limit"}, {"id": "blank2", "text": "schedule", "options": ["schedule", "balance", "limit", "mute"], "correctAnswer": "schedule"}, {"id": "blank3", "text": "mute", "options": ["mute", "notify", "balance", "limit"], "correctAnswer": "mute"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 5, 'Complete the Sentences 2', 'Fill with the correct word', '{"text": "I only ___ key apps. Boundaries help me keep ___. I adjust the ___ weekly.", "blanks": [{"id": "blank1", "text": "notify", "options": ["notify", "mute", "limit", "balance"], "correctAnswer": "notify"}, {"id": "blank2", "text": "balance", "options": ["balance", "schedule", "limit", "notify"], "correctAnswer": "balance"}, {"id": "blank3", "text": "schedule", "options": ["schedule", "balance", "notify", "mute"], "correctAnswer": "schedule"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    -- Grammar Explanation: Modals (must/should) for boundaries
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_explanation', 6, 'Modals for Setting Boundaries', 'Use must/should to state rules and advice for tech use', '{"rules": "Use must for strict rules; should for softer advice.\\n- I must log off by 10 PM.\\n- You should mute non-urgent chats.\\nNo contractions.", "examples": ["I must log off by 10 PM.", "You should mute non-urgent chats.", "We must limit screen time before bed.", "They should balance work and social apps.", "He must follow the schedule he set."]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 7, 'Build Sentences 1', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'I must log off by 10 PM', 'I must log off by 10 PM', '["I", "must", "log", "off", "by", "10", "PM"]'::jsonb),
    (activity_id_var, 'You should mute non urgent chats', 'You should mute non-urgent chats', '["You", "should", "mute", "non-urgent", "chats"]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 8, 'Build Sentences 2', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'We must limit screen time before bed', 'We must limit screen time before bed', '["We", "must", "limit", "screen", "time", "before", "bed"]'::jsonb),
    (activity_id_var, 'They should balance work and social apps', 'They should balance work and social apps', '["They", "should", "balance", "work", "and", "social", "apps"]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'speaking_practice', 9, 'Talk About Tech Boundaries', 'Practice talking about setting limits', '{"prompts": ["When do you log off even if you do not want to?", "What rule do you set for late-night screens?", "How do you balance work apps and personal apps?"]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (
      lesson_id,
      activity_type,
      activity_order,
      title,
      description,
      content
    ) VALUES (
      'B1-L94',
      'speaking_improvement',
      10,
      'Speaking Improvement',
      'Read the improved version of your speech',
      '{"type": "speaking_improvement", "similarityThreshold": 70}'::jsonb
    );
END $$;

