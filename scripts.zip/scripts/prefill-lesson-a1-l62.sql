-- =========================================
-- Pre-fill Database with Sample Lesson Data
-- A1-L62: Introducing Yourself
-- =========================================

DELETE FROM grammar_sentences WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'A1-L62');
DELETE FROM vocabulary_items WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'A1-L62');
DELETE FROM lesson_activities WHERE lesson_id = 'A1-L62';
DELETE FROM lessons WHERE id = 'A1-L62';

INSERT INTO lessons (id, level, lesson_number, topic) VALUES
('A1-L62', 'A1', 62, 'Introducing Yourself')
ON CONFLICT (id) DO UPDATE SET topic = EXCLUDED.topic;

DO $$
DECLARE
    lesson_id_var TEXT := 'A1-L62';
    activity_id_var UUID;
BEGIN
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'warm_up_speaking', 1, 'Introduce', 'Talk about yourself', '{"prompt": "What is your name?"}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_intro', 2, 'Self Words', 'Learn words to introduce yourself', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'name', 'ชื่อ', NULL),
    (activity_id_var, 'age', 'อายุ', NULL),
    (activity_id_var, 'from', 'จาก', NULL),
    (activity_id_var, 'live', 'อาศัย', NULL),
    (activity_id_var, 'hello', 'สวัสดี', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_matching_drag', 3, 'Match Self Words', 'Match introduction words', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'name', 'ชื่อ', NULL),
    (activity_id_var, 'age', 'อายุ', NULL),
    (activity_id_var, 'from', 'จาก', NULL),
    (activity_id_var, 'live', 'อาศัย', NULL),
    (activity_id_var, 'hello', 'สวัสดี', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 4, 'Complete the Sentences 1', 'Fill with the correct word', '{"text": "My ___ is Anna. I am 20 ___ old.", "blanks": [{"id": "blank1", "text": "name", "options": ["name", "age", "from", "hello"], "correctAnswer": "name"}, {"id": "blank2", "text": "years", "options": ["years", "hello", "live", "age"], "correctAnswer": "years"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 5, 'Complete the Sentences 2', 'Fill with the correct word', '{"text": "I am from ___. I ___ in Bangkok.", "blanks": [{"id": "blank1", "text": "Thailand", "options": ["Thailand", "hello", "age", "live"], "correctAnswer": "Thailand"}, {"id": "blank2", "text": "live", "options": ["live", "from", "name", "age"], "correctAnswer": "live"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_explanation', 6, 'Be + Name/Age/From', 'Introduce yourself', '{"rules": "Use be with name, age, from.\n- I am Anna. I am 20. I am from Thailand.\nAsk: What is your name?", "examples": ["I am Anna.", "I am 20 years old.", "I am from Thailand.", "What is your name?", "Where are you from?"]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 7, 'Build Sentences 1', 'Arrange words', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'I am Anna', 'I am Anna.', '["I", "am", "Anna."]'::jsonb),
    (activity_id_var, 'I am 20 years old', 'I am 20 years old.', '["I", "am", "20", "years", "old."]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 8, 'Build Sentences 2', 'Arrange words', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'I am from Thailand', 'I am from Thailand.', '["I", "am", "from", "Thailand."]'::jsonb),
    (activity_id_var, 'What is your name', 'What is your name?', '["What", "is", "your", "name?"]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'speaking_practice', 9, 'Introduce Yourself', 'Practice simple intro', '{"prompts": ["What is your name?", "How old are you?", "Where are you from?", "Where do you live?", "Can you say hello?"]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (
      lesson_id,
      activity_type,
      activity_order,
      title,
      description,
      content
    ) VALUES (
      'A1-L62',
      'speaking_improvement',
      10,
      'Speaking Improvement',
      'Read the improved version of your speech',
      '{"type": "speaking_improvement", "similarityThreshold": 70}'::jsonb
    );
END $$;

