-- =========================================
-- Pre-fill Database with Sample Lesson Data
-- B1-L7: Travel Experiences
-- =========================================

-- Clear existing sample data for B1-L7 (optional - comment out if you want to keep existing data)
DELETE FROM grammar_sentences WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'B1-L7');
DELETE FROM vocabulary_items WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'B1-L7');
DELETE FROM lesson_activities WHERE lesson_id = 'B1-L7';
DELETE FROM lessons WHERE id = 'B1-L7';

INSERT INTO lessons (id, level, lesson_number, topic) VALUES
('B1-L7', 'B1', 7, 'Travel Experiences')
ON CONFLICT (id) DO UPDATE SET topic = EXCLUDED.topic;

DO $$
DECLARE
    lesson_id_var TEXT := 'B1-L7';
    activity_id_var UUID;
BEGIN
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content) VALUES (lesson_id_var, 'warm_up_speaking', 1, 'Travel Memories', 'Talk about travel', '{"prompt": "What is the best trip you have ever taken?"}'::jsonb) RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content) VALUES (lesson_id_var, 'vocabulary_intro', 2, 'Travel Words', 'Learn travel vocabulary', '{}'::jsonb) RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'destination', 'จุดหมายปลายทาง', NULL),
    (activity_id_var, 'sightseeing', 'การเที่ยวชมสถานที่', NULL),
    (activity_id_var, 'accommodation', 'ที่พัก', NULL),
    (activity_id_var, 'itinerary', 'แผนการเดินทาง', NULL),
    (activity_id_var, 'souvenir', 'ของที่ระลึก', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content) VALUES (lesson_id_var, 'vocabulary_matching_drag', 3, 'Match Travel Words', 'Match English words with Thai meanings', '{}'::jsonb) RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'destination', 'จุดหมายปลายทาง', NULL),
    (activity_id_var, 'sightseeing', 'การเที่ยวชมสถานที่', NULL),
    (activity_id_var, 'accommodation', 'ที่พัก', NULL),
    (activity_id_var, 'itinerary', 'แผนการเดินทาง', NULL),
    (activity_id_var, 'souvenir', 'ของที่ระลึก', NULL);

    -- 4. Vocabulary Fill Blanks #1 (4 words: destination, sightseeing, accommodation, itinerary - souvenir left out)
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content) VALUES (lesson_id_var, 'vocabulary_fill_blanks', 4, 'Complete the Sentences 1', 'Fill in the blanks with correct words', '{"text": "Our ___ was beautiful. We did a lot of ___. The ___ was comfortable. We followed our ___.", "blanks": [{"id": "blank1", "text": "destination", "options": ["destination", "sightseeing", "accommodation", "itinerary"], "correctAnswer": "destination"}, {"id": "blank2", "text": "sightseeing", "options": ["destination", "sightseeing", "accommodation", "itinerary"], "correctAnswer": "sightseeing"}, {"id": "blank3", "text": "accommodation", "options": ["destination", "sightseeing", "accommodation", "itinerary"], "correctAnswer": "accommodation"}, {"id": "blank4", "text": "itinerary", "options": ["destination", "sightseeing", "accommodation", "itinerary"], "correctAnswer": "itinerary"}]}'::jsonb) RETURNING id INTO activity_id_var;

    -- 4. Vocabulary Fill Blanks #2 (4 words: destination, sightseeing, accommodation, souvenir - itinerary left out)
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content) VALUES (lesson_id_var, 'vocabulary_fill_blanks', 5, 'Complete the Sentences 2', 'Fill in the blanks with correct words', '{"text": "The ___ was amazing. We enjoyed ___. Our ___ was nice. I bought a ___.", "blanks": [{"id": "blank1", "text": "destination", "options": ["destination", "sightseeing", "accommodation", "souvenir"], "correctAnswer": "destination"}, {"id": "blank2", "text": "sightseeing", "options": ["destination", "sightseeing", "accommodation", "souvenir"], "correctAnswer": "sightseeing"}, {"id": "blank3", "text": "accommodation", "options": ["destination", "sightseeing", "accommodation", "souvenir"], "correctAnswer": "accommodation"}, {"id": "blank4", "text": "souvenir", "options": ["destination", "sightseeing", "accommodation", "souvenir"], "correctAnswer": "souvenir"}]}'::jsonb) RETURNING id INTO activity_id_var;

    -- 4. Grammar Explanation (5 examples - CEFR B1: Past simple, present perfect for travel)
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content) VALUES (lesson_id_var, 'grammar_explanation', 6, 'Past Simple & Present Perfect - Travel', 'Learn to describe travel experiences', '{"rules": "Use past simple for specific past travel events:\n\n- I went/visited/saw + specific time (I went to Paris last year)\n- Use present perfect for travel experiences (I have been to many countries)\n- Use past simple for itinerary details (We visited museums, we stayed at a hotel)\n- Use present perfect for overall experiences (I have traveled a lot)\n- Use ''ever'' and ''never'' with present perfect", "examples": ["I went to Japan last summer.", "I have been to many countries.", "We visited several museums during our trip.", "I have never been to Africa.", "We stayed in a beautiful hotel."]}'::jsonb) RETURNING id INTO activity_id_var;

    -- 4. Grammar Sentences #1
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content) VALUES (lesson_id_var, 'grammar_sentences', 7, 'Build Sentences 1', 'Arrange words to make sentences', '{}'::jsonb) RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'I went to Japan last summer', 'I went to Japan last summer', '["I", "went", "to", "Japan", "last", "summer"]'::jsonb),
    (activity_id_var, 'I have been to many countries', 'I have been to many countries', '["I", "have", "been", "to", "many", "countries"]'::jsonb);
    -- 4. Grammar Sentences #2
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content) VALUES (lesson_id_var, 'grammar_sentences', 8, 'Build Sentences 2', 'Arrange words to make sentences', '{}'::jsonb) RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'We visited several museums during our trip', 'We visited several museums during our trip', '["We", "visited", "several", "museums", "during", "our", "trip"]'::jsonb),
    (activity_id_var, 'I have never been to Africa', 'I have never been to Africa', '["I", "have", "never", "been", "to", "Africa"]'::jsonb);
    -- 4. Speaking Practice (5 prompts - CEFR B1: Travel experiences)
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content) VALUES (lesson_id_var, 'speaking_practice', 9, 'Talk About Travel', 'Practice talking about trips', '{"prompts": ["What is the best trip you have ever taken?", "What countries have you visited?", "What do you enjoy most about traveling?", "How do you plan your trips?", "What is your dream destination?"]}'::jsonb) RETURNING id INTO activity_id_var;

END $$;
INSERT INTO lesson_activities (
  lesson_id,
  activity_type,
  activity_order,
  title,
  description,
  content
) VALUES (
  'B1-L7',
  'speaking_improvement',
  10,
  'Speaking Improvement',
  'Read the improved version of your speech',
  '{"type": "speaking_improvement", "similarityThreshold": 70}'::jsonb
);