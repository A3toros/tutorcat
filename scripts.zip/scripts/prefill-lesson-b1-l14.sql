-- =========================================
-- Pre-fill Database with Sample Lesson Data
-- B1-L14: Workplace Communication
-- =========================================

DELETE FROM grammar_sentences WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'B1-L14');
DELETE FROM vocabulary_items WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'B1-L14');
DELETE FROM lesson_activities WHERE lesson_id = 'B1-L14';
DELETE FROM lessons WHERE id = 'B1-L14';

INSERT INTO lessons (id, level, lesson_number, topic) VALUES
('B1-L14', 'B1', 14, 'Workplace Communication')
ON CONFLICT (id) DO UPDATE SET topic = EXCLUDED.topic;

DO $$
DECLARE
    lesson_id_var TEXT := 'B1-L14';
    activity_id_var UUID;
BEGIN
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'warm_up_speaking', 1, 'Clear Messages', 'Talk about handling unclear instructions and messages at work', '{"prompt": "How do you handle unclear instructions from someone?"}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_intro', 2, 'Communication Words', 'Learn workplace communication vocabulary', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'brief', 'สรุปย่อ', NULL),
    (activity_id_var, 'clarify', 'ชี้แจง', NULL),
    (activity_id_var, 'confirm', 'ยืนยัน', NULL),
    (activity_id_var, 'respond', 'ตอบสนอง', NULL),
    (activity_id_var, 'deadline', 'กำหนดส่ง', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_matching_drag', 3, 'Match Communication Words', 'Match words with meanings', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'brief', 'สรุปย่อ', NULL),
    (activity_id_var, 'clarify', 'ชี้แจง', NULL),
    (activity_id_var, 'confirm', 'ยืนยัน', NULL),
    (activity_id_var, 'respond', 'ตอบสนอง', NULL),
    (activity_id_var, 'deadline', 'กำหนดส่ง', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 4, 'Complete the Sentences 1', 'Fill with the correct word', '{"text": "I sent a short ___. Please ___ the details. We must meet the ___.", "blanks": [{"id": "blank1", "text": "brief", "options": ["brief", "deadline", "respond", "confirm"], "correctAnswer": "brief"}, {"id": "blank2", "text": "confirm", "options": ["confirm", "clarify", "brief", "deadline"], "correctAnswer": "confirm"}, {"id": "blank3", "text": "deadline", "options": ["deadline", "respond", "brief", "clarify"], "correctAnswer": "deadline"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 5, 'Complete the Sentences 2', 'Fill with the correct word', '{"text": "Can you ___ the request? I will ___ if it is correct. We should ___ the timeline.", "blanks": [{"id": "blank1", "text": "clarify", "options": ["clarify", "respond", "brief", "confirm"], "correctAnswer": "clarify"}, {"id": "blank2", "text": "respond", "options": ["respond", "confirm", "clarify", "deadline"], "correctAnswer": "respond"}, {"id": "blank3", "text": "confirm", "options": ["confirm", "respond", "clarify", "deadline"], "correctAnswer": "confirm"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    -- Grammar Explanation: Modals (must / have to / should) for duties and advice
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_explanation', 6, 'Modals for Duties and Advice', 'Use must / have to / should for rules, necessity, and advice in workplace communication', '{"rules": "Use must and have to for strong necessity or rules. Use should for advice or recommendations.\\n- You must send the report today.\\n- We have to meet the deadline.\\n- You should clarify the details.\\nDo not use contractions. Keep statements clear.", "examples": ["You must include the deadline in the email.", "We have to clarify the task before we start.", "You should confirm the meeting time.", "They must respond to the client by noon.", "She should brief the team after the call."]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 7, 'Build Sentences 1', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'You must include the deadline in the email', 'You must include the deadline in the email', '["You", "must", "include", "the", "deadline", "in", "the", "email"]'::jsonb),
    (activity_id_var, 'We have to clarify the task before we start', 'We have to clarify the task before we start', '["We", "have", "to", "clarify", "the", "task", "before", "we", "start"]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 8, 'Build Sentences 2', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'You should confirm the meeting time', 'You should confirm the meeting time', '["You", "should", "confirm", "the", "meeting", "time"]'::jsonb),
    (activity_id_var, 'They must respond to the client by noon', 'They must respond to the client by noon', '["They", "must", "respond", "to", "the", "client", "by", "noon"]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'speaking_practice', 9, 'Talk About Communication', 'Practice talking about workplace communication', '{"prompts": ["How do you handle unclear instructions from someone?", "When do you feel you should push back?", "Describe the best work message you have sent or received."]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (
      lesson_id,
      activity_type,
      activity_order,
      title,
      description,
      content
    ) VALUES (
      'B1-L14',
      'speaking_improvement',
      10,
      'Speaking Improvement',
      'Read the improved version of your speech',
      '{"type": "speaking_improvement", "similarityThreshold": 70}'::jsonb
    );
END $$;


