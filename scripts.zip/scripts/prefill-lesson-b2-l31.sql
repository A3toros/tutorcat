-- =========================================
-- Pre-fill Database with Sample Lesson Data
-- B2-L31: Healthy lifestyle for students
-- =========================================

DELETE FROM grammar_sentences WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'B2-L31');
DELETE FROM vocabulary_items WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'B2-L31');
DELETE FROM lesson_activities WHERE lesson_id = 'B2-L31';
DELETE FROM lessons WHERE id = 'B2-L31';

INSERT INTO lessons (id, level, lesson_number, topic) VALUES
('B2-L31', 'B2', 31, 'Healthy lifestyle for students')
ON CONFLICT (id) DO UPDATE SET topic = EXCLUDED.topic;

DO $$
DECLARE
    lesson_id_var TEXT := 'B2-L31';
    activity_id_var UUID;
BEGIN
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'warm_up_speaking', 1, 'Energy Habits', 'Talk about routines', '{"prompt": "How have you kept energy up lately, and what habit sticks?"}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_intro', 2, 'Health Words', 'Key words for student health', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'nutrition', 'โภชนาการ', NULL),
    (activity_id_var, 'hydrate', 'ดื่มน้ำให้เพียงพอ', NULL),
    (activity_id_var, 'stamina', 'ความทนทาน/พลังงาน', NULL),
    (activity_id_var, 'consistent', 'สม่ำเสมอ', NULL),
    (activity_id_var, 'crash', 'หมดแรง/พลังตก', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_matching_drag', 3, 'Match Health Words', 'Match words with meanings', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'nutrition', 'โภชนาการ', NULL),
    (activity_id_var, 'hydrate', 'ดื่มน้ำให้เพียงพอ', NULL),
    (activity_id_var, 'stamina', 'ความทนทาน/พลังงาน', NULL),
    (activity_id_var, 'consistent', 'สม่ำเสมอ', NULL),
    (activity_id_var, 'crash', 'หมดแรง/พลังตก', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 4, 'Complete the Sentences 1', 'Fill with the correct word', '{"text": "Good ___ supports ___. I drink water to ___.", "blanks": [{"id": "blank1", "text": "nutrition", "options": ["nutrition", "stamina", "hydrate", "consistent"], "correctAnswer": "nutrition"}, {"id": "blank2", "text": "stamina", "options": ["stamina", "crash", "hydrate", "consistent"], "correctAnswer": "stamina"}, {"id": "blank3", "text": "hydrate", "options": ["hydrate", "nutrition", "consistent", "crash"], "correctAnswer": "hydrate"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 5, 'Complete the Sentences 2', 'Fill with the correct word', '{"text": "A ___ schedule stops a ___.", "blanks": [{"id": "blank1", "text": "consistent", "options": ["consistent", "crash", "hydrate", "stamina"], "correctAnswer": "consistent"}, {"id": "blank2", "text": "crash", "options": ["crash", "stamina", "consistent", "nutrition"], "correctAnswer": "crash"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_explanation', 6, 'Reason & Result (so/such…that)', 'Connect habits and outcomes', '{"rules": "Use so + adj/adv + that or such + (a/an) + noun + that for clear cause/effect. Keep results specific.\\n- The routine was so consistent that my energy stayed high.\\n- It was such a long week that I crashed on Friday.", "examples": ["My diet was so steady that my focus improved.", "I had such a consistent sleep time that mornings felt easier.", "The workout was so intense that I needed a nap.", "It was such a rushed day that I forgot to hydrate.", "The breaks were so short that I still felt tired."]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 7, 'Build Sentences 1', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'My diet was so steady that my focus improved', 'My diet was so steady that my focus improved.', '["My", "diet", "was", "so", "steady", "that", "my", "focus", "improved."]'::jsonb),
    (activity_id_var, 'It was such a rushed day that I forgot to hydrate', 'It was such a rushed day that I forgot to hydrate.', '["It", "was", "such", "a", "rushed", "day", "that", "I", "forgot", "to", "hydrate."]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 8, 'Build Sentences 2', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'The breaks were so short that I still felt tired', 'The breaks were so short that I still felt tired.', '["The", "breaks", "were", "so", "short", "that", "I", "still", "felt", "tired."]'::jsonb),
    (activity_id_var, 'It was such a long week that I crashed on Friday', 'It was such a long week that I crashed on Friday.', '["It", "was", "such", "a", "long", "week", "that", "I", "crashed", "on", "Friday."]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'speaking_practice', 9, 'Talk About Health Habits', 'Practice cause/effect', '{"prompts": ["What habit is so effective you keep it daily?", "When was a day so long that you crashed?", "How do you stay consistent during exams?"]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (
      lesson_id,
      activity_type,
      activity_order,
      title,
      description,
      content
    ) VALUES (
      'B2-L31',
      'speaking_improvement',
      10,
      'Speaking Improvement',
      'Read the improved version of your speech',
      '{"type": "speaking_improvement", "similarityThreshold": 70}'::jsonb
    );
END $$;


