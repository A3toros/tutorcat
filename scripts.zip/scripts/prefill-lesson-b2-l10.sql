-- =========================================
-- Pre-fill Database with Sample Lesson Data
-- B2-L10: Personal Development
-- =========================================

DELETE FROM grammar_sentences WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'B2-L10');
DELETE FROM vocabulary_items WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'B2-L10');
DELETE FROM lesson_activities WHERE lesson_id = 'B2-L10';
DELETE FROM lessons WHERE id = 'B2-L10';

INSERT INTO lessons (id, level, lesson_number, topic) VALUES
('B2-L10', 'B2', 10, 'Personal Development')
ON CONFLICT (id) DO UPDATE SET topic = EXCLUDED.topic;

DO $$
DECLARE
    lesson_id_var TEXT := 'B2-L10';
    activity_id_var UUID;
BEGIN
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'warm_up_speaking', 1, 'Growth Moments', 'Talk about learning from choices', '{"prompt": "What recent habit changed you the most?"}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_intro', 2, 'Growth Words', 'Key words for development', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'resilience', 'ความยืดหยุ่น/ฟื้นตัวได้', NULL),
    (activity_id_var, 'mentor', 'ที่ปรึกษา/พี่เลี้ยง', NULL),
    (activity_id_var, 'setback', 'อุปสรรค/การถอยหลัง', NULL),
    (activity_id_var, 'milestone', 'เหตุการณ์สำคัญ', NULL),
    (activity_id_var, 'self-reflection', 'การไตร่ตรองตนเอง', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_matching_drag', 3, 'Match Growth Words', 'Match words with meanings', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'resilience', 'ความยืดหยุ่น/ฟื้นตัวได้', NULL),
    (activity_id_var, 'mentor', 'ที่ปรึกษา/พี่เลี้ยง', NULL),
    (activity_id_var, 'setback', 'อุปสรรค/การถอยหลัง', NULL),
    (activity_id_var, 'milestone', 'เหตุการณ์สำคัญ', NULL),
    (activity_id_var, 'self-reflection', 'การไตร่ตรองตนเอง', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 4, 'Complete the Sentences 1', 'Fill with the correct word', '{"text": "A mentor helped me after a ___. That moment was a big ___. I practice ___.", "blanks": [{"id": "blank1", "text": "setback", "options": ["setback", "mentor", "milestone", "self-reflection"], "correctAnswer": "setback"}, {"id": "blank2", "text": "milestone", "options": ["milestone", "setback", "mentor", "resilience"], "correctAnswer": "milestone"}, {"id": "blank3", "text": "self-reflection", "options": ["self-reflection", "resilience", "milestone", "mentor"], "correctAnswer": "self-reflection"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 5, 'Complete the Sentences 2', 'Fill with the correct word', '{"text": "He showed real ___. She became my ___. That was a small ___ that still mattered.", "blanks": [{"id": "blank1", "text": "resilience", "options": ["resilience", "mentor", "setback", "milestone"], "correctAnswer": "resilience"}, {"id": "blank2", "text": "mentor", "options": ["mentor", "self-reflection", "resilience", "milestone"], "correctAnswer": "mentor"}, {"id": "blank3", "text": "milestone", "options": ["milestone", "resilience", "mentor", "setback"], "correctAnswer": "milestone"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_explanation', 6, 'Third Conditional', 'Talk about past hypotheticals and lessons', '{"rules": "Use if + past perfect + would have + past participle to talk about unreal past situations and results.\\n- If I had started earlier, I would have finished on time.\\nUse could/might have for less certain results.", "examples": ["If I had asked a mentor sooner, I would have avoided that setback.", "If she had rested, she might have recovered faster.", "If we had planned milestones, we would have stayed on track.", "If he had practiced self-reflection, he could have grown sooner.", "If they had noticed the problem, they would have fixed it earlier."]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 7, 'Build Sentences 1', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'If I had asked a mentor sooner, I would have avoided that setback', 'If I had asked a mentor sooner, I would have avoided that setback.', '["If", "I", "had", "asked", "a", "mentor", "sooner,", "I", "would", "have", "avoided", "that", "setback."]'::jsonb),
    (activity_id_var, 'If she had rested, she might have recovered faster', 'If she had rested, she might have recovered faster.', '["If", "she", "had", "rested,", "she", "might", "have", "recovered", "faster."]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 8, 'Build Sentences 2', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'If we had planned milestones, we would have stayed on track', 'If we had planned milestones, we would have stayed on track.', '["If", "we", "had", "planned", "milestones,", "we", "would", "have", "stayed", "on", "track."]'::jsonb),
    (activity_id_var, 'If he had practiced self-reflection, he could have grown sooner', 'If he had practiced self-reflection, he could have grown sooner.', '["If", "he", "had", "practiced", "self-reflection,", "he", "could", "have", "grown", "sooner."]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'speaking_practice', 9, 'Talk About Growth', 'Practice past lessons and changes', '{"prompts": ["If you had more time last term, what would you have done?", "Who acted like a mentor for you, and how?", "What small milestone are you proud of?"]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (
      lesson_id,
      activity_type,
      activity_order,
      title,
      description,
      content
    ) VALUES (
      'B2-L10',
      'speaking_improvement',
      10,
      'Speaking Improvement',
      'Read the improved version of your speech',
      '{"type": "speaking_improvement", "similarityThreshold": 70}'::jsonb
    );
END $$;


