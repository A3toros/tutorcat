-- =========================================
-- Pre-fill Database with Sample Lesson Data
-- A1-L88: Dream Job (simple)
-- =========================================

DELETE FROM grammar_sentences WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'A1-L88');
DELETE FROM vocabulary_items WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'A1-L88');
DELETE FROM lesson_activities WHERE lesson_id = 'A1-L88');
DELETE FROM lessons WHERE id = 'A1-L88';

INSERT INTO lessons (id, level, lesson_number, topic) VALUES
('A1-L88', 'A1', 88, 'Dream Job (simple)')
ON CONFLICT (id) DO UPDATE SET topic = EXCLUDED.topic;

DO $$
DECLARE
    lesson_id_var TEXT := 'A1-L88';
    activity_id_var UUID;
BEGIN
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'warm_up_speaking', 1, 'Dream Job', 'Talk about dream jobs', '{"prompt": "What job do you want?"}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_intro', 2, 'Job Words', 'Learn dream job words', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'job', 'งาน', NULL),
    (activity_id_var, 'dream', 'ความฝัน', NULL),
    (activity_id_var, 'want', 'ต้องการ', NULL),
    (activity_id_var, 'like', 'ชอบ', NULL),
    (activity_id_var, 'work', 'ทำงาน', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_matching_drag', 3, 'Match Job Words', 'Match dream job words', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'job', 'งาน', NULL),
    (activity_id_var, 'dream', 'ความฝัน', NULL),
    (activity_id_var, 'want', 'ต้องการ', NULL),
    (activity_id_var, 'like', 'ชอบ', NULL),
    (activity_id_var, 'work', 'ทำงาน', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 4, 'Complete the Sentences 1', 'Fill with the correct word', '{"text": "My ___ job is to be a ___.", "blanks": [{"id": "blank1", "text": "dream", "options": ["dream", "job", "want", "work"], "correctAnswer": "dream"}, {"id": "blank2", "text": "job", "options": ["job", "work", "like", "want"], "correctAnswer": "job"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 5, 'Complete the Sentences 2', 'Fill with the correct word', '{"text": "I ___ to be a ___. I ___ this job.", "blanks": [{"id": "blank1", "text": "want", "options": ["want", "like", "dream", "job"], "correctAnswer": "want"}, {"id": "blank2", "text": "work", "options": ["work", "job", "like", "dream"], "correctAnswer": "work"}, {"id": "blank3", "text": "like", "options": ["like", "want", "work", "job"], "correctAnswer": "like"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_explanation', 6, 'Be + Job / Want', 'Say what job you want', '{"rules": "Use be for job; want to be for dream.\n- I want to be a doctor.\n- I like this job.\nAsk: What job do you want?", "examples": ["I want to be a doctor.", "I want to be a chef.", "I like this job.", "What job do you want?", "Is that your dream job?"]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 7, 'Build Sentences 1', 'Arrange words', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'I want to be a doctor', 'I want to be a doctor.', '["I", "want", "to", "be", "a", "doctor."]'::jsonb),
    (activity_id_var, 'I like this job', 'I like this job.', '["I", "like", "this", "job."]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 8, 'Build Sentences 2', 'Arrange words', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'What job do you want', 'What job do you want?', '["What", "job", "do", "you", "want?"]'::jsonb),
    (activity_id_var, 'Is that your dream job', 'Is that your dream job?', '["Is", "that", "your", "dream", "job?"]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'speaking_practice', 9, 'Talk About Dream Jobs', 'Practice want to be', '{"prompts": ["What job do you want?", "Is that your dream job?", "Do you like this job?", "Do you want to be a doctor?", "Do you want to be a chef?"]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (
      lesson_id,
      activity_type,
      activity_order,
      title,
      description,
      content
    ) VALUES (
      'A1-L88',
      'speaking_improvement',
      10,
      'Speaking Improvement',
      'Read the improved version of your speech',
      '{"type": "speaking_improvement", "similarityThreshold": 70}'::jsonb
    );
END $$;

