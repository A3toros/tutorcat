-- ===== LESSON A1-L47 =====

-- =========================================
-- Pre-fill Database with Sample Lesson Data
-- A1-L47: Favorite Things
-- =========================================

DELETE FROM grammar_sentences WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'A1-L47');
DELETE FROM vocabulary_items WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'A1-L47');
DELETE FROM lesson_activities WHERE lesson_id = 'A1-L47';
DELETE FROM lessons WHERE id = 'A1-L47';

INSERT INTO lessons (id, level, lesson_number, topic) VALUES
('A1-L47', 'A1', 47, 'Favorite Things')
ON CONFLICT (id) DO UPDATE SET topic = EXCLUDED.topic;

DO $$
DECLARE
    lesson_id_var TEXT := 'A1-L47';
    activity_id_var UUID;
BEGIN
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'warm_up_speaking', 1, 'What do you like?', 'Talk about favorite things', '{"prompt": "Do you like rice?"}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_intro', 2, 'Favorite Words', 'Learn favorite words', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'toy', 'ของเล่น', NULL),
    (activity_id_var, 'game', 'เกม', NULL),
    (activity_id_var, 'song', 'เพลง', NULL),
    (activity_id_var, 'movie', 'หนัง', NULL),
    (activity_id_var, 'book', 'หนังสือ', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_matching_drag', 3, 'Match Favorite Words', 'Match favorite words', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'toy', 'ของเล่น', NULL),
    (activity_id_var, 'game', 'เกม', NULL),
    (activity_id_var, 'song', 'เพลง', NULL),
    (activity_id_var, 'movie', 'หนัง', NULL),
    (activity_id_var, 'book', 'หนังสือ', NULL);

    -- 4. Vocabulary Fill Blanks #1
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 4, 'Complete the Sentences 1', 'Fill in the blanks with correct words', '{"text": "I like to play with my ___. I listen to my favorite ___. I read a ___.", "blanks": [{"id": "blank1", "text": "toy", "options": ["toy", "game", "song", "movie"], "correctAnswer": "toy"}, {"id": "blank2", "text": "song", "options": ["song", "toy", "game", "book"], "correctAnswer": "song"}, {"id": "blank3", "text": "book", "options": ["book", "toy", "song", "movie"], "correctAnswer": "book"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    -- 5. Vocabulary Fill Blanks #2
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 5, 'Complete the Sentences 2', 'Fill in the blanks with correct words', '{"text": "I play a ___. I watch a ___. My favorite ___ is fun.", "blanks": [{"id": "blank1", "text": "game", "options": ["game", "toy", "song", "movie"], "correctAnswer": "game"}, {"id": "blank2", "text": "movie", "options": ["movie", "toy", "game", "book"], "correctAnswer": "movie"}, {"id": "blank3", "text": "game", "options": ["game", "toy", "song", "book"], "correctAnswer": "game"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    -- 6. Grammar Explanation
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_explanation', 6, 'Like / Don''t Like', 'Learn like/don''t like preferences', '{"rules": "Use like to talk about preferences:\n\n- I like + noun (I like rice)\n- She likes + noun (She likes games)\n- They don''t like + noun (They don''t like movies)\n- Use likes for he/she/it, like for I/you/we/they", "examples": ["I like rice.", "She likes games.", "They don''t like movies.", "We like books.", "He doesn''t like toys."]}'::jsonb)
    RETURNING id INTO activity_id_var;

    -- 7. Grammar Sentences #1
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 7, 'Build Sentences 1', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'I like rice', 'I like rice.', '["I", "like", "rice."]'::jsonb),
    (activity_id_var, 'She likes games', 'She likes games.', '["She", "likes", "games."]'::jsonb);

    -- 8. Grammar Sentences #2
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 8, 'Build Sentences 2', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'They don''t like movies', 'They don''t like movies.', '["They", "don''t", "like", "movies."]'::jsonb),
    (activity_id_var, 'We like books', 'We like books.', '["We", "like", "books."]'::jsonb);

    -- 9. Speaking Practice
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'speaking_practice', 9, 'Talk About Favorites', 'Practice talking about favorites', '{"prompts": ["What is your favorite food?", "Do you like listening to music?", "What games do you play?", "What is your favorite movie?", "Do you like reading books?"]}'::jsonb)
    RETURNING id INTO activity_id_var;

    -- 10. Speaking Improvement
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'speaking_improvement', 10, 'Speaking Improvement', 'Read the improved version of your speech', '{"type": "speaking_improvement", "similarityThreshold": 70}'::jsonb)
    RETURNING id INTO activity_id_var;
END $$;