-- =========================================
-- Pre-fill Database with Sample Lesson Data
-- A2-L19: Playing Team Sports
-- =========================================

DELETE FROM grammar_sentences WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'A2-L19');
DELETE FROM vocabulary_items WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'A2-L19');
DELETE FROM lesson_activities WHERE lesson_id = 'A2-L19';
DELETE FROM lessons WHERE id = 'A2-L19';

INSERT INTO lessons (id, level, lesson_number, topic) VALUES
('A2-L19', 'A2', 19, 'Playing Team Sports')
ON CONFLICT (id) DO UPDATE SET topic = EXCLUDED.topic;

DO $$
DECLARE
    lesson_id_var TEXT := 'A2-L19';
    activity_id_var UUID;
BEGIN
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'warm_up_speaking', 1, 'Team Sports', 'Talk about sports you play', '{"prompt": "Are you playing on a team now?"}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_intro', 2, 'Sports Words', 'Learn team sport vocabulary', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'team', 'ทีม', NULL),
    (activity_id_var, 'match', 'การแข่งขัน', NULL),
    (activity_id_var, 'practice', 'ฝึกซ้อม', NULL),
    (activity_id_var, 'coach', 'โค้ช', NULL),
    (activity_id_var, 'score', 'ทำคะแนน', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_matching_drag', 3, 'Match Sports Words', 'Match sports words', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'team', 'ทีม', NULL),
    (activity_id_var, 'match', 'การแข่งขัน', NULL),
    (activity_id_var, 'practice', 'ฝึกซ้อม', NULL),
    (activity_id_var, 'coach', 'โค้ช', NULL),
    (activity_id_var, 'score', 'ทำคะแนน', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 4, 'Complete the Sentences 1', 'Fill with the correct word', '{"text": "Our ___ is tonight. We ___ after school. The ___ helps us ___.", "blanks": [{"id": "blank1", "text": "match", "options": ["match", "coach", "practice", "score"], "correctAnswer": "match"}, {"id": "blank2", "text": "practice", "options": ["practice", "score", "match", "team"], "correctAnswer": "practice"}, {"id": "blank3", "text": "coach", "options": ["coach", "score", "practice", "team"], "correctAnswer": "coach"}, {"id": "blank4", "text": "score", "options": ["score", "coach", "practice", "team"], "correctAnswer": "score"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 5, 'Complete the Sentences 2', 'Fill with the correct word', '{"text": "I play on a ___. We have a ___ every weekend. The ___ gives us a plan.", "blanks": [{"id": "blank1", "text": "team", "options": ["team", "match", "coach", "score"], "correctAnswer": "team"}, {"id": "blank2", "text": "match", "options": ["match", "practice", "team", "score"], "correctAnswer": "match"}, {"id": "blank3", "text": "coach", "options": ["coach", "team", "score", "match"], "correctAnswer": "coach"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_explanation', 6, 'Present Continuous Now', 'Talk about actions happening now', '{"rules": "Use am/is/are + verb-ing for actions now.\n- We are practicing now.\n- He is talking to the coach.\nQuestions: Are you playing today?", "examples": ["We are practicing after school.", "He is talking to the coach.", "They are playing a match now.", "Are you scoring many points?", "I am watching the team today."]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 7, 'Build Sentences 1', 'Arrange words', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'We are practicing after school', 'We are practicing after school.', '["We", "are", "practicing", "after", "school."]'::jsonb),
    (activity_id_var, 'He is talking to the coach', 'He is talking to the coach.', '["He", "is", "talking", "to", "the", "coach."]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 8, 'Build Sentences 2', 'Arrange words', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'They are playing a match now', 'They are playing a match now.', '["They", "are", "playing", "a", "match", "now."]'::jsonb),
    (activity_id_var, 'Are you scoring many points', 'Are you scoring many points?', '["Are", "you", "scoring", "many", "points?"]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'speaking_practice', 9, 'Talk About Team Sports', 'Practice talking about playing on a team', '{"prompts": ["Are you playing on a team now?", "What position do you like to play?", "When are you practicing with your team?", "How often do you play or train?", "What sport would you like to try in the future?"]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (
      lesson_id,
      activity_type,
      activity_order,
      title,
      description,
      content
    ) VALUES (
      'A2-L19',
      'speaking_improvement',
      10,
      'Speaking Improvement',
      'Read the improved version of your speech',
      '{"type": "speaking_improvement", "similarityThreshold": 70}'::jsonb
    );
END $$;

