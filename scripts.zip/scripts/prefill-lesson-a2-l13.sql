-- =========================================
-- Pre-fill Database with Sample Lesson Data
-- A2-L13: Comparing Prices
-- =========================================

DELETE FROM grammar_sentences WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'A2-L13');
DELETE FROM vocabulary_items WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'A2-L13');
DELETE FROM lesson_activities WHERE lesson_id = 'A2-L13';
DELETE FROM lessons WHERE id = 'A2-L13';

INSERT INTO lessons (id, level, lesson_number, topic) VALUES
('A2-L13', 'A2', 13, 'Comparing Prices')
ON CONFLICT (id) DO UPDATE SET topic = EXCLUDED.topic;

DO $$
DECLARE
    lesson_id_var TEXT := 'A2-L13';
    activity_id_var UUID;
BEGIN
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'warm_up_speaking', 1, 'Best Deal', 'Talk about finding good prices', '{"prompt": "Where do you usually find good prices?"}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_intro', 2, 'Price Words', 'Learn words for comparing prices', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'cheaper', 'ถูกกว่า', NULL),
    (activity_id_var, 'expensive', 'แพง', NULL),
    (activity_id_var, 'best', 'ดีที่สุด', NULL),
    (activity_id_var, 'price', 'ราคา', NULL),
    (activity_id_var, 'deal', 'ข้อตกลง/ของถูก', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_matching_drag', 3, 'Match Price Words', 'Match shopping words', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'cheaper', 'ถูกกว่า', NULL),
    (activity_id_var, 'expensive', 'แพง', NULL),
    (activity_id_var, 'best', 'ดีที่สุด', NULL),
    (activity_id_var, 'price', 'ราคา', NULL),
    (activity_id_var, 'deal', 'ข้อตกลง/ของถูก', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 4, 'Complete the Sentences 1', 'Fill with the correct word', '{"text": "This phone is ___ than that one. The laptop is very ___. I want the ___ price.", "blanks": [{"id": "blank1", "text": "cheaper", "options": ["cheaper", "expensive", "best", "deal"], "correctAnswer": "cheaper"}, {"id": "blank2", "text": "expensive", "options": ["expensive", "cheaper", "best", "deal"], "correctAnswer": "expensive"}, {"id": "blank3", "text": "best", "options": ["best", "cheaper", "expensive", "deal"], "correctAnswer": "best"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 5, 'Complete the Sentences 2', 'Fill with the correct word', '{"text": "Can you give me a good ___? What is the ___ of this bag? Online prices are sometimes ___", "blanks": [{"id": "blank1", "text": "deal", "options": ["deal", "price", "cheaper", "expensive"], "correctAnswer": "deal"}, {"id": "blank2", "text": "price", "options": ["price", "deal", "cheaper", "expensive"], "correctAnswer": "price"}, {"id": "blank3", "text": "cheaper", "options": ["cheaper", "expensive", "price", "deal"], "correctAnswer": "cheaper"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_explanation', 6, 'Comparatives', 'Compare two prices', '{"rules": "Use comparative adjectives to compare.\n- cheap → cheaper\n- expensive → more expensive\nStructure: X is cheaper than Y.\nSuperlative: the best, the most expensive.", "examples": ["This bus ticket is cheaper than the train.", "That phone is more expensive.", "This is the best deal today.", "Online prices are cheaper than in the mall.", "It is the most expensive item here."]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 7, 'Build Sentences 1', 'Arrange words', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'This ticket is cheaper than that one', 'This ticket is cheaper than that one.', '["This", "ticket", "is", "cheaper", "than", "that", "one."]'::jsonb),
    (activity_id_var, 'That laptop is more expensive', 'That laptop is more expensive.', '["That", "laptop", "is", "more", "expensive."]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 8, 'Build Sentences 2', 'Arrange words', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'This is the best price today', 'This is the best price today.', '["This", "is", "the", "best", "price", "today."]'::jsonb),
    (activity_id_var, 'Online deals are cheaper than mall prices', 'Online deals are cheaper than mall prices.', '["Online", "deals", "are", "cheaper", "than", "mall", "prices."]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'speaking_practice', 9, 'Talk About Prices', 'Practice comparing prices', '{"prompts": ["Where do you usually find good prices?", "Do you compare prices online or in stores?", "What was the best deal you have ever found?", "Which store near you has the cheapest prices?", "How do you decide if something is worth buying?"]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (
      lesson_id,
      activity_type,
      activity_order,
      title,
      description,
      content
    ) VALUES (
      'A2-L13',
      'speaking_improvement',
      10,
      'Speaking Improvement',
      'Read the improved version of your speech',
      '{"type": "speaking_improvement", "similarityThreshold": 70}'::jsonb
    );
END $$;

