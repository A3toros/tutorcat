-- =========================================
-- Pre-fill Database with Sample Lesson Data
-- A2-L70: Colors & Shapes
-- =========================================

DELETE FROM grammar_sentences WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'A2-L70');
DELETE FROM vocabulary_items WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'A2-L70');
DELETE FROM lesson_activities WHERE lesson_id = 'A2-L70';
DELETE FROM lessons WHERE id = 'A2-L70';

INSERT INTO lessons (id, level, lesson_number, topic) VALUES
('A2-L70', 'A2', 70, 'Colors & Shapes')
ON CONFLICT (id) DO UPDATE SET topic = EXCLUDED.topic;

DO $$
DECLARE
    lesson_id_var TEXT := 'A2-L70';
    activity_id_var UUID;
BEGIN
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'warm_up_speaking', 1, 'Colors and Shapes', 'Talk about describing objects', '{"prompt": "What colors do you like wearing?"}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_intro', 2, 'Color & Shape Words', 'Learn colors and shapes', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'red', 'สีแดง', NULL),
    (activity_id_var, 'blue', 'สีน้ำเงิน', NULL),
    (activity_id_var, 'round', 'กลม', NULL),
    (activity_id_var, 'square', 'สี่เหลี่ยมจัตุรัส', NULL),
    (activity_id_var, 'striped', 'ลายทาง', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_matching_drag', 3, 'Match Color & Shape Words', 'Match color and shape words', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'red', 'สีแดง', NULL),
    (activity_id_var, 'blue', 'สีน้ำเงิน', NULL),
    (activity_id_var, 'round', 'กลม', NULL),
    (activity_id_var, 'square', 'สี่เหลี่ยมจัตุรัส', NULL),
    (activity_id_var, 'striped', 'ลายทาง', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 4, 'Complete the Sentences 1', 'Fill with the correct word', '{"text": "The bag is ___. The table is ___. The ball is ___.", "blanks": [{"id": "blank1", "text": "red", "options": ["red", "blue", "round", "square"], "correctAnswer": "red"}, {"id": "blank2", "text": "square", "options": ["square", "round", "blue", "striped"], "correctAnswer": "square"}, {"id": "blank3", "text": "round", "options": ["round", "striped", "red", "square"], "correctAnswer": "round"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 5, 'Complete the Sentences 2', 'Fill with the correct word', '{"text": "My shirt is ___. I like a ___ pattern.", "blanks": [{"id": "blank1", "text": "blue", "options": ["blue", "red", "round", "square"], "correctAnswer": "blue"}, {"id": "blank2", "text": "striped", "options": ["striped", "round", "square", "blue"], "correctAnswer": "striped"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_explanation', 6, 'Be + Adjectives (description)', 'Describe objects with colors/shapes', '{"rules": "Use be + adjective to describe color/shape.\n- It is red and round.\nOrder: color before shape (a red round ball).\nQuestions: What color is it? What shape is it?", "examples": ["It is red and round.", "The table is square.", "The shirt is blue and striped.", "What color is your bag?", "Is the box square or round?"]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 7, 'Build Sentences 1', 'Arrange words', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'The shirt is blue and striped', 'The shirt is blue and striped.', '["The", "shirt", "is", "blue", "and", "striped."]'::jsonb),
    (activity_id_var, 'The table is square', 'The table is square.', '["The", "table", "is", "square."]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 8, 'Build Sentences 2', 'Arrange words', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'It is red and round', 'It is red and round.', '["It", "is", "red", "and", "round."]'::jsonb),
    (activity_id_var, 'Is the box square or round', 'Is the box square or round?', '["Is", "the", "box", "square", "or", "round?"]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'speaking_practice', 9, 'Talk About Colors & Shapes', 'Practice describing objects', '{"prompts": ["What colors do you like wearing?", "Do you prefer round or square objects?", "Describe a bag you use every day.", "What shapes do you see in your room?", "What color and shape do you like most?"]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (
      lesson_id,
      activity_type,
      activity_order,
      title,
      description,
      content
    ) VALUES (
      'A2-L70',
      'speaking_improvement',
      10,
      'Speaking Improvement',
      'Read the improved version of your speech',
      '{"type": "speaking_improvement", "similarityThreshold": 70}'::jsonb
    );
END $$;

