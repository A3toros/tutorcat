-- =========================================
-- Pre-fill Database with Sample Lesson Data
-- C1-L15: Fairness in Grading Systems
-- =========================================

DELETE FROM grammar_sentences WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'C1-L15');
DELETE FROM vocabulary_items WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'C1-L15');
DELETE FROM lesson_activities WHERE lesson_id = 'C1-L15';
DELETE FROM lessons WHERE id = 'C1-L15';

INSERT INTO lessons (id, level, lesson_number, topic) VALUES
('C1-L15', 'C1', 15, 'Fairness in Grading Systems')
ON CONFLICT (id) DO UPDATE SET topic = EXCLUDED.topic;

DO $$
DECLARE
    lesson_id_var TEXT := 'C1-L15';
    activity_id_var UUID;
BEGIN
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'warm_up_speaking', 1, 'Grading Fairness', 'Discuss fairness in grading', '{"prompt": "What makes grading fair in your opinion?"}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_intro', 2, 'Grading Vocabulary', 'Learn vocabulary about grading systems', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'fairness', 'ความยุติธรรม', NULL),
    (activity_id_var, 'objectivity', 'ความเป็นกลาง', NULL),
    (activity_id_var, 'consistency', 'ความสม่ำเสมอ', NULL),
    (activity_id_var, 'discrepancy', 'ความแตกต่าง', NULL),
    (activity_id_var, 'appeal', 'การอุทธรณ์', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_matching_drag', 3, 'Match Grading Words', 'Match English words with Thai meanings', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'fairness', 'ความยุติธรรม', NULL),
    (activity_id_var, 'objectivity', 'ความเป็นกลาง', NULL),
    (activity_id_var, 'consistency', 'ความสม่ำเสมอ', NULL),
    (activity_id_var, 'discrepancy', 'ความแตกต่าง', NULL),
    (activity_id_var, 'appeal', 'การอุทธรณ์', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 4, 'Complete the Sentences 1', 'Fill with the correct word', '{"text": "Grading requires ___ and ___. Students can ___ unfair grades.", "blanks": [{"id": "blank1", "text": "fairness", "options": ["fairness", "objectivity", "consistency", "discrepancy"], "correctAnswer": "fairness"}, {"id": "blank2", "text": "objectivity", "options": ["objectivity", "fairness", "consistency", "appeal"], "correctAnswer": "objectivity"}, {"id": "blank3", "text": "appeal", "options": ["appeal", "fairness", "objectivity", "discrepancy"], "correctAnswer": "appeal"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 5, 'Complete the Sentences 2', 'Fill with the correct word', '{"text": "___ in grading standards creates problems. A ___ between grades raises questions.", "blanks": [{"id": "blank1", "text": "Inconsistency", "options": ["Inconsistency", "Fairness", "Objectivity", "Appeal"], "correctAnswer": "Inconsistency"}, {"id": "blank2", "text": "discrepancy", "options": ["discrepancy", "fairness", "objectivity", "consistency"], "correctAnswer": "discrepancy"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_explanation', 6, 'Cleft Sentences and Emphatic Structures', 'Learn cleft sentences for emphasis', '{"rules": "Cleft sentences emphasize specific elements:\n- It-cleft: \"It is fairness that matters most.\"\n- What-cleft: \"What makes grading fair is consistency.\"\n- Wh-cleft: \"What I value is objectivity.\"\n\nStructure:\n- It + be + emphasized element + that/who clause\n- What + verb + be + emphasized element\n\nUse for:\n- Emphasizing importance: \"It is consistency that ensures fairness.\"\n- Highlighting focus: \"What matters is objectivity.\"\n- Clarifying meaning: \"What makes it fair is the rubric.\"", "examples": ["It is fairness that students value most.", "What makes grading fair is consistency.", "What I contest is the discrepancy.", "It is objectivity that ensures trust.", "What matters is the appeal process."]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 7, 'Build Sentences 1', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'It is fairness that makes grading systems trustworthy.', 'It is fairness that makes grading systems trustworthy.', '["It", "is", "fairness", "that", "makes", "grading", "systems", "trustworthy."]'::jsonb),
    (activity_id_var, 'What makes grading fair is consistent application of criteria.', 'What makes grading fair is consistent application of criteria.', '["What", "makes", "grading", "fair", "is", "consistent", "application", "of", "criteria."]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 8, 'Build Sentences 2', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'What I contest is the discrepancy between grades.', 'What I contest is the discrepancy between grades.', '["What", "I", "contest", "is", "the", "discrepancy", "between", "grades."]'::jsonb),
    (activity_id_var, 'It is objectivity that students expect from evaluators.', 'It is objectivity that students expect from evaluators.', '["It", "is", "objectivity", "that", "students", "expect", "from", "evaluators."]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'speaking_practice', 9, 'Discuss Grading Fairness', 'Practice speaking about grading systems', '{"prompts": ["What makes a grading system fair?", "When do students question grades?", "How important is objectivity in grading?", "What causes inconsistencies in grading?", "How can grading systems be improved?"]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (
      lesson_id,
      activity_type,
      activity_order,
      title,
      description,
      content
    ) VALUES (
      'C1-L15',
      'speaking_improvement',
      10,
      'Speaking Improvement',
      'Read the improved version of your speech',
      '{"type": "speaking_improvement", "similarityThreshold": 70}'::jsonb
    );
END $$;
