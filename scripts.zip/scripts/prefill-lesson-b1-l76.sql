-- =========================================
-- Pre-fill Database with Sample Lesson Data
-- B1-L76: Helping in Emergencies
-- =========================================

DELETE FROM grammar_sentences WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'B1-L76');
DELETE FROM vocabulary_items WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'B1-L76');
DELETE FROM lesson_activities WHERE lesson_id = 'B1-L76';
DELETE FROM lessons WHERE id = 'B1-L76';

INSERT INTO lessons (id, level, lesson_number, topic) VALUES
('B1-L76', 'B1', 76, 'Helping in Emergencies')
ON CONFLICT (id) DO UPDATE SET topic = EXCLUDED.topic;

DO $$
DECLARE
    lesson_id_var TEXT := 'B1-L76';
    activity_id_var UUID;
BEGIN
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'warm_up_speaking', 1, 'Emergency Actions', 'Talk about first steps in emergencies', '{"prompt": "If you saw an accident, what would you do first?"}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_intro', 2, 'Emergency Words', 'Learn vocabulary about helping in emergencies', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'assist', 'ช่วยเหลือ', NULL),
    (activity_id_var, 'call', 'โทร', NULL),
    (activity_id_var, 'respond', 'ตอบสนอง', NULL),
    (activity_id_var, 'calm', 'ทำให้สงบ', NULL),
    (activity_id_var, 'protect', 'ปกป้อง', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_matching_drag', 3, 'Match Emergency Words', 'Match words with meanings', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'assist', 'ช่วยเหลือ', NULL),
    (activity_id_var, 'call', 'โทร', NULL),
    (activity_id_var, 'respond', 'ตอบสนอง', NULL),
    (activity_id_var, 'calm', 'ทำให้สงบ', NULL),
    (activity_id_var, 'protect', 'ปกป้อง', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 4, 'Complete the Sentences 1', 'Fill with the correct word', '{"text": "I will ___ first. Then I ___ for help. We must ___ quickly.", "blanks": [{"id": "blank1", "text": "call", "options": ["call", "assist", "respond", "calm"], "correctAnswer": "call"}, {"id": "blank2", "text": "call", "options": ["call", "assist", "protect", "respond"], "correctAnswer": "call"}, {"id": "blank3", "text": "respond", "options": ["respond", "assist", "calm", "protect"], "correctAnswer": "respond"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 5, 'Complete the Sentences 2', 'Fill with the correct word', '{"text": "Try to ___ people. ___ the area if needed. Stay and ___ until help arrives.", "blanks": [{"id": "blank1", "text": "calm", "options": ["calm", "call", "assist", "respond"], "correctAnswer": "calm"}, {"id": "blank2", "text": "protect", "options": ["protect", "assist", "respond", "call"], "correctAnswer": "protect"}, {"id": "blank3", "text": "assist", "options": ["assist", "protect", "respond", "calm"], "correctAnswer": "assist"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    -- Grammar Explanation: First Conditional for emergencies
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_explanation', 6, 'First Conditional for Emergencies', 'Use if + present, will + base verb to show likely actions in emergencies', '{"rules": "If + present simple, will + base verb for likely responses.\\n- If I see an accident, I will call emergency services.\\n- If someone is hurt, we will protect the area.\\nNo contractions.", "examples": ["If I see an accident, I will call emergency services.", "If someone is hurt, I will stay and assist.", "If the area is dangerous, we will protect others.", "If people panic, I will try to calm them.", "If help is coming, I will keep responding."]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 7, 'Build Sentences 1', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'If I see an accident I will call emergency services', 'If I see an accident, I will call emergency services', '["If", "I", "see", "an", "accident,", "I", "will", "call", "emergency", "services"]'::jsonb),
    (activity_id_var, 'If someone is hurt I will stay and assist', 'If someone is hurt, I will stay and assist', '["If", "someone", "is", "hurt,", "I", "will", "stay", "and", "assist"]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 8, 'Build Sentences 2', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'If the area is dangerous we will protect others', 'If the area is dangerous, we will protect others', '["If", "the", "area", "is", "dangerous,", "we", "will", "protect", "others"]'::jsonb),
    (activity_id_var, 'If people panic I will try to calm them', 'If people panic, I will try to calm them', '["If", "people", "panic,", "I", "will", "try", "to", "calm", "them"]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'speaking_practice', 9, 'Talk About Emergencies', 'Practice talking about emergency responses', '{"prompts": ["If you saw an accident, what would you do first?", "How do you keep calm in a crisis?", "Who do you call right away?"]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (
      lesson_id,
      activity_type,
      activity_order,
      title,
      description,
      content
    ) VALUES (
      'B1-L76',
      'speaking_improvement',
      10,
      'Speaking Improvement',
      'Read the improved version of your speech',
      '{"type": "speaking_improvement", "similarityThreshold": 70}'::jsonb
    );
END $$;

