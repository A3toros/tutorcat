-- =========================================
-- Pre-fill Database with Sample Lesson Data
-- C1-L49: Automation and Society
-- =========================================
DELETE FROM lesson_activity_results WHERE lesson_id = 'C1-L49';
DELETE FROM user_progress WHERE lesson_id = 'C1-L49';
DELETE FROM lesson_history WHERE lesson_id = 'C1-L49';
DELETE FROM grammar_sentences WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'C1-L49');
DELETE FROM vocabulary_items WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'C1-L49');
DELETE FROM lesson_activities WHERE lesson_id = 'C1-L49';
DELETE FROM lessons WHERE id = 'C1-L49';

INSERT INTO lessons (id, level, lesson_number, topic) VALUES
('C1-L49', 'C1', 49, 'Automation and Society')
ON CONFLICT (id) DO UPDATE SET topic = EXCLUDED.topic;

DO $$
DECLARE
    lesson_id_var TEXT := 'C1-L49';
    activity_id_var UUID;
BEGIN
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'warm_up_speaking', 1, 'Automation', 'Discuss automation and society', '{"prompt": "What should remain human in an automated world?"}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_intro', 2, 'Automation Vocabulary', 'Learn vocabulary about automation', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'automation', 'ระบบอัตโนมัติ', NULL),
    (activity_id_var, 'task', 'งาน', NULL),
    (activity_id_var, 'impact', 'ผลกระทบ', NULL),
    (activity_id_var, 'concern', 'ความกังวล', NULL),
    (activity_id_var, 'adaptation', 'การปรับตัว', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_matching_drag', 3, 'Match Automation Words', 'Match English words with Thai meanings', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'automation', 'ระบบอัตโนมัติ', NULL),
    (activity_id_var, 'task', 'งาน', NULL),
    (activity_id_var, 'impact', 'ผลกระทบ', NULL),
    (activity_id_var, 'concern', 'ความกังวล', NULL),
    (activity_id_var, 'adaptation', 'การปรับตัว', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 4, 'Complete the Sentences 1', 'Fill with the correct word', '{"text": "Some ___ should be automated. Others must remain ___. ___ affects jobs.", "blanks": [{"id": "blank1", "text": "tasks", "options": ["tasks", "automation", "impact", "concern"], "correctAnswer": "tasks"}, {"id": "blank2", "text": "human", "options": ["human", "automation", "task", "impact"], "correctAnswer": "human"}, {"id": "blank3", "text": "Automation", "options": ["Automation", "Task", "Impact", "Concern"], "correctAnswer": "Automation"}, {"id": "blank4", "text": "impact", "options": ["impact", "automation", "task", "concern"], "correctAnswer": "impact"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 5, 'Complete the Sentences 2', 'Fill with the correct word', '{"text": "Ethical ___ require attention. Society must ___ to ___.", "blanks": [{"id": "blank1", "text": "concerns", "options": ["concerns", "automation", "task", "impact"], "correctAnswer": "concerns"}, {"id": "blank2", "text": "adapt", "options": ["adapt", "automation", "task", "impact"], "correctAnswer": "adapt"}, {"id": "blank3", "text": "automation", "options": ["automation", "task", "impact", "concern"], "correctAnswer": "automation"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_explanation', 6, 'Advanced Passives', 'Learn advanced passive structures', '{"rules": "Advanced passive forms:\n- \"Tasks should be automated.\" (obligation)\n- \"Some work must remain human.\" (necessity)\n- \"Automation is being implemented.\" (continuous)\n- \"Jobs have been affected.\" (perfect)\n- \"Society will be transformed.\" (future)\n\nUse when:\n- Focus is on action, not actor: \"Tasks should be automated.\"\n- Actor is unknown/unimportant: \"Automation was introduced gradually.\"\n- Formal/impersonal tone: \"It is required that some tasks remain human.\"", "examples": ["Some tasks should be automated for efficiency.", "Certain work must remain human.", "Automation is being implemented across industries.", "Jobs have been affected by automation.", "Society will be transformed by automation."]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 7, 'Build Sentences 1', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'Some tasks should be automated for efficiency.', 'Some tasks should be automated for efficiency.', '["Some", "tasks", "should", "be", "automated", "for", "efficiency."]'::jsonb),
    (activity_id_var, 'Certain work must remain human.', 'Certain work must remain human.', '["Certain", "work", "must", "remain", "human."]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 8, 'Build Sentences 2', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'Automation is being implemented across industries.', 'Automation is being implemented across industries.', '["Automation", "is", "being", "implemented", "across", "industries."]'::jsonb),
    (activity_id_var, 'Jobs have been affected by automation.', 'Jobs have been affected by automation.', '["Jobs", "have", "been", "affected", "by", "automation."]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'speaking_practice', 9, 'Discuss Automation', 'Practice speaking about automation', '{"prompts": ["What tasks should be automated?", "What should never be automated?", "How does automation affect jobs?", "What ethical concerns exist?", "How should society adapt to automation?"]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (
      lesson_id,
      activity_type,
      activity_order,
      title,
      description,
      content
    ) VALUES (
      'C1-L49',
      'speaking_improvement',
      10,
      'Speaking Improvement',
      'Read the improved version of your speech',
      '{"type": "speaking_improvement", "similarityThreshold": 70}'::jsonb
    );
END $$;
