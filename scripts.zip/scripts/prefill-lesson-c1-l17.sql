-- =========================================
-- Pre-fill Database with Sample Lesson Data
-- C1-L17: Digital Surveillance in Education
-- =========================================

DELETE FROM grammar_sentences WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'C1-L17');
DELETE FROM vocabulary_items WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'C1-L17');
DELETE FROM lesson_activities WHERE lesson_id = 'C1-L17';
DELETE FROM lessons WHERE id = 'C1-L17';

INSERT INTO lessons (id, level, lesson_number, topic) VALUES
('C1-L17', 'C1', 17, 'Digital Surveillance in Education')
ON CONFLICT (id) DO UPDATE SET topic = EXCLUDED.topic;

DO $$
DECLARE
    lesson_id_var TEXT := 'C1-L17';
    activity_id_var UUID;
BEGIN
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'warm_up_speaking', 1, 'Digital Surveillance', 'Discuss digital surveillance in education', '{"prompt": "How much student data should schools collect?"}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_intro', 2, 'Surveillance Vocabulary', 'Learn vocabulary about digital surveillance', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'surveillance', 'การเฝ้าระวัง', NULL),
    (activity_id_var, 'monitoring', 'การติดตาม', NULL),
    (activity_id_var, 'privacy', 'ความเป็นส่วนตัว', NULL),
    (activity_id_var, 'consent', 'ความยินยอม', NULL),
    (activity_id_var, 'intrusion', 'การบุกรุก', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_matching_drag', 3, 'Match Surveillance Words', 'Match English words with Thai meanings', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'surveillance', 'การเฝ้าระวัง', NULL),
    (activity_id_var, 'monitoring', 'การติดตาม', NULL),
    (activity_id_var, 'privacy', 'ความเป็นส่วนตัว', NULL),
    (activity_id_var, 'consent', 'ความยินยอม', NULL),
    (activity_id_var, 'intrusion', 'การบุกรุก', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 4, 'Complete the Sentences 1', 'Fill with the correct word', '{"text": "Digital ___ raises ___ concerns. Student ___ must be protected.", "blanks": [{"id": "blank1", "text": "surveillance", "options": ["surveillance", "monitoring", "privacy", "consent"], "correctAnswer": "surveillance"}, {"id": "blank2", "text": "privacy", "options": ["privacy", "surveillance", "monitoring", "intrusion"], "correctAnswer": "privacy"}, {"id": "blank3", "text": "privacy", "options": ["privacy", "surveillance", "monitoring", "consent"], "correctAnswer": "privacy"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 5, 'Complete the Sentences 2', 'Fill with the correct word', '{"text": "Continuous ___ may feel like ___. Informed ___ is essential.", "blanks": [{"id": "blank1", "text": "monitoring", "options": ["monitoring", "surveillance", "privacy", "intrusion"], "correctAnswer": "monitoring"}, {"id": "blank2", "text": "intrusion", "options": ["intrusion", "surveillance", "privacy", "consent"], "correctAnswer": "intrusion"}, {"id": "blank3", "text": "consent", "options": ["consent", "surveillance", "monitoring", "intrusion"], "correctAnswer": "consent"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_explanation', 6, 'Advanced Passives', 'Learn advanced passive structures', '{"rules": "Advanced passive forms:\n- \"Data should be handled carefully.\" (obligation)\n- \"Information must not be tracked without consent.\" (prohibition)\n- \"Surveillance is being implemented.\" (continuous)\n- \"Privacy has been compromised.\" (perfect)\n- \"Monitoring will be reviewed.\" (future)\n\nUse when:\n- Focus is on action, not actor: \"Data should be protected.\"\n- Actor is unknown/unimportant: \"Information was leaked.\"\n- Formal/impersonal tone: \"It is required that data be secured.\"", "examples": ["Data should be handled with care.", "Student information must not be tracked without consent.", "Surveillance is being implemented across campuses.", "Privacy has been compromised by excessive monitoring.", "Monitoring systems will be reviewed regularly."]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 7, 'Build Sentences 1', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'Data should be handled according to privacy regulations.', 'Data should be handled according to privacy regulations.', '["Data", "should", "be", "handled", "according", "to", "privacy", "regulations."]'::jsonb),
    (activity_id_var, 'Student information must not be tracked without consent.', 'Student information must not be tracked without consent.', '["Student", "information", "must", "not", "be", "tracked", "without", "consent."]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 8, 'Build Sentences 2', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'Surveillance is being implemented in many institutions.', 'Surveillance is being implemented in many institutions.', '["Surveillance", "is", "being", "implemented", "in", "many", "institutions."]'::jsonb),
    (activity_id_var, 'Privacy has been compromised by excessive monitoring.', 'Privacy has been compromised by excessive monitoring.', '["Privacy", "has", "been", "compromised", "by", "excessive", "monitoring."]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'speaking_practice', 9, 'Discuss Digital Surveillance', 'Practice speaking about surveillance', '{"prompts": ["What student data is commonly tracked?", "When does monitoring go too far?", "Is surveillance ever justified in schools?", "How can privacy be protected?", "What does informed consent mean for students?"]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (
      lesson_id,
      activity_type,
      activity_order,
      title,
      description,
      content
    ) VALUES (
      'C1-L17',
      'speaking_improvement',
      10,
      'Speaking Improvement',
      'Read the improved version of your speech',
      '{"type": "speaking_improvement", "similarityThreshold": 70}'::jsonb
    );
END $$;
