-- =========================================
-- Pre-fill Database with Sample Lesson Data
-- C1-L55: Science Communication & Public Trust
-- =========================================
DELETE FROM lesson_activity_results WHERE lesson_id = 'C1-L55';
DELETE FROM user_progress WHERE lesson_id = 'C1-L55';
DELETE FROM lesson_history WHERE lesson_id = 'C1-L55';
DELETE FROM grammar_sentences WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'C1-L55');
DELETE FROM vocabulary_items WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'C1-L55');
DELETE FROM lesson_activities WHERE lesson_id = 'C1-L55';
DELETE FROM lessons WHERE id = 'C1-L55';

INSERT INTO lessons (id, level, lesson_number, topic) VALUES
('C1-L55', 'C1', 55, 'Science Communication & Public Trust')
ON CONFLICT (id) DO UPDATE SET topic = EXCLUDED.topic;

DO $$
DECLARE
    lesson_id_var TEXT := 'C1-L55';
    activity_id_var UUID;
BEGIN
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'warm_up_speaking', 1, 'Science Communication', 'Discuss science communication', '{"prompt": "How should scientific information be communicated to the public?"}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_intro', 2, 'Science Communication Vocabulary', 'Learn vocabulary about science communication', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'communication', 'การสื่อสาร', NULL),
    (activity_id_var, 'trust', 'ความไว้วางใจ', NULL),
    (activity_id_var, 'evaluation', 'การประเมิน', NULL),
    (activity_id_var, 'effectiveness', 'ประสิทธิภาพ', NULL),
    (activity_id_var, 'claim', 'ข้อเรียกร้อง', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_matching_drag', 3, 'Match Science Communication Words', 'Match English words with Thai meanings', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'communication', 'การสื่อสาร', NULL),
    (activity_id_var, 'trust', 'ความไว้วางใจ', NULL),
    (activity_id_var, 'evaluation', 'การประเมิน', NULL),
    (activity_id_var, 'effectiveness', 'ประสิทธิภาพ', NULL),
    (activity_id_var, 'claim', 'ข้อเรียกร้อง', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 4, 'Complete the Sentences 1', 'Fill with the correct word', '{"text": "Science ___ builds ___. Effective ___ requires clarity.", "blanks": [{"id": "blank1", "text": "communication", "options": ["communication", "trust", "evaluation", "effectiveness"], "correctAnswer": "communication"}, {"id": "blank2", "text": "trust", "options": ["trust", "communication", "evaluation", "effectiveness"], "correctAnswer": "trust"}, {"id": "blank3", "text": "communication", "options": ["communication", "trust", "evaluation", "effectiveness"], "correctAnswer": "communication"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 5, 'Complete the Sentences 2', 'Fill with the correct word', '{"text": "Scientific ___ are evaluated by the public. ___ of communication matters.", "blanks": [{"id": "blank1", "text": "claims", "options": ["claims", "communication", "trust", "evaluation"], "correctAnswer": "claims"}, {"id": "blank2", "text": "Effectiveness", "options": ["Effectiveness", "Communication", "Trust", "Evaluation"], "correctAnswer": "Effectiveness"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_explanation', 6, 'Advanced Passives', 'Learn advanced passive structures', '{"rules": "Advanced passive forms:\n- \"Science should be communicated clearly.\" (obligation)\n- \"Trust must be built over time.\" (necessity)\n- \"Information is being shared.\" (continuous)\n- \"Trust has been lost.\" (perfect)\n- \"Communication will be improved.\" (future)\n\nUse when:\n- Focus is on action, not actor: \"Science should be communicated.\"\n- Actor is unknown/unimportant: \"Trust was built gradually.\"\n- Formal/impersonal tone: \"It is required that science be communicated clearly.\"", "examples": ["Science should be communicated clearly to the public.", "Trust must be built through transparent communication.", "Information is being shared more effectively.", "Trust has been lost due to poor communication.", "Communication will be improved through better methods."]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 7, 'Build Sentences 1', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'Science should be communicated clearly to the public.', 'Science should be communicated clearly to the public.', '["Science", "should", "be", "communicated", "clearly", "to", "the", "public."]'::jsonb),
    (activity_id_var, 'Trust must be built through transparent communication.', 'Trust must be built through transparent communication.', '["Trust", "must", "be", "built", "through", "transparent", "communication."]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 8, 'Build Sentences 2', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'Information is being shared more effectively.', 'Information is being shared more effectively.', '["Information", "is", "being", "shared", "more", "effectively."]'::jsonb),
    (activity_id_var, 'Trust has been lost due to poor communication.', 'Trust has been lost due to poor communication.', '["Trust", "has", "been", "lost", "due", "to", "poor", "communication."]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'speaking_practice', 9, 'Discuss Science Communication', 'Practice speaking about science communication', '{"prompts": ["How should science be communicated?", "Who should lead science communication?", "How is trust in science built or lost?", "What makes scientific communication effective?", "How are scientific claims evaluated by the public?"]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (
      lesson_id,
      activity_type,
      activity_order,
      title,
      description,
      content
    ) VALUES (
      'C1-L55',
      'speaking_improvement',
      10,
      'Speaking Improvement',
      'Read the improved version of your speech',
      '{"type": "speaking_improvement", "similarityThreshold": 70}'::jsonb
    );
END $$;
