-- =========================================
-- Delete Speaking Improvement Activities from Database
-- =========================================
-- This script removes all speaking improvement activities that were
-- incorrectly stored as 'speaking_practice' type with hardcoded prompts.
-- The improvement step will now use AI-generated improved transcripts
-- from the user's actual speech stored in localStorage.

-- First, check how many activities will be deleted (optional - uncomment to run)
/*
SELECT 
    activity_type,
    activity_order,
    title,
    lesson_id,
    COUNT(*) as count
FROM lesson_activities 
WHERE (activity_type = 'speaking_practice' AND activity_order IN (10, 11) AND title = 'Read Improved Response')
   OR activity_type = 'speaking_improvement'
GROUP BY activity_type, activity_order, title, lesson_id
ORDER BY lesson_id, activity_order;
*/

DO $$
BEGIN
    -- Delete activity 11 improvement activities (A1, A2, B1, B2 levels)
    DELETE FROM lesson_activities 
    WHERE activity_type = 'speaking_practice' 
      AND activity_order = 11 
      AND title = 'Read Improved Response';
    
    RAISE NOTICE 'Deleted activity 11 improvement activities';
    
    -- Delete activity 10 improvement activities (C1, C2 levels)
    -- These have activity_order = 10 and title = 'Read Improved Response'
    DELETE FROM lesson_activities 
    WHERE activity_type = 'speaking_practice' 
      AND activity_order = 10 
      AND title = 'Read Improved Response';
    
    RAISE NOTICE 'Deleted activity 10 improvement activities';
    
    -- Also delete any speaking_improvement type activities if they exist
    DELETE FROM lesson_activities 
    WHERE activity_type = 'speaking_improvement';
    
    RAISE NOTICE 'Deleted speaking_improvement type activities';
    
    RAISE NOTICE 'Cleanup complete!';
END $$;

