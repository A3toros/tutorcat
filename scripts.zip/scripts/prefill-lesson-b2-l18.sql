-- =========================================
-- Pre-fill Database with Sample Lesson Data
-- B2-L18: Media and student opinions
-- =========================================

DELETE FROM grammar_sentences WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'B2-L18');
DELETE FROM vocabulary_items WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'B2-L18');
DELETE FROM lesson_activities WHERE lesson_id = 'B2-L18';
DELETE FROM lessons WHERE id = 'B2-L18';

INSERT INTO lessons (id, level, lesson_number, topic) VALUES
('B2-L18', 'B2', 18, 'Media and student opinions')
ON CONFLICT (id) DO UPDATE SET topic = EXCLUDED.topic;

DO $$
DECLARE
    lesson_id_var TEXT := 'B2-L18';
    activity_id_var UUID;
BEGIN
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'warm_up_speaking', 1, 'Media Habits', 'Talk about reactions to news', '{"prompt": "Never have you what… when reading news, and who challenges your view?"}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_intro', 2, 'Media Words', 'Key words for opinions and news', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'headline', 'พาดหัวข่าว', NULL),
    (activity_id_var, 'bias', 'อคติ', NULL),
    (activity_id_var, 'verify', 'ตรวจสอบความถูกต้อง', NULL),
    (activity_id_var, 'platform', 'แพลตฟอร์ม', NULL),
    (activity_id_var, 'comment', 'ความเห็น/คอมเมนต์', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_matching_drag', 3, 'Match Media Words', 'Match words with meanings', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'headline', 'พาดหัวข่าว', NULL),
    (activity_id_var, 'bias', 'อคติ', NULL),
    (activity_id_var, 'verify', 'ตรวจสอบความถูกต้อง', NULL),
    (activity_id_var, 'platform', 'แพลตฟอร์ม', NULL),
    (activity_id_var, 'comment', 'ความเห็น/คอมเมนต์', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 4, 'Complete the Sentences 1', 'Fill with the correct word', '{"text": "I read the ___. I check the ___. I always ___ facts.", "blanks": [{"id": "blank1", "text": "headline", "options": ["headline", "bias", "verify", "platform"], "correctAnswer": "headline"}, {"id": "blank2", "text": "platform", "options": ["platform", "bias", "verify", "comment"], "correctAnswer": "platform"}, {"id": "blank3", "text": "verify", "options": ["verify", "headline", "comment", "bias"], "correctAnswer": "verify"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 5, 'Complete the Sentences 2', 'Fill with the correct word', '{"text": "Hidden ___ shapes views. I left a short ___.", "blanks": [{"id": "blank1", "text": "bias", "options": ["bias", "comment", "platform", "headline"], "correctAnswer": "bias"}, {"id": "blank2", "text": "comment", "options": ["comment", "bias", "verify", "platform"], "correctAnswer": "comment"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_explanation', 6, 'Inversion with Negative Adverbials', 'Use inversion for emphasis (Never/Rarely)', '{"rules": "For emphasis, move the auxiliary before the subject after negative adverbials: Never, Rarely, Hardly, Seldom. Structure: Negative adverbial + auxiliary + subject + verb.\\n- Never have I seen such bias.\\n- Rarely do students verify every source.", "examples": ["Never have I shared a link without reading it.", "Rarely do we agree on every headline.", "Seldom have students checked the full source.", "Hardly had I read it when a new update came.", "Never had I noticed the bias until my friend pointed it out."]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 7, 'Build Sentences 1', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'Never have I shared a link without reading it', 'Never have I shared a link without reading it.', '["Never", "have", "I", "shared", "a", "link", "without", "reading", "it."]'::jsonb),
    (activity_id_var, 'Rarely do we agree on every headline', 'Rarely do we agree on every headline.', '["Rarely", "do", "we", "agree", "on", "every", "headline."]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 8, 'Build Sentences 2', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'Hardly had I read it when a new update came', 'Hardly had I read it when a new update came.', '["Hardly", "had", "I", "read", "it", "when", "a", "new", "update", "came."]'::jsonb),
    (activity_id_var, 'Never had I noticed the bias until my friend pointed it out', 'Never had I noticed the bias until my friend pointed it out.', '["Never", "had", "I", "noticed", "the", "bias", "until", "my", "friend", "pointed", "it", "out."]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'speaking_practice', 9, 'Talk About Media Reactions', 'Practice inversion for emphasis', '{"prompts": ["Never have you what… when reading news?", "Who challenges your views the most?", "How do you verify before you comment?" ]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (
      lesson_id,
      activity_type,
      activity_order,
      title,
      description,
      content
    ) VALUES (
      'B2-L18',
      'speaking_improvement',
      10,
      'Speaking Improvement',
      'Read the improved version of your speech',
      '{"type": "speaking_improvement", "similarityThreshold": 70}'::jsonb
    );
END $$;


