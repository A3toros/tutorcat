-- =========================================
-- Pre-fill Database with Sample Lesson Data
-- A2-L28: Feeling Angry or Upset
-- =========================================

DELETE FROM grammar_sentences WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'A2-L28');
DELETE FROM vocabulary_items WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'A2-L28');
DELETE FROM lesson_activities WHERE lesson_id = 'A2-L28';
DELETE FROM lessons WHERE id = 'A2-L28';

INSERT INTO lessons (id, level, lesson_number, topic) VALUES
('A2-L28', 'A2', 28, 'Feeling Angry or Upset')
ON CONFLICT (id) DO UPDATE SET topic = EXCLUDED.topic;

DO $$
DECLARE
    lesson_id_var TEXT := 'A2-L28';
    activity_id_var UUID;
BEGIN
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'warm_up_speaking', 1, 'Frustration', 'Talk about anger calmly', '{"prompt": "What usually makes you angry or upset?"}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_intro', 2, 'Feeling Words', 'Learn words about anger', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'angry', 'โกรธ', NULL),
    (activity_id_var, 'upset', 'หงุดหงิด/ไม่สบายใจ', NULL),
    (activity_id_var, 'calm', 'สงบ', NULL),
    (activity_id_var, 'reason', 'เหตุผล', NULL),
    (activity_id_var, 'breathe', 'หายใจ', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_matching_drag', 3, 'Match Feeling Words', 'Match feeling words', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'angry', 'โกรธ', NULL),
    (activity_id_var, 'upset', 'หงุดหงิด/ไม่สบายใจ', NULL),
    (activity_id_var, 'calm', 'สงบ', NULL),
    (activity_id_var, 'reason', 'เหตุผล', NULL),
    (activity_id_var, 'breathe', 'หายใจ', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 4, 'Complete the Sentences 1', 'Fill with the correct word', '{"text": "I feel ___ when plans change. I try to ___ and stay ___.", "blanks": [{"id": "blank1", "text": "upset", "options": ["upset", "angry", "calm", "breathe"], "correctAnswer": "upset"}, {"id": "blank2", "text": "breathe", "options": ["breathe", "calm", "reason", "angry"], "correctAnswer": "breathe"}, {"id": "blank3", "text": "calm", "options": ["calm", "angry", "breathe", "reason"], "correctAnswer": "calm"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 5, 'Complete the Sentences 2', 'Fill with the correct word', '{"text": "What is the ___ you feel ___? He stays ___ when he is late.", "blanks": [{"id": "blank1", "text": "reason", "options": ["reason", "angry", "calm", "upset"], "correctAnswer": "reason"}, {"id": "blank2", "text": "angry", "options": ["angry", "reason", "calm", "upset"], "correctAnswer": "angry"}, {"id": "blank3", "text": "calm", "options": ["calm", "angry", "upset", "reason"], "correctAnswer": "calm"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_explanation', 6, 'Linkers: because / so', 'Explain reasons and results', '{"rules": "Use because to give a reason; use so to give a result.\n- I am angry because the bus is late.\n- The bus is late, so I am angry.", "examples": ["I am upset because I waited long.", "He is calm because he breathes slowly.", "The line is short, so we are happy.", "It is loud, so I feel upset.", "She is late because of traffic."]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 7, 'Build Sentences 1', 'Arrange words', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'I am upset because I waited long', 'I am upset because I waited long.', '["I", "am", "upset", "because", "I", "waited", "long."]'::jsonb),
    (activity_id_var, 'He is calm because he breathes slowly', 'He is calm because he breathes slowly.', '["He", "is", "calm", "because", "he", "breathes", "slowly."]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 8, 'Build Sentences 2', 'Arrange words', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'It is loud so I feel upset', 'It is loud, so I feel upset.', '["It", "is", "loud,", "so", "I", "feel", "upset."]'::jsonb),
    (activity_id_var, 'The bus is late so we are angry', 'The bus is late, so we are angry.', '["The", "bus", "is", "late,", "so", "we", "are", "angry."]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'speaking_practice', 9, 'Talk About Anger', 'Practice explaining feelings', '{"prompts": ["What usually makes you angry or upset?", "How do you calm down when you are angry?", "Do you talk to someone when you feel upset?", "Why do small problems sometimes feel big?", "What helps you feel better quickly?"]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (
      lesson_id,
      activity_type,
      activity_order,
      title,
      description,
      content
    ) VALUES (
      'A2-L28',
      'speaking_improvement',
      10,
      'Speaking Improvement',
      'Read the improved version of your speech',
      '{"type": "speaking_improvement", "similarityThreshold": 70}'::jsonb
    );
END $$;

