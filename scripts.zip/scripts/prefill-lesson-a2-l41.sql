-- =========================================
-- Pre-fill Database with Sample Lesson Data
-- A2-L41: Airport Check-in
-- =========================================

DELETE FROM grammar_sentences WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'A2-L41');
DELETE FROM vocabulary_items WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'A2-L41');
DELETE FROM lesson_activities WHERE lesson_id = 'A2-L41';
DELETE FROM lessons WHERE id = 'A2-L41';

INSERT INTO lessons (id, level, lesson_number, topic) VALUES
('A2-L41', 'A2', 41, 'Airport Check-in')
ON CONFLICT (id) DO UPDATE SET topic = EXCLUDED.topic;

DO $$
DECLARE
    lesson_id_var TEXT := 'A2-L41';
    activity_id_var UUID;
BEGIN
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'warm_up_speaking', 1, 'At the Airport', 'Talk about check-in', '{"prompt": "What are you usually doing when you arrive at the airport?"}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_intro', 2, 'Check-in Words', 'Learn airport check-in vocabulary', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'check-in', 'เช็กอิน', NULL),
    (activity_id_var, 'queue', 'คิว', NULL),
    (activity_id_var, 'luggage', 'กระเป๋าเดินทาง', NULL),
    (activity_id_var, 'boarding pass', 'บอร์ดดิ้งพาส', NULL),
    (activity_id_var, 'counter', 'เคาน์เตอร์', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_matching_drag', 3, 'Match Check-in Words', 'Match airport words', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'check-in', 'เช็กอิน', NULL),
    (activity_id_var, 'queue', 'คิว', NULL),
    (activity_id_var, 'luggage', 'กระเป๋าเดินทาง', NULL),
    (activity_id_var, 'boarding pass', 'บอร์ดดิ้งพาส', NULL),
    (activity_id_var, 'counter', 'เคาน์เตอร์', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 4, 'Complete the Sentences 1', 'Fill with the correct word', '{"text": "I am ___ at the ___. My ___ is heavy. I get my ___.", "blanks": [{"id": "blank1", "text": "checking in", "options": ["checking in", "queue", "luggage", "boarding pass"], "correctAnswer": "checking in"}, {"id": "blank2", "text": "counter", "options": ["counter", "queue", "boarding pass", "luggage"], "correctAnswer": "counter"}, {"id": "blank3", "text": "luggage", "options": ["luggage", "queue", "boarding pass", "counter"], "correctAnswer": "luggage"}, {"id": "blank4", "text": "boarding pass", "options": ["boarding pass", "counter", "queue", "luggage"], "correctAnswer": "boarding pass"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 5, 'Complete the Sentences 2', 'Fill with the correct word', '{"text": "The ___ is long. I am waiting in the ___.", "blanks": [{"id": "blank1", "text": "queue", "options": ["queue", "counter", "luggage", "boarding pass"], "correctAnswer": "queue"}, {"id": "blank2", "text": "queue", "options": ["queue", "counter", "boarding pass", "luggage"], "correctAnswer": "queue"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_explanation', 6, 'Present Continuous (plans/in-progress)', 'Describe what is happening now', '{"rules": "Use am/is/are + verb-ing for actions now or near plans.\n- I am checking in now.\n- We are waiting in the queue.\n- They are getting boarding passes.", "examples": ["I am checking in now.", "We are waiting in the queue.", "He is carrying the luggage.", "Are you printing the boarding pass?", "They are walking to the counter."]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 7, 'Build Sentences 1', 'Arrange words', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'I am checking in now', 'I am checking in now.', '["I", "am", "checking", "in", "now."]'::jsonb),
    (activity_id_var, 'We are waiting in the queue', 'We are waiting in the queue.', '["We", "are", "waiting", "in", "the", "queue."]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 8, 'Build Sentences 2', 'Arrange words', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'Are you printing the boarding pass', 'Are you printing the boarding pass?', '["Are", "you", "printing", "the", "boarding", "pass?"]'::jsonb),
    (activity_id_var, 'They are walking to the counter', 'They are walking to the counter.', '["They", "are", "walking", "to", "the", "counter."]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'speaking_practice', 9, 'Talk About Check-in', 'Practice airport check-in talk', '{"prompts": ["What are you usually doing when you arrive at the airport?", "Are you checking in online or at the counter?", "What documents are you showing at check-in?", "What are you packing in your carry-on bag?", "How are you preparing for your flight?"]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (
      lesson_id,
      activity_type,
      activity_order,
      title,
      description,
      content
    ) VALUES (
      'A2-L41',
      'speaking_improvement',
      10,
      'Speaking Improvement',
      'Read the improved version of your speech',
      '{"type": "speaking_improvement", "similarityThreshold": 70}'::jsonb
    );
END $$;

