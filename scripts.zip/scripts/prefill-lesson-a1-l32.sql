-- =========================================
-- Pre-fill Database with Sample Lesson Data
-- A1-L32: Home & Rooms
-- =========================================

DELETE FROM grammar_sentences WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'A1-L32');
DELETE FROM vocabulary_items WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'A1-L32');
DELETE FROM lesson_activities WHERE lesson_id = 'A1-L32';
DELETE FROM lessons WHERE id = 'A1-L32';

INSERT INTO lessons (id, level, lesson_number, topic) VALUES
('A1-L32', 'A1', 32, 'Home & Rooms')
ON CONFLICT (id) DO UPDATE SET topic = EXCLUDED.topic;

DO $$
DECLARE
    lesson_id_var TEXT := 'A1-L32';
    activity_id_var UUID;
BEGIN
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'warm_up_speaking', 1, 'Rooms', 'Talk about rooms in a home', '{"prompt": "How many rooms are in your home?"}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_intro', 2, 'Room Words', 'Learn room words', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'living room', 'ห้องนั่งเล่น', NULL),
    (activity_id_var, 'kitchen', 'ห้องครัว', NULL),
    (activity_id_var, 'bathroom', 'ห้องน้ำ', NULL),
    (activity_id_var, 'bedroom', 'ห้องนอน', NULL),
    (activity_id_var, 'door', 'ประตู', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_matching_drag', 3, 'Match Room Words', 'Match room words', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'living room', 'ห้องนั่งเล่น', NULL),
    (activity_id_var, 'kitchen', 'ห้องครัว', NULL),
    (activity_id_var, 'bathroom', 'ห้องน้ำ', NULL),
    (activity_id_var, 'bedroom', 'ห้องนอน', NULL),
    (activity_id_var, 'door', 'ประตู', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 4, 'Complete the Sentences 1', 'Fill with the correct word', '{"text": "There is a ___. There is a ___.", "blanks": [{"id": "blank1", "text": "kitchen", "options": ["kitchen", "living room", "bathroom", "door"], "correctAnswer": "kitchen"}, {"id": "blank2", "text": "living room", "options": ["living room", "bedroom", "bathroom", "door"], "correctAnswer": "living room"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 5, 'Complete the Sentences 2', 'Fill with the correct word', '{"text": "There is a ___. The __ is open.", "blanks": [{"id": "blank1", "text": "bathroom", "options": ["bathroom", "bedroom", "kitchen", "living room"], "correctAnswer": "bathroom"}, {"id": "blank2", "text": "door", "options": ["door", "bedroom", "kitchen", "bathroom"], "correctAnswer": "door"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_explanation', 6, 'There is / There are', 'Talk about rooms in a house', '{"rules": "Use there is for one; there are for many.\n- There is a kitchen.\n- There are two bedrooms.\nAsk: Is there a bathroom?", "examples": ["There is a kitchen.", "There is a living room.", "There are two bedrooms.", "Is there a bathroom?", "Are there many rooms?"]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 7, 'Build Sentences 1', 'Arrange words', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'There is a kitchen', 'There is a kitchen.', '["There", "is", "a", "kitchen."]'::jsonb),
    (activity_id_var, 'There are two bedrooms', 'There are two bedrooms.', '["There", "are", "two", "bedrooms."]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 8, 'Build Sentences 2', 'Arrange words', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'Is there a bathroom', 'Is there a bathroom?', '["Is", "there", "a", "bathroom?"]'::jsonb),
    (activity_id_var, 'Are there many rooms', 'Are there many rooms?', '["Are", "there", "many", "rooms?"]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'speaking_practice', 9, 'Talk About Your Home', 'Practice there is/are for rooms', '{"prompts": ["How many rooms are in your home?", "Is there a kitchen?", "Is there a bathroom?", "Is the door open?", "Is there a living room?"]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (
      lesson_id,
      activity_type,
      activity_order,
      title,
      description,
      content
    ) VALUES (
      'A1-L32',
      'speaking_improvement',
      10,
      'Speaking Improvement',
      'Read the improved version of your speech',
      '{"type": "speaking_improvement", "similarityThreshold": 70}'::jsonb
    );
END $$;

