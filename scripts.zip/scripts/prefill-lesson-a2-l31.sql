-- =========================================
-- Pre-fill Database with Sample Lesson Data
-- A2-L31: Missing a Bus or Train
-- =========================================

DELETE FROM grammar_sentences WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'A2-L31');
DELETE FROM vocabulary_items WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'A2-L31');
DELETE FROM lesson_activities WHERE lesson_id = 'A2-L31';
DELETE FROM lessons WHERE id = 'A2-L31';

INSERT INTO lessons (id, level, lesson_number, topic) VALUES
('A2-L31', 'A2', 31, 'Missing a Bus or Train')
ON CONFLICT (id) DO UPDATE SET topic = EXCLUDED.topic;

DO $$
DECLARE
    lesson_id_var TEXT := 'A2-L31';
    activity_id_var UUID;
BEGIN
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'warm_up_speaking', 1, 'Missed Transport', 'Talk about missing a ride', '{"prompt": "Have you ever missed a bus or train?"}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_intro', 2, 'Missed Ride Words', 'Learn words about missing transport', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'missed', 'พลาด', NULL),
    (activity_id_var, 'waited', 'รอ', NULL),
    (activity_id_var, 'ran', 'วิ่ง', NULL),
    (activity_id_var, 'caught', 'ขึ้นทัน', NULL),
    (activity_id_var, 'change', 'เปลี่ยน', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_matching_drag', 3, 'Match Missed Ride Words', 'Match transport delay words', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'missed', 'พลาด', NULL),
    (activity_id_var, 'waited', 'รอ', NULL),
    (activity_id_var, 'ran', 'วิ่ง', NULL),
    (activity_id_var, 'caught', 'ขึ้นทัน', NULL),
    (activity_id_var, 'change', 'เปลี่ยน', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 4, 'Complete the Sentences 1', 'Fill with the correct word', '{"text": "I ___ the bus. I ___ for 20 minutes. I ___ to catch it.", "blanks": [{"id": "blank1", "text": "missed", "options": ["missed", "waited", "ran", "caught"], "correctAnswer": "missed"}, {"id": "blank2", "text": "waited", "options": ["waited", "ran", "missed", "caught"], "correctAnswer": "waited"}, {"id": "blank3", "text": "ran", "options": ["ran", "caught", "waited", "missed"], "correctAnswer": "ran"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 5, 'Complete the Sentences 2', 'Fill with the correct word', '{"text": "I finally ___ the train. I need to ___ my plan.", "blanks": [{"id": "blank1", "text": "caught", "options": ["caught", "missed", "ran", "waited"], "correctAnswer": "caught"}, {"id": "blank2", "text": "change", "options": ["change", "caught", "waited", "missed"], "correctAnswer": "change"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_explanation', 6, 'Past Simple (regular/irregular)', 'Talk about a missed trip', '{"rules": "Use past simple for finished actions.\nRegular: verb + ed (wait → waited).\nIrregular: ran, caught, went, missed.\nQuestions: Did + subject + verb? Negatives: didn''t + verb.", "examples": ["I missed the bus.", "I waited for 20 minutes.", "I ran but I didn''t catch it.", "Did you wait long?", "We caught the next train."]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 7, 'Build Sentences 1', 'Arrange words', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'I missed the bus', 'I missed the bus.', '["I", "missed", "the", "bus."]'::jsonb),
    (activity_id_var, 'I waited for twenty minutes', 'I waited for twenty minutes.', '["I", "waited", "for", "twenty", "minutes."]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 8, 'Build Sentences 2', 'Arrange words', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'Did you catch the train', 'Did you catch the train?', '["Did", "you", "catch", "the", "train?"]'::jsonb),
    (activity_id_var, 'We didn t catch it so we changed plans', 'We didn''t catch it, so we changed plans.', '["We", "didn''t", "catch", "it,", "so", "we", "changed", "plans."]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'speaking_practice', 9, 'Talk About Missing Transport', 'Practice past trip stories', '{"prompts": ["Have you ever missed a bus or train?", "Who helped you when that happened?", "How did you feel at the time?", "What did you do after you missed it?", "How did you solve the problem?"]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (
      lesson_id,
      activity_type,
      activity_order,
      title,
      description,
      content
    ) VALUES (
      'A2-L31',
      'speaking_improvement',
      10,
      'Speaking Improvement',
      'Read the improved version of your speech',
      '{"type": "speaking_improvement", "similarityThreshold": 70}'::jsonb
    );
END $$;

