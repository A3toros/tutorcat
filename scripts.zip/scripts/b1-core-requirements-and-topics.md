# B1 Lessons — Core Requirements and Topics

## Common Content Rules (carry over from A1/A2)
- **Vocabulary fill blanks:** only one correct option per blank; include 3 unrelated distractors; don’t use all options from the same vocab category.
- **Grammar sentences:** avoid swap-ambiguous patterns (no two bare nouns with “and” that can switch places); attach “?” to the last word in `words_array`; attach commas to the preceding word in `words_array`; no contractions in target sentences.
- **Speaking prompts:** student-appropriate, open-ended, lively; invite personal stories/experiences; no adult-only topics.
- **Speaking improvement activity:** include the standard `speaking_improvement` activity with similarityThreshold 70.

## Grammar Requirements (from `cefr-grammar-requirements.md` — B1)
- Present Perfect (experience, result)
- Past Continuous
- Future: will vs going to
- First Conditional
- Modal verbs: must / have to / should
- Gerunds & infinitives (like, want, enjoy)
- Verb + preposition
- Passive voice (present & past)
- Zero Conditional
- First Conditional
- Reported speech (statements, basic)
- Relative clauses: defining (who/which/that)
- Comparison: too/enough; so/such
- Articles: definite vs zero article

## B1 Level – 90 Additional Topics (by theme)
### Daily Life & Personal Growth
- Daily Life Changes
- Childhood Memories
- Living in a City vs. the Countryside
- Free Time and Work–Life Balance
- Friendship and Social Circles
- Learning New Skills
- Personal Strengths and Weaknesses
- Making Decisions
- Dealing with Stress
- Healthy Habits

### Technology & Digital Life
- Social Media Influence
- Online Communication
- Digital Privacy
- Advantages and Disadvantages of Technology
- Studying Online vs. Offline
- Using Apps in Daily Life
- News and Information Sources
- Trusting Information Online
- Technology Problems and Fixes
- Future Technology Predictions

### Travel & Culture
- Travel Planning
- Cultural Differences
- Customs and Traditions
- Food Cultures
- Traveling Alone vs. With Others
- Problems While Traveling
- Language Barriers
- Living Abroad
- Homesickness
- Travel Tips

### Work & Career
- Workplace Communication
- Teamwork
- Dealing with Problems at Work
- Work Responsibilities
- Job Interviews
- Career Changes
- Learning at Work
- Working Under Pressure
- Remote Work
- Work–Life Balance (applied)

### Money & Consumer Life
- Personal Finances
- Saving and Spending Money
- Shopping Habits
- Advertising and Consumers
- Comparing Products
- Online Shopping
- Budgeting
- Making Complaints
- Customer Service Experiences
- Financial Goals

### Health & Wellbeing
- Health Problems and Advice
- Visiting the Doctor
- Mental Health Awareness
- Fitness Routines
- Diet Choices
- Sleep and Energy
- Balancing Health and Work
- Bad Habits
- Health Myths
- Giving Health Advice

### Relationships & Community
- Relationships at Work
- Family Roles
- Conflict and Agreement
- Giving Opinions Politely
- Apologizing and Explaining
- Making Suggestions
- Accepting and Refusing Invitations
- Helping Others
- Social Responsibilities
- Community Life

### Environment & Civic Life
- Environmental Problems
- Recycling and Waste
- Climate Awareness
- Protecting Nature
- Daily Actions for the Environment
- Public Transport vs. Cars
- Energy Use at Home
- Environmental Solutions
- Volunteering
- Being a Responsible Citizen

