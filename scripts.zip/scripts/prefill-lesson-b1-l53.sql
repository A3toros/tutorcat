-- =========================================
-- Pre-fill Database with Sample Lesson Data
-- B1-L53: Diet Choices
-- =========================================

DELETE FROM grammar_sentences WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'B1-L53');
DELETE FROM vocabulary_items WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'B1-L53');
DELETE FROM lesson_activities WHERE lesson_id = 'B1-L53';
DELETE FROM lessons WHERE id = 'B1-L53';

INSERT INTO lessons (id, level, lesson_number, topic) VALUES
('B1-L53', 'B1', 53, 'Diet Choices')
ON CONFLICT (id) DO UPDATE SET topic = EXCLUDED.topic;

DO $$
DECLARE
    lesson_id_var TEXT := 'B1-L53';
    activity_id_var UUID;
BEGIN
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'warm_up_speaking', 1, 'Food Balance', 'Talk about eating habits and cravings', '{"prompt": "What food is so satisfying you crave it?"}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_intro', 2, 'Diet Words', 'Learn vocabulary about diet choices', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'balanced', 'สมดุล', NULL),
    (activity_id_var, 'portion', 'ส่วนอาหาร', NULL),
    (activity_id_var, 'craving', 'ความอยาก', NULL),
    (activity_id_var, 'nutrient', 'สารอาหาร', NULL),
    (activity_id_var, 'variety', 'ความหลากหลาย', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_matching_drag', 3, 'Match Diet Words', 'Match words with meanings', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'balanced', 'สมดุล', NULL),
    (activity_id_var, 'portion', 'ส่วนอาหาร', NULL),
    (activity_id_var, 'craving', 'ความอยาก', NULL),
    (activity_id_var, 'nutrient', 'สารอาหาร', NULL),
    (activity_id_var, 'variety', 'ความหลากหลาย', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 4, 'Complete the Sentences 1', 'Fill with the correct word', '{"text": "I want a ___ meal. I watch each ___. This ___ is strong today.", "blanks": [{"id": "blank1", "text": "balanced", "options": ["balanced", "portion", "craving", "variety"], "correctAnswer": "balanced"}, {"id": "blank2", "text": "portion", "options": ["portion", "balanced", "craving", "nutrient"], "correctAnswer": "portion"}, {"id": "blank3", "text": "craving", "options": ["craving", "nutrient", "portion", "variety"], "correctAnswer": "craving"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 5, 'Complete the Sentences 2', 'Fill with the correct word', '{"text": "I check each ___. I add ___. A wider ___ keeps me happy.", "blanks": [{"id": "blank1", "text": "nutrient", "options": ["nutrient", "balanced", "portion", "variety"], "correctAnswer": "nutrient"}, {"id": "blank2", "text": "protein", "options": ["protein", "nutrient", "portion", "craving"], "correctAnswer": "protein"}, {"id": "blank3", "text": "variety", "options": ["variety", "portion", "craving", "balanced"], "correctAnswer": "variety"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    -- Grammar Explanation: So / Such (diet emphasis)
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_explanation', 6, 'So / Such for Diet Choices', 'Use so + adjective; such a/an + adjective + noun to emphasize food', '{"rules": "Use so + adjective: so filling. Use such a/an + adjective + noun: such a satisfying meal. Keep natural.\\n- It was such a rich dessert.\\n- I was so full after lunch.", "examples": ["It was such a satisfying meal.", "That dessert was so sweet for me.", "We had such a balanced dinner.", "I was so full after that portion.", "She made such a colorful salad."]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 7, 'Build Sentences 1', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'It was such a satisfying meal', 'It was such a satisfying meal', '["It", "was", "such", "a", "satisfying", "meal"]'::jsonb),
    (activity_id_var, 'That dessert was so sweet for me', 'That dessert was so sweet for me', '["That", "dessert", "was", "so", "sweet", "for", "me"]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 8, 'Build Sentences 2', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'We had such a balanced dinner', 'We had such a balanced dinner', '["We", "had", "such", "a", "balanced", "dinner"]'::jsonb),
    (activity_id_var, 'I was so full after that portion', 'I was so full after that portion', '["I", "was", "so", "full", "after", "that", "portion"]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'speaking_practice', 9, 'Talk About Diet Choices', 'Practice talking about cravings and balance', '{"prompts": ["What food is so satisfying you crave it?", "What is such a hard craving to resist for you?", "How do you balance taste and health personally?"]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (
      lesson_id,
      activity_type,
      activity_order,
      title,
      description,
      content
    ) VALUES (
      'B1-L53',
      'speaking_improvement',
      10,
      'Speaking Improvement',
      'Read the improved version of your speech',
      '{"type": "speaking_improvement", "similarityThreshold": 70}'::jsonb
    );
END $$;

