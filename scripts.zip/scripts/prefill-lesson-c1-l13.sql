-- =========================================
-- Pre-fill Database with Sample Lesson Data
-- C1-L13: AI Use in Academic Work
-- =========================================

DELETE FROM grammar_sentences WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'C1-L13');
DELETE FROM vocabulary_items WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'C1-L13');
DELETE FROM lesson_activities WHERE lesson_id = 'C1-L13';
DELETE FROM lessons WHERE id = 'C1-L13';

INSERT INTO lessons (id, level, lesson_number, topic) VALUES
('C1-L13', 'C1', 13, 'AI Use in Academic Work')
ON CONFLICT (id) DO UPDATE SET topic = EXCLUDED.topic;

DO $$
DECLARE
    lesson_id_var TEXT := 'C1-L13';
    activity_id_var UUID;
BEGIN
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'warm_up_speaking', 1, 'AI in Academia', 'Discuss AI use in academic work', '{"prompt": "How has AI affected the way you study?"}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_intro', 2, 'AI Vocabulary', 'Learn vocabulary about AI in academia', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'automation', 'การทำงานอัตโนมัติ', NULL),
    (activity_id_var, 'algorithm', 'อัลกอริทึม', NULL),
    (activity_id_var, 'bias', 'อคติ', NULL),
    (activity_id_var, 'reliance', 'การพึ่งพา', NULL),
    (activity_id_var, 'enhancement', 'การปรับปรุง', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_matching_drag', 3, 'Match AI Words', 'Match English words with Thai meanings', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'automation', 'การทำงานอัตโนมัติ', NULL),
    (activity_id_var, 'algorithm', 'อัลกอริทึม', NULL),
    (activity_id_var, 'bias', 'อคติ', NULL),
    (activity_id_var, 'reliance', 'การพึ่งพา', NULL),
    (activity_id_var, 'enhancement', 'การปรับปรุง', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 4, 'Complete the Sentences 1', 'Fill with the correct word', '{"text": "Academic ___ may improve efficiency. However, ___ on AI raises concerns.", "blanks": [{"id": "blank1", "text": "automation", "options": ["automation", "algorithm", "bias", "reliance"], "correctAnswer": "automation"}, {"id": "blank2", "text": "reliance", "options": ["reliance", "automation", "algorithm", "bias"], "correctAnswer": "reliance"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 5, 'Complete the Sentences 2', 'Fill with the correct word', '{"text": "The ___ may contain hidden ___. AI ___ can improve learning outcomes.", "blanks": [{"id": "blank1", "text": "algorithm", "options": ["algorithm", "automation", "bias", "reliance"], "correctAnswer": "algorithm"}, {"id": "blank2", "text": "bias", "options": ["bias", "reliance", "automation", "enhancement"], "correctAnswer": "bias"}, {"id": "blank3", "text": "enhancement", "options": ["enhancement", "automation", "algorithm", "bias"], "correctAnswer": "enhancement"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_explanation', 6, 'Modals: Speculation and Criticism in the Past', 'Learn modals for past speculation and criticism', '{"rules": "Past speculation and criticism:\n- \"might/could have + past participle\" (possibility in past)\n- \"should have + past participle\" (criticism/regret)\n- \"must have + past participle\" (strong probability)\n- \"may have + past participle\" (uncertainty)\n\nUse for:\n- Speculating about past events: \"AI might have helped you\"\n- Criticizing past actions: \"You should have cited the source\"\n- Expressing regret: \"I could have used AI better\"", "examples": ["AI might have improved your research efficiency.", "Students should have been taught about AI ethics.", "The algorithm must have processed thousands of papers.", "You may have overlooked potential bias.", "They could have used AI more effectively."]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 7, 'Build Sentences 1', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'AI might have helped you complete the assignment faster.', 'AI might have helped you complete the assignment faster.', '["AI", "might", "have", "helped", "you", "complete", "the", "assignment", "faster."]'::jsonb),
    (activity_id_var, 'You should have disclosed your use of AI tools.', 'You should have disclosed your use of AI tools.', '["You", "should", "have", "disclosed", "your", "use", "of", "AI", "tools."]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 8, 'Build Sentences 2', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'The system must have processed millions of documents.', 'The system must have processed millions of documents.', '["The", "system", "must", "have", "processed", "millions", "of", "documents."]'::jsonb),
    (activity_id_var, 'They could have avoided bias by reviewing the algorithm.', 'They could have avoided bias by reviewing the algorithm.', '["They", "could", "have", "avoided", "bias", "by", "reviewing", "the", "algorithm."]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'speaking_practice', 9, 'Discuss AI in Academia', 'Practice speaking about AI use', '{"prompts": ["How might AI have helped your learning?", "How might it have caused problems?", "Should AI be allowed in assignments?", "What ethical concerns does AI raise?", "How can AI be used responsibly in education?"]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (
      lesson_id,
      activity_type,
      activity_order,
      title,
      description,
      content
    ) VALUES (
      'C1-L13',
      'speaking_improvement',
      10,
      'Speaking Improvement',
      'Read the improved version of your speech',
      '{"type": "speaking_improvement", "similarityThreshold": 70}'::jsonb
    );
END $$;
