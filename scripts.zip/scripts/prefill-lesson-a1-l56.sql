-- =========================================
-- Pre-fill Database with Sample Lesson Data
-- A1-L56: Parts of the Face
-- =========================================

DELETE FROM grammar_sentences WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'A1-L56');
DELETE FROM vocabulary_items WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'A1-L56');
DELETE FROM lesson_activities WHERE lesson_id = 'A1-L56';
DELETE FROM lessons WHERE id = 'A1-L56';

INSERT INTO lessons (id, level, lesson_number, topic) VALUES
('A1-L56', 'A1', 56, 'Parts of the Face')
ON CONFLICT (id) DO UPDATE SET topic = EXCLUDED.topic;

DO $$
DECLARE
    lesson_id_var TEXT := 'A1-L56';
    activity_id_var UUID;
BEGIN
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'warm_up_speaking', 1, 'Face Parts', 'Talk about your face', '{"prompt": "Do you have long hair?"}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_intro', 2, 'Face Words', 'Learn face words', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'eyes', 'ตา', NULL),
    (activity_id_var, 'nose', 'จมูก', NULL),
    (activity_id_var, 'mouth', 'ปาก', NULL),
    (activity_id_var, 'ears', 'หู', NULL),
    (activity_id_var, 'hair', 'ผม', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_matching_drag', 3, 'Match Face Words', 'Match face words', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'eyes', 'ตา', NULL),
    (activity_id_var, 'nose', 'จมูก', NULL),
    (activity_id_var, 'mouth', 'ปาก', NULL),
    (activity_id_var, 'ears', 'หู', NULL),
    (activity_id_var, 'hair', 'ผม', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 4, 'Complete the Sentences 1', 'Fill with the correct word', '{"text": "I have two ___. I have two ___.", "blanks": [{"id": "blank1", "text": "eyes", "options": ["eyes", "ears", "hair", "nose"], "correctAnswer": "eyes"}, {"id": "blank2", "text": "ears", "options": ["ears", "mouth", "hair", "nose"], "correctAnswer": "ears"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 5, 'Complete the Sentences 2', 'Fill with the correct word', '{"text": "This is my ___. This is my ___.", "blanks": [{"id": "blank1", "text": "nose", "options": ["nose", "mouth", "hair", "eyes"], "correctAnswer": "nose"}, {"id": "blank2", "text": "mouth", "options": ["mouth", "nose", "hair", "ears"], "correctAnswer": "mouth"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_explanation', 6, 'Have / Has Got', 'Talk about face parts', '{"rules": "Use have/has got to show possession.\n- I have two eyes.\n- She has long hair.\nAsk: Do you have long hair?", "examples": ["I have two eyes.", "I have a small nose.", "She has long hair.", "Do you have big ears?", "Do you have a big mouth?"]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 7, 'Build Sentences 1', 'Arrange words', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'I have two eyes', 'I have two eyes.', '["I", "have", "two", "eyes."]'::jsonb),
    (activity_id_var, 'She has long hair', 'She has long hair.', '["She", "has", "long", "hair."]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 8, 'Build Sentences 2', 'Arrange words', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'Do you have big ears', 'Do you have big ears?', '["Do", "you", "have", "big", "ears?"]'::jsonb),
    (activity_id_var, 'Do you have a big mouth', 'Do you have a big mouth?', '["Do", "you", "have", "a", "big", "mouth?"]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'speaking_practice', 9, 'Talk About Your Face', 'Practice have/has got', '{"prompts": ["Do you have long hair?", "Do you have big eyes?", "Do you have a small nose?", "Do you have big ears?", "Do you have a big mouth?"]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (
      lesson_id,
      activity_type,
      activity_order,
      title,
      description,
      content
    ) VALUES (
      'A1-L56',
      'speaking_improvement',
      10,
      'Speaking Improvement',
      'Read the improved version of your speech',
      '{"type": "speaking_improvement", "similarityThreshold": 70}'::jsonb
    );
END $$;

