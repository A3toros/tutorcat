-- =========================================
-- Pre-fill Database with Sample Lesson Data
-- B1-L8: Technology & Internet Use
-- =========================================

-- Clear existing sample data for B1-L8 (optional - comment out if you want to keep existing data)
DELETE FROM grammar_sentences WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'B1-L8');
DELETE FROM vocabulary_items WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'B1-L8');
DELETE FROM lesson_activities WHERE lesson_id = 'B1-L8';
DELETE FROM lessons WHERE id = 'B1-L8';

INSERT INTO lessons (id, level, lesson_number, topic) VALUES
('B1-L8', 'B1', 8, 'Technology & Internet Use')
ON CONFLICT (id) DO UPDATE SET topic = EXCLUDED.topic;

DO $$
DECLARE
    lesson_id_var TEXT := 'B1-L8';
    activity_id_var UUID;
BEGIN
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content) VALUES (lesson_id_var, 'warm_up_speaking', 1, 'Technology Impact', 'Talk about technology', '{"prompt": "How has technology changed your life?"}'::jsonb) RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content) VALUES (lesson_id_var, 'vocabulary_intro', 2, 'Technology Words', 'Learn technology vocabulary', '{}'::jsonb) RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'device', 'อุปกรณ์', NULL),
    (activity_id_var, 'software', 'ซอฟต์แวร์', NULL),
    (activity_id_var, 'network', 'เครือข่าย', NULL),
    (activity_id_var, 'security', 'ความปลอดภัย', NULL),
    (activity_id_var, 'innovation', 'นวัตกรรม', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content) VALUES (lesson_id_var, 'vocabulary_matching_drag', 3, 'Match Technology Words', 'Match English words with Thai meanings', '{}'::jsonb) RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'device', 'อุปกรณ์', NULL),
    (activity_id_var, 'software', 'ซอฟต์แวร์', NULL),
    (activity_id_var, 'network', 'เครือข่าย', NULL),
    (activity_id_var, 'security', 'ความปลอดภัย', NULL),
    (activity_id_var, 'innovation', 'นวัตกรรม', NULL);

    -- 4. Vocabulary Fill Blanks #1 (4 words: device, software, network, security - innovation left out)
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content) VALUES (lesson_id_var, 'vocabulary_fill_blanks', 4, 'Complete the Sentences 1', 'Fill in the blanks with correct words', '{"text": "I use this ___. I installed new ___. I connected to the ___. I care about ___.", "blanks": [{"id": "blank1", "text": "device", "options": ["device", "software", "network", "security"], "correctAnswer": "device"}, {"id": "blank2", "text": "software", "options": ["device", "software", "network", "security"], "correctAnswer": "software"}, {"id": "blank3", "text": "network", "options": ["device", "software", "network", "security"], "correctAnswer": "network"}, {"id": "blank4", "text": "security", "options": ["device", "software", "network", "security"], "correctAnswer": "security"}]}'::jsonb) RETURNING id INTO activity_id_var;

    -- 4. Vocabulary Fill Blanks #2 (4 words: device, software, network, innovation - security left out)
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content) VALUES (lesson_id_var, 'vocabulary_fill_blanks', 5, 'Complete the Sentences 2', 'Fill in the blanks with correct words', '{"text": "My ___ is new. The ___ works well. The ___ is fast. This is an ___.", "blanks": [{"id": "blank1", "text": "device", "options": ["device", "software", "network", "innovation"], "correctAnswer": "device"}, {"id": "blank2", "text": "software", "options": ["device", "software", "network", "innovation"], "correctAnswer": "software"}, {"id": "blank3", "text": "network", "options": ["device", "software", "network", "innovation"], "correctAnswer": "network"}, {"id": "blank4", "text": "innovation", "options": ["device", "software", "network", "innovation"], "correctAnswer": "innovation"}]}'::jsonb) RETURNING id INTO activity_id_var;

    -- 4. Grammar Explanation (5 examples - CEFR B1: Present perfect continuous, opinions)
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content) VALUES (lesson_id_var, 'grammar_explanation', 6, 'Present Perfect Continuous - Technology', 'Learn to talk about ongoing technology use', '{"rules": "Use present perfect continuous for ongoing actions:\n\n- I have been using + noun (I have been using this app)\n- I have been working on + noun (I have been working on this project)\n- Express opinions: I think/believe/feel that...\n- Use ''for'' and ''since'' with continuous forms\n- Use ''how long'' questions (How long have you been...?)", "examples": ["I have been using this device for two years.", "I have been working on this project since January.", "I think technology makes life easier.", "I have been learning programming for six months.", "How long have you been using this software?"]}'::jsonb) RETURNING id INTO activity_id_var;

    -- 4. Grammar Sentences #1
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content) VALUES (lesson_id_var, 'grammar_sentences', 7, 'Build Sentences 1', 'Arrange words to make sentences', '{}'::jsonb) RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'I have been using this device for two years', 'I have been using this device for two years', '["I", "have", "been", "using", "this", "device", "for", "two", "years"]'::jsonb),
    (activity_id_var, 'I think technology makes life easier', 'I think technology makes life easier', '["I", "think", "technology", "makes", "life", "easier"]'::jsonb);
    -- 4. Grammar Sentences #2
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content) VALUES (lesson_id_var, 'grammar_sentences', 8, 'Build Sentences 2', 'Arrange words to make sentences', '{}'::jsonb) RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'I have been learning programming for six months', 'I have been learning programming for six months', '["I", "have", "been", "learning", "programming", "for", "six", "months"]'::jsonb),
    (activity_id_var, 'How long have you been using this software', 'How long have you been using this software?', '["How", "long", "have", "you", "been", "using", "this", "software"]'::jsonb);
    -- 4. Speaking Practice (5 prompts - CEFR B1: Technology and internet)
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content) VALUES (lesson_id_var, 'speaking_practice', 9, 'Talk About Technology', 'Practice talking about tech use', '{"prompts": ["How has technology changed your life?", "What devices do you use every day?", "How long have you been using the internet?", "What do you think about social media?", "How do you protect your online security?"]}'::jsonb) RETURNING id INTO activity_id_var;

END $$;
INSERT INTO lesson_activities (
  lesson_id,
  activity_type,
  activity_order,
  title,
  description,
  content
) VALUES (
  'B1-L8',
  'speaking_improvement',
  10,
  'Speaking Improvement',
  'Read the improved version of your speech',
  '{"type": "speaking_improvement", "similarityThreshold": 70}'::jsonb
);