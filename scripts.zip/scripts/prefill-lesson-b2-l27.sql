-- =========================================
-- Pre-fill Database with Sample Lesson Data
-- B2-L27: News consumption habits
-- =========================================

DELETE FROM grammar_sentences WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'B2-L27');
DELETE FROM vocabulary_items WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'B2-L27');
DELETE FROM lesson_activities WHERE lesson_id = 'B2-L27';
DELETE FROM lessons WHERE id = 'B2-L27';

INSERT INTO lessons (id, level, lesson_number, topic) VALUES
('B2-L27', 'B2', 27, 'News consumption habits')
ON CONFLICT (id) DO UPDATE SET topic = EXCLUDED.topic;

DO $$
DECLARE
    lesson_id_var TEXT := 'B2-L27';
    activity_id_var UUID;
BEGIN
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'warm_up_speaking', 1, 'News Routine', 'Talk about how you get news', '{"prompt": "What were you told to check before sharing, and who sets your news routine?"}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_intro', 2, 'News Habit Words', 'Key words for news routines', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'skim', 'อ่านผ่านเร็ว ๆ', NULL),
    (activity_id_var, 'alert', 'การแจ้งเตือน', NULL),
    (activity_id_var, 'mute', 'ปิดเสียง/ปิดแจ้งเตือน', NULL),
    (activity_id_var, 'digest', 'ย่อยข่าว/ทำความเข้าใจ', NULL),
    (activity_id_var, 'review', 'ทบทวน/ตรวจทาน', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_matching_drag', 3, 'Match News Habit Words', 'Match words with meanings', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'skim', 'อ่านผ่านเร็ว ๆ', NULL),
    (activity_id_var, 'alert', 'การแจ้งเตือน', NULL),
    (activity_id_var, 'mute', 'ปิดเสียง/ปิดแจ้งเตือน', NULL),
    (activity_id_var, 'digest', 'ย่อยข่าว/ทำความเข้าใจ', NULL),
    (activity_id_var, 'review', 'ทบทวน/ตรวจทาน', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 4, 'Complete the Sentences 1', 'Fill with the correct word', '{"text": "I ___ headlines first. I set one trusted ___. Some apps I ___.", "blanks": [{"id": "blank1", "text": "skim", "options": ["skim", "alert", "mute", "digest"], "correctAnswer": "skim"}, {"id": "blank2", "text": "alert", "options": ["alert", "digest", "review", "mute"], "correctAnswer": "alert"}, {"id": "blank3", "text": "mute", "options": ["mute", "review", "skim", "alert"], "correctAnswer": "mute"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 5, 'Complete the Sentences 2', 'Fill with the correct word', '{"text": "I take time to ___ one long story. Nightly I ___ my sources.", "blanks": [{"id": "blank1", "text": "digest", "options": ["digest", "skim", "mute", "alert"], "correctAnswer": "digest"}, {"id": "blank2", "text": "review", "options": ["review", "digest", "skim", "alert"], "correctAnswer": "review"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_explanation', 6, 'Reported Speech (commands)', 'Report advice about news habits', '{"rules": "Use tell/ask + object + to-infinitive for commands; use not to for negatives. Backshift if needed.\\n- \"Check the source\" → They told us to check the source.\\n- \"Don’t share unverified news\" → She told me not to share unverified news.", "examples": ["They told us to review headlines before sharing.", "My mentor told me not to rely on one platform.", "The club asked us to mute distracting alerts.", "She told me to digest one long story daily.", "He asked me not to skip source checks."]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 7, 'Build Sentences 1', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'They told us to review headlines before sharing', 'They told us to review headlines before sharing.', '["They", "told", "us", "to", "review", "headlines", "before", "sharing."]'::jsonb),
    (activity_id_var, 'My mentor told me not to rely on one platform', 'My mentor told me not to rely on one platform.', '["My", "mentor", "told", "me", "not", "to", "rely", "on", "one", "platform."]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 8, 'Build Sentences 2', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'The club asked us to mute distracting alerts', 'The club asked us to mute distracting alerts.', '["The", "club", "asked", "us", "to", "mute", "distracting", "alerts."]'::jsonb),
    (activity_id_var, 'She told me to digest one long story daily', 'She told me to digest one long story daily.', '["She", "told", "me", "to", "digest", "one", "long", "story", "daily."]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'speaking_practice', 9, 'Talk About News Habits', 'Practice reported commands', '{"prompts": ["What were you told to check before sharing?", "Who sets your news routine?", "What advice about alerts do you repeat?"]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (
      lesson_id,
      activity_type,
      activity_order,
      title,
      description,
      content
    ) VALUES (
      'B2-L27',
      'speaking_improvement',
      10,
      'Speaking Improvement',
      'Read the improved version of your speech',
      '{"type": "speaking_improvement", "similarityThreshold": 70}'::jsonb
    );
END $$;


