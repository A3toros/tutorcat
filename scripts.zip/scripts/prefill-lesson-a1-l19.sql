-- =========================================
-- Pre-fill Database with Sample Lesson Data
-- A1-L19: Saying Hello and Goodbye
-- =========================================

DELETE FROM grammar_sentences WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'A1-L19');
DELETE FROM vocabulary_items WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'A1-L19');
DELETE FROM lesson_activities WHERE lesson_id = 'A1-L19';
DELETE FROM lessons WHERE id = 'A1-L19';

INSERT INTO lessons (id, level, lesson_number, topic) VALUES
('A1-L19', 'A1', 19, 'Saying Hello and Goodbye')
ON CONFLICT (id) DO UPDATE SET topic = EXCLUDED.topic;

DO $$
DECLARE
    lesson_id_var TEXT := 'A1-L19';
    activity_id_var UUID;
BEGIN
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'warm_up_speaking', 1, 'Greetings', 'Talk about greeting words', '{"prompt": "How do you say hello?"}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_intro', 2, 'Greeting Words', 'Learn greeting words', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'hello', 'สวัสดี', NULL),
    (activity_id_var, 'goodbye', 'ลาก่อน', NULL),
    (activity_id_var, 'morning', 'เช้า', NULL),
    (activity_id_var, 'afternoon', 'บ่าย', NULL),
    (activity_id_var, 'night', 'กลางคืน', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_matching_drag', 3, 'Match Greeting Words', 'Match greeting words', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'hello', 'สวัสดี', NULL),
    (activity_id_var, 'goodbye', 'ลาก่อน', NULL),
    (activity_id_var, 'morning', 'เช้า', NULL),
    (activity_id_var, 'afternoon', 'บ่าย', NULL),
    (activity_id_var, 'night', 'กลางคืน', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 4, 'Complete the Sentences 1', 'Fill with the correct word', '{"text": "I say ___. I say ___ at night.", "blanks": [{"id": "blank1", "text": "hello", "options": ["hello", "goodbye", "morning", "afternoon"], "correctAnswer": "hello"}, {"id": "blank2", "text": "goodbye", "options": ["goodbye", "hello", "night", "morning"], "correctAnswer": "goodbye"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 5, 'Complete the Sentences 2', 'Fill with the correct word', '{"text": "Good ___, teacher. Good ___, class.", "blanks": [{"id": "blank1", "text": "morning", "options": ["morning", "afternoon", "night", "hello"], "correctAnswer": "morning"}, {"id": "blank2", "text": "afternoon", "options": ["afternoon", "morning", "night", "goodbye"], "correctAnswer": "afternoon"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_explanation', 6, 'Be + Greetings', 'Use be with time of day greetings', '{"rules": "Use greetings with be.\n- It is morning. Good morning.\n- It is night. Good night.\nAsk: Are you free now?", "examples": ["Good morning.", "Good afternoon.", "Good night.", "Are you free now?", "Hello, how are you?"]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 7, 'Build Sentences 1', 'Arrange words', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'Good morning class', 'Good morning, class.', '["Good", "morning,", "class."]'::jsonb),
    (activity_id_var, 'Good night teacher', 'Good night, teacher.', '["Good", "night,", "teacher."]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 8, 'Build Sentences 2', 'Arrange words', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'Hello how are you', 'Hello, how are you?', '["Hello,", "how", "are", "you?"]'::jsonb),
    (activity_id_var, 'Are you free now', 'Are you free now?', '["Are", "you", "free", "now?"]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'speaking_practice', 9, 'Practice Greetings', 'Say hello and goodbye', '{"prompts": ["How do you say hello?", "Do you wave goodbye?", "Do you say good morning?", "Do you say good night?", "Are you free now?"]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (
      lesson_id,
      activity_type,
      activity_order,
      title,
      description,
      content
    ) VALUES (
      'A1-L19',
      'speaking_improvement',
      10,
      'Speaking Improvement',
      'Read the improved version of your speech',
      '{"type": "speaking_improvement", "similarityThreshold": 70}'::jsonb
    );
END $$;

