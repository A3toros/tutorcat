-- =========================================
-- Pre-fill Database with Sample Lesson Data
-- B1-L89: Future Tech Ethics
-- =========================================

DELETE FROM grammar_sentences WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'B1-L89');
DELETE FROM vocabulary_items WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'B1-L89');
DELETE FROM lesson_activities WHERE lesson_id = 'B1-L89';
DELETE FROM lessons WHERE id = 'B1-L89';

INSERT INTO lessons (id, level, lesson_number, topic) VALUES
('B1-L89', 'B1', 89, 'Future Tech Ethics')
ON CONFLICT (id) DO UPDATE SET topic = EXCLUDED.topic;

DO $$
DECLARE
    lesson_id_var TEXT := 'B1-L89';
    activity_id_var UUID;
BEGIN
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'warm_up_speaking', 1, 'Ethics in Tech', 'Talk about future rules for technology', '{"prompt": "What tech do you think will need strict rules?"}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_intro', 2, 'Ethics Words', 'Learn vocabulary about future tech ethics', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'ethics', 'จริยธรรม', NULL),
    (activity_id_var, 'bias', 'อคติ', NULL),
    (activity_id_var, 'regulate', 'ออกกฎควบคุม', NULL),
    (activity_id_var, 'predict', 'ทำนาย', NULL),
    (activity_id_var, 'impact', 'ผลกระทบ', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_matching_drag', 3, 'Match Ethics Words', 'Match words with meanings', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'ethics', 'จริยธรรม', NULL),
    (activity_id_var, 'bias', 'อคติ', NULL),
    (activity_id_var, 'regulate', 'ออกกฎควบคุม', NULL),
    (activity_id_var, 'predict', 'ทำนาย', NULL),
    (activity_id_var, 'impact', 'ผลกระทบ', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 4, 'Complete the Sentences 1', 'Fill with the correct word', '{"text": "We debate ___. Systems can have ___. Governments may ___ tools. We try to ___ outcomes.", "blanks": [{"id": "blank1", "text": "ethics", "options": ["ethics", "bias", "regulate", "predict"], "correctAnswer": "ethics"}, {"id": "blank2", "text": "bias", "options": ["bias", "impact", "regulate", "predict"], "correctAnswer": "bias"}, {"id": "blank3", "text": "regulate", "options": ["regulate", "predict", "impact", "ethics"], "correctAnswer": "regulate"}, {"id": "blank4", "text": "predict", "options": ["predict", "regulate", "ethics", "impact"], "correctAnswer": "predict"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 5, 'Complete the Sentences 2', 'Fill with the correct word', '{"text": "We measure ___. Clear rules can ___ harm. Teams must study ___ early.", "blanks": [{"id": "blank1", "text": "impact", "options": ["impact", "bias", "ethics", "predict"], "correctAnswer": "impact"}, {"id": "blank2", "text": "reduce", "options": ["reduce", "regulate", "predict", "impact"], "correctAnswer": "reduce"}, {"id": "blank3", "text": "ethics", "options": ["ethics", "impact", "regulate", "bias"], "correctAnswer": "ethics"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    -- Grammar Explanation: Future (will vs going to) light
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_explanation', 6, 'Future: Will vs Going To for Tech Ethics', 'Use will for predictions; going to for planned actions', '{"rules": "Use will for predictions and uncertain outcomes. Use going to for intended plans.\\n- Governments will regulate AI.\\n- We are going to study bias more.\\nAvoid contractions.", "examples": ["Governments will regulate AI tools soon.", "We are going to study bias in our model.", "Companies will set strict rules for data.", "Teams are going to predict impacts before launch.", "Users will expect clear ethics policies."]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 7, 'Build Sentences 1', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'Governments will regulate AI tools soon', 'Governments will regulate AI tools soon', '["Governments", "will", "regulate", "AI", "tools", "soon"]'::jsonb),
    (activity_id_var, 'We are going to study bias in our model', 'We are going to study bias in our model', '["We", "are", "going", "to", "study", "bias", "in", "our", "model"]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 8, 'Build Sentences 2', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'Companies will set strict rules for data', 'Companies will set strict rules for data', '["Companies", "will", "set", "strict", "rules", "for", "data"]'::jsonb),
    (activity_id_var, 'Teams are going to predict impacts before launch', 'Teams are going to predict impacts before launch', '["Teams", "are", "going", "to", "predict", "impacts", "before", "launch"]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'speaking_practice', 9, 'Talk About Future Tech Ethics', 'Practice talking about tech rules and impact', '{"prompts": ["What tech do you think will need strict rules?", "How are you going to handle AI tools in your life?", "What impact worries you most?"]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (
      lesson_id,
      activity_type,
      activity_order,
      title,
      description,
      content
    ) VALUES (
      'B1-L89',
      'speaking_improvement',
      10,
      'Speaking Improvement',
      'Read the improved version of your speech',
      '{"type": "speaking_improvement", "similarityThreshold": 70}'::jsonb
    );
END $$;

