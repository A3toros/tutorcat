-- =========================================
-- Pre-fill Database with Sample Lesson Data
-- B2-L62: City life vs small towns (deep)
-- =========================================

DELETE FROM grammar_sentences WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'B2-L62');
DELETE FROM vocabulary_items WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'B2-L62');
DELETE FROM lesson_activities WHERE lesson_id = 'B2-L62';
DELETE FROM lessons WHERE id = 'B2-L62';

INSERT INTO lessons (id, level, lesson_number, topic) VALUES
('B2-L62', 'B2', 62, 'City life vs small towns (deep)')
ON CONFLICT (id) DO UPDATE SET topic = EXCLUDED.topic;

DO $$
DECLARE
    lesson_id_var TEXT := 'B2-L62';
    activity_id_var UUID;
BEGIN
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'warm_up_speaking', 1, 'City or Town', 'Talk about surprises', '{"prompt": "What had you underestimated about each, and what changed your mind?"}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_intro', 2, 'Place Words', 'Key words for city vs town', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'pace', 'จังหวะ/ความเร็ว', NULL),
    (activity_id_var, 'commute', 'การเดินทางไปกลับ', NULL),
    (activity_id_var, 'tight-knit', 'สนิทสนม/ใกล้ชิด', NULL),
    (activity_id_var, 'amenities', 'สิ่งอำนวยความสะดวก', NULL),
    (activity_id_var, 'quiet', 'เงียบสงบ', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_matching_drag', 3, 'Match Place Words', 'Match words with meanings', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'pace', 'จังหวะ/ความเร็ว', NULL),
    (activity_id_var, 'commute', 'การเดินทางไปกลับ', NULL),
    (activity_id_var, 'tight-knit', 'สนิทสนม/ใกล้ชิด', NULL),
    (activity_id_var, 'amenities', 'สิ่งอำนวยความสะดวก', NULL),
    (activity_id_var, 'quiet', 'เงียบสงบ', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 4, 'Complete the Sentences 1', 'Fill with the correct word', '{"text": "The city ___ surprised me. The town felt ___. The ___ was long.", "blanks": [{"id": "blank1", "text": "pace", "options": ["pace", "tight-knit", "commute", "amenities"], "correctAnswer": "pace"}, {"id": "blank2", "text": "tight-knit", "options": ["tight-knit", "quiet", "pace", "amenities"], "correctAnswer": "tight-knit"}, {"id": "blank3", "text": "commute", "options": ["commute", "amenities", "pace", "quiet"], "correctAnswer": "commute"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 5, 'Complete the Sentences 2', 'Fill with the correct word', '{"text": "City ___ were great. I loved the ___.", "blanks": [{"id": "blank1", "text": "amenities", "options": ["amenities", "commute", "tight-knit", "pace"], "correctAnswer": "amenities"}, {"id": "blank2", "text": "quiet", "options": ["quiet", "amenities", "pace", "tight-knit"], "correctAnswer": "quiet"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_explanation', 6, 'Past Perfect', 'Contrast expectations vs reality', '{"rules": "Use had + past participle for an action/state before another past point.\\n- I had underestimated the pace before moving.\\n- They had expected more amenities before arriving.", "examples": ["I had underestimated the commute before I took the job.", "We had expected a quieter town before we visited.", "She had assumed city life was too fast before trying it.", "They had thought small towns lacked amenities before living there.", "He had planned for long commutes before finding a closer place."]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 7, 'Build Sentences 1', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'I had underestimated the commute before I took the job', 'I had underestimated the commute before I took the job.', '["I", "had", "underestimated", "the", "commute", "before", "I", "took", "the", "job."]'::jsonb),
    (activity_id_var, 'We had expected a quieter town before we visited', 'We had expected a quieter town before we visited.', '["We", "had", "expected", "a", "quieter", "town", "before", "we", "visited."]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 8, 'Build Sentences 2', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'She had assumed city life was too fast before trying it', 'She had assumed city life was too fast before trying it.', '["She", "had", "assumed", "city", "life", "was", "too", "fast", "before", "trying", "it."]'::jsonb),
    (activity_id_var, 'They had thought small towns lacked amenities before living there', 'They had thought small towns lacked amenities before living there.', '["They", "had", "thought", "small", "towns", "lacked", "amenities", "before", "living", "there."]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'speaking_practice', 9, 'Talk About City vs Town', 'Practice past perfect', '{"prompts": ["What had you underestimated about city life?", "What changed your mind about small towns?", "Who helped you adjust to the pace?"]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (
      lesson_id,
      activity_type,
      activity_order,
      title,
      description,
      content
    ) VALUES (
      'B2-L62',
      'speaking_improvement',
      10,
      'Speaking Improvement',
      'Read the improved version of your speech',
      '{"type": "speaking_improvement", "similarityThreshold": 70}'::jsonb
    );
END $$;


