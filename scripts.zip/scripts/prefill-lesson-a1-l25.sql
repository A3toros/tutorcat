-- =========================================
-- Pre-fill Database with Sample Lesson Data
-- A1-L25: Places in Town
-- =========================================

DELETE FROM grammar_sentences WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'A1-L25');
DELETE FROM vocabulary_items WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'A1-L25');
DELETE FROM lesson_activities WHERE lesson_id = 'A1-L25';
DELETE FROM lessons WHERE id = 'A1-L25';

INSERT INTO lessons (id, level, lesson_number, topic) VALUES
('A1-L25', 'A1', 25, 'Places in Town')
ON CONFLICT (id) DO UPDATE SET topic = EXCLUDED.topic;

DO $$
DECLARE
    lesson_id_var TEXT := 'A1-L25';
    activity_id_var UUID;
BEGIN
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'warm_up_speaking', 1, 'Town Places', 'Talk about places in town', '{"prompt": "Is there a park?"}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_intro', 2, 'Place Words', 'Learn place words', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'park', 'สวนสาธารณะ', NULL),
    (activity_id_var, 'school', 'โรงเรียน', NULL),
    (activity_id_var, 'bank', 'ธนาคาร', NULL),
    (activity_id_var, 'shop', 'ร้านค้า', NULL),
    (activity_id_var, 'street', 'ถนน', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_matching_drag', 3, 'Match Place Words', 'Match place words', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'park', 'สวนสาธารณะ', NULL),
    (activity_id_var, 'school', 'โรงเรียน', NULL),
    (activity_id_var, 'bank', 'ธนาคาร', NULL),
    (activity_id_var, 'shop', 'ร้านค้า', NULL),
    (activity_id_var, 'street', 'ถนน', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 4, 'Complete the Sentences 1', 'Fill with the correct word', '{"text": "There is a ___. There is a ___.", "blanks": [{"id": "blank1", "text": "park", "options": ["park", "bank", "shop", "street"], "correctAnswer": "park"}, {"id": "blank2", "text": "school", "options": ["school", "bank", "park", "shop"], "correctAnswer": "school"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 5, 'Complete the Sentences 2', 'Fill with the correct word', '{"text": "The ___ is on this ___. The ___ is near.", "blanks": [{"id": "blank1", "text": "bank", "options": ["bank", "shop", "park", "school"], "correctAnswer": "bank"}, {"id": "blank2", "text": "street", "options": ["street", "shop", "park", "bank"], "correctAnswer": "street"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_explanation', 6, 'There is / There are', 'Talk about places that exist', '{"rules": "Use there is for one; there are for many.\n- There is a bank.\n- There are two shops.\nAsk: Is there a park?", "examples": ["There is a bank on this street.", "There is a park near my house.", "There are two shops here.", "Is there a school nearby?", "Are there many streets?"]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 7, 'Build Sentences 1', 'Arrange words', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'There is a bank on this street', 'There is a bank on this street.', '["There", "is", "a", "bank", "on", "this", "street."]'::jsonb),
    (activity_id_var, 'There is a park near my house', 'There is a park near my house.', '["There", "is", "a", "park", "near", "my", "house."]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 8, 'Build Sentences 2', 'Arrange words', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'There are two shops here', 'There are two shops here.', '["There", "are", "two", "shops", "here."]'::jsonb),
    (activity_id_var, 'Is there a school nearby', 'Is there a school nearby?', '["Is", "there", "a", "school", "nearby?"]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'speaking_practice', 9, 'Talk About Places', 'Practice there is/are for places', '{"prompts": ["Is there a park?", "Where is the bank?", "Do you go to the shop?", "Is there a school near you?", "Is the street busy?"]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (
      lesson_id,
      activity_type,
      activity_order,
      title,
      description,
      content
    ) VALUES (
      'A1-L25',
      'speaking_improvement',
      10,
      'Speaking Improvement',
      'Read the improved version of your speech',
      '{"type": "speaking_improvement", "similarityThreshold": 70}'::jsonb
    );
END $$;

