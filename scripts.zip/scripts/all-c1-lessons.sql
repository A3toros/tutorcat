-- =========================================
-- All C1 Lessons (L1-L100) Combined
-- =========================================


-- =========================================
-- C1 Lesson 1
-- =========================================

-- =========================================
-- Pre-fill Database with Sample Lesson Data
-- C1-L1: Defining Success in Modern Society
-- =========================================
DELETE FROM lesson_activity_results WHERE lesson_id = 'C1-L1';
DELETE FROM user_progress WHERE lesson_id = 'C1-L1';
DELETE FROM lesson_history WHERE lesson_id = 'C1-L1';
DELETE FROM grammar_sentences WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'C1-L1');
DELETE FROM vocabulary_items WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'C1-L1');
DELETE FROM lesson_activities WHERE lesson_id = 'C1-L1';
DELETE FROM lessons WHERE id = 'C1-L1';

INSERT INTO lessons (id, level, lesson_number, topic) VALUES
('C1-L1', 'C1', 1, 'Defining Success in Modern Society')
ON CONFLICT (id) DO UPDATE SET topic = EXCLUDED.topic;

DO $$
DECLARE
    lesson_id_var TEXT := 'C1-L1';
    activity_id_var UUID;
BEGIN
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'warm_up_speaking', 1, 'Success Discussion', 'Discuss what success means', '{"prompt": "What does success mean to you now?"}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_intro', 2, 'Success Vocabulary', 'Learn vocabulary about success', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'achievement', 'ความสำเร็จ', NULL),
    (activity_id_var, 'fulfillment', 'ความพึงพอใจ', NULL),
    (activity_id_var, 'aspiration', 'ความหวัง', NULL),
    (activity_id_var, 'milestone', 'จุดสำคัญ', NULL),
    (activity_id_var, 'accomplishment', 'ผลสำเร็จ', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_matching_drag', 3, 'Match Success Words', 'Match English words with Thai meanings', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'achievement', 'ความสำเร็จ', NULL),
    (activity_id_var, 'fulfillment', 'ความพึงพอใจ', NULL),
    (activity_id_var, 'aspiration', 'ความหวัง', NULL),
    (activity_id_var, 'milestone', 'จุดสำคัญ', NULL),
    (activity_id_var, 'accomplishment', 'ผลสำเร็จ', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 4, 'Complete the Sentences 1', 'Fill with the correct word', '{"text": "Personal ___ brings deep ___. Setting clear ___ helps track progress.", "blanks": [{"id": "blank1", "text": "achievement", "options": ["achievement", "fulfillment", "aspiration", "milestone"], "correctAnswer": "achievement"}, {"id": "blank2", "text": "fulfillment", "options": ["fulfillment", "achievement", "aspiration", "accomplishment"], "correctAnswer": "fulfillment"}, {"id": "blank3", "text": "aspirations", "options": ["aspirations", "achievements", "milestones", "accomplishments"], "correctAnswer": "aspirations"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 5, 'Complete the Sentences 2', 'Fill with the correct word', '{"text": "Reaching a major ___ is a significant ___. Each ___ builds toward greater success.", "blanks": [{"id": "blank1", "text": "milestone", "options": ["milestone", "achievement", "aspiration", "fulfillment"], "correctAnswer": "milestone"}, {"id": "blank2", "text": "accomplishment", "options": ["accomplishment", "achievement", "milestone", "fulfillment"], "correctAnswer": "accomplishment"}, {"id": "blank3", "text": "achievement", "options": ["achievement", "milestone", "aspiration", "fulfillment"], "correctAnswer": "achievement"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_explanation', 6, 'Cleft Sentences and Emphatic Structures', 'Learn cleft sentences for emphasis', '{"rules": "Cleft sentences emphasize specific elements:\n- It-cleft: \"It is success that matters most.\"\n- What-cleft: \"What defines success is personal fulfillment.\"\n- Wh-cleft: \"What I value is achievement.\"\n\nStructure:\n- It + be + emphasized element + that/who clause\n- What + verb + be + emphasized element\n\nUse for:\n- Emphasizing importance: \"It is fulfillment that brings true happiness.\"\n- Highlighting focus: \"What matters is personal growth.\"\n- Clarifying meaning: \"What I seek is meaningful accomplishment.\"", "examples": ["It is fulfillment that defines true success.", "What matters most is personal achievement.", "What I value is meaningful accomplishment.", "It is aspiration that drives progress.", "What defines success is individual fulfillment."]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 7, 'Build Sentences 1', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'It is fulfillment that defines true success.', 'It is fulfillment that defines true success.', '["It", "is", "fulfillment", "that", "defines", "true", "success."]'::jsonb),
    (activity_id_var, 'What matters most is personal achievement.', 'What matters most is personal achievement.', '["What", "matters", "most", "is", "personal", "achievement."]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 8, 'Build Sentences 2', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'What I value is meaningful accomplishment.', 'What I value is meaningful accomplishment.', '["What", "I", "value", "is", "meaningful", "accomplishment."]'::jsonb),
    (activity_id_var, 'It is aspiration that drives personal growth.', 'It is aspiration that drives personal growth.', '["It", "is", "aspiration", "that", "drives", "personal", "growth."]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'speaking_practice', 9, 'Discuss Success', 'Practice speaking about success', '{"prompts": ["What does success mean to you at this stage of your life?", "When do people usually redefine success?", "How do you define success in your academic life?", "What factors influence your idea of success?", "How has your view of success changed over time?"]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (
      lesson_id,
      activity_type,
      activity_order,
      title,
      description,
      content
    ) VALUES (
      'C1-L1',
      'speaking_improvement',
      10,
      'Speaking Improvement',
      'Read the improved version of your speech',
      '{"type": "speaking_improvement", "similarityThreshold": 70}'::jsonb
    );
END $$;



-- =========================================
-- C1 Lesson 2
-- =========================================

-- =========================================
-- Pre-fill Database with Sample Lesson Data
-- C1-L2: Role of Education in Shaping Identity
-- =========================================

DELETE FROM grammar_sentences WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'C1-L2');
DELETE FROM vocabulary_items WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'C1-L2');
DELETE FROM lesson_activities WHERE lesson_id = 'C1-L2';
DELETE FROM lessons WHERE id = 'C1-L2';

INSERT INTO lessons (id, level, lesson_number, topic) VALUES
('C1-L2', 'C1', 2, 'Role of Education in Shaping Identity')
ON CONFLICT (id) DO UPDATE SET topic = EXCLUDED.topic;

DO $$
DECLARE
    lesson_id_var TEXT := 'C1-L2';
    activity_id_var UUID;
BEGIN
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'warm_up_speaking', 1, 'Education and Identity', 'Discuss how education shapes identity', '{"prompt": "How has education shaped who you are?"}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_intro', 2, 'Identity Vocabulary', 'Learn vocabulary about identity and education', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'identity', 'ตัวตน', NULL),
    (activity_id_var, 'formation', 'การก่อตัว', NULL),
    (activity_id_var, 'influence', 'อิทธิพล', NULL),
    (activity_id_var, 'perspective', 'มุมมอง', NULL),
    (activity_id_var, 'development', 'การพัฒนา', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_matching_drag', 3, 'Match Identity Words', 'Match English words with Thai meanings', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'identity', 'ตัวตน', NULL),
    (activity_id_var, 'formation', 'การก่อตัว', NULL),
    (activity_id_var, 'influence', 'อิทธิพล', NULL),
    (activity_id_var, 'perspective', 'มุมมอง', NULL),
    (activity_id_var, 'development', 'การพัฒนา', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 4, 'Complete the Sentences 1', 'Fill with the correct word', '{"text": "Education plays a key role in ___ ___. The ___ of teachers shapes student ___.", "blanks": [{"id": "blank1", "text": "identity", "options": ["identity", "formation", "influence", "perspective"], "correctAnswer": "identity"}, {"id": "blank2", "text": "formation", "options": ["formation", "identity", "influence", "development"], "correctAnswer": "formation"}, {"id": "blank3", "text": "influence", "options": ["influence", "identity", "formation", "perspective"], "correctAnswer": "influence"}, {"id": "blank4", "text": "development", "options": ["development", "identity", "formation", "influence"], "correctAnswer": "development"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 5, 'Complete the Sentences 2', 'Fill with the correct word', '{"text": "Different ___ broaden understanding. Personal ___ continues throughout life.", "blanks": [{"id": "blank1", "text": "perspectives", "options": ["perspectives", "identities", "influences", "formations"], "correctAnswer": "perspectives"}, {"id": "blank2", "text": "development", "options": ["development", "identity", "formation", "influence"], "correctAnswer": "development"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_explanation', 6, 'Nominal Clauses', 'Learn about nominal clauses', '{"rules": "Nominal clauses function as nouns:\n- Subject: \"What education teaches shapes identity.\"\n- Object: \"I believe that education influences development.\"\n- Complement: \"The question is how education shapes us.\"\n\nTypes:\n- That-clauses: \"I think that education matters.\"\n- Wh-clauses: \"What you learn determines your perspective.\"\n- Whether/if: \"The issue is whether education changes identity.\"\n\nUse for:\n- Expressing opinions: \"What I think is that education shapes identity.\"\n- Asking questions: \"How does education influence development?\"\n- Making statements: \"That education matters is clear.\"", "examples": ["What education teaches shapes personal identity.", "I believe that education influences development.", "The question is how education shapes perspective.", "Whether education changes identity remains debated.", "That education matters is widely accepted."]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 7, 'Build Sentences 1', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'What education teaches shapes personal identity.', 'What education teaches shapes personal identity.', '["What", "education", "teaches", "shapes", "personal", "identity."]'::jsonb),
    (activity_id_var, 'I believe that education influences development.', 'I believe that education influences development.', '["I", "believe", "that", "education", "influences", "development."]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 8, 'Build Sentences 2', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'The question is how education shapes perspective.', 'The question is how education shapes perspective.', '["The", "question", "is", "how", "education", "shapes", "perspective."]'::jsonb),
    (activity_id_var, 'Whether education changes identity remains uncertain.', 'Whether education changes identity remains uncertain.', '["Whether", "education", "changes", "identity", "remains", "uncertain."]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'speaking_practice', 9, 'Discuss Education and Identity', 'Practice speaking about education shaping identity', '{"prompts": ["How has education shaped your identity?", "What would change if you had a different educational background?", "In what ways does education influence personal development?", "What role does education play in shaping identity?", "How do school experiences affect values and beliefs?"]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (
      lesson_id,
      activity_type,
      activity_order,
      title,
      description,
      content
    ) VALUES (
      'C1-L2',
      'speaking_improvement',
      10,
      'Speaking Improvement',
      'Read the improved version of your speech',
      '{"type": "speaking_improvement", "similarityThreshold": 70}'::jsonb
    );
END $$;



-- =========================================
-- C1 Lesson 3
-- =========================================

-- =========================================
-- Pre-fill Database with Sample Lesson Data
-- C1-L3: Critical Thinking in Academic Life
-- =========================================

DELETE FROM grammar_sentences WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'C1-L3');
DELETE FROM vocabulary_items WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'C1-L3');
DELETE FROM lesson_activities WHERE lesson_id = 'C1-L3';
DELETE FROM lessons WHERE id = 'C1-L3';

INSERT INTO lessons (id, level, lesson_number, topic) VALUES
('C1-L3', 'C1', 3, 'Critical Thinking in Academic Life')
ON CONFLICT (id) DO UPDATE SET topic = EXCLUDED.topic;

DO $$
DECLARE
    lesson_id_var TEXT := 'C1-L3';
    activity_id_var UUID;
BEGIN
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'warm_up_speaking', 1, 'Critical Thinking', 'Discuss critical thinking', '{"prompt": "When do you question assumptions?"}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_intro', 2, 'Critical Thinking Vocabulary', 'Learn vocabulary about critical thinking', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'analysis', 'การวิเคราะห์', NULL),
    (activity_id_var, 'evaluation', 'การประเมิน', NULL),
    (activity_id_var, 'reasoning', 'การให้เหตุผล', NULL),
    (activity_id_var, 'assumption', 'สมมติฐาน', NULL),
    (activity_id_var, 'evidence', 'หลักฐาน', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_matching_drag', 3, 'Match Critical Thinking Words', 'Match English words with Thai meanings', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'analysis', 'การวิเคราะห์', NULL),
    (activity_id_var, 'evaluation', 'การประเมิน', NULL),
    (activity_id_var, 'reasoning', 'การให้เหตุผล', NULL),
    (activity_id_var, 'assumption', 'สมมติฐาน', NULL),
    (activity_id_var, 'evidence', 'หลักฐาน', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 4, 'Complete the Sentences 1', 'Fill with the correct word', '{"text": "Critical ___ requires careful ___. Strong ___ supports sound ___.", "blanks": [{"id": "blank1", "text": "analysis", "options": ["analysis", "evaluation", "reasoning", "assumption"], "correctAnswer": "analysis"}, {"id": "blank2", "text": "evaluation", "options": ["evaluation", "analysis", "reasoning", "evidence"], "correctAnswer": "evaluation"}, {"id": "blank3", "text": "evidence", "options": ["evidence", "analysis", "assumption", "reasoning"], "correctAnswer": "evidence"}, {"id": "blank4", "text": "reasoning", "options": ["reasoning", "analysis", "evaluation", "assumption"], "correctAnswer": "reasoning"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 5, 'Complete the Sentences 2', 'Fill with the correct word', '{"text": "Questioning ___ leads to deeper understanding. Valid ___ requires solid ___.", "blanks": [{"id": "blank1", "text": "assumptions", "options": ["assumptions", "analysis", "evaluation", "reasoning"], "correctAnswer": "assumptions"}, {"id": "blank2", "text": "reasoning", "options": ["reasoning", "analysis", "assumption", "evidence"], "correctAnswer": "reasoning"}, {"id": "blank3", "text": "evidence", "options": ["evidence", "analysis", "assumption", "evaluation"], "correctAnswer": "evidence"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_explanation', 6, 'Inversion: Seldom/Rarely', 'Learn inversion with seldom and rarely', '{"rules": "Inversion with seldom/rarely:\n- \"Seldom do students question assumptions.\" (formal emphasis)\n- \"Rarely do we challenge authority.\" (emphasis on infrequency)\n- \"Seldom have I seen such critical thinking.\" (past emphasis)\n\nStructure:\n- Seldom/Rarely + auxiliary + subject + verb\n- Used for emphasis and formal tone\n\nUse for:\n- Emphasizing rarity: \"Rarely do we question information.\"\n- Formal statements: \"Seldom did they challenge assumptions.\"\n- Highlighting infrequency: \"Rarely is critical thinking encouraged.\"", "examples": ["Seldom do students question assumptions without prompting.", "Rarely do we challenge information we receive.", "Seldom have I encountered such thorough analysis.", "Rarely is critical thinking fully developed in students.", "Seldom does evaluation occur without evidence."]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 7, 'Build Sentences 1', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'Seldom do students question assumptions without prompting.', 'Seldom do students question assumptions without prompting.', '["Seldom", "do", "students", "question", "assumptions", "without", "prompting."]'::jsonb),
    (activity_id_var, 'Rarely do we challenge information we receive.', 'Rarely do we challenge information we receive.', '["Rarely", "do", "we", "challenge", "information", "we", "receive."]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 8, 'Build Sentences 2', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'Seldom have I encountered such thorough analysis.', 'Seldom have I encountered such thorough analysis.', '["Seldom", "have", "I", "encountered", "such", "thorough", "analysis."]'::jsonb),
    (activity_id_var, 'Rarely is critical thinking fully developed in students.', 'Rarely is critical thinking fully developed in students.', '["Rarely", "is", "critical", "thinking", "fully", "developed", "in", "students."]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'speaking_practice', 9, 'Discuss Critical Thinking', 'Practice speaking about critical thinking', '{"prompts": ["When do you question information you are given?", "What triggers doubt in your academic work?", "How do you develop critical thinking skills?", "What makes an argument worth challenging?", "When is it important to challenge ideas?"]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (
      lesson_id,
      activity_type,
      activity_order,
      title,
      description,
      content
    ) VALUES (
      'C1-L3',
      'speaking_improvement',
      10,
      'Speaking Improvement',
      'Read the improved version of your speech',
      '{"type": "speaking_improvement", "similarityThreshold": 70}'::jsonb
    );
END $$;



-- =========================================
-- C1 Lesson 4
-- =========================================

-- =========================================
-- Pre-fill Database with Sample Lesson Data
-- C1-L4: Academic Freedom and Its Limits
-- =========================================

DELETE FROM grammar_sentences WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'C1-L4');
DELETE FROM vocabulary_items WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'C1-L4');
DELETE FROM lesson_activities WHERE lesson_id = 'C1-L4';
DELETE FROM lessons WHERE id = 'C1-L4';

INSERT INTO lessons (id, level, lesson_number, topic) VALUES
('C1-L4', 'C1', 4, 'Academic Freedom and Its Limits')
ON CONFLICT (id) DO UPDATE SET topic = EXCLUDED.topic;

DO $$
DECLARE
    lesson_id_var TEXT := 'C1-L4';
    activity_id_var UUID;
BEGIN
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'warm_up_speaking', 1, 'Academic Freedom', 'Discuss academic freedom and limits', '{"prompt": "How confident are you that limits are necessary?"}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_intro', 2, 'Academic Freedom Vocabulary', 'Learn vocabulary about academic freedom', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'freedom', 'เสรีภาพ', NULL),
    (activity_id_var, 'restriction', 'ข้อจำกัด', NULL),
    (activity_id_var, 'expression', 'การแสดงออก', NULL),
    (activity_id_var, 'boundary', 'ขอบเขต', NULL),
    (activity_id_var, 'responsibility', 'ความรับผิดชอบ', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_matching_drag', 3, 'Match Academic Freedom Words', 'Match English words with Thai meanings', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'freedom', 'เสรีภาพ', NULL),
    (activity_id_var, 'restriction', 'ข้อจำกัด', NULL),
    (activity_id_var, 'expression', 'การแสดงออก', NULL),
    (activity_id_var, 'boundary', 'ขอบเขต', NULL),
    (activity_id_var, 'responsibility', 'ความรับผิดชอบ', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 4, 'Complete the Sentences 1', 'Fill with the correct word', '{"text": "Academic ___ allows open ___. However, some ___ protect students.", "blanks": [{"id": "blank1", "text": "freedom", "options": ["freedom", "restriction", "expression", "boundary"], "correctAnswer": "freedom"}, {"id": "blank2", "text": "expression", "options": ["expression", "freedom", "restriction", "responsibility"], "correctAnswer": "expression"}, {"id": "blank3", "text": "restrictions", "options": ["restrictions", "freedom", "expression", "boundary"], "correctAnswer": "restrictions"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 5, 'Complete the Sentences 2', 'Fill with the correct word', '{"text": "Clear ___ define acceptable behavior. Academic ___ requires ___.", "blanks": [{"id": "blank1", "text": "boundaries", "options": ["boundaries", "freedom", "restriction", "expression"], "correctAnswer": "boundaries"}, {"id": "blank2", "text": "freedom", "options": ["freedom", "restriction", "expression", "boundary"], "correctAnswer": "freedom"}, {"id": "blank3", "text": "responsibility", "options": ["responsibility", "freedom", "restriction", "boundary"], "correctAnswer": "responsibility"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_explanation', 6, 'Modals: Degrees of Certainty', 'Learn modals expressing degrees of certainty', '{"rules": "Modals for degrees of certainty:\n- \"must\" (high certainty): \"Limits must be necessary.\"\n- \"should\" (probable): \"Limits should help academic environments.\"\n- \"might/may\" (possible): \"Limits might harm freedom.\"\n- \"could\" (less certain): \"Limits could restrict expression.\"\n\nUse for:\n- Expressing confidence: \"I am certain that limits help.\"\n- Showing uncertainty: \"I am not sure if limits are needed.\"\n- Speculating: \"Limits might be necessary in some cases.\"", "examples": ["Limits must be necessary for academic safety.", "I should be certain that limits help academic environments.", "Limits might harm academic freedom if too strict.", "I could be wrong about the need for restrictions.", "You may be confident that boundaries protect students."]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 7, 'Build Sentences 1', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'Limits must be necessary for academic safety.', 'Limits must be necessary for academic safety.', '["Limits", "must", "be", "necessary", "for", "academic", "safety."]'::jsonb),
    (activity_id_var, 'I should be certain that limits help academic environments.', 'I should be certain that limits help academic environments.', '["I", "should", "be", "certain", "that", "limits", "help", "academic", "environments."]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 8, 'Build Sentences 2', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'Limits might harm academic freedom if too strict.', 'Limits might harm academic freedom if too strict.', '["Limits", "might", "harm", "academic", "freedom", "if", "too", "strict."]'::jsonb),
    (activity_id_var, 'You may be confident that boundaries protect students.', 'You may be confident that boundaries protect students.', '["You", "may", "be", "confident", "that", "boundaries", "protect", "students."]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'speaking_practice', 9, 'Discuss Academic Freedom', 'Practice speaking about academic freedom', '{"prompts": ["How certain are you that limits help academic environments?", "When might limits harm academic freedom?", "What limits should exist in academic settings?", "How should freedom and responsibility be balanced?", "When should academic expression be restricted?"]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (
      lesson_id,
      activity_type,
      activity_order,
      title,
      description,
      content
    ) VALUES (
      'C1-L4',
      'speaking_improvement',
      10,
      'Speaking Improvement',
      'Read the improved version of your speech',
      '{"type": "speaking_improvement", "similarityThreshold": 70}'::jsonb
    );
END $$;



-- =========================================
-- C1 Lesson 5
-- =========================================

-- =========================================
-- Pre-fill Database with Sample Lesson Data
-- C1-L5: Purpose of Higher Education
-- =========================================

DELETE FROM grammar_sentences WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'C1-L5');
DELETE FROM vocabulary_items WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'C1-L5');
DELETE FROM lesson_activities WHERE lesson_id = 'C1-L5';
DELETE FROM lessons WHERE id = 'C1-L5';

INSERT INTO lessons (id, level, lesson_number, topic) VALUES
('C1-L5', 'C1', 5, 'Purpose of Higher Education')
ON CONFLICT (id) DO UPDATE SET topic = EXCLUDED.topic;

DO $$
DECLARE
    lesson_id_var TEXT := 'C1-L5';
    activity_id_var UUID;
BEGIN
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'warm_up_speaking', 1, 'Higher Education Purpose', 'Discuss the purpose of higher education', '{"prompt": "What do you seek from higher education?"}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_intro', 2, 'Higher Education Vocabulary', 'Learn vocabulary about higher education', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'purpose', 'จุดประสงค์', NULL),
    (activity_id_var, 'pursuit', 'การแสวงหา', NULL),
    (activity_id_var, 'scholarship', 'ทุนการศึกษา', NULL),
    (activity_id_var, 'excellence', 'ความเป็นเลิศ', NULL),
    (activity_id_var, 'enlightenment', 'การให้ความรู้', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_matching_drag', 3, 'Match Higher Education Words', 'Match English words with Thai meanings', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'purpose', 'จุดประสงค์', NULL),
    (activity_id_var, 'pursuit', 'การแสวงหา', NULL),
    (activity_id_var, 'scholarship', 'ทุนการศึกษา', NULL),
    (activity_id_var, 'excellence', 'ความเป็นเลิศ', NULL),
    (activity_id_var, 'enlightenment', 'การให้ความรู้', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 4, 'Complete the Sentences 1', 'Fill with the correct word', '{"text": "The ___ of higher education is intellectual ___. Students pursue academic ___.", "blanks": [{"id": "blank1", "text": "purpose", "options": ["purpose", "pursuit", "scholarship", "excellence"], "correctAnswer": "purpose"}, {"id": "blank2", "text": "enlightenment", "options": ["enlightenment", "purpose", "pursuit", "excellence"], "correctAnswer": "enlightenment"}, {"id": "blank3", "text": "excellence", "options": ["excellence", "purpose", "pursuit", "scholarship"], "correctAnswer": "excellence"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 5, 'Complete the Sentences 2', 'Fill with the correct word', '{"text": "Academic ___ requires dedication. ___ supports student ___.", "blanks": [{"id": "blank1", "text": "pursuit", "options": ["pursuit", "purpose", "scholarship", "excellence"], "correctAnswer": "pursuit"}, {"id": "blank2", "text": "Scholarship", "options": ["Scholarship", "Purpose", "Pursuit", "Excellence"], "correctAnswer": "Scholarship"}, {"id": "blank3", "text": "pursuit", "options": ["pursuit", "purpose", "excellence", "enlightenment"], "correctAnswer": "pursuit"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_explanation', 6, 'Cleft Sentences: It-clefts', 'Learn it-cleft sentences for emphasis', '{"rules": "It-cleft sentences emphasize specific elements:\n- It-cleft: \"It is knowledge that I seek.\"\n- Structure: It + be + emphasized element + that/who clause\n\nUse for:\n- Emphasizing what you seek: \"It is enlightenment that matters.\"\n- Highlighting purpose: \"It is excellence that drives me.\"\n- Clarifying meaning: \"It is scholarship that enables pursuit.\"", "examples": ["It is enlightenment that I seek from higher education.", "It is excellence that makes higher education meaningful.", "It is scholarship that enables academic pursuit.", "It is knowledge that drives my studies.", "It is purpose that guides my education."]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 7, 'Build Sentences 1', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'It is enlightenment that I seek from higher education.', 'It is enlightenment that I seek from higher education.', '["It", "is", "enlightenment", "that", "I", "seek", "from", "higher", "education."]'::jsonb),
    (activity_id_var, 'It is excellence that makes higher education meaningful.', 'It is excellence that makes higher education meaningful.', '["It", "is", "excellence", "that", "makes", "higher", "education", "meaningful."]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 8, 'Build Sentences 2', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'It is scholarship that enables academic pursuit.', 'It is scholarship that enables academic pursuit.', '["It", "is", "scholarship", "that", "enables", "academic", "pursuit."]'::jsonb),
    (activity_id_var, 'It is purpose that guides my education.', 'It is purpose that guides my education.', '["It", "is", "purpose", "that", "guides", "my", "education."]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'speaking_practice', 9, 'Discuss Higher Education', 'Practice speaking about higher education', '{"prompts": ["What do you seek from higher education?", "What makes higher education meaningful?", "What are your main goals for university study?", "How do you measure the value of education?", "What outcomes do you expect from your studies?"]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (
      lesson_id,
      activity_type,
      activity_order,
      title,
      description,
      content
    ) VALUES (
      'C1-L5',
      'speaking_improvement',
      10,
      'Speaking Improvement',
      'Read the improved version of your speech',
      '{"type": "speaking_improvement", "similarityThreshold": 70}'::jsonb
    );
END $$;



-- =========================================
-- C1 Lesson 6
-- =========================================

-- =========================================
-- Pre-fill Database with Sample Lesson Data
-- C1-L6: Knowledge vs Skills in the 21st Century
-- =========================================

DELETE FROM grammar_sentences WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'C1-L6');
DELETE FROM vocabulary_items WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'C1-L6');
DELETE FROM lesson_activities WHERE lesson_id = 'C1-L6';
DELETE FROM lessons WHERE id = 'C1-L6';

INSERT INTO lessons (id, level, lesson_number, topic) VALUES
('C1-L6', 'C1', 6, 'Knowledge vs Skills in the 21st Century')
ON CONFLICT (id) DO UPDATE SET topic = EXCLUDED.topic;

DO $$
DECLARE
    lesson_id_var TEXT := 'C1-L6';
    activity_id_var UUID;
BEGIN
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'warm_up_speaking', 1, 'Knowledge vs Skills', 'Discuss knowledge versus skills', '{"prompt": "Which do you value more today: knowledge or skills?"}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_intro', 2, 'Knowledge and Skills Vocabulary', 'Learn vocabulary about knowledge and skills', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'knowledge', 'ความรู้', NULL),
    (activity_id_var, 'competence', 'ความสามารถ', NULL),
    (activity_id_var, 'expertise', 'ความเชี่ยวชาญ', NULL),
    (activity_id_var, 'proficiency', 'ความชำนาญ', NULL),
    (activity_id_var, 'application', 'การประยุกต์ใช้', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_matching_drag', 3, 'Match Knowledge and Skills Words', 'Match English words with Thai meanings', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'knowledge', 'ความรู้', NULL),
    (activity_id_var, 'competence', 'ความสามารถ', NULL),
    (activity_id_var, 'expertise', 'ความเชี่ยวชาญ', NULL),
    (activity_id_var, 'proficiency', 'ความชำนาญ', NULL),
    (activity_id_var, 'application', 'การประยุกต์ใช้', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 4, 'Complete the Sentences 1', 'Fill with the correct word', '{"text": "Theoretical ___ differs from practical ___. ___ requires both ___.", "blanks": [{"id": "blank1", "text": "knowledge", "options": ["knowledge", "competence", "expertise", "proficiency"], "correctAnswer": "knowledge"}, {"id": "blank2", "text": "competence", "options": ["competence", "knowledge", "expertise", "application"], "correctAnswer": "competence"}, {"id": "blank3", "text": "Expertise", "options": ["Expertise", "Knowledge", "Competence", "Proficiency"], "correctAnswer": "Expertise"}, {"id": "blank4", "text": "application", "options": ["application", "knowledge", "competence", "proficiency"], "correctAnswer": "application"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 5, 'Complete the Sentences 2', 'Fill with the correct word', '{"text": "Technical ___ demonstrates ___. Effective ___ combines knowledge and skills.", "blanks": [{"id": "blank1", "text": "proficiency", "options": ["proficiency", "knowledge", "competence", "expertise"], "correctAnswer": "proficiency"}, {"id": "blank2", "text": "competence", "options": ["competence", "knowledge", "expertise", "application"], "correctAnswer": "competence"}, {"id": "blank3", "text": "application", "options": ["application", "knowledge", "competence", "proficiency"], "correctAnswer": "application"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_explanation', 6, 'Contrast Linking at C1 Level', 'Learn advanced contrast linking', '{"rules": "C1 contrast linking shows nuanced relationships:\n- \"While/Whereas\" (formal contrast): \"While knowledge is important, skills are practical.\"\n- \"However/Nevertheless\" (concession): \"Knowledge matters; however, skills are essential.\"\n- \"On the one hand... on the other hand\" (balanced contrast)\n- \"Despite/In spite of\" (contrary expectation): \"Despite knowledge, skills matter more.\"\n\nUse for:\n- Presenting balanced views: \"On one hand, knowledge is valuable; on the other, skills are practical.\"\n- Acknowledging complexity: \"While knowledge provides foundation, skills enable application.\"\n- Showing contradiction: \"Knowledge is important; however, skills determine success.\"", "examples": ["While knowledge provides foundation, skills enable application.", "Knowledge matters; however, skills are essential today.", "On the one hand, knowledge is valuable; on the other, skills are practical.", "Despite theoretical knowledge, practical competence matters more.", "Whereas knowledge is static, skills develop through practice."]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 7, 'Build Sentences 1', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'While knowledge provides foundation, skills enable application.', 'While knowledge provides foundation, skills enable application.', '["While", "knowledge", "provides", "foundation,", "skills", "enable", "application."]'::jsonb),
    (activity_id_var, 'Knowledge matters; however, skills are essential today.', 'Knowledge matters; however, skills are essential today.', '["Knowledge", "matters;", "however,", "skills", "are", "essential", "today."]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 8, 'Build Sentences 2', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'On the one hand, knowledge is valuable; on the other, skills are practical.', 'On the one hand, knowledge is valuable; on the other, skills are practical.', '["On", "the", "one", "hand,", "knowledge", "is", "valuable;", "on", "the", "other,", "skills", "are", "practical."]'::jsonb),
    (activity_id_var, 'Despite theoretical knowledge, practical competence matters more.', 'Despite theoretical knowledge, practical competence matters more.', '["Despite", "theoretical", "knowledge,", "practical", "competence", "matters", "more."]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'speaking_practice', 9, 'Discuss Knowledge and Skills', 'Practice speaking about knowledge versus skills', '{"prompts": ["Which is more important today: knowledge or skills?", "Why might one be valued over the other?", "How do knowledge and skills complement each other?", "What balance between knowledge and skills is ideal?", "How has their importance changed over time?"]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (
      lesson_id,
      activity_type,
      activity_order,
      title,
      description,
      content
    ) VALUES (
      'C1-L6',
      'speaking_improvement',
      10,
      'Speaking Improvement',
      'Read the improved version of your speech',
      '{"type": "speaking_improvement", "similarityThreshold": 70}'::jsonb
    );
END $$;



-- =========================================
-- C1 Lesson 7
-- =========================================

-- =========================================
-- Pre-fill Database with Sample Lesson Data
-- C1-L7: Lifelong Learning
-- =========================================

DELETE FROM grammar_sentences WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'C1-L7');
DELETE FROM vocabulary_items WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'C1-L7');
DELETE FROM lesson_activities WHERE lesson_id = 'C1-L7';
DELETE FROM lessons WHERE id = 'C1-L7';

INSERT INTO lessons (id, level, lesson_number, topic) VALUES
('C1-L7', 'C1', 7, 'Lifelong Learning')
ON CONFLICT (id) DO UPDATE SET topic = EXCLUDED.topic;

DO $$
DECLARE
    lesson_id_var TEXT := 'C1-L7';
    activity_id_var UUID;
BEGIN
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'warm_up_speaking', 1, 'Lifelong Learning', 'Discuss lifelong learning', '{"prompt": "How do you continue learning outside the classroom?"}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_intro', 2, 'Lifelong Learning Vocabulary', 'Learn vocabulary about lifelong learning', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'continuous', 'ต่อเนื่อง', NULL),
    (activity_id_var, 'self-directed', 'ด้วยตนเอง', NULL),
    (activity_id_var, 'adaptation', 'การปรับตัว', NULL),
    (activity_id_var, 'enrichment', 'การเสริมสร้าง', NULL),
    (activity_id_var, 'growth', 'การเติบโต', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_matching_drag', 3, 'Match Lifelong Learning Words', 'Match English words with Thai meanings', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'continuous', 'ต่อเนื่อง', NULL),
    (activity_id_var, 'self-directed', 'ด้วยตนเอง', NULL),
    (activity_id_var, 'adaptation', 'การปรับตัว', NULL),
    (activity_id_var, 'enrichment', 'การเสริมสร้าง', NULL),
    (activity_id_var, 'growth', 'การเติบโต', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 4, 'Complete the Sentences 1', 'Fill with the correct word', '{"text": "___ learning requires ___ effort. ___ learning promotes personal ___.", "blanks": [{"id": "blank1", "text": "Continuous", "options": ["Continuous", "Self-directed", "Adaptation", "Enrichment"], "correctAnswer": "Continuous"}, {"id": "blank2", "text": "self-directed", "options": ["self-directed", "continuous", "adaptation", "enrichment"], "correctAnswer": "self-directed"}, {"id": "blank3", "text": "Self-directed", "options": ["Self-directed", "Continuous", "Adaptation", "Growth"], "correctAnswer": "Self-directed"}, {"id": "blank4", "text": "growth", "options": ["growth", "continuous", "adaptation", "enrichment"], "correctAnswer": "growth"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 5, 'Complete the Sentences 2', 'Fill with the correct word', '{"text": "Successful ___ requires constant ___. Learning brings intellectual ___.", "blanks": [{"id": "blank1", "text": "adaptation", "options": ["adaptation", "continuous", "self-directed", "enrichment"], "correctAnswer": "adaptation"}, {"id": "blank2", "text": "learning", "options": ["learning", "adaptation", "growth", "enrichment"], "correctAnswer": "learning"}, {"id": "blank3", "text": "enrichment", "options": ["enrichment", "adaptation", "growth", "continuous"], "correctAnswer": "enrichment"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_explanation', 6, 'Participle Clauses', 'Learn participle clauses', '{"rules": "Participle clauses:\n- Present participle (-ing): \"Learning continuously, students grow.\"\n- Past participle (-ed): \"Motivated by curiosity, they explore.\"\n- Perfect participle (having + past participle): \"Having learned the basics, they advanced.\"\n\nUse for:\n- Showing simultaneous actions: \"Continuing to learn, you develop skills.\"\n- Showing cause: \"Motivated by growth, students pursue learning.\"\n- Showing time sequence: \"Having completed the course, they continued learning.\"", "examples": ["Continuing to learn outside class, students develop skills.", "Motivated by curiosity, learners explore new topics.", "Having learned the basics, they advanced to complex subjects.", "Keeping learning habits, people maintain growth.", "Inspired by enrichment, students pursue knowledge."]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 7, 'Build Sentences 1', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'Continuing to learn outside class, students develop skills.', 'Continuing to learn outside class, students develop skills.', '["Continuing", "to", "learn", "outside", "class,", "students", "develop", "skills."]'::jsonb),
    (activity_id_var, 'Motivated by curiosity, learners explore new topics.', 'Motivated by curiosity, learners explore new topics.', '["Motivated", "by", "curiosity,", "learners", "explore", "new", "topics."]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 8, 'Build Sentences 2', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'Having learned the basics, they advanced to complex subjects.', 'Having learned the basics, they advanced to complex subjects.', '["Having", "learned", "the", "basics,", "they", "advanced", "to", "complex", "subjects."]'::jsonb),
    (activity_id_var, 'Keeping learning habits, people maintain growth.', 'Keeping learning habits, people maintain growth.', '["Keeping", "learning", "habits,", "people", "maintain", "growth."]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'speaking_practice', 9, 'Discuss Lifelong Learning', 'Practice speaking about lifelong learning', '{"prompts": ["How do you keep learning beyond formal education?", "What habits support lifelong learning?", "What motivates you to continue learning?", "How do you include learning in daily life?", "What resources do you use for self-directed learning?"]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (
      lesson_id,
      activity_type,
      activity_order,
      title,
      description,
      content
    ) VALUES (
      'C1-L7',
      'speaking_improvement',
      10,
      'Speaking Improvement',
      'Read the improved version of your speech',
      '{"type": "speaking_improvement", "similarityThreshold": 70}'::jsonb
    );
END $$;



-- =========================================
-- C1 Lesson 8
-- =========================================

-- =========================================
-- Pre-fill Database with Sample Lesson Data
-- C1-L8: Intellectual Curiosity
-- =========================================

DELETE FROM grammar_sentences WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'C1-L8');
DELETE FROM vocabulary_items WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'C1-L8');
DELETE FROM lesson_activities WHERE lesson_id = 'C1-L8';
DELETE FROM lessons WHERE id = 'C1-L8';

INSERT INTO lessons (id, level, lesson_number, topic) VALUES
('C1-L8', 'C1', 8, 'Intellectual Curiosity')
ON CONFLICT (id) DO UPDATE SET topic = EXCLUDED.topic;

DO $$
DECLARE
    lesson_id_var TEXT := 'C1-L8';
    activity_id_var UUID;
BEGIN
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'warm_up_speaking', 1, 'Intellectual Curiosity', 'Discuss intellectual curiosity', '{"prompt": "What have you pursued purely out of curiosity?"}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_intro', 2, 'Curiosity Vocabulary', 'Learn vocabulary about intellectual curiosity', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'curiosity', 'ความอยากรู้', NULL),
    (activity_id_var, 'inquiry', 'การสอบถาม', NULL),
    (activity_id_var, 'exploration', 'การสำรวจ', NULL),
    (activity_id_var, 'discovery', 'การค้นพบ', NULL),
    (activity_id_var, 'investigation', 'การสืบสวน', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_matching_drag', 3, 'Match Curiosity Words', 'Match English words with Thai meanings', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'curiosity', 'ความอยากรู้', NULL),
    (activity_id_var, 'inquiry', 'การสอบถาม', NULL),
    (activity_id_var, 'exploration', 'การสำรวจ', NULL),
    (activity_id_var, 'discovery', 'การค้นพบ', NULL),
    (activity_id_var, 'investigation', 'การสืบสวน', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 4, 'Complete the Sentences 1', 'Fill with the correct word', '{"text": "Intellectual ___ drives ___. Careful ___ leads to ___.", "blanks": [{"id": "blank1", "text": "curiosity", "options": ["curiosity", "inquiry", "exploration", "discovery"], "correctAnswer": "curiosity"}, {"id": "blank2", "text": "exploration", "options": ["exploration", "curiosity", "inquiry", "investigation"], "correctAnswer": "exploration"}, {"id": "blank3", "text": "investigation", "options": ["investigation", "curiosity", "inquiry", "discovery"], "correctAnswer": "investigation"}, {"id": "blank4", "text": "discovery", "options": ["discovery", "curiosity", "inquiry", "exploration"], "correctAnswer": "discovery"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 5, 'Complete the Sentences 2', 'Fill with the correct word', '{"text": "Academic ___ requires systematic ___. ___ often follows deep ___.", "blanks": [{"id": "blank1", "text": "inquiry", "options": ["inquiry", "curiosity", "exploration", "discovery"], "correctAnswer": "inquiry"}, {"id": "blank2", "text": "investigation", "options": ["investigation", "curiosity", "inquiry", "exploration"], "correctAnswer": "investigation"}, {"id": "blank3", "text": "Discovery", "options": ["Discovery", "Curiosity", "Inquiry", "Exploration"], "correctAnswer": "Discovery"}, {"id": "blank4", "text": "exploration", "options": ["exploration", "curiosity", "inquiry", "investigation"], "correctAnswer": "exploration"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_explanation', 6, 'Advanced Perfect Aspect', 'Learn advanced perfect forms', '{"rules": "Advanced perfect aspect:\n- Present perfect: \"I have explored many topics.\"\n- Past perfect: \"I had discovered this before.\"\n- Future perfect: \"I will have investigated this by then.\"\n- Perfect continuous: \"I have been exploring for years.\"\n\nUse for:\n- Completed actions with present relevance: \"I have pursued curiosity.\"\n- Past before past: \"I had explored this before discovering that.\"\n- Future completion: \"I will have investigated this by next year.\"", "examples": ["I have explored many topics purely for curiosity.", "I had discovered this concept before the lecture.", "I will have investigated this thoroughly by next month.", "I have been pursuing intellectual curiosity for years.", "Having explored extensively, I discovered new insights."]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 7, 'Build Sentences 1', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'I have explored many topics purely for curiosity.', 'I have explored many topics purely for curiosity.', '["I", "have", "explored", "many", "topics", "purely", "for", "curiosity."]'::jsonb),
    (activity_id_var, 'I had discovered this concept before the lecture.', 'I had discovered this concept before the lecture.', '["I", "had", "discovered", "this", "concept", "before", "the", "lecture."]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 8, 'Build Sentences 2', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'I have been pursuing intellectual curiosity for years.', 'I have been pursuing intellectual curiosity for years.', '["I", "have", "been", "pursuing", "intellectual", "curiosity", "for", "years."]'::jsonb),
    (activity_id_var, 'Having explored extensively, I discovered new insights.', 'Having explored extensively, I discovered new insights.', '["Having", "explored", "extensively,", "I", "discovered", "new", "insights."]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'speaking_practice', 9, 'Discuss Intellectual Curiosity', 'Practice speaking about intellectual curiosity', '{"prompts": ["What have you explored purely for curiosity?", "How has curiosity shaped your thinking?", "What topics spark your intellectual interest?", "How do you maintain curiosity over time?", "What have you discovered by following curiosity?"]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (
      lesson_id,
      activity_type,
      activity_order,
      title,
      description,
      content
    ) VALUES (
      'C1-L8',
      'speaking_improvement',
      10,
      'Speaking Improvement',
      'Read the improved version of your speech',
      '{"type": "speaking_improvement", "similarityThreshold": 70}'::jsonb
    );
END $$;



-- =========================================
-- C1 Lesson 9
-- =========================================

-- =========================================
-- Pre-fill Database with Sample Lesson Data
-- C1-L9: Academic Pressure & Achievement Culture
-- =========================================

DELETE FROM grammar_sentences WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'C1-L9');
DELETE FROM vocabulary_items WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'C1-L9');
DELETE FROM lesson_activities WHERE lesson_id = 'C1-L9';
DELETE FROM lessons WHERE id = 'C1-L9';

INSERT INTO lessons (id, level, lesson_number, topic) VALUES
('C1-L9', 'C1', 9, 'Academic Pressure & Achievement Culture')
ON CONFLICT (id) DO UPDATE SET topic = EXCLUDED.topic;

DO $$
DECLARE
    lesson_id_var TEXT := 'C1-L9';
    activity_id_var UUID;
BEGIN
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'warm_up_speaking', 1, 'Academic Pressure', 'Discuss academic pressure', '{"prompt": "Describe a time when academic pressure was highest."}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_intro', 2, 'Academic Pressure Vocabulary', 'Learn vocabulary about academic pressure', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'pressure', 'ความกดดัน', NULL),
    (activity_id_var, 'stress', 'ความเครียด', NULL),
    (activity_id_var, 'expectation', 'ความคาดหวัง', NULL),
    (activity_id_var, 'competition', 'การแข่งขัน', NULL),
    (activity_id_var, 'overwhelm', 'ความท่วมท้น', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_matching_drag', 3, 'Match Academic Pressure Words', 'Match English words with Thai meanings', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'pressure', 'ความกดดัน', NULL),
    (activity_id_var, 'stress', 'ความเครียด', NULL),
    (activity_id_var, 'expectation', 'ความคาดหวัง', NULL),
    (activity_id_var, 'competition', 'การแข่งขัน', NULL),
    (activity_id_var, 'overwhelm', 'ความท่วมท้น', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 4, 'Complete the Sentences 1', 'Fill with the correct word', '{"text": "Academic ___ creates significant ___. High ___ increase ___.", "blanks": [{"id": "blank1", "text": "pressure", "options": ["pressure", "stress", "expectation", "competition"], "correctAnswer": "pressure"}, {"id": "blank2", "text": "stress", "options": ["stress", "pressure", "expectation", "overwhelm"], "correctAnswer": "stress"}, {"id": "blank3", "text": "expectations", "options": ["expectations", "pressure", "stress", "competition"], "correctAnswer": "expectations"}, {"id": "blank4", "text": "overwhelm", "options": ["overwhelm", "pressure", "stress", "competition"], "correctAnswer": "overwhelm"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 5, 'Complete the Sentences 2', 'Fill with the correct word', '{"text": "Intense ___ drives achievement. Managing ___ requires balance.", "blanks": [{"id": "blank1", "text": "competition", "options": ["competition", "pressure", "stress", "expectation"], "correctAnswer": "competition"}, {"id": "blank2", "text": "pressure", "options": ["pressure", "competition", "stress", "overwhelm"], "correctAnswer": "pressure"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_explanation', 6, 'Narrative Tenses', 'Learn narrative tenses for storytelling', '{"rules": "Narrative tenses:\n- Past simple: \"The pressure peaked last semester.\"\n- Past continuous: \"I was studying when the pressure increased.\"\n- Past perfect: \"I had finished when the pressure peaked.\"\n- Past perfect continuous: \"I had been studying when pressure peaked.\"\n\nUse for:\n- Main events: \"The situation unfolded quickly.\"\n- Background: \"I was studying when pressure peaked.\"\n- Earlier events: \"I had prepared before pressure peaked.\"\n- Duration: \"I had been studying when pressure peaked.\"", "examples": ["The academic pressure peaked during finals.", "I was studying when the pressure became overwhelming.", "I had prepared thoroughly before the pressure peaked.", "I had been studying for hours when pressure peaked.", "The situation unfolded gradually over the semester."]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 7, 'Build Sentences 1', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'The academic pressure peaked during finals.', 'The academic pressure peaked during finals.', '["The", "academic", "pressure", "peaked", "during", "finals."]'::jsonb),
    (activity_id_var, 'I was studying when the pressure became overwhelming.', 'I was studying when the pressure became overwhelming.', '["I", "was", "studying", "when", "the", "pressure", "became", "overwhelming."]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 8, 'Build Sentences 2', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'I had prepared thoroughly before the pressure peaked.', 'I had prepared thoroughly before the pressure peaked.', '["I", "had", "prepared", "thoroughly", "before", "the", "pressure", "peaked."]'::jsonb),
    (activity_id_var, 'The situation unfolded gradually over the semester.', 'The situation unfolded gradually over the semester.', '["The", "situation", "unfolded", "gradually", "over", "the", "semester."]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'speaking_practice', 9, 'Discuss Academic Pressure', 'Practice speaking about academic pressure', '{"prompts": ["Describe a time when academic pressure peaked.", "How did the situation unfold?", "What creates pressure in academic environments?", "How does achievement culture affect students?", "What strategies help you manage pressure?"]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (
      lesson_id,
      activity_type,
      activity_order,
      title,
      description,
      content
    ) VALUES (
      'C1-L9',
      'speaking_improvement',
      10,
      'Speaking Improvement',
      'Read the improved version of your speech',
      '{"type": "speaking_improvement", "similarityThreshold": 70}'::jsonb
    );
END $$;



-- =========================================
-- C1 Lesson 10
-- =========================================

-- =========================================
-- Pre-fill Database with Sample Lesson Data
-- C1-L10: Value of Failure in Learning
-- =========================================

DELETE FROM grammar_sentences WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'C1-L10');
DELETE FROM vocabulary_items WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'C1-L10');
DELETE FROM lesson_activities WHERE lesson_id = 'C1-L10';
DELETE FROM lessons WHERE id = 'C1-L10';

INSERT INTO lessons (id, level, lesson_number, topic) VALUES
('C1-L10', 'C1', 10, 'Value of Failure in Learning')
ON CONFLICT (id) DO UPDATE SET topic = EXCLUDED.topic;

DO $$
DECLARE
    lesson_id_var TEXT := 'C1-L10';
    activity_id_var UUID;
BEGIN
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'warm_up_speaking', 1, 'Failure in Learning', 'Discuss the value of failure', '{"prompt": "If you had not failed at a key moment, what might you have missed?"}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_intro', 2, 'Failure Vocabulary', 'Learn vocabulary about failure and learning', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'failure', 'ความล้มเหลว', NULL),
    (activity_id_var, 'setback', 'ความล้มเหลว', NULL),
    (activity_id_var, 'resilience', 'ความยืดหยุ่น', NULL),
    (activity_id_var, 'reflection', 'การสะท้อน', NULL),
    (activity_id_var, 'growth', 'การเติบโต', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_matching_drag', 3, 'Match Failure Words', 'Match English words with Thai meanings', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'failure', 'ความล้มเหลว', NULL),
    (activity_id_var, 'setback', 'ความล้มเหลว', NULL),
    (activity_id_var, 'resilience', 'ความยืดหยุ่น', NULL),
    (activity_id_var, 'reflection', 'การสะท้อน', NULL),
    (activity_id_var, 'growth', 'การเติบโต', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 4, 'Complete the Sentences 1', 'Fill with the correct word', '{"text": "Learning from ___ builds ___. ___ on ___ promotes ___.", "blanks": [{"id": "blank1", "text": "failure", "options": ["failure", "setback", "resilience", "reflection"], "correctAnswer": "failure"}, {"id": "blank2", "text": "resilience", "options": ["resilience", "failure", "setback", "growth"], "correctAnswer": "resilience"}, {"id": "blank3", "text": "Reflection", "options": ["Reflection", "Failure", "Setback", "Resilience"], "correctAnswer": "Reflection"}, {"id": "blank4", "text": "setbacks", "options": ["setbacks", "failures", "resilience", "reflection"], "correctAnswer": "setbacks"}, {"id": "blank5", "text": "growth", "options": ["growth", "failure", "resilience", "reflection"], "correctAnswer": "growth"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 5, 'Complete the Sentences 2', 'Fill with the correct word', '{"text": "Each ___ teaches valuable lessons. ___ helps overcome ___.", "blanks": [{"id": "blank1", "text": "setback", "options": ["setback", "failure", "resilience", "reflection"], "correctAnswer": "setback"}, {"id": "blank2", "text": "Resilience", "options": ["Resilience", "Failure", "Setback", "Reflection"], "correctAnswer": "Resilience"}, {"id": "blank3", "text": "failure", "options": ["failure", "setback", "resilience", "reflection"], "correctAnswer": "failure"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_explanation', 6, 'Mixed Conditionals', 'Learn mixed conditional structures', '{"rules": "Mixed conditionals combine different time references:\n- Mixed 2/3: \"If I had not failed (past), I would be different now (present).\"\n- Mixed 3/2: \"If I had failed (past), I would not understand now (present).\"\n\nStructures:\n- If + past perfect, would + base form (past condition, present result)\n- If + past simple, would have + past participle (present condition, past result)\n\nUse for:\n- Hypothetical past affecting present: \"If I had not failed, I would be overconfident now.\"\n- Unreal present affecting past: \"If I were better, I would have succeeded.\"", "examples": ["If I had not failed, I would have missed important lessons.", "If I had not failed, I would be overconfident now.", "If I were more careful, I would not have failed.", "If I had failed earlier, I would understand better now.", "If I had not experienced failure, I would not have grown."]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 7, 'Build Sentences 1', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'If I had not failed, I would have missed important lessons.', 'If I had not failed, I would have missed important lessons.', '["If", "I", "had", "not", "failed,", "I", "would", "have", "missed", "important", "lessons."]'::jsonb),
    (activity_id_var, 'If I had not failed, I would be overconfident now.', 'If I had not failed, I would be overconfident now.', '["If", "I", "had", "not", "failed,", "I", "would", "be", "overconfident", "now."]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 8, 'Build Sentences 2', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'If I had failed earlier, I would understand better now.', 'If I had failed earlier, I would understand better now.', '["If", "I", "had", "failed", "earlier,", "I", "would", "understand", "better", "now."]'::jsonb),
    (activity_id_var, 'If I had not experienced failure, I would not have grown.', 'If I had not experienced failure, I would not have grown.', '["If", "I", "had", "not", "experienced", "failure,", "I", "would", "not", "have", "grown."]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'speaking_practice', 9, 'Discuss Failure in Learning', 'Practice speaking about failure and learning', '{"prompts": ["If you had not failed, what would you have missed?", "How has failure contributed to your learning?", "What lessons have you learned from failure?", "How can failure be reframed as opportunity?", "What role should failure play in education?"]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (
      lesson_id,
      activity_type,
      activity_order,
      title,
      description,
      content
    ) VALUES (
      'C1-L10',
      'speaking_improvement',
      10,
      'Speaking Improvement',
      'Read the improved version of your speech',
      '{"type": "speaking_improvement", "similarityThreshold": 70}'::jsonb
    );
END $$;



-- =========================================
-- C1 Lesson 11
-- =========================================

-- =========================================
-- Pre-fill Database with Sample Lesson Data
-- C1-L11: Ethics in Education
-- =========================================

DELETE FROM grammar_sentences WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'C1-L11');
DELETE FROM vocabulary_items WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'C1-L11');
DELETE FROM lesson_activities WHERE lesson_id = 'C1-L11';
DELETE FROM lessons WHERE id = 'C1-L11';

INSERT INTO lessons (id, level, lesson_number, topic) VALUES
('C1-L11', 'C1', 11, 'Ethics in Education')
ON CONFLICT (id) DO UPDATE SET topic = EXCLUDED.topic;

DO $$
DECLARE
    lesson_id_var TEXT := 'C1-L11';
    activity_id_var UUID;
BEGIN
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'warm_up_speaking', 1, 'Ethics Discussion', 'Discuss ethics in education', '{"prompt": "When should rules be flexible in education?"}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_intro', 2, 'Ethics Vocabulary', 'Learn vocabulary about ethics', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'integrity', 'ความซื่อสัตย์', NULL),
    (activity_id_var, 'principle', 'หลักการ', NULL),
    (activity_id_var, 'dilemma', 'สถานการณ์ที่ยากลำบาก', NULL),
    (activity_id_var, 'accountability', 'ความรับผิดชอบ', NULL),
    (activity_id_var, 'transparency', 'ความโปร่งใส', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_matching_drag', 3, 'Match Ethics Words', 'Match English words with Thai meanings', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'integrity', 'ความซื่อสัตย์', NULL),
    (activity_id_var, 'principle', 'หลักการ', NULL),
    (activity_id_var, 'dilemma', 'สถานการณ์ที่ยากลำบาก', NULL),
    (activity_id_var, 'accountability', 'ความรับผิดชอบ', NULL),
    (activity_id_var, 'transparency', 'ความโปร่งใส', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 4, 'Complete the Sentences 1', 'Fill with the correct word', '{"text": "Academic ___ requires honesty in all work. Students must follow ethical ___.", "blanks": [{"id": "blank1", "text": "integrity", "options": ["integrity", "principle", "dilemma", "accountability"], "correctAnswer": "integrity"}, {"id": "blank2", "text": "principles", "options": ["principles", "transparency", "dilemma", "integrity"], "correctAnswer": "principles"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 5, 'Complete the Sentences 2', 'Fill with the correct word', '{"text": "Teachers face an ethical ___ when grading. ___ is essential for trust.", "blanks": [{"id": "blank1", "text": "dilemma", "options": ["dilemma", "principle", "integrity", "transparency"], "correctAnswer": "dilemma"}, {"id": "blank2", "text": "Transparency", "options": ["Transparency", "Accountability", "Integrity", "Dilemma"], "correctAnswer": "Transparency"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_explanation', 6, 'Articles: Abstract and Stylistic Use', 'Learn about articles with abstract concepts', '{"rules": "Articles with abstract nouns:\n- Use \"the\" when referring to a specific abstract concept: \"the ethics of education\"\n- Omit article for general abstract concepts: \"ethics is important\"\n- Use \"a/an\" when classifying: \"an ethical dilemma\"\n\nStylistic use:\n- \"The\" can emphasize importance: \"the principle of fairness\"\n- Zero article for broad concepts: \"education requires integrity\"", "examples": ["The ethics of academic work are complex.", "Ethics is a fundamental concern.", "A dilemma arose during the exam.", "The principle of fairness must be upheld.", "Education requires integrity from all parties."]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 7, 'Build Sentences 1', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'The ethics of education require careful consideration.', 'The ethics of education require careful consideration.', '["The", "ethics", "of", "education", "require", "careful", "consideration."]'::jsonb),
    (activity_id_var, 'A dilemma often arises when principles conflict.', 'A dilemma often arises when principles conflict.', '["A", "dilemma", "often", "arises", "when", "principles", "conflict."]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 8, 'Build Sentences 2', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'Transparency builds trust in academic institutions.', 'Transparency builds trust in academic institutions.', '["Transparency", "builds", "trust", "in", "academic", "institutions."]'::jsonb),
    (activity_id_var, 'The principle of accountability must be maintained.', 'The principle of accountability must be maintained.', '["The", "principle", "of", "accountability", "must", "be", "maintained."]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'speaking_practice', 9, 'Discuss Ethics', 'Practice speaking about ethics', '{"prompts": ["Is ethics fixed or changeable in your view?", "When, if ever, is it acceptable to bend rules?", "How do you define academic integrity?", "What ethical dilemmas can students face at school?", "Why is transparency important in education?"]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (
      lesson_id,
      activity_type,
      activity_order,
      title,
      description,
      content
    ) VALUES (
      'C1-L11',
      'speaking_improvement',
      10,
      'Speaking Improvement',
      'Read the improved version of your speech',
      '{"type": "speaking_improvement", "similarityThreshold": 70}'::jsonb
    );
END $$;



-- =========================================
-- C1 Lesson 12
-- =========================================

-- =========================================
-- Pre-fill Database with Sample Lesson Data
-- C1-L12: Plagiarism & Academic Integrity
-- =========================================

DELETE FROM grammar_sentences WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'C1-L12');
DELETE FROM vocabulary_items WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'C1-L12');
DELETE FROM lesson_activities WHERE lesson_id = 'C1-L12';
DELETE FROM lessons WHERE id = 'C1-L12';

INSERT INTO lessons (id, level, lesson_number, topic) VALUES
('C1-L12', 'C1', 12, 'Plagiarism & Academic Integrity')
ON CONFLICT (id) DO UPDATE SET topic = EXCLUDED.topic;

DO $$
DECLARE
    lesson_id_var TEXT := 'C1-L12';
    activity_id_var UUID;
BEGIN
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'warm_up_speaking', 1, 'Academic Integrity', 'Discuss academic integrity', '{"prompt": "How should plagiarism be handled in schools?"}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_intro', 2, 'Academic Integrity Vocabulary', 'Learn vocabulary about plagiarism and integrity', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'plagiarism', 'การลอกเลียน', NULL),
    (activity_id_var, 'citation', 'การอ้างอิง', NULL),
    (activity_id_var, 'attribution', 'การให้เครดิต', NULL),
    (activity_id_var, 'sanction', 'การลงโทษ', NULL),
    (activity_id_var, 'violation', 'การละเมิด', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_matching_drag', 3, 'Match Academic Integrity Words', 'Match English words with Thai meanings', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'plagiarism', 'การลอกเลียน', NULL),
    (activity_id_var, 'citation', 'การอ้างอิง', NULL),
    (activity_id_var, 'attribution', 'การให้เครดิต', NULL),
    (activity_id_var, 'sanction', 'การลงโทษ', NULL),
    (activity_id_var, 'violation', 'การละเมิด', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 4, 'Complete the Sentences 1', 'Fill with the correct word', '{"text": "___ is a serious academic ___. Proper ___ is required for all sources.", "blanks": [{"id": "blank1", "text": "Plagiarism", "options": ["Plagiarism", "Citation", "Attribution", "Sanction"], "correctAnswer": "Plagiarism"}, {"id": "blank2", "text": "violation", "options": ["violation", "citation", "attribution", "sanction"], "correctAnswer": "violation"}, {"id": "blank3", "text": "citation", "options": ["citation", "plagiarism", "attribution", "sanction"], "correctAnswer": "citation"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 5, 'Complete the Sentences 2', 'Fill with the correct word', '{"text": "Correct ___ gives credit to original authors. Academic ___ may include suspension.", "blanks": [{"id": "blank1", "text": "attribution", "options": ["attribution", "citation", "plagiarism", "violation"], "correctAnswer": "attribution"}, {"id": "blank2", "text": "sanctions", "options": ["sanctions", "violations", "citations", "attributions"], "correctAnswer": "sanctions"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_explanation', 6, 'Advanced Passives: Reporting Structures', 'Learn advanced passive forms in reporting', '{"rules": "Advanced passive reporting structures:\n- \"It is said/reported/believed that...\" (impersonal)\n- \"X is said/reported/believed to...\" (personal)\n- \"X should be enforced/held accountable\" (obligation)\n- \"X must be maintained/upheld\" (necessity)\n\nUse when the focus is on the action, not the doer:\n- \"Integrity should be enforced by institutions.\"\n- \"It is believed that sanctions deter violations.\"", "examples": ["It is reported that plagiarism cases have increased.", "Students are expected to maintain academic integrity.", "Sanctions should be enforced fairly.", "It is believed that proper citation prevents violations.", "Academic standards must be upheld by all."]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 7, 'Build Sentences 1', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'It is reported that plagiarism has increased significantly.', 'It is reported that plagiarism has increased significantly.', '["It", "is", "reported", "that", "plagiarism", "has", "increased", "significantly."]'::jsonb),
    (activity_id_var, 'Academic integrity should be enforced by all institutions.', 'Academic integrity should be enforced by all institutions.', '["Academic", "integrity", "should", "be", "enforced", "by", "all", "institutions."]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 8, 'Build Sentences 2', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'Students are expected to provide proper attribution.', 'Students are expected to provide proper attribution.', '["Students", "are", "expected", "to", "provide", "proper", "attribution."]'::jsonb),
    (activity_id_var, 'It is believed that sanctions deter future violations.', 'It is believed that sanctions deter future violations.', '["It", "is", "believed", "that", "sanctions", "deter", "future", "violations."]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'speaking_practice', 9, 'Discuss Academic Integrity', 'Practice speaking about plagiarism and integrity', '{"prompts": ["What actions are considered plagiarism?", "Why is plagiarism taken seriously?", "How can students avoid academic dishonesty?", "When is punishment fair or unfair?", "What consequences are appropriate for violations?"]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (
      lesson_id,
      activity_type,
      activity_order,
      title,
      description,
      content
    ) VALUES (
      'C1-L12',
      'speaking_improvement',
      10,
      'Speaking Improvement',
      'Read the improved version of your speech',
      '{"type": "speaking_improvement", "similarityThreshold": 70}'::jsonb
    );
END $$;



-- =========================================
-- C1 Lesson 13
-- =========================================

-- =========================================
-- Pre-fill Database with Sample Lesson Data
-- C1-L13: AI Use in Academic Work
-- =========================================

DELETE FROM grammar_sentences WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'C1-L13');
DELETE FROM vocabulary_items WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'C1-L13');
DELETE FROM lesson_activities WHERE lesson_id = 'C1-L13';
DELETE FROM lessons WHERE id = 'C1-L13';

INSERT INTO lessons (id, level, lesson_number, topic) VALUES
('C1-L13', 'C1', 13, 'AI Use in Academic Work')
ON CONFLICT (id) DO UPDATE SET topic = EXCLUDED.topic;

DO $$
DECLARE
    lesson_id_var TEXT := 'C1-L13';
    activity_id_var UUID;
BEGIN
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'warm_up_speaking', 1, 'AI in Academia', 'Discuss AI use in academic work', '{"prompt": "How has AI affected the way you study?"}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_intro', 2, 'AI Vocabulary', 'Learn vocabulary about AI in academia', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'automation', 'การทำงานอัตโนมัติ', NULL),
    (activity_id_var, 'algorithm', 'อัลกอริทึม', NULL),
    (activity_id_var, 'bias', 'อคติ', NULL),
    (activity_id_var, 'reliance', 'การพึ่งพา', NULL),
    (activity_id_var, 'enhancement', 'การปรับปรุง', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_matching_drag', 3, 'Match AI Words', 'Match English words with Thai meanings', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'automation', 'การทำงานอัตโนมัติ', NULL),
    (activity_id_var, 'algorithm', 'อัลกอริทึม', NULL),
    (activity_id_var, 'bias', 'อคติ', NULL),
    (activity_id_var, 'reliance', 'การพึ่งพา', NULL),
    (activity_id_var, 'enhancement', 'การปรับปรุง', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 4, 'Complete the Sentences 1', 'Fill with the correct word', '{"text": "Academic ___ may improve efficiency. However, ___ on AI raises concerns.", "blanks": [{"id": "blank1", "text": "automation", "options": ["automation", "algorithm", "bias", "reliance"], "correctAnswer": "automation"}, {"id": "blank2", "text": "reliance", "options": ["reliance", "automation", "algorithm", "bias"], "correctAnswer": "reliance"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 5, 'Complete the Sentences 2', 'Fill with the correct word', '{"text": "The ___ may contain hidden ___. AI ___ can improve learning outcomes.", "blanks": [{"id": "blank1", "text": "algorithm", "options": ["algorithm", "automation", "bias", "reliance"], "correctAnswer": "algorithm"}, {"id": "blank2", "text": "bias", "options": ["bias", "reliance", "automation", "enhancement"], "correctAnswer": "bias"}, {"id": "blank3", "text": "enhancement", "options": ["enhancement", "automation", "algorithm", "bias"], "correctAnswer": "enhancement"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_explanation', 6, 'Modals: Speculation and Criticism in the Past', 'Learn modals for past speculation and criticism', '{"rules": "Past speculation and criticism:\n- \"might/could have + past participle\" (possibility in past)\n- \"should have + past participle\" (criticism/regret)\n- \"must have + past participle\" (strong probability)\n- \"may have + past participle\" (uncertainty)\n\nUse for:\n- Speculating about past events: \"AI might have helped you\"\n- Criticizing past actions: \"You should have cited the source\"\n- Expressing regret: \"I could have used AI better\"", "examples": ["AI might have improved your research efficiency.", "Students should have been taught about AI ethics.", "The algorithm must have processed thousands of papers.", "You may have overlooked potential bias.", "They could have used AI more effectively."]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 7, 'Build Sentences 1', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'AI might have helped you complete the assignment faster.', 'AI might have helped you complete the assignment faster.', '["AI", "might", "have", "helped", "you", "complete", "the", "assignment", "faster."]'::jsonb),
    (activity_id_var, 'You should have disclosed your use of AI tools.', 'You should have disclosed your use of AI tools.', '["You", "should", "have", "disclosed", "your", "use", "of", "AI", "tools."]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 8, 'Build Sentences 2', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'The system must have processed millions of documents.', 'The system must have processed millions of documents.', '["The", "system", "must", "have", "processed", "millions", "of", "documents."]'::jsonb),
    (activity_id_var, 'They could have avoided bias by reviewing the algorithm.', 'They could have avoided bias by reviewing the algorithm.', '["They", "could", "have", "avoided", "bias", "by", "reviewing", "the", "algorithm."]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'speaking_practice', 9, 'Discuss AI in Academia', 'Practice speaking about AI use', '{"prompts": ["How might AI have helped your learning?", "How might it have caused problems?", "Should AI be allowed in assignments?", "What ethical concerns does AI raise?", "How can AI be used responsibly in education?"]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (
      lesson_id,
      activity_type,
      activity_order,
      title,
      description,
      content
    ) VALUES (
      'C1-L13',
      'speaking_improvement',
      10,
      'Speaking Improvement',
      'Read the improved version of your speech',
      '{"type": "speaking_improvement", "similarityThreshold": 70}'::jsonb
    );
END $$;



-- =========================================
-- C1 Lesson 14
-- =========================================

-- =========================================
-- Pre-fill Database with Sample Lesson Data
-- C1-L14: Future of Assessment
-- =========================================

DELETE FROM grammar_sentences WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'C1-L14');
DELETE FROM vocabulary_items WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'C1-L14');
DELETE FROM lesson_activities WHERE lesson_id = 'C1-L14';
DELETE FROM lessons WHERE id = 'C1-L14';

INSERT INTO lessons (id, level, lesson_number, topic) VALUES
('C1-L14', 'C1', 14, 'Future of Assessment')
ON CONFLICT (id) DO UPDATE SET topic = EXCLUDED.topic;

DO $$
DECLARE
    lesson_id_var TEXT := 'C1-L14';
    activity_id_var UUID;
BEGIN
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'warm_up_speaking', 1, 'Assessment Future', 'Discuss the future of assessment', '{"prompt": "What should assessment really measure?"}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_intro', 2, 'Assessment Vocabulary', 'Learn vocabulary about assessment', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'evaluation', 'การประเมิน', NULL),
    (activity_id_var, 'criterion', 'เกณฑ์', NULL),
    (activity_id_var, 'authentic', 'แท้จริง', NULL),
    (activity_id_var, 'portfolio', 'ผลงานสะสม', NULL),
    (activity_id_var, 'rubric', 'เกณฑ์การให้คะแนน', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_matching_drag', 3, 'Match Assessment Words', 'Match English words with Thai meanings', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'evaluation', 'การประเมิน', NULL),
    (activity_id_var, 'criterion', 'เกณฑ์', NULL),
    (activity_id_var, 'authentic', 'แท้จริง', NULL),
    (activity_id_var, 'portfolio', 'ผลงานสะสม', NULL),
    (activity_id_var, 'rubric', 'เกณฑ์การให้คะแนน', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 4, 'Complete the Sentences 1', 'Fill with the correct word', '{"text": "Modern ___ requires clear ___. A ___ helps standardize grading.", "blanks": [{"id": "blank1", "text": "evaluation", "options": ["evaluation", "criterion", "authentic", "rubric"], "correctAnswer": "evaluation"}, {"id": "blank2", "text": "criteria", "options": ["criteria", "evaluation", "portfolio", "rubric"], "correctAnswer": "criteria"}, {"id": "blank3", "text": "rubric", "options": ["rubric", "evaluation", "criterion", "portfolio"], "correctAnswer": "rubric"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 5, 'Complete the Sentences 2', 'Fill with the correct word', '{"text": "A ___ assessment measures real skills. Students compile work in a ___.", "blanks": [{"id": "blank1", "text": "authentic", "options": ["authentic", "evaluation", "criterion", "rubric"], "correctAnswer": "authentic"}, {"id": "blank2", "text": "portfolio", "options": ["portfolio", "evaluation", "criterion", "rubric"], "correctAnswer": "portfolio"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_explanation', 6, 'Nominal Clauses', 'Learn about nominal clauses', '{"rules": "Nominal clauses function as nouns:\n- Subject: \"What assessment proves matters.\"\n- Object: \"I think that assessment should change.\"\n- Complement: \"The question is who decides.\"\n\nTypes:\n- That-clauses: \"I believe that evaluation needs reform.\"\n- Wh-clauses: \"What you think determines your approach.\"\n- Whether/if: \"The issue is whether portfolios work.\"\n\nUse for:\n- Expressing opinions: \"What I think is that...\"\n- Asking questions: \"Who decides the criteria?\"\n- Making statements: \"That assessment matters is clear.\"", "examples": ["What assessment should prove is a key question.", "I think that evaluation methods need updating.", "The question is who decides the criteria.", "Whether portfolios are effective remains debated.", "That authentic assessment matters is widely accepted."]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 7, 'Build Sentences 1', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'What assessment should prove is a complex question.', 'What assessment should prove is a complex question.', '["What", "assessment", "should", "prove", "is", "a", "complex", "question."]'::jsonb),
    (activity_id_var, 'I think that evaluation methods need reform.', 'I think that evaluation methods need reform.', '["I", "think", "that", "evaluation", "methods", "need", "reform."]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 8, 'Build Sentences 2', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'The question is who decides the criteria.', 'The question is who decides the criteria.', '["The", "question", "is", "who", "decides", "the", "criteria."]'::jsonb),
    (activity_id_var, 'Whether portfolios are effective remains uncertain.', 'Whether portfolios are effective remains uncertain.', '["Whether", "portfolios", "are", "effective", "remains", "uncertain."]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'speaking_practice', 9, 'Discuss Assessment', 'Practice speaking about assessment', '{"prompts": ["What do you think assessment should prove?", "Who should decide how students are evaluated?", "Are exams still effective today?", "Are portfolios a better alternative?", "What makes assessment fair and meaningful?"]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (
      lesson_id,
      activity_type,
      activity_order,
      title,
      description,
      content
    ) VALUES (
      'C1-L14',
      'speaking_improvement',
      10,
      'Speaking Improvement',
      'Read the improved version of your speech',
      '{"type": "speaking_improvement", "similarityThreshold": 70}'::jsonb
    );
END $$;



-- =========================================
-- C1 Lesson 15
-- =========================================

-- =========================================
-- Pre-fill Database with Sample Lesson Data
-- C1-L15: Fairness in Grading Systems
-- =========================================

DELETE FROM grammar_sentences WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'C1-L15');
DELETE FROM vocabulary_items WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'C1-L15');
DELETE FROM lesson_activities WHERE lesson_id = 'C1-L15';
DELETE FROM lessons WHERE id = 'C1-L15';

INSERT INTO lessons (id, level, lesson_number, topic) VALUES
('C1-L15', 'C1', 15, 'Fairness in Grading Systems')
ON CONFLICT (id) DO UPDATE SET topic = EXCLUDED.topic;

DO $$
DECLARE
    lesson_id_var TEXT := 'C1-L15';
    activity_id_var UUID;
BEGIN
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'warm_up_speaking', 1, 'Grading Fairness', 'Discuss fairness in grading', '{"prompt": "What makes grading fair in your opinion?"}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_intro', 2, 'Grading Vocabulary', 'Learn vocabulary about grading systems', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'fairness', 'ความยุติธรรม', NULL),
    (activity_id_var, 'objectivity', 'ความเป็นกลาง', NULL),
    (activity_id_var, 'consistency', 'ความสม่ำเสมอ', NULL),
    (activity_id_var, 'discrepancy', 'ความแตกต่าง', NULL),
    (activity_id_var, 'appeal', 'การอุทธรณ์', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_matching_drag', 3, 'Match Grading Words', 'Match English words with Thai meanings', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'fairness', 'ความยุติธรรม', NULL),
    (activity_id_var, 'objectivity', 'ความเป็นกลาง', NULL),
    (activity_id_var, 'consistency', 'ความสม่ำเสมอ', NULL),
    (activity_id_var, 'discrepancy', 'ความแตกต่าง', NULL),
    (activity_id_var, 'appeal', 'การอุทธรณ์', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 4, 'Complete the Sentences 1', 'Fill with the correct word', '{"text": "Grading requires ___ and ___. Students can ___ unfair grades.", "blanks": [{"id": "blank1", "text": "fairness", "options": ["fairness", "objectivity", "consistency", "discrepancy"], "correctAnswer": "fairness"}, {"id": "blank2", "text": "objectivity", "options": ["objectivity", "fairness", "consistency", "appeal"], "correctAnswer": "objectivity"}, {"id": "blank3", "text": "appeal", "options": ["appeal", "fairness", "objectivity", "discrepancy"], "correctAnswer": "appeal"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 5, 'Complete the Sentences 2', 'Fill with the correct word', '{"text": "___ in grading standards creates problems. A ___ between grades raises questions.", "blanks": [{"id": "blank1", "text": "Inconsistency", "options": ["Inconsistency", "Fairness", "Objectivity", "Appeal"], "correctAnswer": "Inconsistency"}, {"id": "blank2", "text": "discrepancy", "options": ["discrepancy", "fairness", "objectivity", "consistency"], "correctAnswer": "discrepancy"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_explanation', 6, 'Cleft Sentences and Emphatic Structures', 'Learn cleft sentences for emphasis', '{"rules": "Cleft sentences emphasize specific elements:\n- It-cleft: \"It is fairness that matters most.\"\n- What-cleft: \"What makes grading fair is consistency.\"\n- Wh-cleft: \"What I value is objectivity.\"\n\nStructure:\n- It + be + emphasized element + that/who clause\n- What + verb + be + emphasized element\n\nUse for:\n- Emphasizing importance: \"It is consistency that ensures fairness.\"\n- Highlighting focus: \"What matters is objectivity.\"\n- Clarifying meaning: \"What makes it fair is the rubric.\"", "examples": ["It is fairness that students value most.", "What makes grading fair is consistency.", "What I contest is the discrepancy.", "It is objectivity that ensures trust.", "What matters is the appeal process."]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 7, 'Build Sentences 1', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'It is fairness that makes grading systems trustworthy.', 'It is fairness that makes grading systems trustworthy.', '["It", "is", "fairness", "that", "makes", "grading", "systems", "trustworthy."]'::jsonb),
    (activity_id_var, 'What makes grading fair is consistent application of criteria.', 'What makes grading fair is consistent application of criteria.', '["What", "makes", "grading", "fair", "is", "consistent", "application", "of", "criteria."]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 8, 'Build Sentences 2', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'What I contest is the discrepancy between grades.', 'What I contest is the discrepancy between grades.', '["What", "I", "contest", "is", "the", "discrepancy", "between", "grades."]'::jsonb),
    (activity_id_var, 'It is objectivity that students expect from evaluators.', 'It is objectivity that students expect from evaluators.', '["It", "is", "objectivity", "that", "students", "expect", "from", "evaluators."]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'speaking_practice', 9, 'Discuss Grading Fairness', 'Practice speaking about grading systems', '{"prompts": ["What makes a grading system fair?", "When do students question grades?", "How important is objectivity in grading?", "What causes inconsistencies in grading?", "How can grading systems be improved?"]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (
      lesson_id,
      activity_type,
      activity_order,
      title,
      description,
      content
    ) VALUES (
      'C1-L15',
      'speaking_improvement',
      10,
      'Speaking Improvement',
      'Read the improved version of your speech',
      '{"type": "speaking_improvement", "similarityThreshold": 70}'::jsonb
    );
END $$;



-- =========================================
-- C1 Lesson 16
-- =========================================

-- =========================================
-- Pre-fill Database with Sample Lesson Data
-- C1-L16: Standardized Testing: Benefits/Drawbacks
-- =========================================

DELETE FROM grammar_sentences WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'C1-L16');
DELETE FROM vocabulary_items WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'C1-L16');
DELETE FROM lesson_activities WHERE lesson_id = 'C1-L16';
DELETE FROM lessons WHERE id = 'C1-L16';

INSERT INTO lessons (id, level, lesson_number, topic) VALUES
('C1-L16', 'C1', 16, 'Standardized Testing: Benefits/Drawbacks')
ON CONFLICT (id) DO UPDATE SET topic = EXCLUDED.topic;

DO $$
DECLARE
    lesson_id_var TEXT := 'C1-L16';
    activity_id_var UUID;
BEGIN
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'warm_up_speaking', 1, 'Standardized Tests', 'Discuss standardized testing', '{"prompt": "How have standardized tests affected you?"}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_intro', 2, 'Testing Vocabulary', 'Learn vocabulary about standardized testing', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'standardized', 'มาตรฐาน', NULL),
    (activity_id_var, 'validity', 'ความถูกต้อง', NULL),
    (activity_id_var, 'reliability', 'ความน่าเชื่อถือ', NULL),
    (activity_id_var, 'limitation', 'ข้อจำกัด', NULL),
    (activity_id_var, 'equity', 'ความเท่าเทียม', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_matching_drag', 3, 'Match Testing Words', 'Match English words with Thai meanings', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'standardized', 'มาตรฐาน', NULL),
    (activity_id_var, 'validity', 'ความถูกต้อง', NULL),
    (activity_id_var, 'reliability', 'ความน่าเชื่อถือ', NULL),
    (activity_id_var, 'limitation', 'ข้อจำกัด', NULL),
    (activity_id_var, 'equity', 'ความเท่าเทียม', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 4, 'Complete the Sentences 1', 'Fill with the correct word', '{"text": "___ tests have both benefits and ___. Test ___ is crucial for fairness.", "blanks": [{"id": "blank1", "text": "Standardized", "options": ["Standardized", "Validity", "Reliability", "Equity"], "correctAnswer": "Standardized"}, {"id": "blank2", "text": "limitations", "options": ["limitations", "validity", "reliability", "equity"], "correctAnswer": "limitations"}, {"id": "blank3", "text": "validity", "options": ["validity", "reliability", "limitation", "equity"], "correctAnswer": "validity"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 5, 'Complete the Sentences 2', 'Fill with the correct word', '{"text": "Test ___ ensures consistent results. ___ in testing remains a challenge.", "blanks": [{"id": "blank1", "text": "reliability", "options": ["reliability", "validity", "limitation", "equity"], "correctAnswer": "reliability"}, {"id": "blank2", "text": "Equity", "options": ["Equity", "Validity", "Reliability", "Limitation"], "correctAnswer": "Equity"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_explanation', 6, 'Contrast Linking at C1 Level', 'Learn advanced contrast linking', '{"rules": "C1 contrast linking shows nuanced relationships:\n- \"While/Whereas\" (formal contrast): \"While tests measure knowledge, they may miss skills.\"\n- \"However/Nevertheless\" (concession): \"Tests are useful; however, they have limitations.\"\n- \"On the one hand... on the other hand\" (balanced contrast)\n- \"Despite/In spite of\" (contrary expectation): \"Despite benefits, tests have drawbacks.\"\n\nUse for:\n- Presenting balanced views: \"On one hand, tests are fair; on the other, they limit creativity.\"\n- Acknowledging complexity: \"While standardized tests help, they also create stress.\"\n- Showing contradiction: \"Tests measure ability; however, they may not reflect potential.\"", "examples": ["While standardized tests provide consistency, they may limit creativity.", "Tests measure knowledge; however, they may not assess skills.", "On the one hand, tests ensure fairness; on the other, they create pressure.", "Despite their benefits, standardized tests have significant limitations.", "Whereas validity is important, equity remains a concern."]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 7, 'Build Sentences 1', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'While standardized tests ensure consistency, they may limit creativity.', 'While standardized tests ensure consistency, they may limit creativity.', '["While", "standardized", "tests", "ensure", "consistency,", "they", "may", "limit", "creativity."]'::jsonb),
    (activity_id_var, 'Tests measure knowledge; however, they may not assess skills.', 'Tests measure knowledge; however, they may not assess skills.', '["Tests", "measure", "knowledge;", "however,", "they", "may", "not", "assess", "skills."]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 8, 'Build Sentences 2', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'On the one hand, tests provide validity; on the other, they lack equity.', 'On the one hand, tests provide validity; on the other, they lack equity.', '["On", "the", "one", "hand,", "tests", "provide", "validity;", "on", "the", "other,", "they", "lack", "equity."]'::jsonb),
    (activity_id_var, 'Despite their reliability, standardized tests have limitations.', 'Despite their reliability, standardized tests have limitations.', '["Despite", "their", "reliability,", "standardized", "tests", "have", "limitations."]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'speaking_practice', 9, 'Discuss Standardized Testing', 'Practice speaking about testing', '{"prompts": ["How have tests helped your learning?", "Where have they caused stress or problems?", "What are the benefits of standardized testing?", "What are the main drawbacks?", "How can testing be made more equitable?"]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (
      lesson_id,
      activity_type,
      activity_order,
      title,
      description,
      content
    ) VALUES (
      'C1-L16',
      'speaking_improvement',
      10,
      'Speaking Improvement',
      'Read the improved version of your speech',
      '{"type": "speaking_improvement", "similarityThreshold": 70}'::jsonb
    );
END $$;



-- =========================================
-- C1 Lesson 17
-- =========================================

-- =========================================
-- Pre-fill Database with Sample Lesson Data
-- C1-L17: Digital Surveillance in Education
-- =========================================

DELETE FROM grammar_sentences WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'C1-L17');
DELETE FROM vocabulary_items WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'C1-L17');
DELETE FROM lesson_activities WHERE lesson_id = 'C1-L17';
DELETE FROM lessons WHERE id = 'C1-L17';

INSERT INTO lessons (id, level, lesson_number, topic) VALUES
('C1-L17', 'C1', 17, 'Digital Surveillance in Education')
ON CONFLICT (id) DO UPDATE SET topic = EXCLUDED.topic;

DO $$
DECLARE
    lesson_id_var TEXT := 'C1-L17';
    activity_id_var UUID;
BEGIN
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'warm_up_speaking', 1, 'Digital Surveillance', 'Discuss digital surveillance in education', '{"prompt": "How much student data should schools collect?"}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_intro', 2, 'Surveillance Vocabulary', 'Learn vocabulary about digital surveillance', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'surveillance', 'การเฝ้าระวัง', NULL),
    (activity_id_var, 'monitoring', 'การติดตาม', NULL),
    (activity_id_var, 'privacy', 'ความเป็นส่วนตัว', NULL),
    (activity_id_var, 'consent', 'ความยินยอม', NULL),
    (activity_id_var, 'intrusion', 'การบุกรุก', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_matching_drag', 3, 'Match Surveillance Words', 'Match English words with Thai meanings', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'surveillance', 'การเฝ้าระวัง', NULL),
    (activity_id_var, 'monitoring', 'การติดตาม', NULL),
    (activity_id_var, 'privacy', 'ความเป็นส่วนตัว', NULL),
    (activity_id_var, 'consent', 'ความยินยอม', NULL),
    (activity_id_var, 'intrusion', 'การบุกรุก', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 4, 'Complete the Sentences 1', 'Fill with the correct word', '{"text": "Digital ___ raises ___ concerns. Student ___ must be protected.", "blanks": [{"id": "blank1", "text": "surveillance", "options": ["surveillance", "monitoring", "privacy", "consent"], "correctAnswer": "surveillance"}, {"id": "blank2", "text": "privacy", "options": ["privacy", "surveillance", "monitoring", "intrusion"], "correctAnswer": "privacy"}, {"id": "blank3", "text": "privacy", "options": ["privacy", "surveillance", "monitoring", "consent"], "correctAnswer": "privacy"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 5, 'Complete the Sentences 2', 'Fill with the correct word', '{"text": "Continuous ___ may feel like ___. Informed ___ is essential.", "blanks": [{"id": "blank1", "text": "monitoring", "options": ["monitoring", "surveillance", "privacy", "intrusion"], "correctAnswer": "monitoring"}, {"id": "blank2", "text": "intrusion", "options": ["intrusion", "surveillance", "privacy", "consent"], "correctAnswer": "intrusion"}, {"id": "blank3", "text": "consent", "options": ["consent", "surveillance", "monitoring", "intrusion"], "correctAnswer": "consent"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_explanation', 6, 'Advanced Passives', 'Learn advanced passive structures', '{"rules": "Advanced passive forms:\n- \"Data should be handled carefully.\" (obligation)\n- \"Information must not be tracked without consent.\" (prohibition)\n- \"Surveillance is being implemented.\" (continuous)\n- \"Privacy has been compromised.\" (perfect)\n- \"Monitoring will be reviewed.\" (future)\n\nUse when:\n- Focus is on action, not actor: \"Data should be protected.\"\n- Actor is unknown/unimportant: \"Information was leaked.\"\n- Formal/impersonal tone: \"It is required that data be secured.\"", "examples": ["Data should be handled with care.", "Student information must not be tracked without consent.", "Surveillance is being implemented across campuses.", "Privacy has been compromised by excessive monitoring.", "Monitoring systems will be reviewed regularly."]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 7, 'Build Sentences 1', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'Data should be handled according to privacy regulations.', 'Data should be handled according to privacy regulations.', '["Data", "should", "be", "handled", "according", "to", "privacy", "regulations."]'::jsonb),
    (activity_id_var, 'Student information must not be tracked without consent.', 'Student information must not be tracked without consent.', '["Student", "information", "must", "not", "be", "tracked", "without", "consent."]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 8, 'Build Sentences 2', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'Surveillance is being implemented in many institutions.', 'Surveillance is being implemented in many institutions.', '["Surveillance", "is", "being", "implemented", "in", "many", "institutions."]'::jsonb),
    (activity_id_var, 'Privacy has been compromised by excessive monitoring.', 'Privacy has been compromised by excessive monitoring.', '["Privacy", "has", "been", "compromised", "by", "excessive", "monitoring."]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'speaking_practice', 9, 'Discuss Digital Surveillance', 'Practice speaking about surveillance', '{"prompts": ["What student data is commonly tracked?", "When does monitoring go too far?", "Is surveillance ever justified in schools?", "How can privacy be protected?", "What does informed consent mean for students?"]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (
      lesson_id,
      activity_type,
      activity_order,
      title,
      description,
      content
    ) VALUES (
      'C1-L17',
      'speaking_improvement',
      10,
      'Speaking Improvement',
      'Read the improved version of your speech',
      '{"type": "speaking_improvement", "similarityThreshold": 70}'::jsonb
    );
END $$;



-- =========================================
-- C1 Lesson 18
-- =========================================

-- =========================================
-- Pre-fill Database with Sample Lesson Data
-- C1-L18: Access to Education Worldwide
-- =========================================

DELETE FROM grammar_sentences WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'C1-L18');
DELETE FROM vocabulary_items WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'C1-L18');
DELETE FROM lesson_activities WHERE lesson_id = 'C1-L18';
DELETE FROM lessons WHERE id = 'C1-L18';

INSERT INTO lessons (id, level, lesson_number, topic) VALUES
('C1-L18', 'C1', 18, 'Access to Education Worldwide')
ON CONFLICT (id) DO UPDATE SET topic = EXCLUDED.topic;

DO $$
DECLARE
    lesson_id_var TEXT := 'C1-L18';
    activity_id_var UUID;
BEGIN
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'warm_up_speaking', 1, 'Education Access', 'Discuss access to education', '{"prompt": "Why do some students lack access to education?"}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_intro', 2, 'Access Vocabulary', 'Learn vocabulary about education access', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'accessibility', 'การเข้าถึง', NULL),
    (activity_id_var, 'barrier', 'อุปสรรค', NULL),
    (activity_id_var, 'opportunity', 'โอกาส', NULL),
    (activity_id_var, 'disparity', 'ความแตกต่าง', NULL),
    (activity_id_var, 'inclusion', 'การรวมเข้า', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_matching_drag', 3, 'Match Access Words', 'Match English words with Thai meanings', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'accessibility', 'การเข้าถึง', NULL),
    (activity_id_var, 'barrier', 'อุปสรรค', NULL),
    (activity_id_var, 'opportunity', 'โอกาส', NULL),
    (activity_id_var, 'disparity', 'ความแตกต่าง', NULL),
    (activity_id_var, 'inclusion', 'การรวมเข้า', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 4, 'Complete the Sentences 1', 'Fill with the correct word', '{"text": "Educational ___ faces many ___. Equal ___ requires removing obstacles.", "blanks": [{"id": "blank1", "text": "accessibility", "options": ["accessibility", "barrier", "opportunity", "disparity"], "correctAnswer": "accessibility"}, {"id": "blank2", "text": "barriers", "options": ["barriers", "accessibility", "opportunity", "disparity"], "correctAnswer": "barriers"}, {"id": "blank3", "text": "opportunity", "options": ["opportunity", "accessibility", "barrier", "inclusion"], "correctAnswer": "opportunity"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 5, 'Complete the Sentences 2', 'Fill with the correct word', '{"text": "Global ___ in education persists. True ___ requires systemic change.", "blanks": [{"id": "blank1", "text": "disparity", "options": ["disparity", "accessibility", "barrier", "opportunity"], "correctAnswer": "disparity"}, {"id": "blank2", "text": "inclusion", "options": ["inclusion", "accessibility", "barrier", "disparity"], "correctAnswer": "inclusion"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_explanation', 6, 'Inversion: Little/Rarely', 'Learn inversion with little and rarely', '{"rules": "Inversion with little/rarely:\n- \"Little do people realize...\" (formal emphasis)\n- \"Rarely do we consider...\" (emphasis on infrequency)\n- \"Seldom have we addressed...\" (past emphasis)\n\nStructure:\n- Little/Rarely/Seldom + auxiliary + subject + verb\n- Used for emphasis and formal tone\n\nUse for:\n- Emphasizing rarity: \"Rarely do we think about global access.\"\n- Formal statements: \"Little did they realize the barriers.\"\n- Highlighting infrequency: \"Seldom have opportunities been equal.\"", "examples": ["Rarely do we consider global education access.", "Little do people realize the barriers students face.", "Seldom have opportunities been distributed equally.", "Rarely is accessibility prioritized in policy.", "Little attention is paid to educational disparities."]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 7, 'Build Sentences 1', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'Rarely do we consider the barriers to education access.', 'Rarely do we consider the barriers to education access.', '["Rarely", "do", "we", "consider", "the", "barriers", "to", "education", "access."]'::jsonb),
    (activity_id_var, 'Little do people realize the global disparities in opportunity.', 'Little do people realize the global disparities in opportunity.', '["Little", "do", "people", "realize", "the", "global", "disparities", "in", "opportunity."]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 8, 'Build Sentences 2', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'Seldom have opportunities been distributed equally worldwide.', 'Seldom have opportunities been distributed equally worldwide.', '["Seldom", "have", "opportunities", "been", "distributed", "equally", "worldwide."]'::jsonb),
    (activity_id_var, 'Rarely is true inclusion achieved without systemic change.', 'Rarely is true inclusion achieved without systemic change.', '["Rarely", "is", "true", "inclusion", "achieved", "without", "systemic", "change."]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'speaking_practice', 9, 'Discuss Education Access', 'Practice speaking about access to education', '{"prompts": ["What limits access to education globally?", "How rarely is access equal across countries?", "What barriers affect disadvantaged students?", "How can access be expanded?", "What does equal opportunity require?"]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (
      lesson_id,
      activity_type,
      activity_order,
      title,
      description,
      content
    ) VALUES (
      'C1-L18',
      'speaking_improvement',
      10,
      'Speaking Improvement',
      'Read the improved version of your speech',
      '{"type": "speaking_improvement", "similarityThreshold": 70}'::jsonb
    );
END $$;



-- =========================================
-- C1 Lesson 19
-- =========================================

-- =========================================
-- Pre-fill Database with Sample Lesson Data
-- C1-L19: Educational Inequality
-- =========================================

DELETE FROM grammar_sentences WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'C1-L19');
DELETE FROM vocabulary_items WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'C1-L19');
DELETE FROM lesson_activities WHERE lesson_id = 'C1-L19';
DELETE FROM lessons WHERE id = 'C1-L19';

INSERT INTO lessons (id, level, lesson_number, topic) VALUES
('C1-L19', 'C1', 19, 'Educational Inequality')
ON CONFLICT (id) DO UPDATE SET topic = EXCLUDED.topic;

DO $$
DECLARE
    lesson_id_var TEXT := 'C1-L19';
    activity_id_var UUID;
BEGIN
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'warm_up_speaking', 1, 'Educational Inequality', 'Discuss educational inequality', '{"prompt": "What causes inequality in education?"}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_intro', 2, 'Inequality Vocabulary', 'Learn vocabulary about educational inequality', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'inequality', 'ความไม่เท่าเทียม', NULL),
    (activity_id_var, 'privilege', 'สิทธิพิเศษ', NULL),
    (activity_id_var, 'disadvantage', 'ข้อเสียเปรียบ', NULL),
    (activity_id_var, 'socioeconomic', 'ทางสังคมและเศรษฐกิจ', NULL),
    (activity_id_var, 'marginalization', 'การถูกทำให้เป็นชายขอบ', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_matching_drag', 3, 'Match Inequality Words', 'Match English words with Thai meanings', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'inequality', 'ความไม่เท่าเทียม', NULL),
    (activity_id_var, 'privilege', 'สิทธิพิเศษ', NULL),
    (activity_id_var, 'disadvantage', 'ข้อเสียเปรียบ', NULL),
    (activity_id_var, 'socioeconomic', 'ทางสังคมและเศรษฐกิจ', NULL),
    (activity_id_var, 'marginalization', 'การถูกทำให้เป็นชายขอบ', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 4, 'Complete the Sentences 1', 'Fill with the correct word', '{"text": "Educational ___ persists globally. ___ status affects access.", "blanks": [{"id": "blank1", "text": "inequality", "options": ["inequality", "privilege", "disadvantage", "marginalization"], "correctAnswer": "inequality"}, {"id": "blank2", "text": "Socioeconomic", "options": ["Socioeconomic", "Inequality", "Privilege", "Disadvantage"], "correctAnswer": "Socioeconomic"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 5, 'Complete the Sentences 2', 'Fill with the correct word', '{"text": "___ creates unfair advantages. ___ leads to educational ___.", "blanks": [{"id": "blank1", "text": "Privilege", "options": ["Privilege", "Inequality", "Disadvantage", "Marginalization"], "correctAnswer": "Privilege"}, {"id": "blank2", "text": "Marginalization", "options": ["Marginalization", "Privilege", "Inequality", "Disadvantage"], "correctAnswer": "Marginalization"}, {"id": "blank3", "text": "disadvantage", "options": ["disadvantage", "privilege", "inequality", "marginalization"], "correctAnswer": "disadvantage"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_explanation', 6, 'Articles: Generic Reference', 'Learn articles with generic nouns', '{"rules": "Generic reference with articles:\n- Zero article for general concepts: \"Inequality affects many.\"\n- \"The\" for specific instances: \"The inequality in this region is severe.\"\n- \"A/an\" for classifying: \"Inequality is a complex issue.\"\n\nPatterns:\n- General statements: \"Privilege creates advantages.\"\n- Specific reference: \"The privilege of wealth enables access.\"\n- Classification: \"Education is a right, not a privilege.\"\n\nUse for:\n- General statements: \"Inequality persists in education.\"\n- Specific cases: \"The inequality we see is systemic.\"\n- Classification: \"Privilege is a form of advantage.\"", "examples": ["Inequality affects educational outcomes globally.", "The inequality in urban areas is particularly visible.", "Privilege creates unfair advantages in access.", "The privilege of socioeconomic status shapes opportunities.", "Education should be a right, not a privilege."]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 7, 'Build Sentences 1', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'Inequality affects educational outcomes across regions.', 'Inequality affects educational outcomes across regions.', '["Inequality", "affects", "educational", "outcomes", "across", "regions."]'::jsonb),
    (activity_id_var, 'The inequality in this system is deeply entrenched.', 'The inequality in this system is deeply entrenched.', '["The", "inequality", "in", "this", "system", "is", "deeply", "entrenched."]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 8, 'Build Sentences 2', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'Privilege creates unfair advantages in access to education.', 'Privilege creates unfair advantages in access to education.', '["Privilege", "creates", "unfair", "advantages", "in", "access", "to", "education."]'::jsonb),
    (activity_id_var, 'The privilege of wealth enables better opportunities.', 'The privilege of wealth enables better opportunities.', '["The", "privilege", "of", "wealth", "enables", "better", "opportunities."]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'speaking_practice', 9, 'Discuss Educational Inequality', 'Practice speaking about inequality', '{"prompts": ["What factors create educational inequality?", "How does family background affect opportunity?", "Where do you see inequality in your community?", "How does privilege influence outcomes?", "What steps could reduce inequality?"]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (
      lesson_id,
      activity_type,
      activity_order,
      title,
      description,
      content
    ) VALUES (
      'C1-L19',
      'speaking_improvement',
      10,
      'Speaking Improvement',
      'Read the improved version of your speech',
      '{"type": "speaking_improvement", "similarityThreshold": 70}'::jsonb
    );
END $$;



-- =========================================
-- C1 Lesson 20
-- =========================================

-- =========================================
-- Pre-fill Database with Sample Lesson Data
-- C1-L20: Meritocracy in Education
-- =========================================

DELETE FROM grammar_sentences WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'C1-L20');
DELETE FROM vocabulary_items WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'C1-L20');
DELETE FROM lesson_activities WHERE lesson_id = 'C1-L20';
DELETE FROM lessons WHERE id = 'C1-L20';

INSERT INTO lessons (id, level, lesson_number, topic) VALUES
('C1-L20', 'C1', 20, 'Meritocracy in Education')
ON CONFLICT (id) DO UPDATE SET topic = EXCLUDED.topic;

DO $$
DECLARE
    lesson_id_var TEXT := 'C1-L20';
    activity_id_var UUID;
BEGIN
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'warm_up_speaking', 1, 'Meritocracy', 'Discuss meritocracy in education', '{"prompt": "Does effort always lead to success in education?"}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_intro', 2, 'Meritocracy Vocabulary', 'Learn vocabulary about meritocracy', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'meritocracy', 'ระบบคุณธรรม', NULL),
    (activity_id_var, 'merit', 'คุณความดี', NULL),
    (activity_id_var, 'achievement', 'ความสำเร็จ', NULL),
    (activity_id_var, 'equity', 'ความเท่าเทียม', NULL),
    (activity_id_var, 'fairness', 'ความยุติธรรม', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_matching_drag', 3, 'Match Meritocracy Words', 'Match English words with Thai meanings', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'meritocracy', 'ระบบคุณธรรม', NULL),
    (activity_id_var, 'merit', 'คุณความดี', NULL),
    (activity_id_var, 'achievement', 'ความสำเร็จ', NULL),
    (activity_id_var, 'equity', 'ความเท่าเทียม', NULL),
    (activity_id_var, 'fairness', 'ความยุติธรรม', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 4, 'Complete the Sentences 1', 'Fill with the correct word', '{"text": "A ___ rewards ___ and ___. True ___ requires equal starting points.", "blanks": [{"id": "blank1", "text": "meritocracy", "options": ["meritocracy", "merit", "achievement", "equity"], "correctAnswer": "meritocracy"}, {"id": "blank2", "text": "merit", "options": ["merit", "meritocracy", "achievement", "fairness"], "correctAnswer": "merit"}, {"id": "blank3", "text": "achievement", "options": ["achievement", "merit", "equity", "fairness"], "correctAnswer": "achievement"}, {"id": "blank4", "text": "equity", "options": ["equity", "merit", "achievement", "fairness"], "correctAnswer": "equity"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 5, 'Complete the Sentences 2', 'Fill with the correct word', '{"text": "___ in meritocracy means equal opportunity. ___ ensures rewards match effort.", "blanks": [{"id": "blank1", "text": "Fairness", "options": ["Fairness", "Merit", "Achievement", "Equity"], "correctAnswer": "Fairness"}, {"id": "blank2", "text": "Fairness", "options": ["Fairness", "Merit", "Achievement", "Equity"], "correctAnswer": "Fairness"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_explanation', 6, 'Mixed and Implied Conditionals', 'Learn advanced conditional structures', '{"rules": "Mixed and implied conditionals:\n- Mixed 2/3: \"If meritocracy worked (now), campuses would look different (now).\"\n- Mixed 3/2: \"If meritocracy had worked (past), campuses would look different (now).\"\n- Implied: \"Had meritocracy worked, campuses would be fairer.\" (omitted if)\n\nStructures:\n- If + past perfect, would + base form (past condition, present result)\n- If + past simple, would + base form (present condition, present result)\n- Had + past participle, would + base form (implied conditional)\n\nUse for:\n- Hypothetical past affecting present: \"If merit had mattered, access would be fairer.\"\n- Unreal present: \"If meritocracy worked, achievement would determine success.\"\n- Implied conditions: \"Had equity existed, merit would matter more.\"", "examples": ["If meritocracy had truly worked, campuses would look different now.", "If merit determined success, achievement would be rewarded fairly.", "Had equity been ensured, merit would matter more.", "If meritocracy worked, fairness would be visible everywhere.", "Had starting points been equal, merit would determine outcomes."]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 7, 'Build Sentences 1', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'If meritocracy had truly worked, campuses would look different now.', 'If meritocracy had truly worked, campuses would look different now.', '["If", "meritocracy", "had", "truly", "worked,", "campuses", "would", "look", "different", "now."]'::jsonb),
    (activity_id_var, 'If merit determined success, achievement would be rewarded fairly.', 'If merit determined success, achievement would be rewarded fairly.', '["If", "merit", "determined", "success,", "achievement", "would", "be", "rewarded", "fairly."]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 8, 'Build Sentences 2', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'Had equity been ensured, merit would matter more.', 'Had equity been ensured, merit would matter more.', '["Had", "equity", "been", "ensured,", "merit", "would", "matter", "more."]'::jsonb),
    (activity_id_var, 'If fairness existed, achievement would reflect true merit.', 'If fairness existed, achievement would reflect true merit.', '["If", "fairness", "existed,", "achievement", "would", "reflect", "true", "merit."]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'speaking_practice', 9, 'Discuss Meritocracy', 'Practice speaking about meritocracy', '{"prompts": ["If meritocracy worked perfectly, what would change?", "What limits fair competition in education?", "Does talent matter more than opportunity?", "How can systems reward effort fairly?", "What role does support play in achievement?"]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (
      lesson_id,
      activity_type,
      activity_order,
      title,
      description,
      content
    ) VALUES (
      'C1-L20',
      'speaking_improvement',
      10,
      'Speaking Improvement',
      'Read the improved version of your speech',
      '{"type": "speaking_improvement", "similarityThreshold": 70}'::jsonb
    );
END $$;



-- =========================================
-- C1 Lesson 21
-- =========================================

-- =========================================
-- Pre-fill Database with Sample Lesson Data
-- C1-L21: Media Literacy & Misinformation
-- =========================================
DELETE FROM lesson_activity_results WHERE lesson_id = 'C1-L21';
DELETE FROM user_progress WHERE lesson_id = 'C1-L21';
DELETE FROM lesson_history WHERE lesson_id = 'C1-L21';
DELETE FROM grammar_sentences WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'C1-L21');
DELETE FROM vocabulary_items WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'C1-L21');
DELETE FROM lesson_activities WHERE lesson_id = 'C1-L21';
DELETE FROM lessons WHERE id = 'C1-L21';

INSERT INTO lessons (id, level, lesson_number, topic) VALUES
('C1-L21', 'C1', 21, 'Media Literacy & Misinformation')
ON CONFLICT (id) DO UPDATE SET topic = EXCLUDED.topic;

DO $$
DECLARE
    lesson_id_var TEXT := 'C1-L21';
    activity_id_var UUID;
BEGIN
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'warm_up_speaking', 1, 'Media Literacy', 'Discuss media literacy', '{"prompt": "How do you decide what information to trust?"}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_intro', 2, 'Media Literacy Vocabulary', 'Learn vocabulary about media literacy', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'credibility', 'ความน่าเชื่อถือ', NULL),
    (activity_id_var, 'verification', 'การตรวจสอบ', NULL),
    (activity_id_var, 'misinformation', 'ข้อมูลผิด', NULL),
    (activity_id_var, 'bias', 'อคติ', NULL),
    (activity_id_var, 'reliability', 'ความน่าเชื่อถือ', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_matching_drag', 3, 'Match Media Literacy Words', 'Match English words with Thai meanings', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'credibility', 'ความน่าเชื่อถือ', NULL),
    (activity_id_var, 'verification', 'การตรวจสอบ', NULL),
    (activity_id_var, 'misinformation', 'ข้อมูลผิด', NULL),
    (activity_id_var, 'bias', 'อคติ', NULL),
    (activity_id_var, 'reliability', 'ความน่าเชื่อถือ', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 4, 'Complete the Sentences 1', 'Fill with the correct word', '{"text": "Checking ___ ensures ___. ___ spreads through social media.", "blanks": [{"id": "blank1", "text": "credibility", "options": ["credibility", "verification", "misinformation", "bias"], "correctAnswer": "credibility"}, {"id": "blank2", "text": "reliability", "options": ["reliability", "credibility", "verification", "bias"], "correctAnswer": "reliability"}, {"id": "blank3", "text": "Misinformation", "options": ["Misinformation", "Credibility", "Verification", "Bias"], "correctAnswer": "Misinformation"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 5, 'Complete the Sentences 2', 'Fill with the correct word', '{"text": "Fact ___ prevents false information. Hidden ___ affects reporting.", "blanks": [{"id": "blank1", "text": "verification", "options": ["verification", "credibility", "misinformation", "bias"], "correctAnswer": "verification"}, {"id": "blank2", "text": "bias", "options": ["bias", "credibility", "verification", "misinformation"], "correctAnswer": "bias"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_explanation', 6, 'Participle Clauses', 'Learn participle clauses', '{"rules": "Participle clauses:\n- Present participle (-ing): \"Checking sources, students verify information.\"\n- Past participle (-ed): \"Influenced by bias, readers misunderstand.\"\n- Perfect participle (having + past participle): \"Having verified the source, they trusted it.\"\n\nUse for:\n- Showing simultaneous actions: \"Checking news, you evaluate credibility.\"\n- Showing cause: \"Influenced by misinformation, people spread false claims.\"\n- Showing time sequence: \"Having verified facts, journalists publish stories.\"", "examples": ["Checking sources carefully, students verify information.", "Influenced by bias, readers misunderstand the news.", "Having verified the source, they trusted the information.", "Filtering information, people avoid misinformation.", "Shaped by algorithms, feeds show biased content."]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 7, 'Build Sentences 1', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'Checking sources carefully, students verify information.', 'Checking sources carefully, students verify information.', '["Checking", "sources", "carefully,", "students", "verify", "information."]'::jsonb),
    (activity_id_var, 'Influenced by bias, readers misunderstand the news.', 'Influenced by bias, readers misunderstand the news.', '["Influenced", "by", "bias,", "readers", "misunderstand", "the", "news."]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 8, 'Build Sentences 2', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'Having verified the source, they trusted the information.', 'Having verified the source, they trusted the information.', '["Having", "verified", "the", "source,", "they", "trusted", "the", "information."]'::jsonb),
    (activity_id_var, 'Filtering information, people avoid misinformation.', 'Filtering information, people avoid misinformation.', '["Filtering", "information,", "people", "avoid", "misinformation."]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'speaking_practice', 9, 'Discuss Media Literacy', 'Practice speaking about media literacy', '{"prompts": ["How do you check if news is reliable?", "What signs suggest bias or misinformation?", "How do social media platforms influence beliefs?", "What habits help you stay informed?", "How do you deal with conflicting information?"]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (
      lesson_id,
      activity_type,
      activity_order,
      title,
      description,
      content
    ) VALUES (
      'C1-L21',
      'speaking_improvement',
      10,
      'Speaking Improvement',
      'Read the improved version of your speech',
      '{"type": "speaking_improvement", "similarityThreshold": 70}'::jsonb
    );
END $$;



-- =========================================
-- C1 Lesson 22
-- =========================================

-- =========================================
-- Pre-fill Database with Sample Lesson Data
-- C1-L22: Critical Evaluation of Sources
-- =========================================
DELETE FROM lesson_activity_results WHERE lesson_id = 'C1-L22';
DELETE FROM user_progress WHERE lesson_id = 'C1-L22';
DELETE FROM lesson_history WHERE lesson_id = 'C1-L22';
DELETE FROM grammar_sentences WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'C1-L22');
DELETE FROM vocabulary_items WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'C1-L22');
DELETE FROM lesson_activities WHERE lesson_id = 'C1-L22';
DELETE FROM lessons WHERE id = 'C1-L22';

INSERT INTO lessons (id, level, lesson_number, topic) VALUES
('C1-L22', 'C1', 22, 'Critical Evaluation of Sources')
ON CONFLICT (id) DO UPDATE SET topic = EXCLUDED.topic;

DO $$
DECLARE
    lesson_id_var TEXT := 'C1-L22';
    activity_id_var UUID;
BEGIN
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'warm_up_speaking', 1, 'Source Evaluation', 'Discuss evaluating sources', '{"prompt": "What makes a source trustworthy?"}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_intro', 2, 'Source Evaluation Vocabulary', 'Learn vocabulary about source evaluation', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'evidence', 'หลักฐาน', NULL),
    (activity_id_var, 'authority', 'ผู้มีอำนาจ', NULL),
    (activity_id_var, 'validity', 'ความถูกต้อง', NULL),
    (activity_id_var, 'authenticity', 'ความแท้จริง', NULL),
    (activity_id_var, 'scrutiny', 'การตรวจสอบ', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_matching_drag', 3, 'Match Source Evaluation Words', 'Match English words with Thai meanings', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'evidence', 'หลักฐาน', NULL),
    (activity_id_var, 'authority', 'ผู้มีอำนาจ', NULL),
    (activity_id_var, 'validity', 'ความถูกต้อง', NULL),
    (activity_id_var, 'authenticity', 'ความแท้จริง', NULL),
    (activity_id_var, 'scrutiny', 'การตรวจสอบ', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 4, 'Complete the Sentences 1', 'Fill with the correct word', '{"text": "Strong ___ supports claims. Academic ___ ensures ___.", "blanks": [{"id": "blank1", "text": "evidence", "options": ["evidence", "authority", "validity", "authenticity"], "correctAnswer": "evidence"}, {"id": "blank2", "text": "scrutiny", "options": ["scrutiny", "evidence", "authority", "validity"], "correctAnswer": "scrutiny"}, {"id": "blank3", "text": "validity", "options": ["validity", "evidence", "authority", "authenticity"], "correctAnswer": "validity"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 5, 'Complete the Sentences 2', 'Fill with the correct word', '{"text": "Expert ___ increases trust. Document ___ confirms ___.", "blanks": [{"id": "blank1", "text": "authority", "options": ["authority", "evidence", "validity", "authenticity"], "correctAnswer": "authority"}, {"id": "blank2", "text": "authenticity", "options": ["authenticity", "evidence", "authority", "validity"], "correctAnswer": "authenticity"}, {"id": "blank3", "text": "validity", "options": ["validity", "evidence", "authority", "authenticity"], "correctAnswer": "validity"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_explanation', 6, 'Nominal Clauses', 'Learn about nominal clauses', '{"rules": "Nominal clauses function as nouns:\n- Subject: \"What you consider evidence matters.\"\n- Object: \"I believe that sources need evaluation.\"\n- Complement: \"The question is who influences trust.\"\n\nTypes:\n- That-clauses: \"I think that evidence is crucial.\"\n- Wh-clauses: \"What you trust determines your view.\"\n- Whether/if: \"The issue is whether sources are reliable.\"\n\nUse for:\n- Expressing opinions: \"What I consider is strong evidence.\"\n- Asking questions: \"Who influences what you trust?\"\n- Making statements: \"That sources matter is clear.\"", "examples": ["What you consider evidence determines your judgment.", "I believe that sources need careful evaluation.", "The question is who influences what you trust.", "Whether sources are reliable remains uncertain.", "That evidence matters is widely accepted."]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 7, 'Build Sentences 1', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'What you consider evidence determines your judgment.', 'What you consider evidence determines your judgment.', '["What", "you", "consider", "evidence", "determines", "your", "judgment."]'::jsonb),
    (activity_id_var, 'I believe that sources need careful evaluation.', 'I believe that sources need careful evaluation.', '["I", "believe", "that", "sources", "need", "careful", "evaluation."]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 8, 'Build Sentences 2', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'The question is who influences what you trust.', 'The question is who influences what you trust.', '["The", "question", "is", "who", "influences", "what", "you", "trust."]'::jsonb),
    (activity_id_var, 'Whether sources are reliable remains uncertain.', 'Whether sources are reliable remains uncertain.', '["Whether", "sources", "are", "reliable", "remains", "uncertain."]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'speaking_practice', 9, 'Discuss Source Evaluation', 'Practice speaking about evaluating sources', '{"prompts": ["What do you consider strong evidence?", "How do you judge credibility?", "Who influences what you trust?", "What criteria do you use to evaluate sources?", "How do you avoid unreliable information?"]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (
      lesson_id,
      activity_type,
      activity_order,
      title,
      description,
      content
    ) VALUES (
      'C1-L22',
      'speaking_improvement',
      10,
      'Speaking Improvement',
      'Read the improved version of your speech',
      '{"type": "speaking_improvement", "similarityThreshold": 70}'::jsonb
    );
END $$;



-- =========================================
-- C1 Lesson 23
-- =========================================

-- =========================================
-- Pre-fill Database with Sample Lesson Data
-- C1-L23: Bias in News Reporting
-- =========================================
DELETE FROM lesson_activity_results WHERE lesson_id = 'C1-L23';
DELETE FROM user_progress WHERE lesson_id = 'C1-L23';
DELETE FROM lesson_history WHERE lesson_id = 'C1-L23';
DELETE FROM grammar_sentences WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'C1-L23');
DELETE FROM vocabulary_items WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'C1-L23');
DELETE FROM lesson_activities WHERE lesson_id = 'C1-L23';
DELETE FROM lessons WHERE id = 'C1-L23';

INSERT INTO lessons (id, level, lesson_number, topic) VALUES
('C1-L23', 'C1', 23, 'Bias in News Reporting')
ON CONFLICT (id) DO UPDATE SET topic = EXCLUDED.topic;

DO $$
DECLARE
    lesson_id_var TEXT := 'C1-L23';
    activity_id_var UUID;
BEGIN
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'warm_up_speaking', 1, 'Media Bias', 'Discuss bias in news reporting', '{"prompt": "How confident are you in detecting media bias?"}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_intro', 2, 'Bias Vocabulary', 'Learn vocabulary about bias', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'prejudice', 'อคติ', NULL),
    (activity_id_var, 'partiality', 'ความลำเอียง', NULL),
    (activity_id_var, 'objectivity', 'ความเป็นกลาง', NULL),
    (activity_id_var, 'distortion', 'การบิดเบือน', NULL),
    (activity_id_var, 'fairness', 'ความยุติธรรม', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_matching_drag', 3, 'Match Bias Words', 'Match English words with Thai meanings', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'prejudice', 'อคติ', NULL),
    (activity_id_var, 'partiality', 'ความลำเอียง', NULL),
    (activity_id_var, 'objectivity', 'ความเป็นกลาง', NULL),
    (activity_id_var, 'distortion', 'การบิดเบือน', NULL),
    (activity_id_var, 'fairness', 'ความยุติธรรม', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 4, 'Complete the Sentences 1', 'Fill with the correct word', '{"text": "Hidden ___ affects reporting. True ___ requires ___.", "blanks": [{"id": "blank1", "text": "prejudice", "options": ["prejudice", "partiality", "objectivity", "distortion"], "correctAnswer": "prejudice"}, {"id": "blank2", "text": "objectivity", "options": ["objectivity", "prejudice", "partiality", "fairness"], "correctAnswer": "objectivity"}, {"id": "blank3", "text": "fairness", "options": ["fairness", "prejudice", "objectivity", "distortion"], "correctAnswer": "fairness"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 5, 'Complete the Sentences 2', 'Fill with the correct word', '{"text": "Journalistic ___ undermines trust. ___ of facts misleads readers.", "blanks": [{"id": "blank1", "text": "partiality", "options": ["partiality", "prejudice", "objectivity", "distortion"], "correctAnswer": "partiality"}, {"id": "blank2", "text": "Distortion", "options": ["Distortion", "Prejudice", "Partiality", "Objectivity"], "correctAnswer": "Distortion"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_explanation', 6, 'Modals: Degrees of Certainty', 'Learn modals expressing degrees of certainty', '{"rules": "Modals for degrees of certainty:\n- \"must\" (high certainty): \"The news must be biased.\"\n- \"should\" (probable): \"The report should be accurate.\"\n- \"might/may\" (possible): \"The article might contain bias.\"\n- \"could\" (less certain): \"The source could be unreliable.\"\n\nUse for:\n- Expressing confidence: \"I am certain the news is biased.\"\n- Showing uncertainty: \"I am not sure if bias exists.\"\n- Speculating: \"The reporting might be influenced by bias.\"", "examples": ["The news must be biased given the evidence.", "I should be certain the report is accurate.", "The article might contain unintentional bias.", "I could be wrong about detecting bias.", "You may be confident that journalists reduce bias."]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 7, 'Build Sentences 1', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'The news must be biased given the evidence.', 'The news must be biased given the evidence.', '["The", "news", "must", "be", "biased", "given", "the", "evidence."]'::jsonb),
    (activity_id_var, 'I should be certain the report is accurate.', 'I should be certain the report is accurate.', '["I", "should", "be", "certain", "the", "report", "is", "accurate."]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 8, 'Build Sentences 2', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'The article might contain unintentional bias.', 'The article might contain unintentional bias.', '["The", "article", "might", "contain", "unintentional", "bias."]'::jsonb),
    (activity_id_var, 'You may be confident that journalists reduce bias.', 'You may be confident that journalists reduce bias.', '["You", "may", "be", "confident", "that", "journalists", "reduce", "bias."]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'speaking_practice', 9, 'Discuss Media Bias', 'Practice speaking about bias in news', '{"prompts": ["How sure are you when news is biased?", "What evidence convinces you?", "What types of bias concern you most?", "Can bias ever be unintentional?", "How can journalists reduce bias?"]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (
      lesson_id,
      activity_type,
      activity_order,
      title,
      description,
      content
    ) VALUES (
      'C1-L23',
      'speaking_improvement',
      10,
      'Speaking Improvement',
      'Read the improved version of your speech',
      '{"type": "speaking_improvement", "similarityThreshold": 70}'::jsonb
    );
END $$;



-- =========================================
-- C1 Lesson 24
-- =========================================

-- =========================================
-- Pre-fill Database with Sample Lesson Data
-- C1-L24: Impact of Algorithms on Information
-- =========================================
DELETE FROM lesson_activity_results WHERE lesson_id = 'C1-L24';
DELETE FROM user_progress WHERE lesson_id = 'C1-L24';
DELETE FROM lesson_history WHERE lesson_id = 'C1-L24';
DELETE FROM grammar_sentences WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'C1-L24');
DELETE FROM vocabulary_items WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'C1-L24');
DELETE FROM lesson_activities WHERE lesson_id = 'C1-L24';
DELETE FROM lessons WHERE id = 'C1-L24';

INSERT INTO lessons (id, level, lesson_number, topic) VALUES
('C1-L24', 'C1', 24, 'Impact of Algorithms on Information')
ON CONFLICT (id) DO UPDATE SET topic = EXCLUDED.topic;

DO $$
DECLARE
    lesson_id_var TEXT := 'C1-L24';
    activity_id_var UUID;
BEGIN
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'warm_up_speaking', 1, 'Algorithms and Information', 'Discuss algorithms and information', '{"prompt": "How have algorithms shaped what you see online?"}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_intro', 2, 'Algorithm Vocabulary', 'Learn vocabulary about algorithms', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'algorithm', 'อัลกอริทึม', NULL),
    (activity_id_var, 'filtering', 'การกรอง', NULL),
    (activity_id_var, 'recommendation', 'คำแนะนำ', NULL),
    (activity_id_var, 'personalization', 'การปรับแต่ง', NULL),
    (activity_id_var, 'echo', 'เสียงสะท้อน', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_matching_drag', 3, 'Match Algorithm Words', 'Match English words with Thai meanings', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'algorithm', 'อัลกอริทึม', NULL),
    (activity_id_var, 'filtering', 'การกรอง', NULL),
    (activity_id_var, 'recommendation', 'คำแนะนำ', NULL),
    (activity_id_var, 'personalization', 'การปรับแต่ง', NULL),
    (activity_id_var, 'echo', 'เสียงสะท้อน', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 4, 'Complete the Sentences 1', 'Fill with the correct word', '{"text": "The ___ controls content ___. ___ systems create ___.", "blanks": [{"id": "blank1", "text": "algorithm", "options": ["algorithm", "filtering", "recommendation", "personalization"], "correctAnswer": "algorithm"}, {"id": "blank2", "text": "filtering", "options": ["filtering", "algorithm", "recommendation", "echo"], "correctAnswer": "filtering"}, {"id": "blank3", "text": "Recommendation", "options": ["Recommendation", "Algorithm", "Filtering", "Personalization"], "correctAnswer": "Recommendation"}, {"id": "blank4", "text": "echo", "options": ["echo", "algorithm", "filtering", "personalization"], "correctAnswer": "echo"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 5, 'Complete the Sentences 2', 'Fill with the correct word', '{"text": "Content ___ shapes user experience. ___ creates filter bubbles.", "blanks": [{"id": "blank1", "text": "personalization", "options": ["personalization", "algorithm", "filtering", "recommendation"], "correctAnswer": "personalization"}, {"id": "blank2", "text": "Filtering", "options": ["Filtering", "Algorithm", "Recommendation", "Personalization"], "correctAnswer": "Filtering"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_explanation', 6, 'Advanced Perfect Aspect', 'Learn advanced perfect forms', '{"rules": "Advanced perfect aspect:\n- Present perfect: \"I have seen how algorithms work.\"\n- Past perfect: \"I had noticed changes before.\"\n- Future perfect: \"I will have adapted by then.\"\n- Perfect continuous: \"I have been influenced for years.\"\n\nUse for:\n- Completed actions with present relevance: \"I have noticed algorithm changes.\"\n- Past before past: \"I had seen this before algorithms changed.\"\n- Future completion: \"I will have adapted to algorithms by next year.\"", "examples": ["I have noticed how algorithms shape my feed.", "I had seen different content before algorithms changed.", "I will have adapted to new algorithms by next month.", "I have been influenced by recommendations for years.", "Having experienced algorithm changes, I understand their impact."]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 7, 'Build Sentences 1', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'I have noticed how algorithms shape my feed.', 'I have noticed how algorithms shape my feed.', '["I", "have", "noticed", "how", "algorithms", "shape", "my", "feed."]'::jsonb),
    (activity_id_var, 'I had seen different content before algorithms changed.', 'I had seen different content before algorithms changed.', '["I", "had", "seen", "different", "content", "before", "algorithms", "changed."]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 8, 'Build Sentences 2', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'I have been influenced by recommendations for years.', 'I have been influenced by recommendations for years.', '["I", "have", "been", "influenced", "by", "recommendations", "for", "years."]'::jsonb),
    (activity_id_var, 'Having experienced algorithm changes, I understand their impact.', 'Having experienced algorithm changes, I understand their impact.', '["Having", "experienced", "algorithm", "changes,", "I", "understand", "their", "impact."]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'speaking_practice', 9, 'Discuss Algorithms', 'Practice speaking about algorithms', '{"prompts": ["How have recommendations influenced your views?", "What role do algorithms play in daily life?", "How has your information diet changed?", "What risks come with algorithmic filtering?", "How can users stay informed despite algorithms?"]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (
      lesson_id,
      activity_type,
      activity_order,
      title,
      description,
      content
    ) VALUES (
      'C1-L24',
      'speaking_improvement',
      10,
      'Speaking Improvement',
      'Read the improved version of your speech',
      '{"type": "speaking_improvement", "similarityThreshold": 70}'::jsonb
    );
END $$;



-- =========================================
-- C1 Lesson 25
-- =========================================

-- =========================================
-- Pre-fill Database with Sample Lesson Data
-- C1-L25: Freedom of Speech on Campuses
-- =========================================
DELETE FROM lesson_activity_results WHERE lesson_id = 'C1-L25';
DELETE FROM user_progress WHERE lesson_id = 'C1-L25';
DELETE FROM lesson_history WHERE lesson_id = 'C1-L25';
DELETE FROM grammar_sentences WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'C1-L25');
DELETE FROM vocabulary_items WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'C1-L25');
DELETE FROM lesson_activities WHERE lesson_id = 'C1-L25';
DELETE FROM lessons WHERE id = 'C1-L25';

INSERT INTO lessons (id, level, lesson_number, topic) VALUES
('C1-L25', 'C1', 25, 'Freedom of Speech on Campuses')
ON CONFLICT (id) DO UPDATE SET topic = EXCLUDED.topic;

DO $$
DECLARE
    lesson_id_var TEXT := 'C1-L25';
    activity_id_var UUID;
BEGIN
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'warm_up_speaking', 1, 'Campus Speech', 'Discuss freedom of speech on campuses', '{"prompt": "When should speech be limited at universities?"}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_intro', 2, 'Speech Freedom Vocabulary', 'Learn vocabulary about speech freedom', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'expression', 'การแสดงออก', NULL),
    (activity_id_var, 'restriction', 'ข้อจำกัด', NULL),
    (activity_id_var, 'boundary', 'ขอบเขต', NULL),
    (activity_id_var, 'tension', 'ความตึงเครียด', NULL),
    (activity_id_var, 'safety', 'ความปลอดภัย', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_matching_drag', 3, 'Match Speech Freedom Words', 'Match English words with Thai meanings', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'expression', 'การแสดงออก', NULL),
    (activity_id_var, 'restriction', 'ข้อจำกัด', NULL),
    (activity_id_var, 'boundary', 'ขอบเขต', NULL),
    (activity_id_var, 'tension', 'ความตึงเครียด', NULL),
    (activity_id_var, 'safety', 'ความปลอดภัย', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 4, 'Complete the Sentences 1', 'Fill with the correct word', '{"text": "Free ___ faces ___. Clear ___ protect ___.", "blanks": [{"id": "blank1", "text": "expression", "options": ["expression", "restriction", "boundary", "tension"], "correctAnswer": "expression"}, {"id": "blank2", "text": "restrictions", "options": ["restrictions", "expression", "boundary", "tension"], "correctAnswer": "restrictions"}, {"id": "blank3", "text": "boundaries", "options": ["boundaries", "expression", "restriction", "tension"], "correctAnswer": "boundaries"}, {"id": "blank4", "text": "safety", "options": ["safety", "expression", "restriction", "tension"], "correctAnswer": "safety"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 5, 'Complete the Sentences 2', 'Fill with the correct word', '{"text": "Campus ___ arises around speech. Balancing ___ and ___ is challenging.", "blanks": [{"id": "blank1", "text": "tension", "options": ["tension", "expression", "restriction", "boundary"], "correctAnswer": "tension"}, {"id": "blank2", "text": "expression", "options": ["expression", "tension", "restriction", "safety"], "correctAnswer": "expression"}, {"id": "blank3", "text": "safety", "options": ["safety", "expression", "tension", "restriction"], "correctAnswer": "safety"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_explanation', 6, 'Inversion: Hardly/Scarcely', 'Learn inversion with hardly and scarcely', '{"rules": "Inversion with hardly/scarcely:\n- \"Hardly had speech begun when tensions rose.\" (formal emphasis)\n- \"Scarcely do students speak freely.\" (emphasis on infrequency)\n- \"Hardly ever is speech unrestricted.\" (emphasis on rarity)\n\nStructure:\n- Hardly/Scarcely + auxiliary + subject + verb\n- Used for emphasis and formal tone\n\nUse for:\n- Emphasizing rarity: \"Hardly ever is speech completely free.\"\n- Formal statements: \"Scarcely had they spoken when restrictions appeared.\"\n- Highlighting infrequency: \"Hardly do tensions arise without reason.\"", "examples": ["Hardly ever is speech completely unrestricted on campus.", "Scarcely do students speak freely without boundaries.", "Hardly had tensions risen when restrictions were imposed.", "Scarcely is expression limited without reason.", "Hardly do safety concerns override free expression."]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 7, 'Build Sentences 1', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'Hardly ever is speech completely unrestricted on campus.', 'Hardly ever is speech completely unrestricted on campus.', '["Hardly", "ever", "is", "speech", "completely", "unrestricted", "on", "campus."]'::jsonb),
    (activity_id_var, 'Scarcely do students speak freely without boundaries.', 'Scarcely do students speak freely without boundaries.', '["Scarcely", "do", "students", "speak", "freely", "without", "boundaries."]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 8, 'Build Sentences 2', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'Hardly had tensions risen when restrictions were imposed.', 'Hardly had tensions risen when restrictions were imposed.', '["Hardly", "had", "tensions", "risen", "when", "restrictions", "were", "imposed."]'::jsonb),
    (activity_id_var, 'Scarcely is expression limited without reason.', 'Scarcely is expression limited without reason.', '["Scarcely", "is", "expression", "limited", "without", "reason."]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'speaking_practice', 9, 'Discuss Campus Speech', 'Practice speaking about freedom of speech', '{"prompts": ["When is free speech restricted on campus?", "Why do tensions arise around speech?", "What limits are reasonable?", "How can safety and expression coexist?", "Who should decide speech boundaries?"]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (
      lesson_id,
      activity_type,
      activity_order,
      title,
      description,
      content
    ) VALUES (
      'C1-L25',
      'speaking_improvement',
      10,
      'Speaking Improvement',
      'Read the improved version of your speech',
      '{"type": "speaking_improvement", "similarityThreshold": 70}'::jsonb
    );
END $$;



-- =========================================
-- C1 Lesson 26
-- =========================================

-- =========================================
-- Pre-fill Database with Sample Lesson Data
-- C1-L26: Cancel Culture and Debate
-- =========================================
DELETE FROM lesson_activity_results WHERE lesson_id = 'C1-L26';
DELETE FROM user_progress WHERE lesson_id = 'C1-L26';
DELETE FROM lesson_history WHERE lesson_id = 'C1-L26';
DELETE FROM grammar_sentences WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'C1-L26');
DELETE FROM vocabulary_items WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'C1-L26');
DELETE FROM lesson_activities WHERE lesson_id = 'C1-L26';
DELETE FROM lessons WHERE id = 'C1-L26';

INSERT INTO lessons (id, level, lesson_number, topic) VALUES
('C1-L26', 'C1', 26, 'Cancel Culture and Debate')
ON CONFLICT (id) DO UPDATE SET topic = EXCLUDED.topic;

DO $$
DECLARE
    lesson_id_var TEXT := 'C1-L26';
    activity_id_var UUID;
BEGIN
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'warm_up_speaking', 1, 'Cancel Culture', 'Discuss cancel culture and debate', '{"prompt": "When does accountability become silencing?"}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_intro', 2, 'Cancel Culture Vocabulary', 'Learn vocabulary about cancel culture', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'accountability', 'ความรับผิดชอบ', NULL),
    (activity_id_var, 'criticism', 'การวิจารณ์', NULL),
    (activity_id_var, 'outrage', 'ความโกรธ', NULL),
    (activity_id_var, 'debate', 'การโต้วาที', NULL),
    (activity_id_var, 'silencing', 'การทำให้เงียบ', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_matching_drag', 3, 'Match Cancel Culture Words', 'Match English words with Thai meanings', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'accountability', 'ความรับผิดชอบ', NULL),
    (activity_id_var, 'criticism', 'การวิจารณ์', NULL),
    (activity_id_var, 'outrage', 'ความโกรธ', NULL),
    (activity_id_var, 'debate', 'การโต้วาที', NULL),
    (activity_id_var, 'silencing', 'การทำให้เงียบ', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 4, 'Complete the Sentences 1', 'Fill with the correct word', '{"text": "Public ___ demands ___. Constructive ___ differs from ___.", "blanks": [{"id": "blank1", "text": "criticism", "options": ["criticism", "accountability", "outrage", "debate"], "correctAnswer": "criticism"}, {"id": "blank2", "text": "accountability", "options": ["accountability", "criticism", "outrage", "silencing"], "correctAnswer": "accountability"}, {"id": "blank3", "text": "debate", "options": ["debate", "criticism", "accountability", "outrage"], "correctAnswer": "debate"}, {"id": "blank4", "text": "silencing", "options": ["silencing", "criticism", "accountability", "outrage"], "correctAnswer": "silencing"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 5, 'Complete the Sentences 2', 'Fill with the correct word', '{"text": "Online ___ escalates quickly. Respectful ___ promotes understanding.", "blanks": [{"id": "blank1", "text": "outrage", "options": ["outrage", "criticism", "accountability", "debate"], "correctAnswer": "outrage"}, {"id": "blank2", "text": "debate", "options": ["debate", "criticism", "accountability", "outrage"], "correctAnswer": "debate"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_explanation', 6, 'Contrast Linking at C1 Level', 'Learn advanced contrast linking', '{"rules": "C1 contrast linking shows nuanced relationships:\n- \"While/Whereas\" (formal contrast): \"While accountability is important, silencing is harmful.\"\n- \"However/Nevertheless\" (concession): \"Criticism matters; however, silencing prevents debate.\"\n- \"On the one hand... on the other hand\" (balanced contrast)\n- \"Despite/In spite of\" (contrary expectation): \"Despite accountability, silencing occurs.\"\n\nUse for:\n- Presenting balanced views: \"On one hand, accountability is needed; on the other, silencing is wrong.\"\n- Acknowledging complexity: \"While criticism is valid, outrage can be excessive.\"\n- Showing contradiction: \"Accountability is important; however, silencing prevents dialogue.\"", "examples": ["While accountability is important, silencing prevents debate.", "Criticism matters; however, outrage can be excessive.", "On the one hand, accountability is needed; on the other, silencing is harmful.", "Despite valid criticism, silencing undermines free speech.", "Whereas debate promotes understanding, silencing prevents dialogue."]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 7, 'Build Sentences 1', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'While accountability is important, silencing prevents debate.', 'While accountability is important, silencing prevents debate.', '["While", "accountability", "is", "important,", "silencing", "prevents", "debate."]'::jsonb),
    (activity_id_var, 'Criticism matters; however, outrage can be excessive.', 'Criticism matters; however, outrage can be excessive.', '["Criticism", "matters;", "however,", "outrage", "can", "be", "excessive."]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 8, 'Build Sentences 2', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'On the one hand, accountability is needed; on the other, silencing is harmful.', 'On the one hand, accountability is needed; on the other, silencing is harmful.', '["On", "the", "one", "hand,", "accountability", "is", "needed;", "on", "the", "other,", "silencing", "is", "harmful."]'::jsonb),
    (activity_id_var, 'Despite valid criticism, silencing undermines free speech.', 'Despite valid criticism, silencing undermines free speech.', '["Despite", "valid", "criticism,", "silencing", "undermines", "free", "speech."]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'speaking_practice', 9, 'Discuss Cancel Culture', 'Practice speaking about cancel culture', '{"prompts": ["How do you define cancel culture?", "When is public criticism justified?", "How can debate remain respectful?", "What risks come with online outrage?", "How should disagreements be handled?"]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (
      lesson_id,
      activity_type,
      activity_order,
      title,
      description,
      content
    ) VALUES (
      'C1-L26',
      'speaking_improvement',
      10,
      'Speaking Improvement',
      'Read the improved version of your speech',
      '{"type": "speaking_improvement", "similarityThreshold": 70}'::jsonb
    );
END $$;



-- =========================================
-- C1 Lesson 27
-- =========================================

-- =========================================
-- Pre-fill Database with Sample Lesson Data
-- C1-L27: Social Media and Public Opinion
-- =========================================
DELETE FROM lesson_activity_results WHERE lesson_id = 'C1-L27';
DELETE FROM user_progress WHERE lesson_id = 'C1-L27';
DELETE FROM lesson_history WHERE lesson_id = 'C1-L27';
DELETE FROM grammar_sentences WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'C1-L27');
DELETE FROM vocabulary_items WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'C1-L27');
DELETE FROM lesson_activities WHERE lesson_id = 'C1-L27';
DELETE FROM lessons WHERE id = 'C1-L27';

INSERT INTO lessons (id, level, lesson_number, topic) VALUES
('C1-L27', 'C1', 27, 'Social Media and Public Opinion')
ON CONFLICT (id) DO UPDATE SET topic = EXCLUDED.topic;

DO $$
DECLARE
    lesson_id_var TEXT := 'C1-L27';
    activity_id_var UUID;
BEGIN
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'warm_up_speaking', 1, 'Social Media and Opinion', 'Discuss social media and public opinion', '{"prompt": "How does social media shape opinions?"}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_intro', 2, 'Social Media Vocabulary', 'Learn vocabulary about social media', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'influence', 'อิทธิพล', NULL),
    (activity_id_var, 'platform', 'แพลตฟอร์ม', NULL),
    (activity_id_var, 'controversy', 'ข้อโต้แย้ง', NULL),
    (activity_id_var, 'trend', 'เทรนด์', NULL),
    (activity_id_var, 'image', 'ภาพลักษณ์', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_matching_drag', 3, 'Match Social Media Words', 'Match English words with Thai meanings', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'influence', 'อิทธิพล', NULL),
    (activity_id_var, 'platform', 'แพลตฟอร์ม', NULL),
    (activity_id_var, 'controversy', 'ข้อโต้แย้ง', NULL),
    (activity_id_var, 'trend', 'เทรนด์', NULL),
    (activity_id_var, 'image', 'ภาพลักษณ์', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 4, 'Complete the Sentences 1', 'Fill with the correct word', '{"text": "Social media ___ public views. Different ___ require different approaches.", "blanks": [{"id": "blank1", "text": "influences", "options": ["influences", "platform", "controversy", "trend"], "correctAnswer": "influences"}, {"id": "blank2", "text": "platforms", "options": ["platforms", "influence", "controversy", "trend"], "correctAnswer": "platforms"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 5, 'Complete the Sentences 2', 'Fill with the correct word', '{"text": "Posts create ___. Online ___ spread rapidly. Managing digital ___ is important.", "blanks": [{"id": "blank1", "text": "controversy", "options": ["controversy", "influence", "platform", "trend"], "correctAnswer": "controversy"}, {"id": "blank2", "text": "trends", "options": ["trends", "influence", "controversy", "platform"], "correctAnswer": "trends"}, {"id": "blank3", "text": "image", "options": ["image", "influence", "controversy", "trend"], "correctAnswer": "image"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_explanation', 6, 'Cohesive Transformations', 'Learn cohesive transformations', '{"rules": "Cohesive transformations:\n- Substitution: \"Social media influences views, and so do posts.\"\n- Ellipsis: \"Posts influence views, and trends do too.\"\n- Reference: \"Platforms shape opinions; this affects society.\"\n- Lexical cohesion: \"Posts influence views; such influence matters.\"\n\nUse for:\n- Avoiding repetition: \"Posts shape opinions; so do videos.\"\n- Creating flow: \"Platforms influence views; this impact is significant.\"\n- Connecting ideas: \"Social media shapes opinions; such influence spreads quickly.\"", "examples": ["Posts influence public views, and videos do too.", "Platforms shape opinions; this impact is significant.", "Social media affects beliefs; such influence spreads quickly.", "Trends emerge online; these trends shape culture.", "Controversy arises; such controversy affects reputation."]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 7, 'Build Sentences 1', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'Posts influence public views, and videos do too.', 'Posts influence public views, and videos do too.', '["Posts", "influence", "public", "views,", "and", "videos", "do", "too."]'::jsonb),
    (activity_id_var, 'Platforms shape opinions; this impact is significant.', 'Platforms shape opinions; this impact is significant.', '["Platforms", "shape", "opinions;", "this", "impact", "is", "significant."]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 8, 'Build Sentences 2', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'Social media affects beliefs; such influence spreads quickly.', 'Social media affects beliefs; such influence spreads quickly.', '["Social", "media", "affects", "beliefs;", "such", "influence", "spreads", "quickly."]'::jsonb),
    (activity_id_var, 'Trends emerge online; these trends shape culture.', 'Trends emerge online; these trends shape culture.', '["Trends", "emerge", "online;", "these", "trends", "shape", "culture."]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'speaking_practice', 9, 'Discuss Social Media', 'Practice speaking about social media', '{"prompts": ["How do posts influence public views?", "How do you adapt messages for different platforms?", "What posts have caused controversy?", "How do trends spread online?", "How do you manage your digital image?"]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (
      lesson_id,
      activity_type,
      activity_order,
      title,
      description,
      content
    ) VALUES (
      'C1-L27',
      'speaking_improvement',
      10,
      'Speaking Improvement',
      'Read the improved version of your speech',
      '{"type": "speaking_improvement", "similarityThreshold": 70}'::jsonb
    );
END $$;



-- =========================================
-- C1 Lesson 28
-- =========================================

-- =========================================
-- Pre-fill Database with Sample Lesson Data
-- C1-L28: Responsibility of Content Creators
-- =========================================
DELETE FROM lesson_activity_results WHERE lesson_id = 'C1-L28';
DELETE FROM user_progress WHERE lesson_id = 'C1-L28';
DELETE FROM lesson_history WHERE lesson_id = 'C1-L28';
DELETE FROM grammar_sentences WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'C1-L28');
DELETE FROM vocabulary_items WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'C1-L28');
DELETE FROM lesson_activities WHERE lesson_id = 'C1-L28';
DELETE FROM lessons WHERE id = 'C1-L28';

INSERT INTO lessons (id, level, lesson_number, topic) VALUES
('C1-L28', 'C1', 28, 'Responsibility of Content Creators')
ON CONFLICT (id) DO UPDATE SET topic = EXCLUDED.topic;

DO $$
DECLARE
    lesson_id_var TEXT := 'C1-L28';
    activity_id_var UUID;
BEGIN
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'warm_up_speaking', 1, 'Content Creator Responsibility', 'Discuss content creator responsibility', '{"prompt": "What responsibilities come with a large audience?"}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_intro', 2, 'Content Creator Vocabulary', 'Learn vocabulary about content creators', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'responsibility', 'ความรับผิดชอบ', NULL),
    (activity_id_var, 'accountability', 'ความรับผิดชอบ', NULL),
    (activity_id_var, 'harm', 'อันตราย', NULL),
    (activity_id_var, 'platform', 'แพลตฟอร์ม', NULL),
    (activity_id_var, 'standard', 'มาตรฐาน', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_matching_drag', 3, 'Match Content Creator Words', 'Match English words with Thai meanings', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'responsibility', 'ความรับผิดชอบ', NULL),
    (activity_id_var, 'accountability', 'ความรับผิดชอบ', NULL),
    (activity_id_var, 'harm', 'อันตราย', NULL),
    (activity_id_var, 'platform', 'แพลตฟอร์ม', NULL),
    (activity_id_var, 'standard', 'มาตรฐาน', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 4, 'Complete the Sentences 1', 'Fill with the correct word', '{"text": "Content creators have ___. ___ must be addressed when ___.", "blanks": [{"id": "blank1", "text": "responsibility", "options": ["responsibility", "accountability", "harm", "platform"], "correctAnswer": "responsibility"}, {"id": "blank2", "text": "Harm", "options": ["Harm", "Responsibility", "Accountability", "Platform"], "correctAnswer": "Harm"}, {"id": "blank3", "text": "harm", "options": ["harm", "responsibility", "accountability", "platform"], "correctAnswer": "harm"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 5, 'Complete the Sentences 2', 'Fill with the correct word', '{"text": "___ requires ___. ___ set ethical ___.", "blanks": [{"id": "blank1", "text": "Accountability", "options": ["Accountability", "Responsibility", "Harm", "Platform"], "correctAnswer": "Accountability"}, {"id": "blank2", "text": "responsibility", "options": ["responsibility", "accountability", "harm", "standard"], "correctAnswer": "responsibility"}, {"id": "blank3", "text": "Platforms", "options": ["Platforms", "Responsibility", "Accountability", "Harm"], "correctAnswer": "Platforms"}, {"id": "blank4", "text": "standards", "options": ["standards", "responsibility", "accountability", "harm"], "correctAnswer": "standards"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_explanation', 6, 'Advanced Passives', 'Learn advanced passive structures', '{"rules": "Advanced passive forms:\n- \"Creators should be held accountable.\" (obligation)\n- \"Harm must be addressed.\" (necessity)\n- \"Standards are being established.\" (continuous)\n- \"Misinformation has been corrected.\" (perfect)\n- \"Content will be reviewed.\" (future)\n\nUse when:\n- Focus is on action, not actor: \"Harm should be prevented.\"\n- Actor is unknown/unimportant: \"Misinformation was spread.\"\n- Formal/impersonal tone: \"It is required that standards be followed.\"", "examples": ["Creators should be held accountable for their content.", "Harm must be addressed when it occurs.", "Standards are being established by platforms.", "Misinformation has been corrected by fact-checkers.", "Content will be reviewed regularly."]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 7, 'Build Sentences 1', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'Creators should be held accountable for their content.', 'Creators should be held accountable for their content.', '["Creators", "should", "be", "held", "accountable", "for", "their", "content."]'::jsonb),
    (activity_id_var, 'Harm must be addressed when it occurs.', 'Harm must be addressed when it occurs.', '["Harm", "must", "be", "addressed", "when", "it", "occurs."]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 8, 'Build Sentences 2', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'Standards are being established by platforms.', 'Standards are being established by platforms.', '["Standards", "are", "being", "established", "by", "platforms."]'::jsonb),
    (activity_id_var, 'Misinformation has been corrected by fact-checkers.', 'Misinformation has been corrected by fact-checkers.', '["Misinformation", "has", "been", "corrected", "by", "fact-checkers."]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'speaking_practice', 9, 'Discuss Content Creators', 'Practice speaking about content creators', '{"prompts": ["What should creators be accountable for?", "How should harm be addressed?", "What role do platforms play?", "How should misinformation be corrected?", "What ethical standards should creators follow?"]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (
      lesson_id,
      activity_type,
      activity_order,
      title,
      description,
      content
    ) VALUES (
      'C1-L28',
      'speaking_improvement',
      10,
      'Speaking Improvement',
      'Read the improved version of your speech',
      '{"type": "speaking_improvement", "similarityThreshold": 70}'::jsonb
    );
END $$;



-- =========================================
-- C1 Lesson 29
-- =========================================

-- =========================================
-- Pre-fill Database with Sample Lesson Data
-- C1-L29: Emotional Manipulation in Media
-- =========================================
DELETE FROM lesson_activity_results WHERE lesson_id = 'C1-L29';
DELETE FROM user_progress WHERE lesson_id = 'C1-L29';
DELETE FROM lesson_history WHERE lesson_id = 'C1-L29';
DELETE FROM grammar_sentences WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'C1-L29');
DELETE FROM vocabulary_items WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'C1-L29');
DELETE FROM lesson_activities WHERE lesson_id = 'C1-L29';
DELETE FROM lessons WHERE id = 'C1-L29';

INSERT INTO lessons (id, level, lesson_number, topic) VALUES
('C1-L29', 'C1', 29, 'Emotional Manipulation in Media')
ON CONFLICT (id) DO UPDATE SET topic = EXCLUDED.topic;

DO $$
DECLARE
    lesson_id_var TEXT := 'C1-L29';
    activity_id_var UUID;
BEGIN
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'warm_up_speaking', 1, 'Emotional Manipulation', 'Discuss emotional manipulation in media', '{"prompt": "How has media influenced your emotions?"}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_intro', 2, 'Emotional Manipulation Vocabulary', 'Learn vocabulary about emotional manipulation', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'manipulation', 'การบงการ', NULL),
    (activity_id_var, 'appeal', 'การดึงดูด', NULL),
    (activity_id_var, 'technique', 'เทคนิค', NULL),
    (activity_id_var, 'resistance', 'การต่อต้าน', NULL),
    (activity_id_var, 'effectiveness', 'ประสิทธิภาพ', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_matching_drag', 3, 'Match Manipulation Words', 'Match English words with Thai meanings', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'manipulation', 'การบงการ', NULL),
    (activity_id_var, 'appeal', 'การดึงดูด', NULL),
    (activity_id_var, 'technique', 'เทคนิค', NULL),
    (activity_id_var, 'resistance', 'การต่อต้าน', NULL),
    (activity_id_var, 'effectiveness', 'ประสิทธิภาพ', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 4, 'Complete the Sentences 1', 'Fill with the correct word', '{"text": "Emotional ___ uses persuasive ___. Audiences develop ___.", "blanks": [{"id": "blank1", "text": "manipulation", "options": ["manipulation", "appeal", "technique", "resistance"], "correctAnswer": "manipulation"}, {"id": "blank2", "text": "techniques", "options": ["techniques", "manipulation", "appeal", "effectiveness"], "correctAnswer": "techniques"}, {"id": "blank3", "text": "resistance", "options": ["resistance", "manipulation", "appeal", "effectiveness"], "correctAnswer": "resistance"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 5, 'Complete the Sentences 2', 'Fill with the correct word', '{"text": "Emotional ___ targets feelings. The ___ of manipulation concerns viewers.", "blanks": [{"id": "blank1", "text": "appeal", "options": ["appeal", "manipulation", "technique", "resistance"], "correctAnswer": "appeal"}, {"id": "blank2", "text": "effectiveness", "options": ["effectiveness", "manipulation", "appeal", "resistance"], "correctAnswer": "effectiveness"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_explanation', 6, 'Modals: Speculation in the Past', 'Learn modals for past speculation', '{"rules": "Past speculation with modals:\n- \"might/could have + past participle\" (possibility in past): \"Media might have influenced your emotions.\"\n- \"must have + past participle\" (strong probability): \"Media must have shaped your feelings.\"\n- \"may have + past participle\" (uncertainty): \"Media may have affected your mood.\"\n\nUse for:\n- Speculating about past influence: \"Media might have shaped how you felt.\"\n- Expressing probability: \"Media must have influenced your emotions.\"\n- Showing uncertainty: \"Media may have affected your feelings.\"", "examples": ["Media might have shaped how you felt about the issue.", "Media must have influenced your emotional response.", "Media may have affected your mood without you realizing.", "Media could have manipulated your emotions subtly.", "Media might have triggered an emotional reaction."]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 7, 'Build Sentences 1', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'Media might have shaped how you felt about the issue.', 'Media might have shaped how you felt about the issue.', '["Media", "might", "have", "shaped", "how", "you", "felt", "about", "the", "issue."]'::jsonb),
    (activity_id_var, 'Media must have influenced your emotional response.', 'Media must have influenced your emotional response.', '["Media", "must", "have", "influenced", "your", "emotional", "response."]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 8, 'Build Sentences 2', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'Media may have affected your mood without you realizing.', 'Media may have affected your mood without you realizing.', '["Media", "may", "have", "affected", "your", "mood", "without", "you", "realizing."]'::jsonb),
    (activity_id_var, 'Media could have manipulated your emotions subtly.', 'Media could have manipulated your emotions subtly.', '["Media", "could", "have", "manipulated", "your", "emotions", "subtly."]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'speaking_practice', 9, 'Discuss Emotional Manipulation', 'Practice speaking about emotional manipulation', '{"prompts": ["How might media have shaped how you felt?", "What emotional techniques are commonly used?", "When is emotional appeal acceptable?", "How can audiences resist manipulation?", "Why is emotional content effective?"]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (
      lesson_id,
      activity_type,
      activity_order,
      title,
      description,
      content
    ) VALUES (
      'C1-L29',
      'speaking_improvement',
      10,
      'Speaking Improvement',
      'Read the improved version of your speech',
      '{"type": "speaking_improvement", "similarityThreshold": 70}'::jsonb
    );
END $$;



-- =========================================
-- C1 Lesson 30
-- =========================================

-- =========================================
-- Pre-fill Database with Sample Lesson Data
-- C1-L30: Media Ethics
-- =========================================
DELETE FROM lesson_activity_results WHERE lesson_id = 'C1-L30';
DELETE FROM user_progress WHERE lesson_id = 'C1-L30';
DELETE FROM lesson_history WHERE lesson_id = 'C1-L30';
DELETE FROM grammar_sentences WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'C1-L30');
DELETE FROM vocabulary_items WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'C1-L30');
DELETE FROM lesson_activities WHERE lesson_id = 'C1-L30';
DELETE FROM lessons WHERE id = 'C1-L30';

INSERT INTO lessons (id, level, lesson_number, topic) VALUES
('C1-L30', 'C1', 30, 'Media Ethics')
ON CONFLICT (id) DO UPDATE SET topic = EXCLUDED.topic;

DO $$
DECLARE
    lesson_id_var TEXT := 'C1-L30';
    activity_id_var UUID;
BEGIN
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'warm_up_speaking', 1, 'Media Ethics', 'Discuss media ethics', '{"prompt": "Where should media draw ethical boundaries?"}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_intro', 2, 'Media Ethics Vocabulary', 'Learn vocabulary about media ethics', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'ethics', 'จริยธรรม', NULL),
    (activity_id_var, 'boundary', 'ขอบเขต', NULL),
    (activity_id_var, 'violation', 'การละเมิด', NULL),
    (activity_id_var, 'reporting', 'การรายงาน', NULL),
    (activity_id_var, 'enforcement', 'การบังคับใช้', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_matching_drag', 3, 'Match Media Ethics Words', 'Match English words with Thai meanings', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'ethics', 'จริยธรรม', NULL),
    (activity_id_var, 'boundary', 'ขอบเขต', NULL),
    (activity_id_var, 'violation', 'การละเมิด', NULL),
    (activity_id_var, 'reporting', 'การรายงาน', NULL),
    (activity_id_var, 'enforcement', 'การบังคับใช้', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 4, 'Complete the Sentences 1', 'Fill with the correct word', '{"text": "Media ___ requires clear ___. Ethical ___ prevents ___.", "blanks": [{"id": "blank1", "text": "ethics", "options": ["ethics", "boundary", "violation", "reporting"], "correctAnswer": "ethics"}, {"id": "blank2", "text": "boundaries", "options": ["boundaries", "ethics", "violation", "enforcement"], "correctAnswer": "boundaries"}, {"id": "blank3", "text": "reporting", "options": ["reporting", "ethics", "boundary", "violation"], "correctAnswer": "reporting"}, {"id": "blank4", "text": "violations", "options": ["violations", "ethics", "boundary", "reporting"], "correctAnswer": "violations"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 5, 'Complete the Sentences 2', 'Fill with the correct word', '{"text": "Ethical ___ ensures accuracy. ___ of standards protects integrity.", "blanks": [{"id": "blank1", "text": "reporting", "options": ["reporting", "ethics", "boundary", "violation"], "correctAnswer": "reporting"}, {"id": "blank2", "text": "Enforcement", "options": ["Enforcement", "Ethics", "Boundary", "Violation"], "correctAnswer": "Enforcement"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_explanation', 6, 'Articles: Abstract Reference', 'Learn articles with abstract nouns', '{"rules": "Articles with abstract nouns:\n- Use \"the\" when referring to a specific abstract concept: \"the ethics of media\"\n- Omit article for general abstract concepts: \"ethics is important\"\n- Use \"a/an\" when classifying: \"an ethical violation\"\n\nStylistic use:\n- \"The\" can emphasize importance: \"the boundary of ethics\"\n- Zero article for broad concepts: \"media requires ethics\"\n\nUse for:\n- General statements: \"Ethics guides media practice.\"\n- Specific reference: \"The ethics of journalism are complex.\"\n- Classification: \"A violation occurred.\"", "examples": ["The ethics of media are complex.", "Ethics is fundamental to journalism.", "A violation of ethical standards occurred.", "The boundary of ethics must be respected.", "Media requires ethics from all practitioners."]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 7, 'Build Sentences 1', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'The ethics of media are complex.', 'The ethics of media are complex.', '["The", "ethics", "of", "media", "are", "complex."]'::jsonb),
    (activity_id_var, 'Ethics is fundamental to journalism.', 'Ethics is fundamental to journalism.', '["Ethics", "is", "fundamental", "to", "journalism."]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 8, 'Build Sentences 2', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'A violation of ethical standards occurred.', 'A violation of ethical standards occurred.', '["A", "violation", "of", "ethical", "standards", "occurred."]'::jsonb),
    (activity_id_var, 'The boundary of ethics must be respected.', 'The boundary of ethics must be respected.', '["The", "boundary", "of", "ethics", "must", "be", "respected."]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'speaking_practice', 9, 'Discuss Media Ethics', 'Practice speaking about media ethics', '{"prompts": ["What does media ethics mean to you?", "What actions cross ethical lines?", "How do you judge ethical reporting?", "What violations worry you most?", "How can ethical standards be enforced?"]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (
      lesson_id,
      activity_type,
      activity_order,
      title,
      description,
      content
    ) VALUES (
      'C1-L30',
      'speaking_improvement',
      10,
      'Speaking Improvement',
      'Read the improved version of your speech',
      '{"type": "speaking_improvement", "similarityThreshold": 70}'::jsonb
    );
END $$;



-- =========================================
-- C1 Lesson 31
-- =========================================

-- =========================================
-- Pre-fill Database with Sample Lesson Data
-- C1-L31: Cultural Identity in a Globalized World
-- =========================================
DELETE FROM lesson_activity_results WHERE lesson_id = 'C1-L31';
DELETE FROM user_progress WHERE lesson_id = 'C1-L31';
DELETE FROM lesson_history WHERE lesson_id = 'C1-L31';
DELETE FROM grammar_sentences WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'C1-L31');
DELETE FROM vocabulary_items WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'C1-L31');
DELETE FROM lesson_activities WHERE lesson_id = 'C1-L31';
DELETE FROM lessons WHERE id = 'C1-L31';

INSERT INTO lessons (id, level, lesson_number, topic) VALUES
('C1-L31', 'C1', 31, 'Cultural Identity in a Globalized World')
ON CONFLICT (id) DO UPDATE SET topic = EXCLUDED.topic;

DO $$
DECLARE
    lesson_id_var TEXT := 'C1-L31';
    activity_id_var UUID;
BEGIN
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'warm_up_speaking', 1, 'Cultural Identity', 'Discuss cultural identity', '{"prompt": "How do you balance identity and adaptation?"}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_intro', 2, 'Cultural Identity Vocabulary', 'Learn vocabulary about cultural identity', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'identity', 'ตัวตน', NULL),
    (activity_id_var, 'globalization', 'โลกาภิวัตน์', NULL),
    (activity_id_var, 'tradition', 'ประเพณี', NULL),
    (activity_id_var, 'adaptation', 'การปรับตัว', NULL),
    (activity_id_var, 'heritage', 'มรดก', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_matching_drag', 3, 'Match Cultural Identity Words', 'Match English words with Thai meanings', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'identity', 'ตัวตน', NULL),
    (activity_id_var, 'globalization', 'โลกาภิวัตน์', NULL),
    (activity_id_var, 'tradition', 'ประเพณี', NULL),
    (activity_id_var, 'adaptation', 'การปรับตัว', NULL),
    (activity_id_var, 'heritage', 'มรดก', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 4, 'Complete the Sentences 1', 'Fill with the correct word', '{"text": "Cultural ___ faces challenges from ___. Preserving ___ requires ___.", "blanks": [{"id": "blank1", "text": "identity", "options": ["identity", "globalization", "tradition", "adaptation"], "correctAnswer": "identity"}, {"id": "blank2", "text": "globalization", "options": ["globalization", "identity", "tradition", "heritage"], "correctAnswer": "globalization"}, {"id": "blank3", "text": "heritage", "options": ["heritage", "identity", "tradition", "adaptation"], "correctAnswer": "heritage"}, {"id": "blank4", "text": "adaptation", "options": ["adaptation", "identity", "tradition", "globalization"], "correctAnswer": "adaptation"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 5, 'Complete the Sentences 2', 'Fill with the correct word', '{"text": "Traditional ___ connect to ___. Successful ___ maintains ___.", "blanks": [{"id": "blank1", "text": "traditions", "options": ["traditions", "identity", "globalization", "adaptation"], "correctAnswer": "traditions"}, {"id": "blank2", "text": "heritage", "options": ["heritage", "identity", "tradition", "adaptation"], "correctAnswer": "heritage"}, {"id": "blank3", "text": "adaptation", "options": ["adaptation", "identity", "tradition", "globalization"], "correctAnswer": "adaptation"}, {"id": "blank4", "text": "identity", "options": ["identity", "tradition", "globalization", "heritage"], "correctAnswer": "identity"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_explanation', 6, 'Participle Clauses', 'Learn participle clauses', '{"rules": "Participle clauses:\n- Present participle (-ing): \"Balancing identity, people adapt.\"\n- Past participle (-ed): \"Influenced by globalization, cultures change.\"\n- Perfect participle (having + past participle): \"Having preserved traditions, they maintain identity.\"\n\nUse for:\n- Showing simultaneous actions: \"Balancing identity, you adapt to change.\"\n- Showing cause: \"Influenced by globalization, people modify traditions.\"\n- Showing time sequence: \"Having kept traditions, they preserve heritage.\"", "examples": ["Balancing identity and adaptation, people navigate globalization.", "Influenced by globalization, cultures evolve while maintaining heritage.", "Having preserved traditions, communities maintain cultural identity.", "Adapting to change, people keep their heritage alive.", "Shaped by both tradition and globalization, identity evolves."]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 7, 'Build Sentences 1', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'Balancing identity and adaptation, people navigate globalization.', 'Balancing identity and adaptation, people navigate globalization.', '["Balancing", "identity", "and", "adaptation,", "people", "navigate", "globalization."]'::jsonb),
    (activity_id_var, 'Influenced by globalization, cultures evolve while maintaining heritage.', 'Influenced by globalization, cultures evolve while maintaining heritage.', '["Influenced", "by", "globalization,", "cultures", "evolve", "while", "maintaining", "heritage."]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 8, 'Build Sentences 2', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'Having preserved traditions, communities maintain cultural identity.', 'Having preserved traditions, communities maintain cultural identity.', '["Having", "preserved", "traditions,", "communities", "maintain", "cultural", "identity."]'::jsonb),
    (activity_id_var, 'Adapting to change, people keep their heritage alive.', 'Adapting to change, people keep their heritage alive.', '["Adapting", "to", "change,", "people", "keep", "their", "heritage", "alive."]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'speaking_practice', 9, 'Discuss Cultural Identity', 'Practice speaking about cultural identity', '{"prompts": ["What defines your cultural identity?", "How has globalization affected it?", "What traditions do you keep?", "What changes have you accepted?", "How do you adapt without losing identity?"]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (
      lesson_id,
      activity_type,
      activity_order,
      title,
      description,
      content
    ) VALUES (
      'C1-L31',
      'speaking_improvement',
      10,
      'Speaking Improvement',
      'Read the improved version of your speech',
      '{"type": "speaking_improvement", "similarityThreshold": 70}'::jsonb
    );
END $$;



-- =========================================
-- C1 Lesson 32
-- =========================================

-- =========================================
-- Pre-fill Database with Sample Lesson Data
-- C1-L32: Preserving Traditions in Modern Societies
-- =========================================
DELETE FROM lesson_activity_results WHERE lesson_id = 'C1-L32';
DELETE FROM user_progress WHERE lesson_id = 'C1-L32';
DELETE FROM lesson_history WHERE lesson_id = 'C1-L32';
DELETE FROM grammar_sentences WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'C1-L32');
DELETE FROM vocabulary_items WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'C1-L32');
DELETE FROM lesson_activities WHERE lesson_id = 'C1-L32';
DELETE FROM lessons WHERE id = 'C1-L32';

INSERT INTO lessons (id, level, lesson_number, topic) VALUES
('C1-L32', 'C1', 32, 'Preserving Traditions in Modern Societies')
ON CONFLICT (id) DO UPDATE SET topic = EXCLUDED.topic;

DO $$
DECLARE
    lesson_id_var TEXT := 'C1-L32';
    activity_id_var UUID;
BEGIN
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'warm_up_speaking', 1, 'Preserving Traditions', 'Discuss preserving traditions', '{"prompt": "What traditions have you kept over time?"}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_intro', 2, 'Traditions Vocabulary', 'Learn vocabulary about traditions', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'preservation', 'การอนุรักษ์', NULL),
    (activity_id_var, 'custom', 'ประเพณี', NULL),
    (activity_id_var, 'evolution', 'วิวัฒนาการ', NULL),
    (activity_id_var, 'continuity', 'ความต่อเนื่อง', NULL),
    (activity_id_var, 'relevance', 'ความเกี่ยวข้อง', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_matching_drag', 3, 'Match Traditions Words', 'Match English words with Thai meanings', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'preservation', 'การอนุรักษ์', NULL),
    (activity_id_var, 'custom', 'ประเพณี', NULL),
    (activity_id_var, 'evolution', 'วิวัฒนาการ', NULL),
    (activity_id_var, 'continuity', 'ความต่อเนื่อง', NULL),
    (activity_id_var, 'relevance', 'ความเกี่ยวข้อง', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 4, 'Complete the Sentences 1', 'Fill with the correct word', '{"text": "Cultural ___ requires ___. Traditional ___ undergo ___.", "blanks": [{"id": "blank1", "text": "preservation", "options": ["preservation", "custom", "evolution", "continuity"], "correctAnswer": "preservation"}, {"id": "blank2", "text": "continuity", "options": ["continuity", "preservation", "custom", "relevance"], "correctAnswer": "continuity"}, {"id": "blank3", "text": "customs", "options": ["customs", "preservation", "evolution", "continuity"], "correctAnswer": "customs"}, {"id": "blank4", "text": "evolution", "options": ["evolution", "preservation", "custom", "continuity"], "correctAnswer": "evolution"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 5, 'Complete the Sentences 2', 'Fill with the correct word', '{"text": "Maintaining ___ ensures ___. Modern ___ requires ___.", "blanks": [{"id": "blank1", "text": "traditions", "options": ["traditions", "preservation", "custom", "evolution"], "correctAnswer": "traditions"}, {"id": "blank2", "text": "relevance", "options": ["relevance", "preservation", "continuity", "evolution"], "correctAnswer": "relevance"}, {"id": "blank3", "text": "preservation", "options": ["preservation", "custom", "evolution", "continuity"], "correctAnswer": "preservation"}, {"id": "blank4", "text": "adaptation", "options": ["adaptation", "preservation", "custom", "evolution"], "correctAnswer": "adaptation"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_explanation', 6, 'Advanced Perfect Aspect', 'Learn advanced perfect forms', '{"rules": "Advanced perfect aspect:\n- Present perfect: \"I have kept traditions for years.\"\n- Past perfect: \"I had preserved customs before they changed.\"\n- Future perfect: \"I will have maintained traditions by then.\"\n- Perfect continuous: \"I have been preserving customs for decades.\"\n\nUse for:\n- Completed actions with present relevance: \"I have kept traditions over time.\"\n- Past before past: \"I had preserved customs before modernization.\"\n- Future completion: \"I will have maintained traditions by next year.\"", "examples": ["I have kept traditions for many years.", "I had preserved customs before they evolved.", "I will have maintained traditions by next generation.", "I have been preserving customs for decades.", "Having kept traditions, communities maintain cultural continuity."]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 7, 'Build Sentences 1', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'I have kept traditions for many years.', 'I have kept traditions for many years.', '["I", "have", "kept", "traditions", "for", "many", "years."]'::jsonb),
    (activity_id_var, 'I had preserved customs before they evolved.', 'I had preserved customs before they evolved.', '["I", "had", "preserved", "customs", "before", "they", "evolved."]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 8, 'Build Sentences 2', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'I have been preserving customs for decades.', 'I have been preserving customs for decades.', '["I", "have", "been", "preserving", "customs", "for", "decades."]'::jsonb),
    (activity_id_var, 'Having kept traditions, communities maintain cultural continuity.', 'Having kept traditions, communities maintain cultural continuity.', '["Having", "kept", "traditions,", "communities", "maintain", "cultural", "continuity."]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'speaking_practice', 9, 'Discuss Traditions', 'Practice speaking about preserving traditions', '{"prompts": ["What traditions remain important to you?", "What traditions have changed?", "How are traditions preserved today?", "Why do some traditions disappear?", "How can traditions adapt to modern life?"]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (
      lesson_id,
      activity_type,
      activity_order,
      title,
      description,
      content
    ) VALUES (
      'C1-L32',
      'speaking_improvement',
      10,
      'Speaking Improvement',
      'Read the improved version of your speech',
      '{"type": "speaking_improvement", "similarityThreshold": 70}'::jsonb
    );
END $$;



-- =========================================
-- C1 Lesson 33
-- =========================================

-- =========================================
-- Pre-fill Database with Sample Lesson Data
-- C1-L33: Cultural Appropriation vs Appreciation
-- =========================================
DELETE FROM lesson_activity_results WHERE lesson_id = 'C1-L33';
DELETE FROM user_progress WHERE lesson_id = 'C1-L33';
DELETE FROM lesson_history WHERE lesson_id = 'C1-L33';
DELETE FROM grammar_sentences WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'C1-L33');
DELETE FROM vocabulary_items WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'C1-L33');
DELETE FROM lesson_activities WHERE lesson_id = 'C1-L33';
DELETE FROM lessons WHERE id = 'C1-L33';

INSERT INTO lessons (id, level, lesson_number, topic) VALUES
('C1-L33', 'C1', 33, 'Cultural Appropriation vs Appreciation')
ON CONFLICT (id) DO UPDATE SET topic = EXCLUDED.topic;

DO $$
DECLARE
    lesson_id_var TEXT := 'C1-L33';
    activity_id_var UUID;
BEGIN
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'warm_up_speaking', 1, 'Cultural Appropriation', 'Discuss cultural appropriation and appreciation', '{"prompt": "What separates appreciation from misuse?"}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_intro', 2, 'Cultural Exchange Vocabulary', 'Learn vocabulary about cultural exchange', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'appropriation', 'การยึดครอง', NULL),
    (activity_id_var, 'appreciation', 'การชื่นชม', NULL),
    (activity_id_var, 'exchange', 'การแลกเปลี่ยน', NULL),
    (activity_id_var, 'intent', 'เจตนา', NULL),
    (activity_id_var, 'respect', 'ความเคารพ', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_matching_drag', 3, 'Match Cultural Exchange Words', 'Match English words with Thai meanings', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'appropriation', 'การยึดครอง', NULL),
    (activity_id_var, 'appreciation', 'การชื่นชม', NULL),
    (activity_id_var, 'exchange', 'การแลกเปลี่ยน', NULL),
    (activity_id_var, 'intent', 'เจตนา', NULL),
    (activity_id_var, 'respect', 'ความเคารพ', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 4, 'Complete the Sentences 1', 'Fill with the correct word', '{"text": "Cultural ___ differs from ___. Respectful ___ requires ___.", "blanks": [{"id": "blank1", "text": "appropriation", "options": ["appropriation", "appreciation", "exchange", "intent"], "correctAnswer": "appropriation"}, {"id": "blank2", "text": "appreciation", "options": ["appreciation", "appropriation", "exchange", "respect"], "correctAnswer": "appreciation"}, {"id": "blank3", "text": "exchange", "options": ["exchange", "appropriation", "appreciation", "intent"], "correctAnswer": "exchange"}, {"id": "blank4", "text": "respect", "options": ["respect", "appropriation", "appreciation", "intent"], "correctAnswer": "respect"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 5, 'Complete the Sentences 2', 'Fill with the correct word', '{"text": "Understanding ___ matters. Positive ___ promotes cultural ___.", "blanks": [{"id": "blank1", "text": "intent", "options": ["intent", "appropriation", "appreciation", "exchange"], "correctAnswer": "intent"}, {"id": "blank2", "text": "appreciation", "options": ["appreciation", "appropriation", "exchange", "respect"], "correctAnswer": "appreciation"}, {"id": "blank3", "text": "exchange", "options": ["exchange", "appropriation", "appreciation", "respect"], "correctAnswer": "exchange"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_explanation', 6, 'Cleft Sentences and Emphatic Structures', 'Learn cleft sentences for emphasis', '{"rules": "Cleft sentences emphasize specific elements:\n- It-cleft: \"It is respect that separates appreciation from appropriation.\"\n- What-cleft: \"What divides respect from misuse is intent.\"\n- Wh-cleft: \"What matters is respectful engagement.\"\n\nStructure:\n- It + be + emphasized element + that/who clause\n- What + verb + be + emphasized element\n\nUse for:\n- Emphasizing importance: \"It is intent that determines appropriation.\"\n- Highlighting focus: \"What matters is respectful exchange.\"\n- Clarifying meaning: \"What separates appreciation is respect.\"", "examples": ["It is respect that separates appreciation from appropriation.", "What divides respect from misuse is intent.", "What matters is respectful cultural exchange.", "It is intent that determines whether exchange is appropriate.", "What makes exchange respectful is understanding."]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 7, 'Build Sentences 1', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'It is respect that separates appreciation from appropriation.', 'It is respect that separates appreciation from appropriation.', '["It", "is", "respect", "that", "separates", "appreciation", "from", "appropriation."]'::jsonb),
    (activity_id_var, 'What divides respect from misuse is intent.', 'What divides respect from misuse is intent.', '["What", "divides", "respect", "from", "misuse", "is", "intent."]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 8, 'Build Sentences 2', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'What matters is respectful cultural exchange.', 'What matters is respectful cultural exchange.', '["What", "matters", "is", "respectful", "cultural", "exchange."]'::jsonb),
    (activity_id_var, 'It is intent that determines whether exchange is appropriate.', 'It is intent that determines whether exchange is appropriate.', '["It", "is", "intent", "that", "determines", "whether", "exchange", "is", "appropriate."]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'speaking_practice', 9, 'Discuss Cultural Exchange', 'Practice speaking about cultural appropriation', '{"prompts": ["How do you define cultural appropriation?", "When does appreciation become harmful?", "What makes cultural exchange respectful?", "Why is intent important?", "How can people engage respectfully with cultures?"]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (
      lesson_id,
      activity_type,
      activity_order,
      title,
      description,
      content
    ) VALUES (
      'C1-L33',
      'speaking_improvement',
      10,
      'Speaking Improvement',
      'Read the improved version of your speech',
      '{"type": "speaking_improvement", "similarityThreshold": 70}'::jsonb
    );
END $$;



-- =========================================
-- C1 Lesson 34
-- =========================================

-- =========================================
-- Pre-fill Database with Sample Lesson Data
-- C1-L34: Language and Cultural Power
-- =========================================
DELETE FROM lesson_activity_results WHERE lesson_id = 'C1-L34';
DELETE FROM user_progress WHERE lesson_id = 'C1-L34';
DELETE FROM lesson_history WHERE lesson_id = 'C1-L34';
DELETE FROM grammar_sentences WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'C1-L34');
DELETE FROM vocabulary_items WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'C1-L34');
DELETE FROM lesson_activities WHERE lesson_id = 'C1-L34';
DELETE FROM lessons WHERE id = 'C1-L34';

INSERT INTO lessons (id, level, lesson_number, topic) VALUES
('C1-L34', 'C1', 34, 'Language and Cultural Power')
ON CONFLICT (id) DO UPDATE SET topic = EXCLUDED.topic;

DO $$
DECLARE
    lesson_id_var TEXT := 'C1-L34';
    activity_id_var UUID;
BEGIN
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'warm_up_speaking', 1, 'Language and Power', 'Discuss language and cultural power', '{"prompt": "How does language influence power?"}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_intro', 2, 'Language Power Vocabulary', 'Learn vocabulary about language and power', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'dominance', 'การครอบงำ', NULL),
    (activity_id_var, 'status', 'สถานะ', NULL),
    (activity_id_var, 'opportunity', 'โอกาส', NULL),
    (activity_id_var, 'diversity', 'ความหลากหลาย', NULL),
    (activity_id_var, 'minority', 'ชนกลุ่มน้อย', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_matching_drag', 3, 'Match Language Power Words', 'Match English words with Thai meanings', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'dominance', 'การครอบงำ', NULL),
    (activity_id_var, 'status', 'สถานะ', NULL),
    (activity_id_var, 'opportunity', 'โอกาส', NULL),
    (activity_id_var, 'diversity', 'ความหลากหลาย', NULL),
    (activity_id_var, 'minority', 'ชนกลุ่มน้อย', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 4, 'Complete the Sentences 1', 'Fill with the correct word', '{"text": "Language ___ signals ___. Linguistic ___ affects ___.", "blanks": [{"id": "blank1", "text": "dominance", "options": ["dominance", "status", "opportunity", "diversity"], "correctAnswer": "dominance"}, {"id": "blank2", "text": "status", "options": ["status", "dominance", "opportunity", "minority"], "correctAnswer": "status"}, {"id": "blank3", "text": "diversity", "options": ["diversity", "dominance", "status", "opportunity"], "correctAnswer": "diversity"}, {"id": "blank4", "text": "opportunity", "options": ["opportunity", "dominance", "status", "diversity"], "correctAnswer": "opportunity"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 5, 'Complete the Sentences 2', 'Fill with the correct word', '{"text": "Protecting ___ languages preserves ___. ___ communities need support.", "blanks": [{"id": "blank1", "text": "minority", "options": ["minority", "dominance", "status", "diversity"], "correctAnswer": "minority"}, {"id": "blank2", "text": "diversity", "options": ["diversity", "dominance", "status", "opportunity"], "correctAnswer": "diversity"}, {"id": "blank3", "text": "Minority", "options": ["Minority", "Dominance", "Status", "Diversity"], "correctAnswer": "Minority"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_explanation', 6, 'Nominal Clauses', 'Learn about nominal clauses', '{"rules": "Nominal clauses function as nouns:\n- Subject: \"What language signals affects status.\"\n- Object: \"I believe that language influences power.\"\n- Complement: \"The question is how language affects opportunity.\"\n\nTypes:\n- That-clauses: \"I think that language matters.\"\n- Wh-clauses: \"What you speak determines your access.\"\n- Whether/if: \"The issue is whether dominance is harmful.\"\n\nUse for:\n- Expressing opinions: \"What I think is that language shapes power.\"\n- Asking questions: \"How does language affect opportunity?\"\n- Making statements: \"That language matters is clear.\"", "examples": ["What language signals affects social status.", "I believe that language influences opportunity.", "The question is how language affects power.", "Whether linguistic dominance is harmful remains debated.", "That language matters is widely accepted."]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 7, 'Build Sentences 1', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'What language signals affects social status.', 'What language signals affects social status.', '["What", "language", "signals", "affects", "social", "status."]'::jsonb),
    (activity_id_var, 'I believe that language influences opportunity.', 'I believe that language influences opportunity.', '["I", "believe", "that", "language", "influences", "opportunity."]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 8, 'Build Sentences 2', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'The question is how language affects power.', 'The question is how language affects power.', '["The", "question", "is", "how", "language", "affects", "power."]'::jsonb),
    (activity_id_var, 'Whether linguistic dominance is harmful remains debated.', 'Whether linguistic dominance is harmful remains debated.', '["Whether", "linguistic", "dominance", "is", "harmful", "remains", "debated."]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'speaking_practice', 9, 'Discuss Language and Power', 'Practice speaking about language and power', '{"prompts": ["How does language signal status?", "What happens when one language dominates?", "How does language affect opportunity?", "Why is linguistic diversity important?", "How can minority languages be protected?"]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (
      lesson_id,
      activity_type,
      activity_order,
      title,
      description,
      content
    ) VALUES (
      'C1-L34',
      'speaking_improvement',
      10,
      'Speaking Improvement',
      'Read the improved version of your speech',
      '{"type": "speaking_improvement", "similarityThreshold": 70}'::jsonb
    );
END $$;



-- =========================================
-- C1 Lesson 35
-- =========================================

-- =========================================
-- Pre-fill Database with Sample Lesson Data
-- C1-L35: Multicultural Education
-- =========================================
DELETE FROM lesson_activity_results WHERE lesson_id = 'C1-L35';
DELETE FROM user_progress WHERE lesson_id = 'C1-L35';
DELETE FROM lesson_history WHERE lesson_id = 'C1-L35';
DELETE FROM grammar_sentences WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'C1-L35');
DELETE FROM vocabulary_items WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'C1-L35');
DELETE FROM lesson_activities WHERE lesson_id = 'C1-L35';
DELETE FROM lessons WHERE id = 'C1-L35';

INSERT INTO lessons (id, level, lesson_number, topic) VALUES
('C1-L35', 'C1', 35, 'Multicultural Education')
ON CONFLICT (id) DO UPDATE SET topic = EXCLUDED.topic;

DO $$
DECLARE
    lesson_id_var TEXT := 'C1-L35';
    activity_id_var UUID;
BEGIN
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'warm_up_speaking', 1, 'Multicultural Education', 'Discuss multicultural education', '{"prompt": "What makes classrooms inclusive?"}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_intro', 2, 'Multicultural Education Vocabulary', 'Learn vocabulary about multicultural education', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'inclusion', 'การรวมเข้า', NULL),
    (activity_id_var, 'diversity', 'ความหลากหลาย', NULL),
    (activity_id_var, 'challenge', 'ความท้าทาย', NULL),
    (activity_id_var, 'support', 'การสนับสนุน', NULL),
    (activity_id_var, 'role', 'บทบาท', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_matching_drag', 3, 'Match Multicultural Education Words', 'Match English words with Thai meanings', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'inclusion', 'การรวมเข้า', NULL),
    (activity_id_var, 'diversity', 'ความหลากหลาย', NULL),
    (activity_id_var, 'challenge', 'ความท้าทาย', NULL),
    (activity_id_var, 'support', 'การสนับสนุน', NULL),
    (activity_id_var, 'role', 'บทบาท', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 4, 'Complete the Sentences 1', 'Fill with the correct word', '{"text": "Diverse classrooms promote ___. ___ arise in multicultural settings. ___ helps improve ___.", "blanks": [{"id": "blank1", "text": "inclusion", "options": ["inclusion", "diversity", "challenge", "support"], "correctAnswer": "inclusion"}, {"id": "blank2", "text": "Challenges", "options": ["Challenges", "Inclusion", "Diversity", "Support"], "correctAnswer": "Challenges"}, {"id": "blank3", "text": "Support", "options": ["Support", "Inclusion", "Diversity", "Challenge"], "correctAnswer": "Support"}, {"id": "blank4", "text": "inclusion", "options": ["inclusion", "diversity", "challenge", "support"], "correctAnswer": "inclusion"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 5, 'Complete the Sentences 2', 'Fill with the correct word', '{"text": "Teachers play a key ___. Students ___ each other. ___ benefits everyone.", "blanks": [{"id": "blank1", "text": "role", "options": ["role", "inclusion", "diversity", "support"], "correctAnswer": "role"}, {"id": "blank2", "text": "support", "options": ["support", "inclusion", "diversity", "role"], "correctAnswer": "support"}, {"id": "blank3", "text": "Diversity", "options": ["Diversity", "Inclusion", "Support", "Role"], "correctAnswer": "Diversity"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_explanation', 6, 'Cohesion and Ellipsis', 'Learn cohesion and ellipsis', '{"rules": "Cohesion and ellipsis:\n- Ellipsis: \"Diverse classrooms benefit students, and inclusive ones do too.\"\n- Substitution: \"Teachers support inclusion, and students do so as well.\"\n- Reference: \"Multicultural settings create challenges; these challenges require support.\"\n\nUse for:\n- Avoiding repetition: \"Teachers support inclusion, and students do too.\"\n- Creating flow: \"Diverse classrooms benefit everyone; such diversity enriches learning.\"\n- Connecting ideas: \"Challenges arise; these challenges need addressing.\"", "examples": ["Diverse classrooms benefit students, and inclusive ones do too.", "Teachers support inclusion, and students do so as well.", "Multicultural settings create challenges; these challenges require support.", "Inclusion improves learning; such inclusion benefits everyone.", "Students support each other; this support creates community."]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 7, 'Build Sentences 1', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'Diverse classrooms benefit students, and inclusive ones do too.', 'Diverse classrooms benefit students, and inclusive ones do too.', '["Diverse", "classrooms", "benefit", "students,", "and", "inclusive", "ones", "do", "too."]'::jsonb),
    (activity_id_var, 'Teachers support inclusion, and students do so as well.', 'Teachers support inclusion, and students do so as well.', '["Teachers", "support", "inclusion,", "and", "students", "do", "so", "as", "well."]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 8, 'Build Sentences 2', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'Multicultural settings create challenges; these challenges require support.', 'Multicultural settings create challenges; these challenges require support.', '["Multicultural", "settings", "create", "challenges;", "these", "challenges", "require", "support."]'::jsonb),
    (activity_id_var, 'Inclusion improves learning; such inclusion benefits everyone.', 'Inclusion improves learning; such inclusion benefits everyone.', '["Inclusion", "improves", "learning;", "such", "inclusion", "benefits", "everyone."]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'speaking_practice', 9, 'Discuss Multicultural Education', 'Practice speaking about multicultural education', '{"prompts": ["How do diverse classrooms benefit students?", "What challenges arise in multicultural settings?", "How can inclusion be improved?", "What role do teachers play?", "How do students support inclusion?"]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (
      lesson_id,
      activity_type,
      activity_order,
      title,
      description,
      content
    ) VALUES (
      'C1-L35',
      'speaking_improvement',
      10,
      'Speaking Improvement',
      'Read the improved version of your speech',
      '{"type": "speaking_improvement", "similarityThreshold": 70}'::jsonb
    );
END $$;



-- =========================================
-- C1 Lesson 36
-- =========================================

-- =========================================
-- Pre-fill Database with Sample Lesson Data
-- C1-L36: Global Citizenship
-- =========================================
DELETE FROM lesson_activity_results WHERE lesson_id = 'C1-L36';
DELETE FROM user_progress WHERE lesson_id = 'C1-L36';
DELETE FROM lesson_history WHERE lesson_id = 'C1-L36';
DELETE FROM grammar_sentences WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'C1-L36');
DELETE FROM vocabulary_items WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'C1-L36');
DELETE FROM lesson_activities WHERE lesson_id = 'C1-L36';
DELETE FROM lessons WHERE id = 'C1-L36';

INSERT INTO lessons (id, level, lesson_number, topic) VALUES
('C1-L36', 'C1', 36, 'Global Citizenship')
ON CONFLICT (id) DO UPDATE SET topic = EXCLUDED.topic;

DO $$
DECLARE
    lesson_id_var TEXT := 'C1-L36';
    activity_id_var UUID;
BEGIN
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'warm_up_speaking', 1, 'Global Citizenship', 'Discuss global citizenship', '{"prompt": "What does being a global citizen mean to you?"}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_intro', 2, 'Global Citizenship Vocabulary', 'Learn vocabulary about global citizenship', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'citizenship', 'ความเป็นพลเมือง', NULL),
    (activity_id_var, 'responsibility', 'ความรับผิดชอบ', NULL),
    (activity_id_var, 'awareness', 'การตระหนัก', NULL),
    (activity_id_var, 'engagement', 'การมีส่วนร่วม', NULL),
    (activity_id_var, 'impact', 'ผลกระทบ', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_matching_drag', 3, 'Match Global Citizenship Words', 'Match English words with Thai meanings', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'citizenship', 'ความเป็นพลเมือง', NULL),
    (activity_id_var, 'responsibility', 'ความรับผิดชอบ', NULL),
    (activity_id_var, 'awareness', 'การตระหนัก', NULL),
    (activity_id_var, 'engagement', 'การมีส่วนร่วม', NULL),
    (activity_id_var, 'impact', 'ผลกระทบ', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 4, 'Complete the Sentences 1', 'Fill with the correct word', '{"text": "Global ___ involves ___. ___ of global issues creates ___.", "blanks": [{"id": "blank1", "text": "citizenship", "options": ["citizenship", "responsibility", "awareness", "engagement"], "correctAnswer": "citizenship"}, {"id": "blank2", "text": "responsibility", "options": ["responsibility", "citizenship", "awareness", "engagement"], "correctAnswer": "responsibility"}, {"id": "blank3", "text": "Awareness", "options": ["Awareness", "Citizenship", "Responsibility", "Engagement"], "correctAnswer": "Awareness"}, {"id": "blank4", "text": "impact", "options": ["impact", "citizenship", "responsibility", "engagement"], "correctAnswer": "impact"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 5, 'Complete the Sentences 2', 'Fill with the correct word', '{"text": "Active ___ shows global ___. Student ___ addresses global challenges.", "blanks": [{"id": "blank1", "text": "engagement", "options": ["engagement", "citizenship", "responsibility", "awareness"], "correctAnswer": "engagement"}, {"id": "blank2", "text": "citizenship", "options": ["citizenship", "responsibility", "awareness", "impact"], "correctAnswer": "citizenship"}, {"id": "blank3", "text": "engagement", "options": ["engagement", "citizenship", "responsibility", "awareness"], "correctAnswer": "engagement"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_explanation', 6, 'Inversion: Never/Rarely', 'Learn inversion with never and rarely', '{"rules": "Inversion with never/rarely:\n- \"Never have I acted as a global citizen.\" (formal emphasis)\n- \"Rarely do students engage globally.\" (emphasis on infrequency)\n- \"Never before have I considered global impact.\" (past emphasis)\n\nStructure:\n- Never/Rarely + auxiliary + subject + verb\n- Used for emphasis and formal tone\n\nUse for:\n- Emphasizing rarity: \"Rarely do people act as global citizens.\"\n- Formal statements: \"Never have I seen such global awareness.\"\n- Highlighting infrequency: \"Rarely is global citizenship fully understood.\"", "examples": ["Never have I acted as a global citizen without considering impact.", "Rarely do students engage globally without awareness.", "Never before have I considered my global responsibilities.", "Rarely is global citizenship fully understood by students.", "Never do global issues fail to affect local communities."]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 7, 'Build Sentences 1', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'Never have I acted as a global citizen without considering impact.', 'Never have I acted as a global citizen without considering impact.', '["Never", "have", "I", "acted", "as", "a", "global", "citizen", "without", "considering", "impact."]'::jsonb),
    (activity_id_var, 'Rarely do students engage globally without awareness.', 'Rarely do students engage globally without awareness.', '["Rarely", "do", "students", "engage", "globally", "without", "awareness."]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 8, 'Build Sentences 2', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'Never before have I considered my global responsibilities.', 'Never before have I considered my global responsibilities.', '["Never", "before", "have", "I", "considered", "my", "global", "responsibilities."]'::jsonb),
    (activity_id_var, 'Rarely is global citizenship fully understood by students.', 'Rarely is global citizenship fully understood by students.', '["Rarely", "is", "global", "citizenship", "fully", "understood", "by", "students."]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'speaking_practice', 9, 'Discuss Global Citizenship', 'Practice speaking about global citizenship', '{"prompts": ["What responsibilities come with global citizenship?", "How do global issues affect you?", "What actions show global awareness?", "How can students engage globally?", "Why is global citizenship important today?"]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (
      lesson_id,
      activity_type,
      activity_order,
      title,
      description,
      content
    ) VALUES (
      'C1-L36',
      'speaking_improvement',
      10,
      'Speaking Improvement',
      'Read the improved version of your speech',
      '{"type": "speaking_improvement", "similarityThreshold": 70}'::jsonb
    );
END $$;



-- =========================================
-- C1 Lesson 37
-- =========================================

-- =========================================
-- Pre-fill Database with Sample Lesson Data
-- C1-L37: Cross-cultural Misunderstandings
-- =========================================
DELETE FROM lesson_activity_results WHERE lesson_id = 'C1-L37';
DELETE FROM user_progress WHERE lesson_id = 'C1-L37';
DELETE FROM lesson_history WHERE lesson_id = 'C1-L37';
DELETE FROM grammar_sentences WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'C1-L37');
DELETE FROM vocabulary_items WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'C1-L37');
DELETE FROM lesson_activities WHERE lesson_id = 'C1-L37';
DELETE FROM lessons WHERE id = 'C1-L37';

INSERT INTO lessons (id, level, lesson_number, topic) VALUES
('C1-L37', 'C1', 37, 'Cross-cultural Misunderstandings')
ON CONFLICT (id) DO UPDATE SET topic = EXCLUDED.topic;

DO $$
DECLARE
    lesson_id_var TEXT := 'C1-L37';
    activity_id_var UUID;
BEGIN
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'warm_up_speaking', 1, 'Cross-cultural Misunderstandings', 'Discuss cross-cultural misunderstandings', '{"prompt": "What misunderstandings arise across cultures?"}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_intro', 2, 'Misunderstanding Vocabulary', 'Learn vocabulary about misunderstandings', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'misunderstanding', 'ความเข้าใจผิด', NULL),
    (activity_id_var, 'conflict', 'ความขัดแย้ง', NULL),
    (activity_id_var, 'prevention', 'การป้องกัน', NULL),
    (activity_id_var, 'norm', 'บรรทัดฐาน', NULL),
    (activity_id_var, 'mistake', 'ข้อผิดพลาด', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_matching_drag', 3, 'Match Misunderstanding Words', 'Match English words with Thai meanings', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'misunderstanding', 'ความเข้าใจผิด', NULL),
    (activity_id_var, 'conflict', 'ความขัดแย้ง', NULL),
    (activity_id_var, 'prevention', 'การป้องกัน', NULL),
    (activity_id_var, 'norm', 'บรรทัดฐาน', NULL),
    (activity_id_var, 'mistake', 'ข้อผิดพลาด', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 4, 'Complete the Sentences 1', 'Fill with the correct word', '{"text": "Cultural ___ lead to ___. Understanding ___ helps ___.", "blanks": [{"id": "blank1", "text": "misunderstandings", "options": ["misunderstandings", "conflict", "prevention", "norm"], "correctAnswer": "misunderstandings"}, {"id": "blank2", "text": "conflict", "options": ["conflict", "misunderstanding", "prevention", "mistake"], "correctAnswer": "conflict"}, {"id": "blank3", "text": "norms", "options": ["norms", "misunderstanding", "conflict", "prevention"], "correctAnswer": "norms"}, {"id": "blank4", "text": "prevention", "options": ["prevention", "misunderstanding", "conflict", "norm"], "correctAnswer": "prevention"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 5, 'Complete the Sentences 2', 'Fill with the correct word', '{"text": "Learning from ___ improves understanding. Cultural ___ prevent ___.", "blanks": [{"id": "blank1", "text": "mistakes", "options": ["mistakes", "misunderstanding", "conflict", "norm"], "correctAnswer": "mistakes"}, {"id": "blank2", "text": "norms", "options": ["norms", "misunderstanding", "conflict", "prevention"], "correctAnswer": "norms"}, {"id": "blank3", "text": "conflict", "options": ["conflict", "misunderstanding", "norm", "mistake"], "correctAnswer": "conflict"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_explanation', 6, 'Mixed Conditionals', 'Learn mixed conditional structures', '{"rules": "Mixed conditionals combine different time references:\n- Mixed 2/3: \"If I had known the norm (past), I would act differently now (present).\"\n- Mixed 3/2: \"If I had understood (past), I would not make mistakes now (present).\"\n\nStructures:\n- If + past perfect, would + base form (past condition, present result)\n- If + past simple, would have + past participle (present condition, past result)\n\nUse for:\n- Hypothetical past affecting present: \"If I had known the norm, I would avoid conflict now.\"\n- Unreal present affecting past: \"If I were more aware, I would not have misunderstood.\"", "examples": ["If I had known the norm, I would act differently now.", "If I had understood the culture, I would avoid misunderstandings now.", "If I were more aware, I would not have made that mistake.", "If I had learned the norms earlier, I would communicate better now.", "If I had known the customs, I would not have caused conflict."]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 7, 'Build Sentences 1', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'If I had known the norm, I would act differently now.', 'If I had known the norm, I would act differently now.', '["If", "I", "had", "known", "the", "norm,", "I", "would", "act", "differently", "now."]'::jsonb),
    (activity_id_var, 'If I had understood the culture, I would avoid misunderstandings now.', 'If I had understood the culture, I would avoid misunderstandings now.', '["If", "I", "had", "understood", "the", "culture,", "I", "would", "avoid", "misunderstandings", "now."]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 8, 'Build Sentences 2', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'If I had learned the norms earlier, I would communicate better now.', 'If I had learned the norms earlier, I would communicate better now.', '["If", "I", "had", "learned", "the", "norms", "earlier,", "I", "would", "communicate", "better", "now."]'::jsonb),
    (activity_id_var, 'If I had known the customs, I would not have caused conflict.', 'If I had known the customs, I would not have caused conflict.', '["If", "I", "had", "known", "the", "customs,", "I", "would", "not", "have", "caused", "conflict."]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'speaking_practice', 9, 'Discuss Misunderstandings', 'Practice speaking about cross-cultural misunderstandings', '{"prompts": ["What cultural misunderstandings have you seen?", "How could they have been avoided?", "What helps prevent conflict?", "How do you learn cultural norms?", "How should mistakes be handled?"]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (
      lesson_id,
      activity_type,
      activity_order,
      title,
      description,
      content
    ) VALUES (
      'C1-L37',
      'speaking_improvement',
      10,
      'Speaking Improvement',
      'Read the improved version of your speech',
      '{"type": "speaking_improvement", "similarityThreshold": 70}'::jsonb
    );
END $$;



-- =========================================
-- C1 Lesson 38
-- =========================================

-- =========================================
-- Pre-fill Database with Sample Lesson Data
-- C1-L38: National Identity Among Youth
-- =========================================
DELETE FROM lesson_activity_results WHERE lesson_id = 'C1-L38';
DELETE FROM user_progress WHERE lesson_id = 'C1-L38';
DELETE FROM lesson_history WHERE lesson_id = 'C1-L38';
DELETE FROM grammar_sentences WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'C1-L38');
DELETE FROM vocabulary_items WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'C1-L38');
DELETE FROM lesson_activities WHERE lesson_id = 'C1-L38';
DELETE FROM lessons WHERE id = 'C1-L38';

INSERT INTO lessons (id, level, lesson_number, topic) VALUES
('C1-L38', 'C1', 38, 'National Identity Among Youth')
ON CONFLICT (id) DO UPDATE SET topic = EXCLUDED.topic;

DO $$
DECLARE
    lesson_id_var TEXT := 'C1-L38';
    activity_id_var UUID;
BEGIN
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'warm_up_speaking', 1, 'National Identity', 'Discuss national identity among youth', '{"prompt": "How do young people view national identity today?"}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_intro', 2, 'National Identity Vocabulary', 'Learn vocabulary about national identity', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'identity', 'ตัวตน', NULL),
    (activity_id_var, 'youth', 'เยาวชน', NULL),
    (activity_id_var, 'influence', 'อิทธิพล', NULL),
    (activity_id_var, 'globalization', 'โลกาภิวัตน์', NULL),
    (activity_id_var, 'expression', 'การแสดงออก', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_matching_drag', 3, 'Match National Identity Words', 'Match English words with Thai meanings', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'identity', 'ตัวตน', NULL),
    (activity_id_var, 'youth', 'เยาวชน', NULL),
    (activity_id_var, 'influence', 'อิทธิพล', NULL),
    (activity_id_var, 'globalization', 'โลกาภิวัตน์', NULL),
    (activity_id_var, 'expression', 'การแสดงออก', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 4, 'Complete the Sentences 1', 'Fill with the correct word', '{"text": "National ___ among ___ is changing. Various ___ shape ___.", "blanks": [{"id": "blank1", "text": "identity", "options": ["identity", "youth", "influence", "globalization"], "correctAnswer": "identity"}, {"id": "blank2", "text": "youth", "options": ["youth", "identity", "influence", "expression"], "correctAnswer": "youth"}, {"id": "blank3", "text": "influences", "options": ["influences", "identity", "youth", "globalization"], "correctAnswer": "influences"}, {"id": "blank4", "text": "identity", "options": ["identity", "youth", "influence", "expression"], "correctAnswer": "identity"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 5, 'Complete the Sentences 2', 'Fill with the correct word', '{"text": "___ affects national ___. Young people express ___ through various means.", "blanks": [{"id": "blank1", "text": "Globalization", "options": ["Globalization", "Identity", "Youth", "Influence"], "correctAnswer": "Globalization"}, {"id": "blank2", "text": "identity", "options": ["identity", "youth", "influence", "expression"], "correctAnswer": "identity"}, {"id": "blank3", "text": "identity", "options": ["identity", "youth", "influence", "expression"], "correctAnswer": "identity"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_explanation', 6, 'Articles: Generic Reference', 'Learn articles with generic nouns', '{"rules": "Generic reference with articles:\n- Zero article for general concepts: \"Identity changes over time.\"\n- \"The\" for specific instances: \"The identity of youth is evolving.\"\n- \"A/an\" for classifying: \"Identity is a complex concept.\"\n\nPatterns:\n- General statements: \"National identity shapes values.\"\n- Specific reference: \"The identity of young people differs.\"\n- Classification: \"Identity is a personal construct.\"\n\nUse for:\n- General statements: \"National identity evolves.\"\n- Specific cases: \"The identity we see is changing.\"\n- Classification: \"Identity is a form of belonging.\"", "examples": ["National identity evolves among youth.", "The identity of young people is changing.", "Identity is a complex personal construct.", "The identity we observe reflects globalization.", "National identity shapes how youth express themselves."]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 7, 'Build Sentences 1', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'National identity evolves among youth.', 'National identity evolves among youth.', '["National", "identity", "evolves", "among", "youth."]'::jsonb),
    (activity_id_var, 'The identity of young people is changing.', 'The identity of young people is changing.', '["The", "identity", "of", "young", "people", "is", "changing."]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 8, 'Build Sentences 2', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'Identity is a complex personal construct.', 'Identity is a complex personal construct.', '["Identity", "is", "a", "complex", "personal", "construct."]'::jsonb),
    (activity_id_var, 'The identity we observe reflects globalization.', 'The identity we observe reflects globalization.', '["The", "identity", "we", "observe", "reflects", "globalization."]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'speaking_practice', 9, 'Discuss National Identity', 'Practice speaking about national identity', '{"prompts": ["What does national identity mean to you?", "How is it changing among youth?", "What influences national identity?", "How does globalization affect it?", "How do young people express identity?"]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (
      lesson_id,
      activity_type,
      activity_order,
      title,
      description,
      content
    ) VALUES (
      'C1-L38',
      'speaking_improvement',
      10,
      'Speaking Improvement',
      'Read the improved version of your speech',
      '{"type": "speaking_improvement", "similarityThreshold": 70}'::jsonb
    );
END $$;



-- =========================================
-- C1 Lesson 39
-- =========================================

-- =========================================
-- Pre-fill Database with Sample Lesson Data
-- C1-L39: Cultural Stereotypes
-- =========================================
DELETE FROM lesson_activity_results WHERE lesson_id = 'C1-L39';
DELETE FROM user_progress WHERE lesson_id = 'C1-L39';
DELETE FROM lesson_history WHERE lesson_id = 'C1-L39';
DELETE FROM grammar_sentences WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'C1-L39');
DELETE FROM vocabulary_items WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'C1-L39');
DELETE FROM lesson_activities WHERE lesson_id = 'C1-L39';
DELETE FROM lessons WHERE id = 'C1-L39';

INSERT INTO lessons (id, level, lesson_number, topic) VALUES
('C1-L39', 'C1', 39, 'Cultural Stereotypes')
ON CONFLICT (id) DO UPDATE SET topic = EXCLUDED.topic;

DO $$
DECLARE
    lesson_id_var TEXT := 'C1-L39';
    activity_id_var UUID;
BEGIN
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'warm_up_speaking', 1, 'Cultural Stereotypes', 'Discuss cultural stereotypes', '{"prompt": "Why do stereotypes persist?"}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_intro', 2, 'Stereotypes Vocabulary', 'Learn vocabulary about stereotypes', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'stereotype', 'ภาพเหมารวม', NULL),
    (activity_id_var, 'formation', 'การก่อตัว', NULL),
    (activity_id_var, 'inaccuracy', 'ความไม่ถูกต้อง', NULL),
    (activity_id_var, 'harm', 'อันตราย', NULL),
    (activity_id_var, 'challenge', 'ความท้าทาย', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_matching_drag', 3, 'Match Stereotypes Words', 'Match English words with Thai meanings', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'stereotype', 'ภาพเหมารวม', NULL),
    (activity_id_var, 'formation', 'การก่อตัว', NULL),
    (activity_id_var, 'inaccuracy', 'ความไม่ถูกต้อง', NULL),
    (activity_id_var, 'harm', 'อันตราย', NULL),
    (activity_id_var, 'challenge', 'ความท้าทาย', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 4, 'Complete the Sentences 1', 'Fill with the correct word', '{"text": "Stereotype ___ leads to ___. ___ of stereotypes causes ___.", "blanks": [{"id": "blank1", "text": "formation", "options": ["formation", "stereotype", "inaccuracy", "harm"], "correctAnswer": "formation"}, {"id": "blank2", "text": "inaccuracy", "options": ["inaccuracy", "formation", "stereotype", "harm"], "correctAnswer": "inaccuracy"}, {"id": "blank3", "text": "Harm", "options": ["Harm", "Stereotype", "Formation", "Inaccuracy"], "correctAnswer": "Harm"}, {"id": "blank4", "text": "harm", "options": ["harm", "formation", "inaccuracy", "challenge"], "correctAnswer": "harm"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 5, 'Complete the Sentences 2', 'Fill with the correct word', '{"text": "Challenging ___ requires awareness. ___ of stereotypes promotes understanding.", "blanks": [{"id": "blank1", "text": "stereotypes", "options": ["stereotypes", "formation", "inaccuracy", "harm"], "correctAnswer": "stereotypes"}, {"id": "blank2", "text": "Challenge", "options": ["Challenge", "Stereotype", "Formation", "Harm"], "correctAnswer": "Challenge"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_explanation', 6, 'Modals: Certainty', 'Learn modals expressing certainty', '{"rules": "Modals for certainty:\n- \"must\" (high certainty): \"Stereotypes must be inaccurate.\"\n- \"should\" (probable): \"Stereotypes should be challenged.\"\n- \"might/may\" (possible): \"Stereotypes might be harmful.\"\n- \"could\" (less certain): \"Stereotypes could be wrong.\"\n\nUse for:\n- Expressing confidence: \"I am certain stereotypes are inaccurate.\"\n- Showing uncertainty: \"I am not sure if stereotypes are wrong.\"\n- Speculating: \"Stereotypes might cause harm.\"", "examples": ["Stereotypes must be inaccurate given the evidence.", "I should be certain that stereotypes cause harm.", "Stereotypes might be harmful if unchallenged.", "I could be wrong about stereotype accuracy.", "You may be confident that stereotypes are inaccurate."]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 7, 'Build Sentences 1', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'Stereotypes must be inaccurate given the evidence.', 'Stereotypes must be inaccurate given the evidence.', '["Stereotypes", "must", "be", "inaccurate", "given", "the", "evidence."]'::jsonb),
    (activity_id_var, 'I should be certain that stereotypes cause harm.', 'I should be certain that stereotypes cause harm.', '["I", "should", "be", "certain", "that", "stereotypes", "cause", "harm."]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 8, 'Build Sentences 2', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'Stereotypes might be harmful if unchallenged.', 'Stereotypes might be harmful if unchallenged.', '["Stereotypes", "might", "be", "harmful", "if", "unchallenged."]'::jsonb),
    (activity_id_var, 'You may be confident that stereotypes are inaccurate.', 'You may be confident that stereotypes are inaccurate.', '["You", "may", "be", "confident", "that", "stereotypes", "are", "inaccurate."]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'speaking_practice', 9, 'Discuss Stereotypes', 'Practice speaking about cultural stereotypes', '{"prompts": ["How do stereotypes form?", "How sure can we be they are inaccurate?", "What harm do stereotypes cause?", "When did you change a belief?", "How can stereotypes be challenged?"]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (
      lesson_id,
      activity_type,
      activity_order,
      title,
      description,
      content
    ) VALUES (
      'C1-L39',
      'speaking_improvement',
      10,
      'Speaking Improvement',
      'Read the improved version of your speech',
      '{"type": "speaking_improvement", "similarityThreshold": 70}'::jsonb
    );
END $$;



-- =========================================
-- C1 Lesson 40
-- =========================================

-- =========================================
-- Pre-fill Database with Sample Lesson Data
-- C1-L40: Language as a Social Divider
-- =========================================
DELETE FROM lesson_activity_results WHERE lesson_id = 'C1-L40';
DELETE FROM user_progress WHERE lesson_id = 'C1-L40';
DELETE FROM lesson_history WHERE lesson_id = 'C1-L40';
DELETE FROM grammar_sentences WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'C1-L40');
DELETE FROM vocabulary_items WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'C1-L40');
DELETE FROM lesson_activities WHERE lesson_id = 'C1-L40';
DELETE FROM lessons WHERE id = 'C1-L40';

INSERT INTO lessons (id, level, lesson_number, topic) VALUES
('C1-L40', 'C1', 40, 'Language as a Social Divider')
ON CONFLICT (id) DO UPDATE SET topic = EXCLUDED.topic;

DO $$
DECLARE
    lesson_id_var TEXT := 'C1-L40';
    activity_id_var UUID;
BEGIN
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'warm_up_speaking', 1, 'Language as Divider', 'Discuss language as a social divider', '{"prompt": "How can language exclude people?"}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_intro', 2, 'Language Divider Vocabulary', 'Learn vocabulary about language divisions', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'barrier', 'อุปสรรค', NULL),
    (activity_id_var, 'exclusion', 'การกีดกัน', NULL),
    (activity_id_var, 'division', 'การแบ่งแยก', NULL),
    (activity_id_var, 'inclusion', 'การรวมเข้า', NULL),
    (activity_id_var, 'adaptation', 'การปรับตัว', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_matching_drag', 3, 'Match Language Divider Words', 'Match English words with Thai meanings', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'barrier', 'อุปสรรค', NULL),
    (activity_id_var, 'exclusion', 'การกีดกัน', NULL),
    (activity_id_var, 'division', 'การแบ่งแยก', NULL),
    (activity_id_var, 'inclusion', 'การรวมเข้า', NULL),
    (activity_id_var, 'adaptation', 'การปรับตัว', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 4, 'Complete the Sentences 1', 'Fill with the correct word', '{"text": "Language ___ create ___. Promoting ___ requires ___.", "blanks": [{"id": "blank1", "text": "barriers", "options": ["barriers", "exclusion", "division", "inclusion"], "correctAnswer": "barriers"}, {"id": "blank2", "text": "division", "options": ["division", "barrier", "exclusion", "inclusion"], "correctAnswer": "division"}, {"id": "blank3", "text": "inclusion", "options": ["inclusion", "barrier", "exclusion", "division"], "correctAnswer": "inclusion"}, {"id": "blank4", "text": "adaptation", "options": ["adaptation", "barrier", "exclusion", "division"], "correctAnswer": "adaptation"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 5, 'Complete the Sentences 2', 'Fill with the correct word', '{"text": "Language ___ affects many. Education plays a role in reducing ___.", "blanks": [{"id": "blank1", "text": "exclusion", "options": ["exclusion", "barrier", "division", "inclusion"], "correctAnswer": "exclusion"}, {"id": "blank2", "text": "barriers", "options": ["barriers", "exclusion", "division", "inclusion"], "correctAnswer": "barriers"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_explanation', 6, 'Advanced Passives', 'Learn advanced passive structures', '{"rules": "Advanced passive forms:\n- \"Language should be used inclusively.\" (obligation)\n- \"Barriers must be removed.\" (necessity)\n- \"Exclusion is being addressed.\" (continuous)\n- \"Divisions have been created.\" (perfect)\n- \"Inclusion will be improved.\" (future)\n\nUse when:\n- Focus is on action, not actor: \"Barriers should be removed.\"\n- Actor is unknown/unimportant: \"Exclusion was caused by language.\"\n- Formal/impersonal tone: \"It is required that inclusion be promoted.\"", "examples": ["Language barriers should be removed to promote inclusion.", "Exclusion must be addressed in multilingual settings.", "Divisions are being created by language differences.", "Inclusion has been improved through education.", "Barriers will be reduced through adaptation."]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 7, 'Build Sentences 1', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'Language barriers should be removed to promote inclusion.', 'Language barriers should be removed to promote inclusion.', '["Language", "barriers", "should", "be", "removed", "to", "promote", "inclusion."]'::jsonb),
    (activity_id_var, 'Exclusion must be addressed in multilingual settings.', 'Exclusion must be addressed in multilingual settings.', '["Exclusion", "must", "be", "addressed", "in", "multilingual", "settings."]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 8, 'Build Sentences 2', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'Divisions are being created by language differences.', 'Divisions are being created by language differences.', '["Divisions", "are", "being", "created", "by", "language", "differences."]'::jsonb),
    (activity_id_var, 'Inclusion has been improved through education.', 'Inclusion has been improved through education.', '["Inclusion", "has", "been", "improved", "through", "education."]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'speaking_practice', 9, 'Discuss Language Divisions', 'Practice speaking about language as a divider', '{"prompts": ["How does language create barriers?", "Who is affected by language divisions?", "How can inclusion be improved?", "Who should adapt in multilingual settings?", "What role does education play?"]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (
      lesson_id,
      activity_type,
      activity_order,
      title,
      description,
      content
    ) VALUES (
      'C1-L40',
      'speaking_improvement',
      10,
      'Speaking Improvement',
      'Read the improved version of your speech',
      '{"type": "speaking_improvement", "similarityThreshold": 70}'::jsonb
    );
END $$;



-- =========================================
-- C1 Lesson 41
-- =========================================

-- =========================================
-- Pre-fill Database with Sample Lesson Data
-- C1-L41: Technology Shaping Human Behavior
-- =========================================
DELETE FROM lesson_activity_results WHERE lesson_id = 'C1-L41';
DELETE FROM user_progress WHERE lesson_id = 'C1-L41';
DELETE FROM lesson_history WHERE lesson_id = 'C1-L41';
DELETE FROM grammar_sentences WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'C1-L41');
DELETE FROM vocabulary_items WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'C1-L41');
DELETE FROM lesson_activities WHERE lesson_id = 'C1-L41';
DELETE FROM lessons WHERE id = 'C1-L41';

INSERT INTO lessons (id, level, lesson_number, topic) VALUES
('C1-L41', 'C1', 41, 'Technology Shaping Human Behavior')
ON CONFLICT (id) DO UPDATE SET topic = EXCLUDED.topic;

DO $$
DECLARE
    lesson_id_var TEXT := 'C1-L41';
    activity_id_var UUID;
BEGIN
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'warm_up_speaking', 1, 'Technology and Behavior', 'Discuss technology shaping behavior', '{"prompt": "How has technology changed your habits?"}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_intro', 2, 'Technology Behavior Vocabulary', 'Learn vocabulary about technology and behavior', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'behavior', 'พฤติกรรม', NULL),
    (activity_id_var, 'routine', 'กิจวัตร', NULL),
    (activity_id_var, 'habit', 'นิสัย', NULL),
    (activity_id_var, 'influence', 'อิทธิพล', NULL),
    (activity_id_var, 'management', 'การจัดการ', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_matching_drag', 3, 'Match Technology Behavior Words', 'Match English words with Thai meanings', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'behavior', 'พฤติกรรม', NULL),
    (activity_id_var, 'routine', 'กิจวัตร', NULL),
    (activity_id_var, 'habit', 'นิสัย', NULL),
    (activity_id_var, 'influence', 'อิทธิพล', NULL),
    (activity_id_var, 'management', 'การจัดการ', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 4, 'Complete the Sentences 1', 'Fill with the correct word', '{"text": "Technology shapes human ___. Daily ___ have changed. New ___ emerge from tech ___.", "blanks": [{"id": "blank1", "text": "behavior", "options": ["behavior", "routine", "habit", "influence"], "correctAnswer": "behavior"}, {"id": "blank2", "text": "routines", "options": ["routines", "behavior", "habit", "influence"], "correctAnswer": "routines"}, {"id": "blank3", "text": "habits", "options": ["habits", "behavior", "routine", "influence"], "correctAnswer": "habits"}, {"id": "blank4", "text": "influence", "options": ["influence", "behavior", "routine", "habit"], "correctAnswer": "influence"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 5, 'Complete the Sentences 2', 'Fill with the correct word', '{"text": "Effective ___ of tech ___ requires awareness. Managing ___ helps control ___.", "blanks": [{"id": "blank1", "text": "management", "options": ["management", "behavior", "routine", "habit"], "correctAnswer": "management"}, {"id": "blank2", "text": "influence", "options": ["influence", "behavior", "routine", "habit"], "correctAnswer": "influence"}, {"id": "blank3", "text": "habits", "options": ["habits", "behavior", "routine", "influence"], "correctAnswer": "habits"}, {"id": "blank4", "text": "behavior", "options": ["behavior", "routine", "habit", "influence"], "correctAnswer": "behavior"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_explanation', 6, 'Advanced Perfect Aspect', 'Learn advanced perfect forms', '{"rules": "Advanced perfect aspect:\n- Present perfect: \"I have changed my habits over time.\"\n- Past perfect: \"I had developed routines before technology changed.\"\n- Future perfect: \"I will have adapted by then.\"\n- Perfect continuous: \"I have been using technology for years.\"\n\nUse for:\n- Completed actions with present relevance: \"I have altered my habits over time.\"\n- Past before past: \"I had established routines before tech changed them.\"\n- Future completion: \"I will have adapted to new technology by next year.\"", "examples": ["I have changed my habits over the years.", "I had developed routines before technology altered them.", "I will have adapted to new technology by next year.", "I have been using technology for decades.", "Having changed my habits, I understand tech influence better."]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 7, 'Build Sentences 1', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'I have changed my habits over the years.', 'I have changed my habits over the years.', '["I", "have", "changed", "my", "habits", "over", "the", "years."]'::jsonb),
    (activity_id_var, 'I had developed routines before technology altered them.', 'I had developed routines before technology altered them.', '["I", "had", "developed", "routines", "before", "technology", "altered", "them."]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 8, 'Build Sentences 2', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'I have been using technology for decades.', 'I have been using technology for decades.', '["I", "have", "been", "using", "technology", "for", "decades."]'::jsonb),
    (activity_id_var, 'Having changed my habits, I understand tech influence better.', 'Having changed my habits, I understand tech influence better.', '["Having", "changed", "my", "habits,", "I", "understand", "tech", "influence", "better."]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'speaking_practice', 9, 'Discuss Technology and Behavior', 'Practice speaking about technology shaping behavior', '{"prompts": ["What behaviors have changed over time?", "How has technology shaped routines?", "What habits concern you?", "What benefits have emerged?", "How do you manage tech influence?"]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (
      lesson_id,
      activity_type,
      activity_order,
      title,
      description,
      content
    ) VALUES (
      'C1-L41',
      'speaking_improvement',
      10,
      'Speaking Improvement',
      'Read the improved version of your speech',
      '{"type": "speaking_improvement", "similarityThreshold": 70}'::jsonb
    );
END $$;



-- =========================================
-- C1 Lesson 42
-- =========================================

-- =========================================
-- Pre-fill Database with Sample Lesson Data
-- C1-L42: Ethical Limits of Artificial Intelligence
-- =========================================
DELETE FROM lesson_activity_results WHERE lesson_id = 'C1-L42';
DELETE FROM user_progress WHERE lesson_id = 'C1-L42';
DELETE FROM lesson_history WHERE lesson_id = 'C1-L42';
DELETE FROM grammar_sentences WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'C1-L42');
DELETE FROM vocabulary_items WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'C1-L42');
DELETE FROM lesson_activities WHERE lesson_id = 'C1-L42';
DELETE FROM lessons WHERE id = 'C1-L42';

INSERT INTO lessons (id, level, lesson_number, topic) VALUES
('C1-L42', 'C1', 42, 'Ethical Limits of Artificial Intelligence')
ON CONFLICT (id) DO UPDATE SET topic = EXCLUDED.topic;

DO $$
DECLARE
    lesson_id_var TEXT := 'C1-L42';
    activity_id_var UUID;
BEGIN
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'warm_up_speaking', 1, 'AI Ethical Limits', 'Discuss ethical limits of AI', '{"prompt": "Where should limits be placed on AI?"}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_intro', 2, 'AI Ethics Vocabulary', 'Learn vocabulary about AI ethics', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'boundary', 'ขอบเขต', NULL),
    (activity_id_var, 'regulation', 'การควบคุม', NULL),
    (activity_id_var, 'harm', 'อันตราย', NULL),
    (activity_id_var, 'oversight', 'การกำกับดูแล', NULL),
    (activity_id_var, 'responsibility', 'ความรับผิดชอบ', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_matching_drag', 3, 'Match AI Ethics Words', 'Match English words with Thai meanings', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'boundary', 'ขอบเขต', NULL),
    (activity_id_var, 'regulation', 'การควบคุม', NULL),
    (activity_id_var, 'harm', 'อันตราย', NULL),
    (activity_id_var, 'oversight', 'การกำกับดูแล', NULL),
    (activity_id_var, 'responsibility', 'ความรับผิดชอบ', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 4, 'Complete the Sentences 1', 'Fill with the correct word', '{"text": "Ethical ___ must be respected. AI ___ requires ___.", "blanks": [{"id": "blank1", "text": "boundaries", "options": ["boundaries", "regulation", "harm", "oversight"], "correctAnswer": "boundaries"}, {"id": "blank2", "text": "regulation", "options": ["regulation", "boundary", "harm", "oversight"], "correctAnswer": "regulation"}, {"id": "blank3", "text": "oversight", "options": ["oversight", "boundary", "regulation", "harm"], "correctAnswer": "oversight"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 5, 'Complete the Sentences 2', 'Fill with the correct word', '{"text": "AI ___ must be prevented. ___ requires clear ___.", "blanks": [{"id": "blank1", "text": "harm", "options": ["harm", "boundary", "regulation", "oversight"], "correctAnswer": "harm"}, {"id": "blank2", "text": "Responsibility", "options": ["Responsibility", "Boundary", "Regulation", "Oversight"], "correctAnswer": "Responsibility"}, {"id": "blank3", "text": "regulation", "options": ["regulation", "boundary", "harm", "oversight"], "correctAnswer": "regulation"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_explanation', 6, 'Modals: Criticism in the Past', 'Learn modals for past criticism', '{"rules": "Past criticism with modals:\n- \"should have + past participle\" (criticism/regret): \"AI should have been limited earlier.\"\n- \"ought to have + past participle\" (stronger criticism): \"AI ought to have been regulated.\"\n- \"could have + past participle\" (missed opportunity): \"AI could have been controlled better.\"\n\nUse for:\n- Criticizing past actions: \"AI should have been limited before harm occurred.\"\n- Expressing regret: \"AI ought to have been regulated earlier.\"\n- Showing missed opportunities: \"AI could have been developed more carefully.\"", "examples": ["AI should have been limited before causing harm.", "AI ought to have been regulated from the start.", "AI could have been developed more ethically.", "AI should have been restricted where harm was done.", "AI ought to have been overseen more carefully."]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 7, 'Build Sentences 1', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'AI should have been limited before causing harm.', 'AI should have been limited before causing harm.', '["AI", "should", "have", "been", "limited", "before", "causing", "harm."]'::jsonb),
    (activity_id_var, 'AI ought to have been regulated from the start.', 'AI ought to have been regulated from the start.', '["AI", "ought", "to", "have", "been", "regulated", "from", "the", "start."]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 8, 'Build Sentences 2', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'AI could have been developed more ethically.', 'AI could have been developed more ethically.', '["AI", "could", "have", "been", "developed", "more", "ethically."]'::jsonb),
    (activity_id_var, 'AI should have been restricted where harm was done.', 'AI should have been restricted where harm was done.', '["AI", "should", "have", "been", "restricted", "where", "harm", "was", "done."]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'speaking_practice', 9, 'Discuss AI Ethics', 'Practice speaking about AI ethical limits', '{"prompts": ["What ethical boundaries should AI respect?", "Where has AI caused harm?", "How should AI development be regulated?", "What uses of AI concern you most?", "Who should be responsible for oversight?"]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (
      lesson_id,
      activity_type,
      activity_order,
      title,
      description,
      content
    ) VALUES (
      'C1-L42',
      'speaking_improvement',
      10,
      'Speaking Improvement',
      'Read the improved version of your speech',
      '{"type": "speaking_improvement", "similarityThreshold": 70}'::jsonb
    );
END $$;



-- =========================================
-- C1 Lesson 43
-- =========================================

-- =========================================
-- Pre-fill Database with Sample Lesson Data
-- C1-L43: Data Privacy and Consent
-- =========================================
DELETE FROM lesson_activity_results WHERE lesson_id = 'C1-L43';
DELETE FROM user_progress WHERE lesson_id = 'C1-L43';
DELETE FROM lesson_history WHERE lesson_id = 'C1-L43';
DELETE FROM grammar_sentences WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'C1-L43');
DELETE FROM vocabulary_items WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'C1-L43');
DELETE FROM lesson_activities WHERE lesson_id = 'C1-L43';
DELETE FROM lessons WHERE id = 'C1-L43';

INSERT INTO lessons (id, level, lesson_number, topic) VALUES
('C1-L43', 'C1', 43, 'Data Privacy and Consent')
ON CONFLICT (id) DO UPDATE SET topic = EXCLUDED.topic;

DO $$
DECLARE
    lesson_id_var TEXT := 'C1-L43';
    activity_id_var UUID;
BEGIN
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'warm_up_speaking', 1, 'Data Privacy', 'Discuss data privacy and consent', '{"prompt": "What does consent mean online?"}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_intro', 2, 'Data Privacy Vocabulary', 'Learn vocabulary about data privacy', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'consent', 'ความยินยอม', NULL),
    (activity_id_var, 'privacy', 'ความเป็นส่วนตัว', NULL),
    (activity_id_var, 'ownership', 'ความเป็นเจ้าของ', NULL),
    (activity_id_var, 'sharing', 'การแบ่งปัน', NULL),
    (activity_id_var, 'protection', 'การป้องกัน', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_matching_drag', 3, 'Match Data Privacy Words', 'Match English words with Thai meanings', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'consent', 'ความยินยอม', NULL),
    (activity_id_var, 'privacy', 'ความเป็นส่วนตัว', NULL),
    (activity_id_var, 'ownership', 'ความเป็นเจ้าของ', NULL),
    (activity_id_var, 'sharing', 'การแบ่งปัน', NULL),
    (activity_id_var, 'protection', 'การป้องกัน', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 4, 'Complete the Sentences 1', 'Fill with the correct word', '{"text": "Informed ___ protects ___. Data ___ determines ___.", "blanks": [{"id": "blank1", "text": "consent", "options": ["consent", "privacy", "ownership", "sharing"], "correctAnswer": "consent"}, {"id": "blank2", "text": "privacy", "options": ["privacy", "consent", "ownership", "protection"], "correctAnswer": "privacy"}, {"id": "blank3", "text": "ownership", "options": ["ownership", "consent", "privacy", "sharing"], "correctAnswer": "ownership"}, {"id": "blank4", "text": "sharing", "options": ["sharing", "consent", "privacy", "ownership"], "correctAnswer": "sharing"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 5, 'Complete the Sentences 2', 'Fill with the correct word', '{"text": "Data ___ requires user ___. Privacy ___ prevents unauthorized access.", "blanks": [{"id": "blank1", "text": "sharing", "options": ["sharing", "consent", "privacy", "ownership"], "correctAnswer": "sharing"}, {"id": "blank2", "text": "consent", "options": ["consent", "privacy", "ownership", "protection"], "correctAnswer": "consent"}, {"id": "blank3", "text": "protection", "options": ["protection", "consent", "privacy", "ownership"], "correctAnswer": "protection"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_explanation', 6, 'Nominal Clauses', 'Learn about nominal clauses', '{"rules": "Nominal clauses function as nouns:\n- Subject: \"What consent means matters online.\"\n- Object: \"I believe that data ownership is important.\"\n- Complement: \"The question is who owns your data.\"\n\nTypes:\n- That-clauses: \"I think that consent is crucial.\"\n- Wh-clauses: \"What you share determines privacy.\"\n- Whether/if: \"The issue is whether consent is clear.\"\n\nUse for:\n- Expressing opinions: \"What I think is that consent matters.\"\n- Asking questions: \"Who owns your data?\"\n- Making statements: \"That privacy matters is clear.\"", "examples": ["What consent means online is often unclear.", "I believe that data ownership is important.", "The question is who owns your personal data.", "Whether consent is truly informed remains uncertain.", "That privacy matters is widely accepted."]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 7, 'Build Sentences 1', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'What consent means online is often unclear.', 'What consent means online is often unclear.', '["What", "consent", "means", "online", "is", "often", "unclear."]'::jsonb),
    (activity_id_var, 'I believe that data ownership is important.', 'I believe that data ownership is important.', '["I", "believe", "that", "data", "ownership", "is", "important."]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 8, 'Build Sentences 2', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'The question is who owns your personal data.', 'The question is who owns your personal data.', '["The", "question", "is", "who", "owns", "your", "personal", "data."]'::jsonb),
    (activity_id_var, 'Whether consent is truly informed remains uncertain.', 'Whether consent is truly informed remains uncertain.', '["Whether", "consent", "is", "truly", "informed", "remains", "uncertain."]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'speaking_practice', 9, 'Discuss Data Privacy', 'Practice speaking about data privacy', '{"prompts": ["Who owns personal data?", "What data do you share knowingly?", "How do you protect your privacy?", "When is consent unclear?", "How should companies handle user data?"]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (
      lesson_id,
      activity_type,
      activity_order,
      title,
      description,
      content
    ) VALUES (
      'C1-L43',
      'speaking_improvement',
      10,
      'Speaking Improvement',
      'Read the improved version of your speech',
      '{"type": "speaking_improvement", "similarityThreshold": 70}'::jsonb
    );
END $$;



-- =========================================
-- C1 Lesson 44
-- =========================================

-- =========================================
-- Pre-fill Database with Sample Lesson Data
-- C1-L44: Digital Dependency
-- =========================================
DELETE FROM lesson_activity_results WHERE lesson_id = 'C1-L44';
DELETE FROM user_progress WHERE lesson_id = 'C1-L44';
DELETE FROM lesson_history WHERE lesson_id = 'C1-L44';
DELETE FROM grammar_sentences WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'C1-L44');
DELETE FROM vocabulary_items WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'C1-L44');
DELETE FROM lesson_activities WHERE lesson_id = 'C1-L44';
DELETE FROM lessons WHERE id = 'C1-L44';

INSERT INTO lessons (id, level, lesson_number, topic) VALUES
('C1-L44', 'C1', 44, 'Digital Dependency')
ON CONFLICT (id) DO UPDATE SET topic = EXCLUDED.topic;

DO $$
DECLARE
    lesson_id_var TEXT := 'C1-L44';
    activity_id_var UUID;
BEGIN
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'warm_up_speaking', 1, 'Digital Dependency', 'Discuss digital dependency', '{"prompt": "How dependent are you on digital devices?"}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_intro', 2, 'Digital Dependency Vocabulary', 'Learn vocabulary about digital dependency', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'dependency', 'การพึ่งพา', NULL),
    (activity_id_var, 'disconnect', 'การตัดการเชื่อมต่อ', NULL),
    (activity_id_var, 'sign', 'สัญญาณ', NULL),
    (activity_id_var, 'benefit', 'ประโยชน์', NULL),
    (activity_id_var, 'balance', 'ความสมดุล', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_matching_drag', 3, 'Match Digital Dependency Words', 'Match English words with Thai meanings', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'dependency', 'การพึ่งพา', NULL),
    (activity_id_var, 'disconnect', 'การตัดการเชื่อมต่อ', NULL),
    (activity_id_var, 'sign', 'สัญญาณ', NULL),
    (activity_id_var, 'benefit', 'ประโยชน์', NULL),
    (activity_id_var, 'balance', 'ความสมดุล', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 4, 'Complete the Sentences 1', 'Fill with the correct word', '{"text": "Digital ___ creates challenges. ___ from devices requires ___.", "blanks": [{"id": "blank1", "text": "dependency", "options": ["dependency", "disconnect", "sign", "benefit"], "correctAnswer": "dependency"}, {"id": "blank2", "text": "Disconnection", "options": ["Disconnection", "Dependency", "Sign", "Benefit"], "correctAnswer": "Disconnection"}, {"id": "blank3", "text": "balance", "options": ["balance", "dependency", "sign", "benefit"], "correctAnswer": "balance"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 5, 'Complete the Sentences 2', 'Fill with the correct word', '{"text": "Warning ___ indicate ___. Technology provides ___. Maintaining ___ is essential.", "blanks": [{"id": "blank1", "text": "signs", "options": ["signs", "dependency", "disconnect", "benefit"], "correctAnswer": "signs"}, {"id": "blank2", "text": "dependency", "options": ["dependency", "sign", "disconnect", "benefit"], "correctAnswer": "dependency"}, {"id": "blank3", "text": "benefits", "options": ["benefits", "dependency", "sign", "balance"], "correctAnswer": "benefits"}, {"id": "blank4", "text": "balance", "options": ["balance", "dependency", "sign", "benefit"], "correctAnswer": "balance"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_explanation', 6, 'Inversion: Hardly/Rarely', 'Learn inversion with hardly and rarely', '{"rules": "Inversion with hardly/rarely:\n- \"Hardly ever am I offline.\" (formal emphasis)\n- \"Rarely do I disconnect.\" (emphasis on infrequency)\n- \"Hardly had I disconnected when I felt anxious.\" (past emphasis)\n\nStructure:\n- Hardly/Rarely + auxiliary + subject + verb\n- Used for emphasis and formal tone\n\nUse for:\n- Emphasizing rarity: \"Rarely am I offline.\"\n- Formal statements: \"Hardly ever do I disconnect.\"\n- Highlighting infrequency: \"Rarely do people manage without devices.\"", "examples": ["Hardly ever am I offline during the day.", "Rarely do I disconnect from digital devices.", "Hardly had I disconnected when I felt anxious.", "Rarely are people completely offline.", "Hardly ever do students manage without technology."]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 7, 'Build Sentences 1', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'Hardly ever am I offline during the day.', 'Hardly ever am I offline during the day.', '["Hardly", "ever", "am", "I", "offline", "during", "the", "day."]'::jsonb),
    (activity_id_var, 'Rarely do I disconnect from digital devices.', 'Rarely do I disconnect from digital devices.', '["Rarely", "do", "I", "disconnect", "from", "digital", "devices."]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 8, 'Build Sentences 2', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'Hardly had I disconnected when I felt anxious.', 'Hardly had I disconnected when I felt anxious.', '["Hardly", "had", "I", "disconnected", "when", "I", "felt", "anxious."]'::jsonb),
    (activity_id_var, 'Rarely are people completely offline.', 'Rarely are people completely offline.', '["Rarely", "are", "people", "completely", "offline."]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'speaking_practice', 9, 'Discuss Digital Dependency', 'Practice speaking about digital dependency', '{"prompts": ["How often are you offline?", "What happens when you disconnect?", "What signs show dependency?", "What benefits does technology provide?", "How can balance be maintained?"]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (
      lesson_id,
      activity_type,
      activity_order,
      title,
      description,
      content
    ) VALUES (
      'C1-L44',
      'speaking_improvement',
      10,
      'Speaking Improvement',
      'Read the improved version of your speech',
      '{"type": "speaking_improvement", "similarityThreshold": 70}'::jsonb
    );
END $$;



-- =========================================
-- C1 Lesson 45
-- =========================================

-- =========================================
-- Pre-fill Database with Sample Lesson Data
-- C1-L45: Technology and Attention Span
-- =========================================
DELETE FROM lesson_activity_results WHERE lesson_id = 'C1-L45';
DELETE FROM user_progress WHERE lesson_id = 'C1-L45';
DELETE FROM lesson_history WHERE lesson_id = 'C1-L45';
DELETE FROM grammar_sentences WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'C1-L45');
DELETE FROM vocabulary_items WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'C1-L45');
DELETE FROM lesson_activities WHERE lesson_id = 'C1-L45';
DELETE FROM lessons WHERE id = 'C1-L45';

INSERT INTO lessons (id, level, lesson_number, topic) VALUES
('C1-L45', 'C1', 45, 'Technology and Attention Span')
ON CONFLICT (id) DO UPDATE SET topic = EXCLUDED.topic;

DO $$
DECLARE
    lesson_id_var TEXT := 'C1-L45';
    activity_id_var UUID;
BEGIN
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'warm_up_speaking', 1, 'Technology and Attention', 'Discuss technology and attention span', '{"prompt": "What affects your ability to focus?"}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_intro', 2, 'Attention Vocabulary', 'Learn vocabulary about attention', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'attention', 'ความสนใจ', NULL),
    (activity_id_var, 'distraction', 'สิ่งที่ทำให้ไขว้เขว', NULL),
    (activity_id_var, 'concentration', 'การมีสมาธิ', NULL),
    (activity_id_var, 'strategy', 'กลยุทธ์', NULL),
    (activity_id_var, 'improvement', 'การปรับปรุง', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_matching_drag', 3, 'Match Attention Words', 'Match English words with Thai meanings', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'attention', 'ความสนใจ', NULL),
    (activity_id_var, 'distraction', 'สิ่งที่ทำให้ไขว้เขว', NULL),
    (activity_id_var, 'concentration', 'การมีสมาธิ', NULL),
    (activity_id_var, 'strategy', 'กลยุทธ์', NULL),
    (activity_id_var, 'improvement', 'การปรับปรุง', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 4, 'Complete the Sentences 1', 'Fill with the correct word', '{"text": "Technology affects ___. Digital ___ reduce ___. Protecting ___ requires ___.", "blanks": [{"id": "blank1", "text": "attention", "options": ["attention", "distraction", "concentration", "strategy"], "correctAnswer": "attention"}, {"id": "blank2", "text": "distractions", "options": ["distractions", "attention", "concentration", "strategy"], "correctAnswer": "distractions"}, {"id": "blank3", "text": "concentration", "options": ["concentration", "attention", "distraction", "strategy"], "correctAnswer": "concentration"}, {"id": "blank4", "text": "strategies", "options": ["strategies", "attention", "distraction", "concentration"], "correctAnswer": "strategies"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 5, 'Complete the Sentences 2', 'Fill with the correct word', '{"text": "Effective ___ help maintain ___. ___ in attention requires practice.", "blanks": [{"id": "blank1", "text": "strategies", "options": ["strategies", "attention", "distraction", "concentration"], "correctAnswer": "strategies"}, {"id": "blank2", "text": "focus", "options": ["focus", "attention", "distraction", "concentration"], "correctAnswer": "focus"}, {"id": "blank3", "text": "Improvement", "options": ["Improvement", "Attention", "Distraction", "Concentration"], "correctAnswer": "Improvement"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_explanation', 6, 'Articles: Abstract Reference', 'Learn articles with abstract nouns', '{"rules": "Articles with abstract nouns:\n- Use \"the\" when referring to a specific abstract concept: \"the attention span\"\n- Omit article for general abstract concepts: \"attention is important\"\n- Use \"a/an\" when classifying: \"an attention problem\"\n\nStylistic use:\n- \"The\" can emphasize importance: \"the ability to focus\"\n- Zero article for broad concepts: \"technology affects attention\"\n\nUse for:\n- General statements: \"Attention requires protection.\"\n- Specific reference: \"The attention span has decreased.\"\n- Classification: \"Distraction is a common problem.\"", "examples": ["The attention span has decreased over time.", "Attention is essential for learning.", "A distraction can disrupt concentration.", "The ability to focus requires practice.", "Technology affects attention in various ways."]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 7, 'Build Sentences 1', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'The attention span has decreased over time.', 'The attention span has decreased over time.', '["The", "attention", "span", "has", "decreased", "over", "time."]'::jsonb),
    (activity_id_var, 'Attention is essential for learning.', 'Attention is essential for learning.', '["Attention", "is", "essential", "for", "learning."]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 8, 'Build Sentences 2', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'A distraction can disrupt concentration.', 'A distraction can disrupt concentration.', '["A", "distraction", "can", "disrupt", "concentration."]'::jsonb),
    (activity_id_var, 'The ability to focus requires practice.', 'The ability to focus requires practice.', '["The", "ability", "to", "focus", "requires", "practice."]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'speaking_practice', 9, 'Discuss Attention Span', 'Practice speaking about technology and attention', '{"prompts": ["How has technology affected attention?", "What distracts you most?", "How do you protect concentration?", "What strategies help maintain focus?", "How can attention be improved?"]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (
      lesson_id,
      activity_type,
      activity_order,
      title,
      description,
      content
    ) VALUES (
      'C1-L45',
      'speaking_improvement',
      10,
      'Speaking Improvement',
      'Read the improved version of your speech',
      '{"type": "speaking_improvement", "similarityThreshold": 70}'::jsonb
    );
END $$;



-- =========================================
-- C1 Lesson 46
-- =========================================

-- =========================================
-- Pre-fill Database with Sample Lesson Data
-- C1-L46: Human Connection in a Digital Age
-- =========================================
DELETE FROM lesson_activity_results WHERE lesson_id = 'C1-L46';
DELETE FROM user_progress WHERE lesson_id = 'C1-L46';
DELETE FROM lesson_history WHERE lesson_id = 'C1-L46';
DELETE FROM grammar_sentences WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'C1-L46');
DELETE FROM vocabulary_items WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'C1-L46');
DELETE FROM lesson_activities WHERE lesson_id = 'C1-L46';
DELETE FROM lessons WHERE id = 'C1-L46';

INSERT INTO lessons (id, level, lesson_number, topic) VALUES
('C1-L46', 'C1', 46, 'Human Connection in a Digital Age')
ON CONFLICT (id) DO UPDATE SET topic = EXCLUDED.topic;

DO $$
DECLARE
    lesson_id_var TEXT := 'C1-L46';
    activity_id_var UUID;
BEGIN
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'warm_up_speaking', 1, 'Human Connection', 'Discuss human connection in digital age', '{"prompt": "How do digital tools affect relationships?"}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_intro', 2, 'Connection Vocabulary', 'Learn vocabulary about human connection', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'connection', 'การเชื่อมต่อ', NULL),
    (activity_id_var, 'interaction', 'การโต้ตอบ', NULL),
    (activity_id_var, 'authenticity', 'ความจริงใจ', NULL),
    (activity_id_var, 'balance', 'ความสมดุล', NULL),
    (activity_id_var, 'challenge', 'ความท้าทาย', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_matching_drag', 3, 'Match Connection Words', 'Match English words with Thai meanings', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'connection', 'การเชื่อมต่อ', NULL),
    (activity_id_var, 'interaction', 'การโต้ตอบ', NULL),
    (activity_id_var, 'authenticity', 'ความจริงใจ', NULL),
    (activity_id_var, 'balance', 'ความสมดุล', NULL),
    (activity_id_var, 'challenge', 'ความท้าทาย', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 4, 'Complete the Sentences 1', 'Fill with the correct word', '{"text": "Meaningful ___ requires ___. Digital ___ can feel ___.", "blanks": [{"id": "blank1", "text": "connections", "options": ["connections", "interaction", "authenticity", "balance"], "correctAnswer": "connections"}, {"id": "blank2", "text": "authenticity", "options": ["authenticity", "connection", "interaction", "balance"], "correctAnswer": "authenticity"}, {"id": "blank3", "text": "interactions", "options": ["interactions", "connection", "authenticity", "balance"], "correctAnswer": "interactions"}, {"id": "blank4", "text": "shallow", "options": ["shallow", "connection", "authenticity", "balance"], "correctAnswer": "shallow"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 5, 'Complete the Sentences 2', 'Fill with the correct word', '{"text": "Maintaining ___ between online and offline ___ is a ___.", "blanks": [{"id": "blank1", "text": "balance", "options": ["balance", "connection", "interaction", "authenticity"], "correctAnswer": "balance"}, {"id": "blank2", "text": "connection", "options": ["connection", "interaction", "authenticity", "challenge"], "correctAnswer": "connection"}, {"id": "blank3", "text": "challenge", "options": ["challenge", "connection", "interaction", "authenticity"], "correctAnswer": "challenge"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_explanation', 6, 'Participle Clauses', 'Learn participle clauses', '{"rules": "Participle clauses:\n- Present participle (-ing): \"Maintaining connections, people stay engaged.\"\n- Past participle (-ed): \"Affected by technology, relationships change.\"\n- Perfect participle (having + past participle): \"Having connected online, people build relationships.\"\n\nUse for:\n- Showing simultaneous actions: \"Maintaining connections, you build relationships.\"\n- Showing cause: \"Affected by digital tools, interactions evolve.\"\n- Showing time sequence: \"Having connected online, people maintain relationships.\"", "examples": ["Maintaining meaningful connections, people stay engaged online.", "Affected by digital tools, relationships evolve.", "Having connected online, people build authentic relationships.", "Balancing online and offline, people maintain connections.", "Shaped by technology, human interaction changes."]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 7, 'Build Sentences 1', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'Maintaining meaningful connections, people stay engaged online.', 'Maintaining meaningful connections, people stay engaged online.', '["Maintaining", "meaningful", "connections,", "people", "stay", "engaged", "online."]'::jsonb),
    (activity_id_var, 'Affected by digital tools, relationships evolve.', 'Affected by digital tools, relationships evolve.', '["Affected", "by", "digital", "tools,", "relationships", "evolve."]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 8, 'Build Sentences 2', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'Having connected online, people build authentic relationships.', 'Having connected online, people build authentic relationships.', '["Having", "connected", "online,", "people", "build", "authentic", "relationships."]'::jsonb),
    (activity_id_var, 'Balancing online and offline, people maintain connections.', 'Balancing online and offline, people maintain connections.', '["Balancing", "online", "and", "offline,", "people", "maintain", "connections."]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'speaking_practice', 9, 'Discuss Human Connection', 'Practice speaking about human connection', '{"prompts": ["How do you maintain meaningful connections online?", "When do digital interactions feel shallow?", "What makes communication authentic?", "How do you balance online and offline connection?", "What challenges exist in digital relationships?"]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (
      lesson_id,
      activity_type,
      activity_order,
      title,
      description,
      content
    ) VALUES (
      'C1-L46',
      'speaking_improvement',
      10,
      'Speaking Improvement',
      'Read the improved version of your speech',
      '{"type": "speaking_improvement", "similarityThreshold": 70}'::jsonb
    );
END $$;



-- =========================================
-- C1 Lesson 47
-- =========================================

-- =========================================
-- Pre-fill Database with Sample Lesson Data
-- C1-L47: Virtual Communities
-- =========================================
DELETE FROM lesson_activity_results WHERE lesson_id = 'C1-L47';
DELETE FROM user_progress WHERE lesson_id = 'C1-L47';
DELETE FROM lesson_history WHERE lesson_id = 'C1-L47';
DELETE FROM grammar_sentences WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'C1-L47');
DELETE FROM vocabulary_items WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'C1-L47');
DELETE FROM lesson_activities WHERE lesson_id = 'C1-L47';
DELETE FROM lessons WHERE id = 'C1-L47';

INSERT INTO lessons (id, level, lesson_number, topic) VALUES
('C1-L47', 'C1', 47, 'Virtual Communities')
ON CONFLICT (id) DO UPDATE SET topic = EXCLUDED.topic;

DO $$
DECLARE
    lesson_id_var TEXT := 'C1-L47';
    activity_id_var UUID;
BEGIN
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'warm_up_speaking', 1, 'Virtual Communities', 'Discuss virtual communities', '{"prompt": "Why do people join virtual communities?"}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_intro', 2, 'Virtual Communities Vocabulary', 'Learn vocabulary about virtual communities', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'community', 'ชุมชน', NULL),
    (activity_id_var, 'belonging', 'ความรู้สึกเป็นเจ้าของ', NULL),
    (activity_id_var, 'norm', 'บรรทัดฐาน', NULL),
    (activity_id_var, 'benefit', 'ประโยชน์', NULL),
    (activity_id_var, 'challenge', 'ความท้าทาย', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_matching_drag', 3, 'Match Virtual Community Words', 'Match English words with Thai meanings', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'community', 'ชุมชน', NULL),
    (activity_id_var, 'belonging', 'ความรู้สึกเป็นเจ้าของ', NULL),
    (activity_id_var, 'norm', 'บรรทัดฐาน', NULL),
    (activity_id_var, 'benefit', 'ประโยชน์', NULL),
    (activity_id_var, 'challenge', 'ความท้าทาย', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 4, 'Complete the Sentences 1', 'Fill with the correct word', '{"text": "Virtual ___ create ___. Online ___ develop ___.", "blanks": [{"id": "blank1", "text": "communities", "options": ["communities", "belonging", "norm", "benefit"], "correctAnswer": "communities"}, {"id": "blank2", "text": "belonging", "options": ["belonging", "community", "norm", "benefit"], "correctAnswer": "belonging"}, {"id": "blank3", "text": "norms", "options": ["norms", "community", "belonging", "benefit"], "correctAnswer": "norms"}, {"id": "blank4", "text": "naturally", "options": ["naturally", "community", "belonging", "norm"], "correctAnswer": "naturally"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 5, 'Complete the Sentences 2', 'Fill with the correct word', '{"text": "Online ___ offer ___. Virtual ___ face ___.", "blanks": [{"id": "blank1", "text": "communities", "options": ["communities", "belonging", "norm", "benefit"], "correctAnswer": "communities"}, {"id": "blank2", "text": "benefits", "options": ["benefits", "community", "belonging", "norm"], "correctAnswer": "benefits"}, {"id": "blank3", "text": "communities", "options": ["communities", "belonging", "norm", "benefit"], "correctAnswer": "communities"}, {"id": "blank4", "text": "challenges", "options": ["challenges", "community", "belonging", "norm"], "correctAnswer": "challenges"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_explanation', 6, 'Cohesion and Substitution', 'Learn cohesion and substitution', '{"rules": "Cohesion and substitution:\n- Substitution: \"Virtual communities create belonging, and offline ones do too.\"\n- Reference: \"Online communities differ from offline ones; these differences matter.\"\n- Ellipsis: \"Virtual groups form norms, and offline groups do as well.\"\n\nUse for:\n- Avoiding repetition: \"Online communities offer benefits, and offline ones do too.\"\n- Creating flow: \"Virtual groups create belonging; such belonging matters.\"\n- Connecting ideas: \"Challenges exist; these challenges need addressing.\"", "examples": ["Virtual communities create belonging, and offline ones do too.", "Online communities differ from offline ones; these differences matter.", "Virtual groups form norms, and offline groups do as well.", "Online communities offer benefits; such benefits are valuable.", "Challenges exist in virtual communities; these challenges need addressing."]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 7, 'Build Sentences 1', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'Virtual communities create belonging, and offline ones do too.', 'Virtual communities create belonging, and offline ones do too.', '["Virtual", "communities", "create", "belonging,", "and", "offline", "ones", "do", "too."]'::jsonb),
    (activity_id_var, 'Online communities differ from offline ones; these differences matter.', 'Online communities differ from offline ones; these differences matter.', '["Online", "communities", "differ", "from", "offline", "ones;", "these", "differences", "matter."]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 8, 'Build Sentences 2', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'Virtual groups form norms, and offline groups do as well.', 'Virtual groups form norms, and offline groups do as well.', '["Virtual", "groups", "form", "norms,", "and", "offline", "groups", "do", "as", "well."]'::jsonb),
    (activity_id_var, 'Online communities offer benefits; such benefits are valuable.', 'Online communities offer benefits; such benefits are valuable.', '["Online", "communities", "offer", "benefits;", "such", "benefits", "are", "valuable."]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'speaking_practice', 9, 'Discuss Virtual Communities', 'Practice speaking about virtual communities', '{"prompts": ["What creates belonging online?", "What norms form in virtual groups?", "How do online communities differ from offline ones?", "What benefits do they offer?", "What challenges do they face?"]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (
      lesson_id,
      activity_type,
      activity_order,
      title,
      description,
      content
    ) VALUES (
      'C1-L47',
      'speaking_improvement',
      10,
      'Speaking Improvement',
      'Read the improved version of your speech',
      '{"type": "speaking_improvement", "similarityThreshold": 70}'::jsonb
    );
END $$;



-- =========================================
-- C1 Lesson 48
-- =========================================

-- =========================================
-- Pre-fill Database with Sample Lesson Data
-- C1-L48: Future of Human Communication
-- =========================================
DELETE FROM lesson_activity_results WHERE lesson_id = 'C1-L48';
DELETE FROM user_progress WHERE lesson_id = 'C1-L48';
DELETE FROM lesson_history WHERE lesson_id = 'C1-L48';
DELETE FROM grammar_sentences WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'C1-L48');
DELETE FROM vocabulary_items WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'C1-L48');
DELETE FROM lesson_activities WHERE lesson_id = 'C1-L48';
DELETE FROM lessons WHERE id = 'C1-L48';

INSERT INTO lessons (id, level, lesson_number, topic) VALUES
('C1-L48', 'C1', 48, 'Future of Human Communication')
ON CONFLICT (id) DO UPDATE SET topic = EXCLUDED.topic;

DO $$
DECLARE
    lesson_id_var TEXT := 'C1-L48';
    activity_id_var UUID;
BEGIN
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'warm_up_speaking', 1, 'Future Communication', 'Discuss future of communication', '{"prompt": "How will communication change in the future?"}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_intro', 2, 'Future Communication Vocabulary', 'Learn vocabulary about future communication', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'evolution', 'วิวัฒนาการ', NULL),
    (activity_id_var, 'trend', 'แนวโน้ม', NULL),
    (activity_id_var, 'interaction', 'การโต้ตอบ', NULL),
    (activity_id_var, 'adaptation', 'การปรับตัว', NULL),
    (activity_id_var, 'prediction', 'การทำนาย', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_matching_drag', 3, 'Match Future Communication Words', 'Match English words with Thai meanings', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'evolution', 'วิวัฒนาการ', NULL),
    (activity_id_var, 'trend', 'แนวโน้ม', NULL),
    (activity_id_var, 'interaction', 'การโต้ตอบ', NULL),
    (activity_id_var, 'adaptation', 'การปรับตัว', NULL),
    (activity_id_var, 'prediction', 'การทำนาย', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 4, 'Complete the Sentences 1', 'Fill with the correct word', '{"text": "Communication ___ continues. Future ___ will shape ___.", "blanks": [{"id": "blank1", "text": "evolution", "options": ["evolution", "trend", "interaction", "adaptation"], "correctAnswer": "evolution"}, {"id": "blank2", "text": "trends", "options": ["trends", "evolution", "interaction", "adaptation"], "correctAnswer": "trends"}, {"id": "blank3", "text": "interaction", "options": ["interaction", "evolution", "trend", "adaptation"], "correctAnswer": "interaction"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 5, 'Complete the Sentences 2', 'Fill with the correct word', '{"text": "Making ___ about communication requires ___. Successful ___ enables ___.", "blanks": [{"id": "blank1", "text": "predictions", "options": ["predictions", "evolution", "trend", "interaction"], "correctAnswer": "predictions"}, {"id": "blank2", "text": "insight", "options": ["insight", "evolution", "trend", "interaction"], "correctAnswer": "insight"}, {"id": "blank3", "text": "adaptation", "options": ["adaptation", "evolution", "trend", "interaction"], "correctAnswer": "adaptation"}, {"id": "blank4", "text": "growth", "options": ["growth", "evolution", "trend", "interaction"], "correctAnswer": "growth"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_explanation', 6, 'Advanced Perfect Aspect', 'Learn advanced perfect forms', '{"rules": "Advanced perfect aspect:\n- Future perfect: \"I will have adapted to new communication by 2030.\"\n- Future perfect continuous: \"I will have been communicating differently for years.\"\n- Perfect in conditional: \"If I had adapted, I would have communicated better.\"\n\nUse for:\n- Future completion: \"I will have changed my communication style by then.\"\n- Duration up to future point: \"I will have been using new tools for a decade.\"\n- Hypothetical past: \"If I had adapted earlier, I would have communicated better.\"", "examples": ["I will have adapted to new communication by 2030.", "I will have been communicating differently for years.", "By next decade, communication will have evolved significantly.", "I will have changed my communication style by then.", "Having adapted to new tools, people will communicate better."]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 7, 'Build Sentences 1', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'I will have adapted to new communication by 2030.', 'I will have adapted to new communication by 2030.', '["I", "will", "have", "adapted", "to", "new", "communication", "by", "2030."]'::jsonb),
    (activity_id_var, 'I will have been communicating differently for years.', 'I will have been communicating differently for years.', '["I", "will", "have", "been", "communicating", "differently", "for", "years."]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 8, 'Build Sentences 2', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'By next decade, communication will have evolved significantly.', 'By next decade, communication will have evolved significantly.', '["By", "next", "decade,", "communication", "will", "have", "evolved", "significantly."]'::jsonb),
    (activity_id_var, 'Having adapted to new tools, people will communicate better.', 'Having adapted to new tools, people will communicate better.', '["Having", "adapted", "to", "new", "tools,", "people", "will", "communicate", "better."]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'speaking_practice', 9, 'Discuss Future Communication', 'Practice speaking about future communication', '{"prompts": ["How will communication have evolved in 10 years?", "What trends do you predict?", "What will remain the same?", "How will technology shape interaction?", "How should people adapt?"]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (
      lesson_id,
      activity_type,
      activity_order,
      title,
      description,
      content
    ) VALUES (
      'C1-L48',
      'speaking_improvement',
      10,
      'Speaking Improvement',
      'Read the improved version of your speech',
      '{"type": "speaking_improvement", "similarityThreshold": 70}'::jsonb
    );
END $$;



-- =========================================
-- C1 Lesson 49
-- =========================================

-- =========================================
-- Pre-fill Database with Sample Lesson Data
-- C1-L49: Automation and Society
-- =========================================
DELETE FROM lesson_activity_results WHERE lesson_id = 'C1-L49';
DELETE FROM user_progress WHERE lesson_id = 'C1-L49';
DELETE FROM lesson_history WHERE lesson_id = 'C1-L49';
DELETE FROM grammar_sentences WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'C1-L49');
DELETE FROM vocabulary_items WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'C1-L49');
DELETE FROM lesson_activities WHERE lesson_id = 'C1-L49';
DELETE FROM lessons WHERE id = 'C1-L49';

INSERT INTO lessons (id, level, lesson_number, topic) VALUES
('C1-L49', 'C1', 49, 'Automation and Society')
ON CONFLICT (id) DO UPDATE SET topic = EXCLUDED.topic;

DO $$
DECLARE
    lesson_id_var TEXT := 'C1-L49';
    activity_id_var UUID;
BEGIN
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'warm_up_speaking', 1, 'Automation', 'Discuss automation and society', '{"prompt": "What should remain human in an automated world?"}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_intro', 2, 'Automation Vocabulary', 'Learn vocabulary about automation', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'automation', 'ระบบอัตโนมัติ', NULL),
    (activity_id_var, 'task', 'งาน', NULL),
    (activity_id_var, 'impact', 'ผลกระทบ', NULL),
    (activity_id_var, 'concern', 'ความกังวล', NULL),
    (activity_id_var, 'adaptation', 'การปรับตัว', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_matching_drag', 3, 'Match Automation Words', 'Match English words with Thai meanings', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'automation', 'ระบบอัตโนมัติ', NULL),
    (activity_id_var, 'task', 'งาน', NULL),
    (activity_id_var, 'impact', 'ผลกระทบ', NULL),
    (activity_id_var, 'concern', 'ความกังวล', NULL),
    (activity_id_var, 'adaptation', 'การปรับตัว', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 4, 'Complete the Sentences 1', 'Fill with the correct word', '{"text": "Some ___ should be automated. Others must remain ___. ___ affects jobs.", "blanks": [{"id": "blank1", "text": "tasks", "options": ["tasks", "automation", "impact", "concern"], "correctAnswer": "tasks"}, {"id": "blank2", "text": "human", "options": ["human", "automation", "task", "impact"], "correctAnswer": "human"}, {"id": "blank3", "text": "Automation", "options": ["Automation", "Task", "Impact", "Concern"], "correctAnswer": "Automation"}, {"id": "blank4", "text": "impact", "options": ["impact", "automation", "task", "concern"], "correctAnswer": "impact"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 5, 'Complete the Sentences 2', 'Fill with the correct word', '{"text": "Ethical ___ require attention. Society must ___ to ___.", "blanks": [{"id": "blank1", "text": "concerns", "options": ["concerns", "automation", "task", "impact"], "correctAnswer": "concerns"}, {"id": "blank2", "text": "adapt", "options": ["adapt", "automation", "task", "impact"], "correctAnswer": "adapt"}, {"id": "blank3", "text": "automation", "options": ["automation", "task", "impact", "concern"], "correctAnswer": "automation"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_explanation', 6, 'Advanced Passives', 'Learn advanced passive structures', '{"rules": "Advanced passive forms:\n- \"Tasks should be automated.\" (obligation)\n- \"Some work must remain human.\" (necessity)\n- \"Automation is being implemented.\" (continuous)\n- \"Jobs have been affected.\" (perfect)\n- \"Society will be transformed.\" (future)\n\nUse when:\n- Focus is on action, not actor: \"Tasks should be automated.\"\n- Actor is unknown/unimportant: \"Automation was introduced gradually.\"\n- Formal/impersonal tone: \"It is required that some tasks remain human.\"", "examples": ["Some tasks should be automated for efficiency.", "Certain work must remain human.", "Automation is being implemented across industries.", "Jobs have been affected by automation.", "Society will be transformed by automation."]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 7, 'Build Sentences 1', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'Some tasks should be automated for efficiency.', 'Some tasks should be automated for efficiency.', '["Some", "tasks", "should", "be", "automated", "for", "efficiency."]'::jsonb),
    (activity_id_var, 'Certain work must remain human.', 'Certain work must remain human.', '["Certain", "work", "must", "remain", "human."]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 8, 'Build Sentences 2', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'Automation is being implemented across industries.', 'Automation is being implemented across industries.', '["Automation", "is", "being", "implemented", "across", "industries."]'::jsonb),
    (activity_id_var, 'Jobs have been affected by automation.', 'Jobs have been affected by automation.', '["Jobs", "have", "been", "affected", "by", "automation."]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'speaking_practice', 9, 'Discuss Automation', 'Practice speaking about automation', '{"prompts": ["What tasks should be automated?", "What should never be automated?", "How does automation affect jobs?", "What ethical concerns exist?", "How should society adapt to automation?"]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (
      lesson_id,
      activity_type,
      activity_order,
      title,
      description,
      content
    ) VALUES (
      'C1-L49',
      'speaking_improvement',
      10,
      'Speaking Improvement',
      'Read the improved version of your speech',
      '{"type": "speaking_improvement", "similarityThreshold": 70}'::jsonb
    );
END $$;



-- =========================================
-- C1 Lesson 50
-- =========================================

-- =========================================
-- Pre-fill Database with Sample Lesson Data
-- C1-L50: Ethical Responsibility of Tech Companies
-- =========================================
DELETE FROM lesson_activity_results WHERE lesson_id = 'C1-L50';
DELETE FROM user_progress WHERE lesson_id = 'C1-L50';
DELETE FROM lesson_history WHERE lesson_id = 'C1-L50';
DELETE FROM grammar_sentences WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'C1-L50');
DELETE FROM vocabulary_items WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'C1-L50');
DELETE FROM lesson_activities WHERE lesson_id = 'C1-L50';
DELETE FROM lessons WHERE id = 'C1-L50';

INSERT INTO lessons (id, level, lesson_number, topic) VALUES
('C1-L50', 'C1', 50, 'Ethical Responsibility of Tech Companies')
ON CONFLICT (id) DO UPDATE SET topic = EXCLUDED.topic;

DO $$
DECLARE
    lesson_id_var TEXT := 'C1-L50';
    activity_id_var UUID;
BEGIN
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'warm_up_speaking', 1, 'Tech Company Ethics', 'Discuss ethical responsibility of tech companies', '{"prompt": "How could tech companies have acted differently in the past?"}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_intro', 2, 'Tech Ethics Vocabulary', 'Learn vocabulary about tech company ethics', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'responsibility', 'ความรับผิดชอบ', NULL),
    (activity_id_var, 'mistake', 'ข้อผิดพลาด', NULL),
    (activity_id_var, 'regulation', 'การควบคุม', NULL),
    (activity_id_var, 'accountability', 'ความรับผิดชอบ', NULL),
    (activity_id_var, 'impact', 'ผลกระทบ', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_matching_drag', 3, 'Match Tech Ethics Words', 'Match English words with Thai meanings', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'responsibility', 'ความรับผิดชอบ', NULL),
    (activity_id_var, 'mistake', 'ข้อผิดพลาด', NULL),
    (activity_id_var, 'regulation', 'การควบคุม', NULL),
    (activity_id_var, 'accountability', 'ความรับผิดชอบ', NULL),
    (activity_id_var, 'impact', 'ผลกระทบ', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 4, 'Complete the Sentences 1', 'Fill with the correct word', '{"text": "Tech companies have ___. ___ for ___ requires ___.", "blanks": [{"id": "blank1", "text": "responsibilities", "options": ["responsibilities", "mistake", "regulation", "accountability"], "correctAnswer": "responsibilities"}, {"id": "blank2", "text": "Accountability", "options": ["Accountability", "Responsibility", "Mistake", "Regulation"], "correctAnswer": "Accountability"}, {"id": "blank3", "text": "mistakes", "options": ["mistakes", "responsibility", "regulation", "accountability"], "correctAnswer": "mistakes"}, {"id": "blank4", "text": "regulation", "options": ["regulation", "responsibility", "mistake", "accountability"], "correctAnswer": "regulation"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 5, 'Complete the Sentences 2', 'Fill with the correct word', '{"text": "Technology ___ affects society. ___ should be held accountable for ___.", "blanks": [{"id": "blank1", "text": "impact", "options": ["impact", "responsibility", "mistake", "regulation"], "correctAnswer": "impact"}, {"id": "blank2", "text": "Companies", "options": ["Companies", "Responsibility", "Mistake", "Regulation"], "correctAnswer": "Companies"}, {"id": "blank3", "text": "impact", "options": ["impact", "responsibility", "mistake", "regulation"], "correctAnswer": "impact"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_explanation', 6, 'Modals: Degrees of Certainty in the Past', 'Learn modals for past certainty', '{"rules": "Past certainty with modals:\n- \"must have + past participle\" (high certainty): \"Tech companies must have known about the impact.\"\n- \"should have + past participle\" (expected): \"Tech companies should have acted differently.\"\n- \"might have + past participle\" (possibility): \"Tech companies might have prevented harm.\"\n- \"could have + past participle\" (ability/possibility): \"Tech companies could have acted better.\"\n\nUse for:\n- Expressing certainty about past: \"Tech companies must have been aware.\"\n- Showing expectation: \"Tech companies should have been more responsible.\"\n- Speculating: \"Tech companies might have avoided mistakes.\"", "examples": ["Tech companies must have known about the potential impact.", "Tech companies should have acted more responsibly.", "Tech companies might have prevented harm if they had acted earlier.", "Tech companies could have been more ethical in their decisions.", "Tech companies must have been aware of their responsibilities."]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 7, 'Build Sentences 1', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'Tech companies must have known about the potential impact.', 'Tech companies must have known about the potential impact.', '["Tech", "companies", "must", "have", "known", "about", "the", "potential", "impact."]'::jsonb),
    (activity_id_var, 'Tech companies should have acted more responsibly.', 'Tech companies should have acted more responsibly.', '["Tech", "companies", "should", "have", "acted", "more", "responsibly."]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 8, 'Build Sentences 2', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'Tech companies might have prevented harm if they had acted earlier.', 'Tech companies might have prevented harm if they had acted earlier.', '["Tech", "companies", "might", "have", "prevented", "harm", "if", "they", "had", "acted", "earlier."]'::jsonb),
    (activity_id_var, 'Tech companies could have been more ethical in their decisions.', 'Tech companies could have been more ethical in their decisions.', '["Tech", "companies", "could", "have", "been", "more", "ethical", "in", "their", "decisions."]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'speaking_practice', 9, 'Discuss Tech Company Ethics', 'Practice speaking about tech company ethics', '{"prompts": ["How could tech companies have acted differently?", "Who pays for mistakes made by tech firms?", "What responsibilities do tech companies have?", "How should tech companies be regulated?", "Who should be accountable for technology''s impact?"]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (
      lesson_id,
      activity_type,
      activity_order,
      title,
      description,
      content
    ) VALUES (
      'C1-L50',
      'speaking_improvement',
      10,
      'Speaking Improvement',
      'Read the improved version of your speech',
      '{"type": "speaking_improvement", "similarityThreshold": 70}'::jsonb
    );
END $$;



-- =========================================
-- C1 Lesson 51
-- =========================================

-- =========================================
-- Pre-fill Database with Sample Lesson Data
-- C1-L51: Climate Responsibility of Individuals
-- =========================================
DELETE FROM lesson_activity_results WHERE lesson_id = 'C1-L51';
DELETE FROM user_progress WHERE lesson_id = 'C1-L51';
DELETE FROM lesson_history WHERE lesson_id = 'C1-L51';
DELETE FROM grammar_sentences WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'C1-L51');
DELETE FROM vocabulary_items WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'C1-L51');
DELETE FROM lesson_activities WHERE lesson_id = 'C1-L51';
DELETE FROM lessons WHERE id = 'C1-L51';

INSERT INTO lessons (id, level, lesson_number, topic) VALUES
('C1-L51', 'C1', 51, 'Climate Responsibility of Individuals')
ON CONFLICT (id) DO UPDATE SET topic = EXCLUDED.topic;

DO $$
DECLARE
    lesson_id_var TEXT := 'C1-L51';
    activity_id_var UUID;
BEGIN
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'warm_up_speaking', 1, 'Climate Responsibility', 'Discuss climate responsibility', '{"prompt": "What is it that you can change first in your daily life?"}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_intro', 2, 'Climate Responsibility Vocabulary', 'Learn vocabulary about climate responsibility', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'responsibility', 'ความรับผิดชอบ', NULL),
    (activity_id_var, 'action', 'การกระทำ', NULL),
    (activity_id_var, 'individual', 'บุคคล', NULL),
    (activity_id_var, 'collective', 'รวมกัน', NULL),
    (activity_id_var, 'change', 'การเปลี่ยนแปลง', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_matching_drag', 3, 'Match Climate Responsibility Words', 'Match English words with Thai meanings', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'responsibility', 'ความรับผิดชอบ', NULL),
    (activity_id_var, 'action', 'การกระทำ', NULL),
    (activity_id_var, 'individual', 'บุคคล', NULL),
    (activity_id_var, 'collective', 'รวมกัน', NULL),
    (activity_id_var, 'change', 'การเปลี่ยนแปลง', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 4, 'Complete the Sentences 1', 'Fill with the correct word', '{"text": "Individual ___ matters. Taking ___ requires ___.", "blanks": [{"id": "blank1", "text": "responsibility", "options": ["responsibility", "action", "individual", "collective"], "correctAnswer": "responsibility"}, {"id": "blank2", "text": "action", "options": ["action", "responsibility", "individual", "change"], "correctAnswer": "action"}, {"id": "blank3", "text": "commitment", "options": ["commitment", "responsibility", "action", "individual"], "correctAnswer": "commitment"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 5, 'Complete the Sentences 2', 'Fill with the correct word', '{"text": "Balancing ___ and ___ responsibility is important. Making ___ requires effort.", "blanks": [{"id": "blank1", "text": "personal", "options": ["personal", "individual", "collective", "change"], "correctAnswer": "personal"}, {"id": "blank2", "text": "collective", "options": ["collective", "individual", "responsibility", "change"], "correctAnswer": "collective"}, {"id": "blank3", "text": "changes", "options": ["changes", "individual", "responsibility", "action"], "correctAnswer": "changes"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_explanation', 6, 'Cleft Sentences and Emphatic Structures', 'Learn cleft sentences for emphasis', '{"rules": "Cleft sentences emphasize specific elements:\n- It-cleft: \"It is individual action that matters most.\"\n- What-cleft: \"What you can change first is your daily habits.\"\n- Wh-cleft: \"What matters is taking action.\"\n\nStructure:\n- It + be + emphasized element + that/who clause\n- What + verb + be + emphasized element\n\nUse for:\n- Emphasizing importance: \"It is individual responsibility that drives change.\"\n- Highlighting focus: \"What you can change first is your lifestyle.\"\n- Clarifying meaning: \"What matters is taking action.\"", "examples": ["It is individual action that matters most for climate.", "What you can change first is your daily habits.", "What matters is taking responsibility.", "It is personal commitment that drives change.", "What makes a difference is collective action."]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 7, 'Build Sentences 1', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'It is individual action that matters most for climate.', 'It is individual action that matters most for climate.', '["It", "is", "individual", "action", "that", "matters", "most", "for", "climate."]'::jsonb),
    (activity_id_var, 'What you can change first is your daily habits.', 'What you can change first is your daily habits.', '["What", "you", "can", "change", "first", "is", "your", "daily", "habits."]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 8, 'Build Sentences 2', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'What matters is taking responsibility.', 'What matters is taking responsibility.', '["What", "matters", "is", "taking", "responsibility."]'::jsonb),
    (activity_id_var, 'It is personal commitment that drives change.', 'It is personal commitment that drives change.', '["It", "is", "personal", "commitment", "that", "drives", "change."]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'speaking_practice', 9, 'Discuss Climate Responsibility', 'Practice speaking about climate responsibility', '{"prompts": ["What is it that you can change first?", "How do you take action on climate issues?", "What individual actions matter most?", "How do you balance personal and collective responsibility?", "What changes have you already made for the climate?"]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (
      lesson_id,
      activity_type,
      activity_order,
      title,
      description,
      content
    ) VALUES (
      'C1-L51',
      'speaking_improvement',
      10,
      'Speaking Improvement',
      'Read the improved version of your speech',
      '{"type": "speaking_improvement", "similarityThreshold": 70}'::jsonb
    );
END $$;



-- =========================================
-- C1 Lesson 52
-- =========================================

-- =========================================
-- Pre-fill Database with Sample Lesson Data
-- C1-L52: Environmental Activism Among Youth
-- =========================================
DELETE FROM lesson_activity_results WHERE lesson_id = 'C1-L52';
DELETE FROM user_progress WHERE lesson_id = 'C1-L52';
DELETE FROM lesson_history WHERE lesson_id = 'C1-L52';
DELETE FROM grammar_sentences WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'C1-L52');
DELETE FROM vocabulary_items WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'C1-L52');
DELETE FROM lesson_activities WHERE lesson_id = 'C1-L52';
DELETE FROM lessons WHERE id = 'C1-L52';

INSERT INTO lessons (id, level, lesson_number, topic) VALUES
('C1-L52', 'C1', 52, 'Environmental Activism Among Youth')
ON CONFLICT (id) DO UPDATE SET topic = EXCLUDED.topic;

DO $$
DECLARE
    lesson_id_var TEXT := 'C1-L52';
    activity_id_var UUID;
BEGIN
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'warm_up_speaking', 1, 'Environmental Activism', 'Discuss environmental activism', '{"prompt": "When have you taken action for the environment?"}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_intro', 2, 'Activism Vocabulary', 'Learn vocabulary about activism', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'activism', 'การเคลื่อนไหว', NULL),
    (activity_id_var, 'action', 'การกระทำ', NULL),
    (activity_id_var, 'engagement', 'การมีส่วนร่วม', NULL),
    (activity_id_var, 'motivation', 'แรงจูงใจ', NULL),
    (activity_id_var, 'barrier', 'อุปสรรค', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_matching_drag', 3, 'Match Activism Words', 'Match English words with Thai meanings', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'activism', 'การเคลื่อนไหว', NULL),
    (activity_id_var, 'action', 'การกระทำ', NULL),
    (activity_id_var, 'engagement', 'การมีส่วนร่วม', NULL),
    (activity_id_var, 'motivation', 'แรงจูงใจ', NULL),
    (activity_id_var, 'barrier', 'อุปสรรค', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 4, 'Complete the Sentences 1', 'Fill with the correct word', '{"text": "Youth ___ drives change. Environmental ___ requires ___.", "blanks": [{"id": "blank1", "text": "activism", "options": ["activism", "action", "engagement", "motivation"], "correctAnswer": "activism"}, {"id": "blank2", "text": "action", "options": ["action", "activism", "engagement", "motivation"], "correctAnswer": "action"}, {"id": "blank3", "text": "commitment", "options": ["commitment", "activism", "action", "engagement"], "correctAnswer": "commitment"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 5, 'Complete the Sentences 2', 'Fill with the correct word', '{"text": "Strong ___ supports ___. ___ prevent young people from acting.", "blanks": [{"id": "blank1", "text": "motivation", "options": ["motivation", "activism", "action", "engagement"], "correctAnswer": "motivation"}, {"id": "blank2", "text": "engagement", "options": ["engagement", "activism", "action", "motivation"], "correctAnswer": "engagement"}, {"id": "blank3", "text": "Barriers", "options": ["Barriers", "Activism", "Action", "Motivation"], "correctAnswer": "Barriers"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_explanation', 6, 'Inversion: Seldom/Rarely', 'Learn inversion with seldom and rarely', '{"rules": "Inversion with seldom/rarely:\n- \"Seldom do young people take action.\" (formal emphasis)\n- \"Rarely have I seen such activism.\" (past emphasis)\n- \"Seldom is environmental action easy.\" (emphasis on difficulty)\n\nStructure:\n- Seldom/Rarely + auxiliary + subject + verb\n- Used for emphasis and formal tone\n\nUse for:\n- Emphasizing rarity: \"Seldom do youth engage in activism.\"\n- Formal statements: \"Rarely have I witnessed such commitment.\"\n- Highlighting infrequency: \"Seldom is environmental action taken.\"", "examples": ["Seldom do young people take environmental action.", "Rarely have I seen such youth activism.", "Seldom is environmental engagement easy.", "Rarely do barriers prevent determined youth.", "Seldom have I witnessed such commitment."]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 7, 'Build Sentences 1', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'Seldom do young people take environmental action.', 'Seldom do young people take environmental action.', '["Seldom", "do", "young", "people", "take", "environmental", "action."]'::jsonb),
    (activity_id_var, 'Rarely have I seen such youth activism.', 'Rarely have I seen such youth activism.', '["Rarely", "have", "I", "seen", "such", "youth", "activism."]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 8, 'Build Sentences 2', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'Seldom is environmental engagement easy.', 'Seldom is environmental engagement easy.', '["Seldom", "is", "environmental", "engagement", "easy."]'::jsonb),
    (activity_id_var, 'Rarely do barriers prevent determined youth.', 'Rarely do barriers prevent determined youth.', '["Rarely", "do", "barriers", "prevent", "determined", "youth."]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'speaking_practice', 9, 'Discuss Environmental Activism', 'Practice speaking about environmental activism', '{"prompts": ["When have you taken action?", "What stopped you from acting more?", "How do young people engage in environmental activism?", "What motivates youth environmental action?", "What barriers prevent young people from acting?"]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (
      lesson_id,
      activity_type,
      activity_order,
      title,
      description,
      content
    ) VALUES (
      'C1-L52',
      'speaking_improvement',
      10,
      'Speaking Improvement',
      'Read the improved version of your speech',
      '{"type": "speaking_improvement", "similarityThreshold": 70}'::jsonb
    );
END $$;



-- =========================================
-- C1 Lesson 53
-- =========================================

-- =========================================
-- Pre-fill Database with Sample Lesson Data
-- C1-L53: Sustainable Lifestyles
-- =========================================
DELETE FROM lesson_activity_results WHERE lesson_id = 'C1-L53';
DELETE FROM user_progress WHERE lesson_id = 'C1-L53';
DELETE FROM lesson_history WHERE lesson_id = 'C1-L53';
DELETE FROM grammar_sentences WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'C1-L53');
DELETE FROM vocabulary_items WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'C1-L53');
DELETE FROM lesson_activities WHERE lesson_id = 'C1-L53';
DELETE FROM lessons WHERE id = 'C1-L53';

INSERT INTO lessons (id, level, lesson_number, topic) VALUES
('C1-L53', 'C1', 53, 'Sustainable Lifestyles')
ON CONFLICT (id) DO UPDATE SET topic = EXCLUDED.topic;

DO $$
DECLARE
    lesson_id_var TEXT := 'C1-L53';
    activity_id_var UUID;
BEGIN
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'warm_up_speaking', 1, 'Sustainable Lifestyles', 'Discuss sustainable lifestyles', '{"prompt": "What habits have you kept while trying to live sustainably?"}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_intro', 2, 'Sustainability Vocabulary', 'Learn vocabulary about sustainability', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'sustainability', 'ความยั่งยืน', NULL),
    (activity_id_var, 'habit', 'นิสัย', NULL),
    (activity_id_var, 'practice', 'การปฏิบัติ', NULL),
    (activity_id_var, 'permanent', 'ถาวร', NULL),
    (activity_id_var, 'maintenance', 'การบำรุงรักษา', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_matching_drag', 3, 'Match Sustainability Words', 'Match English words with Thai meanings', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'sustainability', 'ความยั่งยืน', NULL),
    (activity_id_var, 'habit', 'นิสัย', NULL),
    (activity_id_var, 'practice', 'การปฏิบัติ', NULL),
    (activity_id_var, 'permanent', 'ถาวร', NULL),
    (activity_id_var, 'maintenance', 'การบำรุงรักษา', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 4, 'Complete the Sentences 1', 'Fill with the correct word', '{"text": "Sustainable ___ require ___. Maintaining ___ becomes part of daily life.", "blanks": [{"id": "blank1", "text": "habits", "options": ["habits", "sustainability", "practice", "permanent"], "correctAnswer": "habits"}, {"id": "blank2", "text": "practice", "options": ["practice", "sustainability", "habit", "permanent"], "correctAnswer": "practice"}, {"id": "blank3", "text": "practices", "options": ["practices", "sustainability", "habit", "permanent"], "correctAnswer": "practices"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 5, 'Complete the Sentences 2', 'Fill with the correct word', '{"text": "Some changes become ___. ___ of sustainable habits requires effort.", "blanks": [{"id": "blank1", "text": "permanent", "options": ["permanent", "sustainability", "habit", "practice"], "correctAnswer": "permanent"}, {"id": "blank2", "text": "Maintenance", "options": ["Maintenance", "Sustainability", "Habit", "Practice"], "correctAnswer": "Maintenance"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_explanation', 6, 'Participle Clauses', 'Learn participle clauses', '{"rules": "Participle clauses:\n- Present participle (-ing): \"Maintaining sustainable habits, people live better.\"\n- Past participle (-ed): \"Shaped by sustainability, lifestyles change.\"\n- Perfect participle (having + past participle): \"Having adopted sustainable practices, people maintain them.\"\n\nUse for:\n- Showing simultaneous actions: \"Maintaining habits, you live sustainably.\"\n- Showing cause: \"Shaped by sustainability, lifestyles evolve.\"\n- Showing time sequence: \"Having kept sustainable habits, people maintain them.\"", "examples": ["Maintaining sustainable habits, people live more responsibly.", "Shaped by sustainability, lifestyles change permanently.", "Having adopted sustainable practices, people maintain them.", "Keeping sustainable habits, people reduce their impact.", "Sustaining practices over time, people create lasting change."]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 7, 'Build Sentences 1', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'Maintaining sustainable habits, people live more responsibly.', 'Maintaining sustainable habits, people live more responsibly.', '["Maintaining", "sustainable", "habits,", "people", "live", "more", "responsibly."]'::jsonb),
    (activity_id_var, 'Shaped by sustainability, lifestyles change permanently.', 'Shaped by sustainability, lifestyles change permanently.', '["Shaped", "by", "sustainability,", "lifestyles", "change", "permanently."]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 8, 'Build Sentences 2', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'Having adopted sustainable practices, people maintain them.', 'Having adopted sustainable practices, people maintain them.', '["Having", "adopted", "sustainable", "practices,", "people", "maintain", "them."]'::jsonb),
    (activity_id_var, 'Keeping sustainable habits, people reduce their impact.', 'Keeping sustainable habits, people reduce their impact.', '["Keeping", "sustainable", "habits,", "people", "reduce", "their", "impact."]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'speaking_practice', 9, 'Discuss Sustainable Lifestyles', 'Practice speaking about sustainable lifestyles', '{"prompts": ["What habits have you kept?", "What sustainable practices do you maintain?", "How do you make sustainability part of daily life?", "What changes have become permanent for you?", "What makes sustainable habits hard to maintain?"]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (
      lesson_id,
      activity_type,
      activity_order,
      title,
      description,
      content
    ) VALUES (
      'C1-L53',
      'speaking_improvement',
      10,
      'Speaking Improvement',
      'Read the improved version of your speech',
      '{"type": "speaking_improvement", "similarityThreshold": 70}'::jsonb
    );
END $$;



-- =========================================
-- C1 Lesson 54
-- =========================================

-- =========================================
-- Pre-fill Database with Sample Lesson Data
-- C1-L54: Climate Anxiety
-- =========================================
DELETE FROM lesson_activity_results WHERE lesson_id = 'C1-L54';
DELETE FROM user_progress WHERE lesson_id = 'C1-L54';
DELETE FROM lesson_history WHERE lesson_id = 'C1-L54';
DELETE FROM grammar_sentences WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'C1-L54');
DELETE FROM vocabulary_items WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'C1-L54');
DELETE FROM lesson_activities WHERE lesson_id = 'C1-L54';
DELETE FROM lessons WHERE id = 'C1-L54';

INSERT INTO lessons (id, level, lesson_number, topic) VALUES
('C1-L54', 'C1', 54, 'Climate Anxiety')
ON CONFLICT (id) DO UPDATE SET topic = EXCLUDED.topic;

DO $$
DECLARE
    lesson_id_var TEXT := 'C1-L54';
    activity_id_var UUID;
BEGIN
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'warm_up_speaking', 1, 'Climate Anxiety', 'Discuss climate anxiety', '{"prompt": "What helps you stay calm when thinking about the future?"}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_intro', 2, 'Climate Anxiety Vocabulary', 'Learn vocabulary about climate anxiety', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'anxiety', 'ความวิตกกังวล', NULL),
    (activity_id_var, 'calm', 'ความสงบ', NULL),
    (activity_id_var, 'management', 'การจัดการ', NULL),
    (activity_id_var, 'hope', 'ความหวัง', NULL),
    (activity_id_var, 'balance', 'ความสมดุล', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_matching_drag', 3, 'Match Climate Anxiety Words', 'Match English words with Thai meanings', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'anxiety', 'ความวิตกกังวล', NULL),
    (activity_id_var, 'calm', 'ความสงบ', NULL),
    (activity_id_var, 'management', 'การจัดการ', NULL),
    (activity_id_var, 'hope', 'ความหวัง', NULL),
    (activity_id_var, 'balance', 'ความสมดุล', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 4, 'Complete the Sentences 1', 'Fill with the correct word', '{"text": "Climate ___ affects many. Finding ___ requires ___.", "blanks": [{"id": "blank1", "text": "anxiety", "options": ["anxiety", "calm", "management", "hope"], "correctAnswer": "anxiety"}, {"id": "blank2", "text": "calm", "options": ["calm", "anxiety", "management", "hope"], "correctAnswer": "calm"}, {"id": "blank3", "text": "management", "options": ["management", "anxiety", "calm", "hope"], "correctAnswer": "management"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 5, 'Complete the Sentences 2', 'Fill with the correct word', '{"text": "Maintaining ___ helps. Balancing concern with ___ is important.", "blanks": [{"id": "blank1", "text": "hope", "options": ["hope", "anxiety", "calm", "management"], "correctAnswer": "hope"}, {"id": "blank2", "text": "action", "options": ["action", "anxiety", "calm", "management"], "correctAnswer": "action"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_explanation', 6, 'Nominal Clauses', 'Learn about nominal clauses', '{"rules": "Nominal clauses function as nouns:\n- Subject: \"What you tell yourself affects anxiety.\"\n- Object: \"I believe that hope matters.\"\n- Complement: \"The question is what helps you stay calm.\"\n\nTypes:\n- That-clauses: \"I think that anxiety is manageable.\"\n- Wh-clauses: \"What you tell yourself shapes your response.\"\n- Whether/if: \"The issue is whether hope is possible.\"\n\nUse for:\n- Expressing thoughts: \"What I tell myself is that action helps.\"\n- Asking questions: \"What helps you stay calm?\"\n- Making statements: \"That anxiety exists is understandable.\"", "examples": ["What you tell yourself about the future affects anxiety.", "I believe that hope helps manage climate anxiety.", "The question is what helps you stay calm.", "Whether hope is possible remains debated.", "That anxiety exists is widely recognized."]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 7, 'Build Sentences 1', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'What you tell yourself about the future affects anxiety.', 'What you tell yourself about the future affects anxiety.', '["What", "you", "tell", "yourself", "about", "the", "future", "affects", "anxiety."]'::jsonb),
    (activity_id_var, 'I believe that hope helps manage climate anxiety.', 'I believe that hope helps manage climate anxiety.', '["I", "believe", "that", "hope", "helps", "manage", "climate", "anxiety."]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 8, 'Build Sentences 2', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'The question is what helps you stay calm.', 'The question is what helps you stay calm.', '["The", "question", "is", "what", "helps", "you", "stay", "calm."]'::jsonb),
    (activity_id_var, 'Whether hope is possible remains debated.', 'Whether hope is possible remains debated.', '["Whether", "hope", "is", "possible", "remains", "debated."]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'speaking_practice', 9, 'Discuss Climate Anxiety', 'Practice speaking about climate anxiety', '{"prompts": ["What do you tell yourself about the future?", "What helps you feel calmer?", "How do you manage climate anxiety?", "What helps you stay hopeful?", "How do you balance concern with action?"]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (
      lesson_id,
      activity_type,
      activity_order,
      title,
      description,
      content
    ) VALUES (
      'C1-L54',
      'speaking_improvement',
      10,
      'Speaking Improvement',
      'Read the improved version of your speech',
      '{"type": "speaking_improvement", "similarityThreshold": 70}'::jsonb
    );
END $$;



-- =========================================
-- C1 Lesson 55
-- =========================================

-- =========================================
-- Pre-fill Database with Sample Lesson Data
-- C1-L55: Science Communication & Public Trust
-- =========================================
DELETE FROM lesson_activity_results WHERE lesson_id = 'C1-L55';
DELETE FROM user_progress WHERE lesson_id = 'C1-L55';
DELETE FROM lesson_history WHERE lesson_id = 'C1-L55';
DELETE FROM grammar_sentences WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'C1-L55');
DELETE FROM vocabulary_items WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'C1-L55');
DELETE FROM lesson_activities WHERE lesson_id = 'C1-L55';
DELETE FROM lessons WHERE id = 'C1-L55';

INSERT INTO lessons (id, level, lesson_number, topic) VALUES
('C1-L55', 'C1', 55, 'Science Communication & Public Trust')
ON CONFLICT (id) DO UPDATE SET topic = EXCLUDED.topic;

DO $$
DECLARE
    lesson_id_var TEXT := 'C1-L55';
    activity_id_var UUID;
BEGIN
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'warm_up_speaking', 1, 'Science Communication', 'Discuss science communication', '{"prompt": "How should scientific information be communicated to the public?"}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_intro', 2, 'Science Communication Vocabulary', 'Learn vocabulary about science communication', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'communication', 'การสื่อสาร', NULL),
    (activity_id_var, 'trust', 'ความไว้วางใจ', NULL),
    (activity_id_var, 'evaluation', 'การประเมิน', NULL),
    (activity_id_var, 'effectiveness', 'ประสิทธิภาพ', NULL),
    (activity_id_var, 'claim', 'ข้อเรียกร้อง', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_matching_drag', 3, 'Match Science Communication Words', 'Match English words with Thai meanings', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'communication', 'การสื่อสาร', NULL),
    (activity_id_var, 'trust', 'ความไว้วางใจ', NULL),
    (activity_id_var, 'evaluation', 'การประเมิน', NULL),
    (activity_id_var, 'effectiveness', 'ประสิทธิภาพ', NULL),
    (activity_id_var, 'claim', 'ข้อเรียกร้อง', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 4, 'Complete the Sentences 1', 'Fill with the correct word', '{"text": "Science ___ builds ___. Effective ___ requires clarity.", "blanks": [{"id": "blank1", "text": "communication", "options": ["communication", "trust", "evaluation", "effectiveness"], "correctAnswer": "communication"}, {"id": "blank2", "text": "trust", "options": ["trust", "communication", "evaluation", "effectiveness"], "correctAnswer": "trust"}, {"id": "blank3", "text": "communication", "options": ["communication", "trust", "evaluation", "effectiveness"], "correctAnswer": "communication"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 5, 'Complete the Sentences 2', 'Fill with the correct word', '{"text": "Scientific ___ are evaluated by the public. ___ of communication matters.", "blanks": [{"id": "blank1", "text": "claims", "options": ["claims", "communication", "trust", "evaluation"], "correctAnswer": "claims"}, {"id": "blank2", "text": "Effectiveness", "options": ["Effectiveness", "Communication", "Trust", "Evaluation"], "correctAnswer": "Effectiveness"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_explanation', 6, 'Advanced Passives', 'Learn advanced passive structures', '{"rules": "Advanced passive forms:\n- \"Science should be communicated clearly.\" (obligation)\n- \"Trust must be built over time.\" (necessity)\n- \"Information is being shared.\" (continuous)\n- \"Trust has been lost.\" (perfect)\n- \"Communication will be improved.\" (future)\n\nUse when:\n- Focus is on action, not actor: \"Science should be communicated.\"\n- Actor is unknown/unimportant: \"Trust was built gradually.\"\n- Formal/impersonal tone: \"It is required that science be communicated clearly.\"", "examples": ["Science should be communicated clearly to the public.", "Trust must be built through transparent communication.", "Information is being shared more effectively.", "Trust has been lost due to poor communication.", "Communication will be improved through better methods."]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 7, 'Build Sentences 1', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'Science should be communicated clearly to the public.', 'Science should be communicated clearly to the public.', '["Science", "should", "be", "communicated", "clearly", "to", "the", "public."]'::jsonb),
    (activity_id_var, 'Trust must be built through transparent communication.', 'Trust must be built through transparent communication.', '["Trust", "must", "be", "built", "through", "transparent", "communication."]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 8, 'Build Sentences 2', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'Information is being shared more effectively.', 'Information is being shared more effectively.', '["Information", "is", "being", "shared", "more", "effectively."]'::jsonb),
    (activity_id_var, 'Trust has been lost due to poor communication.', 'Trust has been lost due to poor communication.', '["Trust", "has", "been", "lost", "due", "to", "poor", "communication."]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'speaking_practice', 9, 'Discuss Science Communication', 'Practice speaking about science communication', '{"prompts": ["How should science be communicated?", "Who should lead science communication?", "How is trust in science built or lost?", "What makes scientific communication effective?", "How are scientific claims evaluated by the public?"]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (
      lesson_id,
      activity_type,
      activity_order,
      title,
      description,
      content
    ) VALUES (
      'C1-L55',
      'speaking_improvement',
      10,
      'Speaking Improvement',
      'Read the improved version of your speech',
      '{"type": "speaking_improvement", "similarityThreshold": 70}'::jsonb
    );
END $$;



-- =========================================
-- C1 Lesson 56
-- =========================================

-- =========================================
-- Pre-fill Database with Sample Lesson Data
-- C1-L56: Environmental Education
-- =========================================
DELETE FROM lesson_activity_results WHERE lesson_id = 'C1-L56';
DELETE FROM user_progress WHERE lesson_id = 'C1-L56';
DELETE FROM lesson_history WHERE lesson_id = 'C1-L56';
DELETE FROM grammar_sentences WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'C1-L56');
DELETE FROM vocabulary_items WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'C1-L56');
DELETE FROM lesson_activities WHERE lesson_id = 'C1-L56';
DELETE FROM lessons WHERE id = 'C1-L56';

INSERT INTO lessons (id, level, lesson_number, topic) VALUES
('C1-L56', 'C1', 56, 'Environmental Education')
ON CONFLICT (id) DO UPDATE SET topic = EXCLUDED.topic;

DO $$
DECLARE
    lesson_id_var TEXT := 'C1-L56';
    activity_id_var UUID;
BEGIN
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'warm_up_speaking', 1, 'Environmental Education', 'Discuss environmental education', '{"prompt": "What makes environmental education effective?"}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_intro', 2, 'Environmental Education Vocabulary', 'Learn vocabulary about environmental education', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'education', 'การศึกษา', NULL),
    (activity_id_var, 'effectiveness', 'ประสิทธิภาพ', NULL),
    (activity_id_var, 'measurement', 'การวัด', NULL),
    (activity_id_var, 'impact', 'ผลกระทบ', NULL),
    (activity_id_var, 'assessment', 'การประเมิน', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_matching_drag', 3, 'Match Environmental Education Words', 'Match English words with Thai meanings', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'education', 'การศึกษา', NULL),
    (activity_id_var, 'effectiveness', 'ประสิทธิภาพ', NULL),
    (activity_id_var, 'measurement', 'การวัด', NULL),
    (activity_id_var, 'impact', 'ผลกระทบ', NULL),
    (activity_id_var, 'assessment', 'การประเมิน', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 4, 'Complete the Sentences 1', 'Fill with the correct word', '{"text": "Environmental ___ requires ___. Success should be measured through ___.", "blanks": [{"id": "blank1", "text": "education", "options": ["education", "effectiveness", "measurement", "impact"], "correctAnswer": "education"}, {"id": "blank2", "text": "effectiveness", "options": ["effectiveness", "education", "measurement", "impact"], "correctAnswer": "effectiveness"}, {"id": "blank3", "text": "assessment", "options": ["assessment", "education", "measurement", "impact"], "correctAnswer": "assessment"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 5, 'Complete the Sentences 2', 'Fill with the correct word', '{"text": "Effective ___ creates ___. ___ of learning requires careful ___.", "blanks": [{"id": "blank1", "text": "education", "options": ["education", "effectiveness", "measurement", "impact"], "correctAnswer": "education"}, {"id": "blank2", "text": "impact", "options": ["impact", "education", "measurement", "effectiveness"], "correctAnswer": "impact"}, {"id": "blank3", "text": "Measurement", "options": ["Measurement", "Education", "Effectiveness", "Impact"], "correctAnswer": "Measurement"}, {"id": "blank4", "text": "assessment", "options": ["assessment", "education", "measurement", "impact"], "correctAnswer": "assessment"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_explanation', 6, 'Articles: Generic Reference', 'Learn articles with generic nouns', '{"rules": "Generic reference with articles:\n- Zero article for general concepts: \"Education shapes understanding.\"\n- \"The\" for specific instances: \"The education we receive matters.\"\n- \"A/an\" for classifying: \"Education is a powerful tool.\"\n\nPatterns:\n- General statements: \"Environmental education influences behavior.\"\n- Specific reference: \"The education provided in schools differs.\"\n- Classification: \"Education is a form of empowerment.\"\n\nUse for:\n- General statements: \"Education evolves.\"\n- Specific cases: \"The education we see is changing.\"\n- Classification: \"Education is a lifelong process.\"", "examples": ["Environmental education shapes understanding.", "The education provided in schools creates impact.", "Education is a powerful tool for change.", "The education we receive influences behavior.", "Environmental education requires effective methods."]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 7, 'Build Sentences 1', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'Environmental education shapes understanding.', 'Environmental education shapes understanding.', '["Environmental", "education", "shapes", "understanding."]'::jsonb),
    (activity_id_var, 'The education provided in schools creates impact.', 'The education provided in schools creates impact.', '["The", "education", "provided", "in", "schools", "creates", "impact."]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 8, 'Build Sentences 2', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'Education is a powerful tool for change.', 'Education is a powerful tool for change.', '["Education", "is", "a", "powerful", "tool", "for", "change."]'::jsonb),
    (activity_id_var, 'The education we receive influences behavior.', 'The education we receive influences behavior.', '["The", "education", "we", "receive", "influences", "behavior."]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'speaking_practice', 9, 'Discuss Environmental Education', 'Practice speaking about environmental education', '{"prompts": ["What makes environmental education effective?", "How should success in environmental education be measured?", "How should environmental topics be taught?", "What makes environmental education impactful?", "How is learning about the environment assessed?"]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (
      lesson_id,
      activity_type,
      activity_order,
      title,
      description,
      content
    ) VALUES (
      'C1-L56',
      'speaking_improvement',
      10,
      'Speaking Improvement',
      'Read the improved version of your speech',
      '{"type": "speaking_improvement", "similarityThreshold": 70}'::jsonb
    );
END $$;



-- =========================================
-- C1 Lesson 57
-- =========================================

-- =========================================
-- Pre-fill Database with Sample Lesson Data
-- C1-L57: Green Technology Promises & Limits
-- =========================================
DELETE FROM lesson_activity_results WHERE lesson_id = 'C1-L57';
DELETE FROM user_progress WHERE lesson_id = 'C1-L57';
DELETE FROM lesson_history WHERE lesson_id = 'C1-L57';
DELETE FROM grammar_sentences WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'C1-L57');
DELETE FROM vocabulary_items WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'C1-L57');
DELETE FROM lesson_activities WHERE lesson_id = 'C1-L57';
DELETE FROM lessons WHERE id = 'C1-L57';

INSERT INTO lessons (id, level, lesson_number, topic) VALUES
('C1-L57', 'C1', 57, 'Green Technology Promises & Limits')
ON CONFLICT (id) DO UPDATE SET topic = EXCLUDED.topic;

DO $$
DECLARE
    lesson_id_var TEXT := 'C1-L57';
    activity_id_var UUID;
BEGIN
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'warm_up_speaking', 1, 'Green Technology', 'Discuss green technology', '{"prompt": "What hopes do you have for green technology?"}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_intro', 2, 'Green Technology Vocabulary', 'Learn vocabulary about green technology', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'promise', 'คำสัญญา', NULL),
    (activity_id_var, 'hope', 'ความหวัง', NULL),
    (activity_id_var, 'hype', 'การโฆษณาเกินจริง', NULL),
    (activity_id_var, 'limitation', 'ข้อจำกัด', NULL),
    (activity_id_var, 'realism', 'ความสมจริง', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_matching_drag', 3, 'Match Green Technology Words', 'Match English words with Thai meanings', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'promise', 'คำสัญญา', NULL),
    (activity_id_var, 'hope', 'ความหวัง', NULL),
    (activity_id_var, 'hype', 'การโฆษณาเกินจริง', NULL),
    (activity_id_var, 'limitation', 'ข้อจำกัด', NULL),
    (activity_id_var, 'realism', 'ความสมจริง', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 4, 'Complete the Sentences 1', 'Fill with the correct word', '{"text": "Green technology offers ___. ___ for innovation drives progress.", "blanks": [{"id": "blank1", "text": "promises", "options": ["promises", "hope", "hype", "limitation"], "correctAnswer": "promises"}, {"id": "blank2", "text": "Hope", "options": ["Hope", "Promise", "Hype", "Limitation"], "correctAnswer": "Hope"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 5, 'Complete the Sentences 2', 'Fill with the correct word', '{"text": "Excessive ___ creates false expectations. Understanding ___ requires ___.", "blanks": [{"id": "blank1", "text": "hype", "options": ["hype", "promise", "hope", "limitation"], "correctAnswer": "hype"}, {"id": "blank2", "text": "limitations", "options": ["limitations", "promise", "hope", "hype"], "correctAnswer": "limitations"}, {"id": "blank3", "text": "realism", "options": ["realism", "promise", "hope", "hype"], "correctAnswer": "realism"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_explanation', 6, 'Contrast Linking', 'Learn contrast linking devices', '{"rules": "Contrast linking devices:\n- \"While green technology offers promise, it has limitations.\"\n- \"However, hype can create false expectations.\"\n- \"On the other hand, realism is important.\"\n- \"Whereas some technologies excite, others concern.\"\n\nUse for:\n- Showing contrast: \"While hope exists, limitations remain.\"\n- Balancing views: \"On one hand, technology promises much; on the other, it has limits.\"\n- Comparing: \"Whereas some see promise, others see hype.\"", "examples": ["While green technology offers promise, it has limitations.", "However, hype can create false expectations.", "On the other hand, realism is important for progress.", "Whereas some technologies excite, others concern.", "While hope drives innovation, realism ensures success."]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 7, 'Build Sentences 1', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'While green technology offers promise, it has limitations.', 'While green technology offers promise, it has limitations.', '["While", "green", "technology", "offers", "promise,", "it", "has", "limitations."]'::jsonb),
    (activity_id_var, 'However, hype can create false expectations.', 'However, hype can create false expectations.', '["However,", "hype", "can", "create", "false", "expectations."]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 8, 'Build Sentences 2', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'On the other hand, realism is important for progress.', 'On the other hand, realism is important for progress.', '["On", "the", "other", "hand,", "realism", "is", "important", "for", "progress."]'::jsonb),
    (activity_id_var, 'Whereas some technologies excite, others concern.', 'Whereas some technologies excite, others concern.', '["Whereas", "some", "technologies", "excite,", "others", "concern."]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'speaking_practice', 9, 'Discuss Green Technology', 'Practice speaking about green technology', '{"prompts": ["What hopes do you have for green technology?", "Where do you see exaggeration or hype?", "What green technologies excite you?", "What limitations concern you?", "How do you balance optimism with realism?"]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (
      lesson_id,
      activity_type,
      activity_order,
      title,
      description,
      content
    ) VALUES (
      'C1-L57',
      'speaking_improvement',
      10,
      'Speaking Improvement',
      'Read the improved version of your speech',
      '{"type": "speaking_improvement", "similarityThreshold": 70}'::jsonb
    );
END $$;



-- =========================================
-- C1 Lesson 58
-- =========================================

-- =========================================
-- Pre-fill Database with Sample Lesson Data
-- C1-L58: Consumer Responsibility
-- =========================================
DELETE FROM lesson_activity_results WHERE lesson_id = 'C1-L58';
DELETE FROM user_progress WHERE lesson_id = 'C1-L58';
DELETE FROM lesson_history WHERE lesson_id = 'C1-L58';
DELETE FROM grammar_sentences WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'C1-L58');
DELETE FROM vocabulary_items WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'C1-L58');
DELETE FROM lesson_activities WHERE lesson_id = 'C1-L58';
DELETE FROM lessons WHERE id = 'C1-L58';

INSERT INTO lessons (id, level, lesson_number, topic) VALUES
('C1-L58', 'C1', 58, 'Consumer Responsibility')
ON CONFLICT (id) DO UPDATE SET topic = EXCLUDED.topic;

DO $$
DECLARE
    lesson_id_var TEXT := 'C1-L58';
    activity_id_var UUID;
BEGIN
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'warm_up_speaking', 1, 'Consumer Responsibility', 'Discuss consumer responsibility', '{"prompt": "How could you have made different buying choices in the past?"}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_intro', 2, 'Consumer Responsibility Vocabulary', 'Learn vocabulary about consumer responsibility', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'choice', 'ทางเลือก', NULL),
    (activity_id_var, 'decision', 'การตัดสินใจ', NULL),
    (activity_id_var, 'influence', 'อิทธิพล', NULL),
    (activity_id_var, 'sustainability', 'ความยั่งยืน', NULL),
    (activity_id_var, 'balance', 'ความสมดุล', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_matching_drag', 3, 'Match Consumer Responsibility Words', 'Match English words with Thai meanings', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'choice', 'ทางเลือก', NULL),
    (activity_id_var, 'decision', 'การตัดสินใจ', NULL),
    (activity_id_var, 'influence', 'อิทธิพล', NULL),
    (activity_id_var, 'sustainability', 'ความยั่งยืน', NULL),
    (activity_id_var, 'balance', 'ความสมดุล', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 4, 'Complete the Sentences 1', 'Fill with the correct word', '{"text": "Consumer ___ matter for the environment. Making responsible ___ requires ___.", "blanks": [{"id": "blank1", "text": "choices", "options": ["choices", "decision", "influence", "sustainability"], "correctAnswer": "choices"}, {"id": "blank2", "text": "decisions", "options": ["decisions", "choice", "influence", "sustainability"], "correctAnswer": "decisions"}, {"id": "blank3", "text": "awareness", "options": ["awareness", "choice", "decision", "influence"], "correctAnswer": "awareness"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 5, 'Complete the Sentences 2', 'Fill with the correct word', '{"text": "Various ___ affect buying ___. Balancing cost and ___ is challenging.", "blanks": [{"id": "blank1", "text": "influences", "options": ["influences", "choice", "decision", "sustainability"], "correctAnswer": "influences"}, {"id": "blank2", "text": "choices", "options": ["choices", "decision", "influence", "sustainability"], "correctAnswer": "choices"}, {"id": "blank3", "text": "sustainability", "options": ["sustainability", "choice", "decision", "influence"], "correctAnswer": "sustainability"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_explanation', 6, 'Modals: Speculation in the Past', 'Learn modals for past speculation', '{"rules": "Past speculation with modals:\n- \"might have + past participle\" (possibility): \"I might have bought differently.\"\n- \"could have + past participle\" (ability/possibility): \"I could have made better choices.\"\n- \"may have + past participle\" (possibility): \"I may have chosen more sustainably.\"\n- \"must have + past participle\" (certainty): \"I must have been influenced by price.\"\n\nUse for:\n- Speculating about past: \"I might have bought more sustainably.\"\n- Showing missed opportunity: \"I could have made better choices.\"\n- Expressing certainty: \"I must have been influenced by advertising.\"", "examples": ["I might have bought differently if I had known more.", "I could have made better consumer choices.", "I may have chosen more sustainably with better information.", "I must have been influenced by price in my decisions.", "I could have balanced cost and sustainability better."]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 7, 'Build Sentences 1', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'I might have bought differently if I had known more.', 'I might have bought differently if I had known more.', '["I", "might", "have", "bought", "differently", "if", "I", "had", "known", "more."]'::jsonb),
    (activity_id_var, 'I could have made better consumer choices.', 'I could have made better consumer choices.', '["I", "could", "have", "made", "better", "consumer", "choices."]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 8, 'Build Sentences 2', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'I may have chosen more sustainably with better information.', 'I may have chosen more sustainably with better information.', '["I", "may", "have", "chosen", "more", "sustainably", "with", "better", "information."]'::jsonb),
    (activity_id_var, 'I could have balanced cost and sustainability better.', 'I could have balanced cost and sustainability better.', '["I", "could", "have", "balanced", "cost", "and", "sustainability", "better."]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'speaking_practice', 9, 'Discuss Consumer Responsibility', 'Practice speaking about consumer responsibility', '{"prompts": ["How could you have bought differently?", "What consumer choices matter for the environment?", "How do you make responsible purchasing decisions?", "What influences your buying choices most?", "How do you balance cost and sustainability?"]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (
      lesson_id,
      activity_type,
      activity_order,
      title,
      description,
      content
    ) VALUES (
      'C1-L58',
      'speaking_improvement',
      10,
      'Speaking Improvement',
      'Read the improved version of your speech',
      '{"type": "speaking_improvement", "similarityThreshold": 70}'::jsonb
    );
END $$;



-- =========================================
-- C1 Lesson 59
-- =========================================

-- =========================================
-- Pre-fill Database with Sample Lesson Data
-- C1-L59: Ethics of Environmental Protest
-- =========================================
DELETE FROM lesson_activity_results WHERE lesson_id = 'C1-L59';
DELETE FROM user_progress WHERE lesson_id = 'C1-L59';
DELETE FROM lesson_history WHERE lesson_id = 'C1-L59';
DELETE FROM grammar_sentences WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'C1-L59');
DELETE FROM vocabulary_items WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'C1-L59');
DELETE FROM lesson_activities WHERE lesson_id = 'C1-L59';
DELETE FROM lessons WHERE id = 'C1-L59';

INSERT INTO lessons (id, level, lesson_number, topic) VALUES
('C1-L59', 'C1', 59, 'Ethics of Environmental Protest')
ON CONFLICT (id) DO UPDATE SET topic = EXCLUDED.topic;

DO $$
DECLARE
    lesson_id_var TEXT := 'C1-L59';
    activity_id_var UUID;
BEGIN
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'warm_up_speaking', 1, 'Environmental Protest', 'Discuss ethics of environmental protest', '{"prompt": "If environmental protests were banned, what would you do now?"}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_intro', 2, 'Protest Ethics Vocabulary', 'Learn vocabulary about protest ethics', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'protest', 'การประท้วง', NULL),
    (activity_id_var, 'justification', 'การให้เหตุผล', NULL),
    (activity_id_var, 'ethics', 'จริยธรรม', NULL),
    (activity_id_var, 'disruption', 'การรบกวน', NULL),
    (activity_id_var, 'alternative', 'ทางเลือก', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_matching_drag', 3, 'Match Protest Ethics Words', 'Match English words with Thai meanings', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'protest', 'การประท้วง', NULL),
    (activity_id_var, 'justification', 'การให้เหตุผล', NULL),
    (activity_id_var, 'ethics', 'จริยธรรม', NULL),
    (activity_id_var, 'disruption', 'การรบกวน', NULL),
    (activity_id_var, 'alternative', 'ทางเลือก', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 4, 'Complete the Sentences 1', 'Fill with the correct word', '{"text": "Environmental ___ requires ___. Ethical ___ must be considered.", "blanks": [{"id": "blank1", "text": "protest", "options": ["protest", "justification", "ethics", "disruption"], "correctAnswer": "protest"}, {"id": "blank2", "text": "justification", "options": ["justification", "protest", "ethics", "disruption"], "correctAnswer": "justification"}, {"id": "blank3", "text": "ethics", "options": ["ethics", "protest", "justification", "disruption"], "correctAnswer": "ethics"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 5, 'Complete the Sentences 2', 'Fill with the correct word', '{"text": "Balancing ___ and message is important. ___ to protest exist.", "blanks": [{"id": "blank1", "text": "disruption", "options": ["disruption", "protest", "justification", "ethics"], "correctAnswer": "disruption"}, {"id": "blank2", "text": "Alternatives", "options": ["Alternatives", "Protest", "Justification", "Ethics"], "correctAnswer": "Alternatives"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_explanation', 6, 'Mixed Conditionals', 'Learn mixed conditional structures', '{"rules": "Mixed conditionals combine different time references:\n- Mixed 2/3: \"If protests were banned (present), I would have acted differently (past).\"\n- Mixed 3/2: \"If protests had been banned (past), I would act now (present).\"\n\nStructures:\n- If + past simple, would have + past participle (present condition, past result)\n- If + past perfect, would + base form (past condition, present result)\n\nUse for:\n- Hypothetical present affecting past: \"If protests were banned, I would have found alternatives.\"\n- Unreal past affecting present: \"If protests had been banned, I would act differently now.\"", "examples": ["If protests were banned, I would have found alternatives.", "If protests had been banned, I would act differently now.", "If environmental action were restricted, I would have adapted.", "If protests had been limited, I would seek other methods now.", "If action were banned, I would have changed my approach."]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 7, 'Build Sentences 1', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'If protests were banned, I would have found alternatives.', 'If protests were banned, I would have found alternatives.', '["If", "protests", "were", "banned,", "I", "would", "have", "found", "alternatives."]'::jsonb),
    (activity_id_var, 'If protests had been banned, I would act differently now.', 'If protests had been banned, I would act differently now.', '["If", "protests", "had", "been", "banned,", "I", "would", "act", "differently", "now."]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 8, 'Build Sentences 2', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'If environmental action were restricted, I would have adapted.', 'If environmental action were restricted, I would have adapted.', '["If", "environmental", "action", "were", "restricted,", "I", "would", "have", "adapted."]'::jsonb),
    (activity_id_var, 'If protests had been limited, I would seek other methods now.', 'If protests had been limited, I would seek other methods now.', '["If", "protests", "had", "been", "limited,", "I", "would", "seek", "other", "methods", "now."]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'speaking_practice', 9, 'Discuss Environmental Protest', 'Practice speaking about environmental protest', '{"prompts": ["If protests were banned, what would you do now?", "When is environmental protest justified?", "What forms of protest are ethical?", "How do you balance disruption and message?", "What alternatives to protest exist?"]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (
      lesson_id,
      activity_type,
      activity_order,
      title,
      description,
      content
    ) VALUES (
      'C1-L59',
      'speaking_improvement',
      10,
      'Speaking Improvement',
      'Read the improved version of your speech',
      '{"type": "speaking_improvement", "similarityThreshold": 70}'::jsonb
    );
END $$;



-- =========================================
-- C1 Lesson 60
-- =========================================

-- =========================================
-- Pre-fill Database with Sample Lesson Data
-- C1-L60: Long-term Thinking in Climate Policy
-- =========================================
DELETE FROM lesson_activity_results WHERE lesson_id = 'C1-L60';
DELETE FROM user_progress WHERE lesson_id = 'C1-L60';
DELETE FROM lesson_history WHERE lesson_id = 'C1-L60';
DELETE FROM grammar_sentences WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'C1-L60');
DELETE FROM vocabulary_items WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'C1-L60');
DELETE FROM lesson_activities WHERE lesson_id = 'C1-L60';
DELETE FROM lessons WHERE id = 'C1-L60';

INSERT INTO lessons (id, level, lesson_number, topic) VALUES
('C1-L60', 'C1', 60, 'Long-term Thinking in Climate Policy')
ON CONFLICT (id) DO UPDATE SET topic = EXCLUDED.topic;

DO $$
DECLARE
    lesson_id_var TEXT := 'C1-L60';
    activity_id_var UUID;
BEGIN
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'warm_up_speaking', 1, 'Long-term Thinking', 'Discuss long-term thinking in climate policy', '{"prompt": "How will today''s decisions have shaped the world by 2040?"}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_intro', 2, 'Long-term Thinking Vocabulary', 'Learn vocabulary about long-term thinking', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'consequence', 'ผลที่ตามมา', NULL),
    (activity_id_var, 'generation', 'รุ่น', NULL),
    (activity_id_var, 'policy', 'นโยบาย', NULL),
    (activity_id_var, 'vision', 'วิสัยทัศน์', NULL),
    (activity_id_var, 'balance', 'ความสมดุล', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_matching_drag', 3, 'Match Long-term Thinking Words', 'Match English words with Thai meanings', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'consequence', 'ผลที่ตามมา', NULL),
    (activity_id_var, 'generation', 'รุ่น', NULL),
    (activity_id_var, 'policy', 'นโยบาย', NULL),
    (activity_id_var, 'vision', 'วิสัยทัศน์', NULL),
    (activity_id_var, 'balance', 'ความสมดุล', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 4, 'Complete the Sentences 1', 'Fill with the correct word', '{"text": "Long-term ___ concern future ___. Climate ___ requires ___.", "blanks": [{"id": "blank1", "text": "consequences", "options": ["consequences", "generation", "policy", "vision"], "correctAnswer": "consequences"}, {"id": "blank2", "text": "generations", "options": ["generations", "consequence", "policy", "vision"], "correctAnswer": "generations"}, {"id": "blank3", "text": "policy", "options": ["policy", "consequence", "generation", "vision"], "correctAnswer": "policy"}, {"id": "blank4", "text": "vision", "options": ["vision", "consequence", "generation", "policy"], "correctAnswer": "vision"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 5, 'Complete the Sentences 2', 'Fill with the correct word', '{"text": "Balancing present and future ___ is essential. Long-term ___ shapes outcomes.", "blanks": [{"id": "blank1", "text": "needs", "options": ["needs", "consequence", "generation", "policy"], "correctAnswer": "needs"}, {"id": "blank2", "text": "thinking", "options": ["thinking", "consequence", "generation", "policy"], "correctAnswer": "thinking"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_explanation', 6, 'Advanced Perfect Aspect', 'Learn advanced perfect forms', '{"rules": "Advanced perfect aspect:\n- Future perfect: \"By 2040, decisions will have shaped the world.\"\n- Future perfect continuous: \"By then, we will have been living with consequences for years.\"\n- Perfect in conditional: \"If we had acted, the world would have been different.\"\n\nUse for:\n- Future completion: \"By 2040, today''s choices will have shaped outcomes.\"\n- Duration up to future point: \"By then, we will have been dealing with consequences.\"\n- Hypothetical past: \"If we had acted earlier, the future would have been better.\"", "examples": ["By 2040, today''s decisions will have shaped the world.", "By then, we will have been living with consequences for years.", "If we had acted earlier, the future would have been different.", "By 2040, today''s choices will have determined outcomes.", "Having made long-term decisions, we will see results."]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 7, 'Build Sentences 1', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'By 2040, today''s decisions will have shaped the world.', 'By 2040, today''s decisions will have shaped the world.', '["By", "2040,", "today''s", "decisions", "will", "have", "shaped", "the", "world."]'::jsonb),
    (activity_id_var, 'By then, we will have been living with consequences for years.', 'By then, we will have been living with consequences for years.', '["By", "then,", "we", "will", "have", "been", "living", "with", "consequences", "for", "years."]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 8, 'Build Sentences 2', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'If we had acted earlier, the future would have been different.', 'If we had acted earlier, the future would have been different.', '["If", "we", "had", "acted", "earlier,", "the", "future", "would", "have", "been", "different."]'::jsonb),
    (activity_id_var, 'By 2040, today''s choices will have determined outcomes.', 'By 2040, today''s choices will have determined outcomes.', '["By", "2040,", "today''s", "choices", "will", "have", "determined", "outcomes."]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'speaking_practice', 9, 'Discuss Long-term Thinking', 'Practice speaking about long-term thinking', '{"prompts": ["How will today''s choices have shaped the future?", "What long-term consequences concern you most?", "How do you think about future generations?", "What policies require long-term vision?", "How do you balance present and future needs?"]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (
      lesson_id,
      activity_type,
      activity_order,
      title,
      description,
      content
    ) VALUES (
      'C1-L60',
      'speaking_improvement',
      10,
      'Speaking Improvement',
      'Read the improved version of your speech',
      '{"type": "speaking_improvement", "similarityThreshold": 70}'::jsonb
    );
END $$;



-- =========================================
-- C1 Lesson 61
-- =========================================

-- =========================================
-- Pre-fill Database with Sample Lesson Data
-- C1-L61: Moral Decision-making in Daily Life
-- =========================================
DELETE FROM lesson_activity_results WHERE lesson_id = 'C1-L61';
DELETE FROM user_progress WHERE lesson_id = 'C1-L61';
DELETE FROM lesson_history WHERE lesson_id = 'C1-L61';
DELETE FROM grammar_sentences WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'C1-L61');
DELETE FROM vocabulary_items WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'C1-L61');
DELETE FROM lesson_activities WHERE lesson_id = 'C1-L61';
DELETE FROM lessons WHERE id = 'C1-L61';

INSERT INTO lessons (id, level, lesson_number, topic) VALUES
('C1-L61', 'C1', 61, 'Moral Decision-making in Daily Life')
ON CONFLICT (id) DO UPDATE SET topic = EXCLUDED.topic;

DO $$
DECLARE
    lesson_id_var TEXT := 'C1-L61';
    activity_id_var UUID;
BEGIN
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'warm_up_speaking', 1, 'Moral Decision-making', 'Discuss moral decision-making', '{"prompt": "What makes a small choice a moral one?"}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_intro', 2, 'Moral Decision Vocabulary', 'Learn vocabulary about moral decisions', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'moral', 'ศีลธรรม', NULL),
    (activity_id_var, 'choice', 'ทางเลือก', NULL),
    (activity_id_var, 'decision', 'การตัดสินใจ', NULL),
    (activity_id_var, 'guidance', 'คำแนะนำ', NULL),
    (activity_id_var, 'importance', 'ความสำคัญ', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_matching_drag', 3, 'Match Moral Decision Words', 'Match English words with Thai meanings', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'moral', 'ศีลธรรม', NULL),
    (activity_id_var, 'choice', 'ทางเลือก', NULL),
    (activity_id_var, 'decision', 'การตัดสินใจ', NULL),
    (activity_id_var, 'guidance', 'คำแนะนำ', NULL),
    (activity_id_var, 'importance', 'ความสำคัญ', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 4, 'Complete the Sentences 1', 'Fill with the correct word', '{"text": "Small ___ can be ___. Making ___ requires ___.", "blanks": [{"id": "blank1", "text": "choices", "options": ["choices", "moral", "decision", "guidance"], "correctAnswer": "choices"}, {"id": "blank2", "text": "moral", "options": ["moral", "choice", "decision", "importance"], "correctAnswer": "moral"}, {"id": "blank3", "text": "decisions", "options": ["decisions", "moral", "choice", "guidance"], "correctAnswer": "decisions"}, {"id": "blank4", "text": "guidance", "options": ["guidance", "moral", "choice", "decision"], "correctAnswer": "guidance"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 5, 'Complete the Sentences 2', 'Fill with the correct word', '{"text": "Understanding ___ helps. ___ of choices becomes clear over time.", "blanks": [{"id": "blank1", "text": "morality", "options": ["morality", "moral", "choice", "decision"], "correctAnswer": "morality"}, {"id": "blank2", "text": "Importance", "options": ["Importance", "Moral", "Choice", "Decision"], "correctAnswer": "Importance"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_explanation', 6, 'Articles: Abstract Reference', 'Learn articles with abstract nouns', '{"rules": "Articles with abstract nouns:\n- Use \"the\" when referring to a specific abstract concept: \"the moral choice\"\n- Omit article for general abstract concepts: \"morality guides decisions\"\n- Use \"a/an\" when classifying: \"a moral dilemma\"\n\nStylistic use:\n- \"The\" can emphasize importance: \"the ability to decide\"\n- Zero article for broad concepts: \"morality affects choices\"\n\nUse for:\n- General statements: \"Morality guides daily decisions.\"\n- Specific reference: \"The moral choice is clear.\"\n- Classification: \"A moral decision requires thought.\"", "examples": ["The moral choice requires careful consideration.", "Morality guides daily decision-making.", "A moral dilemma challenges values.", "The ability to make moral decisions develops over time.", "Moral reasoning shapes how we choose."]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 7, 'Build Sentences 1', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'The moral choice requires careful consideration.', 'The moral choice requires careful consideration.', '["The", "moral", "choice", "requires", "careful", "consideration."]'::jsonb),
    (activity_id_var, 'Morality guides daily decision-making.', 'Morality guides daily decision-making.', '["Morality", "guides", "daily", "decision-making."]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 8, 'Build Sentences 2', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'A moral dilemma challenges values.', 'A moral dilemma challenges values.', '["A", "moral", "dilemma", "challenges", "values."]'::jsonb),
    (activity_id_var, 'The ability to make moral decisions develops over time.', 'The ability to make moral decisions develops over time.', '["The", "ability", "to", "make", "moral", "decisions", "develops", "over", "time."]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'speaking_practice', 9, 'Discuss Moral Decision-making', 'Practice speaking about moral decision-making', '{"prompts": ["What makes a small choice moral?", "How do you decide what is right?", "How do you make moral decisions daily?", "What guides your ethical choices?", "When do small choices become morally important?"]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (
      lesson_id,
      activity_type,
      activity_order,
      title,
      description,
      content
    ) VALUES (
      'C1-L61',
      'speaking_improvement',
      10,
      'Speaking Improvement',
      'Read the improved version of your speech',
      '{"type": "speaking_improvement", "similarityThreshold": 70}'::jsonb
    );
END $$;



-- =========================================
-- C1 Lesson 62
-- =========================================

-- =========================================
-- Pre-fill Database with Sample Lesson Data
-- C1-L62: Personal Values vs Social Norms
-- =========================================
DELETE FROM lesson_activity_results WHERE lesson_id = 'C1-L62';
DELETE FROM user_progress WHERE lesson_id = 'C1-L62';
DELETE FROM lesson_history WHERE lesson_id = 'C1-L62';
DELETE FROM grammar_sentences WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'C1-L62');
DELETE FROM vocabulary_items WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'C1-L62');
DELETE FROM lesson_activities WHERE lesson_id = 'C1-L62';
DELETE FROM lessons WHERE id = 'C1-L62';

INSERT INTO lessons (id, level, lesson_number, topic) VALUES
('C1-L62', 'C1', 62, 'Personal Values vs Social Norms')
ON CONFLICT (id) DO UPDATE SET topic = EXCLUDED.topic;

DO $$
DECLARE
    lesson_id_var TEXT := 'C1-L62';
    activity_id_var UUID;
BEGIN
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'warm_up_speaking', 1, 'Values vs Norms', 'Discuss personal values vs social norms', '{"prompt": "What is it that you refuse to change about yourself?"}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_intro', 2, 'Values and Norms Vocabulary', 'Learn vocabulary about values and norms', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'value', 'ค่า', NULL),
    (activity_id_var, 'norm', 'บรรทัดฐาน', NULL),
    (activity_id_var, 'expectation', 'ความคาดหวัง', NULL),
    (activity_id_var, 'priority', 'ลำดับความสำคัญ', NULL),
    (activity_id_var, 'conflict', 'ความขัดแย้ง', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_matching_drag', 3, 'Match Values and Norms Words', 'Match English words with Thai meanings', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'value', 'ค่า', NULL),
    (activity_id_var, 'norm', 'บรรทัดฐาน', NULL),
    (activity_id_var, 'expectation', 'ความคาดหวัง', NULL),
    (activity_id_var, 'priority', 'ลำดับความสำคัญ', NULL),
    (activity_id_var, 'conflict', 'ความขัดแย้ง', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 4, 'Complete the Sentences 1', 'Fill with the correct word', '{"text": "Personal ___ differ from social ___. Balancing ___ requires ___.", "blanks": [{"id": "blank1", "text": "values", "options": ["values", "norm", "expectation", "priority"], "correctAnswer": "values"}, {"id": "blank2", "text": "norms", "options": ["norms", "value", "expectation", "priority"], "correctAnswer": "norms"}, {"id": "blank3", "text": "expectations", "options": ["expectations", "value", "norm", "priority"], "correctAnswer": "expectations"}, {"id": "blank4", "text": "priority", "options": ["priority", "value", "norm", "expectation"], "correctAnswer": "priority"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 5, 'Complete the Sentences 2', 'Fill with the correct word', '{"text": "___ arise between ___ and ___. Prioritizing ___ matters.", "blanks": [{"id": "blank1", "text": "Conflicts", "options": ["Conflicts", "Value", "Norm", "Expectation"], "correctAnswer": "Conflicts"}, {"id": "blank2", "text": "values", "options": ["values", "norm", "expectation", "priority"], "correctAnswer": "values"}, {"id": "blank3", "text": "norms", "options": ["norms", "value", "expectation", "priority"], "correctAnswer": "norms"}, {"id": "blank4", "text": "values", "options": ["values", "norm", "expectation", "priority"], "correctAnswer": "values"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_explanation', 6, 'Cleft Sentences and Emphatic Structures', 'Learn cleft sentences for emphasis', '{"rules": "Cleft sentences emphasize specific elements:\n- It-cleft: \"It is personal values that matter most.\"\n- What-cleft: \"What you refuse to change defines you.\"\n- Wh-cleft: \"What matters is staying true to values.\"\n\nStructure:\n- It + be + emphasized element + that/who clause\n- What + verb + be + emphasized element\n\nUse for:\n- Emphasizing importance: \"It is personal values that guide decisions.\"\n- Highlighting focus: \"What you refuse to change is important.\"\n- Clarifying meaning: \"What matters is balancing values and norms.\"", "examples": ["It is personal values that matter most to you.", "What you refuse to change defines your identity.", "What matters is staying true to your values.", "It is your values that you prioritize.", "What you choose to keep unchanged shows your character."]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 7, 'Build Sentences 1', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'It is personal values that matter most to you.', 'It is personal values that matter most to you.', '["It", "is", "personal", "values", "that", "matter", "most", "to", "you."]'::jsonb),
    (activity_id_var, 'What you refuse to change defines your identity.', 'What you refuse to change defines your identity.', '["What", "you", "refuse", "to", "change", "defines", "your", "identity."]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 8, 'Build Sentences 2', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'What matters is staying true to your values.', 'What matters is staying true to your values.', '["What", "matters", "is", "staying", "true", "to", "your", "values."]'::jsonb),
    (activity_id_var, 'It is your values that you prioritize.', 'It is your values that you prioritize.', '["It", "is", "your", "values", "that", "you", "prioritize."]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'speaking_practice', 9, 'Discuss Values vs Norms', 'Practice speaking about values and norms', '{"prompts": ["What is it that you refuse to change?", "Why is that important to you?", "How do you balance personal values and social expectations?", "When do you prioritize your values?", "What conflicts arise between values and norms?"]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (
      lesson_id,
      activity_type,
      activity_order,
      title,
      description,
      content
    ) VALUES (
      'C1-L62',
      'speaking_improvement',
      10,
      'Speaking Improvement',
      'Read the improved version of your speech',
      '{"type": "speaking_improvement", "similarityThreshold": 70}'::jsonb
    );
END $$;



-- =========================================
-- C1 Lesson 63
-- =========================================

-- =========================================
-- Pre-fill Database with Sample Lesson Data
-- C1-L63: Ethical Dilemmas Without Clear Answers
-- =========================================
DELETE FROM lesson_activity_results WHERE lesson_id = 'C1-L63';
DELETE FROM user_progress WHERE lesson_id = 'C1-L63';
DELETE FROM lesson_history WHERE lesson_id = 'C1-L63';
DELETE FROM grammar_sentences WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'C1-L63');
DELETE FROM vocabulary_items WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'C1-L63');
DELETE FROM lesson_activities WHERE lesson_id = 'C1-L63';
DELETE FROM lessons WHERE id = 'C1-L63';

INSERT INTO lessons (id, level, lesson_number, topic) VALUES
('C1-L63', 'C1', 63, 'Ethical Dilemmas Without Clear Answers')
ON CONFLICT (id) DO UPDATE SET topic = EXCLUDED.topic;

DO $$
DECLARE
    lesson_id_var TEXT := 'C1-L63';
    activity_id_var UUID;
BEGIN
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'warm_up_speaking', 1, 'Ethical Dilemmas', 'Discuss ethical dilemmas', '{"prompt": "If no rule clearly applied, how would you decide?"}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_intro', 2, 'Ethical Dilemma Vocabulary', 'Learn vocabulary about ethical dilemmas', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'dilemma', 'ภาวะที่ลำบาก', NULL),
    (activity_id_var, 'rule', 'กฎ', NULL),
    (activity_id_var, 'guidance', 'คำแนะนำ', NULL),
    (activity_id_var, 'framework', 'กรอบ', NULL),
    (activity_id_var, 'situation', 'สถานการณ์', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_matching_drag', 3, 'Match Ethical Dilemma Words', 'Match English words with Thai meanings', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'dilemma', 'ภาวะที่ลำบาก', NULL),
    (activity_id_var, 'rule', 'กฎ', NULL),
    (activity_id_var, 'guidance', 'คำแนะนำ', NULL),
    (activity_id_var, 'framework', 'กรอบ', NULL),
    (activity_id_var, 'situation', 'สถานการณ์', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 4, 'Complete the Sentences 1', 'Fill with the correct word', '{"text": "Ethical ___ lack clear ___. When ___ conflict, ___ is needed.", "blanks": [{"id": "blank1", "text": "dilemmas", "options": ["dilemmas", "rule", "guidance", "framework"], "correctAnswer": "dilemmas"}, {"id": "blank2", "text": "rules", "options": ["rules", "dilemma", "guidance", "framework"], "correctAnswer": "rules"}, {"id": "blank3", "text": "rules", "options": ["rules", "dilemma", "guidance", "framework"], "correctAnswer": "rules"}, {"id": "blank4", "text": "guidance", "options": ["guidance", "dilemma", "rule", "framework"], "correctAnswer": "guidance"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 5, 'Complete the Sentences 2', 'Fill with the correct word', '{"text": "Making difficult choices requires ___. ___ help in unclear ___.", "blanks": [{"id": "blank1", "text": "frameworks", "options": ["frameworks", "dilemma", "rule", "guidance"], "correctAnswer": "frameworks"}, {"id": "blank2", "text": "Frameworks", "options": ["Frameworks", "Dilemma", "Rule", "Guidance"], "correctAnswer": "Frameworks"}, {"id": "blank3", "text": "situations", "options": ["situations", "dilemma", "rule", "guidance"], "correctAnswer": "situations"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_explanation', 6, 'Mixed and Implied Conditionals', 'Learn mixed and implied conditionals', '{"rules": "Mixed and implied conditionals:\n- Mixed 2/3: \"If no rule fit (present), I would have chosen differently (past).\"\n- Mixed 3/2: \"If rules had conflicted (past), I would decide now (present).\"\n- Implied: \"Without clear rules, I would rely on values.\"\n\nStructures:\n- If + past simple, would have + past participle\n- If + past perfect, would + base form\n- Without/With + noun, would + base form\n\nUse for:\n- Hypothetical present affecting past: \"If no rule fit, I would have used judgment.\"\n- Unreal past affecting present: \"If rules had conflicted, I would decide differently now.\"", "examples": ["If no rule fit, I would have chosen based on values.", "If rules had conflicted, I would decide differently now.", "Without clear guidance, I would rely on principles.", "If no rule applied, I would have used my judgment.", "With conflicting rules, I would prioritize ethics."]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 7, 'Build Sentences 1', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'If no rule fit, I would have chosen based on values.', 'If no rule fit, I would have chosen based on values.', '["If", "no", "rule", "fit,", "I", "would", "have", "chosen", "based", "on", "values."]'::jsonb),
    (activity_id_var, 'If rules had conflicted, I would decide differently now.', 'If rules had conflicted, I would decide differently now.', '["If", "rules", "had", "conflicted,", "I", "would", "decide", "differently", "now."]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 8, 'Build Sentences 2', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'Without clear guidance, I would rely on principles.', 'Without clear guidance, I would rely on principles.', '["Without", "clear", "guidance,", "I", "would", "rely", "on", "principles."]'::jsonb),
    (activity_id_var, 'If no rule applied, I would have used my judgment.', 'If no rule applied, I would have used my judgment.', '["If", "no", "rule", "applied,", "I", "would", "have", "used", "my", "judgment."]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'speaking_practice', 9, 'Discuss Ethical Dilemmas', 'Practice speaking about ethical dilemmas', '{"prompts": ["If no rule fit, how would you choose?", "How do you handle ethical dilemmas?", "What guides you when rules conflict?", "How do you make difficult moral choices?", "What frameworks help in unclear situations?"]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (
      lesson_id,
      activity_type,
      activity_order,
      title,
      description,
      content
    ) VALUES (
      'C1-L63',
      'speaking_improvement',
      10,
      'Speaking Improvement',
      'Read the improved version of your speech',
      '{"type": "speaking_improvement", "similarityThreshold": 70}'::jsonb
    );
END $$;



-- =========================================
-- C1 Lesson 64
-- =========================================

-- =========================================
-- Pre-fill Database with Sample Lesson Data
-- C1-L64: Education Systems
-- =========================================
DELETE FROM lesson_activity_results WHERE lesson_id = 'C1-L64';
DELETE FROM user_progress WHERE lesson_id = 'C1-L64';
DELETE FROM lesson_history WHERE lesson_id = 'C1-L64';
DELETE FROM grammar_sentences WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'C1-L64');
DELETE FROM vocabulary_items WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'C1-L64');
DELETE FROM lesson_activities WHERE lesson_id = 'C1-L64';
DELETE FROM lessons WHERE id = 'C1-L64';

INSERT INTO lessons (id, level, lesson_number, topic) VALUES
('C1-L64', 'C1', 64, 'Education Systems')
ON CONFLICT (id) DO UPDATE SET topic = EXCLUDED.topic;

DO $$
DECLARE
    lesson_id_var TEXT := 'C1-L64';
    activity_id_var UUID;
BEGIN
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'warm_up_speaking', 1, 'Education Systems', 'Discuss education systems', '{"prompt": "What works in the education system where you are?"}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_intro', 2, 'Education System Vocabulary', 'Learn vocabulary about education systems', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'curriculum', 'หลักสูตร', NULL),
    (activity_id_var, 'assessment', 'การประเมิน', NULL),
    (activity_id_var, 'academic', 'ทางวิชาการ', NULL),
    (activity_id_var, 'evaluation', 'การประเมินผล', NULL),
    (activity_id_var, 'framework', 'กรอบงาน', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_matching_drag', 3, 'Match Education Words', 'Match English words with Thai meanings', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'curriculum', 'หลักสูตร', NULL),
    (activity_id_var, 'assessment', 'การประเมิน', NULL),
    (activity_id_var, 'academic', 'ทางวิชาการ', NULL),
    (activity_id_var, 'evaluation', 'การประเมินผล', NULL),
    (activity_id_var, 'framework', 'กรอบงาน', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 4, 'Complete the Sentences 1', 'Fill with the correct word', '{"text": "The ___ needs regular ___. ___ standards require proper ___.", "blanks": [{"id": "blank1", "text": "curriculum", "options": ["curriculum", "assessment", "academic", "evaluation"], "correctAnswer": "curriculum"}, {"id": "blank2", "text": "evaluation", "options": ["evaluation", "curriculum", "assessment", "framework"], "correctAnswer": "evaluation"}, {"id": "blank3", "text": "Academic", "options": ["Academic", "Curriculum", "Assessment", "Framework"], "correctAnswer": "Academic"}, {"id": "blank4", "text": "assessment", "options": ["assessment", "curriculum", "evaluation", "framework"], "correctAnswer": "assessment"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 5, 'Complete the Sentences 2', 'Fill with the correct word', '{"text": "A clear ___ helps structure learning. Regular ___ improves outcomes.", "blanks": [{"id": "blank1", "text": "framework", "options": ["framework", "curriculum", "assessment", "evaluation"], "correctAnswer": "framework"}, {"id": "blank2", "text": "assessment", "options": ["assessment", "curriculum", "evaluation", "framework"], "correctAnswer": "assessment"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_explanation', 6, 'Modals: Degrees of Certainty', 'Learn modals expressing degrees of certainty', '{"rules": "Modals for degrees of certainty:\n- \"must\" (high certainty): \"The system must be effective.\"\n- \"should\" (probable): \"Education should prepare students well.\"\n- \"might/may\" (possible): \"The curriculum might need updates.\"\n- \"could\" (less certain): \"It could work better with changes.\"\n\nUse for:\n- Expressing confidence: \"I am certain this system works.\"\n- Showing uncertainty: \"I am not sure if this approach is best.\"\n- Speculating: \"The framework might need adjustment.\"", "examples": ["The system must be effective.", "Education should prepare students well.", "The curriculum might need updates.", "It could work better with changes.", "You may be certain about the results."]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 7, 'Build Sentences 1', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'The system must be effective.', 'The system must be effective.', '["The", "system", "must", "be", "effective."]'::jsonb),
    (activity_id_var, 'Education should prepare students well.', 'Education should prepare students well.', '["Education", "should", "prepare", "students", "well."]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 8, 'Build Sentences 2', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'The curriculum might need updates.', 'The curriculum might need updates.', '["The", "curriculum", "might", "need", "updates."]'::jsonb),
    (activity_id_var, 'It could work better with changes.', 'It could work better with changes.', '["It", "could", "work", "better", "with", "changes."]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'speaking_practice', 9, 'Discuss Education Systems', 'Practice speaking about education systems', '{"prompts": ["What works in the education system where you are?", "What fails in your current system?", "How sure are you about the effectiveness of your system?", "What might need to change?", "How could the system be improved?"]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (
      lesson_id,
      activity_type,
      activity_order,
      title,
      description,
      content
    ) VALUES (
      'C1-L64',
      'speaking_improvement',
      10,
      'Speaking Improvement',
      'Read the improved version of your speech',
      '{"type": "speaking_improvement", "similarityThreshold": 70}'::jsonb
    );
END $$;



-- =========================================
-- C1 Lesson 65
-- =========================================

-- =========================================
-- Pre-fill Database with Sample Lesson Data
-- C1-L65: Freedom and Accountability
-- =========================================
DELETE FROM lesson_activity_results WHERE lesson_id = 'C1-L65';
DELETE FROM user_progress WHERE lesson_id = 'C1-L65';
DELETE FROM lesson_history WHERE lesson_id = 'C1-L65';
DELETE FROM grammar_sentences WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'C1-L65');
DELETE FROM vocabulary_items WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'C1-L65');
DELETE FROM lesson_activities WHERE lesson_id = 'C1-L65';
DELETE FROM lessons WHERE id = 'C1-L65';

INSERT INTO lessons (id, level, lesson_number, topic) VALUES
('C1-L65', 'C1', 65, 'Freedom and Accountability')
ON CONFLICT (id) DO UPDATE SET topic = EXCLUDED.topic;

DO $$
DECLARE
    lesson_id_var TEXT := 'C1-L65';
    activity_id_var UUID;
BEGIN
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'warm_up_speaking', 1, 'Freedom and Accountability', 'Discuss freedom and accountability', '{"prompt": "Where should the line be drawn between freedom and accountability?"}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_intro', 2, 'Freedom and Accountability Vocabulary', 'Learn vocabulary about freedom and accountability', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'freedom', 'เสรีภาพ', NULL),
    (activity_id_var, 'accountability', 'ความรับผิดชอบ', NULL),
    (activity_id_var, 'balance', 'ความสมดุล', NULL),
    (activity_id_var, 'limit', 'ข้อจำกัด', NULL),
    (activity_id_var, 'interaction', 'การโต้ตอบ', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_matching_drag', 3, 'Match Freedom and Accountability Words', 'Match English words with Thai meanings', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'freedom', 'เสรีภาพ', NULL),
    (activity_id_var, 'accountability', 'ความรับผิดชอบ', NULL),
    (activity_id_var, 'balance', 'ความสมดุล', NULL),
    (activity_id_var, 'limit', 'ข้อจำกัด', NULL),
    (activity_id_var, 'interaction', 'การโต้ตอบ', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 4, 'Complete the Sentences 1', 'Fill with the correct word', '{"text": "Balancing ___ and ___ is essential. ___ must be drawn carefully.", "blanks": [{"id": "blank1", "text": "freedom", "options": ["freedom", "accountability", "balance", "limit"], "correctAnswer": "freedom"}, {"id": "blank2", "text": "accountability", "options": ["accountability", "freedom", "balance", "limit"], "correctAnswer": "accountability"}, {"id": "blank3", "text": "Limits", "options": ["Limits", "Freedom", "Accountability", "Balance"], "correctAnswer": "Limits"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 5, 'Complete the Sentences 2', 'Fill with the correct word', '{"text": "When should ___ be limited? What forms of ___ are necessary? How do these ___ in society?", "blanks": [{"id": "blank1", "text": "freedom", "options": ["freedom", "accountability", "balance", "limit"], "correctAnswer": "freedom"}, {"id": "blank2", "text": "accountability", "options": ["accountability", "freedom", "balance", "limit"], "correctAnswer": "accountability"}, {"id": "blank3", "text": "interact", "options": ["interact", "freedom", "accountability", "balance"], "correctAnswer": "interact"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_explanation', 6, 'Contrast Linking', 'Learn contrast linking devices', '{"rules": "Contrast linking devices:\n- \"While freedom is important, accountability matters too.\"\n- \"However, limits are necessary.\"\n- \"On the other hand, accountability ensures responsibility.\"\n- \"Whereas freedom allows choice, accountability requires answerability.\"\n\nUse for:\n- Showing contrast: \"While freedom exists, accountability is required.\"\n- Balancing views: \"On one hand, freedom is valued; on the other, accountability is needed.\"\n- Comparing: \"Whereas freedom allows action, accountability ensures responsibility.\"", "examples": ["While freedom is important, accountability matters too.", "However, limits are necessary for balance.", "On the other hand, accountability ensures responsibility.", "Whereas freedom allows choice, accountability requires answerability.", "While freedom is valued, accountability cannot be ignored."]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 7, 'Build Sentences 1', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'While freedom is important, accountability matters too.', 'While freedom is important, accountability matters too.', '["While", "freedom", "is", "important,", "accountability", "matters", "too."]'::jsonb),
    (activity_id_var, 'However, limits are necessary for balance.', 'However, limits are necessary for balance.', '["However,", "limits", "are", "necessary", "for", "balance."]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 8, 'Build Sentences 2', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'On the other hand, accountability ensures responsibility.', 'On the other hand, accountability ensures responsibility.', '["On", "the", "other", "hand,", "accountability", "ensures", "responsibility."]'::jsonb),
    (activity_id_var, 'Whereas freedom allows choice, accountability requires answerability.', 'Whereas freedom allows choice, accountability requires answerability.', '["Whereas", "freedom", "allows", "choice,", "accountability", "requires", "answerability."]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'speaking_practice', 9, 'Discuss Freedom and Accountability', 'Practice speaking about freedom and accountability', '{"prompts": ["Where do you draw the line between freedom and accountability?", "How do you balance freedom and responsibility?", "When should freedom be limited?", "What forms of accountability are necessary?", "How do these concepts interact in society?"]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (
      lesson_id,
      activity_type,
      activity_order,
      title,
      description,
      content
    ) VALUES (
      'C1-L65',
      'speaking_improvement',
      10,
      'Speaking Improvement',
      'Read the improved version of your speech',
      '{"type": "speaking_improvement", "similarityThreshold": 70}'::jsonb
    );
END $$;



-- =========================================
-- C1 Lesson 66
-- =========================================

-- =========================================
-- Pre-fill Database with Sample Lesson Data
-- C1-L66: Justice and Fairness
-- =========================================
DELETE FROM lesson_activity_results WHERE lesson_id = 'C1-L66';
DELETE FROM user_progress WHERE lesson_id = 'C1-L66';
DELETE FROM lesson_history WHERE lesson_id = 'C1-L66';
DELETE FROM grammar_sentences WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'C1-L66');
DELETE FROM vocabulary_items WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'C1-L66');
DELETE FROM lesson_activities WHERE lesson_id = 'C1-L66';
DELETE FROM lessons WHERE id = 'C1-L66';

INSERT INTO lessons (id, level, lesson_number, topic) VALUES
('C1-L66', 'C1', 66, 'Justice and Fairness')
ON CONFLICT (id) DO UPDATE SET topic = EXCLUDED.topic;

DO $$
DECLARE
    lesson_id_var TEXT := 'C1-L66';
    activity_id_var UUID;
BEGIN
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'warm_up_speaking', 1, 'Justice and Fairness', 'Discuss justice and fairness', '{"prompt": "How should justice be delivered in society?"}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_intro', 2, 'Justice Vocabulary', 'Learn vocabulary about justice', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'justice', 'ความยุติธรรม', NULL),
    (activity_id_var, 'fairness', 'ความยุติธรรม', NULL),
    (activity_id_var, 'repair', 'การซ่อมแซม', NULL),
    (activity_id_var, 'harm', 'อันตราย', NULL),
    (activity_id_var, 'system', 'ระบบ', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_matching_drag', 3, 'Match Justice Words', 'Match English words with Thai meanings', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'justice', 'ความยุติธรรม', NULL),
    (activity_id_var, 'fairness', 'ความยุติธรรม', NULL),
    (activity_id_var, 'repair', 'การซ่อมแซม', NULL),
    (activity_id_var, 'harm', 'อันตราย', NULL),
    (activity_id_var, 'system', 'ระบบ', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 4, 'Complete the Sentences 1', 'Fill with the correct word', '{"text": "___ must be delivered. ___ must be repaired. ___ requires ___.", "blanks": [{"id": "blank1", "text": "Justice", "options": ["Justice", "Fairness", "Repair", "Harm"], "correctAnswer": "Justice"}, {"id": "blank2", "text": "Harm", "options": ["Harm", "Justice", "Fairness", "Repair"], "correctAnswer": "Harm"}, {"id": "blank3", "text": "Fairness", "options": ["Fairness", "Justice", "Repair", "Harm"], "correctAnswer": "Fairness"}, {"id": "blank4", "text": "systems", "options": ["systems", "justice", "fairness", "repair"], "correctAnswer": "systems"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 5, 'Complete the Sentences 2', 'Fill with the correct word', '{"text": "Effective ___ ensure ___. ___ of harm requires action.", "blanks": [{"id": "blank1", "text": "systems", "options": ["systems", "justice", "fairness", "repair"], "correctAnswer": "systems"}, {"id": "blank2", "text": "justice", "options": ["justice", "fairness", "repair", "harm"], "correctAnswer": "justice"}, {"id": "blank3", "text": "Repair", "options": ["Repair", "Justice", "Fairness", "Harm"], "correctAnswer": "Repair"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_explanation', 6, 'Advanced Passives', 'Learn advanced passive structures', '{"rules": "Advanced passive forms:\n- \"Justice should be delivered fairly.\" (obligation)\n- \"Harm must be repaired.\" (necessity)\n- \"Fairness is being achieved.\" (continuous)\n- \"Justice has been served.\" (perfect)\n- \"Systems will be improved.\" (future)\n\nUse when:\n- Focus is on action, not actor: \"Justice should be delivered.\"\n- Actor is unknown/unimportant: \"Harm was caused by injustice.\"\n- Formal/impersonal tone: \"It is required that justice be served.\"", "examples": ["Justice should be delivered fairly in society.", "Harm must be repaired through justice.", "Fairness is being achieved through better systems.", "Justice has been served in many cases.", "Systems will be improved to ensure fairness."]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 7, 'Build Sentences 1', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'Justice should be delivered fairly in society.', 'Justice should be delivered fairly in society.', '["Justice", "should", "be", "delivered", "fairly", "in", "society."]'::jsonb),
    (activity_id_var, 'Harm must be repaired through justice.', 'Harm must be repaired through justice.', '["Harm", "must", "be", "repaired", "through", "justice."]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 8, 'Build Sentences 2', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'Fairness is being achieved through better systems.', 'Fairness is being achieved through better systems.', '["Fairness", "is", "being", "achieved", "through", "better", "systems."]'::jsonb),
    (activity_id_var, 'Justice has been served in many cases.', 'Justice has been served in many cases.', '["Justice", "has", "been", "served", "in", "many", "cases."]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'speaking_practice', 9, 'Discuss Justice and Fairness', 'Practice speaking about justice and fairness', '{"prompts": ["How should justice be delivered?", "What harms must be repaired?", "What does justice mean to you?", "How is fairness achieved?", "What systems are designed to ensure justice?"]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (
      lesson_id,
      activity_type,
      activity_order,
      title,
      description,
      content
    ) VALUES (
      'C1-L66',
      'speaking_improvement',
      10,
      'Speaking Improvement',
      'Read the improved version of your speech',
      '{"type": "speaking_improvement", "similarityThreshold": 70}'::jsonb
    );
END $$;



-- =========================================
-- C1 Lesson 67
-- =========================================

-- =========================================
-- Pre-fill Database with Sample Lesson Data
-- C1-L67: Moral Courage
-- =========================================
DELETE FROM lesson_activity_results WHERE lesson_id = 'C1-L67';
DELETE FROM user_progress WHERE lesson_id = 'C1-L67';
DELETE FROM lesson_history WHERE lesson_id = 'C1-L67';
DELETE FROM grammar_sentences WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'C1-L67');
DELETE FROM vocabulary_items WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'C1-L67');
DELETE FROM lesson_activities WHERE lesson_id = 'C1-L67';
DELETE FROM lessons WHERE id = 'C1-L67';

INSERT INTO lessons (id, level, lesson_number, topic) VALUES
('C1-L67', 'C1', 67, 'Moral Courage')
ON CONFLICT (id) DO UPDATE SET topic = EXCLUDED.topic;

DO $$
DECLARE
    lesson_id_var TEXT := 'C1-L67';
    activity_id_var UUID;
BEGIN
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'warm_up_speaking', 1, 'Moral Courage', 'Discuss moral courage', '{"prompt": "When have you needed courage to do the right thing?"}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_intro', 2, 'Moral Courage Vocabulary', 'Learn vocabulary about moral courage', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'courage', 'ความกล้าหาญ', NULL),
    (activity_id_var, 'barrier', 'อุปสรรค', NULL),
    (activity_id_var, 'requirement', 'ความต้องการ', NULL),
    (activity_id_var, 'development', 'การพัฒนา', NULL),
    (activity_id_var, 'action', 'การกระทำ', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_matching_drag', 3, 'Match Moral Courage Words', 'Match English words with Thai meanings', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'courage', 'ความกล้าหาญ', NULL),
    (activity_id_var, 'barrier', 'อุปสรรค', NULL),
    (activity_id_var, 'requirement', 'ความต้องการ', NULL),
    (activity_id_var, 'development', 'การพัฒนา', NULL),
    (activity_id_var, 'action', 'การกระทำ', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 4, 'Complete the Sentences 1', 'Fill with the correct word', '{"text": "Moral ___ requires ___. ___ can hold people back.", "blanks": [{"id": "blank1", "text": "courage", "options": ["courage", "barrier", "requirement", "development"], "correctAnswer": "courage"}, {"id": "blank2", "text": "action", "options": ["action", "courage", "barrier", "requirement"], "correctAnswer": "action"}, {"id": "blank3", "text": "Barriers", "options": ["Barriers", "Courage", "Requirement", "Development"], "correctAnswer": "Barriers"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 5, 'Complete the Sentences 2', 'Fill with the correct word', '{"text": "When is ___ required? ___ of courage takes practice.", "blanks": [{"id": "blank1", "text": "courage", "options": ["courage", "barrier", "requirement", "development"], "correctAnswer": "courage"}, {"id": "blank2", "text": "Development", "options": ["Development", "Courage", "Barrier", "Requirement"], "correctAnswer": "Development"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_explanation', 6, 'Inversion: Little/Rarely', 'Learn inversion with little and rarely', '{"rules": "Inversion with little/rarely:\n- \"Little did I know courage was needed.\" (formal emphasis)\n- \"Rarely do people show moral courage.\" (emphasis on infrequency)\n- \"Little had I expected such challenges.\" (past emphasis)\n\nStructure:\n- Little/Rarely + auxiliary + subject + verb\n- Used for emphasis and formal tone\n\nUse for:\n- Emphasizing rarity: \"Rarely do people act with moral courage.\"\n- Formal statements: \"Little did I realize the courage required.\"\n- Highlighting infrequency: \"Rarely is moral courage easy.\"", "examples": ["Little did I know courage was needed.", "Rarely do people show moral courage easily.", "Little had I expected such moral challenges.", "Rarely is moral courage displayed without fear.", "Little do people realize the courage required."]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 7, 'Build Sentences 1', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'Little did I know courage was needed.', 'Little did I know courage was needed.', '["Little", "did", "I", "know", "courage", "was", "needed."]'::jsonb),
    (activity_id_var, 'Rarely do people show moral courage easily.', 'Rarely do people show moral courage easily.', '["Rarely", "do", "people", "show", "moral", "courage", "easily."]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 8, 'Build Sentences 2', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'Little had I expected such moral challenges.', 'Little had I expected such moral challenges.', '["Little", "had", "I", "expected", "such", "moral", "challenges."]'::jsonb),
    (activity_id_var, 'Rarely is moral courage displayed without fear.', 'Rarely is moral courage displayed without fear.', '["Rarely", "is", "moral", "courage", "displayed", "without", "fear."]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'speaking_practice', 9, 'Discuss Moral Courage', 'Practice speaking about moral courage', '{"prompts": ["When did you show moral courage?", "What held you back?", "What does moral courage mean to you?", "When is courage required?", "How can moral courage be developed?"]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (
      lesson_id,
      activity_type,
      activity_order,
      title,
      description,
      content
    ) VALUES (
      'C1-L67',
      'speaking_improvement',
      10,
      'Speaking Improvement',
      'Read the improved version of your speech',
      '{"type": "speaking_improvement", "similarityThreshold": 70}'::jsonb
    );
END $$;



-- =========================================
-- C1 Lesson 68
-- =========================================

-- =========================================
-- Pre-fill Database with Sample Lesson Data
-- C1-L68: Individual Impact on Society
-- =========================================
DELETE FROM lesson_activity_results WHERE lesson_id = 'C1-L68';
DELETE FROM user_progress WHERE lesson_id = 'C1-L68';
DELETE FROM lesson_history WHERE lesson_id = 'C1-L68';
DELETE FROM grammar_sentences WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'C1-L68');
DELETE FROM vocabulary_items WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'C1-L68');
DELETE FROM lesson_activities WHERE lesson_id = 'C1-L68';
DELETE FROM lessons WHERE id = 'C1-L68';

INSERT INTO lessons (id, level, lesson_number, topic) VALUES
('C1-L68', 'C1', 68, 'Individual Impact on Society')
ON CONFLICT (id) DO UPDATE SET topic = EXCLUDED.topic;

DO $$
DECLARE
    lesson_id_var TEXT := 'C1-L68';
    activity_id_var UUID;
BEGIN
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'warm_up_speaking', 1, 'Individual Impact', 'Discuss individual impact on society', '{"prompt": "How are your actions contributing to society over time?"}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_intro', 2, 'Individual Impact Vocabulary', 'Learn vocabulary about individual impact', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'impact', 'ผลกระทบ', NULL),
    (activity_id_var, 'contribution', 'การมีส่วนร่วม', NULL),
    (activity_id_var, 'effect', 'ผลกระทบ', NULL),
    (activity_id_var, 'change', 'การเปลี่ยนแปลง', NULL),
    (activity_id_var, 'accumulation', 'การสะสม', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_matching_drag', 3, 'Match Individual Impact Words', 'Match English words with Thai meanings', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'impact', 'ผลกระทบ', NULL),
    (activity_id_var, 'contribution', 'การมีส่วนร่วม', NULL),
    (activity_id_var, 'effect', 'ผลกระทบ', NULL),
    (activity_id_var, 'change', 'การเปลี่ยนแปลง', NULL),
    (activity_id_var, 'accumulation', 'การสะสม', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 4, 'Complete the Sentences 1', 'Fill with the correct word', '{"text": "Individual ___ creates ___. Small ___ accumulate over time.", "blanks": [{"id": "blank1", "text": "actions", "options": ["actions", "impact", "contribution", "effect"], "correctAnswer": "actions"}, {"id": "blank2", "text": "change", "options": ["change", "impact", "contribution", "effect"], "correctAnswer": "change"}, {"id": "blank3", "text": "contributions", "options": ["contributions", "impact", "action", "effect"], "correctAnswer": "contributions"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 5, 'Complete the Sentences 2', 'Fill with the correct word', '{"text": "___ of effects creates significant ___. One person can have ___.", "blanks": [{"id": "blank1", "text": "Accumulation", "options": ["Accumulation", "Impact", "Contribution", "Effect"], "correctAnswer": "Accumulation"}, {"id": "blank2", "text": "impact", "options": ["impact", "contribution", "effect", "change"], "correctAnswer": "impact"}, {"id": "blank3", "text": "impact", "options": ["impact", "contribution", "effect", "change"], "correctAnswer": "impact"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_explanation', 6, 'Participle Clauses', 'Learn participle clauses', '{"rules": "Participle clauses:\n- Present participle (-ing): \"Contributing to society, people create change.\"\n- Past participle (-ed): \"Shaped by actions, society evolves.\"\n- Perfect participle (having + past participle): \"Having contributed over time, people see impact.\"\n\nUse for:\n- Showing simultaneous actions: \"Contributing now, you create change.\"\n- Showing cause: \"Shaped by individual actions, society changes.\"\n- Showing time sequence: \"Having accumulated effects, contributions matter.\"", "examples": ["Contributing to society, people create meaningful change.", "Shaped by individual actions, society evolves.", "Having contributed over time, people see their impact.", "Accumulating effects, small actions create significant change.", "Creating change, individuals influence society."]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 7, 'Build Sentences 1', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'Contributing to society, people create meaningful change.', 'Contributing to society, people create meaningful change.', '["Contributing", "to", "society,", "people", "create", "meaningful", "change."]'::jsonb),
    (activity_id_var, 'Shaped by individual actions, society evolves.', 'Shaped by individual actions, society evolves.', '["Shaped", "by", "individual", "actions,", "society", "evolves."]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 8, 'Build Sentences 2', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'Having contributed over time, people see their impact.', 'Having contributed over time, people see their impact.', '["Having", "contributed", "over", "time,", "people", "see", "their", "impact."]'::jsonb),
    (activity_id_var, 'Accumulating effects, small actions create significant change.', 'Accumulating effects, small actions create significant change.', '["Accumulating", "effects,", "small", "actions", "create", "significant", "change."]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'speaking_practice', 9, 'Discuss Individual Impact', 'Practice speaking about individual impact', '{"prompts": ["How are you contributing now?", "What effects accumulate over time?", "How do individual actions create change?", "What impact can one person have?", "How do small contributions add up?"]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (
      lesson_id,
      activity_type,
      activity_order,
      title,
      description,
      content
    ) VALUES (
      'C1-L68',
      'speaking_improvement',
      10,
      'Speaking Improvement',
      'Read the improved version of your speech',
      '{"type": "speaking_improvement", "similarityThreshold": 70}'::jsonb
    );
END $$;



-- =========================================
-- C1 Lesson 69
-- =========================================

-- =========================================
-- Pre-fill Database with Sample Lesson Data
-- C1-L69: Altruism vs Self-interest
-- =========================================
DELETE FROM lesson_activity_results WHERE lesson_id = 'C1-L69';
DELETE FROM user_progress WHERE lesson_id = 'C1-L69';
DELETE FROM lesson_history WHERE lesson_id = 'C1-L69';
DELETE FROM grammar_sentences WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'C1-L69');
DELETE FROM vocabulary_items WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'C1-L69');
DELETE FROM lesson_activities WHERE lesson_id = 'C1-L69';
DELETE FROM lessons WHERE id = 'C1-L69';

INSERT INTO lessons (id, level, lesson_number, topic) VALUES
('C1-L69', 'C1', 69, 'Altruism vs Self-interest')
ON CONFLICT (id) DO UPDATE SET topic = EXCLUDED.topic;

DO $$
DECLARE
    lesson_id_var TEXT := 'C1-L69';
    activity_id_var UUID;
BEGIN
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'warm_up_speaking', 1, 'Altruism vs Self-interest', 'Discuss altruism vs self-interest', '{"prompt": "What do you believe motivates people''s actions?"}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_intro', 2, 'Altruism Vocabulary', 'Learn vocabulary about altruism', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'altruism', 'การเห็นแก่ผู้อื่น', NULL),
    (activity_id_var, 'motive', 'แรงจูงใจ', NULL),
    (activity_id_var, 'selflessness', 'การไม่เห็นแก่ตัว', NULL),
    (activity_id_var, 'balance', 'ความสมดุล', NULL),
    (activity_id_var, 'behavior', 'พฤติกรรม', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_matching_drag', 3, 'Match Altruism Words', 'Match English words with Thai meanings', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'altruism', 'การเห็นแก่ผู้อื่น', NULL),
    (activity_id_var, 'motive', 'แรงจูงใจ', NULL),
    (activity_id_var, 'selflessness', 'การไม่เห็นแก่ตัว', NULL),
    (activity_id_var, 'balance', 'ความสมดุล', NULL),
    (activity_id_var, 'behavior', 'พฤติกรรม', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 4, 'Complete the Sentences 1', 'Fill with the correct word', '{"text": "Human ___ vary. ___ actions may be rare. ___ requires ___.", "blanks": [{"id": "blank1", "text": "motives", "options": ["motives", "altruism", "selflessness", "balance"], "correctAnswer": "motives"}, {"id": "blank2", "text": "Purely", "options": ["Purely", "Altruism", "Selflessness", "Balance"], "correctAnswer": "Purely"}, {"id": "blank3", "text": "Balance", "options": ["Balance", "Altruism", "Selflessness", "Motive"], "correctAnswer": "Balance"}, {"id": "blank4", "text": "consideration", "options": ["consideration", "altruism", "selflessness", "balance"], "correctAnswer": "consideration"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 5, 'Complete the Sentences 2', 'Fill with the correct word', '{"text": "Selfless ___ helps others. ___ motivates such ___.", "blanks": [{"id": "blank1", "text": "behavior", "options": ["behavior", "altruism", "selflessness", "motive"], "correctAnswer": "behavior"}, {"id": "blank2", "text": "Altruism", "options": ["Altruism", "Selflessness", "Motive", "Balance"], "correctAnswer": "Altruism"}, {"id": "blank3", "text": "actions", "options": ["actions", "altruism", "selflessness", "motive"], "correctAnswer": "actions"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_explanation', 6, 'Nominal Clauses', 'Learn about nominal clauses', '{"rules": "Nominal clauses function as nouns:\n- Subject: \"What you believe about motives shapes behavior.\"\n- Object: \"I think that altruism exists.\"\n- Complement: \"The question is when you act selflessly.\"\n\nTypes:\n- That-clauses: \"I believe that people can be selfless.\"\n- Wh-clauses: \"What you believe about motives matters.\"\n- Whether/if: \"The issue is whether actions are purely altruistic.\"\n\nUse for:\n- Expressing beliefs: \"What I believe is that motives vary.\"\n- Asking questions: \"When do you act selflessly?\"\n- Making statements: \"That altruism exists is debated.\"", "examples": ["What you believe about human motives shapes your view.", "I think that altruism can exist.", "The question is when you act selflessly.", "Whether actions are purely altruistic remains debated.", "That selflessness exists is widely accepted."]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 7, 'Build Sentences 1', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'What you believe about human motives shapes your view.', 'What you believe about human motives shapes your view.', '["What", "you", "believe", "about", "human", "motives", "shapes", "your", "view."]'::jsonb),
    (activity_id_var, 'I think that altruism can exist.', 'I think that altruism can exist.', '["I", "think", "that", "altruism", "can", "exist."]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 8, 'Build Sentences 2', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'The question is when you act selflessly.', 'The question is when you act selflessly.', '["The", "question", "is", "when", "you", "act", "selflessly."]'::jsonb),
    (activity_id_var, 'Whether actions are purely altruistic remains debated.', 'Whether actions are purely altruistic remains debated.', '["Whether", "actions", "are", "purely", "altruistic", "remains", "debated."]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'speaking_practice', 9, 'Discuss Altruism vs Self-interest', 'Practice speaking about altruism', '{"prompts": ["What do you believe about human motives?", "When do you act selflessly?", "Can actions be purely altruistic?", "How do you balance self-interest and helping others?", "What motivates selfless behavior?"]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (
      lesson_id,
      activity_type,
      activity_order,
      title,
      description,
      content
    ) VALUES (
      'C1-L69',
      'speaking_improvement',
      10,
      'Speaking Improvement',
      'Read the improved version of your speech',
      '{"type": "speaking_improvement", "similarityThreshold": 70}'::jsonb
    );
END $$;



-- =========================================
-- C1 Lesson 70
-- =========================================

-- =========================================
-- Pre-fill Database with Sample Lesson Data
-- C1-L70: Defining Ethical Behavior
-- =========================================
DELETE FROM lesson_activity_results WHERE lesson_id = 'C1-L70';
DELETE FROM user_progress WHERE lesson_id = 'C1-L70';
DELETE FROM lesson_history WHERE lesson_id = 'C1-L70';
DELETE FROM grammar_sentences WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'C1-L70');
DELETE FROM vocabulary_items WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'C1-L70');
DELETE FROM lesson_activities WHERE lesson_id = 'C1-L70';
DELETE FROM lessons WHERE id = 'C1-L70';

INSERT INTO lessons (id, level, lesson_number, topic) VALUES
('C1-L70', 'C1', 70, 'Defining Ethical Behavior')
ON CONFLICT (id) DO UPDATE SET topic = EXCLUDED.topic;

DO $$
DECLARE
    lesson_id_var TEXT := 'C1-L70';
    activity_id_var UUID;
BEGIN
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'warm_up_speaking', 1, 'Ethical Behavior', 'Discuss defining ethical behavior', '{"prompt": "How could you have acted more ethically in a past situation?"}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_intro', 2, 'Ethical Behavior Vocabulary', 'Learn vocabulary about ethical behavior', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'ethics', 'จริยธรรม', NULL),
    (activity_id_var, 'behavior', 'พฤติกรรม', NULL),
    (activity_id_var, 'standard', 'มาตรฐาน', NULL),
    (activity_id_var, 'mistake', 'ข้อผิดพลาด', NULL),
    (activity_id_var, 'guidance', 'คำแนะนำ', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_matching_drag', 3, 'Match Ethical Behavior Words', 'Match English words with Thai meanings', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'ethics', 'จริยธรรม', NULL),
    (activity_id_var, 'behavior', 'พฤติกรรม', NULL),
    (activity_id_var, 'standard', 'มาตรฐาน', NULL),
    (activity_id_var, 'mistake', 'ข้อผิดพลาด', NULL),
    (activity_id_var, 'guidance', 'คำแนะนำ', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 4, 'Complete the Sentences 1', 'Fill with the correct word', '{"text": "Ethical ___ requires ___. ___ guide ___.", "blanks": [{"id": "blank1", "text": "behavior", "options": ["behavior", "ethics", "standard", "mistake"], "correctAnswer": "behavior"}, {"id": "blank2", "text": "standards", "options": ["standards", "ethics", "behavior", "mistake"], "correctAnswer": "standards"}, {"id": "blank3", "text": "Standards", "options": ["Standards", "Ethics", "Behavior", "Mistake"], "correctAnswer": "Standards"}, {"id": "blank4", "text": "behavior", "options": ["behavior", "ethics", "standard", "mistake"], "correctAnswer": "behavior"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 5, 'Complete the Sentences 2', 'Fill with the correct word', '{"text": "Learning from ___ improves ___. ___ helps define ___.", "blanks": [{"id": "blank1", "text": "mistakes", "options": ["mistakes", "ethics", "behavior", "standard"], "correctAnswer": "mistakes"}, {"id": "blank2", "text": "behavior", "options": ["behavior", "ethics", "mistake", "standard"], "correctAnswer": "behavior"}, {"id": "blank3", "text": "Guidance", "options": ["Guidance", "Ethics", "Behavior", "Standard"], "correctAnswer": "Guidance"}, {"id": "blank4", "text": "ethics", "options": ["ethics", "behavior", "mistake", "standard"], "correctAnswer": "ethics"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_explanation', 6, 'Modals: Criticism in the Past', 'Learn modals for past criticism', '{"rules": "Past criticism with modals:\n- \"should have + past participle\" (criticism/regret): \"I should have acted more ethically.\"\n- \"ought to have + past participle\" (stronger criticism): \"I ought to have behaved better.\"\n- \"could have + past participle\" (missed opportunity): \"I could have made better choices.\"\n\nUse for:\n- Criticizing past actions: \"I should have acted more ethically in that moment.\"\n- Expressing regret: \"I ought to have behaved better.\"\n- Showing missed opportunities: \"I could have made more ethical decisions.\"", "examples": ["I should have acted more ethically in that situation.", "I ought to have behaved better at that moment.", "I could have made more ethical choices.", "I should have considered the ethical implications.", "I could have acted with greater integrity."]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 7, 'Build Sentences 1', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'I should have acted more ethically in that situation.', 'I should have acted more ethically in that situation.', '["I", "should", "have", "acted", "more", "ethically", "in", "that", "situation."]'::jsonb),
    (activity_id_var, 'I ought to have behaved better at that moment.', 'I ought to have behaved better at that moment.', '["I", "ought", "to", "have", "behaved", "better", "at", "that", "moment."]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 8, 'Build Sentences 2', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'I could have made more ethical choices.', 'I could have made more ethical choices.', '["I", "could", "have", "made", "more", "ethical", "choices."]'::jsonb),
    (activity_id_var, 'I should have considered the ethical implications.', 'I should have considered the ethical implications.', '["I", "should", "have", "considered", "the", "ethical", "implications."]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'speaking_practice', 9, 'Discuss Ethical Behavior', 'Practice speaking about ethical behavior', '{"prompts": ["How could you have acted better in that moment?", "How do you define ethical behavior?", "What makes behavior ethical?", "How do you learn from ethical mistakes?", "What standards guide your behavior?"]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (
      lesson_id,
      activity_type,
      activity_order,
      title,
      description,
      content
    ) VALUES (
      'C1-L70',
      'speaking_improvement',
      10,
      'Speaking Improvement',
      'Read the improved version of your speech',
      '{"type": "speaking_improvement", "similarityThreshold": 70}'::jsonb
    );
END $$;



-- =========================================
-- C1 Lesson 71
-- =========================================

-- =========================================
-- Pre-fill Database with Sample Lesson Data
-- C1-L71: Psychological Well-being of Students
-- =========================================
DELETE FROM lesson_activity_results WHERE lesson_id = 'C1-L71';
DELETE FROM user_progress WHERE lesson_id = 'C1-L71';
DELETE FROM lesson_history WHERE lesson_id = 'C1-L71';
DELETE FROM grammar_sentences WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'C1-L71');
DELETE FROM vocabulary_items WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'C1-L71');
DELETE FROM lesson_activities WHERE lesson_id = 'C1-L71';
DELETE FROM lessons WHERE id = 'C1-L71';

INSERT INTO lessons (id, level, lesson_number, topic) VALUES
('C1-L71', 'C1', 71, 'Psychological Well-being of Students')
ON CONFLICT (id) DO UPDATE SET topic = EXCLUDED.topic;

DO $$
DECLARE
    lesson_id_var TEXT := 'C1-L71';
    activity_id_var UUID;
BEGIN
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'warm_up_speaking', 1, 'Student Well-being', 'Discuss psychological well-being', '{"prompt": "How has your well-being changed over recent semesters?"}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_intro', 2, 'Well-being Vocabulary', 'Learn vocabulary about well-being', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'wellbeing', 'ความเป็นอยู่ที่ดี', NULL),
    (activity_id_var, 'health', 'สุขภาพ', NULL),
    (activity_id_var, 'maintenance', 'การบำรุงรักษา', NULL),
    (activity_id_var, 'support', 'การสนับสนุน', NULL),
    (activity_id_var, 'recognition', 'การยอมรับ', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_matching_drag', 3, 'Match Well-being Words', 'Match English words with Thai meanings', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'wellbeing', 'ความเป็นอยู่ที่ดี', NULL),
    (activity_id_var, 'health', 'สุขภาพ', NULL),
    (activity_id_var, 'maintenance', 'การบำรุงรักษา', NULL),
    (activity_id_var, 'support', 'การสนับสนุน', NULL),
    (activity_id_var, 'recognition', 'การยอมรับ', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 4, 'Complete the Sentences 1', 'Fill with the correct word', '{"text": "Student ___ affects learning. Maintaining ___ requires ___.", "blanks": [{"id": "blank1", "text": "wellbeing", "options": ["wellbeing", "health", "maintenance", "support"], "correctAnswer": "wellbeing"}, {"id": "blank2", "text": "wellbeing", "options": ["wellbeing", "health", "maintenance", "support"], "correctAnswer": "wellbeing"}, {"id": "blank3", "text": "effort", "options": ["effort", "wellbeing", "health", "maintenance"], "correctAnswer": "effort"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 5, 'Complete the Sentences 2', 'Fill with the correct word', '{"text": "Mental ___ needs ___. ___ of needs helps students.", "blanks": [{"id": "blank1", "text": "health", "options": ["health", "wellbeing", "maintenance", "support"], "correctAnswer": "health"}, {"id": "blank2", "text": "support", "options": ["support", "wellbeing", "health", "maintenance"], "correctAnswer": "support"}, {"id": "blank3", "text": "Recognition", "options": ["Recognition", "Wellbeing", "Health", "Support"], "correctAnswer": "Recognition"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_explanation', 6, 'Advanced Perfect Aspect', 'Learn advanced perfect forms', '{"rules": "Advanced perfect aspect:\n- Present perfect: \"I have changed my well-being over time.\"\n- Past perfect: \"I had improved my well-being before the semester.\"\n- Future perfect: \"I will have maintained well-being by then.\"\n- Perfect continuous: \"I have been working on well-being for months.\"\n\nUse for:\n- Completed actions with present relevance: \"I have changed my well-being across semesters.\"\n- Past before past: \"I had improved well-being before challenges arose.\"\n- Future completion: \"I will have maintained well-being by next semester.\"", "examples": ["I have changed my well-being over recent semesters.", "I had improved my well-being before the challenges.", "I will have maintained well-being by next semester.", "I have been working on well-being for months.", "Having improved well-being, I feel better now."]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 7, 'Build Sentences 1', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'I have changed my well-being over recent semesters.', 'I have changed my well-being over recent semesters.', '["I", "have", "changed", "my", "well-being", "over", "recent", "semesters."]'::jsonb),
    (activity_id_var, 'I had improved my well-being before the challenges.', 'I had improved my well-being before the challenges.', '["I", "had", "improved", "my", "well-being", "before", "the", "challenges."]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 8, 'Build Sentences 2', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'I have been working on well-being for months.', 'I have been working on well-being for months.', '["I", "have", "been", "working", "on", "well-being", "for", "months."]'::jsonb),
    (activity_id_var, 'Having improved well-being, I feel better now.', 'Having improved well-being, I feel better now.', '["Having", "improved", "well-being,", "I", "feel", "better", "now."]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'speaking_practice', 9, 'Discuss Well-being', 'Practice speaking about well-being', '{"prompts": ["How has your well-being changed over time?", "What affects student mental health most?", "How do you maintain well-being during studies?", "What support do students need?", "How do you recognize when you need help?"]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (
      lesson_id,
      activity_type,
      activity_order,
      title,
      description,
      content
    ) VALUES (
      'C1-L71',
      'speaking_improvement',
      10,
      'Speaking Improvement',
      'Read the improved version of your speech',
      '{"type": "speaking_improvement", "similarityThreshold": 70}'::jsonb
    );
END $$;



-- =========================================
-- C1 Lesson 72
-- =========================================

-- =========================================
-- Pre-fill Database with Sample Lesson Data
-- C1-L72: Burnout Culture in Education
-- =========================================
DELETE FROM lesson_activity_results WHERE lesson_id = 'C1-L72';
DELETE FROM user_progress WHERE lesson_id = 'C1-L72';
DELETE FROM lesson_history WHERE lesson_id = 'C1-L72';
DELETE FROM grammar_sentences WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'C1-L72');
DELETE FROM vocabulary_items WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'C1-L72');
DELETE FROM lesson_activities WHERE lesson_id = 'C1-L72';
DELETE FROM lessons WHERE id = 'C1-L72';

INSERT INTO lessons (id, level, lesson_number, topic) VALUES
('C1-L72', 'C1', 72, 'Burnout Culture in Education')
ON CONFLICT (id) DO UPDATE SET topic = EXCLUDED.topic;

DO $$
DECLARE
    lesson_id_var TEXT := 'C1-L72';
    activity_id_var UUID;
BEGIN
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'warm_up_speaking', 1, 'Burnout Culture', 'Discuss burnout culture', '{"prompt": "What contributes most to burnout in education?"}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_intro', 2, 'Burnout Vocabulary', 'Learn vocabulary about burnout', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'burnout', 'การหมดไฟ', NULL),
    (activity_id_var, 'contribution', 'การมีส่วนร่วม', NULL),
    (activity_id_var, 'recognition', 'การยอมรับ', NULL),
    (activity_id_var, 'affect', 'ผลกระทบ', NULL),
    (activity_id_var, 'recovery', 'การฟื้นฟู', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_matching_drag', 3, 'Match Burnout Words', 'Match English words with Thai meanings', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'burnout', 'การหมดไฟ', NULL),
    (activity_id_var, 'contribution', 'การมีส่วนร่วม', NULL),
    (activity_id_var, 'recognition', 'การยอมรับ', NULL),
    (activity_id_var, 'affect', 'ผลกระทบ', NULL),
    (activity_id_var, 'recovery', 'การฟื้นฟู', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 4, 'Complete the Sentences 1', 'Fill with the correct word', '{"text": "___ contributes to ___. Recognizing ___ helps prevention.", "blanks": [{"id": "blank1", "text": "Pressure", "options": ["Pressure", "Burnout", "Contribution", "Recognition"], "correctAnswer": "Pressure"}, {"id": "blank2", "text": "burnout", "options": ["burnout", "contribution", "recognition", "affect"], "correctAnswer": "burnout"}, {"id": "blank3", "text": "signs", "options": ["signs", "burnout", "contribution", "recognition"], "correctAnswer": "signs"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 5, 'Complete the Sentences 2', 'Fill with the correct word', '{"text": "Burnout ___ learning. ___ from burnout requires time.", "blanks": [{"id": "blank1", "text": "affects", "options": ["affects", "burnout", "contribution", "recognition"], "correctAnswer": "affects"}, {"id": "blank2", "text": "Recovery", "options": ["Recovery", "Burnout", "Contribution", "Recognition"], "correctAnswer": "Recovery"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_explanation', 6, 'Articles: Abstract Reference', 'Learn articles with abstract nouns', '{"rules": "Articles with abstract nouns:\n- Use \"the\" when referring to a specific abstract concept: \"the burnout culture\"\n- Omit article for general abstract concepts: \"burnout affects students\"\n- Use \"a/an\" when classifying: \"a burnout problem\"\n\nStylistic use:\n- \"The\" can emphasize importance: \"the ability to recognize burnout\"\n- Zero article for broad concepts: \"burnout creates challenges\"\n\nUse for:\n- General statements: \"Burnout affects education.\"\n- Specific reference: \"The burnout we see is concerning.\"\n- Classification: \"A burnout culture exists.\"", "examples": ["The burnout culture in education is concerning.", "Burnout affects student learning significantly.", "A burnout problem requires attention.", "The ability to recognize burnout is important.", "Burnout creates serious challenges in education."]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 7, 'Build Sentences 1', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'The burnout culture in education is concerning.', 'The burnout culture in education is concerning.', '["The", "burnout", "culture", "in", "education", "is", "concerning."]'::jsonb),
    (activity_id_var, 'Burnout affects student learning significantly.', 'Burnout affects student learning significantly.', '["Burnout", "affects", "student", "learning", "significantly."]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 8, 'Build Sentences 2', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'A burnout problem requires attention.', 'A burnout problem requires attention.', '["A", "burnout", "problem", "requires", "attention."]'::jsonb),
    (activity_id_var, 'The ability to recognize burnout is important.', 'The ability to recognize burnout is important.', '["The", "ability", "to", "recognize", "burnout", "is", "important."]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'speaking_practice', 9, 'Discuss Burnout', 'Practice speaking about burnout', '{"prompts": ["What contributes to burnout?", "How do you recognize burnout?", "What creates burnout in education systems?", "How does burnout affect learning?", "What helps prevent or recover from burnout?"]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (
      lesson_id,
      activity_type,
      activity_order,
      title,
      description,
      content
    ) VALUES (
      'C1-L72',
      'speaking_improvement',
      10,
      'Speaking Improvement',
      'Read the improved version of your speech',
      '{"type": "speaking_improvement", "similarityThreshold": 70}'::jsonb
    );
END $$;



-- =========================================
-- C1 Lesson 73
-- =========================================

-- =========================================
-- Pre-fill Database with Sample Lesson Data
-- C1-L73: Emotional Intelligence
-- =========================================
DELETE FROM lesson_activity_results WHERE lesson_id = 'C1-L73';
DELETE FROM user_progress WHERE lesson_id = 'C1-L73';
DELETE FROM lesson_history WHERE lesson_id = 'C1-L73';
DELETE FROM grammar_sentences WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'C1-L73');
DELETE FROM vocabulary_items WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'C1-L73');
DELETE FROM lesson_activities WHERE lesson_id = 'C1-L73';
DELETE FROM lessons WHERE id = 'C1-L73';

INSERT INTO lessons (id, level, lesson_number, topic) VALUES
('C1-L73', 'C1', 73, 'Emotional Intelligence')
ON CONFLICT (id) DO UPDATE SET topic = EXCLUDED.topic;

DO $$
DECLARE
    lesson_id_var TEXT := 'C1-L73';
    activity_id_var UUID;
BEGIN
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'warm_up_speaking', 1, 'Emotional Intelligence', 'Discuss emotional intelligence', '{"prompt": "What is it that you notice first about other people''s emotions?"}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_intro', 2, 'Emotional Intelligence Vocabulary', 'Learn vocabulary about emotional intelligence', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'intelligence', 'สติปัญญา', NULL),
    (activity_id_var, 'emotion', 'อารมณ์', NULL),
    (activity_id_var, 'response', 'การตอบสนอง', NULL),
    (activity_id_var, 'empathy', 'ความเห็นอกเห็นใจ', NULL),
    (activity_id_var, 'management', 'การจัดการ', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_matching_drag', 3, 'Match Emotional Intelligence Words', 'Match English words with Thai meanings', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'intelligence', 'สติปัญญา', NULL),
    (activity_id_var, 'emotion', 'อารมณ์', NULL),
    (activity_id_var, 'response', 'การตอบสนอง', NULL),
    (activity_id_var, 'empathy', 'ความเห็นอกเห็นใจ', NULL),
    (activity_id_var, 'management', 'การจัดการ', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 4, 'Complete the Sentences 1', 'Fill with the correct word', '{"text": "Emotional ___ involves understanding ___. Effective ___ requires ___.", "blanks": [{"id": "blank1", "text": "intelligence", "options": ["intelligence", "emotion", "response", "empathy"], "correctAnswer": "intelligence"}, {"id": "blank2", "text": "emotions", "options": ["emotions", "intelligence", "response", "empathy"], "correctAnswer": "emotions"}, {"id": "blank3", "text": "response", "options": ["response", "intelligence", "emotion", "empathy"], "correctAnswer": "response"}, {"id": "blank4", "text": "awareness", "options": ["awareness", "intelligence", "emotion", "empathy"], "correctAnswer": "awareness"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 5, 'Complete the Sentences 2', 'Fill with the correct word', '{"text": "___ plays a key role. ___ of emotions is essential.", "blanks": [{"id": "blank1", "text": "Empathy", "options": ["Empathy", "Intelligence", "Emotion", "Response"], "correctAnswer": "Empathy"}, {"id": "blank2", "text": "Management", "options": ["Management", "Intelligence", "Emotion", "Empathy"], "correctAnswer": "Management"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_explanation', 6, 'Cleft Sentences and Emphatic Structures', 'Learn cleft sentences for emphasis', '{"rules": "Cleft sentences emphasize specific elements:\n- It-cleft: \"It is emotional awareness that matters most.\"\n- What-cleft: \"What you notice first is important.\"\n- Wh-cleft: \"What matters is how you respond.\"\n\nStructure:\n- It + be + emphasized element + that/who clause\n- What + verb + be + emphasized element\n\nUse for:\n- Emphasizing importance: \"It is emotional intelligence that helps relationships.\"\n- Highlighting focus: \"What you notice first is people''s emotions.\"\n- Clarifying meaning: \"What matters is how you respond.\"", "examples": ["It is emotional awareness that matters most.", "What you notice first is people''s emotions.", "What matters is how you respond emotionally.", "It is empathy that enables understanding.", "What you observe first shapes your response."]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 7, 'Build Sentences 1', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'It is emotional awareness that matters most.', 'It is emotional awareness that matters most.', '["It", "is", "emotional", "awareness", "that", "matters", "most."]'::jsonb),
    (activity_id_var, 'What you notice first is people''s emotions.', 'What you notice first is people''s emotions.', '["What", "you", "notice", "first", "is", "people''s", "emotions."]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 8, 'Build Sentences 2', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'What matters is how you respond emotionally.', 'What matters is how you respond emotionally.', '["What", "matters", "is", "how", "you", "respond", "emotionally."]'::jsonb),
    (activity_id_var, 'It is empathy that enables understanding.', 'It is empathy that enables understanding.', '["It", "is", "empathy", "that", "enables", "understanding."]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'speaking_practice', 9, 'Discuss Emotional Intelligence', 'Practice speaking about emotional intelligence', '{"prompts": ["What is it that you notice first in others?", "How do you respond emotionally?", "How can emotional intelligence be developed?", "What role does empathy play?", "How do you manage emotions effectively?"]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (
      lesson_id,
      activity_type,
      activity_order,
      title,
      description,
      content
    ) VALUES (
      'C1-L73',
      'speaking_improvement',
      10,
      'Speaking Improvement',
      'Read the improved version of your speech',
      '{"type": "speaking_improvement", "similarityThreshold": 70}'::jsonb
    );
END $$;



-- =========================================
-- C1 Lesson 74
-- =========================================

-- =========================================
-- Pre-fill Database with Sample Lesson Data
-- C1-L74: Identity Formation in Young Adulthood
-- =========================================
DELETE FROM lesson_activity_results WHERE lesson_id = 'C1-L74';
DELETE FROM user_progress WHERE lesson_id = 'C1-L74';
DELETE FROM lesson_history WHERE lesson_id = 'C1-L74';
DELETE FROM grammar_sentences WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'C1-L74');
DELETE FROM vocabulary_items WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'C1-L74');
DELETE FROM lesson_activities WHERE lesson_id = 'C1-L74';
DELETE FROM lessons WHERE id = 'C1-L74';

INSERT INTO lessons (id, level, lesson_number, topic) VALUES
('C1-L74', 'C1', 74, 'Identity Formation in Young Adulthood')
ON CONFLICT (id) DO UPDATE SET topic = EXCLUDED.topic;

DO $$
DECLARE
    lesson_id_var TEXT := 'C1-L74';
    activity_id_var UUID;
BEGIN
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'warm_up_speaking', 1, 'Identity Formation', 'Discuss identity formation', '{"prompt": "How is identity shaped by others'' expectations?"}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_intro', 2, 'Identity Vocabulary', 'Learn vocabulary about identity', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'identity', 'ตัวตน', NULL),
    (activity_id_var, 'formation', 'การก่อตัว', NULL),
    (activity_id_var, 'factor', 'ปัจจัย', NULL),
    (activity_id_var, 'development', 'การพัฒนา', NULL),
    (activity_id_var, 'change', 'การเปลี่ยนแปลง', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_matching_drag', 3, 'Match Identity Words', 'Match English words with Thai meanings', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'identity', 'ตัวตน', NULL),
    (activity_id_var, 'formation', 'การก่อตัว', NULL),
    (activity_id_var, 'factor', 'ปัจจัย', NULL),
    (activity_id_var, 'development', 'การพัฒนา', NULL),
    (activity_id_var, 'change', 'การเปลี่ยนแปลง', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 4, 'Complete the Sentences 1', 'Fill with the correct word', '{"text": "Identity ___ occurs in young adulthood. Various ___ influence ___.", "blanks": [{"id": "blank1", "text": "formation", "options": ["formation", "identity", "factor", "development"], "correctAnswer": "formation"}, {"id": "blank2", "text": "factors", "options": ["factors", "identity", "formation", "development"], "correctAnswer": "factors"}, {"id": "blank3", "text": "development", "options": ["development", "identity", "formation", "factor"], "correctAnswer": "development"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 5, 'Complete the Sentences 2', 'Fill with the correct word', '{"text": "Identity ___ over time. Others play a role in ___.", "blanks": [{"id": "blank1", "text": "changes", "options": ["changes", "identity", "formation", "development"], "correctAnswer": "changes"}, {"id": "blank2", "text": "formation", "options": ["formation", "identity", "change", "development"], "correctAnswer": "formation"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_explanation', 6, 'Advanced Passives', 'Learn advanced passive structures', '{"rules": "Advanced passive forms:\n- \"Identity is shaped by expectations.\" (general)\n- \"Identity must be developed carefully.\" (necessity)\n- \"Identity is being formed.\" (continuous)\n- \"Identity has been influenced.\" (perfect)\n- \"Identity will be defined.\" (future)\n\nUse when:\n- Focus is on action, not actor: \"Identity is shaped by others.\"\n- Actor is unknown/unimportant: \"Identity was influenced by many factors.\"\n- Formal/impersonal tone: \"It is required that identity be understood.\"", "examples": ["Identity is shaped by others'' views and expectations.", "Identity must be developed through self-reflection.", "Identity is being formed during young adulthood.", "Identity has been influenced by various factors.", "Identity will be defined through experiences."]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 7, 'Build Sentences 1', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'Identity is shaped by others'' views and expectations.', 'Identity is shaped by others'' views and expectations.', '["Identity", "is", "shaped", "by", "others''", "views", "and", "expectations."]'::jsonb),
    (activity_id_var, 'Identity must be developed through self-reflection.', 'Identity must be developed through self-reflection.', '["Identity", "must", "be", "developed", "through", "self-reflection."]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 8, 'Build Sentences 2', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'Identity is being formed during young adulthood.', 'Identity is being formed during young adulthood.', '["Identity", "is", "being", "formed", "during", "young", "adulthood."]'::jsonb),
    (activity_id_var, 'Identity has been influenced by various factors.', 'Identity has been influenced by various factors.', '["Identity", "has", "been", "influenced", "by", "various", "factors."]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'speaking_practice', 9, 'Discuss Identity Formation', 'Practice speaking about identity formation', '{"prompts": ["How is identity shaped by others'' views?", "What factors influence identity formation?", "How do you define yourself?", "What role do others play in identity development?", "How does identity change in young adulthood?"]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (
      lesson_id,
      activity_type,
      activity_order,
      title,
      description,
      content
    ) VALUES (
      'C1-L74',
      'speaking_improvement',
      10,
      'Speaking Improvement',
      'Read the improved version of your speech',
      '{"type": "speaking_improvement", "similarityThreshold": 70}'::jsonb
    );
END $$;



-- =========================================
-- C1 Lesson 75
-- =========================================

-- =========================================
-- Pre-fill Database with Sample Lesson Data
-- C1-L75: Coping with Uncertainty
-- =========================================
DELETE FROM lesson_activity_results WHERE lesson_id = 'C1-L75';
DELETE FROM user_progress WHERE lesson_id = 'C1-L75';
DELETE FROM lesson_history WHERE lesson_id = 'C1-L75';
DELETE FROM grammar_sentences WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'C1-L75');
DELETE FROM vocabulary_items WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'C1-L75');
DELETE FROM lesson_activities WHERE lesson_id = 'C1-L75';
DELETE FROM lessons WHERE id = 'C1-L75';

INSERT INTO lessons (id, level, lesson_number, topic) VALUES
('C1-L75', 'C1', 75, 'Coping with Uncertainty')
ON CONFLICT (id) DO UPDATE SET topic = EXCLUDED.topic;

DO $$
DECLARE
    lesson_id_var TEXT := 'C1-L75';
    activity_id_var UUID;
BEGIN
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'warm_up_speaking', 1, 'Coping with Uncertainty', 'Discuss coping with uncertainty', '{"prompt": "How do you decide whether a risk is worth taking?"}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_intro', 2, 'Uncertainty Vocabulary', 'Learn vocabulary about uncertainty', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'uncertainty', 'ความไม่แน่นอน', NULL),
    (activity_id_var, 'risk', 'ความเสี่ยง', NULL),
    (activity_id_var, 'judgment', 'การตัดสิน', NULL),
    (activity_id_var, 'outcome', 'ผลลัพธ์', NULL),
    (activity_id_var, 'strategy', 'กลยุทธ์', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_matching_drag', 3, 'Match Uncertainty Words', 'Match English words with Thai meanings', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'uncertainty', 'ความไม่แน่นอน', NULL),
    (activity_id_var, 'risk', 'ความเสี่ยง', NULL),
    (activity_id_var, 'judgment', 'การตัดสิน', NULL),
    (activity_id_var, 'outcome', 'ผลลัพธ์', NULL),
    (activity_id_var, 'strategy', 'กลยุทธ์', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 4, 'Complete the Sentences 1', 'Fill with the correct word', '{"text": "Coping with ___ requires ___. Judging ___ involves ___.", "blanks": [{"id": "blank1", "text": "uncertainty", "options": ["uncertainty", "risk", "judgment", "outcome"], "correctAnswer": "uncertainty"}, {"id": "blank2", "text": "strategies", "options": ["strategies", "uncertainty", "risk", "judgment"], "correctAnswer": "strategies"}, {"id": "blank3", "text": "risks", "options": ["risks", "uncertainty", "judgment", "outcome"], "correctAnswer": "risks"}, {"id": "blank4", "text": "judgment", "options": ["judgment", "uncertainty", "risk", "outcome"], "correctAnswer": "judgment"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 5, 'Complete the Sentences 2', 'Fill with the correct word', '{"text": "Unknown ___ create challenges. Effective ___ help manage ___.", "blanks": [{"id": "blank1", "text": "outcomes", "options": ["outcomes", "uncertainty", "risk", "judgment"], "correctAnswer": "outcomes"}, {"id": "blank2", "text": "strategies", "options": ["strategies", "uncertainty", "risk", "judgment"], "correctAnswer": "strategies"}, {"id": "blank3", "text": "uncertainty", "options": ["uncertainty", "risk", "judgment", "outcome"], "correctAnswer": "uncertainty"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_explanation', 6, 'Modals: Degrees of Certainty', 'Learn modals expressing degrees of certainty', '{"rules": "Modals for degrees of certainty:\n- \"must\" (high certainty): \"This risk must be worth it.\"\n- \"should\" (probable): \"This risk should be acceptable.\"\n- \"might/may\" (possible): \"This risk might be worth taking.\"\n- \"could\" (less certain): \"This risk could be too high.\"\n\nUse for:\n- Expressing confidence: \"I am certain this risk is worth it.\"\n- Showing uncertainty: \"I am not sure if this risk is acceptable.\"\n- Speculating: \"This risk might be worth taking.\"", "examples": ["This risk must be worth it given the potential benefits.", "I should be certain that the risk is acceptable.", "This risk might be worth taking despite uncertainty.", "I could be wrong about the risk assessment.", "You may be confident that the risk is manageable."]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 7, 'Build Sentences 1', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'This risk must be worth it given the potential benefits.', 'This risk must be worth it given the potential benefits.', '["This", "risk", "must", "be", "worth", "it", "given", "the", "potential", "benefits."]'::jsonb),
    (activity_id_var, 'I should be certain that the risk is acceptable.', 'I should be certain that the risk is acceptable.', '["I", "should", "be", "certain", "that", "the", "risk", "is", "acceptable."]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 8, 'Build Sentences 2', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'This risk might be worth taking despite uncertainty.', 'This risk might be worth taking despite uncertainty.', '["This", "risk", "might", "be", "worth", "taking", "despite", "uncertainty."]'::jsonb),
    (activity_id_var, 'You may be confident that the risk is manageable.', 'You may be confident that the risk is manageable.', '["You", "may", "be", "confident", "that", "the", "risk", "is", "manageable."]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'speaking_practice', 9, 'Discuss Coping with Uncertainty', 'Practice speaking about uncertainty', '{"prompts": ["How do you judge if a risk is worth it?", "How do you handle uncertainty?", "What helps you cope with unknown outcomes?", "How do you make decisions with limited information?", "What strategies help with uncertainty?"]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (
      lesson_id,
      activity_type,
      activity_order,
      title,
      description,
      content
    ) VALUES (
      'C1-L75',
      'speaking_improvement',
      10,
      'Speaking Improvement',
      'Read the improved version of your speech',
      '{"type": "speaking_improvement", "similarityThreshold": 70}'::jsonb
    );
END $$;



-- =========================================
-- C1 Lesson 76
-- =========================================

-- =========================================
-- Pre-fill Database with Sample Lesson Data
-- C1-L76: Perfectionism and Mental Health
-- =========================================
DELETE FROM lesson_activity_results WHERE lesson_id = 'C1-L76';
DELETE FROM user_progress WHERE lesson_id = 'C1-L76';
DELETE FROM lesson_history WHERE lesson_id = 'C1-L76';
DELETE FROM grammar_sentences WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'C1-L76');
DELETE FROM vocabulary_items WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'C1-L76');
DELETE FROM lesson_activities WHERE lesson_id = 'C1-L76';
DELETE FROM lessons WHERE id = 'C1-L76';

INSERT INTO lessons (id, level, lesson_number, topic) VALUES
('C1-L76', 'C1', 76, 'Perfectionism and Mental Health')
ON CONFLICT (id) DO UPDATE SET topic = EXCLUDED.topic;

DO $$
DECLARE
    lesson_id_var TEXT := 'C1-L76';
    activity_id_var UUID;
BEGIN
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'warm_up_speaking', 1, 'Perfectionism', 'Discuss perfectionism and mental health', '{"prompt": "If you had let go earlier, how would you feel now?"}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_intro', 2, 'Perfectionism Vocabulary', 'Learn vocabulary about perfectionism', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'perfectionism', 'การยึดติดกับความสมบูรณ์แบบ', NULL),
    (activity_id_var, 'health', 'สุขภาพ', NULL),
    (activity_id_var, 'behavior', 'พฤติกรรม', NULL),
    (activity_id_var, 'standard', 'มาตรฐาน', NULL),
    (activity_id_var, 'balance', 'ความสมดุล', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_matching_drag', 3, 'Match Perfectionism Words', 'Match English words with Thai meanings', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'perfectionism', 'การยึดติดกับความสมบูรณ์แบบ', NULL),
    (activity_id_var, 'health', 'สุขภาพ', NULL),
    (activity_id_var, 'behavior', 'พฤติกรรม', NULL),
    (activity_id_var, 'standard', 'มาตรฐาน', NULL),
    (activity_id_var, 'balance', 'ความสมดุล', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 4, 'Complete the Sentences 1', 'Fill with the correct word', '{"text": "___ affects mental ___. Perfectionist ___ creates stress.", "blanks": [{"id": "blank1", "text": "Perfectionism", "options": ["Perfectionism", "Health", "Behavior", "Standard"], "correctAnswer": "Perfectionism"}, {"id": "blank2", "text": "health", "options": ["health", "perfectionism", "behavior", "standard"], "correctAnswer": "health"}, {"id": "blank3", "text": "behavior", "options": ["behavior", "perfectionism", "health", "standard"], "correctAnswer": "behavior"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 5, 'Complete the Sentences 2', 'Fill with the correct word', '{"text": "High ___ drive perfectionism. Finding ___ is important.", "blanks": [{"id": "blank1", "text": "standards", "options": ["standards", "perfectionism", "health", "behavior"], "correctAnswer": "standards"}, {"id": "blank2", "text": "balance", "options": ["balance", "perfectionism", "health", "standard"], "correctAnswer": "balance"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_explanation', 6, 'Mixed Conditionals', 'Learn mixed conditional structures', '{"rules": "Mixed conditionals combine different time references:\n- Mixed 2/3: \"If I had let go earlier (past), I would feel better now (present).\"\n- Mixed 3/2: \"If I had released perfectionism (past), I would be happier now (present).\"\n\nStructures:\n- If + past perfect, would + base form (past condition, present result)\n- If + past simple, would have + past participle (present condition, past result)\n\nUse for:\n- Hypothetical past affecting present: \"If I had let go earlier, I would feel better now.\"\n- Unreal past affecting present: \"If I had released perfectionism, I would be healthier now.\"", "examples": ["If I had let go earlier, I would feel better now.", "If I had released perfectionism, I would be happier now.", "If I had balanced standards earlier, I would feel less stressed now.", "If I had let go of perfectionism, I would have more well-being now.", "If I had changed my approach, I would feel different now."]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 7, 'Build Sentences 1', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'If I had let go earlier, I would feel better now.', 'If I had let go earlier, I would feel better now.', '["If", "I", "had", "let", "go", "earlier,", "I", "would", "feel", "better", "now."]'::jsonb),
    (activity_id_var, 'If I had released perfectionism, I would be happier now.', 'If I had released perfectionism, I would be happier now.', '["If", "I", "had", "released", "perfectionism,", "I", "would", "be", "happier", "now."]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 8, 'Build Sentences 2', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'If I had balanced standards earlier, I would feel less stressed now.', 'If I had balanced standards earlier, I would feel less stressed now.', '["If", "I", "had", "balanced", "standards", "earlier,", "I", "would", "feel", "less", "stressed", "now."]'::jsonb),
    (activity_id_var, 'If I had let go of perfectionism, I would have more well-being now.', 'If I had let go of perfectionism, I would have more well-being now.', '["If", "I", "had", "let", "go", "of", "perfectionism,", "I", "would", "have", "more", "well-being", "now."]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'speaking_practice', 9, 'Discuss Perfectionism', 'Practice speaking about perfectionism', '{"prompts": ["If you had let go earlier, how would you feel now?", "How does perfectionism affect you?", "What drives perfectionist behavior?", "How do you balance high standards and well-being?", "What helps you let go of perfectionism?"]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (
      lesson_id,
      activity_type,
      activity_order,
      title,
      description,
      content
    ) VALUES (
      'C1-L76',
      'speaking_improvement',
      10,
      'Speaking Improvement',
      'Read the improved version of your speech',
      '{"type": "speaking_improvement", "similarityThreshold": 70}'::jsonb
    );
END $$;



-- =========================================
-- C1 Lesson 77
-- =========================================

-- =========================================
-- Pre-fill Database with Sample Lesson Data
-- C1-L77: Motivation vs Discipline
-- =========================================
DELETE FROM lesson_activity_results WHERE lesson_id = 'C1-L77';
DELETE FROM user_progress WHERE lesson_id = 'C1-L77';
DELETE FROM lesson_history WHERE lesson_id = 'C1-L77';
DELETE FROM grammar_sentences WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'C1-L77');
DELETE FROM vocabulary_items WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'C1-L77');
DELETE FROM lesson_activities WHERE lesson_id = 'C1-L77';
DELETE FROM lessons WHERE id = 'C1-L77';

INSERT INTO lessons (id, level, lesson_number, topic) VALUES
('C1-L77', 'C1', 77, 'Motivation vs Discipline')
ON CONFLICT (id) DO UPDATE SET topic = EXCLUDED.topic;

DO $$
DECLARE
    lesson_id_var TEXT := 'C1-L77';
    activity_id_var UUID;
BEGIN
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'warm_up_speaking', 1, 'Motivation vs Discipline', 'Discuss motivation vs discipline', '{"prompt": "When does motivation disappear, and what keeps you going?"}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_intro', 2, 'Motivation Vocabulary', 'Learn vocabulary about motivation', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'motivation', 'แรงจูงใจ', NULL),
    (activity_id_var, 'discipline', 'วินัย', NULL),
    (activity_id_var, 'maintenance', 'การบำรุงรักษา', NULL),
    (activity_id_var, 'difference', 'ความแตกต่าง', NULL),
    (activity_id_var, 'commitment', 'ความมุ่งมั่น', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_matching_drag', 3, 'Match Motivation Words', 'Match English words with Thai meanings', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'motivation', 'แรงจูงใจ', NULL),
    (activity_id_var, 'discipline', 'วินัย', NULL),
    (activity_id_var, 'maintenance', 'การบำรุงรักษา', NULL),
    (activity_id_var, 'difference', 'ความแตกต่าง', NULL),
    (activity_id_var, 'commitment', 'ความมุ่งมั่น', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 4, 'Complete the Sentences 1', 'Fill with the correct word', '{"text": "___ can vanish. ___ keeps you moving. Maintaining ___ requires ___.", "blanks": [{"id": "blank1", "text": "Motivation", "options": ["Motivation", "Discipline", "Maintenance", "Difference"], "correctAnswer": "Motivation"}, {"id": "blank2", "text": "Discipline", "options": ["Discipline", "Motivation", "Maintenance", "Difference"], "correctAnswer": "Discipline"}, {"id": "blank3", "text": "discipline", "options": ["discipline", "motivation", "maintenance", "difference"], "correctAnswer": "discipline"}, {"id": "blank4", "text": "commitment", "options": ["commitment", "motivation", "discipline", "difference"], "correctAnswer": "commitment"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 5, 'Complete the Sentences 2', 'Fill with the correct word', '{"text": "The ___ between ___ and ___ matters. ___ without motivation requires ___.", "blanks": [{"id": "blank1", "text": "difference", "options": ["difference", "motivation", "discipline", "maintenance"], "correctAnswer": "difference"}, {"id": "blank2", "text": "motivation", "options": ["motivation", "discipline", "difference", "maintenance"], "correctAnswer": "motivation"}, {"id": "blank3", "text": "discipline", "options": ["discipline", "motivation", "difference", "maintenance"], "correctAnswer": "discipline"}, {"id": "blank4", "text": "Staying", "options": ["Staying", "Motivation", "Discipline", "Difference"], "correctAnswer": "Staying"}, {"id": "blank5", "text": "commitment", "options": ["commitment", "motivation", "discipline", "difference"], "correctAnswer": "commitment"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_explanation', 6, 'Inversion: Hardly/Scarcely', 'Learn inversion with hardly and scarcely', '{"rules": "Inversion with hardly/scarcely:\n- \"Hardly does motivation last.\" (formal emphasis)\n- \"Scarcely had motivation vanished when discipline took over.\" (past emphasis)\n- \"Hardly ever is motivation enough.\" (emphasis on rarity)\n\nStructure:\n- Hardly/Scarcely + auxiliary + subject + verb\n- Used for emphasis and formal tone\n\nUse for:\n- Emphasizing rarity: \"Hardly does motivation sustain long-term effort.\"\n- Formal statements: \"Scarcely had motivation disappeared when discipline was needed.\"\n- Highlighting infrequency: \"Hardly ever is motivation sufficient alone.\"", "examples": ["Hardly does motivation last without discipline.", "Scarcely had motivation vanished when discipline took over.", "Hardly ever is motivation enough for long-term goals.", "Scarcely do people succeed on motivation alone.", "Hardly had motivation disappeared when commitment was required."]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 7, 'Build Sentences 1', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'Hardly does motivation last without discipline.', 'Hardly does motivation last without discipline.', '["Hardly", "does", "motivation", "last", "without", "discipline."]'::jsonb),
    (activity_id_var, 'Scarcely had motivation vanished when discipline took over.', 'Scarcely had motivation vanished when discipline took over.', '["Scarcely", "had", "motivation", "vanished", "when", "discipline", "took", "over."]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 8, 'Build Sentences 2', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'Hardly ever is motivation enough for long-term goals.', 'Hardly ever is motivation enough for long-term goals.', '["Hardly", "ever", "is", "motivation", "enough", "for", "long-term", "goals."]'::jsonb),
    (activity_id_var, 'Scarcely do people succeed on motivation alone.', 'Scarcely do people succeed on motivation alone.', '["Scarcely", "do", "people", "succeed", "on", "motivation", "alone."]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'speaking_practice', 9, 'Discuss Motivation vs Discipline', 'Practice speaking about motivation and discipline', '{"prompts": ["When does motivation vanish?", "What keeps you moving forward?", "How do you maintain discipline?", "What is the difference between motivation and discipline?", "How do you stay committed without motivation?"]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (
      lesson_id,
      activity_type,
      activity_order,
      title,
      description,
      content
    ) VALUES (
      'C1-L77',
      'speaking_improvement',
      10,
      'Speaking Improvement',
      'Read the improved version of your speech',
      '{"type": "speaking_improvement", "similarityThreshold": 70}'::jsonb
    );
END $$;



-- =========================================
-- C1 Lesson 78
-- =========================================

-- =========================================
-- Pre-fill Database with Sample Lesson Data
-- C1-L78: Meaning and Purpose
-- =========================================
DELETE FROM lesson_activity_results WHERE lesson_id = 'C1-L78';
DELETE FROM user_progress WHERE lesson_id = 'C1-L78';
DELETE FROM lesson_history WHERE lesson_id = 'C1-L78';
DELETE FROM grammar_sentences WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'C1-L78');
DELETE FROM vocabulary_items WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'C1-L78');
DELETE FROM lesson_activities WHERE lesson_id = 'C1-L78';
DELETE FROM lessons WHERE id = 'C1-L78';

INSERT INTO lessons (id, level, lesson_number, topic) VALUES
('C1-L78', 'C1', 78, 'Meaning and Purpose')
ON CONFLICT (id) DO UPDATE SET topic = EXCLUDED.topic;

DO $$
DECLARE
    lesson_id_var TEXT := 'C1-L78';
    activity_id_var UUID;
BEGIN
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'warm_up_speaking', 1, 'Meaning and Purpose', 'Discuss meaning and purpose', '{"prompt": "What gives your life a sense of purpose right now?"}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_intro', 2, 'Purpose Vocabulary', 'Learn vocabulary about purpose', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'purpose', 'จุดประสงค์', NULL),
    (activity_id_var, 'meaning', 'ความหมาย', NULL),
    (activity_id_var, 'change', 'การเปลี่ยนแปลง', NULL),
    (activity_id_var, 'direction', 'ทิศทาง', NULL),
    (activity_id_var, 'evolution', 'วิวัฒนาการ', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_matching_drag', 3, 'Match Purpose Words', 'Match English words with Thai meanings', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'purpose', 'จุดประสงค์', NULL),
    (activity_id_var, 'meaning', 'ความหมาย', NULL),
    (activity_id_var, 'change', 'การเปลี่ยนแปลง', NULL),
    (activity_id_var, 'direction', 'ทิศทาง', NULL),
    (activity_id_var, 'evolution', 'วิวัฒนาการ', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 4, 'Complete the Sentences 1', 'Fill with the correct word', '{"text": "Finding ___ gives ___. ___ of purpose changes over time.", "blanks": [{"id": "blank1", "text": "purpose", "options": ["purpose", "meaning", "change", "direction"], "correctAnswer": "purpose"}, {"id": "blank2", "text": "meaning", "options": ["meaning", "purpose", "change", "direction"], "correctAnswer": "meaning"}, {"id": "blank3", "text": "Sense", "options": ["Sense", "Purpose", "Meaning", "Change"], "correctAnswer": "Sense"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 5, 'Complete the Sentences 2', 'Fill with the correct word', '{"text": "Purpose provides ___. ___ of purpose shows ___.", "blanks": [{"id": "blank1", "text": "direction", "options": ["direction", "purpose", "meaning", "change"], "correctAnswer": "direction"}, {"id": "blank2", "text": "Evolution", "options": ["Evolution", "Purpose", "Meaning", "Change"], "correctAnswer": "Evolution"}, {"id": "blank3", "text": "growth", "options": ["growth", "purpose", "meaning", "change"], "correctAnswer": "growth"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_explanation', 6, 'Nominal Clauses', 'Learn about nominal clauses', '{"rules": "Nominal clauses function as nouns:\n- Subject: \"What you call purpose shapes your life.\"\n- Object: \"I believe that purpose matters.\"\n- Complement: \"The question is how purpose has shifted.\"\n\nTypes:\n- That-clauses: \"I think that purpose is important.\"\n- Wh-clauses: \"What you call purpose defines direction.\"\n- Whether/if: \"The issue is whether purpose evolves.\"\n\nUse for:\n- Expressing beliefs: \"What I call purpose is what gives meaning.\"\n- Asking questions: \"What do you call purpose?\"\n- Making statements: \"That purpose matters is clear.\"", "examples": ["What you call purpose shapes your life direction.", "I believe that purpose gives meaning to life.", "The question is how purpose has shifted over time.", "Whether purpose evolves remains a personal question.", "That purpose matters is widely accepted."]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 7, 'Build Sentences 1', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'What you call purpose shapes your life direction.', 'What you call purpose shapes your life direction.', '["What", "you", "call", "purpose", "shapes", "your", "life", "direction."]'::jsonb),
    (activity_id_var, 'I believe that purpose gives meaning to life.', 'I believe that purpose gives meaning to life.', '["I", "believe", "that", "purpose", "gives", "meaning", "to", "life."]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 8, 'Build Sentences 2', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'The question is how purpose has shifted over time.', 'The question is how purpose has shifted over time.', '["The", "question", "is", "how", "purpose", "has", "shifted", "over", "time."]'::jsonb),
    (activity_id_var, 'Whether purpose evolves remains a personal question.', 'Whether purpose evolves remains a personal question.', '["Whether", "purpose", "evolves", "remains", "a", "personal", "question."]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'speaking_practice', 9, 'Discuss Meaning and Purpose', 'Practice speaking about meaning and purpose', '{"prompts": ["What do you call \"purpose\" in your life?", "How has your sense of purpose changed?", "How do you find meaning in daily life?", "What gives your life direction?", "How does purpose evolve over time?"]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (
      lesson_id,
      activity_type,
      activity_order,
      title,
      description,
      content
    ) VALUES (
      'C1-L78',
      'speaking_improvement',
      10,
      'Speaking Improvement',
      'Read the improved version of your speech',
      '{"type": "speaking_improvement", "similarityThreshold": 70}'::jsonb
    );
END $$;



-- =========================================
-- C1 Lesson 79
-- =========================================

-- =========================================
-- Pre-fill Database with Sample Lesson Data
-- C1-L79: Resilience in Challenging Environments
-- =========================================
DELETE FROM lesson_activity_results WHERE lesson_id = 'C1-L79';
DELETE FROM user_progress WHERE lesson_id = 'C1-L79';
DELETE FROM lesson_history WHERE lesson_id = 'C1-L79';
DELETE FROM grammar_sentences WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'C1-L79');
DELETE FROM vocabulary_items WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'C1-L79');
DELETE FROM lesson_activities WHERE lesson_id = 'C1-L79';
DELETE FROM lessons WHERE id = 'C1-L79';

INSERT INTO lessons (id, level, lesson_number, topic) VALUES
('C1-L79', 'C1', 79, 'Resilience in Challenging Environments')
ON CONFLICT (id) DO UPDATE SET topic = EXCLUDED.topic;

DO $$
DECLARE
    lesson_id_var TEXT := 'C1-L79';
    activity_id_var UUID;
BEGIN
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'warm_up_speaking', 1, 'Resilience', 'Discuss resilience', '{"prompt": "What has helped you keep going during difficult periods?"}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_intro', 2, 'Resilience Vocabulary', 'Learn vocabulary about resilience', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'resilience', 'ความยืดหยุ่น', NULL),
    (activity_id_var, 'habit', 'นิสัย', NULL),
    (activity_id_var, 'support', 'การสนับสนุน', NULL),
    (activity_id_var, 'recovery', 'การฟื้นฟู', NULL),
    (activity_id_var, 'strength', 'ความแข็งแกร่ง', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_matching_drag', 3, 'Match Resilience Words', 'Match English words with Thai meanings', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'resilience', 'ความยืดหยุ่น', NULL),
    (activity_id_var, 'habit', 'นิสัย', NULL),
    (activity_id_var, 'support', 'การสนับสนุน', NULL),
    (activity_id_var, 'recovery', 'การฟื้นฟู', NULL),
    (activity_id_var, 'strength', 'ความแข็งแกร่ง', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 4, 'Complete the Sentences 1', 'Fill with the correct word', '{"text": "Building ___ requires ___. Supportive ___ anchor ___.", "blanks": [{"id": "blank1", "text": "resilience", "options": ["resilience", "habit", "support", "recovery"], "correctAnswer": "resilience"}, {"id": "blank2", "text": "practice", "options": ["practice", "resilience", "habit", "support"], "correctAnswer": "practice"}, {"id": "blank3", "text": "habits", "options": ["habits", "resilience", "support", "recovery"], "correctAnswer": "habits"}, {"id": "blank4", "text": "resilience", "options": ["resilience", "habit", "support", "recovery"], "correctAnswer": "resilience"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 5, 'Complete the Sentences 2', 'Fill with the correct word', '{"text": "___ from setbacks requires ___. Maintaining ___ during challenges shows ___.", "blanks": [{"id": "blank1", "text": "Recovery", "options": ["Recovery", "Resilience", "Habit", "Support"], "correctAnswer": "Recovery"}, {"id": "blank2", "text": "resilience", "options": ["resilience", "habit", "support", "recovery"], "correctAnswer": "resilience"}, {"id": "blank3", "text": "strength", "options": ["strength", "resilience", "habit", "support"], "correctAnswer": "strength"}, {"id": "blank4", "text": "resilience", "options": ["resilience", "habit", "support", "strength"], "correctAnswer": "resilience"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_explanation', 6, 'Participle Clauses', 'Learn participle clauses', '{"rules": "Participle clauses:\n- Present participle (-ing): \"Keeping going, people build resilience.\"\n- Past participle (-ed): \"Supported by habits, resilience grows.\"\n- Perfect participle (having + past participle): \"Having kept going, people develop strength.\"\n\nUse for:\n- Showing simultaneous actions: \"Keeping going, you build resilience.\"\n- Showing cause: \"Supported by habits, resilience develops.\"\n- Showing time sequence: \"Having kept going, people maintain strength.\"", "examples": ["Keeping going during challenges, people build resilience.", "Supported by healthy habits, resilience grows.", "Having kept going through difficulties, people develop strength.", "Maintaining habits, people anchor their resilience.", "Facing challenges, people strengthen their resilience."]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 7, 'Build Sentences 1', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'Keeping going during challenges, people build resilience.', 'Keeping going during challenges, people build resilience.', '["Keeping", "going", "during", "challenges,", "people", "build", "resilience."]'::jsonb),
    (activity_id_var, 'Supported by healthy habits, resilience grows.', 'Supported by healthy habits, resilience grows.', '["Supported", "by", "healthy", "habits,", "resilience", "grows."]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 8, 'Build Sentences 2', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'Having kept going through difficulties, people develop strength.', 'Having kept going through difficulties, people develop strength.', '["Having", "kept", "going", "through", "difficulties,", "people", "develop", "strength."]'::jsonb),
    (activity_id_var, 'Maintaining habits, people anchor their resilience.', 'Maintaining habits, people anchor their resilience.', '["Maintaining", "habits,", "people", "anchor", "their", "resilience."]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'speaking_practice', 9, 'Discuss Resilience', 'Practice speaking about resilience', '{"prompts": ["How have you kept going?", "What habits support your resilience?", "How do you build resilience?", "What helps you recover from setbacks?", "How do you stay strong during challenges?"]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (
      lesson_id,
      activity_type,
      activity_order,
      title,
      description,
      content
    ) VALUES (
      'C1-L79',
      'speaking_improvement',
      10,
      'Speaking Improvement',
      'Read the improved version of your speech',
      '{"type": "speaking_improvement", "similarityThreshold": 70}'::jsonb
    );
END $$;



-- =========================================
-- C1 Lesson 80
-- =========================================

-- =========================================
-- Pre-fill Database with Sample Lesson Data
-- C1-L80: Self-reflection as a Skill
-- =========================================
DELETE FROM lesson_activity_results WHERE lesson_id = 'C1-L80';
DELETE FROM user_progress WHERE lesson_id = 'C1-L80';
DELETE FROM lesson_history WHERE lesson_id = 'C1-L80';
DELETE FROM grammar_sentences WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'C1-L80');
DELETE FROM vocabulary_items WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'C1-L80');
DELETE FROM lesson_activities WHERE lesson_id = 'C1-L80';
DELETE FROM lessons WHERE id = 'C1-L80';

INSERT INTO lessons (id, level, lesson_number, topic) VALUES
('C1-L80', 'C1', 80, 'Self-reflection as a Skill')
ON CONFLICT (id) DO UPDATE SET topic = EXCLUDED.topic;

DO $$
DECLARE
    lesson_id_var TEXT := 'C1-L80';
    activity_id_var UUID;
BEGIN
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'warm_up_speaking', 1, 'Self-reflection', 'Discuss self-reflection', '{"prompt": "How long have you practiced deliberate self-reflection?"}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_intro', 2, 'Self-reflection Vocabulary', 'Learn vocabulary about self-reflection', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'reflection', 'การสะท้อน', NULL),
    (activity_id_var, 'practice', 'การปฏิบัติ', NULL),
    (activity_id_var, 'change', 'การเปลี่ยนแปลง', NULL),
    (activity_id_var, 'insight', 'ความเข้าใจ', NULL),
    (activity_id_var, 'improvement', 'การปรับปรุง', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_matching_drag', 3, 'Match Self-reflection Words', 'Match English words with Thai meanings', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'reflection', 'การสะท้อน', NULL),
    (activity_id_var, 'practice', 'การปฏิบัติ', NULL),
    (activity_id_var, 'change', 'การเปลี่ยนแปลง', NULL),
    (activity_id_var, 'insight', 'ความเข้าใจ', NULL),
    (activity_id_var, 'improvement', 'การปรับปรุง', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 4, 'Complete the Sentences 1', 'Fill with the correct word', '{"text": "Self-___ requires ___. Deliberate ___ leads to ___.", "blanks": [{"id": "blank1", "text": "reflection", "options": ["reflection", "practice", "change", "insight"], "correctAnswer": "reflection"}, {"id": "blank2", "text": "practice", "options": ["practice", "reflection", "change", "insight"], "correctAnswer": "practice"}, {"id": "blank3", "text": "practice", "options": ["practice", "reflection", "change", "insight"], "correctAnswer": "practice"}, {"id": "blank4", "text": "insights", "options": ["insights", "reflection", "practice", "change"], "correctAnswer": "insights"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 5, 'Complete the Sentences 2', 'Fill with the correct word', '{"text": "___ from reflection create ___. ___ improves life.", "blanks": [{"id": "blank1", "text": "Insights", "options": ["Insights", "Reflection", "Practice", "Change"], "correctAnswer": "Insights"}, {"id": "blank2", "text": "change", "options": ["change", "reflection", "practice", "insight"], "correctAnswer": "change"}, {"id": "blank3", "text": "Reflection", "options": ["Reflection", "Practice", "Change", "Insight"], "correctAnswer": "Reflection"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_explanation', 6, 'Advanced Perfect Aspect', 'Learn advanced perfect forms', '{"rules": "Advanced perfect aspect:\n- Present perfect: \"I have reflected for years.\"\n- Past perfect: \"I had practiced reflection before seeing changes.\"\n- Future perfect: \"I will have reflected for a decade by then.\"\n- Perfect continuous: \"I have been reflecting deliberately for months.\"\n\nUse for:\n- Completed actions with present relevance: \"I have reflected deliberately for a long time.\"\n- Past before past: \"I had practiced reflection before noticing changes.\"\n- Future completion: \"I will have reflected for years by next year.\"", "examples": ["I have reflected deliberately for a long time.", "I had practiced reflection before noticing changes.", "I will have reflected for years by next year.", "I have been reflecting deliberately for months.", "Having reflected regularly, I notice improvements."]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 7, 'Build Sentences 1', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'I have reflected deliberately for a long time.', 'I have reflected deliberately for a long time.', '["I", "have", "reflected", "deliberately", "for", "a", "long", "time."]'::jsonb),
    (activity_id_var, 'I had practiced reflection before noticing changes.', 'I had practiced reflection before noticing changes.', '["I", "had", "practiced", "reflection", "before", "noticing", "changes."]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 8, 'Build Sentences 2', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'I have been reflecting deliberately for months.', 'I have been reflecting deliberately for months.', '["I", "have", "been", "reflecting", "deliberately", "for", "months."]'::jsonb),
    (activity_id_var, 'Having reflected regularly, I notice improvements.', 'Having reflected regularly, I notice improvements.', '["Having", "reflected", "regularly,", "I", "notice", "improvements."]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'speaking_practice', 9, 'Discuss Self-reflection', 'Practice speaking about self-reflection', '{"prompts": ["How long have you reflected deliberately?", "What changes have you noticed?", "How do you practice self-reflection?", "What insights come from reflection?", "How does reflection improve your life?"]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (
      lesson_id,
      activity_type,
      activity_order,
      title,
      description,
      content
    ) VALUES (
      'C1-L80',
      'speaking_improvement',
      10,
      'Speaking Improvement',
      'Read the improved version of your speech',
      '{"type": "speaking_improvement", "similarityThreshold": 70}'::jsonb
    );
END $$;



-- =========================================
-- C1 Lesson 81
-- =========================================

-- =========================================
-- Pre-fill Database with Sample Lesson Data
-- C1-L81: Global Mobility of Students
-- =========================================
DELETE FROM lesson_activity_results WHERE lesson_id = 'C1-L81';
DELETE FROM user_progress WHERE lesson_id = 'C1-L81';
DELETE FROM lesson_history WHERE lesson_id = 'C1-L81';
DELETE FROM grammar_sentences WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'C1-L81');
DELETE FROM vocabulary_items WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'C1-L81');
DELETE FROM lesson_activities WHERE lesson_id = 'C1-L81';
DELETE FROM lessons WHERE id = 'C1-L81';

INSERT INTO lessons (id, level, lesson_number, topic) VALUES
('C1-L81', 'C1', 81, 'Global Mobility of Students')
ON CONFLICT (id) DO UPDATE SET topic = EXCLUDED.topic;

DO $$
DECLARE
    lesson_id_var TEXT := 'C1-L81';
    activity_id_var UUID;
BEGIN
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'warm_up_speaking', 1, 'Global Student Mobility', 'Discuss global mobility of students', '{"prompt": "How are students moved across borders for education?"}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_intro', 2, 'Student Mobility Vocabulary', 'Learn vocabulary about student mobility', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'mobility', 'การเคลื่อนย้าย', NULL),
    (activity_id_var, 'selection', 'การคัดเลือก', NULL),
    (activity_id_var, 'relocation', 'การย้ายถิ่น', NULL),
    (activity_id_var, 'benefit', 'ประโยชน์', NULL),
    (activity_id_var, 'movement', 'การเคลื่อนไหว', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_matching_drag', 3, 'Match Mobility Words', 'Match English words with Thai meanings', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'mobility', 'การเคลื่อนย้าย', NULL),
    (activity_id_var, 'selection', 'การคัดเลือก', NULL),
    (activity_id_var, 'relocation', 'การย้ายถิ่น', NULL),
    (activity_id_var, 'benefit', 'ประโยชน์', NULL),
    (activity_id_var, 'movement', 'การเคลื่อนไหว', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 4, 'Complete the Sentences 1', 'Fill with the correct word', '{"text": "Student ___ involves ___. ___ across borders requires ___.", "blanks": [{"id": "blank1", "text": "mobility", "options": ["mobility", "selection", "relocation", "benefit"], "correctAnswer": "mobility"}, {"id": "blank2", "text": "selection", "options": ["selection", "mobility", "relocation", "benefit"], "correctAnswer": "selection"}, {"id": "blank3", "text": "Movement", "options": ["Movement", "Mobility", "Selection", "Relocation"], "correctAnswer": "Movement"}, {"id": "blank4", "text": "planning", "options": ["planning", "mobility", "selection", "relocation"], "correctAnswer": "planning"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 5, 'Complete the Sentences 2', 'Fill with the correct word', '{"text": "___ from mobility varies. International ___ creates opportunities.", "blanks": [{"id": "blank1", "text": "Benefit", "options": ["Benefit", "Mobility", "Selection", "Relocation"], "correctAnswer": "Benefit"}, {"id": "blank2", "text": "education", "options": ["education", "mobility", "selection", "relocation"], "correctAnswer": "education"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_explanation', 6, 'Advanced Passives', 'Learn advanced passive structures', '{"rules": "Advanced passive forms:\n- \"Students are selected based on merit.\" (general)\n- \"Students must be moved carefully.\" (necessity)\n- \"Students are being relocated.\" (continuous)\n- \"Students have been selected.\" (perfect)\n- \"Students will be moved.\" (future)\n\nUse when:\n- Focus is on action, not actor: \"Students are selected for programs.\"\n- Actor is unknown/unimportant: \"Students were moved across borders.\"\n- Formal/impersonal tone: \"It is required that students be selected fairly.\"", "examples": ["Students are selected based on academic merit.", "Students must be moved across borders carefully.", "Students are being relocated for international programs.", "Students have been selected for exchange programs.", "Students will be moved to host countries."]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 7, 'Build Sentences 1', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'Students are selected based on academic merit.', 'Students are selected based on academic merit.', '["Students", "are", "selected", "based", "on", "academic", "merit."]'::jsonb),
    (activity_id_var, 'Students must be moved across borders carefully.', 'Students must be moved across borders carefully.', '["Students", "must", "be", "moved", "across", "borders", "carefully."]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 8, 'Build Sentences 2', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'Students are being relocated for international programs.', 'Students are being relocated for international programs.', '["Students", "are", "being", "relocated", "for", "international", "programs."]'::jsonb),
    (activity_id_var, 'Students have been selected for exchange programs.', 'Students have been selected for exchange programs.', '["Students", "have", "been", "selected", "for", "exchange", "programs."]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'speaking_practice', 9, 'Discuss Student Mobility', 'Practice speaking about student mobility', '{"prompts": ["How are students selected or relocated?", "Who benefits from student mobility?", "What drives global student movement?", "How does studying abroad work?", "Who gains from international education?"]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (
      lesson_id,
      activity_type,
      activity_order,
      title,
      description,
      content
    ) VALUES (
      'C1-L81',
      'speaking_improvement',
      10,
      'Speaking Improvement',
      'Read the improved version of your speech',
      '{"type": "speaking_improvement", "similarityThreshold": 70}'::jsonb
    );
END $$;



-- =========================================
-- C1 Lesson 82
-- =========================================

-- =========================================
-- Pre-fill Database with Sample Lesson Data
-- C1-L82: Brain Drain and Brain Circulation
-- =========================================
DELETE FROM lesson_activity_results WHERE lesson_id = 'C1-L82';
DELETE FROM user_progress WHERE lesson_id = 'C1-L82';
DELETE FROM lesson_history WHERE lesson_id = 'C1-L82';
DELETE FROM grammar_sentences WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'C1-L82');
DELETE FROM vocabulary_items WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'C1-L82');
DELETE FROM lesson_activities WHERE lesson_id = 'C1-L82';
DELETE FROM lessons WHERE id = 'C1-L82';

INSERT INTO lessons (id, level, lesson_number, topic) VALUES
('C1-L82', 'C1', 82, 'Brain Drain and Brain Circulation')
ON CONFLICT (id) DO UPDATE SET topic = EXCLUDED.topic;

DO $$
DECLARE
    lesson_id_var TEXT := 'C1-L82';
    activity_id_var UUID;
BEGIN
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'warm_up_speaking', 1, 'Brain Drain', 'Discuss brain drain and circulation', '{"prompt": "What is gained and lost when skilled people leave a country?"}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_intro', 2, 'Brain Drain Vocabulary', 'Learn vocabulary about brain drain', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'drain', 'การสูญเสีย', NULL),
    (activity_id_var, 'circulation', 'การหมุนเวียน', NULL),
    (activity_id_var, 'gain', 'การได้', NULL),
    (activity_id_var, 'loss', 'การสูญเสีย', NULL),
    (activity_id_var, 'policy', 'นโยบาย', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_matching_drag', 3, 'Match Brain Drain Words', 'Match English words with Thai meanings', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'drain', 'การสูญเสีย', NULL),
    (activity_id_var, 'circulation', 'การหมุนเวียน', NULL),
    (activity_id_var, 'gain', 'การได้', NULL),
    (activity_id_var, 'loss', 'การสูญเสีย', NULL),
    (activity_id_var, 'policy', 'นโยบาย', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 4, 'Complete the Sentences 1', 'Fill with the correct word', '{"text": "Brain ___ causes ___. Brain ___ creates ___.", "blanks": [{"id": "blank1", "text": "drain", "options": ["drain", "circulation", "gain", "loss"], "correctAnswer": "drain"}, {"id": "blank2", "text": "loss", "options": ["loss", "drain", "circulation", "gain"], "correctAnswer": "loss"}, {"id": "blank3", "text": "circulation", "options": ["circulation", "drain", "gain", "loss"], "correctAnswer": "circulation"}, {"id": "blank4", "text": "benefits", "options": ["benefits", "drain", "circulation", "loss"], "correctAnswer": "benefits"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 5, 'Complete the Sentences 2', 'Fill with the correct word', '{"text": "Balancing ___ and ___ requires ___. ___ address brain drain.", "blanks": [{"id": "blank1", "text": "gain", "options": ["gain", "drain", "circulation", "loss"], "correctAnswer": "gain"}, {"id": "blank2", "text": "loss", "options": ["loss", "drain", "circulation", "gain"], "correctAnswer": "loss"}, {"id": "blank3", "text": "balance", "options": ["balance", "drain", "circulation", "gain"], "correctAnswer": "balance"}, {"id": "blank4", "text": "Policies", "options": ["Policies", "Drain", "Circulation", "Gain"], "correctAnswer": "Policies"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_explanation', 6, 'Contrast Linking', 'Learn contrast linking devices', '{"rules": "Contrast linking devices:\n- \"While brain drain causes loss, brain circulation creates gain.\"\n- \"However, policies can address these issues.\"\n- \"On the other hand, circulation benefits both countries.\"\n- \"Whereas drain depletes talent, circulation shares it.\"\n\nUse for:\n- Showing contrast: \"While loss occurs, gain is also possible.\"\n- Balancing views: \"On one hand, drain causes loss; on the other, circulation creates benefits.\"\n- Comparing: \"Whereas drain depletes, circulation enriches.\"", "examples": ["While brain drain causes loss, brain circulation creates gain.", "However, policies can address these issues.", "On the other hand, circulation benefits both countries.", "Whereas drain depletes talent, circulation shares it.", "While loss occurs when people leave, gain is possible through circulation."]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 7, 'Build Sentences 1', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'While brain drain causes loss, brain circulation creates gain.', 'While brain drain causes loss, brain circulation creates gain.', '["While", "brain", "drain", "causes", "loss,", "brain", "circulation", "creates", "gain."]'::jsonb),
    (activity_id_var, 'However, policies can address these issues.', 'However, policies can address these issues.', '["However,", "policies", "can", "address", "these", "issues."]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 8, 'Build Sentences 2', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'On the other hand, circulation benefits both countries.', 'On the other hand, circulation benefits both countries.', '["On", "the", "other", "hand,", "circulation", "benefits", "both", "countries."]'::jsonb),
    (activity_id_var, 'Whereas drain depletes talent, circulation shares it.', 'Whereas drain depletes talent, circulation shares it.', '["Whereas", "drain", "depletes", "talent,", "circulation", "shares", "it."]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'speaking_practice', 9, 'Discuss Brain Drain', 'Practice speaking about brain drain', '{"prompts": ["What is gained and lost when people leave?", "How does brain drain affect countries?", "What is brain circulation?", "How do you balance personal opportunity and national need?", "What policies address brain drain?"]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (
      lesson_id,
      activity_type,
      activity_order,
      title,
      description,
      content
    ) VALUES (
      'C1-L82',
      'speaking_improvement',
      10,
      'Speaking Improvement',
      'Read the improved version of your speech',
      '{"type": "speaking_improvement", "similarityThreshold": 70}'::jsonb
    );
END $$;



-- =========================================
-- C1 Lesson 83
-- =========================================

-- =========================================
-- Pre-fill Database with Sample Lesson Data
-- C1-L83: Studying Abroad and Identity Change
-- =========================================
DELETE FROM lesson_activity_results WHERE lesson_id = 'C1-L83';
DELETE FROM user_progress WHERE lesson_id = 'C1-L83';
DELETE FROM lesson_history WHERE lesson_id = 'C1-L83';
DELETE FROM grammar_sentences WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'C1-L83');
DELETE FROM vocabulary_items WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'C1-L83');
DELETE FROM lesson_activities WHERE lesson_id = 'C1-L83';
DELETE FROM lessons WHERE id = 'C1-L83';

INSERT INTO lessons (id, level, lesson_number, topic) VALUES
('C1-L83', 'C1', 83, 'Studying Abroad and Identity Change')
ON CONFLICT (id) DO UPDATE SET topic = EXCLUDED.topic;

DO $$
DECLARE
    lesson_id_var TEXT := 'C1-L83';
    activity_id_var UUID;
BEGIN
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'warm_up_speaking', 1, 'Studying Abroad', 'Discuss studying abroad and identity', '{"prompt": "If you had not studied abroad, how might you be different now?"}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_intro', 2, 'Study Abroad Vocabulary', 'Learn vocabulary about studying abroad', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'identity', 'ตัวตน', NULL),
    (activity_id_var, 'change', 'การเปลี่ยนแปลง', NULL),
    (activity_id_var, 'adaptation', 'การปรับตัว', NULL),
    (activity_id_var, 'experience', 'ประสบการณ์', NULL),
    (activity_id_var, 'maintenance', 'การบำรุงรักษา', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_matching_drag', 3, 'Match Study Abroad Words', 'Match English words with Thai meanings', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'identity', 'ตัวตน', NULL),
    (activity_id_var, 'change', 'การเปลี่ยนแปลง', NULL),
    (activity_id_var, 'adaptation', 'การปรับตัว', NULL),
    (activity_id_var, 'experience', 'ประสบการณ์', NULL),
    (activity_id_var, 'maintenance', 'การบำรุงรักษา', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 4, 'Complete the Sentences 1', 'Fill with the correct word', '{"text": "Studying abroad changes ___. Personal ___ occur during ___.", "blanks": [{"id": "blank1", "text": "identity", "options": ["identity", "change", "adaptation", "experience"], "correctAnswer": "identity"}, {"id": "blank2", "text": "changes", "options": ["changes", "identity", "adaptation", "experience"], "correctAnswer": "changes"}, {"id": "blank3", "text": "adaptation", "options": ["adaptation", "identity", "change", "experience"], "correctAnswer": "adaptation"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 5, 'Complete the Sentences 2', 'Fill with the correct word', '{"text": "Maintaining ___ while adapting is challenging. International ___ enriches ___.", "blanks": [{"id": "blank1", "text": "identity", "options": ["identity", "change", "adaptation", "experience"], "correctAnswer": "identity"}, {"id": "blank2", "text": "experience", "options": ["experience", "identity", "change", "adaptation"], "correctAnswer": "experience"}, {"id": "blank3", "text": "identity", "options": ["identity", "change", "adaptation", "experience"], "correctAnswer": "identity"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_explanation', 6, 'Mixed Conditionals', 'Learn mixed conditional structures', '{"rules": "Mixed conditionals combine different time references:\n- Mixed 2/3: \"If I hadn''t left (past), I would be different now (present).\"\n- Mixed 3/2: \"If I had not studied abroad (past), I would not have this perspective now (present).\"\n\nStructures:\n- If + past perfect, would + base form (past condition, present result)\n- If + past simple, would have + past participle (present condition, past result)\n\nUse for:\n- Hypothetical past affecting present: \"If I hadn''t left, I would be different now.\"\n- Unreal past affecting present: \"If I had not studied abroad, I would not understand this now.\"", "examples": ["If I hadn''t left, I would be different now.", "If I had not studied abroad, I would not have this perspective now.", "If I had stayed home, I would not understand international perspectives now.", "If I hadn''t experienced abroad, I would be less adaptable now.", "If I had not left, I would have a different identity now."]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 7, 'Build Sentences 1', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'If I hadn''t left, I would be different now.', 'If I hadn''t left, I would be different now.', '["If", "I", "hadn''t", "left,", "I", "would", "be", "different", "now."]'::jsonb),
    (activity_id_var, 'If I had not studied abroad, I would not have this perspective now.', 'If I had not studied abroad, I would not have this perspective now.', '["If", "I", "had", "not", "studied", "abroad,", "I", "would", "not", "have", "this", "perspective", "now."]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 8, 'Build Sentences 2', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'If I had stayed home, I would not understand international perspectives now.', 'If I had stayed home, I would not understand international perspectives now.', '["If", "I", "had", "stayed", "home,", "I", "would", "not", "understand", "international", "perspectives", "now."]'::jsonb),
    (activity_id_var, 'If I hadn''t experienced abroad, I would be less adaptable now.', 'If I hadn''t experienced abroad, I would be less adaptable now.', '["If", "I", "hadn''t", "experienced", "abroad,", "I", "would", "be", "less", "adaptable", "now."]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'speaking_practice', 9, 'Discuss Study Abroad', 'Practice speaking about studying abroad', '{"prompts": ["If you hadn''t left, who would you be now?", "How does studying abroad change identity?", "What personal changes occur abroad?", "How do you maintain identity while adapting?", "What do you gain from international experience?"]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (
      lesson_id,
      activity_type,
      activity_order,
      title,
      description,
      content
    ) VALUES (
      'C1-L83',
      'speaking_improvement',
      10,
      'Speaking Improvement',
      'Read the improved version of your speech',
      '{"type": "speaking_improvement", "similarityThreshold": 70}'::jsonb
    );
END $$;



-- =========================================
-- C1 Lesson 84
-- =========================================

-- =========================================
-- Pre-fill Database with Sample Lesson Data
-- C1-L84: Language Dominance in Academia
-- =========================================
DELETE FROM lesson_activity_results WHERE lesson_id = 'C1-L84';
DELETE FROM user_progress WHERE lesson_id = 'C1-L84';
DELETE FROM lesson_history WHERE lesson_id = 'C1-L84';
DELETE FROM grammar_sentences WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'C1-L84');
DELETE FROM vocabulary_items WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'C1-L84');
DELETE FROM lesson_activities WHERE lesson_id = 'C1-L84';
DELETE FROM lessons WHERE id = 'C1-L84';

INSERT INTO lessons (id, level, lesson_number, topic) VALUES
('C1-L84', 'C1', 84, 'Language Dominance in Academia')
ON CONFLICT (id) DO UPDATE SET topic = EXCLUDED.topic;

DO $$
DECLARE
    lesson_id_var TEXT := 'C1-L84';
    activity_id_var UUID;
BEGIN
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'warm_up_speaking', 1, 'Language Dominance', 'Discuss language dominance in academia', '{"prompt": "How does one language come to dominate academic fields?"}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_intro', 2, 'Language Dominance Vocabulary', 'Learn vocabulary about language dominance', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'dominance', 'การครอบงำ', NULL),
    (activity_id_var, 'factor', 'ปัจจัย', NULL),
    (activity_id_var, 'balance', 'ความสมดุล', NULL),
    (activity_id_var, 'access', 'การเข้าถึง', NULL),
    (activity_id_var, 'multilingual', 'หลายภาษา', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_matching_drag', 3, 'Match Language Dominance Words', 'Match English words with Thai meanings', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'dominance', 'การครอบงำ', NULL),
    (activity_id_var, 'factor', 'ปัจจัย', NULL),
    (activity_id_var, 'balance', 'ความสมดุล', NULL),
    (activity_id_var, 'access', 'การเข้าถึง', NULL),
    (activity_id_var, 'multilingual', 'หลายภาษา', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 4, 'Complete the Sentences 1', 'Fill with the correct word', '{"text": "Language ___ in academia affects ___. Various ___ shift the ___.", "blanks": [{"id": "blank1", "text": "dominance", "options": ["dominance", "factor", "balance", "access"], "correctAnswer": "dominance"}, {"id": "blank2", "text": "access", "options": ["access", "dominance", "factor", "balance"], "correctAnswer": "access"}, {"id": "blank3", "text": "factors", "options": ["factors", "dominance", "balance", "access"], "correctAnswer": "factors"}, {"id": "blank4", "text": "balance", "options": ["balance", "dominance", "factor", "access"], "correctAnswer": "balance"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 5, 'Complete the Sentences 2', 'Fill with the correct word', '{"text": "A ___ academic world would be different. Language ___ limits ___.", "blanks": [{"id": "blank1", "text": "multilingual", "options": ["multilingual", "dominance", "factor", "balance"], "correctAnswer": "multilingual"}, {"id": "blank2", "text": "dominance", "options": ["dominance", "factor", "balance", "access"], "correctAnswer": "dominance"}, {"id": "blank3", "text": "access", "options": ["access", "dominance", "factor", "balance"], "correctAnswer": "access"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_explanation', 6, 'Articles: Stylistic Use', 'Learn stylistic use of articles', '{"rules": "Stylistic use of articles:\n- \"The\" for specific reference: \"the language that dominates\"\n- Zero article for general concepts: \"language dominance affects access\"\n- \"A/an\" for classification: \"a dominant language\"\n\nStylistic patterns:\n- General statements: \"Language dominance shapes academia.\"\n- Specific reference: \"The dominance we see is concerning.\"\n- Classification: \"A dominant language creates barriers.\"\n\nUse for:\n- General statements: \"Language dominance evolves.\"\n- Specific cases: \"The dominance of English is clear.\"\n- Classification: \"A multilingual approach benefits all.\"", "examples": ["The language that dominates shapes academic discourse.", "Language dominance affects access to knowledge.", "A dominant language creates barriers for others.", "The dominance we observe limits diversity.", "A multilingual academic world would be inclusive."]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 7, 'Build Sentences 1', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'The language that dominates shapes academic discourse.', 'The language that dominates shapes academic discourse.', '["The", "language", "that", "dominates", "shapes", "academic", "discourse."]'::jsonb),
    (activity_id_var, 'Language dominance affects access to knowledge.', 'Language dominance affects access to knowledge.', '["Language", "dominance", "affects", "access", "to", "knowledge."]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 8, 'Build Sentences 2', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'A dominant language creates barriers for others.', 'A dominant language creates barriers for others.', '["A", "dominant", "language", "creates", "barriers", "for", "others."]'::jsonb),
    (activity_id_var, 'A multilingual academic world would be inclusive.', 'A multilingual academic world would be inclusive.', '["A", "multilingual", "academic", "world", "would", "be", "inclusive."]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'speaking_practice', 9, 'Discuss Language Dominance', 'Practice speaking about language dominance', '{"prompts": ["How does one language dominate academia?", "What factors shift the balance?", "What role does English play in academia?", "How does language dominance affect access?", "What might a multilingual academic world look like?"]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (
      lesson_id,
      activity_type,
      activity_order,
      title,
      description,
      content
    ) VALUES (
      'C1-L84',
      'speaking_improvement',
      10,
      'Speaking Improvement',
      'Read the improved version of your speech',
      '{"type": "speaking_improvement", "similarityThreshold": 70}'::jsonb
    );
END $$;



-- =========================================
-- C1 Lesson 85
-- =========================================

-- =========================================
-- Pre-fill Database with Sample Lesson Data
-- C1-L85: Inequality in Global Education Systems
-- =========================================
DELETE FROM lesson_activity_results WHERE lesson_id = 'C1-L85';
DELETE FROM user_progress WHERE lesson_id = 'C1-L85';
DELETE FROM lesson_history WHERE lesson_id = 'C1-L85';
DELETE FROM grammar_sentences WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'C1-L85');
DELETE FROM vocabulary_items WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'C1-L85');
DELETE FROM lesson_activities WHERE lesson_id = 'C1-L85';
DELETE FROM lessons WHERE id = 'C1-L85';

INSERT INTO lessons (id, level, lesson_number, topic) VALUES
('C1-L85', 'C1', 85, 'Inequality in Global Education Systems')
ON CONFLICT (id) DO UPDATE SET topic = EXCLUDED.topic;

DO $$
DECLARE
    lesson_id_var TEXT := 'C1-L85';
    activity_id_var UUID;
BEGIN
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'warm_up_speaking', 1, 'Education Inequality', 'Discuss inequality in education', '{"prompt": "How rarely do you see true equality in education systems?"}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_intro', 2, 'Inequality Vocabulary', 'Learn vocabulary about inequality', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'inequality', 'ความไม่เท่าเทียม', NULL),
    (activity_id_var, 'equality', 'ความเท่าเทียม', NULL),
    (activity_id_var, 'reduction', 'การลดลง', NULL),
    (activity_id_var, 'system', 'ระบบ', NULL),
    (activity_id_var, 'change', 'การเปลี่ยนแปลง', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_matching_drag', 3, 'Match Inequality Words', 'Match English words with Thai meanings', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'inequality', 'ความไม่เท่าเทียม', NULL),
    (activity_id_var, 'equality', 'ความเท่าเทียม', NULL),
    (activity_id_var, 'reduction', 'การลดลง', NULL),
    (activity_id_var, 'system', 'ระบบ', NULL),
    (activity_id_var, 'change', 'การเปลี่ยนแปลง', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 4, 'Complete the Sentences 1', 'Fill with the correct word', '{"text": "Education ___ exists globally. ___ of ___ requires ___.", "blanks": [{"id": "blank1", "text": "inequality", "options": ["inequality", "equality", "reduction", "system"], "correctAnswer": "inequality"}, {"id": "blank2", "text": "Reduction", "options": ["Reduction", "Inequality", "Equality", "System"], "correctAnswer": "Reduction"}, {"id": "blank3", "text": "inequality", "options": ["inequality", "equality", "reduction", "system"], "correctAnswer": "inequality"}, {"id": "blank4", "text": "change", "options": ["change", "inequality", "equality", "system"], "correctAnswer": "change"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 5, 'Complete the Sentences 2', 'Fill with the correct word', '{"text": "Global education needs ___. Systemic ___ are necessary.", "blanks": [{"id": "blank1", "text": "equality", "options": ["equality", "inequality", "reduction", "system"], "correctAnswer": "equality"}, {"id": "blank2", "text": "changes", "options": ["changes", "inequality", "equality", "system"], "correctAnswer": "changes"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_explanation', 6, 'Inversion: Rarely/Seldom', 'Learn inversion with rarely and seldom', '{"rules": "Inversion with rarely/seldom:\n- \"Rarely do we see true equality.\" (formal emphasis)\n- \"Seldom is equality achieved.\" (emphasis on infrequency)\n- \"Rarely have I seen equal access.\" (past emphasis)\n\nStructure:\n- Rarely/Seldom + auxiliary + subject + verb\n- Used for emphasis and formal tone\n\nUse for:\n- Emphasizing rarity: \"Rarely do we see equality in education.\"\n- Formal statements: \"Seldom is true equality achieved.\"\n- Highlighting infrequency: \"Rarely have systems been equal.\"", "examples": ["Rarely do we see true equality in education systems.", "Seldom is equality achieved globally.", "Rarely have I seen equal access to education.", "Seldom do systems provide equal opportunities.", "Rarely is inequality fully addressed."]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 7, 'Build Sentences 1', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'Rarely do we see true equality in education systems.', 'Rarely do we see true equality in education systems.', '["Rarely", "do", "we", "see", "true", "equality", "in", "education", "systems."]'::jsonb),
    (activity_id_var, 'Seldom is equality achieved globally.', 'Seldom is equality achieved globally.', '["Seldom", "is", "equality", "achieved", "globally."]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 8, 'Build Sentences 2', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'Rarely have I seen equal access to education.', 'Rarely have I seen equal access to education.', '["Rarely", "have", "I", "seen", "equal", "access", "to", "education."]'::jsonb),
    (activity_id_var, 'Seldom do systems provide equal opportunities.', 'Seldom do systems provide equal opportunities.', '["Seldom", "do", "systems", "provide", "equal", "opportunities."]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'speaking_practice', 9, 'Discuss Education Inequality', 'Practice speaking about inequality', '{"prompts": ["How rarely do you see equality in education?", "What would help reduce inequality?", "What inequalities exist in global education?", "How can global education become more equal?", "What systemic changes are needed?"]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (
      lesson_id,
      activity_type,
      activity_order,
      title,
      description,
      content
    ) VALUES (
      'C1-L85',
      'speaking_improvement',
      10,
      'Speaking Improvement',
      'Read the improved version of your speech',
      '{"type": "speaking_improvement", "similarityThreshold": 70}'::jsonb
    );
END $$;



-- =========================================
-- C1 Lesson 86
-- =========================================

-- =========================================
-- Pre-fill Database with Sample Lesson Data
-- C1-L86: International Cooperation in Education
-- =========================================
DELETE FROM lesson_activity_results WHERE lesson_id = 'C1-L86';
DELETE FROM user_progress WHERE lesson_id = 'C1-L86';
DELETE FROM lesson_history WHERE lesson_id = 'C1-L86';
DELETE FROM grammar_sentences WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'C1-L86');
DELETE FROM vocabulary_items WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'C1-L86');
DELETE FROM lesson_activities WHERE lesson_id = 'C1-L86';
DELETE FROM lessons WHERE id = 'C1-L86';

INSERT INTO lessons (id, level, lesson_number, topic) VALUES
('C1-L86', 'C1', 86, 'International Cooperation in Education')
ON CONFLICT (id) DO UPDATE SET topic = EXCLUDED.topic;

DO $$
DECLARE
    lesson_id_var TEXT := 'C1-L86';
    activity_id_var UUID;
BEGIN
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'warm_up_speaking', 1, 'International Cooperation', 'Discuss international cooperation', '{"prompt": "How do international education partnerships succeed or fail?"}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_intro', 2, 'Cooperation Vocabulary', 'Learn vocabulary about cooperation', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'cooperation', 'ความร่วมมือ', NULL),
    (activity_id_var, 'partnership', 'ความร่วมมือ', NULL),
    (activity_id_var, 'success', 'ความสำเร็จ', NULL),
    (activity_id_var, 'failure', 'ความล้มเหลว', NULL),
    (activity_id_var, 'trust', 'ความไว้วางใจ', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_matching_drag', 3, 'Match Cooperation Words', 'Match English words with Thai meanings', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'cooperation', 'ความร่วมมือ', NULL),
    (activity_id_var, 'partnership', 'ความร่วมมือ', NULL),
    (activity_id_var, 'success', 'ความสำเร็จ', NULL),
    (activity_id_var, 'failure', 'ความล้มเหลว', NULL),
    (activity_id_var, 'trust', 'ความไว้วางใจ', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 4, 'Complete the Sentences 1', 'Fill with the correct word', '{"text": "International ___ requires ___. Educational ___ can succeed or ___.", "blanks": [{"id": "blank1", "text": "cooperation", "options": ["cooperation", "partnership", "success", "failure"], "correctAnswer": "cooperation"}, {"id": "blank2", "text": "trust", "options": ["trust", "cooperation", "partnership", "success"], "correctAnswer": "trust"}, {"id": "blank3", "text": "partnerships", "options": ["partnerships", "cooperation", "success", "failure"], "correctAnswer": "partnerships"}, {"id": "blank4", "text": "fail", "options": ["fail", "cooperation", "partnership", "success"], "correctAnswer": "fail"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 5, 'Complete the Sentences 2', 'Fill with the correct word', '{"text": "___ enables ___. Building ___ between institutions matters.", "blanks": [{"id": "blank1", "text": "Trust", "options": ["Trust", "Cooperation", "Partnership", "Success"], "correctAnswer": "Trust"}, {"id": "blank2", "text": "success", "options": ["success", "cooperation", "partnership", "trust"], "correctAnswer": "success"}, {"id": "blank3", "text": "trust", "options": ["trust", "cooperation", "partnership", "success"], "correctAnswer": "trust"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_explanation', 6, 'Cohesion and Ellipsis', 'Learn cohesion and ellipsis', '{"rules": "Cohesion and ellipsis:\n- Ellipsis: \"Partnerships can succeed, and cooperation can too.\"\n- Substitution: \"Some partnerships work, and others do so as well.\"\n- Reference: \"International cooperation creates challenges; these challenges need addressing.\"\n\nUse for:\n- Avoiding repetition: \"Partnerships require trust, and cooperation does too.\"\n- Creating flow: \"Successful partnerships create benefits; such benefits matter.\"\n- Connecting ideas: \"Challenges arise; these challenges need solutions.\"", "examples": ["Partnerships can succeed, and cooperation can too.", "Some partnerships work, and others do so as well.", "International cooperation creates challenges; these challenges need addressing.", "Successful partnerships create benefits; such benefits matter.", "Trust enables cooperation; this trust must be built."]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 7, 'Build Sentences 1', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'Partnerships can succeed, and cooperation can too.', 'Partnerships can succeed, and cooperation can too.', '["Partnerships", "can", "succeed,", "and", "cooperation", "can", "too."]'::jsonb),
    (activity_id_var, 'Some partnerships work, and others do so as well.', 'Some partnerships work, and others do so as well.', '["Some", "partnerships", "work,", "and", "others", "do", "so", "as", "well."]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 8, 'Build Sentences 2', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'International cooperation creates challenges; these challenges need addressing.', 'International cooperation creates challenges; these challenges need addressing.', '["International", "cooperation", "creates", "challenges;", "these", "challenges", "need", "addressing."]'::jsonb),
    (activity_id_var, 'Successful partnerships create benefits; such benefits matter.', 'Successful partnerships create benefits; such benefits matter.', '["Successful", "partnerships", "create", "benefits;", "such", "benefits", "matter."]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'speaking_practice', 9, 'Discuss International Cooperation', 'Practice speaking about cooperation', '{"prompts": ["How do educational partnerships work?", "What causes partnerships to fail?", "What enables successful international cooperation?", "What challenges arise in cross-border partnerships?", "How is trust built between institutions?"]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (
      lesson_id,
      activity_type,
      activity_order,
      title,
      description,
      content
    ) VALUES (
      'C1-L86',
      'speaking_improvement',
      10,
      'Speaking Improvement',
      'Read the improved version of your speech',
      '{"type": "speaking_improvement", "similarityThreshold": 70}'::jsonb
    );
END $$;



-- =========================================
-- C1 Lesson 87
-- =========================================

-- =========================================
-- Pre-fill Database with Sample Lesson Data
-- C1-L87: Cultural Shock and Adaptation
-- =========================================
DELETE FROM lesson_activity_results WHERE lesson_id = 'C1-L87';
DELETE FROM user_progress WHERE lesson_id = 'C1-L87';
DELETE FROM lesson_history WHERE lesson_id = 'C1-L87';
DELETE FROM grammar_sentences WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'C1-L87');
DELETE FROM vocabulary_items WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'C1-L87');
DELETE FROM lesson_activities WHERE lesson_id = 'C1-L87';
DELETE FROM lessons WHERE id = 'C1-L87';

INSERT INTO lessons (id, level, lesson_number, topic) VALUES
('C1-L87', 'C1', 87, 'Cultural Shock and Adaptation')
ON CONFLICT (id) DO UPDATE SET topic = EXCLUDED.topic;

DO $$
DECLARE
    lesson_id_var TEXT := 'C1-L87';
    activity_id_var UUID;
BEGIN
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'warm_up_speaking', 1, 'Cultural Shock', 'Discuss cultural shock', '{"prompt": "Describe a moment of cultural shock and how it ended."}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_intro', 2, 'Cultural Shock Vocabulary', 'Learn vocabulary about cultural shock', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'shock', 'ความตกใจ', NULL),
    (activity_id_var, 'adaptation', 'การปรับตัว', NULL),
    (activity_id_var, 'experience', 'ประสบการณ์', NULL),
    (activity_id_var, 'adjustment', 'การปรับตัว', NULL),
    (activity_id_var, 'difference', 'ความแตกต่าง', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_matching_drag', 3, 'Match Cultural Shock Words', 'Match English words with Thai meanings', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'shock', 'ความตกใจ', NULL),
    (activity_id_var, 'adaptation', 'การปรับตัว', NULL),
    (activity_id_var, 'experience', 'ประสบการณ์', NULL),
    (activity_id_var, 'adjustment', 'การปรับตัว', NULL),
    (activity_id_var, 'difference', 'ความแตกต่าง', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 4, 'Complete the Sentences 1', 'Fill with the correct word', '{"text": "Cultural ___ creates challenges. Successful ___ requires ___.", "blanks": [{"id": "blank1", "text": "shock", "options": ["shock", "adaptation", "experience", "adjustment"], "correctAnswer": "shock"}, {"id": "blank2", "text": "adaptation", "options": ["adaptation", "shock", "experience", "adjustment"], "correctAnswer": "adaptation"}, {"id": "blank3", "text": "time", "options": ["time", "shock", "adaptation", "experience"], "correctAnswer": "time"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 5, 'Complete the Sentences 2', 'Fill with the correct word', '{"text": "Managing cultural ___ requires ___. ___ helps with ___.", "blanks": [{"id": "blank1", "text": "differences", "options": ["differences", "shock", "adaptation", "adjustment"], "correctAnswer": "differences"}, {"id": "blank2", "text": "understanding", "options": ["understanding", "shock", "adaptation", "adjustment"], "correctAnswer": "understanding"}, {"id": "blank3", "text": "Adjustment", "options": ["Adjustment", "Shock", "Adaptation", "Difference"], "correctAnswer": "Adjustment"}, {"id": "blank4", "text": "adaptation", "options": ["adaptation", "shock", "difference", "adjustment"], "correctAnswer": "adaptation"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_explanation', 6, 'Narrative Tenses', 'Learn narrative tenses', '{"rules": "Narrative tenses for storytelling:\n- Past simple: \"I experienced cultural shock.\"\n- Past continuous: \"I was adapting when I realized...\"\n- Past perfect: \"I had arrived before the shock occurred.\"\n- Past perfect continuous: \"I had been living there when...\"\n\nUse for:\n- Main events: \"I experienced the biggest shock.\"\n- Background: \"I was adapting when it happened.\"\n- Earlier events: \"I had arrived before the shock.\"\n- Duration: \"I had been living there for months.\"", "examples": ["I experienced my biggest cultural shock when I arrived.", "I was adapting to the new culture when the shock occurred.", "I had arrived in the country before the shock happened.", "I had been living there for months when I finally adapted.", "The shock occurred, and then I began to adapt."]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 7, 'Build Sentences 1', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'I experienced my biggest cultural shock when I arrived.', 'I experienced my biggest cultural shock when I arrived.', '["I", "experienced", "my", "biggest", "cultural", "shock", "when", "I", "arrived."]'::jsonb),
    (activity_id_var, 'I was adapting to the new culture when the shock occurred.', 'I was adapting to the new culture when the shock occurred.', '["I", "was", "adapting", "to", "the", "new", "culture", "when", "the", "shock", "occurred."]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 8, 'Build Sentences 2', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'I had arrived in the country before the shock happened.', 'I had arrived in the country before the shock happened.', '["I", "had", "arrived", "in", "the", "country", "before", "the", "shock", "happened."]'::jsonb),
    (activity_id_var, 'I had been living there for months when I finally adapted.', 'I had been living there for months when I finally adapted.', '["I", "had", "been", "living", "there", "for", "months", "when", "I", "finally", "adapted."]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'speaking_practice', 9, 'Discuss Cultural Shock', 'Practice speaking about cultural shock', '{"prompts": ["Describe your biggest cultural shock and its outcome.", "What cultural shocks have you experienced?", "How do you adapt to new cultures?", "What helps with cultural adjustment?", "How do you manage cultural differences?"]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (
      lesson_id,
      activity_type,
      activity_order,
      title,
      description,
      content
    ) VALUES (
      'C1-L87',
      'speaking_improvement',
      10,
      'Speaking Improvement',
      'Read the improved version of your speech',
      '{"type": "speaking_improvement", "similarityThreshold": 70}'::jsonb
    );
END $$;



-- =========================================
-- C1 Lesson 88
-- =========================================

-- =========================================
-- Pre-fill Database with Sample Lesson Data
-- C1-L88: Education as Soft Power
-- =========================================
DELETE FROM lesson_activity_results WHERE lesson_id = 'C1-L88';
DELETE FROM user_progress WHERE lesson_id = 'C1-L88';
DELETE FROM lesson_history WHERE lesson_id = 'C1-L88';
DELETE FROM grammar_sentences WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'C1-L88');
DELETE FROM vocabulary_items WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'C1-L88');
DELETE FROM lesson_activities WHERE lesson_id = 'C1-L88';
DELETE FROM lessons WHERE id = 'C1-L88';

INSERT INTO lessons (id, level, lesson_number, topic) VALUES
('C1-L88', 'C1', 88, 'Education as Soft Power')
ON CONFLICT (id) DO UPDATE SET topic = EXCLUDED.topic;

DO $$
DECLARE
    lesson_id_var TEXT := 'C1-L88';
    activity_id_var UUID;
BEGIN
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'warm_up_speaking', 1, 'Education as Soft Power', 'Discuss education as soft power', '{"prompt": "How might education influence international relationships?"}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_intro', 2, 'Soft Power Vocabulary', 'Learn vocabulary about soft power', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'power', 'อำนาจ', NULL),
    (activity_id_var, 'influence', 'อิทธิพล', NULL),
    (activity_id_var, 'relation', 'ความสัมพันธ์', NULL),
    (activity_id_var, 'exchange', 'การแลกเปลี่ยน', NULL),
    (activity_id_var, 'diplomacy', 'การทูต', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_matching_drag', 3, 'Match Soft Power Words', 'Match English words with Thai meanings', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'power', 'อำนาจ', NULL),
    (activity_id_var, 'influence', 'อิทธิพล', NULL),
    (activity_id_var, 'relation', 'ความสัมพันธ์', NULL),
    (activity_id_var, 'exchange', 'การแลกเปลี่ยน', NULL),
    (activity_id_var, 'diplomacy', 'การทูต', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 4, 'Complete the Sentences 1', 'Fill with the correct word', '{"text": "Education serves as ___. ___ shapes international ___.", "blanks": [{"id": "blank1", "text": "power", "options": ["power", "influence", "relation", "exchange"], "correctAnswer": "power"}, {"id": "blank2", "text": "Influence", "options": ["Influence", "Power", "Relation", "Exchange"], "correctAnswer": "Influence"}, {"id": "blank3", "text": "relations", "options": ["relations", "power", "influence", "exchange"], "correctAnswer": "relations"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 5, 'Complete the Sentences 2', 'Fill with the correct word', '{"text": "Exchange programs create ___. Countries use education for ___.", "blanks": [{"id": "blank1", "text": "influence", "options": ["influence", "power", "relation", "exchange"], "correctAnswer": "influence"}, {"id": "blank2", "text": "diplomacy", "options": ["diplomacy", "power", "influence", "exchange"], "correctAnswer": "diplomacy"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_explanation', 6, 'Modals: Speculation', 'Learn modals for speculation', '{"rules": "Modals for speculation:\n- \"might\" (possibility): \"Education might influence relationships.\"\n- \"could\" (possibility): \"Education could shape diplomacy.\"\n- \"may\" (possibility): \"Education may affect international relations.\"\n- \"must\" (high certainty): \"Education must influence nations.\"\n\nUse for:\n- Speculating about possibility: \"Education might influence other nations.\"\n- Expressing uncertainty: \"Education could shape relationships.\"\n- Showing probability: \"Education may affect diplomacy.\"", "examples": ["Education might influence other nations significantly.", "Education could shape international relationships.", "Education may affect diplomatic relations.", "Education must influence how nations interact.", "Education might serve as a form of soft power."]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 7, 'Build Sentences 1', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'Education might influence other nations significantly.', 'Education might influence other nations significantly.', '["Education", "might", "influence", "other", "nations", "significantly."]'::jsonb),
    (activity_id_var, 'Education could shape international relationships.', 'Education could shape international relationships.', '["Education", "could", "shape", "international", "relationships."]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 8, 'Build Sentences 2', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'Education may affect diplomatic relations.', 'Education may affect diplomatic relations.', '["Education", "may", "affect", "diplomatic", "relations."]'::jsonb),
    (activity_id_var, 'Education might serve as a form of soft power.', 'Education might serve as a form of soft power.', '["Education", "might", "serve", "as", "a", "form", "of", "soft", "power."]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'speaking_practice', 9, 'Discuss Education as Soft Power', 'Practice speaking about education as soft power', '{"prompts": ["How might education influence other nations?", "What does \"soft power\" mean in education?", "How does education shape international relations?", "What influence do exchange programs have?", "How do countries use education diplomatically?"]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (
      lesson_id,
      activity_type,
      activity_order,
      title,
      description,
      content
    ) VALUES (
      'C1-L88',
      'speaking_improvement',
      10,
      'Speaking Improvement',
      'Read the improved version of your speech',
      '{"type": "speaking_improvement", "similarityThreshold": 70}'::jsonb
    );
END $$;



-- =========================================
-- C1 Lesson 89
-- =========================================

-- =========================================
-- Pre-fill Database with Sample Lesson Data
-- C1-L89: Ethical Study Abroad Practices
-- =========================================
DELETE FROM lesson_activity_results WHERE lesson_id = 'C1-L89';
DELETE FROM user_progress WHERE lesson_id = 'C1-L89';
DELETE FROM lesson_history WHERE lesson_id = 'C1-L89';
DELETE FROM grammar_sentences WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'C1-L89');
DELETE FROM vocabulary_items WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'C1-L89');
DELETE FROM lesson_activities WHERE lesson_id = 'C1-L89';
DELETE FROM lessons WHERE id = 'C1-L89';

INSERT INTO lessons (id, level, lesson_number, topic) VALUES
('C1-L89', 'C1', 89, 'Ethical Study Abroad Practices')
ON CONFLICT (id) DO UPDATE SET topic = EXCLUDED.topic;

DO $$
DECLARE
    lesson_id_var TEXT := 'C1-L89';
    activity_id_var UUID;
BEGIN
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'warm_up_speaking', 1, 'Ethical Study Abroad', 'Discuss ethical study abroad practices', '{"prompt": "What responsibilities must be upheld in study abroad programs?"}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_intro', 2, 'Ethical Practices Vocabulary', 'Learn vocabulary about ethical practices', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'responsibility', 'ความรับผิดชอบ', NULL),
    (activity_id_var, 'standard', 'มาตรฐาน', NULL),
    (activity_id_var, 'engagement', 'การมีส่วนร่วม', NULL),
    (activity_id_var, 'institution', 'สถาบัน', NULL),
    (activity_id_var, 'practice', 'การปฏิบัติ', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_matching_drag', 3, 'Match Ethical Practices Words', 'Match English words with Thai meanings', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'responsibility', 'ความรับผิดชอบ', NULL),
    (activity_id_var, 'standard', 'มาตรฐาน', NULL),
    (activity_id_var, 'engagement', 'การมีส่วนร่วม', NULL),
    (activity_id_var, 'institution', 'สถาบัน', NULL),
    (activity_id_var, 'practice', 'การปฏิบัติ', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 4, 'Complete the Sentences 1', 'Fill with the correct word', '{"text": "Study abroad programs must ensure ___. Ethical ___ should be followed.", "blanks": [{"id": "blank1", "text": "safety", "options": ["safety", "responsibility", "standard", "engagement"], "correctAnswer": "safety"}, {"id": "blank2", "text": "standards", "options": ["standards", "responsibility", "safety", "engagement"], "correctAnswer": "standards"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 5, 'Complete the Sentences 2', 'Fill with the correct word', '{"text": "Students should avoid harmful ___. Ethical ___ requires ___.", "blanks": [{"id": "blank1", "text": "practices", "options": ["practices", "responsibility", "standard", "engagement"], "correctAnswer": "practices"}, {"id": "blank2", "text": "engagement", "options": ["engagement", "responsibility", "standard", "practice"], "correctAnswer": "engagement"}, {"id": "blank3", "text": "respect", "options": ["respect", "responsibility", "standard", "engagement"], "correctAnswer": "respect"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_explanation', 6, 'Advanced Passives', 'Learn advanced passive structures', '{"rules": "Advanced passive forms:\n- \"Responsibilities must be upheld.\" (necessity)\n- \"Standards should be followed.\" (obligation)\n- \"Practices are being improved.\" (continuous)\n- \"Responsibilities have been defined.\" (perfect)\n- \"Standards will be enforced.\" (future)\n\nUse when:\n- Focus is on action, not actor: \"Responsibilities must be upheld.\"\n- Actor is unknown/unimportant: \"Standards were established.\"\n- Formal/impersonal tone: \"It is required that standards be followed.\"", "examples": ["Responsibilities must be upheld by study abroad programs.", "Standards should be followed by all participants.", "Practices are being improved continuously.", "Responsibilities have been defined clearly.", "Standards will be enforced to ensure ethics."]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 7, 'Build Sentences 1', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'Responsibilities must be upheld by study abroad programs.', 'Responsibilities must be upheld by study abroad programs.', '["Responsibilities", "must", "be", "upheld", "by", "study", "abroad", "programs."]'::jsonb),
    (activity_id_var, 'Standards should be followed by all participants.', 'Standards should be followed by all participants.', '["Standards", "should", "be", "followed", "by", "all", "participants."]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 8, 'Build Sentences 2', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'Practices are being improved continuously.', 'Practices are being improved continuously.', '["Practices", "are", "being", "improved", "continuously."]'::jsonb),
    (activity_id_var, 'Responsibilities have been defined clearly.', 'Responsibilities have been defined clearly.', '["Responsibilities", "have", "been", "defined", "clearly."]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'speaking_practice', 9, 'Discuss Ethical Study Abroad', 'Practice speaking about ethical practices', '{"prompts": ["What must be ensured by study abroad programs?", "What should students avoid when studying abroad?", "What ethical standards should programs follow?", "How can students engage ethically in host cultures?", "What responsibilities are held by institutions?"]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (
      lesson_id,
      activity_type,
      activity_order,
      title,
      description,
      content
    ) VALUES (
      'C1-L89',
      'speaking_improvement',
      10,
      'Speaking Improvement',
      'Read the improved version of your speech',
      '{"type": "speaking_improvement", "similarityThreshold": 70}'::jsonb
    );
END $$;



-- =========================================
-- C1 Lesson 90
-- =========================================

-- =========================================
-- Pre-fill Database with Sample Lesson Data
-- C1-L90: Global Academic Competition
-- =========================================
DELETE FROM lesson_activity_results WHERE lesson_id = 'C1-L90';
DELETE FROM user_progress WHERE lesson_id = 'C1-L90';
DELETE FROM lesson_history WHERE lesson_id = 'C1-L90';
DELETE FROM grammar_sentences WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'C1-L90');
DELETE FROM vocabulary_items WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'C1-L90');
DELETE FROM lesson_activities WHERE lesson_id = 'C1-L90';
DELETE FROM lessons WHERE id = 'C1-L90';

INSERT INTO lessons (id, level, lesson_number, topic) VALUES
('C1-L90', 'C1', 90, 'Global Academic Competition')
ON CONFLICT (id) DO UPDATE SET topic = EXCLUDED.topic;

DO $$
DECLARE
    lesson_id_var TEXT := 'C1-L90';
    activity_id_var UUID;
BEGIN
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'warm_up_speaking', 1, 'Academic Competition', 'Discuss global academic competition', '{"prompt": "How has academic competition shaped your decisions over time?"}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_intro', 2, 'Academic Competition Vocabulary', 'Learn vocabulary about academic competition', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'competition', 'การแข่งขัน', NULL),
    (activity_id_var, 'choice', 'ทางเลือก', NULL),
    (activity_id_var, 'drive', 'แรงผลักดัน', NULL),
    (activity_id_var, 'benefit', 'ประโยชน์', NULL),
    (activity_id_var, 'cost', 'ค่าใช้จ่าย', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_matching_drag', 3, 'Match Competition Words', 'Match English words with Thai meanings', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'competition', 'การแข่งขัน', NULL),
    (activity_id_var, 'choice', 'ทางเลือก', NULL),
    (activity_id_var, 'drive', 'แรงผลักดัน', NULL),
    (activity_id_var, 'benefit', 'ประโยชน์', NULL),
    (activity_id_var, 'cost', 'ค่าใช้จ่าย', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 4, 'Complete the Sentences 1', 'Fill with the correct word', '{"text": "Academic ___ shapes ___. Various ___ drive ___.", "blanks": [{"id": "blank1", "text": "competition", "options": ["competition", "choice", "drive", "benefit"], "correctAnswer": "competition"}, {"id": "blank2", "text": "choices", "options": ["choices", "competition", "drive", "benefit"], "correctAnswer": "choices"}, {"id": "blank3", "text": "factors", "options": ["factors", "competition", "choice", "drive"], "correctAnswer": "factors"}, {"id": "blank4", "text": "competition", "options": ["competition", "choice", "drive", "benefit"], "correctAnswer": "competition"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 5, 'Complete the Sentences 2', 'Fill with the correct word', '{"text": "Competition has ___ and ___. Navigating ___ requires ___.", "blanks": [{"id": "blank1", "text": "benefits", "options": ["benefits", "competition", "choice", "drive"], "correctAnswer": "benefits"}, {"id": "blank2", "text": "costs", "options": ["costs", "competition", "choice", "drive"], "correctAnswer": "costs"}, {"id": "blank3", "text": "environments", "options": ["environments", "competition", "choice", "drive"], "correctAnswer": "environments"}, {"id": "blank4", "text": "strategy", "options": ["strategy", "competition", "choice", "drive"], "correctAnswer": "strategy"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_explanation', 6, 'Advanced Perfect Aspect', 'Learn advanced perfect forms', '{"rules": "Advanced perfect aspect:\n- Present perfect: \"I have shaped my choices through competition.\"\n- Past perfect: \"I had made decisions before competition increased.\"\n- Future perfect: \"I will have navigated competition by then.\"\n- Perfect continuous: \"I have been competing for years.\"\n\nUse for:\n- Completed actions with present relevance: \"I have shaped my academic choices through competition.\"\n- Past before past: \"I had made decisions before competition shaped them.\"\n- Future completion: \"I will have navigated competition by graduation.\"", "examples": ["I have shaped my academic choices through competition.", "I had made decisions before competition increased.", "I will have navigated competition by graduation.", "I have been competing academically for years.", "Having shaped my choices, I understand competition better."]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 7, 'Build Sentences 1', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'I have shaped my academic choices through competition.', 'I have shaped my academic choices through competition.', '["I", "have", "shaped", "my", "academic", "choices", "through", "competition."]'::jsonb),
    (activity_id_var, 'I had made decisions before competition increased.', 'I had made decisions before competition increased.', '["I", "had", "made", "decisions", "before", "competition", "increased."]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 8, 'Build Sentences 2', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'I have been competing academically for years.', 'I have been competing academically for years.', '["I", "have", "been", "competing", "academically", "for", "years."]'::jsonb),
    (activity_id_var, 'Having shaped my choices, I understand competition better.', 'Having shaped my choices, I understand competition better.', '["Having", "shaped", "my", "choices,", "I", "understand", "competition", "better."]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'speaking_practice', 9, 'Discuss Academic Competition', 'Practice speaking about academic competition', '{"prompts": ["How has competition shaped your academic choices?", "What drives global academic competition?", "How does competition affect students?", "What are the benefits and costs of competition?", "How do you navigate competitive environments?"]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (
      lesson_id,
      activity_type,
      activity_order,
      title,
      description,
      content
    ) VALUES (
      'C1-L90',
      'speaking_improvement',
      10,
      'Speaking Improvement',
      'Read the improved version of your speech',
      '{"type": "speaking_improvement", "similarityThreshold": 70}'::jsonb
    );
END $$;



-- =========================================
-- C1 Lesson 91
-- =========================================

-- =========================================
-- Pre-fill Database with Sample Lesson Data
-- C1-L91: Influence of Philosophy on Modern Thinking
-- =========================================
DELETE FROM lesson_activity_results WHERE lesson_id = 'C1-L91';
DELETE FROM user_progress WHERE lesson_id = 'C1-L91';
DELETE FROM lesson_history WHERE lesson_id = 'C1-L91';
DELETE FROM grammar_sentences WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'C1-L91');
DELETE FROM vocabulary_items WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'C1-L91');
DELETE FROM lesson_activities WHERE lesson_id = 'C1-L91';
DELETE FROM lessons WHERE id = 'C1-L91';

INSERT INTO lessons (id, level, lesson_number, topic) VALUES
('C1-L91', 'C1', 91, 'Influence of Philosophy on Modern Thinking')
ON CONFLICT (id) DO UPDATE SET topic = EXCLUDED.topic;

DO $$
DECLARE
    lesson_id_var TEXT := 'C1-L91';
    activity_id_var UUID;
BEGIN
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'warm_up_speaking', 1, 'Philosophy and Thinking', 'Discuss philosophy and modern thinking', '{"prompt": "Which philosophical ideas influence how you see the world?"}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_intro', 2, 'Philosophy Vocabulary', 'Learn vocabulary about philosophy', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'philosophy', 'ปรัชญา', NULL),
    (activity_id_var, 'idea', 'ความคิด', NULL),
    (activity_id_var, 'worldview', 'มุมมองโลก', NULL),
    (activity_id_var, 'concept', 'แนวคิด', NULL),
    (activity_id_var, 'decision', 'การตัดสินใจ', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_matching_drag', 3, 'Match Philosophy Words', 'Match English words with Thai meanings', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'philosophy', 'ปรัชญา', NULL),
    (activity_id_var, 'idea', 'ความคิด', NULL),
    (activity_id_var, 'worldview', 'มุมมองโลก', NULL),
    (activity_id_var, 'concept', 'แนวคิด', NULL),
    (activity_id_var, 'decision', 'การตัดสินใจ', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 4, 'Complete the Sentences 1', 'Fill with the correct word', '{"text": "Philosophical ___ shape ___. Modern ___ guide ___.", "blanks": [{"id": "blank1", "text": "ideas", "options": ["ideas", "philosophy", "worldview", "concept"], "correctAnswer": "ideas"}, {"id": "blank2", "text": "worldviews", "options": ["worldviews", "philosophy", "idea", "concept"], "correctAnswer": "worldviews"}, {"id": "blank3", "text": "concepts", "options": ["concepts", "philosophy", "idea", "worldview"], "correctAnswer": "concepts"}, {"id": "blank4", "text": "society", "options": ["society", "philosophy", "idea", "worldview"], "correctAnswer": "society"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 5, 'Complete the Sentences 2', 'Fill with the correct word', '{"text": "Philosophical ___ affect daily ___. ___ influences modern ___.", "blanks": [{"id": "blank1", "text": "ideas", "options": ["ideas", "philosophy", "worldview", "concept"], "correctAnswer": "ideas"}, {"id": "blank2", "text": "decisions", "options": ["decisions", "philosophy", "idea", "worldview"], "correctAnswer": "decisions"}, {"id": "blank3", "text": "Philosophy", "options": ["Philosophy", "Idea", "Worldview", "Concept"], "correctAnswer": "Philosophy"}, {"id": "blank4", "text": "thinking", "options": ["thinking", "philosophy", "idea", "worldview"], "correctAnswer": "thinking"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_explanation', 6, 'Nominal Clauses', 'Learn about nominal clauses', '{"rules": "Nominal clauses function as nouns:\n- Subject: \"Which ideas shape your worldview matters.\"\n- Object: \"I believe that philosophy influences thinking.\"\n- Complement: \"The question is why those ideas matter.\"\n\nTypes:\n- That-clauses: \"I think that philosophy shapes worldview.\"\n- Wh-clauses: \"Which ideas frame your worldview shapes perspective.\"\n- Whether/if: \"The issue is whether philosophy affects daily life.\"\n\nUse for:\n- Expressing beliefs: \"Which ideas I follow shapes my worldview.\"\n- Asking questions: \"Which ideas frame your worldview?\"\n- Making statements: \"That philosophy matters is clear.\"", "examples": ["Which ideas shape your worldview matters greatly.", "I believe that philosophy influences modern thinking.", "The question is why those ideas matter to you.", "Whether philosophy affects daily decisions remains debated.", "That philosophical ideas guide society is widely accepted."]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 7, 'Build Sentences 1', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'Which ideas shape your worldview matters greatly.', 'Which ideas shape your worldview matters greatly.', '["Which", "ideas", "shape", "your", "worldview", "matters", "greatly."]'::jsonb),
    (activity_id_var, 'I believe that philosophy influences modern thinking.', 'I believe that philosophy influences modern thinking.', '["I", "believe", "that", "philosophy", "influences", "modern", "thinking."]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 8, 'Build Sentences 2', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'The question is why those ideas matter to you.', 'The question is why those ideas matter to you.', '["The", "question", "is", "why", "those", "ideas", "matter", "to", "you."]'::jsonb),
    (activity_id_var, 'Whether philosophy affects daily decisions remains debated.', 'Whether philosophy affects daily decisions remains debated.', '["Whether", "philosophy", "affects", "daily", "decisions", "remains", "debated."]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'speaking_practice', 9, 'Discuss Philosophy', 'Practice speaking about philosophy', '{"prompts": ["Which ideas shape your worldview?", "Why do those ideas matter to you?", "How has philosophy influenced your thinking?", "What philosophical concepts guide modern society?", "How do philosophical ideas affect daily decisions?"]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (
      lesson_id,
      activity_type,
      activity_order,
      title,
      description,
      content
    ) VALUES (
      'C1-L91',
      'speaking_improvement',
      10,
      'Speaking Improvement',
      'Read the improved version of your speech',
      '{"type": "speaking_improvement", "similarityThreshold": 70}'::jsonb
    );
END $$;



-- =========================================
-- C1 Lesson 92
-- =========================================

-- =========================================
-- Pre-fill Database with Sample Lesson Data
-- C1-L92: Literature as Social Commentary
-- =========================================
DELETE FROM lesson_activity_results WHERE lesson_id = 'C1-L92';
DELETE FROM user_progress WHERE lesson_id = 'C1-L92';
DELETE FROM lesson_history WHERE lesson_id = 'C1-L92';
DELETE FROM grammar_sentences WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'C1-L92');
DELETE FROM vocabulary_items WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'C1-L92');
DELETE FROM lesson_activities WHERE lesson_id = 'C1-L92';
DELETE FROM lessons WHERE id = 'C1-L92';

INSERT INTO lessons (id, level, lesson_number, topic) VALUES
('C1-L92', 'C1', 92, 'Literature as Social Commentary')
ON CONFLICT (id) DO UPDATE SET topic = EXCLUDED.topic;

DO $$
DECLARE
    lesson_id_var TEXT := 'C1-L92';
    activity_id_var UUID;
BEGIN
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'warm_up_speaking', 1, 'Literature as Commentary', 'Discuss literature as social commentary', '{"prompt": "How does literature reflect society?"}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_intro', 2, 'Literature Vocabulary', 'Learn vocabulary about literature', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'literature', 'วรรณกรรม', NULL),
    (activity_id_var, 'commentary', 'ข้อคิดเห็น', NULL),
    (activity_id_var, 'issue', 'ประเด็น', NULL),
    (activity_id_var, 'norm', 'บรรทัดฐาน', NULL),
    (activity_id_var, 'criticism', 'การวิจารณ์', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_matching_drag', 3, 'Match Literature Words', 'Match English words with Thai meanings', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'literature', 'วรรณกรรม', NULL),
    (activity_id_var, 'commentary', 'ข้อคิดเห็น', NULL),
    (activity_id_var, 'issue', 'ประเด็น', NULL),
    (activity_id_var, 'norm', 'บรรทัดฐาน', NULL),
    (activity_id_var, 'criticism', 'การวิจารณ์', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 4, 'Complete the Sentences 1', 'Fill with the correct word', '{"text": "___ reflects society. Social ___ are explored through ___.", "blanks": [{"id": "blank1", "text": "Literature", "options": ["Literature", "Commentary", "Issue", "Norm"], "correctAnswer": "Literature"}, {"id": "blank2", "text": "issues", "options": ["issues", "literature", "commentary", "norm"], "correctAnswer": "issues"}, {"id": "blank3", "text": "literature", "options": ["literature", "commentary", "issue", "norm"], "correctAnswer": "literature"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 5, 'Complete the Sentences 2', 'Fill with the correct word', '{"text": "Literature challenges social ___. Critical ___ requires ___.", "blanks": [{"id": "blank1", "text": "norms", "options": ["norms", "literature", "commentary", "issue"], "correctAnswer": "norms"}, {"id": "blank2", "text": "reading", "options": ["reading", "literature", "commentary", "criticism"], "correctAnswer": "reading"}, {"id": "blank3", "text": "analysis", "options": ["analysis", "literature", "commentary", "criticism"], "correctAnswer": "analysis"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_explanation', 6, 'Articles: Abstract Reference', 'Learn articles with abstract nouns', '{"rules": "Articles with abstract nouns:\n- Use \"the\" when referring to a specific abstract concept: \"the literature we read\"\n- Omit article for general abstract concepts: \"literature reflects society\"\n- Use \"a/an\" when classifying: \"a form of commentary\"\n\nStylistic use:\n- \"The\" can emphasize importance: \"the ability to read critically\"\n- Zero article for broad concepts: \"literature speaks to society\"\n\nUse for:\n- General statements: \"Literature reflects society.\"\n- Specific reference: \"The literature we study challenges norms.\"\n- Classification: \"Literature is a form of social commentary.\"", "examples": ["The literature we read reflects social issues.", "Literature speaks to society through commentary.", "A form of social commentary, literature challenges norms.", "The ability to read literature critically is important.", "Literature serves as a mirror of society."]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 7, 'Build Sentences 1', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'The literature we read reflects social issues.', 'The literature we read reflects social issues.', '["The", "literature", "we", "read", "reflects", "social", "issues."]'::jsonb),
    (activity_id_var, 'Literature speaks to society through commentary.', 'Literature speaks to society through commentary.', '["Literature", "speaks", "to", "society", "through", "commentary."]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 8, 'Build Sentences 2', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'A form of social commentary, literature challenges norms.', 'A form of social commentary, literature challenges norms.', '["A", "form", "of", "social", "commentary,", "literature", "challenges", "norms."]'::jsonb),
    (activity_id_var, 'The ability to read literature critically is important.', 'The ability to read literature critically is important.', '["The", "ability", "to", "read", "literature", "critically", "is", "important."]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'speaking_practice', 9, 'Discuss Literature', 'Practice speaking about literature', '{"prompts": ["What is literature to you?", "How does literature comment on society?", "What social issues are explored through literature?", "How does literature challenge social norms?", "How do you read literature critically?"]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (
      lesson_id,
      activity_type,
      activity_order,
      title,
      description,
      content
    ) VALUES (
      'C1-L92',
      'speaking_improvement',
      10,
      'Speaking Improvement',
      'Read the improved version of your speech',
      '{"type": "speaking_improvement", "similarityThreshold": 70}'::jsonb
    );
END $$;



-- =========================================
-- C1 Lesson 93
-- =========================================

-- =========================================
-- Pre-fill Database with Sample Lesson Data
-- C1-L93: Art as Political Expression
-- =========================================
DELETE FROM lesson_activity_results WHERE lesson_id = 'C1-L93';
DELETE FROM user_progress WHERE lesson_id = 'C1-L93';
DELETE FROM lesson_history WHERE lesson_id = 'C1-L93';
DELETE FROM grammar_sentences WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'C1-L93');
DELETE FROM vocabulary_items WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'C1-L93');
DELETE FROM lesson_activities WHERE lesson_id = 'C1-L93';
DELETE FROM lessons WHERE id = 'C1-L93';

INSERT INTO lessons (id, level, lesson_number, topic) VALUES
('C1-L93', 'C1', 93, 'Art as Political Expression')
ON CONFLICT (id) DO UPDATE SET topic = EXCLUDED.topic;

DO $$
DECLARE
    lesson_id_var TEXT := 'C1-L93';
    activity_id_var UUID;
BEGIN
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'warm_up_speaking', 1, 'Art as Expression', 'Discuss art as political expression', '{"prompt": "What is it that art communicates more powerfully than words?"}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_intro', 2, 'Political Art Vocabulary', 'Learn vocabulary about political art', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'expression', 'การแสดงออก', NULL),
    (activity_id_var, 'convey', 'ถ่ายทอด', NULL),
    (activity_id_var, 'power', 'อำนาจ', NULL),
    (activity_id_var, 'interpretation', 'การตีความ', NULL),
    (activity_id_var, 'change', 'การเปลี่ยนแปลง', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_matching_drag', 3, 'Match Political Art Words', 'Match English words with Thai meanings', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'expression', 'การแสดงออก', NULL),
    (activity_id_var, 'convey', 'ถ่ายทอด', NULL),
    (activity_id_var, 'power', 'อำนาจ', NULL),
    (activity_id_var, 'interpretation', 'การตีความ', NULL),
    (activity_id_var, 'change', 'การเปลี่ยนแปลง', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 4, 'Complete the Sentences 1', 'Fill with the correct word', '{"text": "Art conveys political ___. Political ___ requires ___.", "blanks": [{"id": "blank1", "text": "ideas", "options": ["ideas", "expression", "convey", "power"], "correctAnswer": "ideas"}, {"id": "blank2", "text": "art", "options": ["art", "expression", "convey", "power"], "correctAnswer": "art"}, {"id": "blank3", "text": "interpretation", "options": ["interpretation", "expression", "convey", "power"], "correctAnswer": "interpretation"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 5, 'Complete the Sentences 2', 'Fill with the correct word', '{"text": "Art has political ___. Art plays a role in social ___.", "blanks": [{"id": "blank1", "text": "power", "options": ["power", "expression", "convey", "interpretation"], "correctAnswer": "power"}, {"id": "blank2", "text": "change", "options": ["change", "expression", "convey", "power"], "correctAnswer": "change"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_explanation', 6, 'Cleft Sentences and Emphatic Structures', 'Learn cleft sentences for emphasis', '{"rules": "Cleft sentences emphasize specific elements:\n- It-cleft: \"It is art that expresses politics powerfully.\"\n- What-cleft: \"What art communicates is more powerful than words.\"\n- Wh-cleft: \"What matters is how art conveys ideas.\"\n\nStructure:\n- It + be + emphasized element + that/who clause\n- What + verb + be + emphasized element\n\nUse for:\n- Emphasizing importance: \"It is art that expresses better than speech.\"\n- Highlighting focus: \"What art communicates is powerful.\"\n- Clarifying meaning: \"What matters is how art conveys political ideas.\"", "examples": ["It is art that expresses politics more powerfully than words.", "What art communicates is more powerful than speech.", "What matters is how art conveys political ideas.", "It is political expression that art enables.", "What art can say better than speech is profound."]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 7, 'Build Sentences 1', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'It is art that expresses politics more powerfully than words.', 'It is art that expresses politics more powerfully than words.', '["It", "is", "art", "that", "expresses", "politics", "more", "powerfully", "than", "words."]'::jsonb),
    (activity_id_var, 'What art communicates is more powerful than speech.', 'What art communicates is more powerful than speech.', '["What", "art", "communicates", "is", "more", "powerful", "than", "speech."]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 8, 'Build Sentences 2', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'What matters is how art conveys political ideas.', 'What matters is how art conveys political ideas.', '["What", "matters", "is", "how", "art", "conveys", "political", "ideas."]'::jsonb),
    (activity_id_var, 'It is political expression that art enables.', 'It is political expression that art enables.', '["It", "is", "political", "expression", "that", "art", "enables."]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'speaking_practice', 9, 'Discuss Political Art', 'Practice speaking about political art', '{"prompts": ["What is it that art expresses better than speech?", "How does art convey political ideas?", "What makes art politically powerful?", "How do you interpret political art?", "What role does art play in social change?"]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (
      lesson_id,
      activity_type,
      activity_order,
      title,
      description,
      content
    ) VALUES (
      'C1-L93',
      'speaking_improvement',
      10,
      'Speaking Improvement',
      'Read the improved version of your speech',
      '{"type": "speaking_improvement", "similarityThreshold": 70}'::jsonb
    );
END $$;



-- =========================================
-- C1 Lesson 94
-- =========================================

-- =========================================
-- Pre-fill Database with Sample Lesson Data
-- C1-L94: Role of Creativity in Learning
-- =========================================
DELETE FROM lesson_activity_results WHERE lesson_id = 'C1-L94';
DELETE FROM user_progress WHERE lesson_id = 'C1-L94';
DELETE FROM lesson_history WHERE lesson_id = 'C1-L94';
DELETE FROM grammar_sentences WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'C1-L94');
DELETE FROM vocabulary_items WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'C1-L94');
DELETE FROM lesson_activities WHERE lesson_id = 'C1-L94';
DELETE FROM lessons WHERE id = 'C1-L94';

INSERT INTO lessons (id, level, lesson_number, topic) VALUES
('C1-L94', 'C1', 94, 'Role of Creativity in Learning')
ON CONFLICT (id) DO UPDATE SET topic = EXCLUDED.topic;

DO $$
DECLARE
    lesson_id_var TEXT := 'C1-L94';
    activity_id_var UUID;
BEGIN
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'warm_up_speaking', 1, 'Creativity in Learning', 'Discuss creativity in learning', '{"prompt": "How do you incorporate creativity into your learning process?"}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_intro', 2, 'Creativity Vocabulary', 'Learn vocabulary about creativity', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'creativity', 'ความคิดสร้างสรรค์', NULL),
    (activity_id_var, 'role', 'บทบาท', NULL),
    (activity_id_var, 'strategy', 'กลยุทธ์', NULL),
    (activity_id_var, 'understanding', 'ความเข้าใจ', NULL),
    (activity_id_var, 'incorporation', 'การรวมเข้า', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_matching_drag', 3, 'Match Creativity Words', 'Match English words with Thai meanings', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'creativity', 'ความคิดสร้างสรรค์', NULL),
    (activity_id_var, 'role', 'บทบาท', NULL),
    (activity_id_var, 'strategy', 'กลยุทธ์', NULL),
    (activity_id_var, 'understanding', 'ความเข้าใจ', NULL),
    (activity_id_var, 'incorporation', 'การรวมเข้า', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 4, 'Complete the Sentences 1', 'Fill with the correct word', '{"text": "Creativity plays a key ___ in learning. Including ___ requires ___.", "blanks": [{"id": "blank1", "text": "role", "options": ["role", "creativity", "strategy", "understanding"], "correctAnswer": "role"}, {"id": "blank2", "text": "creativity", "options": ["creativity", "role", "strategy", "understanding"], "correctAnswer": "creativity"}, {"id": "blank3", "text": "effort", "options": ["effort", "creativity", "role", "strategy"], "correctAnswer": "effort"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 5, 'Complete the Sentences 2', 'Fill with the correct word', '{"text": "Creative ___ help learning. Creativity deepens ___.", "blanks": [{"id": "blank1", "text": "strategies", "options": ["strategies", "creativity", "role", "understanding"], "correctAnswer": "strategies"}, {"id": "blank2", "text": "understanding", "options": ["understanding", "creativity", "role", "strategy"], "correctAnswer": "understanding"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_explanation', 6, 'Participle Clauses', 'Learn participle clauses', '{"rules": "Participle clauses:\n- Present participle (-ing): \"Including creativity, learning improves.\"\n- Past participle (-ed): \"Shaped by creativity, learning deepens.\"\n- Perfect participle (having + past participle): \"Having incorporated creativity, learning becomes effective.\"\n\nUse for:\n- Showing simultaneous actions: \"Including creativity, you learn better.\"\n- Showing cause: \"Shaped by creativity, learning becomes engaging.\"\n- Showing time sequence: \"Having woven creativity into study, learning improves.\"", "examples": ["Including creativity in studies, learning becomes more engaging.", "Shaped by creativity, learning deepens understanding.", "Having incorporated creativity, learning becomes more effective.", "Weaving creativity into study, students learn better.", "Using creative strategies, learning improves significantly."]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 7, 'Build Sentences 1', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'Including creativity in studies, learning becomes more engaging.', 'Including creativity in studies, learning becomes more engaging.', '["Including", "creativity", "in", "studies,", "learning", "becomes", "more", "engaging."]'::jsonb),
    (activity_id_var, 'Shaped by creativity, learning deepens understanding.', 'Shaped by creativity, learning deepens understanding.', '["Shaped", "by", "creativity,", "learning", "deepens", "understanding."]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 8, 'Build Sentences 2', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'Having incorporated creativity, learning becomes more effective.', 'Having incorporated creativity, learning becomes more effective.', '["Having", "incorporated", "creativity,", "learning", "becomes", "more", "effective."]'::jsonb),
    (activity_id_var, 'Weaving creativity into study, students learn better.', 'Weaving creativity into study, students learn better.', '["Weaving", "creativity", "into", "study,", "students", "learn", "better."]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'speaking_practice', 9, 'Discuss Creativity in Learning', 'Practice speaking about creativity', '{"prompts": ["How do you include creativity in your studies?", "What role does creativity play in learning?", "How can learning be made more creative?", "What creative strategies help you learn?", "How does creativity deepen understanding?"]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (
      lesson_id,
      activity_type,
      activity_order,
      title,
      description,
      content
    ) VALUES (
      'C1-L94',
      'speaking_improvement',
      10,
      'Speaking Improvement',
      'Read the improved version of your speech',
      '{"type": "speaking_improvement", "similarityThreshold": 70}'::jsonb
    );
END $$;



-- =========================================
-- C1 Lesson 95
-- =========================================

-- =========================================
-- Pre-fill Database with Sample Lesson Data
-- C1-L95: Interdisciplinary Thinking
-- =========================================
DELETE FROM lesson_activity_results WHERE lesson_id = 'C1-L95';
DELETE FROM user_progress WHERE lesson_id = 'C1-L95';
DELETE FROM lesson_history WHERE lesson_id = 'C1-L95';
DELETE FROM grammar_sentences WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'C1-L95');
DELETE FROM vocabulary_items WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'C1-L95');
DELETE FROM lesson_activities WHERE lesson_id = 'C1-L95';
DELETE FROM lessons WHERE id = 'C1-L95';

INSERT INTO lessons (id, level, lesson_number, topic) VALUES
('C1-L95', 'C1', 95, 'Interdisciplinary Thinking')
ON CONFLICT (id) DO UPDATE SET topic = EXCLUDED.topic;

DO $$
DECLARE
    lesson_id_var TEXT := 'C1-L95';
    activity_id_var UUID;
BEGIN
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'warm_up_speaking', 1, 'Interdisciplinary Thinking', 'Discuss interdisciplinary thinking', '{"prompt": "When do academic disciplines combine most effectively?"}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_intro', 2, 'Interdisciplinary Vocabulary', 'Learn vocabulary about interdisciplinary thinking', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'discipline', 'สาขาวิชา', NULL),
    (activity_id_var, 'clash', 'การปะทะ', NULL),
    (activity_id_var, 'connection', 'การเชื่อมต่อ', NULL),
    (activity_id_var, 'benefit', 'ประโยชน์', NULL),
    (activity_id_var, 'challenge', 'ความท้าทาย', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_matching_drag', 3, 'Match Interdisciplinary Words', 'Match English words with Thai meanings', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'discipline', 'สาขาวิชา', NULL),
    (activity_id_var, 'clash', 'การปะทะ', NULL),
    (activity_id_var, 'connection', 'การเชื่อมต่อ', NULL),
    (activity_id_var, 'benefit', 'ประโยชน์', NULL),
    (activity_id_var, 'challenge', 'ความท้าทาย', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 4, 'Complete the Sentences 1', 'Fill with the correct word', '{"text": "Academic ___ can clash or blend. Making ___ requires ___.", "blanks": [{"id": "blank1", "text": "disciplines", "options": ["disciplines", "clash", "connection", "benefit"], "correctAnswer": "disciplines"}, {"id": "blank2", "text": "connections", "options": ["connections", "discipline", "clash", "benefit"], "correctAnswer": "connections"}, {"id": "blank3", "text": "effort", "options": ["effort", "discipline", "clash", "connection"], "correctAnswer": "effort"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 5, 'Complete the Sentences 2', 'Fill with the correct word', '{"text": "Interdisciplinary thinking offers ___. Combining fields creates ___.", "blanks": [{"id": "blank1", "text": "benefits", "options": ["benefits", "discipline", "clash", "connection"], "correctAnswer": "benefits"}, {"id": "blank2", "text": "challenges", "options": ["challenges", "discipline", "clash", "benefit"], "correctAnswer": "challenges"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_explanation', 6, 'Contrast Linking', 'Learn contrast linking devices', '{"rules": "Contrast linking devices:\n- \"While some disciplines clash, others blend effectively.\"\n- \"However, interdisciplinary thinking offers benefits.\"\n- \"On the other hand, combining fields creates challenges.\"\n- \"Whereas some fields conflict, others complement.\"\n\nUse for:\n- Showing contrast: \"While fields clash, they can also blend.\"\n- Balancing views: \"On one hand, disciplines differ; on the other, they complement.\"\n- Comparing: \"Whereas some fields conflict, others work together.\"", "examples": ["While some disciplines clash, others blend effectively.", "However, interdisciplinary thinking offers benefits.", "On the other hand, combining fields creates challenges.", "Whereas some fields conflict, others complement each other.", "While disciplines may clash, they work best when blended."]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 7, 'Build Sentences 1', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'While some disciplines clash, others blend effectively.', 'While some disciplines clash, others blend effectively.', '["While", "some", "disciplines", "clash,", "others", "blend", "effectively."]'::jsonb),
    (activity_id_var, 'However, interdisciplinary thinking offers benefits.', 'However, interdisciplinary thinking offers benefits.', '["However,", "interdisciplinary", "thinking", "offers", "benefits."]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 8, 'Build Sentences 2', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'On the other hand, combining fields creates challenges.', 'On the other hand, combining fields creates challenges.', '["On", "the", "other", "hand,", "combining", "fields", "creates", "challenges."]'::jsonb),
    (activity_id_var, 'Whereas some fields conflict, others complement each other.', 'Whereas some fields conflict, others complement each other.', '["Whereas", "some", "fields", "conflict,", "others", "complement", "each", "other."]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'speaking_practice', 9, 'Discuss Interdisciplinary Thinking', 'Practice speaking about interdisciplinary thinking', '{"prompts": ["When do academic fields clash?", "When do they work best together?", "How do you connect different disciplines?", "What benefits come from interdisciplinary thinking?", "What challenges arise when combining fields?"]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (
      lesson_id,
      activity_type,
      activity_order,
      title,
      description,
      content
    ) VALUES (
      'C1-L95',
      'speaking_improvement',
      10,
      'Speaking Improvement',
      'Read the improved version of your speech',
      '{"type": "speaking_improvement", "similarityThreshold": 70}'::jsonb
    );
END $$;



-- =========================================
-- C1 Lesson 96
-- =========================================

-- =========================================
-- Pre-fill Database with Sample Lesson Data
-- C1-L96: Science vs Belief Systems
-- =========================================
DELETE FROM lesson_activity_results WHERE lesson_id = 'C1-L96';
DELETE FROM user_progress WHERE lesson_id = 'C1-L96';
DELETE FROM lesson_history WHERE lesson_id = 'C1-L96';
DELETE FROM grammar_sentences WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'C1-L96');
DELETE FROM vocabulary_items WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'C1-L96');
DELETE FROM lesson_activities WHERE lesson_id = 'C1-L96';
DELETE FROM lessons WHERE id = 'C1-L96';

INSERT INTO lessons (id, level, lesson_number, topic) VALUES
('C1-L96', 'C1', 96, 'Science vs Belief Systems')
ON CONFLICT (id) DO UPDATE SET topic = EXCLUDED.topic;

DO $$
DECLARE
    lesson_id_var TEXT := 'C1-L96';
    activity_id_var UUID;
BEGIN
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'warm_up_speaking', 1, 'Science vs Belief', 'Discuss science vs belief systems', '{"prompt": "When have personal beliefs overridden evidence?"}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_intro', 2, 'Science and Belief Vocabulary', 'Learn vocabulary about science and belief', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'science', 'วิทยาศาสตร์', NULL),
    (activity_id_var, 'belief', 'ความเชื่อ', NULL),
    (activity_id_var, 'evidence', 'หลักฐาน', NULL),
    (activity_id_var, 'balance', 'ความสมดุล', NULL),
    (activity_id_var, 'worldview', 'มุมมองโลก', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_matching_drag', 3, 'Match Science and Belief Words', 'Match English words with Thai meanings', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'science', 'วิทยาศาสตร์', NULL),
    (activity_id_var, 'belief', 'ความเชื่อ', NULL),
    (activity_id_var, 'evidence', 'หลักฐาน', NULL),
    (activity_id_var, 'balance', 'ความสมดุล', NULL),
    (activity_id_var, 'worldview', 'มุมมองโลก', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 4, 'Complete the Sentences 1', 'Fill with the correct word', '{"text": "Beliefs can override ___. Balancing ___ and ___ requires ___.", "blanks": [{"id": "blank1", "text": "evidence", "options": ["evidence", "science", "belief", "balance"], "correctAnswer": "evidence"}, {"id": "blank2", "text": "science", "options": ["science", "belief", "evidence", "balance"], "correctAnswer": "science"}, {"id": "blank3", "text": "belief", "options": ["belief", "science", "evidence", "balance"], "correctAnswer": "belief"}, {"id": "blank4", "text": "thought", "options": ["thought", "science", "belief", "balance"], "correctAnswer": "thought"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 5, 'Complete the Sentences 2', 'Fill with the correct word', '{"text": "Conflicting ___ challenge ___. Reconciling ___ requires ___.", "blanks": [{"id": "blank1", "text": "worldviews", "options": ["worldviews", "science", "belief", "evidence"], "correctAnswer": "worldviews"}, {"id": "blank2", "text": "understanding", "options": ["understanding", "science", "belief", "evidence"], "correctAnswer": "understanding"}, {"id": "blank3", "text": "differences", "options": ["differences", "science", "belief", "evidence"], "correctAnswer": "differences"}, {"id": "blank4", "text": "dialogue", "options": ["dialogue", "science", "belief", "evidence"], "correctAnswer": "dialogue"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_explanation', 6, 'Inversion: Never/Little', 'Learn inversion with never and little', '{"rules": "Inversion with never/little:\n- \"Never have beliefs overridden evidence so clearly.\" (formal emphasis)\n- \"Little did I realize beliefs could override facts.\" (emphasis on surprise)\n- \"Never before had I seen such conflict.\" (past emphasis)\n\nStructure:\n- Never/Little + auxiliary + subject + verb\n- Used for emphasis and formal tone\n\nUse for:\n- Emphasizing rarity: \"Never do beliefs completely override evidence.\"\n- Formal statements: \"Little did I know beliefs could conflict with science.\"\n- Highlighting infrequency: \"Never have I seen such clear conflict.\"", "examples": ["Never have beliefs overridden evidence so clearly.", "Little did I realize beliefs could override facts.", "Never before had I seen such conflict between science and belief.", "Little do people realize how beliefs affect their response.", "Never have I witnessed such a clear override of evidence."]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 7, 'Build Sentences 1', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'Never have beliefs overridden evidence so clearly.', 'Never have beliefs overridden evidence so clearly.', '["Never", "have", "beliefs", "overridden", "evidence", "so", "clearly."]'::jsonb),
    (activity_id_var, 'Little did I realize beliefs could override facts.', 'Little did I realize beliefs could override facts.', '["Little", "did", "I", "realize", "beliefs", "could", "override", "facts."]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 8, 'Build Sentences 2', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'Never before had I seen such conflict between science and belief.', 'Never before had I seen such conflict between science and belief.', '["Never", "before", "had", "I", "seen", "such", "conflict", "between", "science", "and", "belief."]'::jsonb),
    (activity_id_var, 'Little do people realize how beliefs affect their response.', 'Little do people realize how beliefs affect their response.', '["Little", "do", "people", "realize", "how", "beliefs", "affect", "their", "response."]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'speaking_practice', 9, 'Discuss Science vs Belief', 'Practice speaking about science and belief', '{"prompts": ["When have beliefs overridden evidence?", "How did you respond in that situation?", "How do you balance science and belief?", "When do beliefs conflict with facts?", "How can different worldviews be reconciled?"]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (
      lesson_id,
      activity_type,
      activity_order,
      title,
      description,
      content
    ) VALUES (
      'C1-L96',
      'speaking_improvement',
      10,
      'Speaking Improvement',
      'Read the improved version of your speech',
      '{"type": "speaking_improvement", "similarityThreshold": 70}'::jsonb
    );
END $$;



-- =========================================
-- C1 Lesson 97
-- =========================================

-- =========================================
-- Pre-fill Database with Sample Lesson Data
-- C1-L97: Limits of Objectivity
-- =========================================
DELETE FROM lesson_activity_results WHERE lesson_id = 'C1-L97';
DELETE FROM user_progress WHERE lesson_id = 'C1-L97';
DELETE FROM lesson_history WHERE lesson_id = 'C1-L97';
DELETE FROM grammar_sentences WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'C1-L97');
DELETE FROM vocabulary_items WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'C1-L97');
DELETE FROM lesson_activities WHERE lesson_id = 'C1-L97';
DELETE FROM lessons WHERE id = 'C1-L97';

INSERT INTO lessons (id, level, lesson_number, topic) VALUES
('C1-L97', 'C1', 97, 'Limits of Objectivity')
ON CONFLICT (id) DO UPDATE SET topic = EXCLUDED.topic;

DO $$
DECLARE
    lesson_id_var TEXT := 'C1-L97';
    activity_id_var UUID;
BEGIN
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'warm_up_speaking', 1, 'Limits of Objectivity', 'Discuss limits of objectivity', '{"prompt": "How objective can research truly be?"}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_intro', 2, 'Objectivity Vocabulary', 'Learn vocabulary about objectivity', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'objectivity', 'ความเป็นกลาง', NULL),
    (activity_id_var, 'research', 'การวิจัย', NULL),
    (activity_id_var, 'limit', 'ข้อจำกัด', NULL),
    (activity_id_var, 'bias', 'อคติ', NULL),
    (activity_id_var, 'integrity', 'ความซื่อสัตย์', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_matching_drag', 3, 'Match Objectivity Words', 'Match English words with Thai meanings', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'objectivity', 'ความเป็นกลาง', NULL),
    (activity_id_var, 'research', 'การวิจัย', NULL),
    (activity_id_var, 'limit', 'ข้อจำกัด', NULL),
    (activity_id_var, 'bias', 'อคติ', NULL),
    (activity_id_var, 'integrity', 'ความซื่อสัตย์', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 4, 'Complete the Sentences 1', 'Fill with the correct word', '{"text": "Research ___ have ___. ___ can be introduced into ___.", "blanks": [{"id": "blank1", "text": "limits", "options": ["limits", "objectivity", "research", "bias"], "correctAnswer": "limits"}, {"id": "blank2", "text": "objectivity", "options": ["objectivity", "limit", "research", "bias"], "correctAnswer": "objectivity"}, {"id": "blank3", "text": "Bias", "options": ["Bias", "Objectivity", "Research", "Limit"], "correctAnswer": "Bias"}, {"id": "blank4", "text": "research", "options": ["research", "objectivity", "limit", "bias"], "correctAnswer": "research"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 5, 'Complete the Sentences 2', 'Fill with the correct word', '{"text": "Safeguards protect research ___. ___ must be checked by ___.", "blanks": [{"id": "blank1", "text": "integrity", "options": ["integrity", "objectivity", "research", "bias"], "correctAnswer": "integrity"}, {"id": "blank2", "text": "Objectivity", "options": ["Objectivity", "Research", "Bias", "Integrity"], "correctAnswer": "Objectivity"}, {"id": "blank3", "text": "peers", "options": ["peers", "objectivity", "research", "bias"], "correctAnswer": "peers"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_explanation', 6, 'Advanced Passives', 'Learn advanced passive structures', '{"rules": "Advanced passive forms:\n- \"Research must be objective.\" (necessity)\n- \"Objectivity should be checked.\" (obligation)\n- \"Bias is being introduced.\" (continuous)\n- \"Integrity has been protected.\" (perfect)\n- \"Research will be reviewed.\" (future)\n\nUse when:\n- Focus is on action, not actor: \"Objectivity must be maintained.\"\n- Actor is unknown/unimportant: \"Bias was introduced.\"\n- Formal/impersonal tone: \"It is required that research be objective.\"", "examples": ["Research must be conducted objectively.", "Objectivity should be checked by peers.", "Bias is being introduced into research.", "Integrity has been protected through safeguards.", "Research will be reviewed for objectivity."]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 7, 'Build Sentences 1', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'Research must be conducted objectively.', 'Research must be conducted objectively.', '["Research", "must", "be", "conducted", "objectively."]'::jsonb),
    (activity_id_var, 'Objectivity should be checked by peers.', 'Objectivity should be checked by peers.', '["Objectivity", "should", "be", "checked", "by", "peers."]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 8, 'Build Sentences 2', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'Bias is being introduced into research.', 'Bias is being introduced into research.', '["Bias", "is", "being", "introduced", "into", "research."]'::jsonb),
    (activity_id_var, 'Integrity has been protected through safeguards.', 'Integrity has been protected through safeguards.', '["Integrity", "has", "been", "protected", "through", "safeguards."]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'speaking_practice', 9, 'Discuss Objectivity', 'Practice speaking about objectivity', '{"prompts": ["How objective can research be?", "Who is responsible for checking objectivity?", "What limits exist in academic research?", "How are biases introduced into research?", "What safeguards protect research integrity?"]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (
      lesson_id,
      activity_type,
      activity_order,
      title,
      description,
      content
    ) VALUES (
      'C1-L97',
      'speaking_improvement',
      10,
      'Speaking Improvement',
      'Read the improved version of your speech',
      '{"type": "speaking_improvement", "similarityThreshold": 70}'::jsonb
    );
END $$;



-- =========================================
-- C1 Lesson 98
-- =========================================

-- =========================================
-- Pre-fill Database with Sample Lesson Data
-- C1-L98: Truth in the Post-truth Era
-- =========================================
DELETE FROM lesson_activity_results WHERE lesson_id = 'C1-L98';
DELETE FROM user_progress WHERE lesson_id = 'C1-L98';
DELETE FROM lesson_history WHERE lesson_id = 'C1-L98';
DELETE FROM grammar_sentences WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'C1-L98');
DELETE FROM vocabulary_items WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'C1-L98');
DELETE FROM lesson_activities WHERE lesson_id = 'C1-L98';
DELETE FROM lessons WHERE id = 'C1-L98';

INSERT INTO lessons (id, level, lesson_number, topic) VALUES
('C1-L98', 'C1', 98, 'Truth in the Post-truth Era')
ON CONFLICT (id) DO UPDATE SET topic = EXCLUDED.topic;

DO $$
DECLARE
    lesson_id_var TEXT := 'C1-L98';
    activity_id_var UUID;
BEGIN
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'warm_up_speaking', 1, 'Truth in Post-truth Era', 'Discuss truth in post-truth era', '{"prompt": "How do you judge whether information is trustworthy today?"}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_intro', 2, 'Truth Vocabulary', 'Learn vocabulary about truth', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'truth', 'ความจริง', NULL),
    (activity_id_var, 'information', 'ข้อมูล', NULL),
    (activity_id_var, 'reliability', 'ความน่าเชื่อถือ', NULL),
    (activity_id_var, 'verification', 'การตรวจสอบ', NULL),
    (activity_id_var, 'misinformation', 'ข้อมูลเท็จ', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_matching_drag', 3, 'Match Truth Words', 'Match English words with Thai meanings', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'truth', 'ความจริง', NULL),
    (activity_id_var, 'information', 'ข้อมูล', NULL),
    (activity_id_var, 'reliability', 'ความน่าเชื่อถือ', NULL),
    (activity_id_var, 'verification', 'การตรวจสอบ', NULL),
    (activity_id_var, 'misinformation', 'ข้อมูลเท็จ', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 4, 'Complete the Sentences 1', 'Fill with the correct word', '{"text": "Determining ___ requires ___. ___ of information matters.", "blanks": [{"id": "blank1", "text": "truth", "options": ["truth", "information", "reliability", "verification"], "correctAnswer": "truth"}, {"id": "blank2", "text": "judgment", "options": ["judgment", "truth", "information", "reliability"], "correctAnswer": "judgment"}, {"id": "blank3", "text": "Reliability", "options": ["Reliability", "Truth", "Information", "Verification"], "correctAnswer": "Reliability"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 5, 'Complete the Sentences 2', 'Fill with the correct word', '{"text": "___ of facts is essential. Responding to ___ requires ___.", "blanks": [{"id": "blank1", "text": "Verification", "options": ["Verification", "Truth", "Information", "Reliability"], "correctAnswer": "Verification"}, {"id": "blank2", "text": "misinformation", "options": ["misinformation", "truth", "information", "reliability"], "correctAnswer": "misinformation"}, {"id": "blank3", "text": "awareness", "options": ["awareness", "truth", "information", "reliability"], "correctAnswer": "awareness"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_explanation', 6, 'Modals: Degrees of Certainty', 'Learn modals expressing degrees of certainty', '{"rules": "Modals for degrees of certainty:\n- \"must\" (high certainty): \"This information must be true.\"\n- \"should\" (probable): \"This information should be reliable.\"\n- \"might/may\" (possible): \"This information might be accurate.\"\n- \"could\" (less certain): \"This information could be false.\"\n\nUse for:\n- Expressing confidence: \"I am certain this information is true.\"\n- Showing uncertainty: \"I am not sure if this information is reliable.\"\n- Speculating: \"This information might be trustworthy.\"", "examples": ["This information must be true given the sources.", "I should be certain that the information is reliable.", "This information might be accurate despite concerns.", "I could be wrong about the information''s truth.", "You may be confident that the information is trustworthy."]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 7, 'Build Sentences 1', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'This information must be true given the sources.', 'This information must be true given the sources.', '["This", "information", "must", "be", "true", "given", "the", "sources."]'::jsonb),
    (activity_id_var, 'I should be certain that the information is reliable.', 'I should be certain that the information is reliable.', '["I", "should", "be", "certain", "that", "the", "information", "is", "reliable."]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 8, 'Build Sentences 2', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'This information might be accurate despite concerns.', 'This information might be accurate despite concerns.', '["This", "information", "might", "be", "accurate", "despite", "concerns."]'::jsonb),
    (activity_id_var, 'You may be confident that the information is trustworthy.', 'You may be confident that the information is trustworthy.', '["You", "may", "be", "confident", "that", "the", "information", "is", "trustworthy."]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'speaking_practice', 9, 'Discuss Truth', 'Practice speaking about truth', '{"prompts": ["How do you decide what is true?", "What makes information reliable?", "How do you verify facts?", "What challenges exist in finding truth?", "How do you respond to misinformation?"]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (
      lesson_id,
      activity_type,
      activity_order,
      title,
      description,
      content
    ) VALUES (
      'C1-L98',
      'speaking_improvement',
      10,
      'Speaking Improvement',
      'Read the improved version of your speech',
      '{"type": "speaking_improvement", "similarityThreshold": 70}'::jsonb
    );
END $$;



-- =========================================
-- C1 Lesson 99
-- =========================================

-- =========================================
-- Pre-fill Database with Sample Lesson Data
-- C1-L99: Intellectual Responsibility
-- =========================================
DELETE FROM lesson_activity_results WHERE lesson_id = 'C1-L99';
DELETE FROM user_progress WHERE lesson_id = 'C1-L99';
DELETE FROM lesson_history WHERE lesson_id = 'C1-L99';
DELETE FROM grammar_sentences WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'C1-L99');
DELETE FROM vocabulary_items WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'C1-L99');
DELETE FROM lesson_activities WHERE lesson_id = 'C1-L99';
DELETE FROM lessons WHERE id = 'C1-L99';

INSERT INTO lessons (id, level, lesson_number, topic) VALUES
('C1-L99', 'C1', 99, 'Intellectual Responsibility')
ON CONFLICT (id) DO UPDATE SET topic = EXCLUDED.topic;

DO $$
DECLARE
    lesson_id_var TEXT := 'C1-L99';
    activity_id_var UUID;
BEGIN
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'warm_up_speaking', 1, 'Intellectual Responsibility', 'Discuss intellectual responsibility', '{"prompt": "If you had ignored evidence before, how might your views differ now?"}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_intro', 2, 'Intellectual Responsibility Vocabulary', 'Learn vocabulary about intellectual responsibility', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'responsibility', 'ความรับผิดชอบ', NULL),
    (activity_id_var, 'evidence', 'หลักฐาน', NULL),
    (activity_id_var, 'engagement', 'การมีส่วนร่วม', NULL),
    (activity_id_var, 'dismissal', 'การปฏิเสธ', NULL),
    (activity_id_var, 'integrity', 'ความซื่อสัตย์', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_matching_drag', 3, 'Match Intellectual Responsibility Words', 'Match English words with Thai meanings', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'responsibility', 'ความรับผิดชอบ', NULL),
    (activity_id_var, 'evidence', 'หลักฐาน', NULL),
    (activity_id_var, 'engagement', 'การมีส่วนร่วม', NULL),
    (activity_id_var, 'dismissal', 'การปฏิเสธ', NULL),
    (activity_id_var, 'integrity', 'ความซื่อสัตย์', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 4, 'Complete the Sentences 1', 'Fill with the correct word', '{"text": "Intellectual ___ requires ___. Engaging with ___ responsibly matters.", "blanks": [{"id": "blank1", "text": "responsibility", "options": ["responsibility", "evidence", "engagement", "dismissal"], "correctAnswer": "responsibility"}, {"id": "blank2", "text": "integrity", "options": ["integrity", "responsibility", "evidence", "engagement"], "correctAnswer": "integrity"}, {"id": "blank3", "text": "information", "options": ["information", "responsibility", "evidence", "engagement"], "correctAnswer": "information"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 5, 'Complete the Sentences 2', 'Fill with the correct word', '{"text": "Dismissing ___ has consequences. Maintaining ___ requires ___.", "blanks": [{"id": "blank1", "text": "evidence", "options": ["evidence", "responsibility", "engagement", "dismissal"], "correctAnswer": "evidence"}, {"id": "blank2", "text": "integrity", "options": ["integrity", "responsibility", "evidence", "engagement"], "correctAnswer": "integrity"}, {"id": "blank3", "text": "commitment", "options": ["commitment", "responsibility", "evidence", "engagement"], "correctAnswer": "commitment"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_explanation', 6, 'Mixed Conditionals', 'Learn mixed conditional structures', '{"rules": "Mixed conditionals combine different time references:\n- Mixed 2/3: \"If I had ignored facts before (past), I would be different now (present).\"\n- Mixed 3/2: \"If I had dismissed evidence (past), I would not understand this now (present).\"\n\nStructures:\n- If + past perfect, would + base form (past condition, present result)\n- If + past simple, would have + past participle (present condition, past result)\n\nUse for:\n- Hypothetical past affecting present: \"If I had ignored facts before, I would be different now.\"\n- Unreal past affecting present: \"If I had dismissed evidence, I would not have this understanding now.\"", "examples": ["If I had ignored facts before, I would be different now.", "If I had dismissed evidence, I would not understand this now.", "If I had ignored evidence earlier, I would have different views now.", "If I had not engaged with facts, I would be less informed now.", "If I had dismissed evidence, I would not have this perspective now."]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 7, 'Build Sentences 1', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'If I had ignored facts before, I would be different now.', 'If I had ignored facts before, I would be different now.', '["If", "I", "had", "ignored", "facts", "before,", "I", "would", "be", "different", "now."]'::jsonb),
    (activity_id_var, 'If I had dismissed evidence, I would not understand this now.', 'If I had dismissed evidence, I would not understand this now.', '["If", "I", "had", "dismissed", "evidence,", "I", "would", "not", "understand", "this", "now."]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 8, 'Build Sentences 2', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'If I had ignored evidence earlier, I would have different views now.', 'If I had ignored evidence earlier, I would have different views now.', '["If", "I", "had", "ignored", "evidence", "earlier,", "I", "would", "have", "different", "views", "now."]'::jsonb),
    (activity_id_var, 'If I had not engaged with facts, I would be less informed now.', 'If I had not engaged with facts, I would be less informed now.', '["If", "I", "had", "not", "engaged", "with", "facts,", "I", "would", "be", "less", "informed", "now."]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'speaking_practice', 9, 'Discuss Intellectual Responsibility', 'Practice speaking about intellectual responsibility', '{"prompts": ["If you had ignored facts before, where would you be now?", "What does intellectual responsibility mean to you?", "How do you engage responsibly with information?", "What happens when evidence is dismissed?", "How do you maintain intellectual integrity?"]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (
      lesson_id,
      activity_type,
      activity_order,
      title,
      description,
      content
    ) VALUES (
      'C1-L99',
      'speaking_improvement',
      10,
      'Speaking Improvement',
      'Read the improved version of your speech',
      '{"type": "speaking_improvement", "similarityThreshold": 70}'::jsonb
    );
END $$;



-- =========================================
-- C1 Lesson 100
-- =========================================

-- =========================================
-- Pre-fill Database with Sample Lesson Data
-- C1-L100: Shaping the Future Through Ideas
-- =========================================
DELETE FROM lesson_activity_results WHERE lesson_id = 'C1-L100';
DELETE FROM user_progress WHERE lesson_id = 'C1-L100';
DELETE FROM lesson_history WHERE lesson_id = 'C1-L100';
DELETE FROM grammar_sentences WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'C1-L100');
DELETE FROM vocabulary_items WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'C1-L100');
DELETE FROM lesson_activities WHERE lesson_id = 'C1-L100';
DELETE FROM lessons WHERE id = 'C1-L100';

INSERT INTO lessons (id, level, lesson_number, topic) VALUES
('C1-L100', 'C1', 100, 'Shaping the Future Through Ideas')
ON CONFLICT (id) DO UPDATE SET topic = EXCLUDED.topic;

DO $$
DECLARE
    lesson_id_var TEXT := 'C1-L100';
    activity_id_var UUID;
BEGIN
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'warm_up_speaking', 1, 'Shaping the Future', 'Discuss shaping the future through ideas', '{"prompt": "How will your ideas have influenced others by 2035?"}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_intro', 2, 'Future Ideas Vocabulary', 'Learn vocabulary about shaping the future', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'idea', 'ความคิด', NULL),
    (activity_id_var, 'influence', 'อิทธิพล', NULL),
    (activity_id_var, 'contribution', 'การมีส่วนร่วม', NULL),
    (activity_id_var, 'impact', 'ผลกระทบ', NULL),
    (activity_id_var, 'thinking', 'การคิด', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_matching_drag', 3, 'Match Future Ideas Words', 'Match English words with Thai meanings', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'idea', 'ความคิด', NULL),
    (activity_id_var, 'influence', 'อิทธิพล', NULL),
    (activity_id_var, 'contribution', 'การมีส่วนร่วม', NULL),
    (activity_id_var, 'impact', 'ผลกระทบ', NULL),
    (activity_id_var, 'thinking', 'การคิด', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 4, 'Complete the Sentences 1', 'Fill with the correct word', '{"text": "___ shape the future. Your ___ will have influenced others. Making an ___ requires ___.", "blanks": [{"id": "blank1", "text": "Ideas", "options": ["Ideas", "Influence", "Contribution", "Impact"], "correctAnswer": "Ideas"}, {"id": "blank2", "text": "ideas", "options": ["ideas", "influence", "contribution", "impact"], "correctAnswer": "ideas"}, {"id": "blank3", "text": "impact", "options": ["impact", "idea", "influence", "contribution"], "correctAnswer": "impact"}, {"id": "blank4", "text": "commitment", "options": ["commitment", "idea", "influence", "contribution"], "correctAnswer": "commitment"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 5, 'Complete the Sentences 2', 'Fill with the correct word', '{"text": "Contributing ___ to society matters. Future-oriented ___ shapes ___.", "blanks": [{"id": "blank1", "text": "ideas", "options": ["ideas", "influence", "contribution", "impact"], "correctAnswer": "ideas"}, {"id": "blank2", "text": "thinking", "options": ["thinking", "idea", "influence", "contribution"], "correctAnswer": "thinking"}, {"id": "blank3", "text": "outcomes", "options": ["outcomes", "idea", "influence", "contribution"], "correctAnswer": "outcomes"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_explanation', 6, 'Future-facing Perfect and Mixed Forms', 'Learn future-facing perfect and mixed forms', '{"rules": "Future-facing perfect and mixed forms:\n- Future perfect: \"By 2035, my ideas will have influenced others.\"\n- Future perfect continuous: \"By then, I will have been contributing for years.\"\n- Mixed future: \"If I contribute ideas now, they will have influenced others by 2035.\"\n\nUse for:\n- Future completion: \"By 2035, my ideas will have shaped outcomes.\"\n- Duration up to future point: \"By then, I will have been thinking about the future for decades.\"\n- Hypothetical future: \"If I share ideas now, they will have influenced others by 2035.\"", "examples": ["By 2035, my ideas will have influenced others significantly.", "By then, I will have been contributing ideas for years.", "If I share ideas now, they will have influenced others by 2035.", "By 2035, today''s ideas will have shaped the future.", "Having shared ideas, they will have influenced others by 2035."]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 7, 'Build Sentences 1', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'By 2035, my ideas will have influenced others significantly.', 'By 2035, my ideas will have influenced others significantly.', '["By", "2035,", "my", "ideas", "will", "have", "influenced", "others", "significantly."]'::jsonb),
    (activity_id_var, 'By then, I will have been contributing ideas for years.', 'By then, I will have been contributing ideas for years.', '["By", "then,", "I", "will", "have", "been", "contributing", "ideas", "for", "years."]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 8, 'Build Sentences 2', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'If I share ideas now, they will have influenced others by 2035.', 'If I share ideas now, they will have influenced others by 2035.', '["If", "I", "share", "ideas", "now,", "they", "will", "have", "influenced", "others", "by", "2035."]'::jsonb),
    (activity_id_var, 'By 2035, today''s ideas will have shaped the future.', 'By 2035, today''s ideas will have shaped the future.', '["By", "2035,", "today''s", "ideas", "will", "have", "shaped", "the", "future."]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'speaking_practice', 9, 'Discuss Shaping the Future', 'Practice speaking about shaping the future', '{"prompts": ["How will your ideas have influenced others by 2035?", "What ideas do you want to contribute to society?", "How do ideas shape the future?", "What impact do you hope to make?", "How do you participate in future-oriented thinking?"]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (
      lesson_id,
      activity_type,
      activity_order,
      title,
      description,
      content
    ) VALUES (
      'C1-L100',
      'speaking_improvement',
      10,
      'Speaking Improvement',
      'Read the improved version of your speech',
      '{"type": "speaking_improvement", "similarityThreshold": 70}'::jsonb
    );
END $$;


