-- =========================================
-- Pre-fill Database with Sample Lesson Data
-- A2-L17: Using a Smartphone
-- =========================================

DELETE FROM grammar_sentences WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'A2-L17');
DELETE FROM vocabulary_items WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'A2-L17');
DELETE FROM lesson_activities WHERE lesson_id = 'A2-L17';
DELETE FROM lessons WHERE id = 'A2-L17';

INSERT INTO lessons (id, level, lesson_number, topic) VALUES
('A2-L17', 'A2', 17, 'Using a Smartphone')
ON CONFLICT (id) DO UPDATE SET topic = EXCLUDED.topic;

DO $$
DECLARE
    lesson_id_var TEXT := 'A2-L17';
    activity_id_var UUID;
BEGIN
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'warm_up_speaking', 1, 'Phone Habits', 'Talk about phone use', '{"prompt": "What can your phone help you do every day?"}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_intro', 2, 'Smartphone Words', 'Learn phone vocabulary', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'charge', 'ชาร์จ', NULL),
    (activity_id_var, 'call', 'โทร', NULL),
    (activity_id_var, 'chat', 'แชท', NULL),
    (activity_id_var, 'update', 'อัปเดต', NULL),
    (activity_id_var, 'install', 'ติดตั้ง', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_matching_drag', 3, 'Match Phone Words', 'Match smartphone words', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'charge', 'ชาร์จ', NULL),
    (activity_id_var, 'call', 'โทร', NULL),
    (activity_id_var, 'chat', 'แชท', NULL),
    (activity_id_var, 'update', 'อัปเดต', NULL),
    (activity_id_var, 'install', 'ติดตั้ง', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 4, 'Complete the Sentences 1', 'Fill with the correct word', '{"text": "I need to ___ my phone. Can you ___ me later? We ___ in the group chat.", "blanks": [{"id": "blank1", "text": "charge", "options": ["charge", "call", "chat", "install"], "correctAnswer": "charge"}, {"id": "blank2", "text": "call", "options": ["call", "chat", "charge", "update"], "correctAnswer": "call"}, {"id": "blank3", "text": "chat", "options": ["chat", "call", "charge", "update"], "correctAnswer": "chat"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 5, 'Complete the Sentences 2', 'Fill with the correct word', '{"text": "I need to ___ the app. Please help me ___ it. When do you ___ your phone?", "blanks": [{"id": "blank1", "text": "update", "options": ["update", "install", "charge", "call"], "correctAnswer": "update"}, {"id": "blank2", "text": "install", "options": ["install", "update", "call", "chat"], "correctAnswer": "install"}, {"id": "blank3", "text": "charge", "options": ["charge", "install", "update", "call"], "correctAnswer": "charge"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_explanation', 6, 'Can for Ability', 'Talk about what your phone can do', '{"rules": "Use can to talk about ability.\n- I can call my family.\n- She can install apps.\nQuestions: Can you fix this? Short: Yes, I can. / No, I can''t.", "examples": ["I can call my family for free.", "She can install new apps easily.", "Can you charge it now?", "We can chat online.", "He can update the phone tonight."]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 7, 'Build Sentences 1', 'Arrange words', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'I can call my family', 'I can call my family.', '["I", "can", "call", "my", "family."]'::jsonb),
    (activity_id_var, 'Can you charge it now', 'Can you charge it now?', '["Can", "you", "charge", "it", "now?"]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 8, 'Build Sentences 2', 'Arrange words', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'She can install new apps easily', 'She can install new apps easily.', '["She", "can", "install", "new", "apps", "easily."]'::jsonb),
    (activity_id_var, 'We can chat online tonight', 'We can chat online tonight.', '["We", "can", "chat", "online", "tonight."]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'speaking_practice', 9, 'Talk About Smartphones', 'Practice phone abilities', '{"prompts": ["What can your phone help you do?", "Do you install many apps on your phone?", "How do you fix small phone problems?", "What apps do you use the most?", "Can you use your phone without the internet?"]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (
      lesson_id,
      activity_type,
      activity_order,
      title,
      description,
      content
    ) VALUES (
      'A2-L17',
      'speaking_improvement',
      10,
      'Speaking Improvement',
      'Read the improved version of your speech',
      '{"type": "speaking_improvement", "similarityThreshold": 70}'::jsonb
    );
END $$;

