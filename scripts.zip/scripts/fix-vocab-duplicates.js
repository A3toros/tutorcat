const { neon } = require('@neondatabase/serverless');
const fs = require('fs');
const path = require('path');

// Read from .env file manually or use environment variable
const envPath = path.join(__dirname, '..', '.env');
let databaseUrl = process.env.NEON_DATABASE_URL;

if (!databaseUrl && fs.existsSync(envPath)) {
  const envContent = fs.readFileSync(envPath, 'utf8');
  const match = envContent.match(/NEON_DATABASE_URL=(.+)/);
  if (match) {
    databaseUrl = match[1].trim();
  }
}

if (!databaseUrl) {
  console.error('NEON_DATABASE_URL not found');
  process.exit(1);
}

const sql = neon(databaseUrl);

async function fixDuplicates() {
  try {
    console.log('Finding duplicate vocabulary items...');
    
    // Find duplicates
    const duplicates = await sql`
      SELECT 
        activity_id,
        english_word,
        thai_translation,
        array_agg(id ORDER BY created_at) as ids,
        COUNT(*) as count
      FROM vocabulary_items
      GROUP BY activity_id, english_word, thai_translation
      HAVING COUNT(*) > 1
    `;
    
    console.log(`Found ${duplicates.length} sets of duplicates`);
    
    let totalDeleted = 0;
    
    for (const dup of duplicates) {
      // Keep the first one (oldest), delete the rest
      const idsToDelete = dup.ids.slice(1);
      
      console.log(`Activity ${dup.activity_id}: Keeping ${dup.ids[0]}, deleting ${idsToDelete.length} duplicates of "${dup.english_word}"`);
      
      for (const idToDelete of idsToDelete) {
        await sql`
          DELETE FROM vocabulary_items WHERE id = ${idToDelete}::uuid
        `;
        totalDeleted++;
      }
    }
    
    console.log(`\nDeleted ${totalDeleted} duplicate vocabulary items`);
    
    // Verify no more duplicates
    const remainingDuplicates = await sql`
      SELECT 
        activity_id,
        english_word,
        thai_translation,
        COUNT(*) as count
      FROM vocabulary_items
      GROUP BY activity_id, english_word, thai_translation
      HAVING COUNT(*) > 1
    `;
    
    if (remainingDuplicates.length === 0) {
      console.log('✓ All duplicates removed successfully!');
    } else {
      console.log(`⚠ Warning: ${remainingDuplicates.length} sets of duplicates still remain`);
    }
    
  } catch (error) {
    console.error('Error:', error);
    process.exit(1);
  }
}

fixDuplicates();

