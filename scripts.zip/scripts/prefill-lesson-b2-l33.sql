-- =========================================
-- Pre-fill Database with Sample Lesson Data
-- B2-L33: Communication in groups
-- =========================================

DELETE FROM grammar_sentences WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'B2-L33');
DELETE FROM vocabulary_items WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'B2-L33');
DELETE FROM lesson_activities WHERE lesson_id = 'B2-L33';
DELETE FROM lessons WHERE id = 'B2-L33';

INSERT INTO lessons (id, level, lesson_number, topic) VALUES
('B2-L33', 'B2', 33, 'Communication in groups')
ON CONFLICT (id) DO UPDATE SET topic = EXCLUDED.topic;

DO $$
DECLARE
    lesson_id_var TEXT := 'B2-L33';
    activity_id_var UUID;
BEGIN
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'warm_up_speaking', 1, 'Group Flow', 'Talk about keeping clarity', '{"prompt": "What keeps meetings so clear that no one is lost, and when do you step back?"}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_intro', 2, 'Group Comm Words', 'Key words for group communication', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'cue', 'สัญญาณ/คำใบ้', NULL),
    (activity_id_var, 'interrupt', 'ขัดจังหวะ', NULL),
    (activity_id_var, 'facilitate', 'อำนวยความสะดวก', NULL),
    (activity_id_var, 'consensus', 'ความเห็นพ้อง', NULL),
    (activity_id_var, 'clarify', 'ทำให้ชัดเจน', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_matching_drag', 3, 'Match Group Comm Words', 'Match words with meanings', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'cue', 'สัญญาณ/คำใบ้', NULL),
    (activity_id_var, 'interrupt', 'ขัดจังหวะ', NULL),
    (activity_id_var, 'facilitate', 'อำนวยความสะดวก', NULL),
    (activity_id_var, 'consensus', 'ความเห็นพ้อง', NULL),
    (activity_id_var, 'clarify', 'ทำให้ชัดเจน', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 4, 'Complete the Sentences 1', 'Fill with the correct word', '{"text": "A clear ___ helps timing. We avoid ___. We aim for ___.", "blanks": [{"id": "blank1", "text": "cue", "options": ["cue", "interruptions", "consensus", "clarify"], "correctAnswer": "cue"}, {"id": "blank2", "text": "interruptions", "options": ["interruptions", "cue", "clarify", "consensus"], "correctAnswer": "interruptions"}, {"id": "blank3", "text": "consensus", "options": ["consensus", "facilitate", "cue", "clarify"], "correctAnswer": "consensus"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 5, 'Complete the Sentences 2', 'Fill with the correct word', '{"text": "Good leads ___ and ___.", "blanks": [{"id": "blank1", "text": "facilitate", "options": ["facilitate", "interrupt", "cue", "consensus"], "correctAnswer": "facilitate"}, {"id": "blank2", "text": "clarify", "options": ["clarify", "facilitate", "interrupt", "consensus"], "correctAnswer": "clarify"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_explanation', 6, 'Reason & Result (so/such…that)', 'Show how clarity affects outcomes', '{"rules": "Use so + adj/adv + that or such + (a/an) + noun + that to connect cause and specific effect.\\n- The agenda was so clear that we finished early.\\n- It was such a calm meeting that everyone spoke.", "examples": ["The cues were so strong that no one interrupted.", "The facilitator was so organized that consensus came fast.", "It was such a confusing thread that we paused.", "Our notes were so clear that follow-ups were easy.", "The pace was such that everyone could clarify points."]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 7, 'Build Sentences 1', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'The agenda was so clear that we finished early', 'The agenda was so clear that we finished early.', '["The", "agenda", "was", "so", "clear", "that", "we", "finished", "early."]'::jsonb),
    (activity_id_var, 'It was such a calm meeting that everyone spoke', 'It was such a calm meeting that everyone spoke.', '["It", "was", "such", "a", "calm", "meeting", "that", "everyone", "spoke."]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 8, 'Build Sentences 2', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'The cues were so strong that no one interrupted', 'The cues were so strong that no one interrupted.', '["The", "cues", "were", "so", "strong", "that", "no", "one", "interrupted."]'::jsonb),
    (activity_id_var, 'Our notes were so clear that follow-ups were easy', 'Our notes were so clear that follow-ups were easy.', '["Our", "notes", "were", "so", "clear", "that", "follow-ups", "were", "easy."]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'speaking_practice', 9, 'Talk About Group Communication', 'Practice cause/effect', '{"prompts": ["What keeps meetings so clear that no one is lost?", "When do you step back to let others speak?", "How do you clarify when consensus feels stuck?"]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (
      lesson_id,
      activity_type,
      activity_order,
      title,
      description,
      content
    ) VALUES (
      'B2-L33',
      'speaking_improvement',
      10,
      'Speaking Improvement',
      'Read the improved version of your speech',
      '{"type": "speaking_improvement", "similarityThreshold": 70}'::jsonb
    );
END $$;


