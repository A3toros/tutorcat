-- =========================================
-- Pre-fill Database with Sample Lesson Data
-- C1-L5: Purpose of Higher Education
-- =========================================

DELETE FROM grammar_sentences WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'C1-L5');
DELETE FROM vocabulary_items WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'C1-L5');
DELETE FROM lesson_activities WHERE lesson_id = 'C1-L5';
DELETE FROM lessons WHERE id = 'C1-L5';

INSERT INTO lessons (id, level, lesson_number, topic) VALUES
('C1-L5', 'C1', 5, 'Purpose of Higher Education')
ON CONFLICT (id) DO UPDATE SET topic = EXCLUDED.topic;

DO $$
DECLARE
    lesson_id_var TEXT := 'C1-L5';
    activity_id_var UUID;
BEGIN
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'warm_up_speaking', 1, 'Higher Education Purpose', 'Discuss the purpose of higher education', '{"prompt": "What do you seek from higher education?"}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_intro', 2, 'Higher Education Vocabulary', 'Learn vocabulary about higher education', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'purpose', 'จุดประสงค์', NULL),
    (activity_id_var, 'pursuit', 'การแสวงหา', NULL),
    (activity_id_var, 'scholarship', 'ทุนการศึกษา', NULL),
    (activity_id_var, 'excellence', 'ความเป็นเลิศ', NULL),
    (activity_id_var, 'enlightenment', 'การให้ความรู้', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_matching_drag', 3, 'Match Higher Education Words', 'Match English words with Thai meanings', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'purpose', 'จุดประสงค์', NULL),
    (activity_id_var, 'pursuit', 'การแสวงหา', NULL),
    (activity_id_var, 'scholarship', 'ทุนการศึกษา', NULL),
    (activity_id_var, 'excellence', 'ความเป็นเลิศ', NULL),
    (activity_id_var, 'enlightenment', 'การให้ความรู้', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 4, 'Complete the Sentences 1', 'Fill with the correct word', '{"text": "The ___ of higher education is intellectual ___. Students pursue academic ___.", "blanks": [{"id": "blank1", "text": "purpose", "options": ["purpose", "pursuit", "scholarship", "excellence"], "correctAnswer": "purpose"}, {"id": "blank2", "text": "enlightenment", "options": ["enlightenment", "purpose", "pursuit", "excellence"], "correctAnswer": "enlightenment"}, {"id": "blank3", "text": "excellence", "options": ["excellence", "purpose", "pursuit", "scholarship"], "correctAnswer": "excellence"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 5, 'Complete the Sentences 2', 'Fill with the correct word', '{"text": "Academic ___ requires dedication. ___ supports student ___.", "blanks": [{"id": "blank1", "text": "pursuit", "options": ["pursuit", "purpose", "scholarship", "excellence"], "correctAnswer": "pursuit"}, {"id": "blank2", "text": "Scholarship", "options": ["Scholarship", "Purpose", "Pursuit", "Excellence"], "correctAnswer": "Scholarship"}, {"id": "blank3", "text": "pursuit", "options": ["pursuit", "purpose", "excellence", "enlightenment"], "correctAnswer": "pursuit"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_explanation', 6, 'Cleft Sentences: It-clefts', 'Learn it-cleft sentences for emphasis', '{"rules": "It-cleft sentences emphasize specific elements:\n- It-cleft: \"It is knowledge that I seek.\"\n- Structure: It + be + emphasized element + that/who clause\n\nUse for:\n- Emphasizing what you seek: \"It is enlightenment that matters.\"\n- Highlighting purpose: \"It is excellence that drives me.\"\n- Clarifying meaning: \"It is scholarship that enables pursuit.\"", "examples": ["It is enlightenment that I seek from higher education.", "It is excellence that makes higher education meaningful.", "It is scholarship that enables academic pursuit.", "It is knowledge that drives my studies.", "It is purpose that guides my education."]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 7, 'Build Sentences 1', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'It is enlightenment that I seek from higher education.', 'It is enlightenment that I seek from higher education.', '["It", "is", "enlightenment", "that", "I", "seek", "from", "higher", "education."]'::jsonb),
    (activity_id_var, 'It is excellence that makes higher education meaningful.', 'It is excellence that makes higher education meaningful.', '["It", "is", "excellence", "that", "makes", "higher", "education", "meaningful."]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 8, 'Build Sentences 2', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'It is scholarship that enables academic pursuit.', 'It is scholarship that enables academic pursuit.', '["It", "is", "scholarship", "that", "enables", "academic", "pursuit."]'::jsonb),
    (activity_id_var, 'It is purpose that guides my education.', 'It is purpose that guides my education.', '["It", "is", "purpose", "that", "guides", "my", "education."]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'speaking_practice', 9, 'Discuss Higher Education', 'Practice speaking about higher education', '{"prompts": ["What do you seek from higher education?", "What makes higher education meaningful?", "What are your main goals for university study?", "How do you measure the value of education?", "What outcomes do you expect from your studies?"]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (
      lesson_id,
      activity_type,
      activity_order,
      title,
      description,
      content
    ) VALUES (
      'C1-L5',
      'speaking_improvement',
      10,
      'Speaking Improvement',
      'Read the improved version of your speech',
      '{"type": "speaking_improvement", "similarityThreshold": 70}'::jsonb
    );
END $$;
