#!/usr/bin/env python3
"""
Generate SQL scripts for ALL A1 lessons 11-100
Following all guidelines from a1-additional-lessons-plan.md
"""

import os
import json

# Comprehensive lesson data: (num, topic, vocab_list, grammar_desc, sentences_list, prompts_list)
ALL_LESSONS = [
    # Already created: 11, 12
    # 13-20
    (13, 'Jobs and Occupations', ['teacher', 'doctor', 'student', 'nurse', 'engineer'],
     'I am a... / What do you do?',
     ['I am a teacher', 'What do you do?', 'She is a doctor', 'He works as an engineer'],
     ['What do you do?', 'What is your job?', 'Where do you work?', 'What does your friend do?', 'Do you like your job?']),
    
    (14, 'At School', ['school', 'class', 'student', 'teacher', 'book'],
     'I study... / I have class...',
     ['I study English', 'I have class today', 'I go to school', 'Where do you study?'],
     ['Where do you study?', 'What do you study?', 'What time is your class?', 'Do you like school?', 'Who is your teacher?']),
    
    (15, 'Classroom Objects', ['pen', 'pencil', 'book', 'desk', 'chair'],
     'There is... / I have...',
     ['I have a pen', 'There is a desk', 'I have a book', 'What do you have?'],
     ['What do you have?', 'Where is your book?', 'Do you have a pen?', 'What is on your desk?', 'Can I borrow your pencil?']),
    
    (16, 'At Work (Basic)', ['office', 'computer', 'meeting', 'colleague', 'work'],
     'I work at... / I work with...',
     ['I work at an office', 'I work with my colleague', 'I have a meeting', 'Where do you work?'],
     ['Where do you work?', 'What time do you work?', 'Do you like your work?', 'Who do you work with?', 'What do you do at work?']),
    
    (17, 'Colors and Shapes', ['red', 'blue', 'circle', 'square', 'big'],
     'It is [color] / This is a [shape]',
     ['It is red', 'This is a circle', 'The car is blue', 'What color is it?'],
     ['What color is it?', 'What shape is this?', 'Do you like red?', 'What is your favorite color?', 'Can you draw a circle?']),
    
    (18, 'Clothes and Accessories', ['shirt', 'pants', 'shoes', 'hat', 'bag'],
     'I wear... / I have...',
     ['I wear a shirt', 'I have new shoes', 'She wears a hat', 'What do you wear?'],
     ['What do you wear?', 'Do you have a bag?', 'What color is your shirt?', 'Where did you buy your shoes?', 'Do you like this hat?']),
    
    (19, 'Shopping Basics', ['buy', 'sell', 'shop', 'store', 'money'],
     'I want to buy... / How much...?',
     ['I want to buy a book', 'How much is it?', 'I go shopping', 'What do you want to buy?'],
     ['What do you want to buy?', 'Where do you shop?', 'How much money do you have?', 'Do you like shopping?', 'What store do you go to?']),
    
    (20, 'Prices and Money', ['price', 'cost', 'cheap', 'expensive', 'baht'],
     'It costs... / How much is...?',
     ['It costs 100 baht', 'How much is this?', 'This is expensive', 'How much does it cost?'],
     ['How much does it cost?', 'Is it cheap?', 'Do you have money?', 'What is the price?', 'Can I pay with cash?']),
]

def format_sentence_for_array(sentence):
    """Format a sentence into words_array format, handling question marks"""
    if sentence.endswith('?'):
        words = sentence.replace('?', '').split()
        words[-1] = words[-1] + '?'
    else:
        words = sentence.split()
    return '["' + '", "'.join(words) + '"]'

def create_lesson_sql(lesson_num, topic, vocab_words, grammar_desc, sentences, prompts):
    """Generate SQL content for a lesson"""
    
    # Thai translations dictionary (simplified - should be expanded)
    thai_dict = {
        'teacher': 'ครู', 'doctor': 'หมอ', 'student': 'นักเรียน', 'nurse': 'พยาบาล', 'engineer': 'วิศวกร',
        'school': 'โรงเรียน', 'class': 'ชั้นเรียน', 'book': 'หนังสือ',
        'pen': 'ปากกา', 'pencil': 'ดินสอ', 'desk': 'โต๊ะ', 'chair': 'เก้าอี้',
        'office': 'สำนักงาน', 'computer': 'คอมพิวเตอร์', 'meeting': 'การประชุม', 'colleague': 'เพื่อนร่วมงาน', 'work': 'งาน',
        'red': 'แดง', 'blue': 'น้ำเงิน', 'circle': 'วงกลม', 'square': 'สี่เหลี่ยม', 'big': 'ใหญ่',
        'shirt': 'เสื้อ', 'pants': 'กางเกง', 'shoes': 'รองเท้า', 'hat': 'หมวก', 'bag': 'กระเป๋า',
        'buy': 'ซื้อ', 'sell': 'ขาย', 'shop': 'ร้าน', 'store': 'ร้านค้า', 'money': 'เงิน',
        'price': 'ราคา', 'cost': 'ราคา', 'cheap': 'ถูก', 'expensive': 'แพง', 'baht': 'บาท'
    }
    
    v1, v2, v3, v4, v5 = vocab_words
    v1_thai = thai_dict.get(v1, 'คำแปล1')
    v2_thai = thai_dict.get(v2, 'คำแปล2')
    v3_thai = thai_dict.get(v3, 'คำแปล3')
    v4_thai = thai_dict.get(v4, 'คำแปล4')
    v5_thai = thai_dict.get(v5, 'คำแปล5')
    
    # Format sentences
    s1_words = format_sentence_for_array(sentences[0])
    s2_words = format_sentence_for_array(sentences[1])
    s3_words = format_sentence_for_array(sentences[2])
    s4 = sentences[3] if len(sentences) > 3 else sentences[0]
    s4_words = format_sentence_for_array(s4)
    s4_correct = s4 + ('?' if '?' in s4 or s4.endswith('?') else '')
    
    return f'''-- =========================================
-- Pre-fill Database with Sample Lesson Data
-- A1-L{lesson_num}: {topic}
-- =========================================

-- Clear existing sample data for A1-L{lesson_num}
DELETE FROM lesson_activity_results WHERE lesson_id = 'A1-L{lesson_num}';
DELETE FROM user_progress WHERE lesson_id = 'A1-L{lesson_num}';
DELETE FROM lesson_history WHERE lesson_id = 'A1-L{lesson_num}';
DELETE FROM grammar_sentences WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'A1-L{lesson_num}');
DELETE FROM vocabulary_items WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'A1-L{lesson_num}');
DELETE FROM lesson_activities WHERE lesson_id = 'A1-L{lesson_num}';
DELETE FROM lessons WHERE id = 'A1-L{lesson_num}';

INSERT INTO lessons (id, level, lesson_number, topic) VALUES
('A1-L{lesson_num}', 'A1', {lesson_num}, '{topic}')
ON CONFLICT (id) DO UPDATE SET topic = EXCLUDED.topic;

DO $$
DECLARE
    lesson_id_var TEXT := 'A1-L{lesson_num}';
    activity_id_var UUID;
BEGIN
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content) VALUES (lesson_id_var, 'warm_up_speaking', 1, 'Talk About {topic}', 'Introduction', '{{"prompt": "{prompts[0]}"}}'::jsonb) RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content) VALUES (lesson_id_var, 'vocabulary_intro', 2, '{topic} Words', 'Learn {topic.lower()} vocabulary', '{{}}'::jsonb) RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, '{v1}', '{v1_thai}', NULL),
    (activity_id_var, '{v2}', '{v2_thai}', NULL),
    (activity_id_var, '{v3}', '{v3_thai}', NULL),
    (activity_id_var, '{v4}', '{v4_thai}', NULL),
    (activity_id_var, '{v5}', '{v5_thai}', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content) VALUES (lesson_id_var, 'vocabulary_matching_drag', 3, 'Match Words 1', 'Match English words with Thai meanings', '{{}}'::jsonb) RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, '{v1}', '{v1_thai}', NULL),
    (activity_id_var, '{v2}', '{v2_thai}', NULL),
    (activity_id_var, '{v3}', '{v3_thai}', NULL),
    (activity_id_var, '{v4}', '{v4_thai}', NULL),
    (activity_id_var, '{v5}', '{v5_thai}', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content) VALUES (lesson_id_var, 'vocabulary_fill_blanks', 4, 'Complete the Sentences 1', 'Fill in the blanks with correct words', '{{"text": "I use ___. I have a ___. I need ___. I see ___.", "blanks": [{{"id": "blank1", "text": "{v1}", "options": ["{v1}", "book", "car", "table"], "correctAnswer": "{v1}"}}, {{"id": "blank2", "text": "{v2}", "options": ["{v2}", "chair", "door", "window"], "correctAnswer": "{v2}"}}, {{"id": "blank3", "text": "{v3}", "options": ["{v3}", "phone", "water", "tree"], "correctAnswer": "{v3}"}}, {{"id": "blank4", "text": "{v4}", "options": ["{v4}", "pen", "paper", "desk"], "correctAnswer": "{v4}"}}]}}'::jsonb) RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content) VALUES (lesson_id_var, 'vocabulary_fill_blanks', 5, 'Complete the Sentences 2', 'Fill in the blanks with correct words', '{{"text": "I like ___. I want ___. I see ___. I use ___.", "blanks": [{{"id": "blank1", "text": "{v1}", "options": ["{v1}", "car", "book", "table"], "correctAnswer": "{v1}"}}, {{"id": "blank2", "text": "{v2}", "options": ["{v2}", "chair", "door", "window"], "correctAnswer": "{v2}"}}, {{"id": "blank3", "text": "{v3}", "options": ["{v3}", "phone", "water", "tree"], "correctAnswer": "{v3}"}}, {{"id": "blank4", "text": "{v5}", "options": ["{v5}", "pen", "paper", "desk"], "correctAnswer": "{v5}"}}]}}'::jsonb) RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content) VALUES (lesson_id_var, 'grammar_explanation', 6, '{grammar_desc}', 'Learn grammar', '{{"rules": "Grammar rules for {topic.lower()}", "examples": ["{sentences[0]}", "{sentences[1]}", "{sentences[2]}"]}}'::jsonb) RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content) VALUES (lesson_id_var, 'grammar_sentences', 7, 'Build Sentences 1', 'Arrange words to make sentences', '{{}}'::jsonb) RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, '{sentences[0]}', '{sentences[0]}', '{s1_words}'::jsonb),
    (activity_id_var, '{sentences[1]}', '{sentences[1]}', '{s2_words}'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content) VALUES (lesson_id_var, 'grammar_sentences', 8, 'Build Sentences 2', 'Arrange words to make sentences', '{{}}'::jsonb) RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, '{sentences[2]}', '{sentences[2]}', '{s3_words}'::jsonb),
    (activity_id_var, '{s4}', '{s4_correct}', '{s4_words}'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content) VALUES (lesson_id_var, 'speaking_practice', 9, 'Talk About {topic}', 'Practice talking', '{{"prompts": ["{prompts[0]}", "{prompts[1]}", "{prompts[2]}", "{prompts[3]}", "{prompts[4] if len(prompts) > 4 else 'Tell me more'}"}}'::jsonb) RETURNING id INTO activity_id_var;

END $$;
'''

if __name__ == '__main__':
    # Generate lessons 13-20 (11 and 12 already created manually)
    for lesson_data in ALL_LESSONS:
        lesson_num = lesson_data[0]
        if lesson_num >= 13:  # Skip 11, 12 as they're already created
            content = create_lesson_sql(*lesson_data)
            filename = f'prefill-lesson-a1-l{lesson_num}.sql'
            with open(filename, 'w', encoding='utf-8') as f:
                f.write(content)
            print(f'Created {filename}')

