-- ===== LESSON B1-L68 =====

-- =========================================
-- Pre-fill Database with Sample Lesson Data
-- B1-L68: Comparing Housing Options
-- =========================================

DELETE FROM lesson_activity_results WHERE lesson_id = 'B1-L68';
DELETE FROM user_progress WHERE lesson_id = 'B1-L68';
DELETE FROM lesson_history WHERE lesson_id = 'B1-L68';
DELETE FROM grammar_sentences WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'B1-L68');
DELETE FROM vocabulary_items WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'B1-L68');
DELETE FROM lesson_activities WHERE lesson_id = 'B1-L68';
DELETE FROM lessons WHERE id = 'B1-L68';

INSERT INTO lessons (id, level, lesson_number, topic) VALUES
('B1-L68', 'B1', 68, 'Comparing Housing Options')
ON CONFLICT (id) DO UPDATE SET topic = EXCLUDED.topic;

DO $$
DECLARE
    lesson_id_var TEXT := 'B1-L68';
    activity_id_var UUID;
BEGIN
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'warm_up_speaking', 1, 'Housing Choices', 'Talk about different living situations', '{"prompt": "When is a place too noisy for you?"}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_intro', 2, 'Housing Quality Words', 'Learn words for describing living spaces', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'spacious', 'กว้างขวาง', NULL),
    (activity_id_var, 'noisy', 'เสียงดัง', NULL),
    (activity_id_var, 'affordable', 'ราคาไม่แพง', NULL),
    (activity_id_var, 'safe', 'ปลอดภัย', NULL),
    (activity_id_var, 'convenient', 'สะดวก', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_matching_drag', 3, 'Match Housing Words', 'Match housing quality words', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'spacious', 'กว้างขวาง', NULL),
    (activity_id_var, 'noisy', 'เสียงดัง', NULL),
    (activity_id_var, 'affordable', 'ราคาไม่แพง', NULL),
    (activity_id_var, 'safe', 'ปลอดภัย', NULL),
    (activity_id_var, 'convenient', 'สะดวก', NULL);

    -- 4. Vocabulary Fill Blanks #1
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 4, 'Complete the Sentences 1', 'Fill in the blanks with correct words', '{"text": "This apartment is very ___. The area is ___. The price is ___.", "blanks": [{"id": "blank1", "text": "spacious", "options": ["spacious", "noisy", "affordable", "safe"], "correctAnswer": "spacious"}, {"id": "blank2", "text": "safe", "options": ["safe", "noisy", "affordable", "convenient"], "correctAnswer": "safe"}, {"id": "blank3", "text": "affordable", "options": ["affordable", "spacious", "noisy", "safe"], "correctAnswer": "affordable"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    -- 5. Vocabulary Fill Blanks #2
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 5, 'Complete the Sentences 2', 'Fill in the blanks with correct words', '{"text": "The place is too ___. This location is ___. That area is not ___.", "blanks": [{"id": "blank1", "text": "noisy", "options": ["noisy", "spacious", "affordable", "safe"], "correctAnswer": "noisy"}, {"id": "blank2", "text": "convenient", "options": ["convenient", "spacious", "noisy", "safe"], "correctAnswer": "convenient"}, {"id": "blank3", "text": "safe", "options": ["safe", "convenient", "noisy", "affordable"], "correctAnswer": "safe"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    -- 6. Grammar Explanation
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_explanation', 6, 'Too and Enough Comparisons', 'Learn too/enough for comparisons', '{"rules": "Use too and enough to compare and express limits:\n\n- Too = more than needed/desired (too small, too expensive)\n- Enough = sufficient/adequate (big enough, cheap enough)\n- Too + adjective (too small, too noisy)\n- Adjective + enough (big enough, safe enough)\n- Use for to specify purpose (for us, for a family)", "examples": ["This apartment is too small for us.", "That house is big enough for a family.", "The rent is too expensive here.", "This place is safe enough for children.", "It is too noisy to sleep."]}'::jsonb)
    RETURNING id INTO activity_id_var;

    -- 7. Grammar Sentences #1
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 7, 'Build Sentences 1', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'This apartment is too small for us', 'This apartment is too small for us.', '["This", "apartment", "is", "too", "small", "for", "us."]'::jsonb),
    (activity_id_var, 'That house is big enough for a family', 'That house is big enough for a family.', '["That", "house", "is", "big", "enough", "for", "a", "family."]'::jsonb);

    -- 8. Grammar Sentences #2
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 8, 'Build Sentences 2', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'The rent is too expensive here', 'The rent is too expensive here.', '["The", "rent", "is", "too", "expensive", "here."]'::jsonb),
    (activity_id_var, 'This place is safe enough for children', 'This place is safe enough for children.', '["This", "place", "is", "safe", "enough", "for", "children."]'::jsonb);

    -- 9. Speaking Practice
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'speaking_practice', 9, 'Talk About Your Home', 'Practice talking about where you live', '{"prompts": ["How many rooms are in your house?", "Do you have a garden?", "What is your favorite room?", "Is your home too small or big enough?", "What makes a good place to live?"]}'::jsonb)
    RETURNING id INTO activity_id_var;

    -- 10. Speaking Improvement
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'speaking_improvement', 10, 'Speaking Improvement', 'Read the improved version of your speech', '{"type": "speaking_improvement", "similarityThreshold": 70}'::jsonb)
    RETURNING id INTO activity_id_var;
END $$;