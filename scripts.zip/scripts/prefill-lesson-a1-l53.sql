-- =========================================
-- Pre-fill Database with Sample Lesson Data
-- A1-L53: Meat and Fish
-- =========================================

DELETE FROM grammar_sentences WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'A1-L53');
DELETE FROM vocabulary_items WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'A1-L53');
DELETE FROM lesson_activities WHERE lesson_id = 'A1-L53';
DELETE FROM lessons WHERE id = 'A1-L53';

INSERT INTO lessons (id, level, lesson_number, topic) VALUES
('A1-L53', 'A1', 53, 'Meat and Fish')
ON CONFLICT (id) DO UPDATE SET topic = EXCLUDED.topic;

DO $$
DECLARE
    lesson_id_var TEXT := 'A1-L53';
    activity_id_var UUID;
BEGIN
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'warm_up_speaking', 1, 'Meat & Fish', 'Talk about meat and fish', '{"prompt": "Do you eat fish?"}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_intro', 2, 'Meat Words', 'Learn meat words', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'chicken', 'ไก่', NULL),
    (activity_id_var, 'beef', 'เนื้อวัว', NULL),
    (activity_id_var, 'pork', 'หมู', NULL),
    (activity_id_var, 'fish', 'ปลา', NULL),
    (activity_id_var, 'meat', 'เนื้อ', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_matching_drag', 3, 'Match Meat Words', 'Match meat words', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'chicken', 'ไก่', NULL),
    (activity_id_var, 'beef', 'เนื้อวัว', NULL),
    (activity_id_var, 'pork', 'หมู', NULL),
    (activity_id_var, 'fish', 'ปลา', NULL),
    (activity_id_var, 'meat', 'เนื้อ', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 4, 'Complete the Sentences 1', 'Fill with the correct word', '{"text": "I eat ___. I eat ___.", "blanks": [{"id": "blank1", "text": "chicken", "options": ["chicken", "beef", "pork", "fish"], "correctAnswer": "chicken"}, {"id": "blank2", "text": "fish", "options": ["fish", "pork", "beef", "meat"], "correctAnswer": "fish"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 5, 'Complete the Sentences 2', 'Fill with the correct word', '{"text": "I do not eat ___. I eat ___.", "blanks": [{"id": "blank1", "text": "pork", "options": ["pork", "fish", "beef", "meat"], "correctAnswer": "pork"}, {"id": "blank2", "text": "beef", "options": ["beef", "chicken", "pork", "meat"], "correctAnswer": "beef"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_explanation', 6, 'A/Some + Count/Uncount', 'Use a/some with food', '{"rules": "Use a/an with countable single; some for plural/uncount.\n- a fish, a chicken; some meat, some fish.\nAsk: Do you eat meat?", "examples": ["I eat a fish.", "I eat some meat.", "Do you eat meat?", "Do you eat some chicken?", "I like some fish."]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 7, 'Build Sentences 1', 'Arrange words', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'I eat a fish', 'I eat a fish.', '["I", "eat", "a", "fish."]'::jsonb),
    (activity_id_var, 'I eat some meat', 'I eat some meat.', '["I", "eat", "some", "meat."]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 8, 'Build Sentences 2', 'Arrange words', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'Do you eat meat', 'Do you eat meat?', '["Do", "you", "eat", "meat?"]'::jsonb),
    (activity_id_var, 'I like some fish', 'I like some fish.', '["I", "like", "some", "fish."]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'speaking_practice', 9, 'Talk About Meat', 'Practice food words', '{"prompts": ["Do you eat fish?", "Do you eat meat?", "Do you like chicken?", "Do you eat beef?", "Do you like pork?"]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (
      lesson_id,
      activity_type,
      activity_order,
      title,
      description,
      content
    ) VALUES (
      'A1-L53',
      'speaking_improvement',
      10,
      'Speaking Improvement',
      'Read the improved version of your speech',
      '{"type": "speaking_improvement", "similarityThreshold": 70}'::jsonb
    );
END $$;

