-- ===== LESSON B2-L88 =====

-- =========================================
-- Pre-fill Database with Sample Lesson Data
-- B2-L88: Education and personal growth
-- =========================================

DELETE FROM lesson_activity_results WHERE lesson_id = 'B2-L88';
DELETE FROM user_progress WHERE lesson_id = 'B2-L88';
DELETE FROM lesson_history WHERE lesson_id = 'B2-L88';
DELETE FROM grammar_sentences WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'B2-L88');
DELETE FROM vocabulary_items WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'B2-L88');
DELETE FROM lesson_activities WHERE lesson_id = 'B2-L88';
DELETE FROM lessons WHERE id = 'B2-L88';

INSERT INTO lessons (id, level, lesson_number, topic) VALUES
('B2-L88', 'B2', 88, 'Education and personal growth')
ON CONFLICT (id) DO UPDATE SET topic = EXCLUDED.topic;

DO $$
DECLARE
    lesson_id_var TEXT := 'B2-L88';
    activity_id_var UUID;
BEGIN
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'warm_up_speaking', 1, 'Growth Through Learning', 'Talk about how education changes us', '{"prompt": "What had you learned before you grew fastest?"}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_intro', 2, 'Growth Words', 'Learn words related to personal development', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'milestone', 'จุดสำคัญ', NULL),
    (activity_id_var, 'mentor', 'ที่ปรึกษา', NULL),
    (activity_id_var, 'feedback', 'ความคิดเห็น', NULL),
    (activity_id_var, 'reflect', 'สะท้อน', NULL),
    (activity_id_var, 'progress', 'ความก้าวหน้า', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_matching_drag', 3, 'Match Growth Words', 'Match words related to personal development', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'milestone', 'จุดสำคัญ', NULL),
    (activity_id_var, 'mentor', 'ที่ปรึกษา', NULL),
    (activity_id_var, 'feedback', 'ความคิดเห็น', NULL),
    (activity_id_var, 'reflect', 'สะท้อน', NULL),
    (activity_id_var, 'progress', 'ความก้าวหน้า', NULL);

    -- 4. Vocabulary Fill Blanks #1
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 4, 'Complete the Sentences 1', 'Fill in the blanks with correct words', '{"text": "I reached a ___. I have a ___. I got ___.", "blanks": [{"id": "blank1", "text": "milestone", "options": ["milestone", "mentor", "feedback", "reflect"], "correctAnswer": "milestone"}, {"id": "blank2", "text": "mentor", "options": ["mentor", "milestone", "feedback", "progress"], "correctAnswer": "mentor"}, {"id": "blank3", "text": "feedback", "options": ["feedback", "milestone", "mentor", "reflect"], "correctAnswer": "feedback"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    -- 5. Vocabulary Fill Blanks #2
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 5, 'Complete the Sentences 2', 'Fill in the blanks with correct words', '{"text": "I need to ___ on this. I see my ___. We make ___.", "blanks": [{"id": "blank1", "text": "reflect", "options": ["reflect", "milestone", "mentor", "feedback"], "correctAnswer": "reflect"}, {"id": "blank2", "text": "progress", "options": ["progress", "milestone", "mentor", "reflect"], "correctAnswer": "progress"}, {"id": "blank3", "text": "progress", "options": ["progress", "reflect", "milestone", "mentor"], "correctAnswer": "progress"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    -- 6. Grammar Explanation
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_explanation', 6, 'Past Perfect', 'Learn past perfect for completed actions before other past actions', '{"rules": "Use past perfect to show an action completed before another past action:\n\n- Form: had + past participle (had studied, had reflected)\n- Use when one past action happened before another\n- Often used with before/after/when\n- Shows the sequence of past events\n- The earlier action uses past perfect, the later uses past simple", "examples": ["I had studied for years before I got my degree.", "She had reflected on her experiences before making changes.", "They had received feedback before improving their skills.", "I had learned a lot before I started teaching.", "She had practiced before she succeeded."]}'::jsonb)
    RETURNING id INTO activity_id_var;

    -- 7. Grammar Sentences #1
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 7, 'Build Sentences 1', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'I had studied for years before I got my degree', 'I had studied for years before I got my degree.', '["I", "had", "studied", "for", "years", "before", "I", "got", "my", "degree."]'::jsonb),
    (activity_id_var, 'She had reflected on her experiences before making changes', 'She had reflected on her experiences before making changes.', '["She", "had", "reflected", "on", "her", "experiences", "before", "making", "changes."]'::jsonb);

    -- 8. Grammar Sentences #2
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 8, 'Build Sentences 2', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'They had received feedback before improving their skills', 'They had received feedback before improving their skills.', '["They", "had", "received", "feedback", "before", "improving", "their", "skills."]'::jsonb),
    (activity_id_var, 'I had learned a lot before I started teaching', 'I had learned a lot before I started teaching.', '["I", "had", "learned", "a", "lot", "before", "I", "started", "teaching."]'::jsonb);

    -- 9. Speaking Practice
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'speaking_practice', 9, 'Share Growth Stories', 'Practice talking about educational development', '{"prompts": ["What had you learned before you grew fastest?", "Who guided you?", "What changed?", "What milestones have you reached?", "How do you reflect on your progress?"]}'::jsonb)
    RETURNING id INTO activity_id_var;

    -- 10. Speaking Improvement
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'speaking_improvement', 10, 'Speaking Improvement', 'Read the improved version of your speech', '{"type": "speaking_improvement", "similarityThreshold": 70}'::jsonb)
    RETURNING id INTO activity_id_var;
END $$;