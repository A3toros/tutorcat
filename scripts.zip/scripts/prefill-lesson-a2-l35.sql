-- =========================================
-- Pre-fill Database with Sample Lesson Data
-- A2-L35: Buying Medicine
-- =========================================

DELETE FROM grammar_sentences WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'A2-L35');
DELETE FROM vocabulary_items WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'A2-L35');
DELETE FROM lesson_activities WHERE lesson_id = 'A2-L35';
DELETE FROM lessons WHERE id = 'A2-L35';

INSERT INTO lessons (id, level, lesson_number, topic) VALUES
('A2-L35', 'A2', 35, 'Buying Medicine')
ON CONFLICT (id) DO UPDATE SET topic = EXCLUDED.topic;

DO $$
DECLARE
    lesson_id_var TEXT := 'A2-L35';
    activity_id_var UUID;
BEGIN
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'warm_up_speaking', 1, 'Pharmacy Visit', 'Talk about buying medicine', '{"prompt": "How do you ask a pharmacist for medicine?"}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_intro', 2, 'Pharmacy Words', 'Learn pharmacy vocabulary', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'pharmacy', 'ร้านขายยา', NULL),
    (activity_id_var, 'prescription', 'ใบสั่งยา', NULL),
    (activity_id_var, 'tablet', 'เม็ด', NULL),
    (activity_id_var, 'syrup', 'ยาน้ำ', NULL),
    (activity_id_var, 'dose', 'ขนาดยา', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_matching_drag', 3, 'Match Pharmacy Words', 'Match medicine words', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'pharmacy', 'ร้านขายยา', NULL),
    (activity_id_var, 'prescription', 'ใบสั่งยา', NULL),
    (activity_id_var, 'tablet', 'เม็ด', NULL),
    (activity_id_var, 'syrup', 'ยาน้ำ', NULL),
    (activity_id_var, 'dose', 'ขนาดยา', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 4, 'Complete the Sentences 1', 'Fill with the correct word', '{"text": "I went to the ___. I need a ___. Do I take a ___ or ___?", "blanks": [{"id": "blank1", "text": "pharmacy", "options": ["pharmacy", "prescription", "tablet", "syrup"], "correctAnswer": "pharmacy"}, {"id": "blank2", "text": "prescription", "options": ["prescription", "tablet", "syrup", "dose"], "correctAnswer": "prescription"}, {"id": "blank3", "text": "tablet", "options": ["tablet", "syrup", "pharmacy", "dose"], "correctAnswer": "tablet"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 5, 'Complete the Sentences 2', 'Fill with the correct word', '{"text": "This ___ is for children. What ___ should I take? Is this a strong ___?", "blanks": [{"id": "blank1", "text": "syrup", "options": ["syrup", "tablet", "dose", "prescription"], "correctAnswer": "syrup"}, {"id": "blank2", "text": "dose", "options": ["dose", "syrup", "tablet", "pharmacy"], "correctAnswer": "dose"}, {"id": "blank3", "text": "dose", "options": ["dose", "tablet", "prescription", "syrup"], "correctAnswer": "dose"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_explanation', 6, 'Can for Permission', 'Ask politely at a pharmacy', '{"rules": "Use can to ask permission.\n- Can I get this without a prescription?\n- Can you give me a smaller dose?\nShort answers: Yes, you can. / No, you can''t.", "examples": ["Can I buy this without a prescription?", "Can you show me the dose?", "Can I take syrup instead?", "Can you repeat the instructions?", "Can you print the receipt?"]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 7, 'Build Sentences 1', 'Arrange words', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'Can I buy this without a prescription', 'Can I buy this without a prescription?', '["Can", "I", "buy", "this", "without", "a", "prescription?"]'::jsonb),
    (activity_id_var, 'Can you show me the dose', 'Can you show me the dose?', '["Can", "you", "show", "me", "the", "dose?"]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 8, 'Build Sentences 2', 'Arrange words', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'Can I take syrup instead', 'Can I take syrup instead?', '["Can", "I", "take", "syrup", "instead?"]'::jsonb),
    (activity_id_var, 'Can you repeat the instructions', 'Can you repeat the instructions?', '["Can", "you", "repeat", "the", "instructions?"]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'speaking_practice', 9, 'Talk About Medicine', 'Practice asking for medicine', '{"prompts": ["How do you ask a pharmacist for medicine?", "Can you buy medicine without a prescription?", "Do you read the instructions before using medicine?", "What medicine do you buy most often?", "Where do you usually buy medicine?"]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (
      lesson_id,
      activity_type,
      activity_order,
      title,
      description,
      content
    ) VALUES (
      'A2-L35',
      'speaking_improvement',
      10,
      'Speaking Improvement',
      'Read the improved version of your speech',
      '{"type": "speaking_improvement", "similarityThreshold": 70}'::jsonb
    );
END $$;

