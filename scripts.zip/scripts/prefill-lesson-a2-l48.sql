-- =========================================
-- Pre-fill Database with Sample Lesson Data
-- A2-L48: Feeling Relaxed
-- =========================================

DELETE FROM grammar_sentences WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'A2-L48');
DELETE FROM vocabulary_items WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'A2-L48');
DELETE FROM lesson_activities WHERE lesson_id = 'A2-L48';
DELETE FROM lessons WHERE id = 'A2-L48';

INSERT INTO lessons (id, level, lesson_number, topic) VALUES
('A2-L48', 'A2', 48, 'Feeling Relaxed')
ON CONFLICT (id) DO UPDATE SET topic = EXCLUDED.topic;

DO $$
DECLARE
    lesson_id_var TEXT := 'A2-L48';
    activity_id_var UUID;
BEGIN
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'warm_up_speaking', 1, 'Relaxing', 'Talk about relaxing places', '{"prompt": "Where do you feel more relaxed: at home or outside?"}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_intro', 2, 'Relax Words', 'Learn relaxing vocabulary', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'relax', 'ผ่อนคลาย', NULL),
    (activity_id_var, 'quiet', 'เงียบ', NULL),
    (activity_id_var, 'noisy', 'เสียงดัง', NULL),
    (activity_id_var, 'peaceful', 'สงบ', NULL),
    (activity_id_var, 'busy', 'วุ่นวาย', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_matching_drag', 3, 'Match Relax Words', 'Match relaxing words', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'relax', 'ผ่อนคลาย', NULL),
    (activity_id_var, 'quiet', 'เงียบ', NULL),
    (activity_id_var, 'noisy', 'เสียงดัง', NULL),
    (activity_id_var, 'peaceful', 'สงบ', NULL),
    (activity_id_var, 'busy', 'วุ่นวาย', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 4, 'Complete the Sentences 1', 'Fill with the correct word', '{"text": "I want to ___. A ___ place helps me. The city is ___.", "blanks": [{"id": "blank1", "text": "relax", "options": ["relax", "quiet", "peaceful", "busy"], "correctAnswer": "relax"}, {"id": "blank2", "text": "quiet", "options": ["quiet", "busy", "peaceful", "noisy"], "correctAnswer": "quiet"}, {"id": "blank3", "text": "busy", "options": ["busy", "quiet", "peaceful", "noisy"], "correctAnswer": "busy"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 5, 'Complete the Sentences 2', 'Fill with the correct word', '{"text": "I like a ___ park. My office is ___.", "blanks": [{"id": "blank1", "text": "peaceful", "options": ["peaceful", "noisy", "busy", "quiet"], "correctAnswer": "peaceful"}, {"id": "blank2", "text": "noisy", "options": ["noisy", "peaceful", "quiet", "relax"], "correctAnswer": "noisy"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_explanation', 6, 'Comparatives', 'Compare places for relaxing', '{"rules": "Use comparatives: quiet → quieter; noisy → noisier; peaceful → more peaceful; busy → busier.\nPattern: The park is quieter than the street.", "examples": ["The park is quieter than the street.", "My home is more peaceful than the office.", "This café is busier than that one.", "The city is noisier than the village.", "This room is quieter than the hall."]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 7, 'Build Sentences 1', 'Arrange words', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'The park is quieter than the street', 'The park is quieter than the street.', '["The", "park", "is", "quieter", "than", "the", "street."]'::jsonb),
    (activity_id_var, 'My home is more peaceful than the office', 'My home is more peaceful than the office.', '["My", "home", "is", "more", "peaceful", "than", "the", "office."]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 8, 'Build Sentences 2', 'Arrange words', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'This café is busier than that one', 'This café is busier than that one.', '["This", "café", "is", "busier", "than", "that", "one."]'::jsonb),
    (activity_id_var, 'The city is noisier than the village', 'The city is noisier than the village.', '["The", "city", "is", "noisier", "than", "the", "village."]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'speaking_practice', 9, 'Talk About Relaxing', 'Practice comparing relaxing places', '{"prompts": ["Where do you feel more relaxed: at home or outside?", "Is listening to music more relaxing than watching TV?", "What activities help you relax most?", "When do you feel the most relaxed during the day?", "What makes one place more relaxing than another?"]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (
      lesson_id,
      activity_type,
      activity_order,
      title,
      description,
      content
    ) VALUES (
      'A2-L48',
      'speaking_improvement',
      10,
      'Speaking Improvement',
      'Read the improved version of your speech',
      '{"type": "speaking_improvement", "similarityThreshold": 70}'::jsonb
    );
END $$;

