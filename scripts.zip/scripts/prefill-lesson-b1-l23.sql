-- =========================================
-- Pre-fill Database with Sample Lesson Data
-- B1-L23: Saving & Spending Money
-- =========================================

DELETE FROM grammar_sentences WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'B1-L23');
DELETE FROM vocabulary_items WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'B1-L23');
DELETE FROM lesson_activities WHERE lesson_id = 'B1-L23';
DELETE FROM lessons WHERE id = 'B1-L23';

INSERT INTO lessons (id, level, lesson_number, topic) VALUES
('B1-L23', 'B1', 23, 'Saving & Spending Money')
ON CONFLICT (id) DO UPDATE SET topic = EXCLUDED.topic;

DO $$
DECLARE
    lesson_id_var TEXT := 'B1-L23';
    activity_id_var UUID;
BEGIN
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'warm_up_speaking', 1, 'Money Choices', 'Talk about saving and spending decisions', '{"prompt": "What have you saved up for recently?"}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_intro', 2, 'Money Words', 'Learn vocabulary about saving and spending', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'save', 'ออม', NULL),
    (activity_id_var, 'spend', 'ใช้จ่าย', NULL),
    (activity_id_var, 'invest', 'ลงทุน', NULL),
    (activity_id_var, 'waste', 'สูญเสีย/ใช้เปลือง', NULL),
    (activity_id_var, 'goal', 'เป้าหมาย', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_matching_drag', 3, 'Match Money Words', 'Match words with meanings', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'save', 'ออม', NULL),
    (activity_id_var, 'spend', 'ใช้จ่าย', NULL),
    (activity_id_var, 'invest', 'ลงทุน', NULL),
    (activity_id_var, 'waste', 'สูญเสีย/ใช้เปลือง', NULL),
    (activity_id_var, 'goal', 'เป้าหมาย', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 4, 'Complete the Sentences 1', 'Fill with the correct word', '{"text": "I ___ a little each month. I try not to ___. I set one clear ___.", "blanks": [{"id": "blank1", "text": "save", "options": ["save", "spend", "invest", "goal"], "correctAnswer": "save"}, {"id": "blank2", "text": "waste", "options": ["waste", "spend", "invest", "save"], "correctAnswer": "waste"}, {"id": "blank3", "text": "goal", "options": ["goal", "invest", "save", "spend"], "correctAnswer": "goal"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 5, 'Complete the Sentences 2', 'Fill with the correct word', '{"text": "I ___ on essentials. I ___ small amounts. I might ___ later.", "blanks": [{"id": "blank1", "text": "spend", "options": ["spend", "save", "goal", "waste"], "correctAnswer": "spend"}, {"id": "blank2", "text": "save", "options": ["save", "invest", "spend", "waste"], "correctAnswer": "save"}, {"id": "blank3", "text": "invest", "options": ["invest", "save", "spend", "goal"], "correctAnswer": "invest"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    -- Grammar Explanation: Present Perfect (review)
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_explanation', 6, 'Present Perfect for Money Experiences', 'Use have/has + past participle for experiences and recent results', '{"rules": "Present perfect: have/has + past participle for experiences and recent results. No specific past time.\\n- I have saved for months.\\n- She has spent too much this week.\\nUse for life experience and money habits.", "examples": ["I have saved for a new laptop.", "She has spent less this month.", "They have invested in a small fund.", "We have wasted money on things we do not need.", "He has reached his savings goal."]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 7, 'Build Sentences 1', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'I have saved for a new laptop', 'I have saved for a new laptop', '["I", "have", "saved", "for", "a", "new", "laptop"]'::jsonb),
    (activity_id_var, 'She has spent less this month', 'She has spent less this month', '["She", "has", "spent", "less", "this", "month"]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 8, 'Build Sentences 2', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'They have invested in a small fund', 'They have invested in a small fund', '["They", "have", "invested", "in", "a", "small", "fund"]'::jsonb),
    (activity_id_var, 'We have wasted money on things we do not need', 'We have wasted money on things we do not need', '["We", "have", "wasted", "money", "on", "things", "we", "do", "not", "need"]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'speaking_practice', 9, 'Talk About Saving and Spending', 'Practice talking about money choices', '{"prompts": ["What have you saved up for recently?", "When did you regret spending?", "How do you decide something is worth the price?"]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (
      lesson_id,
      activity_type,
      activity_order,
      title,
      description,
      content
    ) VALUES (
      'B1-L23',
      'speaking_improvement',
      10,
      'Speaking Improvement',
      'Read the improved version of your speech',
      '{"type": "speaking_improvement", "similarityThreshold": 70}'::jsonb
    );
END $$;

