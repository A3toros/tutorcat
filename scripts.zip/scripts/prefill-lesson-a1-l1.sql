-- =========================================
-- Pre-fill Database with Sample Lesson Data
-- A1-L1: Personal Information
-- =========================================

-- Clear existing sample data for A1-L1 (optional - comment out if you want to keep existing data)
DELETE FROM grammar_sentences WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'A1-L1');
DELETE FROM vocabulary_items WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'A1-L1');
DELETE FROM lesson_activities WHERE lesson_id = 'A1-L1';
DELETE FROM lessons WHERE id = 'A1-L1';

INSERT INTO lessons (id, level, lesson_number, topic) VALUES
('A1-L1', 'A1', 1, 'Personal Information')
ON CONFLICT (id) DO UPDATE SET topic = EXCLUDED.topic;

-- A1-L1 Activities (CEFR A1: Complete structure with all required activities)
DO $$
DECLARE
    lesson_id_var TEXT := 'A1-L1';
    activity_id_var UUID;
BEGIN
    -- 1. Warm-up Speaking (1 prompt)
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content) VALUES (lesson_id_var, 'warm_up_speaking', 1, 'Introduce Yourself', 'Practice introducing yourself', '{"prompt": "Tell me your name and where you are from."}'::jsonb) RETURNING id INTO activity_id_var;

    -- 2. Vocabulary Introduction (5 words)
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content) VALUES (lesson_id_var, 'vocabulary_intro', 2, 'Personal Information Words', 'Learn words about personal information', '{"title": "Personal Information"}'::jsonb) RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'name', 'ชื่อ', NULL),
    (activity_id_var, 'age', 'อายุ', NULL),
    (activity_id_var, 'country', 'ประเทศ', NULL),
    (activity_id_var, 'city', 'เมือง', NULL),
    (activity_id_var, 'job', 'งาน', NULL);

    -- 3. Vocabulary Matching Drag #1 (5 pairs - same words)
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content) VALUES (lesson_id_var, 'vocabulary_matching_drag', 3, 'Match Words with Meanings 1', 'Match English words (left) with Thai meanings (right)', '{}'::jsonb) RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'name', 'ชื่อ', NULL),
    (activity_id_var, 'age', 'อายุ', NULL),
    (activity_id_var, 'country', 'ประเทศ', NULL),
    (activity_id_var, 'city', 'เมือง', NULL),
    (activity_id_var, 'job', 'งาน', NULL);

    -- 4. Vocabulary Fill Blanks #1 (4 words: name, age, country, city - job left out)
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content) VALUES (lesson_id_var, 'vocabulary_fill_blanks', 4, 'Complete the Sentences 1', 'Fill in the blanks with correct words', '{"text": "My ___ is John. I am 25 years old. I am from the ___ of Thailand. I live in the ___ of Bangkok.", "blanks": [{"id": "blank1", "text": "name", "options": ["name", "car", "snow", "go"], "correctAnswer": "name"}, {"id": "blank2", "text": "country", "options": ["country", "book", "water", "run"], "correctAnswer": "country"}, {"id": "blank3", "text": "city", "options": ["city", "table", "blue", "eat"], "correctAnswer": "city"}]}'::jsonb) RETURNING id INTO activity_id_var;

    -- 5. Vocabulary Fill Blanks #2 (4 words: name, age, country, job - city left out)
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content) VALUES (lesson_id_var, 'vocabulary_fill_blanks', 5, 'Complete the Sentences 2', 'Fill in the blanks with correct words', '{"text": "What is your ___? I am 30 years old. My ___ is Thailand. I work as a teacher, that is my ___.", "blanks": [{"id": "blank1", "text": "name", "options": ["name", "door", "red", "sleep"], "correctAnswer": "name"}, {"id": "blank2", "text": "country", "options": ["country", "tree", "yellow", "jump"], "correctAnswer": "country"}, {"id": "blank3", "text": "job", "options": ["job", "chair", "green", "walk"], "correctAnswer": "job"}]}'::jsonb) RETURNING id INTO activity_id_var;

    -- 4. Grammar Explanation (rules + 5 examples)
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content) VALUES (lesson_id_var, 'grammar_explanation', 6, 'Present Simple - To Be', 'Learn how to use am, is, are', '{"rules": "We use am, is, are to talk about ourselves and others.\n\n- I am\n- You are\n- He/She/It is\n- We are\n- They are", "examples": ["I am from Thailand.", "You are a student.", "He is a teacher.", "We are friends.", "They are happy."]}'::jsonb) RETURNING id INTO activity_id_var;

    -- 4. Grammar Sentences #1 (sentence builder)
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content) VALUES (lesson_id_var, 'grammar_sentences', 7, 'Build Sentences 1', 'Arrange words to make sentences', '{}'::jsonb) RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'I am from Bangkok', 'I am from Bangkok', '["I", "am", "from", "Bangkok"]'::jsonb),
    (activity_id_var, 'My name is Sarah', 'My name is Sarah', '["My", "name", "is", "Sarah"]'::jsonb);

    -- 4. Grammar Sentences #2 (sentence builder)
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content) VALUES (lesson_id_var, 'grammar_sentences', 8, 'Build Sentences 2', 'Arrange words to make sentences', '{}'::jsonb) RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'I am 25 years old', 'I am 25 years old', '["I", "am", "25", "years", "old"]'::jsonb),
    (activity_id_var, 'She is a teacher', 'She is a teacher', '["She", "is", "a", "teacher"]'::jsonb);

    -- 4. Speaking Practice (5 prompts - CEFR A1: Simple questions about personal information)
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content) VALUES (lesson_id_var, 'speaking_practice', 9, 'Talk About Yourself', 'Practice speaking about personal information', '{"prompts": ["What is your name?", "Where are you from?", "Where do you study?", "How old are you?", "What is your hobby?"]}'::jsonb) RETURNING id INTO activity_id_var;

END $$;
