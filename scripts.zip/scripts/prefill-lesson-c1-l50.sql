-- =========================================
-- Pre-fill Database with Sample Lesson Data
-- C1-L50: Ethical Responsibility of Tech Companies
-- =========================================
DELETE FROM lesson_activity_results WHERE lesson_id = 'C1-L50';
DELETE FROM user_progress WHERE lesson_id = 'C1-L50';
DELETE FROM lesson_history WHERE lesson_id = 'C1-L50';
DELETE FROM grammar_sentences WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'C1-L50');
DELETE FROM vocabulary_items WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'C1-L50');
DELETE FROM lesson_activities WHERE lesson_id = 'C1-L50';
DELETE FROM lessons WHERE id = 'C1-L50';

INSERT INTO lessons (id, level, lesson_number, topic) VALUES
('C1-L50', 'C1', 50, 'Ethical Responsibility of Tech Companies')
ON CONFLICT (id) DO UPDATE SET topic = EXCLUDED.topic;

DO $$
DECLARE
    lesson_id_var TEXT := 'C1-L50';
    activity_id_var UUID;
BEGIN
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'warm_up_speaking', 1, 'Tech Company Ethics', 'Discuss ethical responsibility of tech companies', '{"prompt": "How could tech companies have acted differently in the past?"}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_intro', 2, 'Tech Ethics Vocabulary', 'Learn vocabulary about tech company ethics', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'responsibility', 'ความรับผิดชอบ', NULL),
    (activity_id_var, 'mistake', 'ข้อผิดพลาด', NULL),
    (activity_id_var, 'regulation', 'การควบคุม', NULL),
    (activity_id_var, 'accountability', 'ความรับผิดชอบ', NULL),
    (activity_id_var, 'impact', 'ผลกระทบ', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_matching_drag', 3, 'Match Tech Ethics Words', 'Match English words with Thai meanings', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'responsibility', 'ความรับผิดชอบ', NULL),
    (activity_id_var, 'mistake', 'ข้อผิดพลาด', NULL),
    (activity_id_var, 'regulation', 'การควบคุม', NULL),
    (activity_id_var, 'accountability', 'ความรับผิดชอบ', NULL),
    (activity_id_var, 'impact', 'ผลกระทบ', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 4, 'Complete the Sentences 1', 'Fill with the correct word', '{"text": "Tech companies have ___. ___ for ___ requires ___.", "blanks": [{"id": "blank1", "text": "responsibilities", "options": ["responsibilities", "mistake", "regulation", "accountability"], "correctAnswer": "responsibilities"}, {"id": "blank2", "text": "Accountability", "options": ["Accountability", "Responsibility", "Mistake", "Regulation"], "correctAnswer": "Accountability"}, {"id": "blank3", "text": "mistakes", "options": ["mistakes", "responsibility", "regulation", "accountability"], "correctAnswer": "mistakes"}, {"id": "blank4", "text": "regulation", "options": ["regulation", "responsibility", "mistake", "accountability"], "correctAnswer": "regulation"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 5, 'Complete the Sentences 2', 'Fill with the correct word', '{"text": "Technology ___ affects society. ___ should be held accountable for ___.", "blanks": [{"id": "blank1", "text": "impact", "options": ["impact", "responsibility", "mistake", "regulation"], "correctAnswer": "impact"}, {"id": "blank2", "text": "Companies", "options": ["Companies", "Responsibility", "Mistake", "Regulation"], "correctAnswer": "Companies"}, {"id": "blank3", "text": "impact", "options": ["impact", "responsibility", "mistake", "regulation"], "correctAnswer": "impact"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_explanation', 6, 'Modals: Degrees of Certainty in the Past', 'Learn modals for past certainty', '{"rules": "Past certainty with modals:\n- \"must have + past participle\" (high certainty): \"Tech companies must have known about the impact.\"\n- \"should have + past participle\" (expected): \"Tech companies should have acted differently.\"\n- \"might have + past participle\" (possibility): \"Tech companies might have prevented harm.\"\n- \"could have + past participle\" (ability/possibility): \"Tech companies could have acted better.\"\n\nUse for:\n- Expressing certainty about past: \"Tech companies must have been aware.\"\n- Showing expectation: \"Tech companies should have been more responsible.\"\n- Speculating: \"Tech companies might have avoided mistakes.\"", "examples": ["Tech companies must have known about the potential impact.", "Tech companies should have acted more responsibly.", "Tech companies might have prevented harm if they had acted earlier.", "Tech companies could have been more ethical in their decisions.", "Tech companies must have been aware of their responsibilities."]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 7, 'Build Sentences 1', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'Tech companies must have known about the potential impact.', 'Tech companies must have known about the potential impact.', '["Tech", "companies", "must", "have", "known", "about", "the", "potential", "impact."]'::jsonb),
    (activity_id_var, 'Tech companies should have acted more responsibly.', 'Tech companies should have acted more responsibly.', '["Tech", "companies", "should", "have", "acted", "more", "responsibly."]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 8, 'Build Sentences 2', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'Tech companies might have prevented harm if they had acted earlier.', 'Tech companies might have prevented harm if they had acted earlier.', '["Tech", "companies", "might", "have", "prevented", "harm", "if", "they", "had", "acted", "earlier."]'::jsonb),
    (activity_id_var, 'Tech companies could have been more ethical in their decisions.', 'Tech companies could have been more ethical in their decisions.', '["Tech", "companies", "could", "have", "been", "more", "ethical", "in", "their", "decisions."]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'speaking_practice', 9, 'Discuss Tech Company Ethics', 'Practice speaking about tech company ethics', '{"prompts": ["How could tech companies have acted differently?", "Who pays for mistakes made by tech firms?", "What responsibilities do tech companies have?", "How should tech companies be regulated?", "Who should be accountable for technology''s impact?"]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (
      lesson_id,
      activity_type,
      activity_order,
      title,
      description,
      content
    ) VALUES (
      'C1-L50',
      'speaking_improvement',
      10,
      'Speaking Improvement',
      'Read the improved version of your speech',
      '{"type": "speaking_improvement", "similarityThreshold": 70}'::jsonb
    );
END $$;
