-- =========================================
-- Delete User Activity Results
-- WARNING: This will permanently delete all activity results for the user
-- Make sure you have a backup before running this!
-- =========================================

-- Delete all lesson_activity_results for user
DELETE FROM lesson_activity_results 
WHERE user_id = 'b20b9a1e-5633-4ed6-bd1a-fcea31cc9240';

-- Delete user_progress for this user
DELETE FROM user_progress 
WHERE user_id = 'b20b9a1e-5633-4ed6-bd1a-fcea31cc9240';

-- =========================================
-- Deletion complete
-- To restore, run: scripts/restore-lesson-activity-results.sql
-- =========================================

