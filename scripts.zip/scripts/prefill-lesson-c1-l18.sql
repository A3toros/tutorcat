-- =========================================
-- Pre-fill Database with Sample Lesson Data
-- C1-L18: Access to Education Worldwide
-- =========================================

DELETE FROM grammar_sentences WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'C1-L18');
DELETE FROM vocabulary_items WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'C1-L18');
DELETE FROM lesson_activities WHERE lesson_id = 'C1-L18';
DELETE FROM lessons WHERE id = 'C1-L18';

INSERT INTO lessons (id, level, lesson_number, topic) VALUES
('C1-L18', 'C1', 18, 'Access to Education Worldwide')
ON CONFLICT (id) DO UPDATE SET topic = EXCLUDED.topic;

DO $$
DECLARE
    lesson_id_var TEXT := 'C1-L18';
    activity_id_var UUID;
BEGIN
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'warm_up_speaking', 1, 'Education Access', 'Discuss access to education', '{"prompt": "Why do some students lack access to education?"}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_intro', 2, 'Access Vocabulary', 'Learn vocabulary about education access', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'accessibility', 'การเข้าถึง', NULL),
    (activity_id_var, 'barrier', 'อุปสรรค', NULL),
    (activity_id_var, 'opportunity', 'โอกาส', NULL),
    (activity_id_var, 'disparity', 'ความแตกต่าง', NULL),
    (activity_id_var, 'inclusion', 'การรวมเข้า', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_matching_drag', 3, 'Match Access Words', 'Match English words with Thai meanings', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'accessibility', 'การเข้าถึง', NULL),
    (activity_id_var, 'barrier', 'อุปสรรค', NULL),
    (activity_id_var, 'opportunity', 'โอกาส', NULL),
    (activity_id_var, 'disparity', 'ความแตกต่าง', NULL),
    (activity_id_var, 'inclusion', 'การรวมเข้า', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 4, 'Complete the Sentences 1', 'Fill with the correct word', '{"text": "Educational ___ faces many ___. Equal ___ requires removing obstacles.", "blanks": [{"id": "blank1", "text": "accessibility", "options": ["accessibility", "barrier", "opportunity", "disparity"], "correctAnswer": "accessibility"}, {"id": "blank2", "text": "barriers", "options": ["barriers", "accessibility", "opportunity", "disparity"], "correctAnswer": "barriers"}, {"id": "blank3", "text": "opportunity", "options": ["opportunity", "accessibility", "barrier", "inclusion"], "correctAnswer": "opportunity"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 5, 'Complete the Sentences 2', 'Fill with the correct word', '{"text": "Global ___ in education persists. True ___ requires systemic change.", "blanks": [{"id": "blank1", "text": "disparity", "options": ["disparity", "accessibility", "barrier", "opportunity"], "correctAnswer": "disparity"}, {"id": "blank2", "text": "inclusion", "options": ["inclusion", "accessibility", "barrier", "disparity"], "correctAnswer": "inclusion"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_explanation', 6, 'Inversion: Little/Rarely', 'Learn inversion with little and rarely', '{"rules": "Inversion with little/rarely:\n- \"Little do people realize...\" (formal emphasis)\n- \"Rarely do we consider...\" (emphasis on infrequency)\n- \"Seldom have we addressed...\" (past emphasis)\n\nStructure:\n- Little/Rarely/Seldom + auxiliary + subject + verb\n- Used for emphasis and formal tone\n\nUse for:\n- Emphasizing rarity: \"Rarely do we think about global access.\"\n- Formal statements: \"Little did they realize the barriers.\"\n- Highlighting infrequency: \"Seldom have opportunities been equal.\"", "examples": ["Rarely do we consider global education access.", "Little do people realize the barriers students face.", "Seldom have opportunities been distributed equally.", "Rarely is accessibility prioritized in policy.", "Little attention is paid to educational disparities."]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 7, 'Build Sentences 1', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'Rarely do we consider the barriers to education access.', 'Rarely do we consider the barriers to education access.', '["Rarely", "do", "we", "consider", "the", "barriers", "to", "education", "access."]'::jsonb),
    (activity_id_var, 'Little do people realize the global disparities in opportunity.', 'Little do people realize the global disparities in opportunity.', '["Little", "do", "people", "realize", "the", "global", "disparities", "in", "opportunity."]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 8, 'Build Sentences 2', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'Seldom have opportunities been distributed equally worldwide.', 'Seldom have opportunities been distributed equally worldwide.', '["Seldom", "have", "opportunities", "been", "distributed", "equally", "worldwide."]'::jsonb),
    (activity_id_var, 'Rarely is true inclusion achieved without systemic change.', 'Rarely is true inclusion achieved without systemic change.', '["Rarely", "is", "true", "inclusion", "achieved", "without", "systemic", "change."]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'speaking_practice', 9, 'Discuss Education Access', 'Practice speaking about access to education', '{"prompts": ["What limits access to education globally?", "How rarely is access equal across countries?", "What barriers affect disadvantaged students?", "How can access be expanded?", "What does equal opportunity require?"]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (
      lesson_id,
      activity_type,
      activity_order,
      title,
      description,
      content
    ) VALUES (
      'C1-L18',
      'speaking_improvement',
      10,
      'Speaking Improvement',
      'Read the improved version of your speech',
      '{"type": "speaking_improvement", "similarityThreshold": 70}'::jsonb
    );
END $$;
