-- =========================================
-- Pre-fill Database with Sample Lesson Data
-- A1-L23: Animals
-- =========================================

DELETE FROM grammar_sentences WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'A1-L23');
DELETE FROM vocabulary_items WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'A1-L23');
DELETE FROM lesson_activities WHERE lesson_id = 'A1-L23';
DELETE FROM lessons WHERE id = 'A1-L23';

INSERT INTO lessons (id, level, lesson_number, topic) VALUES
('A1-L23', 'A1', 23, 'Animals')
ON CONFLICT (id) DO UPDATE SET topic = EXCLUDED.topic;

DO $$
DECLARE
    lesson_id_var TEXT := 'A1-L23';
    activity_id_var UUID;
BEGIN
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'warm_up_speaking', 1, 'Pets and Animals', 'Talk about animals', '{"prompt": "Do you have a pet?"}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_intro', 2, 'Animal Words', 'Learn animal words', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'cat', 'แมว', NULL),
    (activity_id_var, 'dog', 'สุนัข', NULL),
    (activity_id_var, 'bird', 'นก', NULL),
    (activity_id_var, 'fish', 'ปลา', NULL),
    (activity_id_var, 'rabbit', 'กระต่าย', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_matching_drag', 3, 'Match Animal Words', 'Match animal words', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'cat', 'แมว', NULL),
    (activity_id_var, 'dog', 'สุนัข', NULL),
    (activity_id_var, 'bird', 'นก', NULL),
    (activity_id_var, 'fish', 'ปลา', NULL),
    (activity_id_var, 'rabbit', 'กระต่าย', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 4, 'Complete the Sentences 1', 'Fill with the correct word', '{"text": "This ___ is small. That ___ is big.", "blanks": [{"id": "blank1", "text": "cat", "options": ["cat", "dog", "bird", "fish"], "correctAnswer": "cat"}, {"id": "blank2", "text": "dog", "options": ["dog", "fish", "bird", "rabbit"], "correctAnswer": "dog"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 5, 'Complete the Sentences 2', 'Fill with the correct word', '{"text": "The ___ is in the water. The ___ can fly.", "blanks": [{"id": "blank1", "text": "fish", "options": ["fish", "cat", "dog", "rabbit"], "correctAnswer": "fish"}, {"id": "blank2", "text": "bird", "options": ["bird", "dog", "cat", "fish"], "correctAnswer": "bird"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_explanation', 6, 'Plurals + Be', 'Talk about animals', '{"rules": "Add s for many animals. Use be.\n- Cats are small.\n- Dogs are big.\nSingular: The cat is small.", "examples": ["This cat is small.", "That dog is big.", "Birds are in the tree.", "Fish are in the water.", "Rabbits are cute."]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 7, 'Build Sentences 1', 'Arrange words', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'This cat is small', 'This cat is small.', '["This", "cat", "is", "small."]'::jsonb),
    (activity_id_var, 'That dog is big', 'That dog is big.', '["That", "dog", "is", "big."]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 8, 'Build Sentences 2', 'Arrange words', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'Birds are in the tree', 'Birds are in the tree.', '["Birds", "are", "in", "the", "tree."]'::jsonb),
    (activity_id_var, 'Fish are in the water', 'Fish are in the water.', '["Fish", "are", "in", "the", "water."]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'speaking_practice', 9, 'Talk About Animals', 'Practice pets and animals', '{"prompts": ["Do you have a pet?", "Is the cat small?", "Do you like dogs?", "Can the bird fly?", "Is the fish in water?"]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (
      lesson_id,
      activity_type,
      activity_order,
      title,
      description,
      content
    ) VALUES (
      'A1-L23',
      'speaking_improvement',
      10,
      'Speaking Improvement',
      'Read the improved version of your speech',
      '{"type": "speaking_improvement", "similarityThreshold": 70}'::jsonb
    );
END $$;

