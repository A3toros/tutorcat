-- =========================================
-- Pre-fill Database with Sample Lesson Data
-- A2-L63: Work Clothes
-- =========================================

DELETE FROM grammar_sentences WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'A2-L63');
DELETE FROM vocabulary_items WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'A2-L63');
DELETE FROM lesson_activities WHERE lesson_id = 'A2-L63';
DELETE FROM lessons WHERE id = 'A2-L63';

INSERT INTO lessons (id, level, lesson_number, topic) VALUES
('A2-L63', 'A2', 63, 'Work Clothes')
ON CONFLICT (id) DO UPDATE SET topic = EXCLUDED.topic;

DO $$
DECLARE
    lesson_id_var TEXT := 'A2-L63';
    activity_id_var UUID;
BEGIN
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'warm_up_speaking', 1, 'Clothes for Work', 'Talk about work outfits', '{"prompt": "Are your work clothes comfortable?"}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_intro', 2, 'Work Clothes Words', 'Learn work clothes words', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'uniform', 'เครื่องแบบ', NULL),
    (activity_id_var, 'formal', 'เป็นทางการ', NULL),
    (activity_id_var, 'casual', 'ลำลอง', NULL),
    (activity_id_var, 'comfortable', 'สบาย', NULL),
    (activity_id_var, 'neat', 'เรียบร้อย', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_matching_drag', 3, 'Match Work Clothes Words', 'Match clothes words', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'uniform', 'เครื่องแบบ', NULL),
    (activity_id_var, 'formal', 'เป็นทางการ', NULL),
    (activity_id_var, 'casual', 'ลำลอง', NULL),
    (activity_id_var, 'comfortable', 'สบาย', NULL),
    (activity_id_var, 'neat', 'เรียบร้อย', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 4, 'Complete the Sentences 1', 'Fill with the correct word', '{"text": "I wear a ___. On Fridays we dress ___. These shoes are ___.", "blanks": [{"id": "blank1", "text": "uniform", "options": ["uniform", "casual", "comfortable", "formal"], "correctAnswer": "uniform"}, {"id": "blank2", "text": "casual", "options": ["casual", "formal", "comfortable", "neat"], "correctAnswer": "casual"}, {"id": "blank3", "text": "comfortable", "options": ["comfortable", "neat", "formal", "uniform"], "correctAnswer": "comfortable"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 5, 'Complete the Sentences 2', 'Fill with the correct word', '{"text": "Our office is ___. I like to look ___.", "blanks": [{"id": "blank1", "text": "formal", "options": ["formal", "neat", "casual", "comfortable"], "correctAnswer": "formal"}, {"id": "blank2", "text": "neat", "options": ["neat", "formal", "casual", "comfortable"], "correctAnswer": "neat"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_explanation', 6, 'Comparatives', 'Compare styles and comfort', '{"rules": "Use comparatives to compare two things.\n- comfortable → more comfortable; neat → neater; formal → more formal; casual → more casual.\nPattern: X is more comfortable than Y.", "examples": ["This shirt is more comfortable than that one.", "Formal clothes are more expensive than casual clothes.", "My uniform is neater than before.", "These shoes are more comfortable than my old pair.", "That outfit is more formal than this."]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 7, 'Build Sentences 1', 'Arrange words', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'This shirt is more comfortable than that one', 'This shirt is more comfortable than that one.', '["This", "shirt", "is", "more", "comfortable", "than", "that", "one."]'::jsonb),
    (activity_id_var, 'My uniform is neater than before', 'My uniform is neater than before.', '["My", "uniform", "is", "neater", "than", "before."]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 8, 'Build Sentences 2', 'Arrange words', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'Formal clothes are more expensive than casual clothes', 'Formal clothes are more expensive than casual clothes.', '["Formal", "clothes", "are", "more", "expensive", "than", "casual", "clothes."]'::jsonb),
    (activity_id_var, 'These shoes are more comfortable than my old pair', 'These shoes are more comfortable than my old pair.', '["These", "shoes", "are", "more", "comfortable", "than", "my", "old", "pair."]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'speaking_practice', 9, 'Talk About Work Clothes', 'Practice comparing clothes', '{"prompts": ["Are your work clothes comfortable?", "Is a uniform better than casual clothes?", "What clothes are more practical for work?", "Do you prefer formal or informal clothes?", "How do you choose the best clothes for work?"]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (
      lesson_id,
      activity_type,
      activity_order,
      title,
      description,
      content
    ) VALUES (
      'A2-L63',
      'speaking_improvement',
      10,
      'Speaking Improvement',
      'Read the improved version of your speech',
      '{"type": "speaking_improvement", "similarityThreshold": 70}'::jsonb
    );
END $$;

