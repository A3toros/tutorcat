-- =========================================
-- Pre-fill Database with Sample Lesson Data
-- B2-L50: Group projects and teamwork
-- =========================================

DELETE FROM grammar_sentences WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'B2-L50');
DELETE FROM vocabulary_items WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'B2-L50');
DELETE FROM lesson_activities WHERE lesson_id = 'B2-L50';
DELETE FROM lessons WHERE id = 'B2-L50';

INSERT INTO lessons (id, level, lesson_number, topic) VALUES
('B2-L50', 'B2', 50, 'Group projects and teamwork')
ON CONFLICT (id) DO UPDATE SET topic = EXCLUDED.topic;

DO $$
DECLARE
    lesson_id_var TEXT := 'B2-L50';
    activity_id_var UUID;
BEGIN
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'warm_up_speaking', 1, 'Roles & Rules', 'Talk about team instructions', '{"prompt": "What instructions did you get, and how do you report progress?"}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_intro', 2, 'Teamwork Words', 'Key words for projects and roles', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'assigned', 'มอบหมาย', NULL),
    (activity_id_var, 'delegated', 'มอบหมายต่อ', NULL),
    (activity_id_var, 'accountability', 'ความรับผิดชอบ', NULL),
    (activity_id_var, 'merge', 'รวม/ผสาน', NULL),
    (activity_id_var, 'deadline', 'กำหนดส่ง', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_matching_drag', 3, 'Match Teamwork Words', 'Match words with meanings', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'assigned', 'มอบหมาย', NULL),
    (activity_id_var, 'delegated', 'มอบหมายต่อ', NULL),
    (activity_id_var, 'accountability', 'ความรับผิดชอบ', NULL),
    (activity_id_var, 'merge', 'รวม/ผสาน', NULL),
    (activity_id_var, 'deadline', 'กำหนดส่ง', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 4, 'Complete the Sentences 1', 'Fill with the correct word', '{"text": "Tasks were ___. Work was ___. We keep ___.", "blanks": [{"id": "blank1", "text": "assigned", "options": ["assigned", "delegated", "merge", "deadline"], "correctAnswer": "assigned"}, {"id": "blank2", "text": "delegated", "options": ["delegated", "assigned", "accountability", "merge"], "correctAnswer": "delegated"}, {"id": "blank3", "text": "accountability", "options": ["accountability", "deadline", "merge", "assigned"], "correctAnswer": "accountability"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 5, 'Complete the Sentences 2', 'Fill with the correct word', '{"text": "We ___ drafts and meet the ___.", "blanks": [{"id": "blank1", "text": "merge", "options": ["merge", "delegate", "assign", "deadline"], "correctAnswer": "merge"}, {"id": "blank2", "text": "deadline", "options": ["deadline", "merge", "delegated", "accountability"], "correctAnswer": "deadline"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_explanation', 6, 'Reported Speech (commands)', 'Report instructions and requests', '{"rules": "Use tell/ask + object + to-infinitive for commands; not to for negatives. Backshift if needed.\\n- \"Submit by Friday\" → They told us to submit by Friday.\\n- \"Don’t overwrite the file\" → She told me not to overwrite the file.", "examples": ["They told us to merge drafts by Wednesday.", "She told me not to miss the deadline.", "The lead asked us to keep accountability updates.", "He told us to delegate tasks clearly.", "They asked me not to overwrite the main file."]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 7, 'Build Sentences 1', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'They told us to merge drafts by Wednesday', 'They told us to merge drafts by Wednesday.', '["They", "told", "us", "to", "merge", "drafts", "by", "Wednesday."]'::jsonb),
    (activity_id_var, 'She told me not to miss the deadline', 'She told me not to miss the deadline.', '["She", "told", "me", "not", "to", "miss", "the", "deadline."]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 8, 'Build Sentences 2', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'The lead asked us to keep accountability updates', 'The lead asked us to keep accountability updates.', '["The", "lead", "asked", "us", "to", "keep", "accountability", "updates."]'::jsonb),
    (activity_id_var, 'He told us to delegate tasks clearly', 'He told us to delegate tasks clearly.', '["He", "told", "us", "to", "delegate", "tasks", "clearly."]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'speaking_practice', 9, 'Talk About Teamwork Instructions', 'Practice reported commands', '{"prompts": ["What instructions did you get for the project?", "How do you report progress to the group?", "What rule helps avoid overwriting work?"]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (
      lesson_id,
      activity_type,
      activity_order,
      title,
      description,
      content
    ) VALUES (
      'B2-L50',
      'speaking_improvement',
      10,
      'Speaking Improvement',
      'Read the improved version of your speech',
      '{"type": "speaking_improvement", "similarityThreshold": 70}'::jsonb
    );
END $$;


