-- =========================================
-- Pre-fill Database with Sample Lesson Data
-- B1-L47: City vs Countryside
-- =========================================

DELETE FROM grammar_sentences WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'B1-L47');
DELETE FROM vocabulary_items WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'B1-L47');
DELETE FROM lesson_activities WHERE lesson_id = 'B1-L47';
DELETE FROM lessons WHERE id = 'B1-L47';

INSERT INTO lessons (id, level, lesson_number, topic) VALUES
('B1-L47', 'B1', 47, 'City vs Countryside')
ON CONFLICT (id) DO UPDATE SET topic = EXCLUDED.topic;

DO $$
DECLARE
    lesson_id_var TEXT := 'B1-L47';
    activity_id_var UUID;
BEGIN
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'warm_up_speaking', 1, 'City or Countryside', 'Talk about how places affect you', '{"prompt": "What were you doing last time a city felt overwhelming?"}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_intro', 2, 'Place Words', 'Learn vocabulary about city and countryside life', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'commute', 'เดินทาง', NULL),
    (activity_id_var, 'crowd', 'ฝูงชน', NULL),
    (activity_id_var, 'quiet', 'เงียบ', NULL),
    (activity_id_var, 'scenery', 'ทิวทัศน์', NULL),
    (activity_id_var, 'pace', 'จังหวะ/ความเร็วของชีวิต', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_matching_drag', 3, 'Match Place Words', 'Match words with meanings', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'commute', 'เดินทาง', NULL),
    (activity_id_var, 'crowd', 'ฝูงชน', NULL),
    (activity_id_var, 'quiet', 'เงียบ', NULL),
    (activity_id_var, 'scenery', 'ทิวทัศน์', NULL),
    (activity_id_var, 'pace', 'จังหวะ/ความเร็วของชีวิต', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 4, 'Complete the Sentences 1', 'Fill with the correct word', '{"text": "The ___ is long. The ___ is loud. I like the ___.", "blanks": [{"id": "blank1", "text": "commute", "options": ["commute", "crowd", "quiet", "scenery"], "correctAnswer": "commute"}, {"id": "blank2", "text": "crowd", "options": ["crowd", "pace", "quiet", "commute"], "correctAnswer": "crowd"}, {"id": "blank3", "text": "quiet", "options": ["quiet", "scenery", "pace", "crowd"], "correctAnswer": "quiet"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 5, 'Complete the Sentences 2', 'Fill with the correct word', '{"text": "The ___ is beautiful. The city ___ is fast. The village ___ is slow.", "blanks": [{"id": "blank1", "text": "scenery", "options": ["scenery", "pace", "crowd", "quiet"], "correctAnswer": "scenery"}, {"id": "blank2", "text": "pace", "options": ["pace", "commute", "quiet", "crowd"], "correctAnswer": "pace"}, {"id": "blank3", "text": "pace", "options": ["pace", "scenery", "commute", "crowd"], "correctAnswer": "pace"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    -- Grammar Explanation: Past Continuous (city/countryside scenes)
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_explanation', 6, 'Past Continuous for Background Scenes', 'Use was/were + verb-ing to describe what was happening in the past', '{"rules": "Past continuous: was/were + verb-ing for actions in progress, often background.\\n- I was walking through a crowd when I felt stressed.\\n- We were enjoying the scenery when it started to rain.", "examples": ["I was walking through a crowd when I felt stressed.", "We were enjoying the scenery when it started to rain.", "She was commuting when the train stopped.", "They were resting in a quiet park.", "We were moving fast when the pace slowed down."]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 7, 'Build Sentences 1', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'I was walking through a crowd when I felt stressed', 'I was walking through a crowd when I felt stressed', '["I", "was", "walking", "through", "a", "crowd", "when", "I", "felt", "stressed"]'::jsonb),
    (activity_id_var, 'We were enjoying the scenery when it started to rain', 'We were enjoying the scenery when it started to rain', '["We", "were", "enjoying", "the", "scenery", "when", "it", "started", "to", "rain"]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 8, 'Build Sentences 2', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'She was commuting when the train stopped', 'She was commuting when the train stopped', '["She", "was", "commuting", "when", "the", "train", "stopped"]'::jsonb),
    (activity_id_var, 'They were resting in a quiet park', 'They were resting in a quiet park', '["They", "were", "resting", "in", "a", "quiet", "park"]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'speaking_practice', 9, 'Talk About Places', 'Practice talking about city vs countryside experiences', '{"prompts": ["What were you doing last time a city felt overwhelming?", "How does countryside pace change how you feel?", "Where do you focus better and why?"]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (
      lesson_id,
      activity_type,
      activity_order,
      title,
      description,
      content
    ) VALUES (
      'B1-L47',
      'speaking_improvement',
      10,
      'Speaking Improvement',
      'Read the improved version of your speech',
      '{"type": "speaking_improvement", "similarityThreshold": 70}'::jsonb
    );
END $$;

