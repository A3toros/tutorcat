-- =========================================
-- Pre-fill Database with Sample Lesson Data
-- A2-L4: Work & Jobs
-- =========================================

-- Clear existing sample data for A2-L4 (optional - comment out if you want to keep existing data)
DELETE FROM grammar_sentences WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'A2-L4');
DELETE FROM vocabulary_items WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'A2-L4');
DELETE FROM lesson_activities WHERE lesson_id = 'A2-L4';
DELETE FROM lessons WHERE id = 'A2-L4';

INSERT INTO lessons (id, level, lesson_number, topic) VALUES
('A2-L4', 'A2', 4, 'Work & Jobs')
ON CONFLICT (id) DO UPDATE SET topic = EXCLUDED.topic;

DO $$
DECLARE
    lesson_id_var TEXT := 'A2-L4';
    activity_id_var UUID;
BEGIN
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content) VALUES (lesson_id_var, 'warm_up_speaking', 1, 'Job Talk', 'Talk about jobs and work', '{"prompt": "What jobs do people in your family do?"}'::jsonb) RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content) VALUES (lesson_id_var, 'vocabulary_intro', 2, 'Work Words', 'Learn work vocabulary', '{}'::jsonb) RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'office', 'สำนักงาน', NULL),
    (activity_id_var, 'factory', 'โรงงาน', NULL),
    (activity_id_var, 'teacher', 'ครู', NULL),
    (activity_id_var, 'doctor', 'หมอ', NULL),
    (activity_id_var, 'uniform', 'เครื่องแบบ', NULL);

    -- 3. Vocabulary Matching Drag #1 (5 pairs - same words)
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content) VALUES (lesson_id_var, 'vocabulary_matching_drag', 3, 'Match Work 1', 'Match English words with Thai meanings', '{}'::jsonb) RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'office', 'สำนักงาน', NULL),
    (activity_id_var, 'factory', 'โรงงาน', NULL),
    (activity_id_var, 'teacher', 'ครู', NULL),
    (activity_id_var, 'doctor', 'หมอ', NULL),
    (activity_id_var, 'uniform', 'เครื่องแบบ', NULL);


    -- 4. Vocabulary Fill Blanks #1 (4 words: office, factory, teacher, doctor - uniform left out)
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content) VALUES (lesson_id_var, 'vocabulary_fill_blanks', 4, 'Complete the Sentences 1', 'Fill in the blanks with correct words', '{"text": "My father works in an ___. They make cars in a ___. She is a ___ at school. He is a ___ at the hospital.", "blanks": [{"id": "blank1", "text": "office", "options": ["office", "factory", "teacher", "doctor"], "correctAnswer": "office"}, {"id": "blank2", "text": "factory", "options": ["office", "factory", "teacher", "doctor"], "correctAnswer": "factory"}, {"id": "blank3", "text": "teacher", "options": ["office", "factory", "teacher", "doctor"], "correctAnswer": "teacher"}, {"id": "blank4", "text": "doctor", "options": ["office", "factory", "teacher", "doctor"], "correctAnswer": "doctor"}]}'::jsonb) RETURNING id INTO activity_id_var;

    -- 4. Vocabulary Fill Blanks #2 (4 words: office, factory, teacher, uniform - doctor left out)
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content) VALUES (lesson_id_var, 'vocabulary_fill_blanks', 5, 'Complete the Sentences 2', 'Fill in the blanks with correct words', '{"text": "People work in an ___ all day. Cars come from a ___. The ___ teaches children. Nurses wear a ___ at work.", "blanks": [{"id": "blank1", "text": "office", "options": ["office", "factory", "teacher", "uniform"], "correctAnswer": "office"}, {"id": "blank2", "text": "factory", "options": ["office", "factory", "teacher", "uniform"], "correctAnswer": "factory"}, {"id": "blank3", "text": "teacher", "options": ["office", "factory", "teacher", "uniform"], "correctAnswer": "teacher"}, {"id": "blank4", "text": "uniform", "options": ["office", "factory", "teacher", "uniform"], "correctAnswer": "uniform"}]}'::jsonb) RETURNING id INTO activity_id_var;

    -- 4. Grammar Explanation (5 examples - CEFR A2: Past simple, work vocabulary)
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content) VALUES (lesson_id_var, 'grammar_explanation', 6, 'Past Simple - Work', 'Learn to talk about past work', '{"rules": "Use past simple for completed work actions:\n\n- Regular verbs: verb + ed (I worked)\n- Irregular verbs: special form (I went)\n- Questions: Did + subject + verb? (Did you work?)\n- Negative: didn''t + verb (I didn''t go)\n- Time expressions: yesterday, last week, last year", "examples": ["I worked in an office last year.", "She went to the factory yesterday.", "Did you teach English?", "We didn''t wear uniforms.", "He started a new job last month."]}'::jsonb) RETURNING id INTO activity_id_var;
    -- 4. Grammar Sentences #1
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content) VALUES (lesson_id_var, 'grammar_sentences', 7, 'Build Sentences 1', 'Arrange words to make sentences', '{}'::jsonb) RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'I worked in an office last year', 'I worked in an office last year', '["I", "worked", "in", "an", "office", "last", "year"]'::jsonb),
    (activity_id_var, 'She went to the factory yesterday', 'She went to the factory yesterday', '["She", "went", "to", "the", "factory", "yesterday"]'::jsonb);
    -- 4. Grammar Sentences #2
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content) VALUES (lesson_id_var, 'grammar_sentences', 8, 'Build Sentences 2', 'Arrange words to make sentences', '{}'::jsonb) RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'Did you teach English', 'Did you teach English?', '["Did", "you", "teach", "English?"]'::jsonb),
    (activity_id_var, 'We didn t wear uniforms', 'We didn''t wear uniforms', '["We", "didn''t", "wear", "uniforms"]'::jsonb);
    -- 4. Speaking Practice (5 prompts - CEFR A2: Work conversations)
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content) VALUES (lesson_id_var, 'speaking_practice', 9, 'Talk About Work', 'Practice talking about work', '{"prompts": ["What job does one person in your family have?", "Do you want to be a teacher or another worker?", "Have you ever visited a workplace like a factory or office?", "What uniforms do workers wear in your area?", "Where do doctors usually work?"]}'::jsonb) RETURNING id INTO activity_id_var;

END $$;
