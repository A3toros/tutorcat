-- =========================================
-- Pre-fill Database with Sample Lesson Data
-- A1-L52: Left and Right
-- =========================================

DELETE FROM grammar_sentences WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'A1-L52');
DELETE FROM vocabulary_items WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'A1-L52');
DELETE FROM lesson_activities WHERE lesson_id = 'A1-L52';
DELETE FROM lessons WHERE id = 'A1-L52';

INSERT INTO lessons (id, level, lesson_number, topic) VALUES
('A1-L52', 'A1', 52, 'Left and Right')
ON CONFLICT (id) DO UPDATE SET topic = EXCLUDED.topic;

DO $$
DECLARE
    lesson_id_var TEXT := 'A1-L52';
    activity_id_var UUID;
BEGIN
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'warm_up_speaking', 1, 'Left or Right', 'Talk about directions', '{"prompt": "Turn left or right?"}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_intro', 2, 'Direction Words', 'Learn left/right words', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'left', 'ซ้าย', NULL),
    (activity_id_var, 'right', 'ขวา', NULL),
    (activity_id_var, 'stop', 'หยุด', NULL),
    (activity_id_var, 'turn', 'เลี้ยว', NULL),
    (activity_id_var, 'walk', 'เดิน', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_matching_drag', 3, 'Match Direction Words', 'Match direction words', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'left', 'ซ้าย', NULL),
    (activity_id_var, 'right', 'ขวา', NULL),
    (activity_id_var, 'stop', 'หยุด', NULL),
    (activity_id_var, 'turn', 'เลี้ยว', NULL),
    (activity_id_var, 'walk', 'เดิน', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 4, 'Complete the Sentences 1', 'Fill with the correct word', '{"text": "__ left. __ right.", "blanks": [{"id": "blank1", "text": "Turn", "options": ["Turn", "Go", "Walk", "Stop"], "correctAnswer": "Turn"}, {"id": "blank2", "text": "Turn", "options": ["Turn", "Walk", "Stop", "Go"], "correctAnswer": "Turn"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 5, 'Complete the Sentences 2', 'Fill with the correct word', '{"text": "__ and __. Do not __.", "blanks": [{"id": "blank1", "text": "Walk", "options": ["Walk", "Stop", "Left", "Right"], "correctAnswer": "Walk"}, {"id": "blank2", "text": "stop", "options": ["stop", "walk", "left", "right"], "correctAnswer": "stop"}, {"id": "blank3", "text": "run", "options": ["run", "turn", "stop", "walk"], "correctAnswer": "run"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_explanation', 6, 'Imperatives (directions)', 'Give simple direction commands', '{"rules": "Use base verb to give directions.\n- Turn left. Turn right. Walk and stop.\nAdd please for polite tone.", "examples": ["Turn left here.", "Turn right at the gate.", "Walk and stop there.", "Do not run.", "Go slowly, please."]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 7, 'Build Sentences 1', 'Arrange words', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'Turn left here', 'Turn left here.', '["Turn", "left", "here."]'::jsonb),
    (activity_id_var, 'Turn right at the gate', 'Turn right at the gate.', '["Turn", "right", "at", "the", "gate."]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 8, 'Build Sentences 2', 'Arrange words', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'Walk and stop there', 'Walk and stop there.', '["Walk", "and", "stop", "there."]'::jsonb),
    (activity_id_var, 'Do not run', 'Do not run.', '["Do", "not", "run."]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'speaking_practice', 9, 'Talk About Left/Right', 'Practice giving directions', '{"prompts": ["Turn left or right?", "Do I stop here?", "Do I walk straight?", "Do you run or walk?", "Do you turn at the gate?"]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (
      lesson_id,
      activity_type,
      activity_order,
      title,
      description,
      content
    ) VALUES (
      'A1-L52',
      'speaking_improvement',
      10,
      'Speaking Improvement',
      'Read the improved version of your speech',
      '{"type": "speaking_improvement", "similarityThreshold": 70}'::jsonb
    );
END $$;

