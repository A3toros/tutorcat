-- =========================================
-- Pre-fill Database with Sample Lesson Data
-- B1-L41: Making Decisions
-- =========================================

DELETE FROM grammar_sentences WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'B1-L41');
DELETE FROM vocabulary_items WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'B1-L41');
DELETE FROM lesson_activities WHERE lesson_id = 'B1-L41';
DELETE FROM lessons WHERE id = 'B1-L41';

INSERT INTO lessons (id, level, lesson_number, topic) VALUES
('B1-L41', 'B1', 41, 'Making Decisions')
ON CONFLICT (id) DO UPDATE SET topic = EXCLUDED.topic;

DO $$
DECLARE
    lesson_id_var TEXT := 'B1-L41';
    activity_id_var UUID;
BEGIN
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'warm_up_speaking', 1, 'Deciding Under Pressure', 'Talk about making choices', '{"prompt": "How do you decide when you are under pressure?"}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_intro', 2, 'Decision Words', 'Learn vocabulary about making decisions', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'decide', 'ตัดสินใจ', NULL),
    (activity_id_var, 'choose', 'เลือก', NULL),
    (activity_id_var, 'weigh', 'ชั่งน้ำหนัก', NULL),
    (activity_id_var, 'risk', 'ความเสี่ยง', NULL),
    (activity_id_var, 'option', 'ทางเลือก', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_matching_drag', 3, 'Match Decision Words', 'Match words with meanings', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'decide', 'ตัดสินใจ', NULL),
    (activity_id_var, 'choose', 'เลือก', NULL),
    (activity_id_var, 'weigh', 'ชั่งน้ำหนัก', NULL),
    (activity_id_var, 'risk', 'ความเสี่ยง', NULL),
    (activity_id_var, 'option', 'ทางเลือก', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 4, 'Complete the Sentences 1', 'Fill with the correct word', '{"text": "I must ___ soon. I will ___ my options. Each ___ has some ___.", "blanks": [{"id": "blank1", "text": "decide", "options": ["decide", "choose", "weigh", "risk"], "correctAnswer": "decide"}, {"id": "blank2", "text": "weigh", "options": ["weigh", "choose", "decide", "option"], "correctAnswer": "weigh"}, {"id": "blank3", "text": "option", "options": ["option", "risk", "choose", "weigh"], "correctAnswer": "option"}, {"id": "blank4", "text": "risk", "options": ["risk", "option", "choose", "decide"], "correctAnswer": "risk"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 5, 'Complete the Sentences 2', 'Fill with the correct word', '{"text": "I will ___ the safer path. We must ___ carefully. One ___ stands out.", "blanks": [{"id": "blank1", "text": "choose", "options": ["choose", "decide", "weigh", "risk"], "correctAnswer": "choose"}, {"id": "blank2", "text": "weigh", "options": ["weigh", "option", "choose", "decide"], "correctAnswer": "weigh"}, {"id": "blank3", "text": "option", "options": ["option", "risk", "weigh", "choose"], "correctAnswer": "option"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    -- Grammar Explanation: Future (will vs going to) — decisions
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_explanation', 6, 'Future: Will vs Going To for Decisions', 'Use will for quick decisions/uncertain; going to for planned intentions', '{"rules": "Use will for quick decisions or uncertain plans. Use going to for intentions or decided plans.\\n- I will pick this option now.\\n- I am going to compare risks tonight.\\nAvoid contractions.", "examples": ["I am going to list all options today.", "We will see which option is safest.", "She is going to talk to her mentor.", "They will decide after they weigh the risks.", "He is going to choose a low-risk plan."]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 7, 'Build Sentences 1', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'I am going to list all options today', 'I am going to list all options today', '["I", "am", "going", "to", "list", "all", "options", "today"]'::jsonb),
    (activity_id_var, 'We will see which option is safest', 'We will see which option is safest', '["We", "will", "see", "which", "option", "is", "safest"]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 8, 'Build Sentences 2', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'She is going to talk to her mentor', 'She is going to talk to her mentor', '["She", "is", "going", "to", "talk", "to", "her", "mentor"]'::jsonb),
    (activity_id_var, 'They will decide after they weigh the risks', 'They will decide after they weigh the risks', '["They", "will", "decide", "after", "they", "weigh", "the", "risks"]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'speaking_practice', 9, 'Talk About Decisions', 'Practice talking about decisions under pressure', '{"prompts": ["How do you decide when you are under pressure?", "What decision are you going to make soon?", "When do you change your mind and why?"]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (
      lesson_id,
      activity_type,
      activity_order,
      title,
      description,
      content
    ) VALUES (
      'B1-L41',
      'speaking_improvement',
      10,
      'Speaking Improvement',
      'Read the improved version of your speech',
      '{"type": "speaking_improvement", "similarityThreshold": 70}'::jsonb
    );
END $$;

