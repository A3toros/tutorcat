-- =========================================
-- Pre-fill Database with Sample Lesson Data
-- B2-L13: Mental health among students
-- =========================================

DELETE FROM grammar_sentences WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'B2-L13');
DELETE FROM vocabulary_items WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'B2-L13');
DELETE FROM lesson_activities WHERE lesson_id = 'B2-L13';
DELETE FROM lessons WHERE id = 'B2-L13';

INSERT INTO lessons (id, level, lesson_number, topic) VALUES
('B2-L13', 'B2', 13, 'Mental health among students')
ON CONFLICT (id) DO UPDATE SET topic = EXCLUDED.topic;

DO $$
DECLARE
    lesson_id_var TEXT := 'B2-L13';
    activity_id_var UUID;
BEGIN
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'warm_up_speaking', 1, 'Checking In', 'Talk about balance and stress', '{"prompt": "When do you switch off, and what do you drop first when stressed?"}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_intro', 2, 'Mental Health Words', 'Key words for student wellbeing', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'cope', 'รับมือ', NULL),
    (activity_id_var, 'stigma', 'ตราบาป/มุมมองเชิงลบ', NULL),
    (activity_id_var, 'peer', 'เพื่อนร่วมกลุ่ม/เพื่อน', NULL),
    (activity_id_var, 'space', 'พื้นที่/เวลาส่วนตัว', NULL),
    (activity_id_var, 'recharge', 'ชาร์จพลัง/พักฟื้น', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_matching_drag', 3, 'Match Mental Health Words', 'Match words with meanings', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'cope', 'รับมือ', NULL),
    (activity_id_var, 'stigma', 'ตราบาป/มุมมองเชิงลบ', NULL),
    (activity_id_var, 'peer', 'เพื่อนร่วมกลุ่ม/เพื่อน', NULL),
    (activity_id_var, 'space', 'พื้นที่/เวลาส่วนตัว', NULL),
    (activity_id_var, 'recharge', 'ชาร์จพลัง/พักฟื้น', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 4, 'Complete the Sentences 1', 'Fill with the correct word', '{"text": "I need ___ to rest. Talking to a ___ can help me ___.", "blanks": [{"id": "blank1", "text": "space", "options": ["space", "peer", "cope", "stigma"], "correctAnswer": "space"}, {"id": "blank2", "text": "peer", "options": ["peer", "stigma", "recharge", "space"], "correctAnswer": "peer"}, {"id": "blank3", "text": "cope", "options": ["cope", "recharge", "space", "stigma"], "correctAnswer": "cope"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 5, 'Complete the Sentences 2', 'Fill with the correct word', '{"text": "Taking a break helps me ___. We talk openly to reduce ___.", "blanks": [{"id": "blank1", "text": "recharge", "options": ["recharge", "cope", "peer", "space"], "correctAnswer": "recharge"}, {"id": "blank2", "text": "stigma", "options": ["stigma", "recharge", "space", "peer"], "correctAnswer": "stigma"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_explanation', 6, 'Contrast & Concession', 'Use although/however/whereas to balance ideas', '{"rules": "Use although + clause to show contrast in one sentence. Use however to contrast between sentences. Use whereas to compare two situations. Keep clauses parallel.\\n- Although I was tired, I kept studying.\\n- The group was calm; however, I felt anxious.\\n- She recharges alone, whereas I talk with friends.", "examples": ["Although I was stressed, I asked for help.", "The week was busy; however, I made space to rest.", "She needs quiet, whereas I need a peer to vent to.", "Although stigma exists, we still talk openly.", "The plan was heavy; however, we coped together."]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 7, 'Build Sentences 1', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'Although I was stressed, I asked for help', 'Although I was stressed, I asked for help.', '["Although", "I", "was", "stressed,", "I", "asked", "for", "help."]'::jsonb),
    (activity_id_var, 'The week was busy; however, I made space to rest', 'The week was busy; however, I made space to rest.', '["The", "week", "was", "busy;", "however,", "I", "made", "space", "to", "rest."]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 8, 'Build Sentences 2', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'She needs quiet, whereas I need a peer to talk to', 'She needs quiet, whereas I need a peer to talk to.', '["She", "needs", "quiet,", "whereas", "I", "need", "a", "peer", "to", "talk", "to."]'::jsonb),
    (activity_id_var, 'Although stigma exists, we still talk openly', 'Although stigma exists, we still talk openly.', '["Although", "stigma", "exists,", "we", "still", "talk", "openly."]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'speaking_practice', 9, 'Talk About Mental Health', 'Practice sharing contrasts', '{"prompts": ["When do you switch off first?", "How do friends help you cope?", "What feels harder: asking for help or taking space?"]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (
      lesson_id,
      activity_type,
      activity_order,
      title,
      description,
      content
    ) VALUES (
      'B2-L13',
      'speaking_improvement',
      10,
      'Speaking Improvement',
      'Read the improved version of your speech',
      '{"type": "speaking_improvement", "similarityThreshold": 70}'::jsonb
    );
END $$;


