-- =========================================
-- Pre-fill Database with Sample Lesson Data
-- B2-L30: Balancing study and personal life
-- =========================================

DELETE FROM grammar_sentences WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'B2-L30');
DELETE FROM vocabulary_items WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'B2-L30');
DELETE FROM lesson_activities WHERE lesson_id = 'B2-L30';
DELETE FROM lessons WHERE id = 'B2-L30';

INSERT INTO lessons (id, level, lesson_number, topic) VALUES
('B2-L30', 'B2', 30, 'Balancing study and personal life')
ON CONFLICT (id) DO UPDATE SET topic = EXCLUDED.topic;

DO $$
DECLARE
    lesson_id_var TEXT := 'B2-L30';
    activity_id_var UUID;
BEGIN
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'warm_up_speaking', 1, 'Balance Reflection', 'Talk about changes', '{"prompt": "If you hadn’t changed a habit, what would your balance be now?"}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_intro', 2, 'Balance Words', 'Key words for balancing life', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'boundary', 'ขอบเขต', NULL),
    (activity_id_var, 'prioritize', 'จัดลำดับความสำคัญ', NULL),
    (activity_id_var, 'recharge', 'ชาร์จพลัง/พักฟื้น', NULL),
    (activity_id_var, 'workload', 'ปริมาณงาน', NULL),
    (activity_id_var, 'pace', 'จังหวะ/ความเร็ว', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_matching_drag', 3, 'Match Balance Words', 'Match words with meanings', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'boundary', 'ขอบเขต', NULL),
    (activity_id_var, 'prioritize', 'จัดลำดับความสำคัญ', NULL),
    (activity_id_var, 'recharge', 'ชาร์จพลัง/พักฟื้น', NULL),
    (activity_id_var, 'workload', 'ปริมาณงาน', NULL),
    (activity_id_var, 'pace', 'จังหวะ/ความเร็ว', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 4, 'Complete the Sentences 1', 'Fill with the correct word', '{"text": "I set a ___ each evening. I ___ tasks weekly. A steady ___ helps me manage ___.", "blanks": [{"id": "blank1", "text": "boundary", "options": ["boundary", "prioritize", "recharge", "pace"], "correctAnswer": "boundary"}, {"id": "blank2", "text": "prioritize", "options": ["prioritize", "pace", "recharge", "workload"], "correctAnswer": "prioritize"}, {"id": "blank3", "text": "pace", "options": ["pace", "workload", "boundary", "recharge"], "correctAnswer": "pace"}, {"id": "blank4", "text": "workload", "options": ["workload", "recharge", "boundary", "prioritize"], "correctAnswer": "workload"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 5, 'Complete the Sentences 2', 'Fill with the correct word', '{"text": "Weekend walks help me ___.", "blanks": [{"id": "blank1", "text": "recharge", "options": ["recharge", "pace", "boundary", "workload"], "correctAnswer": "recharge"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_explanation', 6, 'Third Conditional', 'Talk about past choices and outcomes', '{"rules": "Use if + past perfect + would have + past participle for unreal past results. Use could/might have for less certain results.\\n- If I had set boundaries, I would have slept more.\\n- If they had prioritized earlier, they might have avoided burnout.", "examples": ["If I had planned rest, I would have avoided burnout.", "If we had paced ourselves, we would have finished calmer.", "If she had prioritized sleep, she might have felt better.", "If he had reduced his workload, he could have joined us.", "If you had recharged on weekends, you would have focused more."]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 7, 'Build Sentences 1', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'If I had planned rest, I would have avoided burnout', 'If I had planned rest, I would have avoided burnout.', '["If", "I", "had", "planned", "rest,", "I", "would", "have", "avoided", "burnout."]'::jsonb),
    (activity_id_var, 'If we had paced ourselves, we would have finished calmer', 'If we had paced ourselves, we would have finished calmer.', '["If", "we", "had", "paced", "ourselves,", "we", "would", "have", "finished", "calmer."]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 8, 'Build Sentences 2', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'If she had prioritized sleep, she might have felt better', 'If she had prioritized sleep, she might have felt better.', '["If", "she", "had", "prioritized", "sleep,", "she", "might", "have", "felt", "better."]'::jsonb),
    (activity_id_var, 'If he had reduced his workload, he could have joined us', 'If he had reduced his workload, he could have joined us.', '["If", "he", "had", "reduced", "his", "workload,", "he", "could", "have", "joined", "us."]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'speaking_practice', 9, 'Talk About Balance Choices', 'Practice third conditional', '{"prompts": ["If you hadn’t changed a habit, what would your balance be now?", "If you had planned rest sooner, what would have changed?", "If your workload had been lighter, what would you have done?"]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (
      lesson_id,
      activity_type,
      activity_order,
      title,
      description,
      content
    ) VALUES (
      'B2-L30',
      'speaking_improvement',
      10,
      'Speaking Improvement',
      'Read the improved version of your speech',
      '{"type": "speaking_improvement", "similarityThreshold": 70}'::jsonb
    );
END $$;


