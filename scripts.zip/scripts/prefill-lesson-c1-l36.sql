-- =========================================
-- Pre-fill Database with Sample Lesson Data
-- C1-L36: Global Citizenship
-- =========================================
DELETE FROM lesson_activity_results WHERE lesson_id = 'C1-L36';
DELETE FROM user_progress WHERE lesson_id = 'C1-L36';
DELETE FROM lesson_history WHERE lesson_id = 'C1-L36';
DELETE FROM grammar_sentences WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'C1-L36');
DELETE FROM vocabulary_items WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'C1-L36');
DELETE FROM lesson_activities WHERE lesson_id = 'C1-L36';
DELETE FROM lessons WHERE id = 'C1-L36';

INSERT INTO lessons (id, level, lesson_number, topic) VALUES
('C1-L36', 'C1', 36, 'Global Citizenship')
ON CONFLICT (id) DO UPDATE SET topic = EXCLUDED.topic;

DO $$
DECLARE
    lesson_id_var TEXT := 'C1-L36';
    activity_id_var UUID;
BEGIN
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'warm_up_speaking', 1, 'Global Citizenship', 'Discuss global citizenship', '{"prompt": "What does being a global citizen mean to you?"}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_intro', 2, 'Global Citizenship Vocabulary', 'Learn vocabulary about global citizenship', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'citizenship', 'ความเป็นพลเมือง', NULL),
    (activity_id_var, 'responsibility', 'ความรับผิดชอบ', NULL),
    (activity_id_var, 'awareness', 'การตระหนัก', NULL),
    (activity_id_var, 'engagement', 'การมีส่วนร่วม', NULL),
    (activity_id_var, 'impact', 'ผลกระทบ', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_matching_drag', 3, 'Match Global Citizenship Words', 'Match English words with Thai meanings', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'citizenship', 'ความเป็นพลเมือง', NULL),
    (activity_id_var, 'responsibility', 'ความรับผิดชอบ', NULL),
    (activity_id_var, 'awareness', 'การตระหนัก', NULL),
    (activity_id_var, 'engagement', 'การมีส่วนร่วม', NULL),
    (activity_id_var, 'impact', 'ผลกระทบ', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 4, 'Complete the Sentences 1', 'Fill with the correct word', '{"text": "Global ___ involves ___. ___ of global issues creates ___.", "blanks": [{"id": "blank1", "text": "citizenship", "options": ["citizenship", "responsibility", "awareness", "engagement"], "correctAnswer": "citizenship"}, {"id": "blank2", "text": "responsibility", "options": ["responsibility", "citizenship", "awareness", "engagement"], "correctAnswer": "responsibility"}, {"id": "blank3", "text": "Awareness", "options": ["Awareness", "Citizenship", "Responsibility", "Engagement"], "correctAnswer": "Awareness"}, {"id": "blank4", "text": "impact", "options": ["impact", "citizenship", "responsibility", "engagement"], "correctAnswer": "impact"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 5, 'Complete the Sentences 2', 'Fill with the correct word', '{"text": "Active ___ shows global ___. Student ___ addresses global challenges.", "blanks": [{"id": "blank1", "text": "engagement", "options": ["engagement", "citizenship", "responsibility", "awareness"], "correctAnswer": "engagement"}, {"id": "blank2", "text": "citizenship", "options": ["citizenship", "responsibility", "awareness", "impact"], "correctAnswer": "citizenship"}, {"id": "blank3", "text": "engagement", "options": ["engagement", "citizenship", "responsibility", "awareness"], "correctAnswer": "engagement"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_explanation', 6, 'Inversion: Never/Rarely', 'Learn inversion with never and rarely', '{"rules": "Inversion with never/rarely:\n- \"Never have I acted as a global citizen.\" (formal emphasis)\n- \"Rarely do students engage globally.\" (emphasis on infrequency)\n- \"Never before have I considered global impact.\" (past emphasis)\n\nStructure:\n- Never/Rarely + auxiliary + subject + verb\n- Used for emphasis and formal tone\n\nUse for:\n- Emphasizing rarity: \"Rarely do people act as global citizens.\"\n- Formal statements: \"Never have I seen such global awareness.\"\n- Highlighting infrequency: \"Rarely is global citizenship fully understood.\"", "examples": ["Never have I acted as a global citizen without considering impact.", "Rarely do students engage globally without awareness.", "Never before have I considered my global responsibilities.", "Rarely is global citizenship fully understood by students.", "Never do global issues fail to affect local communities."]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 7, 'Build Sentences 1', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'Never have I acted as a global citizen without considering impact.', 'Never have I acted as a global citizen without considering impact.', '["Never", "have", "I", "acted", "as", "a", "global", "citizen", "without", "considering", "impact."]'::jsonb),
    (activity_id_var, 'Rarely do students engage globally without awareness.', 'Rarely do students engage globally without awareness.', '["Rarely", "do", "students", "engage", "globally", "without", "awareness."]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 8, 'Build Sentences 2', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'Never before have I considered my global responsibilities.', 'Never before have I considered my global responsibilities.', '["Never", "before", "have", "I", "considered", "my", "global", "responsibilities."]'::jsonb),
    (activity_id_var, 'Rarely is global citizenship fully understood by students.', 'Rarely is global citizenship fully understood by students.', '["Rarely", "is", "global", "citizenship", "fully", "understood", "by", "students."]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'speaking_practice', 9, 'Discuss Global Citizenship', 'Practice speaking about global citizenship', '{"prompts": ["What responsibilities come with global citizenship?", "How do global issues affect you?", "What actions show global awareness?", "How can students engage globally?", "Why is global citizenship important today?"]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (
      lesson_id,
      activity_type,
      activity_order,
      title,
      description,
      content
    ) VALUES (
      'C1-L36',
      'speaking_improvement',
      10,
      'Speaking Improvement',
      'Read the improved version of your speech',
      '{"type": "speaking_improvement", "similarityThreshold": 70}'::jsonb
    );
END $$;
