const { neon } = require('@neondatabase/serverless');

// Read from .env file manually or use environment variable
const fs = require('fs');
const path = require('path');
const envPath = path.join(__dirname, '..', '.env');
let databaseUrl = process.env.NEON_DATABASE_URL;

if (!databaseUrl && fs.existsSync(envPath)) {
  const envContent = fs.readFileSync(envPath, 'utf8');
  const match = envContent.match(/NEON_DATABASE_URL=(.+)/);
  if (match) {
    databaseUrl = match[1].trim();
  }
}

if (!databaseUrl) {
  console.error('NEON_DATABASE_URL not found');
  process.exit(1);
}

const sql = neon(databaseUrl);

async function checkDuplicates() {
  try {
    const result = await sql`
      SELECT 
        la.id as activity_id,
        la.activity_order,
        la.activity_type,
        la.title,
        COUNT(vi.id) as vocab_count,
        json_agg(
          json_build_object(
            'id', vi.id,
            'word', vi.english_word,
            'translation', vi.thai_translation
          ) ORDER BY vi.english_word
        ) as words
      FROM lesson_activities la
      LEFT JOIN vocabulary_items vi ON la.id = vi.activity_id
      WHERE la.lesson_id = 'A1-L1' AND la.active = TRUE
      GROUP BY la.id, la.activity_order, la.activity_type, la.title
      ORDER BY la.activity_order
    `;
    
    console.log('Vocabulary items per activity:');
    console.log(JSON.stringify(result, null, 2));
    
    // Check for duplicates within same activity
    const duplicates = await sql`
      SELECT 
        activity_id,
        english_word,
        thai_translation,
        COUNT(*) as count
      FROM vocabulary_items
      WHERE activity_id IN (
        SELECT id FROM lesson_activities WHERE lesson_id = 'A1-L1' AND active = TRUE
      )
      GROUP BY activity_id, english_word, thai_translation
      HAVING COUNT(*) > 1
    `;
    
    if (duplicates.length > 0) {
      console.log('\nDuplicate vocabulary items found:');
      console.log(JSON.stringify(duplicates, null, 2));
    } else {
      console.log('\nNo duplicates found within activities.');
    }
    
  } catch (error) {
    console.error('Error:', error);
  }
}

checkDuplicates();

