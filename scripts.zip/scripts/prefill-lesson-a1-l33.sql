-- =========================================
-- Pre-fill Database with Sample Lesson Data
-- A1-L33: Teacher and Students
-- =========================================

DELETE FROM grammar_sentences WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'A1-L33');
DELETE FROM vocabulary_items WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'A1-L33');
DELETE FROM lesson_activities WHERE lesson_id = 'A1-L33');
DELETE FROM lessons WHERE id = 'A1-L33';

INSERT INTO lessons (id, level, lesson_number, topic) VALUES
('A1-L33', 'A1', 33, 'Teacher and Students')
ON CONFLICT (id) DO UPDATE SET topic = EXCLUDED.topic;

DO $$
DECLARE
    lesson_id_var TEXT := 'A1-L33';
    activity_id_var UUID;
BEGIN
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'warm_up_speaking', 1, 'In Class', 'Talk about class actions', '{"prompt": "Do you listen in class?"}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_intro', 2, 'Classroom Actions', 'Learn class imperatives', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'listen', 'ฟัง', NULL),
    (activity_id_var, 'read', 'อ่าน', NULL),
    (activity_id_var, 'write', 'เขียน', NULL),
    (activity_id_var, 'sit', 'นั่ง', NULL),
    (activity_id_var, 'stand', 'ยืน', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_matching_drag', 3, 'Match Class Actions', 'Match class action words', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'listen', 'ฟัง', NULL),
    (activity_id_var, 'read', 'อ่าน', NULL),
    (activity_id_var, 'write', 'เขียน', NULL),
    (activity_id_var, 'sit', 'นั่ง', NULL),
    (activity_id_var, 'stand', 'ยืน', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 4, 'Complete the Sentences 1', 'Fill with the correct word', '{"text": "__ and read. __ and write.", "blanks": [{"id": "blank1", "text": "Sit", "options": ["Sit", "Stand", "Listen", "Write"], "correctAnswer": "Sit"}, {"id": "blank2", "text": "Stand", "options": ["Stand", "Read", "Listen", "Sit"], "correctAnswer": "Stand"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 5, 'Complete the Sentences 2', 'Fill with the correct word', '{"text": "__ to the teacher. __ your name.", "blanks": [{"id": "blank1", "text": "Listen", "options": ["Listen", "Write", "Sit", "Stand"], "correctAnswer": "Listen"}, {"id": "blank2", "text": "Write", "options": ["Write", "Read", "Stand", "Listen"], "correctAnswer": "Write"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_explanation', 6, 'Imperatives (classroom)', 'Use simple commands', '{"rules": "Use the base verb to give simple class commands.\n- Listen. Read. Sit down. Stand up.\nBe polite with please.", "examples": ["Listen, please.", "Read the book.", "Write your name.", "Sit down.", "Stand up."]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 7, 'Build Sentences 1', 'Arrange words', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'Listen please', 'Listen, please.', '["Listen,", "please."]'::jsonb),
    (activity_id_var, 'Read the book', 'Read the book.', '["Read", "the", "book."]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 8, 'Build Sentences 2', 'Arrange words', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'Write your name', 'Write your name.', '["Write", "your", "name."]'::jsonb),
    (activity_id_var, 'Sit down', 'Sit down.', '["Sit", "down."]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'speaking_practice', 9, 'Practice Class Commands', 'Use imperatives politely', '{"prompts": ["Do you listen in class?", "Do you write notes?", "Do you stand up in class?", "Do you read in class?", "Do you sit in front?"]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (
      lesson_id,
      activity_type,
      activity_order,
      title,
      description,
      content
    ) VALUES (
      'A1-L33',
      'speaking_improvement',
      10,
      'Speaking Improvement',
      'Read the improved version of your speech',
      '{"type": "speaking_improvement", "similarityThreshold": 70}'::jsonb
    );
END $$;

