-- =========================================
-- Pre-fill Database with Sample Lesson Data
-- A2-L59: Sports Equipment
-- =========================================

DELETE FROM grammar_sentences WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'A2-L59');
DELETE FROM vocabulary_items WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'A2-L59');
DELETE FROM lesson_activities WHERE lesson_id = 'A2-L59';
DELETE FROM lessons WHERE id = 'A2-L59';

INSERT INTO lessons (id, level, lesson_number, topic) VALUES
('A2-L59', 'A2', 59, 'Sports Equipment')
ON CONFLICT (id) DO UPDATE SET topic = EXCLUDED.topic;

DO $$
DECLARE
    lesson_id_var TEXT := 'A2-L59';
    activity_id_var UUID;
BEGIN
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'warm_up_speaking', 1, 'Sports Gear', 'Talk about sports equipment', '{"prompt": "How much sports equipment do you use?"}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_intro', 2, 'Equipment Words', 'Learn sports equipment words', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'ball', 'ลูกบอล', NULL),
    (activity_id_var, 'racket', 'ไม้แร็กเก็ต', NULL),
    (activity_id_var, 'helmet', 'หมวกกันน็อค', NULL),
    (activity_id_var, 'shoes', 'รองเท้า', NULL),
    (activity_id_var, 'gloves', 'ถุงมือ', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_matching_drag', 3, 'Match Equipment Words', 'Match sports gear words', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'ball', 'ลูกบอล', NULL),
    (activity_id_var, 'racket', 'ไม้แร็กเก็ต', NULL),
    (activity_id_var, 'helmet', 'หมวกกันน็อค', NULL),
    (activity_id_var, 'shoes', 'รองเท้า', NULL),
    (activity_id_var, 'gloves', 'ถุงมือ', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 4, 'Complete the Sentences 1', 'Fill with the correct word', '{"text": "I need a ___. She wears a ___. He bought new ___.", "blanks": [{"id": "blank1", "text": "racket", "options": ["racket", "helmet", "shoes", "gloves"], "correctAnswer": "racket"}, {"id": "blank2", "text": "helmet", "options": ["helmet", "ball", "shoes", "gloves"], "correctAnswer": "helmet"}, {"id": "blank3", "text": "shoes", "options": ["shoes", "gloves", "ball", "racket"], "correctAnswer": "shoes"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 5, 'Complete the Sentences 2', 'Fill with the correct word', '{"text": "He forgot his ___. Can you bring a ___? I have extra ___.", "blanks": [{"id": "blank1", "text": "ball", "options": ["ball", "racket", "helmet", "gloves"], "correctAnswer": "ball"}, {"id": "blank2", "text": "racket", "options": ["racket", "gloves", "helmet", "ball"], "correctAnswer": "racket"}, {"id": "blank3", "text": "gloves", "options": ["gloves", "ball", "shoes", "helmet"], "correctAnswer": "gloves"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_explanation', 6, 'Some / Any / Much / Many', 'Talk about quantities of gear', '{"rules": "Use many with countable; much with uncountable; some/any for general.\n- How many balls do you have?\n- Do you have any helmets?\n- I don''t have much gear.", "examples": ["How many balls do you have?", "Do you have any helmets?", "I don''t have many shoes.", "We have some gloves.", "I don''t have much gear."]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 7, 'Build Sentences 1', 'Arrange words', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'How many balls do you have', 'How many balls do you have?', '["How", "many", "balls", "do", "you", "have?"]'::jsonb),
    (activity_id_var, 'Do you have any helmets', 'Do you have any helmets?', '["Do", "you", "have", "any", "helmets?"]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 8, 'Build Sentences 2', 'Arrange words', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'I don t have many shoes', 'I don''t have many shoes.', '["I", "don''t", "have", "many", "shoes."]'::jsonb),
    (activity_id_var, 'We have some gloves', 'We have some gloves.', '["We", "have", "some", "gloves."]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'speaking_practice', 9, 'Talk About Sports Gear', 'Practice gear quantities', '{"prompts": ["How much sports equipment do you use?", "Do you have any safety equipment?", "How many pairs of shoes do you need?", "Do you buy much equipment or borrow it?", "How much does basic sports equipment cost?"]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (
      lesson_id,
      activity_type,
      activity_order,
      title,
      description,
      content
    ) VALUES (
      'A2-L59',
      'speaking_improvement',
      10,
      'Speaking Improvement',
      'Read the improved version of your speech',
      '{"type": "speaking_improvement", "similarityThreshold": 70}'::jsonb
    );
END $$;

