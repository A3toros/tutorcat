-- =========================================
-- Pre-fill Database with Sample Lesson Data
-- B1-L48: Advertising & Consumers
-- =========================================

DELETE FROM grammar_sentences WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'B1-L48');
DELETE FROM vocabulary_items WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'B1-L48');
DELETE FROM lesson_activities WHERE lesson_id = 'B1-L48';
DELETE FROM lessons WHERE id = 'B1-L48';

INSERT INTO lessons (id, level, lesson_number, topic) VALUES
('B1-L48', 'B1', 48, 'Advertising & Consumers')
ON CONFLICT (id) DO UPDATE SET topic = EXCLUDED.topic;

DO $$
DECLARE
    lesson_id_var TEXT := 'B1-L48';
    activity_id_var UUID;
BEGIN
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'warm_up_speaking', 1, 'Ads Around You', 'Talk about ads that influenced you', '{"prompt": "Which ad actually influenced you?"}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_intro', 2, 'Ad Words', 'Learn vocabulary about advertising', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'advertised', 'โฆษณาแล้ว', NULL),
    (activity_id_var, 'targeted', 'ถูกกำหนดเป้าหมาย', NULL),
    (activity_id_var, 'influenced', 'ถูกมีอิทธิพล', NULL),
    (activity_id_var, 'launched', 'เปิดตัว', NULL),
    (activity_id_var, 'reviewed', 'ถูกรายงาน/รีวิว', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_matching_drag', 3, 'Match Ad Words', 'Match words with meanings', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'advertised', 'โฆษณาแล้ว', NULL),
    (activity_id_var, 'targeted', 'ถูกกำหนดเป้าหมาย', NULL),
    (activity_id_var, 'influenced', 'ถูกมีอิทธิพล', NULL),
    (activity_id_var, 'launched', 'เปิดตัว', NULL),
    (activity_id_var, 'reviewed', 'ถูกรายงาน/รีวิว', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 4, 'Complete the Sentences 1', 'Fill with the correct word', '{"text": "The product was ___. The campaign ___ young buyers. Many were ___.", "blanks": [{"id": "blank1", "text": "advertised", "options": ["advertised", "targeted", "influenced", "launched"], "correctAnswer": "advertised"}, {"id": "blank2", "text": "targeted", "options": ["targeted", "launched", "reviewed", "advertised"], "correctAnswer": "targeted"}, {"id": "blank3", "text": "influenced", "options": ["influenced", "advertised", "reviewed", "launched"], "correctAnswer": "influenced"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 5, 'Complete the Sentences 2', 'Fill with the correct word', '{"text": "It was ___ last month. The item was quickly ___. The ad was heavily ___.", "blanks": [{"id": "blank1", "text": "launched", "options": ["launched", "advertised", "targeted", "reviewed"], "correctAnswer": "launched"}, {"id": "blank2", "text": "reviewed", "options": ["reviewed", "launched", "targeted", "advertised"], "correctAnswer": "reviewed"}, {"id": "blank3", "text": "advertised", "options": ["advertised", "reviewed", "influenced", "targeted"], "correctAnswer": "advertised"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    -- Grammar Explanation: Passive Voice (Past) — ads and consumers
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_explanation', 6, 'Passive Voice (Past) for Ads', 'Use was/were + past participle to describe past actions to objects', '{"rules": "Passive past: was/were + past participle. Focus on what happened to the object.\\n- Customers were targeted by the campaign.\\n- The product was launched in May.\\nAvoid contractions.", "examples": ["Customers were targeted by the campaign.", "The product was launched in May.", "Many viewers were influenced by the ad.", "Reviews were posted within hours.", "The slogan was repeated everywhere."]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 7, 'Build Sentences 1', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'Customers were targeted by the campaign', 'Customers were targeted by the campaign', '["Customers", "were", "targeted", "by", "the", "campaign"]'::jsonb),
    (activity_id_var, 'The product was launched in May', 'The product was launched in May', '["The", "product", "was", "launched", "in", "May"]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 8, 'Build Sentences 2', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'Many viewers were influenced by the ad', 'Many viewers were influenced by the ad', '["Many", "viewers", "were", "influenced", "by", "the", "ad"]'::jsonb),
    (activity_id_var, 'Reviews were posted within hours', 'Reviews were posted within hours', '["Reviews", "were", "posted", "within", "hours"]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'speaking_practice', 9, 'Talk About Ads', 'Practice talking about ads and consumer reactions', '{"prompts": ["Which ad actually influenced you?", "How were buyers targeted in a campaign you saw?", "Describe a campaign that failed for you."]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (
      lesson_id,
      activity_type,
      activity_order,
      title,
      description,
      content
    ) VALUES (
      'B1-L48',
      'speaking_improvement',
      10,
      'Speaking Improvement',
      'Read the improved version of your speech',
      '{"type": "speaking_improvement", "similarityThreshold": 70}'::jsonb
    );
END $$;

