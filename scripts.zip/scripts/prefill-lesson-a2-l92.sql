-- =========================================
-- Pre-fill Database with Sample Lesson Data
-- A2-L92: Asking About Quality
-- =========================================

DELETE FROM grammar_sentences WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'A2-L92');
DELETE FROM vocabulary_items WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'A2-L92');
DELETE FROM lesson_activities WHERE lesson_id = 'A2-L92';
DELETE FROM lessons WHERE id = 'A2-L92';

INSERT INTO lessons (id, level, lesson_number, topic) VALUES
('A2-L92', 'A2', 92, 'Asking About Quality')
ON CONFLICT (id) DO UPDATE SET topic = EXCLUDED.topic;

DO $$
DECLARE
    lesson_id_var TEXT := 'A2-L92';
    activity_id_var UUID;
BEGIN
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'warm_up_speaking', 1, 'Good Products', 'Talk about quality questions', '{"prompt": "How do you ask if something is good quality?"}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_intro', 2, 'Quality Words', 'Learn quality words', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'quality', 'คุณภาพ', NULL),
    (activity_id_var, 'durable', 'ทนทาน', NULL),
    (activity_id_var, 'soft', 'นุ่ม', NULL),
    (activity_id_var, 'safe', 'ปลอดภัย', NULL),
    (activity_id_var, 'guarantee', 'รับประกัน', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_matching_drag', 3, 'Match Quality Words', 'Match quality words', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'quality', 'คุณภาพ', NULL),
    (activity_id_var, 'durable', 'ทนทาน', NULL),
    (activity_id_var, 'soft', 'นุ่ม', NULL),
    (activity_id_var, 'safe', 'ปลอดภัย', NULL),
    (activity_id_var, 'guarantee', 'รับประกัน', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 4, 'Complete the Sentences 1', 'Fill with the correct word', '{"text": "Is the ___ good? Is it ___? Is it ___ to use?", "blanks": [{"id": "blank1", "text": "quality", "options": ["quality", "durable", "safe", "soft"], "correctAnswer": "quality"}, {"id": "blank2", "text": "durable", "options": ["durable", "soft", "safe", "quality"], "correctAnswer": "durable"}, {"id": "blank3", "text": "safe", "options": ["safe", "durable", "soft", "guarantee"], "correctAnswer": "safe"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 5, 'Complete the Sentences 2', 'Fill with the correct word', '{"text": "It feels ___. Does it have a ___?", "blanks": [{"id": "blank1", "text": "soft", "options": ["soft", "durable", "quality", "safe"], "correctAnswer": "soft"}, {"id": "blank2", "text": "guarantee", "options": ["guarantee", "quality", "durable", "soft"], "correctAnswer": "guarantee"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_explanation', 6, 'Do/Does Questions', 'Ask about product quality', '{"rules": "Use do/does + subject + base verb to ask.\n- Does it last long?\n- Do you think it is safe?\nShort answers: Yes, it does. No, it doesn''t.", "examples": ["Does it last long?", "Do you think it is safe?", "Does it feel soft?", "Do they give a guarantee?", "Do you trust the quality?"]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 7, 'Build Sentences 1', 'Arrange words', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'Does it last long', 'Does it last long?', '["Does", "it", "last", "long?"]'::jsonb),
    (activity_id_var, 'Do you think it is safe', 'Do you think it is safe?', '["Do", "you", "think", "it", "is", "safe?"]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 8, 'Build Sentences 2', 'Arrange words', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'Do they give a guarantee', 'Do they give a guarantee?', '["Do", "they", "give", "a", "guarantee?"]'::jsonb),
    (activity_id_var, 'Does it feel soft', 'Does it feel soft?', '["Does", "it", "feel", "soft?"]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'speaking_practice', 9, 'Ask About Quality', 'Practice quality questions', '{"prompts": ["How do you ask if something is good quality?", "Do you check reviews before buying?", "Does the material feel strong?", "Do you trust guarantees?", "What makes something good quality for you?"]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (
      lesson_id,
      activity_type,
      activity_order,
      title,
      description,
      content
    ) VALUES (
      'A2-L92',
      'speaking_improvement',
      10,
      'Speaking Improvement',
      'Read the improved version of your speech',
      '{"type": "speaking_improvement", "similarityThreshold": 70}'::jsonb
    );
END $$;

