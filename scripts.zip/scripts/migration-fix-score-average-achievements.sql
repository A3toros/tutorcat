-- Migration: Fix score_average achievements to require minimum lesson counts
-- This fixes the bug where achievements like "High Achiever" and "Excellence" 
-- were being awarded after just 1 lesson instead of requiring 25+ or 50+ lessons
-- 
-- Date: 2025-01-XX
-- Issue: Achievements with score_average requirement_type were only checking 
--        average score, not the minimum number of lessons required

-- Step 1: Update the check_achievements_on_lesson_complete function
-- to require both average score AND minimum lesson count for score_average achievements
CREATE OR REPLACE FUNCTION check_achievements_on_lesson_complete(p_user_id UUID)
RETURNS TABLE(achievement_code VARCHAR(50), achievement_name VARCHAR(255), icon VARCHAR(50)) AS $$
DECLARE
    v_lesson_count INTEGER;
    v_perfect_scores INTEGER;
    v_avg_score NUMERIC;
    v_stars INTEGER;
    v_level VARCHAR(10);
    v_achievement_record RECORD;
BEGIN
    -- Get basic stats from existing tables
    SELECT COUNT(*) INTO v_lesson_count
    FROM user_progress
    WHERE user_id = p_user_id AND completed = true;
    
    SELECT COUNT(*) INTO v_perfect_scores
    FROM user_progress
    WHERE user_id = p_user_id AND completed = true AND score >= 100;
    
    SELECT COALESCE(AVG(score), 0) INTO v_avg_score
    FROM user_progress
    WHERE user_id = p_user_id AND completed = true;
    
    SELECT COALESCE(total_stars, 0) INTO v_stars
    FROM users
    WHERE id = p_user_id
    LIMIT 1;
    
    -- Check all achievements and award if criteria met
    FOR v_achievement_record IN 
        SELECT * FROM achievements 
        WHERE id NOT IN (
            SELECT achievement_id FROM user_achievements WHERE user_id = p_user_id
        )
    LOOP
        DECLARE
            v_should_award BOOLEAN := false;
            v_level_count INTEGER;
            v_total_in_level INTEGER;
        BEGIN
            -- Check achievement based on requirement_type
            CASE v_achievement_record.requirement_type
                WHEN 'lesson_count' THEN
                    IF v_lesson_count >= v_achievement_record.requirement_value THEN
                        v_should_award := true;
                    END IF;
                
                WHEN 'perfect_score_count' THEN
                    IF v_perfect_scores >= v_achievement_record.requirement_value THEN
                        v_should_award := true;
                    END IF;
                
                WHEN 'score_average' THEN
                    -- FIXED: For score_average, we need both the average score AND minimum lesson count
                    -- requirement_value is the score threshold, requirement_count is the minimum lessons needed
                    -- If requirement_count is NULL, we can't award (need explicit lesson count)
                    IF v_avg_score >= v_achievement_record.requirement_value 
                       AND v_achievement_record.requirement_count IS NOT NULL
                       AND v_lesson_count >= v_achievement_record.requirement_count THEN
                        v_should_award := true;
                    END IF;
                
                WHEN 'score_threshold_count' THEN
                    -- Count lessons with score >= threshold, need requirement_count such lessons
                    DECLARE
                        v_threshold_count INTEGER;
                        v_needed_count INTEGER;
                    BEGIN
                        SELECT COUNT(*) INTO v_threshold_count
                        FROM user_progress
                        WHERE user_id = p_user_id 
                          AND completed = true 
                          AND score >= v_achievement_record.requirement_value;
                        
                        v_needed_count := COALESCE(v_achievement_record.requirement_count, v_achievement_record.requirement_value);
                        
                        IF v_threshold_count >= v_needed_count THEN
                            v_should_award := true;
                        END IF;
                    END;
                
                WHEN 'stars' THEN
                    IF v_stars >= v_achievement_record.requirement_value THEN
                        v_should_award := true;
                    END IF;
                
                WHEN 'level_complete' THEN
                    -- Check if user completed all lessons in a level (dynamic count)
                    -- Extract level from code (e.g., 'a1_master' -> 'A1')
                    DECLARE
                        level_name VARCHAR(10);
                    BEGIN
                        -- Extract level from achievement code (format: 'a1_master', 'b2_master', etc.)
                        IF v_achievement_record.code LIKE 'a1_%' THEN
                            level_name := 'A1';
                        ELSIF v_achievement_record.code LIKE 'a2_%' THEN
                            level_name := 'A2';
                        ELSIF v_achievement_record.code LIKE 'b1_%' THEN
                            level_name := 'B1';
                        ELSIF v_achievement_record.code LIKE 'b2_%' THEN
                            level_name := 'B2';
                        ELSIF v_achievement_record.code LIKE 'c1_%' THEN
                            level_name := 'C1';
                        ELSIF v_achievement_record.code LIKE 'c2_%' THEN
                            level_name := 'C2';
                        END IF;
                        
                        IF level_name IS NOT NULL THEN
                            v_level_count := get_user_completed_lessons_in_level(p_user_id, level_name);
                            v_total_in_level := get_total_lessons_in_level(level_name);
                            
                            -- Award if user completed all lessons in that level (dynamic count)
                            IF v_level_count >= v_total_in_level AND v_total_in_level > 0 THEN
                                v_should_award := true;
                            END IF;
                        END IF;
                    END;
                
                ELSE
                    -- Unknown requirement type - don't award
                    v_should_award := false;
            END CASE;
            
            -- Award achievement if criteria met
            IF v_should_award THEN
                INSERT INTO user_achievements (user_id, achievement_id)
                VALUES (p_user_id, v_achievement_record.id)
                ON CONFLICT (user_id, achievement_id) DO NOTHING;
                
                -- Return newly earned achievement
                RETURN QUERY
                SELECT 
                    v_achievement_record.code,
                    v_achievement_record.name,
                    v_achievement_record.icon;
            END IF;
        END;
    END LOOP;
    
    RETURN;
END;
$$ LANGUAGE plpgsql;

-- Step 2: Update existing achievements to set requirement_count values
DO $$
BEGIN
    -- Fix score_average achievements to require minimum lesson counts
    UPDATE achievements
    SET requirement_count = 25
    WHERE code = 'high_achiever'
      AND requirement_type = 'score_average'
      AND requirement_count IS NULL;

    UPDATE achievements
    SET requirement_count = 25
    WHERE code = 'master_student'
      AND requirement_type = 'score_average'
      AND requirement_count IS NULL;

    UPDATE achievements
    SET requirement_count = 50
    WHERE code = 'excellence'
      AND requirement_type = 'score_average'
      AND requirement_count IS NULL;

    UPDATE achievements
    SET requirement_count = 10
    WHERE code = 'top_performer'
      AND requirement_type = 'score_average'
      AND requirement_count IS NULL;

    UPDATE achievements
    SET requirement_count = 1
    WHERE code = 'good_start'
      AND requirement_type = 'score_average'
      AND requirement_count IS NULL;

    RAISE NOTICE 'Fixed score_average achievements with requirement_count values!';
    RAISE NOTICE 'Updated: high_achiever (25), master_student (25), excellence (50), top_performer (10), good_start (1)';
END $$;

-- Step 3: Remove incorrectly awarded achievements
-- This removes achievements that were awarded before the fix was applied
-- Specifically removes score_average achievements that require multiple lessons
-- but were awarded when users only had 1 lesson completed
DO $$
DECLARE
    v_removed_count INTEGER := 0;
    v_achievement_record RECORD;
BEGIN
    -- Remove incorrectly awarded score_average achievements that require multiple lessons
    FOR v_achievement_record IN
        SELECT a.id, a.code, a.name, a.requirement_count
        FROM achievements a
        WHERE a.requirement_type = 'score_average'
          AND a.requirement_count > 1
    LOOP
        -- Delete user_achievements where user hasn't completed enough lessons
        DELETE FROM user_achievements ua
        WHERE ua.achievement_id = v_achievement_record.id
          AND EXISTS (
              SELECT 1 
              FROM user_progress up 
              WHERE up.user_id = ua.user_id 
                AND up.completed = true
              HAVING COUNT(*) < v_achievement_record.requirement_count
          );
        
        GET DIAGNOSTICS v_removed_count = ROW_COUNT;
        
        IF v_removed_count > 0 THEN
            RAISE NOTICE 'Removed % incorrectly awarded "%" achievements', 
                v_removed_count, v_achievement_record.name;
        END IF;
    END LOOP;
    
    RAISE NOTICE 'Cleanup complete! All incorrectly awarded achievements have been removed.';
END $$;

