-- =========================================
-- Pre-fill Database with Sample Lesson Data
-- A2-L21: Asking About Timetables
-- =========================================

DELETE FROM grammar_sentences WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'A2-L21');
DELETE FROM vocabulary_items WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'A2-L21');
DELETE FROM lesson_activities WHERE lesson_id = 'A2-L21';
DELETE FROM lessons WHERE id = 'A2-L21';

INSERT INTO lessons (id, level, lesson_number, topic) VALUES
('A2-L21', 'A2', 21, 'Asking About Timetables')
ON CONFLICT (id) DO UPDATE SET topic = EXCLUDED.topic;

DO $$
DECLARE
    lesson_id_var TEXT := 'A2-L21';
    activity_id_var UUID;
BEGIN
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'warm_up_speaking', 1, 'Timetable Talk', 'Ask about times', '{"prompt": "When was the last time your bus or train was late?"}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_intro', 2, 'Timetable Words', 'Learn timetable vocabulary', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'arrive', 'มาถึง', NULL),
    (activity_id_var, 'depart', 'ออกเดินทาง', NULL),
    (activity_id_var, 'late', 'สาย', NULL),
    (activity_id_var, 'on time', 'ตรงเวลา', NULL),
    (activity_id_var, 'delay', 'ความล่าช้า', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_matching_drag', 3, 'Match Timetable Words', 'Match time words', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'arrive', 'มาถึง', NULL),
    (activity_id_var, 'depart', 'ออกเดินทาง', NULL),
    (activity_id_var, 'late', 'สาย', NULL),
    (activity_id_var, 'on time', 'ตรงเวลา', NULL),
    (activity_id_var, 'delay', 'ความล่าช้า', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 4, 'Complete the Sentences 1', 'Fill with the correct word', '{"text": "The bus will ___ at 7. It will ___ at 7:30. Today it is ___.", "blanks": [{"id": "blank1", "text": "depart", "options": ["depart", "arrive", "late", "delay"], "correctAnswer": "depart"}, {"id": "blank2", "text": "arrive", "options": ["arrive", "on time", "late", "depart"], "correctAnswer": "arrive"}, {"id": "blank3", "text": "late", "options": ["late", "on time", "delay", "depart"], "correctAnswer": "late"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 5, 'Complete the Sentences 2', 'Fill with the correct word', '{"text": "The train is ___ because of rain. Yesterday it was ___. I hope we are ___.", "blanks": [{"id": "blank1", "text": "delayed", "options": ["delayed", "on time", "late", "arrive"], "correctAnswer": "delayed"}, {"id": "blank2", "text": "on time", "options": ["on time", "delayed", "late", "depart"], "correctAnswer": "on time"}, {"id": "blank3", "text": "on time", "options": ["on time", "late", "depart", "arrive"], "correctAnswer": "on time"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_explanation', 6, 'Prepositions of Time', 'Ask and answer about times', '{"rules": "Use at for clock times; on for days; in for months/years.\n- The bus arrives at 7:30.\n- The train leaves on Monday.\n- The flight is in June.", "examples": ["The train arrives at 8.", "The bus leaves on Friday.", "We travel in April.", "Are you free at 6?", "They depart on Sunday."]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 7, 'Build Sentences 1', 'Arrange words', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'The train arrives at eight', 'The train arrives at eight.', '["The", "train", "arrives", "at", "eight."]'::jsonb),
    (activity_id_var, 'The bus leaves on Friday', 'The bus leaves on Friday.', '["The", "bus", "leaves", "on", "Friday."]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 8, 'Build Sentences 2', 'Arrange words', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'We travel in April', 'We travel in April.', '["We", "travel", "in", "April."]'::jsonb),
    (activity_id_var, 'Are you free at six', 'Are you free at six?', '["Are", "you", "free", "at", "six?"]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'speaking_practice', 9, 'Talk About Timetables', 'Practice asking about time', '{"prompts": ["When was the last time your bus or train was late?", "How do you usually check transport times?", "What do you do while you are waiting?", "How early do you arrive before departure?", "What happens when public transport is late?"]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (
      lesson_id,
      activity_type,
      activity_order,
      title,
      description,
      content
    ) VALUES (
      'A2-L21',
      'speaking_improvement',
      10,
      'Speaking Improvement',
      'Read the improved version of your speech',
      '{"type": "speaking_improvement", "similarityThreshold": 70}'::jsonb
    );
END $$;

