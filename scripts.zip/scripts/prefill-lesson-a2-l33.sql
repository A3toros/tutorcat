-- =========================================
-- Pre-fill Database with Sample Lesson Data
-- A2-L33: Workplace Rules
-- =========================================

DELETE FROM grammar_sentences WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'A2-L33');
DELETE FROM vocabulary_items WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'A2-L33');
DELETE FROM lesson_activities WHERE lesson_id = 'A2-L33';
DELETE FROM lessons WHERE id = 'A2-L33';

INSERT INTO lessons (id, level, lesson_number, topic) VALUES
('A2-L33', 'A2', 33, 'Workplace Rules')
ON CONFLICT (id) DO UPDATE SET topic = EXCLUDED.topic;

DO $$
DECLARE
    lesson_id_var TEXT := 'A2-L33';
    activity_id_var UUID;
BEGIN
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'warm_up_speaking', 1, 'Rules at Work', 'Talk about job rules', '{"prompt": "What rules must people follow at your job or school?"}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_intro', 2, 'Rule Words', 'Learn words about workplace rules', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'rule', 'กฎ', NULL),
    (activity_id_var, 'uniform', 'เครื่องแบบ', NULL),
    (activity_id_var, 'late', 'สาย', NULL),
    (activity_id_var, 'safety', 'ความปลอดภัย', NULL),
    (activity_id_var, 'break time', 'เวลาพัก', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_matching_drag', 3, 'Match Rule Words', 'Match workplace rule words', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'rule', 'กฎ', NULL),
    (activity_id_var, 'uniform', 'เครื่องแบบ', NULL),
    (activity_id_var, 'late', 'สาย', NULL),
    (activity_id_var, 'safety', 'ความปลอดภัย', NULL),
    (activity_id_var, 'break time', 'เวลาพัก', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 4, 'Complete the Sentences 1', 'Fill with the correct word', '{"text": "Our ___ says no phones. Wearing a ___ is for ___.", "blanks": [{"id": "blank1", "text": "rule", "options": ["rule", "uniform", "safety", "late"], "correctAnswer": "rule"}, {"id": "blank2", "text": "uniform", "options": ["uniform", "safety", "rule", "break time"], "correctAnswer": "uniform"}, {"id": "blank3", "text": "safety", "options": ["safety", "uniform", "late", "rule"], "correctAnswer": "safety"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 5, 'Complete the Sentences 2', 'Fill with the correct word', '{"text": "Don''t be ___. We have ___ at noon. Follow the ___.", "blanks": [{"id": "blank1", "text": "late", "options": ["late", "safety", "rule", "uniform"], "correctAnswer": "late"}, {"id": "blank2", "text": "break time", "options": ["break time", "late", "safety", "rule"], "correctAnswer": "break time"}, {"id": "blank3", "text": "rules", "options": ["rules", "uniform", "late", "break time"], "correctAnswer": "rules"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_explanation', 6, 'Must / Mustn''t', 'Talk about rules and safety', '{"rules": "Use must for strong rules; mustn''t for things not allowed.\n- You must wear a uniform.\n- You mustn''t be late.\n- Staff must follow safety rules.", "examples": ["You must wear your badge.", "You mustn''t smoke here.", "Staff must follow safety rules.", "We must take a break at noon.", "You mustn''t use your phone in meetings."]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 7, 'Build Sentences 1', 'Arrange words', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'You must wear your uniform', 'You must wear your uniform.', '["You", "must", "wear", "your", "uniform."]'::jsonb),
    (activity_id_var, 'You mustn t be late', 'You mustn''t be late.', '["You", "mustn''t", "be", "late."]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 8, 'Build Sentences 2', 'Arrange words', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'We must follow safety rules', 'We must follow safety rules.', '["We", "must", "follow", "safety", "rules."]'::jsonb),
    (activity_id_var, 'You mustn t use your phone in meetings', 'You mustn''t use your phone in meetings.', '["You", "mustn''t", "use", "your", "phone", "in", "meetings."]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'speaking_practice', 9, 'Talk About Rules', 'Practice workplace rules', '{"prompts": ["What rules must people follow at your job or school?", "Which rule is the hardest to follow?", "Why must people follow rules?", "What happens if someone breaks a rule?", "Are there any rules you disagree with?"]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (
      lesson_id,
      activity_type,
      activity_order,
      title,
      description,
      content
    ) VALUES (
      'A2-L33',
      'speaking_improvement',
      10,
      'Speaking Improvement',
      'Read the improved version of your speech',
      '{"type": "speaking_improvement", "similarityThreshold": 70}'::jsonb
    );
END $$;

