-- Migration: Add requirement_count column to achievements table
-- This column is needed for score_threshold_count achievements
-- Run this BEFORE running migration-fix-achievement-progress.sql

DO $$
BEGIN
    -- Add requirement_count column if it doesn't exist
    IF NOT EXISTS (
        SELECT 1 FROM information_schema.columns 
        WHERE table_name = 'achievements' AND column_name = 'requirement_count'
    ) THEN
        ALTER TABLE achievements 
        ADD COLUMN requirement_count INTEGER DEFAULT NULL;
        
        RAISE NOTICE 'Added requirement_count column to achievements table';
    ELSE
        RAISE NOTICE 'requirement_count column already exists';
    END IF;
END $$;

