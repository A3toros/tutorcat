-- =========================================
-- Pre-fill Database with Sample Lesson Data
-- A2-L66: Online Learning
-- =========================================

DELETE FROM grammar_sentences WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'A2-L66');
DELETE FROM vocabulary_items WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'A2-L66');
DELETE FROM lesson_activities WHERE lesson_id = 'A2-L66';
DELETE FROM lessons WHERE id = 'A2-L66';

INSERT INTO lessons (id, level, lesson_number, topic) VALUES
('A2-L66', 'A2', 66, 'Online Learning')
ON CONFLICT (id) DO UPDATE SET topic = EXCLUDED.topic;

DO $$
DECLARE
    lesson_id_var TEXT := 'A2-L66';
    activity_id_var UUID;
BEGIN
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'warm_up_speaking', 1, 'Study Plans', 'Talk about future online study', '{"prompt": "What are you going to learn online?"}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_intro', 2, 'Online Study Words', 'Learn online learning vocabulary', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'course', 'คอร์ส', NULL),
    (activity_id_var, 'lesson', 'บทเรียน', NULL),
    (activity_id_var, 'practice', 'ฝึก', NULL),
    (activity_id_var, 'quiz', 'แบบทดสอบ', NULL),
    (activity_id_var, 'improve', 'พัฒนา', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_matching_drag', 3, 'Match Online Study Words', 'Match online learning words', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'course', 'คอร์ส', NULL),
    (activity_id_var, 'lesson', 'บทเรียน', NULL),
    (activity_id_var, 'practice', 'ฝึก', NULL),
    (activity_id_var, 'quiz', 'แบบทดสอบ', NULL),
    (activity_id_var, 'improve', 'พัฒนา', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 4, 'Complete the Sentences 1', 'Fill with the correct word', '{"text": "I will take a new ___. Each ___ has a ___. I want to ___ my English.", "blanks": [{"id": "blank1", "text": "course", "options": ["course", "lesson", "quiz", "improve"], "correctAnswer": "course"}, {"id": "blank2", "text": "lesson", "options": ["lesson", "quiz", "practice", "course"], "correctAnswer": "lesson"}, {"id": "blank3", "text": "quiz", "options": ["quiz", "lesson", "course", "improve"], "correctAnswer": "quiz"}, {"id": "blank4", "text": "improve", "options": ["improve", "practice", "quiz", "course"], "correctAnswer": "improve"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 5, 'Complete the Sentences 2', 'Fill with the correct word', '{"text": "I will ___ every day. The ___ is short.", "blanks": [{"id": "blank1", "text": "practice", "options": ["practice", "improve", "lesson", "quiz"], "correctAnswer": "practice"}, {"id": "blank2", "text": "lesson", "options": ["lesson", "quiz", "course", "practice"], "correctAnswer": "lesson"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_explanation', 6, 'Going to (future)', 'Talk about future study plans', '{"rules": "Use am/is/are + going to + verb for planned future actions.\n- I am going to take a course.\n- We are going to practice daily.\nQuestions: Are you going to join?", "examples": ["I am going to take an online course.", "She is going to study after work.", "We are going to practice daily.", "Are you going to join the quiz?", "They are going to improve their English."]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 7, 'Build Sentences 1', 'Arrange words', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'I am going to take an online course', 'I am going to take an online course.', '["I", "am", "going", "to", "take", "an", "online", "course."]'::jsonb),
    (activity_id_var, 'We are going to practice daily', 'We are going to practice daily.', '["We", "are", "going", "to", "practice", "daily."]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 8, 'Build Sentences 2', 'Arrange words', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'Are you going to join the quiz', 'Are you going to join the quiz?', '["Are", "you", "going", "to", "join", "the", "quiz?"]'::jsonb),
    (activity_id_var, 'They are going to improve their English', 'They are going to improve their English.', '["They", "are", "going", "to", "improve", "their", "English."]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'speaking_practice', 9, 'Talk About Online Learning', 'Practice future study plans', '{"prompts": ["What are you going to learn online?", "Are you going to take a course soon?", "How are you going to practice at home?", "What skills are you going to improve?", "When are you going to study online?"]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (
      lesson_id,
      activity_type,
      activity_order,
      title,
      description,
      content
    ) VALUES (
      'A2-L66',
      'speaking_improvement',
      10,
      'Speaking Improvement',
      'Read the improved version of your speech',
      '{"type": "speaking_improvement", "similarityThreshold": 70}'::jsonb
    );
END $$;

