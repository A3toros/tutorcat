-- ===== LESSON B2-L56 =====

-- =========================================
-- Pre-fill Database with Sample Lesson Data
-- B2-L56: Advertising influence
-- =========================================

DELETE FROM lesson_activity_results WHERE lesson_id = 'B2-L56';
DELETE FROM user_progress WHERE lesson_id = 'B2-L56';
DELETE FROM lesson_history WHERE lesson_id = 'B2-L56';
DELETE FROM grammar_sentences WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'B2-L56');
DELETE FROM vocabulary_items WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'B2-L56');
DELETE FROM lesson_activities WHERE lesson_id = 'B2-L56';
DELETE FROM lessons WHERE id = 'B2-L56';

INSERT INTO lessons (id, level, lesson_number, topic) VALUES
('B2-L56', 'B2', 56, 'Advertising influence')
ON CONFLICT (id) DO UPDATE SET topic = EXCLUDED.topic;

DO $$
DECLARE
    lesson_id_var TEXT := 'B2-L56';
    activity_id_var UUID;
BEGIN
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'warm_up_speaking', 1, 'Ad Awareness', 'Talk about how ads influence consumer behavior', '{"prompt": "How can you tell an ad is shaping you?"}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_intro', 2, 'Advertising Impact Words', 'Learn words related to advertising influence', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'persuasive', 'โน้มน้าวใจ', NULL),
    (activity_id_var, 'subtle', 'ละเอียด', NULL),
    (activity_id_var, 'impulse', 'แรงกระตุ้น', NULL),
    (activity_id_var, 'sponsorship', 'การสนับสนุน', NULL),
    (activity_id_var, 'trigger', 'กระตุ้น', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_matching_drag', 3, 'Match Advertising Words', 'Match words related to advertising effects', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'persuasive', 'โน้มน้าวใจ', NULL),
    (activity_id_var, 'subtle', 'ละเอียด', NULL),
    (activity_id_var, 'impulse', 'แรงกระตุ้น', NULL),
    (activity_id_var, 'sponsorship', 'การสนับสนุน', NULL),
    (activity_id_var, 'trigger', 'กระตุ้น', NULL);

    -- 4. Vocabulary Fill Blanks #1
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 4, 'Complete the Sentences 1', 'Fill in the blanks with correct words', '{"text": "This ad is very ___. The message is ___. It creates an ___.", "blanks": [{"id": "blank1", "text": "persuasive", "options": ["persuasive", "subtle", "impulse", "sponsorship"], "correctAnswer": "persuasive"}, {"id": "blank2", "text": "subtle", "options": ["subtle", "persuasive", "impulse", "trigger"], "correctAnswer": "subtle"}, {"id": "blank3", "text": "impulse", "options": ["impulse", "persuasive", "subtle", "sponsorship"], "correctAnswer": "impulse"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    -- 5. Vocabulary Fill Blanks #2
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 5, 'Complete the Sentences 2', 'Fill in the blanks with correct words', '{"text": "The ___ is clear. This can ___ buying. We see ___.", "blanks": [{"id": "blank1", "text": "sponsorship", "options": ["sponsorship", "persuasive", "subtle", "impulse"], "correctAnswer": "sponsorship"}, {"id": "blank2", "text": "trigger", "options": ["trigger", "persuasive", "subtle", "sponsorship"], "correctAnswer": "trigger"}, {"id": "blank3", "text": "sponsorship", "options": ["sponsorship", "trigger", "persuasive", "subtle"], "correctAnswer": "sponsorship"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    -- 6. Grammar Explanation
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_explanation', 6, 'Modals for Deduction', 'Learn must/might/can''t for logical conclusions', '{"rules": "Use modal verbs to make logical deductions:\n\n- Must = very certain conclusion (must be targeting)\n- Might = possible conclusion (might be chosen)\n- Can''t = impossible conclusion (can''t be unbiased)\n- Use must/might/can''t + be + verb-ing for ongoing actions\n- Use must/might/can''t + be + past participle for passive\n- Expresses logical thinking, not facts", "examples": ["This advertisement must be targeting young adults.", "The colors might be chosen to create desire.", "This can''t be unbiased; it''s sponsored content.", "They must be trying to influence us.", "It might be working on some people."]}'::jsonb)
    RETURNING id INTO activity_id_var;

    -- 7. Grammar Sentences #1
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 7, 'Build Sentences 1', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'This advertisement must be targeting young adults', 'This advertisement must be targeting young adults.', '["This", "advertisement", "must", "be", "targeting", "young", "adults."]'::jsonb),
    (activity_id_var, 'The colors might be chosen to create desire', 'The colors might be chosen to create desire.', '["The", "colors", "might", "be", "chosen", "to", "create", "desire."]'::jsonb);

    -- 8. Grammar Sentences #2
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 8, 'Build Sentences 2', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'This cannot be unbiased it is sponsored content', 'This can''t be unbiased; it''s sponsored content.', '["This", "can''t", "be", "unbiased;", "it''s", "sponsored", "content."]'::jsonb),
    (activity_id_var, 'They must be trying to influence us', 'They must be trying to influence us.', '["They", "must", "be", "trying", "to", "influence", "us."]'::jsonb);

    -- 9. Speaking Practice
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'speaking_practice', 9, 'Talk About Ads', 'Practice talking about advertisements', '{"prompts": ["What food ads do you see?", "Do you buy things from ads?", "What drink commercials are funny?", "How do ads influence you?", "What makes an ad persuasive?"]}'::jsonb)
    RETURNING id INTO activity_id_var;

    -- 10. Speaking Improvement
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'speaking_improvement', 10, 'Speaking Improvement', 'Read the improved version of your speech', '{"type": "speaking_improvement", "similarityThreshold": 70}'::jsonb)
    RETURNING id INTO activity_id_var;
END $$;