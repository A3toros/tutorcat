-- =========================================
-- Pre-fill Database with Sample Lesson Data
-- B2-L91: Life priorities
-- =========================================

DELETE FROM grammar_sentences WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'B2-L91');
DELETE FROM vocabulary_items WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'B2-L91');
DELETE FROM lesson_activities WHERE lesson_id = 'B2-L91';
DELETE FROM lessons WHERE id = 'B2-L91';

INSERT INTO lessons (id, level, lesson_number, topic) VALUES
('B2-L91', 'B2', 91, 'Life priorities')
ON CONFLICT (id) DO UPDATE SET topic = EXCLUDED.topic;

DO $$
DECLARE
    lesson_id_var TEXT := 'B2-L91';
    activity_id_var UUID;
BEGIN
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'warm_up_speaking', 1, 'Core Priorities', 'Discuss what you won’t drop', '{"prompt": "What priority is so core you won’t drop it, and what will you postpone?"}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_intro', 2, 'Priority Words', 'Key words for priorities', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'priority', 'ลำดับความสำคัญ', NULL),
    (activity_id_var, 'urgent', 'เร่งด่วน', NULL),
    (activity_id_var, 'sacrifice', 'เสียสละ', NULL),
    (activity_id_var, 'align', 'สอดคล้อง', NULL),
    (activity_id_var, 'postpone', 'เลื่อนออกไป', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_matching_drag', 3, 'Match Priority Words', 'Match words with meanings', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'priority', 'ลำดับความสำคัญ', NULL),
    (activity_id_var, 'urgent', 'เร่งด่วน', NULL),
    (activity_id_var, 'sacrifice', 'เสียสละ', NULL),
    (activity_id_var, 'align', 'สอดคล้อง', NULL),
    (activity_id_var, 'postpone', 'เลื่อนออกไป', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 4, 'Complete the Sentences 1', 'Fill with the correct word', '{"text": "This ___ is core. I ____ less urgent tasks. I ____ other plans.", "blanks": [{"id": "blank1", "text": "priority", "options": ["priority", "urgent", "sacrifice", "postpone"], "correctAnswer": "priority"}, {"id": "blank2", "text": "postpone", "options": ["postpone", "align", "urgent", "sacrifice"], "correctAnswer": "postpone"}, {"id": "blank3", "text": "sacrifice", "options": ["sacrifice", "align", "priority", "urgent"], "correctAnswer": "sacrifice"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 5, 'Complete the Sentences 2', 'Fill with the correct word', '{"text": "I keep ____ tasks first. Choices must ____ with my values.", "blanks": [{"id": "blank1", "text": "urgent", "options": ["urgent", "priority", "postpone", "sacrifice"], "correctAnswer": "urgent"}, {"id": "blank2", "text": "align", "options": ["align", "priority", "urgent", "sacrifice"], "correctAnswer": "align"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_explanation', 6, 'Reason & Result (so/such…that)', 'Link priorities to outcomes', '{"rules": "Use so + adj/adv + that or such + (a/an) + noun + that to show strong cause → clear result.\\n- This priority is so important that I never drop it.\\n- It was such an urgent task that I postponed everything else.", "examples": ["This goal is so core that I plan around it.", "It was such an urgent request that I paused other tasks.", "The value is so strong that I won’t sacrifice it.", "It was such a clear priority that the team aligned fast.", "The deadline was so close that we postponed less urgent work."]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 7, 'Build Sentences 1', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'This goal is so core that I plan around it', 'This goal is so core that I plan around it.', '["This", "goal", "is", "so", "core", "that", "I", "plan", "around", "it."]'::jsonb),
    (activity_id_var, 'It was such an urgent task that I postponed everything else', 'It was such an urgent task that I postponed everything else.', '["It", "was", "such", "an", "urgent", "task", "that", "I", "postponed", "everything", "else."]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 8, 'Build Sentences 2', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'The value is so strong that I won’t sacrifice it', 'The value is so strong that I won’t sacrifice it.', '["The", "value", "is", "so", "strong", "that", "I", "won’t", "sacrifice", "it."]'::jsonb),
    (activity_id_var, 'It was such a clear priority that the team aligned fast', 'It was such a clear priority that the team aligned fast.', '["It", "was", "such", "a", "clear", "priority", "that", "the", "team", "aligned", "fast."]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'speaking_practice', 9, 'Talk About Priorities', 'Practice cause/effect', '{"prompts": ["What priority is so core you won’t drop it?", "What will you postpone when things get busy?", "When did urgency make you sacrifice something else?"]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (
      lesson_id,
      activity_type,
      activity_order,
      title,
      description,
      content
    ) VALUES (
      'B2-L91',
      'speaking_improvement',
      10,
      'Speaking Improvement',
      'Read the improved version of your speech',
      '{"type": "speaking_improvement", "similarityThreshold": 70}'::jsonb
    );
END $$;


