-- =========================================
-- Pre-fill Database with Sample Lesson Data
-- C1-L22: Critical Evaluation of Sources
-- =========================================
DELETE FROM lesson_activity_results WHERE lesson_id = 'C1-L22';
DELETE FROM user_progress WHERE lesson_id = 'C1-L22';
DELETE FROM lesson_history WHERE lesson_id = 'C1-L22';
DELETE FROM grammar_sentences WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'C1-L22');
DELETE FROM vocabulary_items WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'C1-L22');
DELETE FROM lesson_activities WHERE lesson_id = 'C1-L22';
DELETE FROM lessons WHERE id = 'C1-L22';

INSERT INTO lessons (id, level, lesson_number, topic) VALUES
('C1-L22', 'C1', 22, 'Critical Evaluation of Sources')
ON CONFLICT (id) DO UPDATE SET topic = EXCLUDED.topic;

DO $$
DECLARE
    lesson_id_var TEXT := 'C1-L22';
    activity_id_var UUID;
BEGIN
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'warm_up_speaking', 1, 'Source Evaluation', 'Discuss evaluating sources', '{"prompt": "What makes a source trustworthy?"}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_intro', 2, 'Source Evaluation Vocabulary', 'Learn vocabulary about source evaluation', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'evidence', 'หลักฐาน', NULL),
    (activity_id_var, 'authority', 'ผู้มีอำนาจ', NULL),
    (activity_id_var, 'validity', 'ความถูกต้อง', NULL),
    (activity_id_var, 'authenticity', 'ความแท้จริง', NULL),
    (activity_id_var, 'scrutiny', 'การตรวจสอบ', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_matching_drag', 3, 'Match Source Evaluation Words', 'Match English words with Thai meanings', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'evidence', 'หลักฐาน', NULL),
    (activity_id_var, 'authority', 'ผู้มีอำนาจ', NULL),
    (activity_id_var, 'validity', 'ความถูกต้อง', NULL),
    (activity_id_var, 'authenticity', 'ความแท้จริง', NULL),
    (activity_id_var, 'scrutiny', 'การตรวจสอบ', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 4, 'Complete the Sentences 1', 'Fill with the correct word', '{"text": "Strong ___ supports claims. Academic ___ ensures ___.", "blanks": [{"id": "blank1", "text": "evidence", "options": ["evidence", "authority", "validity", "authenticity"], "correctAnswer": "evidence"}, {"id": "blank2", "text": "scrutiny", "options": ["scrutiny", "evidence", "authority", "validity"], "correctAnswer": "scrutiny"}, {"id": "blank3", "text": "validity", "options": ["validity", "evidence", "authority", "authenticity"], "correctAnswer": "validity"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 5, 'Complete the Sentences 2', 'Fill with the correct word', '{"text": "Expert ___ increases trust. Document ___ confirms ___.", "blanks": [{"id": "blank1", "text": "authority", "options": ["authority", "evidence", "validity", "authenticity"], "correctAnswer": "authority"}, {"id": "blank2", "text": "authenticity", "options": ["authenticity", "evidence", "authority", "validity"], "correctAnswer": "authenticity"}, {"id": "blank3", "text": "validity", "options": ["validity", "evidence", "authority", "authenticity"], "correctAnswer": "validity"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_explanation', 6, 'Nominal Clauses', 'Learn about nominal clauses', '{"rules": "Nominal clauses function as nouns:\n- Subject: \"What you consider evidence matters.\"\n- Object: \"I believe that sources need evaluation.\"\n- Complement: \"The question is who influences trust.\"\n\nTypes:\n- That-clauses: \"I think that evidence is crucial.\"\n- Wh-clauses: \"What you trust determines your view.\"\n- Whether/if: \"The issue is whether sources are reliable.\"\n\nUse for:\n- Expressing opinions: \"What I consider is strong evidence.\"\n- Asking questions: \"Who influences what you trust?\"\n- Making statements: \"That sources matter is clear.\"", "examples": ["What you consider evidence determines your judgment.", "I believe that sources need careful evaluation.", "The question is who influences what you trust.", "Whether sources are reliable remains uncertain.", "That evidence matters is widely accepted."]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 7, 'Build Sentences 1', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'What you consider evidence determines your judgment.', 'What you consider evidence determines your judgment.', '["What", "you", "consider", "evidence", "determines", "your", "judgment."]'::jsonb),
    (activity_id_var, 'I believe that sources need careful evaluation.', 'I believe that sources need careful evaluation.', '["I", "believe", "that", "sources", "need", "careful", "evaluation."]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 8, 'Build Sentences 2', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'The question is who influences what you trust.', 'The question is who influences what you trust.', '["The", "question", "is", "who", "influences", "what", "you", "trust."]'::jsonb),
    (activity_id_var, 'Whether sources are reliable remains uncertain.', 'Whether sources are reliable remains uncertain.', '["Whether", "sources", "are", "reliable", "remains", "uncertain."]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'speaking_practice', 9, 'Discuss Source Evaluation', 'Practice speaking about evaluating sources', '{"prompts": ["What do you consider strong evidence?", "How do you judge credibility?", "Who influences what you trust?", "What criteria do you use to evaluate sources?", "How do you avoid unreliable information?"]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (
      lesson_id,
      activity_type,
      activity_order,
      title,
      description,
      content
    ) VALUES (
      'C1-L22',
      'speaking_improvement',
      10,
      'Speaking Improvement',
      'Read the improved version of your speech',
      '{"type": "speaking_improvement", "similarityThreshold": 70}'::jsonb
    );
END $$;
