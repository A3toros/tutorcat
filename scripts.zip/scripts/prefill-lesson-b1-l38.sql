-- =========================================
-- Pre-fill Database with Sample Lesson Data
-- B1-L38: Comparing Products
-- =========================================

DELETE FROM grammar_sentences WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'B1-L38');
DELETE FROM vocabulary_items WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'B1-L38');
DELETE FROM lesson_activities WHERE lesson_id = 'B1-L38';
DELETE FROM lessons WHERE id = 'B1-L38';

INSERT INTO lessons (id, level, lesson_number, topic) VALUES
('B1-L38', 'B1', 38, 'Comparing Products')
ON CONFLICT (id) DO UPDATE SET topic = EXCLUDED.topic;

DO $$
DECLARE
    lesson_id_var TEXT := 'B1-L38';
    activity_id_var UUID;
BEGIN
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'warm_up_speaking', 1, 'Choosing Products', 'Talk about making purchase decisions', '{"prompt": "How do you decide between two similar products?"}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_intro', 2, 'Product Words', 'Learn vocabulary about comparing products', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'durable', 'ทนทาน', NULL),
    (activity_id_var, 'affordable', 'ราคาไม่แพง', NULL),
    (activity_id_var, 'reliable', 'เชื่อถือได้', NULL),
    (activity_id_var, 'too pricey', 'แพงเกินไป', NULL),
    (activity_id_var, 'good enough', 'ดีพอ', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_matching_drag', 3, 'Match Product Words', 'Match words with meanings', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'durable', 'ทนทาน', NULL),
    (activity_id_var, 'affordable', 'ราคาไม่แพง', NULL),
    (activity_id_var, 'reliable', 'เชื่อถือได้', NULL),
    (activity_id_var, 'too pricey', 'แพงเกินไป', NULL),
    (activity_id_var, 'good enough', 'ดีพอ', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 4, 'Complete the Sentences 1', 'Fill with the correct word', '{"text": "This item is ___. That option is ___. The battery is ___.", "blanks": [{"id": "blank1", "text": "durable", "options": ["durable", "affordable", "reliable", "too pricey"], "correctAnswer": "durable"}, {"id": "blank2", "text": "affordable", "options": ["affordable", "too pricey", "good enough", "reliable"], "correctAnswer": "affordable"}, {"id": "blank3", "text": "reliable", "options": ["reliable", "affordable", "durable", "too pricey"], "correctAnswer": "reliable"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 5, 'Complete the Sentences 2', 'Fill with the correct word', '{"text": "That model is ___. This cheaper one is ___. The camera is ___ for daily use.", "blanks": [{"id": "blank1", "text": "too pricey", "options": ["too pricey", "affordable", "good enough", "durable"], "correctAnswer": "too pricey"}, {"id": "blank2", "text": "affordable", "options": ["affordable", "too pricey", "reliable", "durable"], "correctAnswer": "affordable"}, {"id": "blank3", "text": "good enough", "options": ["good enough", "durable", "affordable", "too pricey"], "correctAnswer": "good enough"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    -- Grammar Explanation: Too / Enough (product comparison)
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_explanation', 6, 'Too / Enough for Products', 'Use too + adj for excess; adj + enough for sufficiency', '{"rules": "Use too + adjective: too pricey. Use adjective + enough: reliable enough. Use enough + noun: enough value.\\nKeep sentences clear and natural.", "examples": ["This phone is too pricey for my budget.", "It is reliable enough for work calls.", "We have enough features for daily use.", "The screen is not bright enough outside.", "The build is strong enough to last."]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 7, 'Build Sentences 1', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'This phone is too pricey for my budget', 'This phone is too pricey for my budget', '["This", "phone", "is", "too", "pricey", "for", "my", "budget"]'::jsonb),
    (activity_id_var, 'It is reliable enough for work calls', 'It is reliable enough for work calls', '["It", "is", "reliable", "enough", "for", "work", "calls"]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 8, 'Build Sentences 2', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'We have enough features for daily use', 'We have enough features for daily use', '["We", "have", "enough", "features", "for", "daily", "use"]'::jsonb),
    (activity_id_var, 'The screen is not bright enough outside', 'The screen is not bright enough outside', '["The", "screen", "is", "not", "bright", "enough", "outside"]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'speaking_practice', 9, 'Talk About Products', 'Practice talking about product choices', '{"prompts": ["How do you decide between two similar products?", "When is quality worth paying more?", "Describe something that was not good enough and why."]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (
      lesson_id,
      activity_type,
      activity_order,
      title,
      description,
      content
    ) VALUES (
      'B1-L38',
      'speaking_improvement',
      10,
      'Speaking Improvement',
      'Read the improved version of your speech',
      '{"type": "speaking_improvement", "similarityThreshold": 70}'::jsonb
    );
END $$;

