-- ===== LESSON B1-L70 =====

-- =========================================
-- Pre-fill Database with Sample Lesson Data
-- B1-L70: Career Changes
-- =========================================

DELETE FROM lesson_activity_results WHERE lesson_id = 'B1-L70';
DELETE FROM user_progress WHERE lesson_id = 'B1-L70';
DELETE FROM lesson_history WHERE lesson_id = 'B1-L70';
DELETE FROM grammar_sentences WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'B1-L70');
DELETE FROM vocabulary_items WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'B1-L70');
DELETE FROM lesson_activities WHERE lesson_id = 'B1-L70';
DELETE FROM lessons WHERE id = 'B1-L70';

INSERT INTO lessons (id, level, lesson_number, topic) VALUES
('B1-L70', 'B1', 70, 'Career Changes')
ON CONFLICT (id) DO UPDATE SET topic = EXCLUDED.topic;

DO $$
DECLARE
    lesson_id_var TEXT := 'B1-L70';
    activity_id_var UUID;
BEGIN
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'warm_up_speaking', 1, 'Career Transitions', 'Talk about changing jobs or careers', '{"prompt": "Have you changed career paths?"}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_intro', 2, 'Career Change Words', 'Learn words related to career transitions', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'switch', 'เปลี่ยน', NULL),
    (activity_id_var, 'promote', 'เลื่อนตำแหน่ง', NULL),
    (activity_id_var, 'resign', 'ลาออก', NULL),
    (activity_id_var, 'retrain', 'ฝึกใหม่', NULL),
    (activity_id_var, 'adjust', 'ปรับตัว', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_matching_drag', 3, 'Match Career Words', 'Match career change words', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'switch', 'เปลี่ยน', NULL),
    (activity_id_var, 'promote', 'เลื่อนตำแหน่ง', NULL),
    (activity_id_var, 'resign', 'ลาออก', NULL),
    (activity_id_var, 'retrain', 'ฝึกใหม่', NULL),
    (activity_id_var, 'adjust', 'ปรับตัว', NULL);

    -- 4. Vocabulary Fill Blanks #1
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 4, 'Complete the Sentences 1', 'Fill in the blanks with correct words', '{"text": "I want to ___ careers. She will be ___. They need to ___.", "blanks": [{"id": "blank1", "text": "switch", "options": ["switch", "promote", "resign", "retrain"], "correctAnswer": "switch"}, {"id": "blank2", "text": "promoted", "options": ["promoted", "switch", "resign", "retrain"], "correctAnswer": "promoted"}, {"id": "blank3", "text": "retrain", "options": ["retrain", "switch", "promote", "resign"], "correctAnswer": "retrain"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    -- 5. Vocabulary Fill Blanks #2
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 5, 'Complete the Sentences 2', 'Fill in the blanks with correct words', '{"text": "He decided to ___. I need to ___ to the new job. They ___ from their positions.", "blanks": [{"id": "blank1", "text": "resign", "options": ["resign", "switch", "promote", "adjust"], "correctAnswer": "resign"}, {"id": "blank2", "text": "adjust", "options": ["adjust", "switch", "promote", "resign"], "correctAnswer": "adjust"}, {"id": "blank3", "text": "resigned", "options": ["resigned", "switch", "promote", "adjust"], "correctAnswer": "resigned"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    -- 6. Grammar Explanation
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_explanation', 6, 'Present Perfect for Experiences', 'Learn present perfect for life experiences', '{"rules": "Use present perfect to talk about life experiences:\n\n- Form: have/has + past participle (have switched, has been promoted)\n- Use for experiences in your life (I have switched jobs)\n- Use ever/never for questions/negatives (Have you ever...?)\n- Use for/since with time periods (for 5 years, since 2020)\n- Don''t use specific past time (yesterday, last week)", "examples": ["I have switched jobs twice.", "She has been promoted three times.", "They have retrained for new careers.", "Have you ever changed careers?", "I have worked here for 5 years."]}'::jsonb)
    RETURNING id INTO activity_id_var;

    -- 7. Grammar Sentences #1
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 7, 'Build Sentences 1', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'I have switched jobs twice', 'I have switched jobs twice.', '["I", "have", "switched", "jobs", "twice."]'::jsonb),
    (activity_id_var, 'She has been promoted three times', 'She has been promoted three times.', '["She", "has", "been", "promoted", "three", "times."]'::jsonb);

    -- 8. Grammar Sentences #2
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 8, 'Build Sentences 2', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'They have retrained for new careers', 'They have retrained for new careers.', '["They", "have", "retrained", "for", "new", "careers."]'::jsonb),
    (activity_id_var, 'I have worked here for 5 years', 'I have worked here for 5 years.', '["I", "have", "worked", "here", "for", "5", "years."]'::jsonb);

    -- 9. Speaking Practice
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'speaking_practice', 9, 'Talk About Future Jobs', 'Practice talking about work and jobs', '{"prompts": ["What job does your father have?", "Do you want to be a teacher?", "Where do you want to work?", "Have you ever changed jobs?", "What career would you like to switch to?"]}'::jsonb)
    RETURNING id INTO activity_id_var;

    -- 10. Speaking Improvement
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'speaking_improvement', 10, 'Speaking Improvement', 'Read the improved version of your speech', '{"type": "speaking_improvement", "similarityThreshold": 70}'::jsonb)
    RETURNING id INTO activity_id_var;
END $$;


-- ===== B2 MISSING LESSONS 51-60 and 81-90 =====