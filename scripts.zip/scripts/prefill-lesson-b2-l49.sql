-- =========================================
-- Pre-fill Database with Sample Lesson Data
-- B2-L49: Cultural differences (signals)
-- =========================================

DELETE FROM grammar_sentences WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'B2-L49');
DELETE FROM vocabulary_items WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'B2-L49');
DELETE FROM lesson_activities WHERE lesson_id = 'B2-L49';
DELETE FROM lessons WHERE id = 'B2-L49';

INSERT INTO lessons (id, level, lesson_number, topic) VALUES
('B2-L49', 'B2', 49, 'Cultural differences (signals)')
ON CONFLICT (id) DO UPDATE SET topic = EXCLUDED.topic;

DO $$
DECLARE
    lesson_id_var TEXT := 'B2-L49';
    activity_id_var UUID;
BEGIN
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'warm_up_speaking', 1, 'Misreading Norms', 'Talk about culture cues', '{"prompt": "How can you tell you misread a norm, and who helps you adjust?"}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_intro', 2, 'Culture Signal Words', 'Key words for cues and adjustments', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'norm', 'บรรทัดฐาน', NULL),
    (activity_id_var, 'gesture', 'ท่าทาง/ภาษากาย', NULL),
    (activity_id_var, 'misread', 'อ่านผิด/เข้าใจผิด', NULL),
    (activity_id_var, 'adapt', 'ปรับตัว', NULL),
    (activity_id_var, 'explain', 'อธิบาย', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_matching_drag', 3, 'Match Culture Signal Words', 'Match words with meanings', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'norm', 'บรรทัดฐาน', NULL),
    (activity_id_var, 'gesture', 'ท่าทาง/ภาษากาย', NULL),
    (activity_id_var, 'misread', 'อ่านผิด/เข้าใจผิด', NULL),
    (activity_id_var, 'adapt', 'ปรับตัว', NULL),
    (activity_id_var, 'explain', 'อธิบาย', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 4, 'Complete the Sentences 1', 'Fill with the correct word', '{"text": "I watch each ___. I try not to ___ a ___.", "blanks": [{"id": "blank1", "text": "gesture", "options": ["gesture", "norm", "adapt", "explain"], "correctAnswer": "gesture"}, {"id": "blank2", "text": "misread", "options": ["misread", "adapt", "gesture", "explain"], "correctAnswer": "misread"}, {"id": "blank3", "text": "norm", "options": ["norm", "gesture", "adapt", "explain"], "correctAnswer": "norm"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 5, 'Complete the Sentences 2', 'Fill with the correct word', '{"text": "Friends ___ and help me ___.", "blanks": [{"id": "blank1", "text": "explain", "options": ["explain", "adapt", "misread", "norm"], "correctAnswer": "explain"}, {"id": "blank2", "text": "adapt", "options": ["adapt", "explain", "gesture", "norm"], "correctAnswer": "adapt"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_explanation', 6, 'Modals for Deduction', 'Read cues to avoid mistakes', '{"rules": "Use must/might/can’t + base verb to guess now; use modal + have + past participle for past clues.\\n- I must have misread that gesture.\\n- They might be waiting for a cue.\\n- This can’t be the norm here.", "examples": ["I must have misread the norm; people looked confused.", "She might be expecting a different greeting.", "He can’t be offended; he is still smiling.", "They must have explained it before; I forgot.", "This might have been a common gesture; I will adapt."]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 7, 'Build Sentences 1', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'I must have misread the norm; people looked confused', 'I must have misread the norm; people looked confused.', '["I", "must", "have", "misread", "the", "norm;", "people", "looked", "confused."]'::jsonb),
    (activity_id_var, 'She might be expecting a different greeting', 'She might be expecting a different greeting.', '["She", "might", "be", "expecting", "a", "different", "greeting."]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 8, 'Build Sentences 2', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'He can’t be offended; he is still smiling', 'He can’t be offended; he is still smiling.', '["He", "can’t", "be", "offended;", "he", "is", "still", "smiling."]'::jsonb),
    (activity_id_var, 'This might have been a common gesture; I will adapt', 'This might have been a common gesture; I will adapt.', '["This", "might", "have", "been", "a", "common", "gesture;", "I", "will", "adapt."]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'speaking_practice', 9, 'Talk About Cultural Signals', 'Practice deduction', '{"prompts": ["How can you tell you misread a norm?", "Who helps you adjust when you travel?", "What do you do when a gesture confuses you?"]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (
      lesson_id,
      activity_type,
      activity_order,
      title,
      description,
      content
    ) VALUES (
      'B2-L49',
      'speaking_improvement',
      10,
      'Speaking Improvement',
      'Read the improved version of your speech',
      '{"type": "speaking_improvement", "similarityThreshold": 70}'::jsonb
    );
END $$;


