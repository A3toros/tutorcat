-- =========================================
-- Insert All 100 Achievements
-- =========================================
-- This script inserts all 100 achievements into the database
-- Run this after the achievements system structure is created
-- =========================================

DO $$
BEGIN
    -- Ensure requirement_count column exists (safety check)
    IF NOT EXISTS (
        SELECT 1 FROM information_schema.columns 
        WHERE table_name = 'achievements' AND column_name = 'requirement_count'
    ) THEN
        ALTER TABLE achievements 
        ADD COLUMN requirement_count INTEGER DEFAULT NULL;
        
        RAISE NOTICE 'Added requirement_count column to achievements table';
    END IF;

    -- Lessons Category (40 achievements)
    INSERT INTO achievements (code, name, description, icon, category, requirement_type, requirement_value, rarity, points, requirement_count) VALUES
    ('first_steps', 'First Steps', 'Complete your first lesson', '🎯', 'lessons', 'lesson_count', 1, 'common', 10, NULL),
    ('getting_started', 'Getting Started', 'Complete 3 lessons', '🚀', 'lessons', 'lesson_count', 3, 'common', 15, NULL),
    ('on_a_roll', 'On a Roll', 'Complete 5 lessons', '⭐', 'lessons', 'lesson_count', 5, 'common', 20, NULL),
    ('making_progress', 'Making Progress', 'Complete 10 lessons', '📈', 'lessons', 'lesson_count', 10, 'common', 25, NULL),
    ('halfway_there', 'Halfway There', 'Complete 25 lessons', '🎪', 'lessons', 'lesson_count', 25, 'rare', 30, NULL),
    ('almost_there', 'Almost There', 'Complete 50 lessons', '🏆', 'lessons', 'lesson_count', 50, 'rare', 40, NULL),
    ('century_club', 'Century Club', 'Complete 100 lessons', '💯', 'lessons', 'lesson_count', 100, 'epic', 50, NULL),
    ('lesson_master', 'Lesson Master', 'Complete 200 lessons', '👑', 'lessons', 'lesson_count', 200, 'legendary', 100, NULL),
    ('perfect_score', 'Perfect Score', 'Score 100% on a lesson', '✨', 'lessons', 'perfect_score_count', 1, 'common', 15, NULL),
    ('perfectionist', 'Perfectionist', 'Score 100% on 5 lessons', '🌟', 'lessons', 'perfect_score_count', 5, 'rare', 30, NULL),
    ('flawless', 'Flawless', 'Score 100% on 10 lessons', '💎', 'lessons', 'perfect_score_count', 10, 'epic', 50, NULL),
    ('excellent', 'Excellent', 'Score 90%+ on 10 lessons', '🎖️', 'lessons', 'score_threshold_count', 90, 'rare', 25, 10),
    ('above_average', 'Above Average', 'Score 80%+ on 20 lessons', '📊', 'lessons', 'score_threshold_count', 80, 'common', 20, 20),
    ('high_achiever', 'High Achiever', 'Average 90%+ across 25 lessons', '🏅', 'lessons', 'score_average', 90, 'epic', 45, NULL),
    ('a1_explorer', 'A1 Explorer', 'Complete 5 A1 lessons', '🔍', 'lessons', 'lesson_count', 5, 'common', 15, NULL),
    ('a1_master', 'A1 Master', 'Complete all A1 lessons', '🥇', 'lessons', 'level_complete', 0, 'rare', 40, NULL),
    ('a2_explorer', 'A2 Explorer', 'Complete 5 A2 lessons', '🔍', 'lessons', 'lesson_count', 5, 'common', 15, NULL),
    ('a2_master', 'A2 Master', 'Complete all A2 lessons', '🥇', 'lessons', 'level_complete', 0, 'rare', 40, NULL),
    ('b1_explorer', 'B1 Explorer', 'Complete 5 B1 lessons', '🔍', 'lessons', 'lesson_count', 5, 'common', 15, NULL),
    ('b1_master', 'B1 Master', 'Complete all B1 lessons', '🥇', 'lessons', 'level_complete', 0, 'rare', 40, NULL),
    ('b2_explorer', 'B2 Explorer', 'Complete 5 B2 lessons', '🔍', 'lessons', 'lesson_count', 5, 'common', 15, NULL),
    ('b2_master', 'B2 Master', 'Complete all B2 lessons', '🥇', 'lessons', 'level_complete', 0, 'rare', 40, NULL),
    ('c1_explorer', 'C1 Explorer', 'Complete 5 C1 lessons', '🔍', 'lessons', 'lesson_count', 5, 'common', 15, NULL),
    ('c1_master', 'C1 Master', 'Complete all C1 lessons', '🥇', 'lessons', 'level_complete', 0, 'rare', 40, NULL),
    ('c2_explorer', 'C2 Explorer', 'Complete 5 C2 lessons', '🔍', 'lessons', 'lesson_count', 5, 'common', 15, NULL),
    ('c2_master', 'C2 Master', 'Complete all C2 lessons', '🥇', 'lessons', 'level_complete', 0, 'rare', 40, NULL),
    ('multi_level', 'Multi-Level', 'Complete lessons in 3 different levels', '🌍', 'lessons', 'lesson_count', 3, 'rare', 30, NULL),
    ('all_levels', 'All Levels', 'Complete lessons in all 6 levels', '🌐', 'lessons', 'lesson_count', 6, 'epic', 60, NULL),
    ('quick_study', 'Quick Study', 'Complete 3 lessons in one day', '⚡', 'lessons', 'lesson_count', 3, 'common', 20, NULL),
    ('marathon', 'Marathon', 'Complete 5 lessons in one day', '🏃', 'lessons', 'lesson_count', 5, 'rare', 35, NULL),
    ('weekend_warrior', 'Weekend Warrior', 'Complete 5 lessons on weekends', '🎮', 'lessons', 'lesson_count', 5, 'rare', 30, NULL),
    ('first_try', 'First Try', 'Pass 1 lesson on first attempt', '🎲', 'lessons', 'lesson_count', 1, 'common', 15, NULL),
    ('quick_learner', 'Quick Learner', 'Pass 5 lessons on first attempt', '🧠', 'lessons', 'lesson_count', 5, 'rare', 30, NULL),
    ('natural_talent', 'Natural Talent', 'Pass 10 lessons on first attempt', '💫', 'lessons', 'lesson_count', 10, 'epic', 50, NULL),
    ('speed_learner', 'Speed Learner', 'Complete 1 lesson in under 15 minutes', '⏱️', 'lessons', 'lesson_count', 1, 'common', 15, NULL),
    ('efficient', 'Efficient', 'Complete 5 lessons averaging under 15 minutes', '⚙️', 'lessons', 'lesson_count', 5, 'rare', 30, NULL),
    ('quick_thinker', 'Quick Thinker', 'Complete 10 lessons in under 15 minutes each', '🧩', 'lessons', 'lesson_count', 10, 'epic', 45, NULL),
    ('grammar_expert', 'Grammar Expert', 'Complete 20 grammar activities', '📝', 'lessons', 'activity_count', 20, 'rare', 35, NULL),
    ('vocabulary_pro', 'Vocabulary Pro', 'Complete 20 vocabulary activities', '📚', 'lessons', 'activity_count', 20, 'rare', 35, NULL),
    ('speaking_champion', 'Speaking Champion', 'Complete 20 speaking activities', '🎤', 'lessons', 'activity_count', 20, 'rare', 35, NULL)
    ON CONFLICT (code) DO NOTHING;

    -- Streaks Category (10 achievements)
    -- Note: Streak achievements require date-based calculations, simplified to lesson_count for now
    INSERT INTO achievements (code, name, description, icon, category, requirement_type, requirement_value, rarity, points, requirement_count) VALUES
    ('streak_starter', 'Streak Starter', 'Complete lessons for 3 consecutive days', '🔥', 'streaks', 'lesson_count', 3, 'common', 20, NULL),
    ('week_warrior', 'Week Warrior', 'Complete lessons for 7 consecutive days', '📅', 'streaks', 'lesson_count', 7, 'rare', 30, NULL),
    ('two_week_champion', 'Two Week Champion', 'Complete lessons for 14 consecutive days', '🏅', 'streaks', 'lesson_count', 14, 'rare', 40, NULL),
    ('monthly_master', 'Monthly Master', 'Complete lessons for 30 consecutive days', '📆', 'streaks', 'lesson_count', 30, 'epic', 60, NULL),
    ('quarter_champion', 'Quarter Champion', 'Complete lessons for 90 consecutive days', '🎯', 'streaks', 'lesson_count', 90, 'legendary', 100, NULL),
    ('perfect_week', 'Perfect Week', 'Complete lesson every day for 7 days', '✨', 'streaks', 'lesson_count', 7, 'rare', 35, NULL),
    ('perfect_month', 'Perfect Month', 'Complete lesson every day for 30 days', '🌟', 'streaks', 'lesson_count', 30, 'epic', 70, NULL),
    ('unstoppable', 'Unstoppable', 'Complete lessons for 100 consecutive days', '💪', 'streaks', 'lesson_count', 100, 'legendary', 120, NULL),
    ('dedicated', 'Dedicated', 'Complete lessons on 50 different days', '📊', 'streaks', 'lesson_count', 50, 'rare', 40, NULL),
    ('consistent', 'Consistent', 'Complete lessons on 100 different days', '📈', 'streaks', 'lesson_count', 100, 'epic', 60, NULL)
    ON CONFLICT (code) DO NOTHING;

    -- Score & Performance Category (20 achievements)
    INSERT INTO achievements (code, name, description, icon, category, requirement_type, requirement_value, rarity, points, requirement_count) VALUES
    ('good_start', 'Good Start', 'Score 70%+ on first lesson', '👍', 'performance', 'score_average', 70, 'common', 15, NULL),
    ('above_average_perf', 'Above Average', 'Score 80%+ on 5 lessons', '📊', 'performance', 'score_threshold_count', 80, 'common', 20, 5),
    ('outstanding', 'Outstanding', 'Score 95%+ on 5 lessons', '⭐', 'performance', 'score_threshold_count', 95, 'rare', 35, 5),
    ('perfect_performance', 'Perfect Performance', 'Score 100% on 3 lessons', '💯', 'performance', 'perfect_score_count', 3, 'rare', 30, NULL),
    ('consistent_performer', 'Consistent Performer', 'Score 80%+ on 10 lessons', '🎯', 'performance', 'score_threshold_count', 80, 'rare', 30, 10),
    ('master_student', 'Master Student', 'Average 95%+ across 25 lessons', '👑', 'performance', 'score_average', 95, 'epic', 60, NULL),
    ('elite_performer', 'Elite Performer', 'Score 100% on 15 lessons', '🏆', 'performance', 'perfect_score_count', 15, 'epic', 70, NULL),
    ('grammar_guru', 'Grammar Guru', 'Score 90%+ on 10 grammar activities', '📝', 'performance', 'score_threshold_count', 90, 'rare', 35, 10),
    ('vocabulary_master', 'Vocabulary Master', 'Score 90%+ on 10 vocabulary activities', '📚', 'performance', 'score_threshold_count', 90, 'rare', 35, 10),
    ('speaking_star', 'Speaking Star', 'Score 90%+ on 10 speaking activities', '🎤', 'performance', 'score_threshold_count', 90, 'rare', 35, 10),
    ('activity_ace', 'Activity Ace', 'Complete 30 activities with 100% score', '🎯', 'performance', 'perfect_score_count', 30, 'epic', 55, NULL),
    ('no_mistakes', 'No Mistakes', 'Complete 5 lessons with 100% score', '✨', 'performance', 'perfect_score_count', 5, 'rare', 30, NULL),
    ('quick_learner_perf', 'Quick Learner', 'Complete 5 lessons with 90%+ on first attempt', '🧠', 'performance', 'score_threshold_count', 90, 'rare', 30, 5),
    ('improvement_master', 'Improvement Master', 'Improve score by 20%+ on 5 lessons', '📈', 'performance', 'lesson_count', 5, 'rare', 30, NULL),
    ('steady_progress', 'Steady Progress', 'Improve score on 10 consecutive lessons', '📊', 'performance', 'lesson_count', 10, 'epic', 45, NULL),
    ('top_performer', 'Top Performer', 'Score in top 10% of all lessons', '🥇', 'performance', 'score_average', 95, 'epic', 60, NULL),
    ('excellence', 'Excellence', 'Maintain 90%+ average across 50 lessons', '🌟', 'performance', 'score_average', 90, 'legendary', 80, NULL),
    ('precision', 'Precision', 'Score exactly 100% on 10 lessons', '🎯', 'performance', 'perfect_score_count', 10, 'epic', 50, NULL),
    ('consistency_king', 'Consistency King', 'Score 85%+ on 30 lessons', '👑', 'performance', 'score_threshold_count', 85, 'epic', 55, 30),
    ('perfection_seeker', 'Perfection Seeker', 'Score 100% on 25 lessons', '💎', 'performance', 'perfect_score_count', 25, 'legendary', 90, NULL)
    ON CONFLICT (code) DO NOTHING;

    -- Stars & Rewards Category (10 achievements)
    INSERT INTO achievements (code, name, description, icon, category, requirement_type, requirement_value, rarity, points, requirement_count) VALUES
    ('star_collector', 'Star Collector', 'Earn 10 stars', '⭐', 'stars', 'stars', 10, 'common', 20, NULL),
    ('star_enthusiast', 'Star Enthusiast', 'Earn 25 stars', '🌟', 'stars', 'stars', 25, 'common', 25, NULL),
    ('star_master', 'Star Master', 'Earn 50 stars', '💫', 'stars', 'stars', 50, 'rare', 35, NULL),
    ('star_champion', 'Star Champion', 'Earn 100 stars', '🏆', 'stars', 'stars', 100, 'rare', 45, NULL),
    ('star_legend', 'Star Legend', 'Earn 200 stars', '👑', 'stars', 'stars', 200, 'epic', 60, NULL),
    ('star_hero', 'Star Hero', 'Earn 300 stars', '🦸', 'stars', 'stars', 300, 'epic', 70, NULL),
    ('star_icon', 'Star Icon', 'Earn 500 stars', '⭐', 'stars', 'stars', 500, 'legendary', 90, NULL),
    ('three_star_master', 'Three Star Master', 'Earn 3 stars on 10 lessons', '💯', 'stars', 'lesson_count', 10, 'rare', 35, NULL),
    ('perfect_star', 'Perfect Star', 'Earn 3 stars on 25 lessons', '✨', 'stars', 'lesson_count', 25, 'epic', 55, NULL),
    ('star_collection', 'Star Collection', 'Earn 3 stars on 50 lessons', '🌟', 'stars', 'lesson_count', 50, 'legendary', 80, NULL)
    ON CONFLICT (code) DO NOTHING;

    -- Titles & Progression Category (10 achievements)
    INSERT INTO achievements (code, name, description, icon, category, requirement_type, requirement_value, rarity, points, requirement_count) VALUES
    ('title_earner', 'Title Earner', 'Earn your first title', '🏷️', 'titles', 'lesson_count', 1, 'common', 15, NULL),
    ('title_collector', 'Title Collector', 'Earn 5 different titles', '📜', 'titles', 'lesson_count', 5, 'common', 25, NULL),
    ('title_master', 'Title Master', 'Earn 10 different titles', '👑', 'titles', 'lesson_count', 10, 'rare', 35, NULL),
    ('title_legend', 'Title Legend', 'Earn 20 different titles', '🌟', 'titles', 'lesson_count', 20, 'epic', 55, NULL),
    ('level_up', 'Level Up', 'Reach A2 level', '⬆️', 'titles', 'lesson_count', 10, 'common', 20, NULL),
    ('advanced', 'Advanced', 'Reach B1 level', '📈', 'titles', 'lesson_count', 20, 'rare', 30, NULL),
    ('expert', 'Expert', 'Reach B2 level', '🎓', 'titles', 'lesson_count', 30, 'rare', 40, NULL),
    ('master_level', 'Master Level', 'Reach C1 level', '👑', 'titles', 'lesson_count', 40, 'epic', 60, NULL),
    ('grandmaster', 'Grandmaster', 'Reach C2 level', '🏆', 'titles', 'lesson_count', 50, 'epic', 70, NULL),
    ('tutorcat', 'TutorCat', 'Reach the ultimate title', '🐱', 'titles', 'lesson_count', 60, 'legendary', 100, NULL)
    ON CONFLICT (code) DO NOTHING;

    -- Activity Types Category (10 achievements)
    INSERT INTO achievements (code, name, description, icon, category, requirement_type, requirement_value, rarity, points, requirement_count) VALUES
    ('warmup_warrior', 'Warmup Warrior', 'Complete 10 warmup activities', '🔥', 'activities', 'activity_count', 10, 'common', 20, NULL),
    ('vocab_veteran', 'Vocab Veteran', 'Complete 30 vocabulary activities', '📚', 'activities', 'activity_count', 30, 'rare', 35, NULL),
    ('grammar_geek', 'Grammar Geek', 'Complete 30 grammar activities', '📝', 'activities', 'activity_count', 30, 'rare', 35, NULL),
    ('speaking_specialist', 'Speaking Specialist', 'Complete 30 speaking activities', '🎤', 'activities', 'activity_count', 30, 'rare', 35, NULL),
    ('listening_learner', 'Listening Learner', 'Complete 10 listening activities', '👂', 'activities', 'activity_count', 10, 'common', 20, NULL),
    ('reading_rookie', 'Reading Rookie', 'Complete 10 reading activities', '📖', 'activities', 'activity_count', 10, 'common', 20, NULL),
    ('activity_enthusiast', 'Activity Enthusiast', 'Complete 100 activities', '🎯', 'activities', 'activity_count', 100, 'epic', 60, NULL),
    ('activity_master', 'Activity Master', 'Complete 200 activities', '👑', 'activities', 'activity_count', 200, 'epic', 70, NULL),
    ('all_around', 'All Around', 'Complete all activity types', '🌐', 'activities', 'activity_count', 6, 'rare', 40, NULL),
    ('completionist', 'Completionist', 'Complete all lessons', '💯', 'activities', 'lesson_count', 100, 'legendary', 100, NULL)
    ON CONFLICT (code) DO NOTHING;

    RAISE NOTICE 'Inserted all 100 achievements successfully!';
END $$;

