-- =========================================
-- Pre-fill Database with Sample Lesson Data
-- A2-L51: Carrying Luggage
-- =========================================

DELETE FROM grammar_sentences WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'A2-L51');
DELETE FROM vocabulary_items WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'A2-L51');
DELETE FROM lesson_activities WHERE lesson_id = 'A2-L51';
DELETE FROM lessons WHERE id = 'A2-L51';

INSERT INTO lessons (id, level, lesson_number, topic) VALUES
('A2-L51', 'A2', 51, 'Carrying Luggage')
ON CONFLICT (id) DO UPDATE SET topic = EXCLUDED.topic;

DO $$
DECLARE
    lesson_id_var TEXT := 'A2-L51';
    activity_id_var UUID;
BEGIN
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'warm_up_speaking', 1, 'Bags', 'Talk about carrying bags', '{"prompt": "Do you travel with lighter or heavier luggage?"}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_intro', 2, 'Luggage Words', 'Learn luggage vocabulary', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'heavy', 'หนัก', NULL),
    (activity_id_var, 'light', 'เบา', NULL),
    (activity_id_var, 'backpack', 'กระเป๋าเป้', NULL),
    (activity_id_var, 'suitcase', 'กระเป๋าเดินทาง', NULL),
    (activity_id_var, 'handle', 'หูหิ้ว', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_matching_drag', 3, 'Match Luggage Words', 'Match luggage words', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'heavy', 'หนัก', NULL),
    (activity_id_var, 'light', 'เบา', NULL),
    (activity_id_var, 'backpack', 'กระเป๋าเป้', NULL),
    (activity_id_var, 'suitcase', 'กระเป๋าเดินทาง', NULL),
    (activity_id_var, 'handle', 'หูหิ้ว', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 4, 'Complete the Sentences 1', 'Fill with the correct word', '{"text": "This bag is ___. That one is ___. I carry a ___ with a strong ___.", "blanks": [{"id": "blank1", "text": "heavy", "options": ["heavy", "light", "backpack", "handle"], "correctAnswer": "heavy"}, {"id": "blank2", "text": "light", "options": ["light", "heavy", "backpack", "handle"], "correctAnswer": "light"}, {"id": "blank3", "text": "backpack", "options": ["backpack", "suitcase", "handle", "light"], "correctAnswer": "backpack"}, {"id": "blank4", "text": "handle", "options": ["handle", "backpack", "suitcase", "heavy"], "correctAnswer": "handle"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 5, 'Complete the Sentences 2', 'Fill with the correct word', '{"text": "My ___ is full. I like a ___ bag. The ___ is broken.", "blanks": [{"id": "blank1", "text": "suitcase", "options": ["suitcase", "light", "heavy", "handle"], "correctAnswer": "suitcase"}, {"id": "blank2", "text": "light", "options": ["light", "heavy", "handle", "backpack"], "correctAnswer": "light"}, {"id": "blank3", "text": "handle", "options": ["handle", "suitcase", "heavy", "light"], "correctAnswer": "handle"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_explanation', 6, 'Comparatives (weight)', 'Compare bag weights', '{"rules": "Use comparatives: heavy → heavier; light → lighter.\nPattern: X is heavier than Y.\nUse than after the comparative.", "examples": ["This bag is heavier than that one.", "My backpack is lighter than your suitcase.", "His suitcase is heavier than mine.", "This handle is stronger than the old one.", "A lighter bag is easier to carry."]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 7, 'Build Sentences 1', 'Arrange words', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'This bag is heavier than that one', 'This bag is heavier than that one.', '["This", "bag", "is", "heavier", "than", "that", "one."]'::jsonb),
    (activity_id_var, 'My backpack is lighter than your suitcase', 'My backpack is lighter than your suitcase.', '["My", "backpack", "is", "lighter", "than", "your", "suitcase."]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 8, 'Build Sentences 2', 'Arrange words', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'His suitcase is heavier than mine', 'His suitcase is heavier than mine.', '["His", "suitcase", "is", "heavier", "than", "mine."]'::jsonb),
    (activity_id_var, 'A lighter bag is easier to carry', 'A lighter bag is easier to carry.', '["A", "lighter", "bag", "is", "easier", "to", "carry."]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'speaking_practice', 9, 'Talk About Luggage', 'Practice comparing bags', '{"prompts": ["Do you travel with lighter or heavier luggage?", "Which bag is easier to carry?", "Is a backpack more comfortable than a suitcase?", "How much luggage do you usually take?", "What items make your bag heavier?"]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (
      lesson_id,
      activity_type,
      activity_order,
      title,
      description,
      content
    ) VALUES (
      'A2-L51',
      'speaking_improvement',
      10,
      'Speaking Improvement',
      'Read the improved version of your speech',
      '{"type": "speaking_improvement", "similarityThreshold": 70}'::jsonb
    );
END $$;

