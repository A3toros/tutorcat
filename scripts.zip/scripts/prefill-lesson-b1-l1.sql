-- =========================================
-- Pre-fill Database with Sample Lesson Data
-- B1-L1: Life Experiences
-- =========================================

-- Clear existing sample data for B1-L1 (optional - comment out if you want to keep existing data)
DELETE FROM grammar_sentences WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'B1-L1');
DELETE FROM vocabulary_items WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'B1-L1');
DELETE FROM lesson_activities WHERE lesson_id = 'B1-L1';
DELETE FROM lessons WHERE id = 'B1-L1';

INSERT INTO lessons (id, level, lesson_number, topic) VALUES
('B1-L1', 'B1', 1, 'Life Experiences')
ON CONFLICT (id) DO UPDATE SET topic = EXCLUDED.topic;

DO $$
DECLARE
    lesson_id_var TEXT := 'B1-L1';
    activity_id_var UUID;
BEGIN
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content) VALUES (lesson_id_var, 'warm_up_speaking', 1, 'Life Experiences', 'Share experiences', '{"prompt": "What is the most interesting experience you have had?"}'::jsonb) RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content) VALUES (lesson_id_var, 'vocabulary_intro', 2, 'Experience Words', 'Learn experience vocabulary', '{}'::jsonb) RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'adventure', 'การผจญภัย', NULL),
    (activity_id_var, 'achievement', 'ความสำเร็จ', NULL),
    (activity_id_var, 'challenge', 'ความท้าทาย', NULL),
    (activity_id_var, 'opportunity', 'โอกาส', NULL),
    (activity_id_var, 'journey', 'การเดินทาง', NULL);

    -- 3. Vocabulary Matching Drag #1 (5 pairs - same words)
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content) VALUES (lesson_id_var, 'vocabulary_matching_drag', 3, 'Match Experience Words 1', 'Match English words with Thai meanings', '{}'::jsonb) RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'adventure', 'การผจญภัย', NULL),
    (activity_id_var, 'achievement', 'ความสำเร็จ', NULL),
    (activity_id_var, 'challenge', 'ความท้าทาย', NULL),
    (activity_id_var, 'opportunity', 'โอกาส', NULL),
    (activity_id_var, 'journey', 'การเดินทาง', NULL);

    

    -- 4. Vocabulary Fill Blanks #1 (4 words: adventure, achievement, challenge, opportunity - journey left out)
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content) VALUES (lesson_id_var, 'vocabulary_fill_blanks', 4, 'Complete the Sentences 1', 'Fill in the blanks with correct words', '{"text": "I had an amazing ___ climbing Mount Everest. It was a great ___ to finish university. It was a big ___ to learn a new language. I took the ___ to study abroad.", "blanks": [{"id": "blank1", "text": "adventure", "options": ["adventure", "achievement", "challenge", "opportunity"], "correctAnswer": "adventure"}, {"id": "blank2", "text": "achievement", "options": ["adventure", "achievement", "challenge", "opportunity"], "correctAnswer": "achievement"}, {"id": "blank3", "text": "challenge", "options": ["adventure", "achievement", "challenge", "opportunity"], "correctAnswer": "challenge"}, {"id": "blank4", "text": "opportunity", "options": ["adventure", "achievement", "challenge", "opportunity"], "correctAnswer": "opportunity"}]}'::jsonb) RETURNING id INTO activity_id_var;

    -- 4. Vocabulary Fill Blanks #2 (4 words: adventure, achievement, challenge, journey - opportunity left out)
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content) VALUES (lesson_id_var, 'vocabulary_fill_blanks', 5, 'Complete the Sentences 2', 'Fill in the blanks with correct words', '{"text": "My ___ to South America was exciting. It was a personal ___ to run a marathon. It was a difficult ___ to overcome my fear. The ___ from student to professional was long.", "blanks": [{"id": "blank1", "text": "adventure", "options": ["adventure", "achievement", "challenge", "journey"], "correctAnswer": "adventure"}, {"id": "blank2", "text": "achievement", "options": ["adventure", "achievement", "challenge", "journey"], "correctAnswer": "achievement"}, {"id": "blank3", "text": "challenge", "options": ["adventure", "achievement", "challenge", "journey"], "correctAnswer": "challenge"}, {"id": "blank4", "text": "journey", "options": ["adventure", "achievement", "challenge", "journey"], "correctAnswer": "journey"}]}'::jsonb) RETURNING id INTO activity_id_var;

    -- 4. Grammar Explanation (5 examples - CEFR B1: Present perfect for experiences)
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content) VALUES (lesson_id_var, 'grammar_explanation', 6, 'Present Perfect - Experiences', 'Learn to talk about life experiences', '{"rules": "Use present perfect for experiences without specific time:\n\n- I have + past participle (I have traveled)\n- Have you ever + past participle? (Have you ever been?)\n- I have never + past participle (I have never tried)\n- Use ''ever'' in questions, ''never'' in negatives\n- Use ''already'' and ''yet'' for timing (I have already done it, I haven''t done it yet)", "examples": ["I have traveled to many countries.", "Have you ever been to Japan?", "She has never tried scuba diving.", "We have lived here for five years.", "They have already finished the project."]}'::jsonb) RETURNING id INTO activity_id_var;

    -- 4. Grammar Sentences #1
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content) VALUES (lesson_id_var, 'grammar_sentences', 7, 'Build Sentences 1', 'Arrange words to make sentences', '{}'::jsonb) RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'I have traveled to many countries', 'I have traveled to many countries', '["I", "have", "traveled", "to", "many", "countries"]'::jsonb),
    (activity_id_var, 'Have you ever been to Japan', 'Have you ever been to Japan?', '["Have", "you", "ever", "been", "to", "Japan?"]'::jsonb);
    -- 4. Grammar Sentences #2
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content) VALUES (lesson_id_var, 'grammar_sentences', 8, 'Build Sentences 2', 'Arrange words to make sentences', '{}'::jsonb) RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'She has never tried scuba diving', 'She has never tried scuba diving', '["She", "has", "never", "tried", "scuba", "diving"]'::jsonb),
    (activity_id_var, 'We have lived here for five years', 'We have lived here for five years', '["We", "have", "lived", "here", "for", "five", "years"]'::jsonb);
    -- 4. Speaking Practice (5 prompts - CEFR B1: Life experiences, present perfect)
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content) VALUES (lesson_id_var, 'speaking_practice', 9, 'Share Experiences', 'Practice talking about experiences', '{"prompts": ["What is the most exciting thing you have ever done?", "Have you ever traveled alone?", "What challenges have you overcome?", "What opportunities have you taken?", "Describe a journey that changed you."]}'::jsonb) RETURNING id INTO activity_id_var;

END $$;
INSERT INTO lesson_activities (
  lesson_id,
  activity_type,
  activity_order,
  title,
  description,
  content
) VALUES (
  'B1-L1',
  'speaking_improvement',
  10,
  'Speaking Improvement',
  'Read the improved version of your speech',
  '{"type": "speaking_improvement", "similarityThreshold": 70}'::jsonb
);