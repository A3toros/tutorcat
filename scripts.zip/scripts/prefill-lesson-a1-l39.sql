-- =========================================
-- Pre-fill Database with Sample Lesson Data
-- A1-L39: Languages You Speak
-- =========================================

DELETE FROM grammar_sentences WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'A1-L39');
DELETE FROM vocabulary_items WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'A1-L39');
DELETE FROM lesson_activities WHERE lesson_id = 'A1-L39';
DELETE FROM lessons WHERE id = 'A1-L39';

INSERT INTO lessons (id, level, lesson_number, topic) VALUES
('A1-L39', 'A1', 39, 'Languages You Speak')
ON CONFLICT (id) DO UPDATE SET topic = EXCLUDED.topic;

DO $$
DECLARE
    lesson_id_var TEXT := 'A1-L39';
    activity_id_var UUID;
BEGIN
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'warm_up_speaking', 1, 'Languages', 'Talk about languages', '{"prompt": "Can you speak English?"}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_intro', 2, 'Language Words', 'Learn language words', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'English', 'ภาษาอังกฤษ', NULL),
    (activity_id_var, 'Thai', 'ภาษาไทย', NULL),
    (activity_id_var, 'speak', 'พูด', NULL),
    (activity_id_var, 'learn', 'เรียน', NULL),
    (activity_id_var, 'easy', 'ง่าย', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_matching_drag', 3, 'Match Language Words', 'Match language words', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'English', 'ภาษาอังกฤษ', NULL),
    (activity_id_var, 'Thai', 'ภาษาไทย', NULL),
    (activity_id_var, 'speak', 'พูด', NULL),
    (activity_id_var, 'learn', 'เรียน', NULL),
    (activity_id_var, 'easy', 'ง่าย', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 4, 'Complete the Sentences 1', 'Fill with the correct word', '{"text": "I can speak ___. I can speak ___.", "blanks": [{"id": "blank1", "text": "English", "options": ["English", "Thai", "learn", "easy"], "correctAnswer": "English"}, {"id": "blank2", "text": "Thai", "options": ["Thai", "English", "easy", "learn"], "correctAnswer": "Thai"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 5, 'Complete the Sentences 2', 'Fill with the correct word', '{"text": "I want to ___. It is ___.", "blanks": [{"id": "blank1", "text": "learn", "options": ["learn", "speak", "English", "Thai"], "correctAnswer": "learn"}, {"id": "blank2", "text": "easy", "options": ["easy", "hard", "English", "Thai"], "correctAnswer": "easy"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_explanation', 6, 'Can for Ability', 'Talk about languages you can speak', '{"rules": "Use can + verb to show ability.\n- I can speak English.\n- She can speak Thai.\nAsk: Can you speak English?", "examples": ["I can speak English.", "I can speak Thai.", "She can learn fast.", "Can you speak English?", "Can he speak Thai?"]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 7, 'Build Sentences 1', 'Arrange words', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'I can speak English', 'I can speak English.', '["I", "can", "speak", "English."]'::jsonb),
    (activity_id_var, 'I can speak Thai', 'I can speak Thai.', '["I", "can", "speak", "Thai."]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 8, 'Build Sentences 2', 'Arrange words', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'Can you speak English', 'Can you speak English?', '["Can", "you", "speak", "English?"]'::jsonb),
    (activity_id_var, 'Can he speak Thai', 'Can he speak Thai?', '["Can", "he", "speak", "Thai?"]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'speaking_practice', 9, 'Talk About Languages', 'Practice can for languages', '{"prompts": ["Can you speak English?", "Can you speak Thai?", "Do you want to learn?", "Is English easy?", "Do you speak with friends?"]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (
      lesson_id,
      activity_type,
      activity_order,
      title,
      description,
      content
    ) VALUES (
      'A1-L39',
      'speaking_improvement',
      10,
      'Speaking Improvement',
      'Read the improved version of your speech',
      '{"type": "speaking_improvement", "similarityThreshold": 70}'::jsonb
    );
END $$;

