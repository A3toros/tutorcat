-- =========================================
-- Pre-fill Database with Sample Lesson Data
-- A1-L91: Time Words (today / yesterday / tomorrow)
-- =========================================

DELETE FROM grammar_sentences WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'A1-L91');
DELETE FROM vocabulary_items WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'A1-L91');
DELETE FROM lesson_activities WHERE lesson_id = 'A1-L91';
DELETE FROM lessons WHERE id = 'A1-L91';

INSERT INTO lessons (id, level, lesson_number, topic) VALUES
('A1-L91', 'A1', 91, 'Time Words (today / yesterday / tomorrow)')
ON CONFLICT (id) DO UPDATE SET topic = EXCLUDED.topic;

DO $$
DECLARE
    lesson_id_var TEXT := 'A1-L91';
    activity_id_var UUID;
BEGIN
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'warm_up_speaking', 1, 'Time Words', 'Talk about today/yesterday/tomorrow', '{"prompt": "Is your test today?"}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_intro', 2, 'Time Words', 'Learn today/yesterday/tomorrow', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'today', 'วันนี้', NULL),
    (activity_id_var, 'yesterday', 'เมื่อวานนี้', NULL),
    (activity_id_var, 'tomorrow', 'พรุ่งนี้', NULL),
    (activity_id_var, 'now', 'ตอนนี้', NULL),
    (activity_id_var, 'later', 'ภายหลัง', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_matching_drag', 3, 'Match Time Words', 'Match time words', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'today', 'วันนี้', NULL),
    (activity_id_var, 'yesterday', 'เมื่อวานนี้', NULL),
    (activity_id_var, 'tomorrow', 'พรุ่งนี้', NULL),
    (activity_id_var, 'now', 'ตอนนี้', NULL),
    (activity_id_var, 'later', 'ภายหลัง', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 4, 'Complete the Sentences 1', 'Fill with the correct word', '{"text": "My test is ___. My homework was ___.", "blanks": [{"id": "blank1", "text": "today", "options": ["today", "yesterday", "tomorrow", "later"], "correctAnswer": "today"}, {"id": "blank2", "text": "yesterday", "options": ["yesterday", "tomorrow", "today", "now"], "correctAnswer": "yesterday"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 5, 'Complete the Sentences 2', 'Fill with the correct word', '{"text": "We study ___. We rest ___.", "blanks": [{"id": "blank1", "text": "now", "options": ["now", "later", "today", "tomorrow"], "correctAnswer": "now"}, {"id": "blank2", "text": "later", "options": ["later", "now", "today", "yesterday"], "correctAnswer": "later"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_explanation', 6, 'Was/Is + Time Words', 'Use was/is with time', '{"rules": "Use is/was with time words.\n- It is today. It was yesterday. It is tomorrow.\nAsk: Is it today?", "examples": ["It is today.", "It was yesterday.", "It is tomorrow.", "Is it today?", "Is it tomorrow?"]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 7, 'Build Sentences 1', 'Arrange words', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'It is today', 'It is today.', '["It", "is", "today."]'::jsonb),
    (activity_id_var, 'It was yesterday', 'It was yesterday.', '["It", "was", "yesterday."]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 8, 'Build Sentences 2', 'Arrange words', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'Is it today', 'Is it today?', '["Is", "it", "today?"]'::jsonb),
    (activity_id_var, 'Is it tomorrow', 'Is it tomorrow?', '["Is", "it", "tomorrow?"]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'speaking_practice', 9, 'Talk About Time Words', 'Practice today/yesterday/tomorrow', '{"prompts": ["Is your test today?", "Was your homework yesterday?", "Is the trip tomorrow?", "Are we studying now?", "Do we rest later?"]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (
      lesson_id,
      activity_type,
      activity_order,
      title,
      description,
      content
    ) VALUES (
      'A1-L91',
      'speaking_improvement',
      10,
      'Speaking Improvement',
      'Read the improved version of your speech',
      '{"type": "speaking_improvement", "similarityThreshold": 70}'::jsonb
    );
END $$;

