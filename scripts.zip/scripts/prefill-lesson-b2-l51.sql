-- ===== LESSON B2-L51 =====

-- =========================================
-- Pre-fill Database with Sample Lesson Data
-- B2-L51: Conflict resolution among peers
-- =========================================

DELETE FROM lesson_activity_results WHERE lesson_id = 'B2-L51';
DELETE FROM user_progress WHERE lesson_id = 'B2-L51';
DELETE FROM lesson_history WHERE lesson_id = 'B2-L51';
DELETE FROM grammar_sentences WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'B2-L51');
DELETE FROM vocabulary_items WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'B2-L51');
DELETE FROM lesson_activities WHERE lesson_id = 'B2-L51';
DELETE FROM lessons WHERE id = 'B2-L51';

INSERT INTO lessons (id, level, lesson_number, topic) VALUES
('B2-L51', 'B2', 51, 'Conflict resolution among peers')
ON CONFLICT (id) DO UPDATE SET topic = EXCLUDED.topic;

DO $$
DECLARE
    lesson_id_var TEXT := 'B2-L51';
    activity_id_var UUID;
BEGIN
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'warm_up_speaking', 1, 'Resolution Approaches', 'Talk about handling peer conflicts', '{"prompt": "How do you solve problems with friends?"}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_intro', 2, 'Conflict Resolution Words', 'Learn words for handling disagreements', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'mediate', 'ไกล่เกลี่ย', NULL),
    (activity_id_var, 'compromise', 'ประนีประนอม', NULL),
    (activity_id_var, 'tension', 'ความตึงเครียด', NULL),
    (activity_id_var, 'pause', 'หยุดชั่วคราว', NULL),
    (activity_id_var, 'resolve', 'แก้ไข', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_matching_drag', 3, 'Match Resolution Words', 'Match conflict resolution words', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'mediate', 'ไกล่เกลี่ย', NULL),
    (activity_id_var, 'compromise', 'ประนีประนอม', NULL),
    (activity_id_var, 'tension', 'ความตึงเครียด', NULL),
    (activity_id_var, 'pause', 'หยุดชั่วคราว', NULL),
    (activity_id_var, 'resolve', 'แก้ไข', NULL);

    -- 4. Vocabulary Fill Blanks #1
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 4, 'Complete the Sentences 1', 'Fill in the blanks with correct words', '{"text": "I can ___ between friends. We need to ___. There is ___.", "blanks": [{"id": "blank1", "text": "mediate", "options": ["mediate", "compromise", "tension", "pause"], "correctAnswer": "mediate"}, {"id": "blank2", "text": "compromise", "options": ["compromise", "mediate", "tension", "resolve"], "correctAnswer": "compromise"}, {"id": "blank3", "text": "tension", "options": ["tension", "mediate", "compromise", "pause"], "correctAnswer": "tension"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    -- 5. Vocabulary Fill Blanks #2
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 5, 'Complete the Sentences 2', 'Fill in the blanks with correct words', '{"text": "Let''s ___ for a moment. We need to ___ this issue. They ___ the problem.", "blanks": [{"id": "blank1", "text": "pause", "options": ["pause", "mediate", "compromise", "tension"], "correctAnswer": "pause"}, {"id": "blank2", "text": "resolve", "options": ["resolve", "mediate", "compromise", "pause"], "correctAnswer": "resolve"}, {"id": "blank3", "text": "resolved", "options": ["resolved", "mediate", "compromise", "pause"], "correctAnswer": "resolved"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    -- 6. Grammar Explanation
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_explanation', 6, 'Present Perfect Continuous for Development', 'Learn present perfect continuous for ongoing development', '{"rules": "Use present perfect continuous for ongoing actions that started in the past:\n\n- Form: have/has + been + verb-ing (have been developing)\n- Use for actions that started in past and continue now\n- Emphasizes duration and ongoing nature\n- Often used with for/since (for 2 years, since last month)\n- Shows development or change over time", "examples": ["I have been developing better communication skills.", "She has been working on conflict resolution.", "They have been learning to mediate disputes.", "We have been practicing for months.", "He has been improving since last year."]}'::jsonb)
    RETURNING id INTO activity_id_var;

    -- 7. Grammar Sentences #1
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 7, 'Build Sentences 1', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'I have been developing better communication skills', 'I have been developing better communication skills.', '["I", "have", "been", "developing", "better", "communication", "skills."]'::jsonb),
    (activity_id_var, 'She has been working on conflict resolution', 'She has been working on conflict resolution.', '["She", "has", "been", "working", "on", "conflict", "resolution."]'::jsonb);

    -- 8. Grammar Sentences #2
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 8, 'Build Sentences 2', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'They have been learning to mediate disputes', 'They have been learning to mediate disputes.', '["They", "have", "been", "learning", "to", "mediate", "disputes."]'::jsonb),
    (activity_id_var, 'We have been practicing for months', 'We have been practicing for months.', '["We", "have", "been", "practicing", "for", "months."]'::jsonb);

    -- 9. Speaking Practice
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'speaking_practice', 9, 'Discuss Conflict Resolution', 'Practice talking about resolving peer conflicts', '{"prompts": ["How do you solve problems with friends?", "What do you do when you disagree?", "Who helps you when you have arguments?", "How do you mediate conflicts?", "What skills have you been developing?"]}'::jsonb)
    RETURNING id INTO activity_id_var;

    -- 10. Speaking Improvement
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'speaking_improvement', 10, 'Speaking Improvement', 'Read the improved version of your speech', '{"type": "speaking_improvement", "similarityThreshold": 70}'::jsonb)
    RETURNING id INTO activity_id_var;
END $$;