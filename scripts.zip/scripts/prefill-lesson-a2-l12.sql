-- =========================================
-- Pre-fill Database with Sample Lesson Data
-- A2-L12: Talking About Happiness
-- =========================================

DELETE FROM grammar_sentences WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'A2-L12');
DELETE FROM vocabulary_items WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'A2-L12');
DELETE FROM lesson_activities WHERE lesson_id = 'A2-L12';
DELETE FROM lessons WHERE id = 'A2-L12';

INSERT INTO lessons (id, level, lesson_number, topic) VALUES
('A2-L12', 'A2', 12, 'Talking About Happiness')
ON CONFLICT (id) DO UPDATE SET topic = EXCLUDED.topic;

DO $$
DECLARE
    lesson_id_var TEXT := 'A2-L12';
    activity_id_var UUID;
BEGIN
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'warm_up_speaking', 1, 'Happy Moments', 'Share what makes you happy', '{"prompt": "What makes you happy in your daily life?"}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_intro', 2, 'Happiness Words', 'Learn words about feeling happy', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'happy', 'มีความสุข', NULL),
    (activity_id_var, 'smile', 'ยิ้ม', NULL),
    (activity_id_var, 'laugh', 'หัวเราะ', NULL),
    (activity_id_var, 'enjoy', 'เพลิดเพลิน', NULL),
    (activity_id_var, 'relax', 'ผ่อนคลาย', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_matching_drag', 3, 'Match Happiness Words', 'Match feelings and actions', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'happy', 'มีความสุข', NULL),
    (activity_id_var, 'smile', 'ยิ้ม', NULL),
    (activity_id_var, 'laugh', 'หัวเราะ', NULL),
    (activity_id_var, 'enjoy', 'เพลิดเพลิน', NULL),
    (activity_id_var, 'relax', 'ผ่อนคลาย', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 4, 'Complete the Sentences 1', 'Fill with the correct word', '{"text": "I feel ___ when I listen to music. My friends ___ together at lunch. We ___ a quiet evening to ___ after work.", "blanks": [{"id": "blank1", "text": "happy", "options": ["happy", "laugh", "enjoy", "relax"], "correctAnswer": "happy"}, {"id": "blank2", "text": "laugh", "options": ["laugh", "happy", "enjoy", "relax"], "correctAnswer": "laugh"}, {"id": "blank3", "text": "enjoy", "options": ["enjoy", "relax", "laugh", "happy"], "correctAnswer": "enjoy"}, {"id": "blank4", "text": "relax", "options": ["relax", "enjoy", "happy", "laugh"], "correctAnswer": "relax"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 5, 'Complete the Sentences 2', 'Fill with the correct word', '{"text": "She ___ when she sees her dog. We ___ the weekend slowly. He likes to ___ after a long day.", "blanks": [{"id": "blank1", "text": "smiles", "options": ["smiles", "relax", "enjoy", "laughs"], "correctAnswer": "smiles"}, {"id": "blank2", "text": "enjoy", "options": ["enjoy", "smiles", "laughs", "relax"], "correctAnswer": "enjoy"}, {"id": "blank3", "text": "relax", "options": ["relax", "enjoy", "smiles", "laughs"], "correctAnswer": "relax"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_explanation', 6, 'Adverbs of Manner', 'Talk about how actions happen', '{"rules": "Use adverbs to say how you do something: verb + adverb.\n- He smiles warmly.\n- They laugh loudly.\n- She relaxes quietly.\nOften add -ly: quick → quickly. Some are the same as adjectives: fast.", "examples": ["She smiles warmly.", "They laugh loudly in class.", "He relaxes quietly at home.", "We enjoy music softly.", "I breathe slowly to relax."]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 7, 'Build Sentences 1', 'Arrange words', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'She smiles warmly', 'She smiles warmly.', '["She", "smiles", "warmly."]'::jsonb),
    (activity_id_var, 'They laugh loudly in class', 'They laugh loudly in class.', '["They", "laugh", "loudly", "in", "class."]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 8, 'Build Sentences 2', 'Arrange words', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'He relaxes quietly at home', 'He relaxes quietly at home.', '["He", "relaxes", "quietly", "at", "home."]'::jsonb),
    (activity_id_var, 'I breathe slowly to relax', 'I breathe slowly to relax.', '["I", "breathe", "slowly", "to", "relax."]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'speaking_practice', 9, 'Talk About Happiness', 'Practice sharing happy moments', '{"prompts": ["What makes you happy in your daily life?", "How do you relax after school or work?", "Who makes you laugh?", "What activities bring you joy?", "When do you feel happiest?"]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (
      lesson_id,
      activity_type,
      activity_order,
      title,
      description,
      content
    ) VALUES (
      'A2-L12',
      'speaking_improvement',
      10,
      'Speaking Improvement',
      'Read the improved version of your speech',
      '{"type": "speaking_improvement", "similarityThreshold": 70}'::jsonb
    );
END $$;

