-- =========================================
-- Pre-fill Database with Sample Lesson Data
-- A1-L28: Telling the Time (basic)
-- =========================================

DELETE FROM grammar_sentences WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'A1-L28');
DELETE FROM vocabulary_items WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'A1-L28');
DELETE FROM lesson_activities WHERE lesson_id = 'A1-L28';
DELETE FROM lessons WHERE id = 'A1-L28';

INSERT INTO lessons (id, level, lesson_number, topic) VALUES
('A1-L28', 'A1', 28, 'Telling the Time (basic)')
ON CONFLICT (id) DO UPDATE SET topic = EXCLUDED.topic;

DO $$
DECLARE
    lesson_id_var TEXT := 'A1-L28';
    activity_id_var UUID;
BEGIN
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'warm_up_speaking', 1, 'Time', 'Talk about the time', '{"prompt": "What time is it?"}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_intro', 2, 'Time Words', 'Learn time words', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'am', 'โมง', NULL),
    (activity_id_var, 'morning', 'เช้า', NULL),
    (activity_id_var, 'afternoon', 'บ่าย', NULL),
    (activity_id_var, 'evening', 'เย็น', NULL),
    (activity_id_var, 'now', 'ตอนนี้', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_matching_drag', 3, 'Match Time Words', 'Match time words', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'am', 'โมง', NULL),
    (activity_id_var, 'morning', 'เช้า', NULL),
    (activity_id_var, 'afternoon', 'บ่าย', NULL),
    (activity_id_var, 'evening', 'เย็น', NULL),
    (activity_id_var, 'now', 'ตอนนี้', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 4, 'Complete the Sentences 1', 'Fill with the correct word', '{"text": "It is seven ___. It is morning.", "blanks": [{"id": "blank1", "text": "am", "options": ["am", "morning", "afternoon", "evening"], "correctAnswer": "am"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 5, 'Complete the Sentences 2', 'Fill with the correct word', '{"text": "It is ___. It is night.", "blanks": [{"id": "blank1", "text": "evening", "options": ["evening", "morning", "afternoon", "now"], "correctAnswer": "evening"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_explanation', 6, 'Be + Time', 'Say the time with be', '{"rules": "Use be with time.\n- It is seven am.\n- It is morning.\nAsk: What time is it?", "examples": ["It is seven am.", "It is morning.", "It is afternoon now.", "It is evening.", "What time is it?"]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 7, 'Build Sentences 1', 'Arrange words', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'It is seven am', 'It is seven am.', '["It", "is", "seven", "am."]'::jsonb),
    (activity_id_var, 'It is morning', 'It is morning.', '["It", "is", "morning."]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 8, 'Build Sentences 2', 'Arrange words', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'It is afternoon now', 'It is afternoon now.', '["It", "is", "afternoon", "now."]'::jsonb),
    (activity_id_var, 'What time is it', 'What time is it?', '["What", "time", "is", "it?"]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'speaking_practice', 9, 'Talk About Time', 'Practice time questions', '{"prompts": ["What time is it?", "Is it morning?", "Is it evening?", "Do you wake up at six?", "Do you sleep at ten?"]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (
      lesson_id,
      activity_type,
      activity_order,
      title,
      description,
      content
    ) VALUES (
      'A1-L28',
      'speaking_improvement',
      10,
      'Speaking Improvement',
      'Read the improved version of your speech',
      '{"type": "speaking_improvement", "similarityThreshold": 70}'::jsonb
    );
END $$;

