-- =========================================
-- Pre-fill Database with Sample Lesson Data
-- A1-L40: Basic Directions
-- =========================================

DELETE FROM grammar_sentences WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'A1-L40');
DELETE FROM vocabulary_items WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'A1-L40');
DELETE FROM lesson_activities WHERE lesson_id = 'A1-L40';
DELETE FROM lessons WHERE id = 'A1-L40';

INSERT INTO lessons (id, level, lesson_number, topic) VALUES
('A1-L40', 'A1', 40, 'Basic Directions')
ON CONFLICT (id) DO UPDATE SET topic = EXCLUDED.topic;

DO $$
DECLARE
    lesson_id_var TEXT := 'A1-L40';
    activity_id_var UUID;
BEGIN
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'warm_up_speaking', 1, 'Directions', 'Talk about simple directions', '{"prompt": "Go left or right?"}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_intro', 2, 'Direction Words', 'Learn direction words', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'go', 'ไป', NULL),
    (activity_id_var, 'turn', 'เลี้ยว', NULL),
    (activity_id_var, 'left', 'ซ้าย', NULL),
    (activity_id_var, 'right', 'ขวา', NULL),
    (activity_id_var, 'straight', 'ตรงไป', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_matching_drag', 3, 'Match Direction Words', 'Match direction words', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'go', 'ไป', NULL),
    (activity_id_var, 'turn', 'เลี้ยว', NULL),
    (activity_id_var, 'left', 'ซ้าย', NULL),
    (activity_id_var, 'right', 'ขวา', NULL),
    (activity_id_var, 'straight', 'ตรงไป', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 4, 'Complete the Sentences 1', 'Fill with the correct word', '{"text": "__ left. __ right.", "blanks": [{"id": "blank1", "text": "Turn", "options": ["Turn", "Go", "Left", "Straight"], "correctAnswer": "Turn"}, {"id": "blank2", "text": "Go", "options": ["Go", "Turn", "Right", "Straight"], "correctAnswer": "Go"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 5, 'Complete the Sentences 2', 'Fill with the correct word', '{"text": "Go ___. Go ___.", "blanks": [{"id": "blank1", "text": "left", "options": ["left", "right", "straight", "turn"], "correctAnswer": "left"}, {"id": "blank2", "text": "straight", "options": ["straight", "right", "left", "turn"], "correctAnswer": "straight"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_explanation', 6, 'Imperatives + Place', 'Give simple directions', '{"rules": "Use base verb for directions.\n- Go left. Turn right. Go straight.\nAdd please for polite tone.", "examples": ["Go left.", "Turn right.", "Go straight, please.", "Turn left here.", "Go to the park."]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 7, 'Build Sentences 1', 'Arrange words', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'Go left', 'Go left.', '["Go", "left."]'::jsonb),
    (activity_id_var, 'Turn right', 'Turn right.', '["Turn", "right."]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 8, 'Build Sentences 2', 'Arrange words', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'Go straight please', 'Go straight, please.', '["Go", "straight,", "please."]'::jsonb),
    (activity_id_var, 'Turn left here', 'Turn left here.', '["Turn", "left", "here."]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'speaking_practice', 9, 'Practice Directions', 'Give simple directions', '{"prompts": ["Go left or right?", "Do I turn here?", "Do I go straight?", "Do you go to the park?", "Do you turn right?"]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (
      lesson_id,
      activity_type,
      activity_order,
      title,
      description,
      content
    ) VALUES (
      'A1-L40',
      'speaking_improvement',
      10,
      'Speaking Improvement',
      'Read the improved version of your speech',
      '{"type": "speaking_improvement", "similarityThreshold": 70}'::jsonb
    );
END $$;

