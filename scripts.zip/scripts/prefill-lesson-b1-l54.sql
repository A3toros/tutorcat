-- =========================================
-- Pre-fill Database with Sample Lesson Data
-- B1-L54: Conflict Resolution (Work)
-- =========================================

DELETE FROM grammar_sentences WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'B1-L54');
DELETE FROM vocabulary_items WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'B1-L54');
DELETE FROM lesson_activities WHERE lesson_id = 'B1-L54';
DELETE FROM lessons WHERE id = 'B1-L54';

INSERT INTO lessons (id, level, lesson_number, topic) VALUES
('B1-L54', 'B1', 54, 'Conflict Resolution (Work)')
ON CONFLICT (id) DO UPDATE SET topic = EXCLUDED.topic;

DO $$
DECLARE
    lesson_id_var TEXT := 'B1-L54';
    activity_id_var UUID;
BEGIN
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'warm_up_speaking', 1, 'Handling Conflict', 'Talk about real meeting conflicts', '{"prompt": "How do you deal with a tense meeting in real life?"}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_intro', 2, 'Conflict Words', 'Learn verb + preposition phrases for conflict resolution', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'deal with', 'จัดการกับ', NULL),
    (activity_id_var, 'agree on', 'เห็นพ้องใน', NULL),
    (activity_id_var, 'listen to', 'รับฟัง', NULL),
    (activity_id_var, 'respond to', 'ตอบสนองต่อ', NULL),
    (activity_id_var, 'compromise on', 'ประนีประนอมใน', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_matching_drag', 3, 'Match Conflict Phrases', 'Match phrases with meanings', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'deal with', 'จัดการกับ', NULL),
    (activity_id_var, 'agree on', 'เห็นพ้องใน', NULL),
    (activity_id_var, 'listen to', 'รับฟัง', NULL),
    (activity_id_var, 'respond to', 'ตอบสนองต่อ', NULL),
    (activity_id_var, 'compromise on', 'ประนีประนอมใน', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 4, 'Complete the Sentences 1', 'Fill with the correct phrase', '{"text": "We must ___ the issue. Teams should ___ one goal. Please ___ each person fully.", "blanks": [{"id": "blank1", "text": "deal with", "options": ["deal with", "agree on", "listen to", "respond to"], "correctAnswer": "deal with"}, {"id": "blank2", "text": "agree on", "options": ["agree on", "compromise on", "listen to", "deal with"], "correctAnswer": "agree on"}, {"id": "blank3", "text": "listen to", "options": ["listen to", "respond to", "deal with", "compromise on"], "correctAnswer": "listen to"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 5, 'Complete the Sentences 2', 'Fill with the correct phrase', '{"text": "Managers must ___ concerns fast. We ___ timelines. We can ___ scope.", "blanks": [{"id": "blank1", "text": "respond to", "options": ["respond to", "listen to", "agree on", "deal with"], "correctAnswer": "respond to"}, {"id": "blank2", "text": "agree on", "options": ["agree on", "compromise on", "respond to", "deal with"], "correctAnswer": "agree on"}, {"id": "blank3", "text": "compromise on", "options": ["compromise on", "respond to", "listen to", "deal with"], "correctAnswer": "compromise on"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    -- Grammar Explanation: Verb + Preposition (work conflict)
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_explanation', 6, 'Verb + Preposition for Conflict', 'Use fixed verb-preposition pairs to sound natural', '{"rules": "Keep verb + preposition together: deal with, agree on, listen to, respond to, compromise on. Do not drop the preposition.\\nUse clear objects.", "examples": ["We must deal with the conflict today.", "They agree on the final goal.", "She listens to every concern.", "He responds to issues quickly.", "We compromise on scope to finish."]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 7, 'Build Sentences 1', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'We must deal with the conflict today', 'We must deal with the conflict today', '["We", "must", "deal", "with", "the", "conflict", "today"]'::jsonb),
    (activity_id_var, 'They agree on the final goal', 'They agree on the final goal', '["They", "agree", "on", "the", "final", "goal"]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 8, 'Build Sentences 2', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'She listens to every concern', 'She listens to every concern', '["She", "listens", "to", "every", "concern"]'::jsonb),
    (activity_id_var, 'He responds to issues quickly', 'He responds to issues quickly', '["He", "responds", "to", "issues", "quickly"]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'speaking_practice', 9, 'Talk About Work Conflict', 'Practice talking about resolving work conflicts', '{"prompts": ["How do you deal with a tense meeting in real life?", "Who do you listen to most before you decide?", "When do you compromise even if you disagree?"]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (
      lesson_id,
      activity_type,
      activity_order,
      title,
      description,
      content
    ) VALUES (
      'B1-L54',
      'speaking_improvement',
      10,
      'Speaking Improvement',
      'Read the improved version of your speech',
      '{"type": "speaking_improvement", "similarityThreshold": 70}'::jsonb
    );
END $$;

