-- ===== LESSON B2-L52 =====

-- =========================================
-- Pre-fill Database with Sample Lesson Data
-- B2-L52: Financial responsibility
-- =========================================

DELETE FROM lesson_activity_results WHERE lesson_id = 'B2-L52';
DELETE FROM user_progress WHERE lesson_id = 'B2-L52';
DELETE FROM lesson_history WHERE lesson_id = 'B2-L52';
DELETE FROM grammar_sentences WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'B2-L52');
DELETE FROM vocabulary_items WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'B2-L52');
DELETE FROM lesson_activities WHERE lesson_id = 'B2-L52';
DELETE FROM lessons WHERE id = 'B2-L52';

INSERT INTO lessons (id, level, lesson_number, topic) VALUES
('B2-L52', 'B2', 52, 'Financial responsibility')
ON CONFLICT (id) DO UPDATE SET topic = EXCLUDED.topic;

DO $$
DECLARE
    lesson_id_var TEXT := 'B2-L52';
    activity_id_var UUID;
BEGIN
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'warm_up_speaking', 1, 'Money Management', 'Talk about staying on top of finances', '{"prompt": "How do you manage your money?"}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_intro', 2, 'Financial Responsibility Words', 'Learn words for managing money', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'due', 'ครบกำหนด', NULL),
    (activity_id_var, 'obligation', 'ภาระผูกพัน', NULL),
    (activity_id_var, 'arrears', 'ค้างชำระ', NULL),
    (activity_id_var, 'mindful', 'ระมัดระวัง', NULL),
    (activity_id_var, 'plan', 'วางแผน', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_matching_drag', 3, 'Match Finance Words', 'Match financial responsibility words', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'due', 'ครบกำหนด', NULL),
    (activity_id_var, 'obligation', 'ภาระผูกพัน', NULL),
    (activity_id_var, 'arrears', 'ค้างชำระ', NULL),
    (activity_id_var, 'mindful', 'ระมัดระวัง', NULL),
    (activity_id_var, 'plan', 'วางแผน', NULL);

    -- 4. Vocabulary Fill Blanks #1
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 4, 'Complete the Sentences 1', 'Fill in the blanks with correct words', '{"text": "The payment is ___. I have an ___. We are in ___.", "blanks": [{"id": "blank1", "text": "due", "options": ["due", "obligation", "arrears", "mindful"], "correctAnswer": "due"}, {"id": "blank2", "text": "obligation", "options": ["obligation", "due", "arrears", "plan"], "correctAnswer": "obligation"}, {"id": "blank3", "text": "arrears", "options": ["arrears", "due", "obligation", "mindful"], "correctAnswer": "arrears"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    -- 5. Vocabulary Fill Blanks #2
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 5, 'Complete the Sentences 2', 'Fill in the blanks with correct words', '{"text": "I am ___ of spending. We need to ___ ahead. They ___ their finances.", "blanks": [{"id": "blank1", "text": "mindful", "options": ["mindful", "due", "obligation", "plan"], "correctAnswer": "mindful"}, {"id": "blank2", "text": "plan", "options": ["plan", "due", "obligation", "mindful"], "correctAnswer": "plan"}, {"id": "blank3", "text": "plan", "options": ["plan", "mindful", "due", "obligation"], "correctAnswer": "plan"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    -- 6. Grammar Explanation
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_explanation', 6, 'Future Continuous for Ongoing Actions', 'Learn future continuous for future ongoing situations', '{"rules": "Use future continuous for actions that will be in progress at a future time:\n\n- Form: will + be + verb-ing (will be tracking, will be setting)\n- Use for actions happening at a specific future time\n- Emphasizes ongoing nature of future action\n- Often used with time expressions (next month, at 3pm)\n- Shows continuous action in the future", "examples": ["I will be tracking my expenses carefully.", "She will be setting financial reminders.", "They will be planning their budget next month.", "We will be managing our money better.", "He will be saving for the future."]}'::jsonb)
    RETURNING id INTO activity_id_var;

    -- 7. Grammar Sentences #1
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 7, 'Build Sentences 1', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'I will be tracking my expenses carefully', 'I will be tracking my expenses carefully.', '["I", "will", "be", "tracking", "my", "expenses", "carefully."]'::jsonb),
    (activity_id_var, 'She will be setting financial reminders', 'She will be setting financial reminders.', '["She", "will", "be", "setting", "financial", "reminders."]'::jsonb);

    -- 8. Grammar Sentences #2
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 8, 'Build Sentences 2', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'They will be planning their budget next month', 'They will be planning their budget next month.', '["They", "will", "be", "planning", "their", "budget", "next", "month."]'::jsonb),
    (activity_id_var, 'We will be managing our money better', 'We will be managing our money better.', '["We", "will", "be", "managing", "our", "money", "better."]'::jsonb);

    -- 9. Speaking Practice
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'speaking_practice', 9, 'Discuss Financial Planning', 'Practice talking about financial responsibility', '{"prompts": ["How do you save money?", "What do you buy with cash?", "Do you use credit cards?", "How do you track expenses?", "What financial plans do you have?"]}'::jsonb)
    RETURNING id INTO activity_id_var;

    -- 10. Speaking Improvement
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'speaking_improvement', 10, 'Speaking Improvement', 'Read the improved version of your speech', '{"type": "speaking_improvement", "similarityThreshold": 70}'::jsonb)
    RETURNING id INTO activity_id_var;
END $$;