-- =========================================
-- Pre-fill Database with Sample Lesson Data
-- B1-L37: Conflict & Agreement
-- =========================================

DELETE FROM grammar_sentences WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'B1-L37');
DELETE FROM vocabulary_items WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'B1-L37');
DELETE FROM lesson_activities WHERE lesson_id = 'B1-L37';
DELETE FROM lessons WHERE id = 'B1-L37';

INSERT INTO lessons (id, level, lesson_number, topic) VALUES
('B1-L37', 'B1', 37, 'Conflict & Agreement')
ON CONFLICT (id) DO UPDATE SET topic = EXCLUDED.topic;

DO $$
DECLARE
    lesson_id_var TEXT := 'B1-L37';
    activity_id_var UUID;
BEGIN
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'warm_up_speaking', 1, 'Sorting Disagreements', 'Talk about how you handle conflict', '{"prompt": "How do you sort out disagreements with friends or coworkers?"}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_intro', 2, 'Conflict Words', 'Learn vocabulary about conflict and agreement', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'disagree', 'ไม่เห็นด้วย', NULL),
    (activity_id_var, 'compromise', 'ประนีประนอม', NULL),
    (activity_id_var, 'mediate', 'ไกล่เกลี่ย', NULL),
    (activity_id_var, 'align', 'ทำให้ตรงกัน', NULL),
    (activity_id_var, 'respect', 'เคารพ', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_matching_drag', 3, 'Match Conflict Words', 'Match words with meanings', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'disagree', 'ไม่เห็นด้วย', NULL),
    (activity_id_var, 'compromise', 'ประนีประนอม', NULL),
    (activity_id_var, 'mediate', 'ไกล่เกลี่ย', NULL),
    (activity_id_var, 'align', 'ทำให้ตรงกัน', NULL),
    (activity_id_var, 'respect', 'เคารพ', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 4, 'Complete the Sentences 1', 'Fill with the correct word', '{"text": "We often ___. We try to ___. A friend can ___ for us.", "blanks": [{"id": "blank1", "text": "disagree", "options": ["disagree", "compromise", "mediate", "respect"], "correctAnswer": "disagree"}, {"id": "blank2", "text": "compromise", "options": ["compromise", "align", "mediate", "disagree"], "correctAnswer": "compromise"}, {"id": "blank3", "text": "mediate", "options": ["mediate", "respect", "align", "compromise"], "correctAnswer": "mediate"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 5, 'Complete the Sentences 2', 'Fill with the correct word', '{"text": "We need to ___ our goals. We must ___ each opinion. We decide to ___.", "blanks": [{"id": "blank1", "text": "align", "options": ["align", "respect", "disagree", "mediate"], "correctAnswer": "align"}, {"id": "blank2", "text": "respect", "options": ["respect", "align", "compromise", "mediate"], "correctAnswer": "respect"}, {"id": "blank3", "text": "compromise", "options": ["compromise", "align", "disagree", "respect"], "correctAnswer": "compromise"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    -- Grammar Explanation: Relative Clauses (defining)
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_explanation', 6, 'Relative Clauses (who/which/that)', 'Use defining clauses to add essential info about people/things', '{"rules": "Use who/which/that to add essential details. No commas.\\n- The person who mediates best is Kim.\\n- The solution that respects both sides works.\\nAvoid contractions.", "examples": ["The person who mediates best is Kim.", "The plan that we agreed on is fair.", "The idea that respects both teams wins trust.", "The teammate who listens well solves conflicts.", "The rule that we set last month still stands."]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 7, 'Build Sentences 1', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'The person who mediates best is Kim', 'The person who mediates best is Kim', '["The", "person", "who", "mediates", "best", "is", "Kim"]'::jsonb),
    (activity_id_var, 'The plan that we agreed on is fair', 'The plan that we agreed on is fair', '["The", "plan", "that", "we", "agreed", "on", "is", "fair"]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 8, 'Build Sentences 2', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'The idea that respects both teams wins trust', 'The idea that respects both teams wins trust', '["The", "idea", "that", "respects", "both", "teams", "wins", "trust"]'::jsonb),
    (activity_id_var, 'The teammate who listens well solves conflicts', 'The teammate who listens well solves conflicts', '["The", "teammate", "who", "listens", "well", "solves", "conflicts"]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'speaking_practice', 9, 'Talk About Conflict & Agreement', 'Practice talking about conflict and agreement', '{"prompts": ["How do you sort out disagreements with friends or coworkers?", "Who is someone that mediates well in your life?", "When do you decide to compromise?"]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (
      lesson_id,
      activity_type,
      activity_order,
      title,
      description,
      content
    ) VALUES (
      'B1-L37',
      'speaking_improvement',
      10,
      'Speaking Improvement',
      'Read the improved version of your speech',
      '{"type": "speaking_improvement", "similarityThreshold": 70}'::jsonb
    );
END $$;

