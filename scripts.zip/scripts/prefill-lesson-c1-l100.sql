-- =========================================
-- Pre-fill Database with Sample Lesson Data
-- C1-L100: Shaping the Future Through Ideas
-- =========================================
DELETE FROM lesson_activity_results WHERE lesson_id = 'C1-L100';
DELETE FROM user_progress WHERE lesson_id = 'C1-L100';
DELETE FROM lesson_history WHERE lesson_id = 'C1-L100';
DELETE FROM grammar_sentences WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'C1-L100');
DELETE FROM vocabulary_items WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'C1-L100');
DELETE FROM lesson_activities WHERE lesson_id = 'C1-L100';
DELETE FROM lessons WHERE id = 'C1-L100';

INSERT INTO lessons (id, level, lesson_number, topic) VALUES
('C1-L100', 'C1', 100, 'Shaping the Future Through Ideas')
ON CONFLICT (id) DO UPDATE SET topic = EXCLUDED.topic;

DO $$
DECLARE
    lesson_id_var TEXT := 'C1-L100';
    activity_id_var UUID;
BEGIN
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'warm_up_speaking', 1, 'Shaping the Future', 'Discuss shaping the future through ideas', '{"prompt": "How will your ideas have influenced others by 2035?"}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_intro', 2, 'Future Ideas Vocabulary', 'Learn vocabulary about shaping the future', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'idea', 'ความคิด', NULL),
    (activity_id_var, 'influence', 'อิทธิพล', NULL),
    (activity_id_var, 'contribution', 'การมีส่วนร่วม', NULL),
    (activity_id_var, 'impact', 'ผลกระทบ', NULL),
    (activity_id_var, 'thinking', 'การคิด', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_matching_drag', 3, 'Match Future Ideas Words', 'Match English words with Thai meanings', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'idea', 'ความคิด', NULL),
    (activity_id_var, 'influence', 'อิทธิพล', NULL),
    (activity_id_var, 'contribution', 'การมีส่วนร่วม', NULL),
    (activity_id_var, 'impact', 'ผลกระทบ', NULL),
    (activity_id_var, 'thinking', 'การคิด', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 4, 'Complete the Sentences 1', 'Fill with the correct word', '{"text": "___ shape the future. Your ___ will have influenced others. Making an ___ requires ___.", "blanks": [{"id": "blank1", "text": "Ideas", "options": ["Ideas", "Influence", "Contribution", "Impact"], "correctAnswer": "Ideas"}, {"id": "blank2", "text": "ideas", "options": ["ideas", "influence", "contribution", "impact"], "correctAnswer": "ideas"}, {"id": "blank3", "text": "impact", "options": ["impact", "idea", "influence", "contribution"], "correctAnswer": "impact"}, {"id": "blank4", "text": "commitment", "options": ["commitment", "idea", "influence", "contribution"], "correctAnswer": "commitment"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 5, 'Complete the Sentences 2', 'Fill with the correct word', '{"text": "Contributing ___ to society matters. Future-oriented ___ shapes ___.", "blanks": [{"id": "blank1", "text": "ideas", "options": ["ideas", "influence", "contribution", "impact"], "correctAnswer": "ideas"}, {"id": "blank2", "text": "thinking", "options": ["thinking", "idea", "influence", "contribution"], "correctAnswer": "thinking"}, {"id": "blank3", "text": "outcomes", "options": ["outcomes", "idea", "influence", "contribution"], "correctAnswer": "outcomes"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_explanation', 6, 'Future-facing Perfect and Mixed Forms', 'Learn future-facing perfect and mixed forms', '{"rules": "Future-facing perfect and mixed forms:\n- Future perfect: \"By 2035, my ideas will have influenced others.\"\n- Future perfect continuous: \"By then, I will have been contributing for years.\"\n- Mixed future: \"If I contribute ideas now, they will have influenced others by 2035.\"\n\nUse for:\n- Future completion: \"By 2035, my ideas will have shaped outcomes.\"\n- Duration up to future point: \"By then, I will have been thinking about the future for decades.\"\n- Hypothetical future: \"If I share ideas now, they will have influenced others by 2035.\"", "examples": ["By 2035, my ideas will have influenced others significantly.", "By then, I will have been contributing ideas for years.", "If I share ideas now, they will have influenced others by 2035.", "By 2035, today\'s ideas will have shaped the future.", "Having shared ideas, they will have influenced others by 2035."]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 7, 'Build Sentences 1', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'By 2035, my ideas will have influenced others significantly.', 'By 2035, my ideas will have influenced others significantly.', '["By", "2035,", "my", "ideas", "will", "have", "influenced", "others", "significantly."]'::jsonb),
    (activity_id_var, 'By then, I will have been contributing ideas for years.', 'By then, I will have been contributing ideas for years.', '["By", "then,", "I", "will", "have", "been", "contributing", "ideas", "for", "years."]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 8, 'Build Sentences 2', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'If I share ideas now, they will have influenced others by 2035.', 'If I share ideas now, they will have influenced others by 2035.', '["If", "I", "share", "ideas", "now,", "they", "will", "have", "influenced", "others", "by", "2035."]'::jsonb),
    (activity_id_var, 'By 2035, today\'s ideas will have shaped the future.', 'By 2035, today\'s ideas will have shaped the future.', '["By", "2035,", "today\'s", "ideas", "will", "have", "shaped", "the", "future."]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'speaking_practice', 9, 'Discuss Shaping the Future', 'Practice speaking about shaping the future', '{"prompts": ["How will your ideas have influenced others by 2035?", "What ideas do you want to contribute to society?", "How do ideas shape the future?", "What impact do you hope to make?", "How do you participate in future-oriented thinking?"]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (
      lesson_id,
      activity_type,
      activity_order,
      title,
      description,
      content
    ) VALUES (
      'C1-L100',
      'speaking_improvement',
      10,
      'Speaking Improvement',
      'Read the improved version of your speech',
      '{"type": "speaking_improvement", "similarityThreshold": 70}'::jsonb
    );
END $$;
