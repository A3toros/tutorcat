-- =========================================
-- Pre-fill Database with Sample Lesson Data
-- A1-L7: Home & Rooms
-- =========================================

-- Clear existing sample data for A1-L7 (optional - comment out if you want to keep existing data)
DELETE FROM lesson_activity_results WHERE lesson_id = 'A1-L7';
DELETE FROM user_progress WHERE lesson_id = 'A1-L7';
DELETE FROM lesson_history WHERE lesson_id = 'A1-L7';
DELETE FROM grammar_sentences WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'A1-L7');
DELETE FROM vocabulary_items WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'A1-L7');
DELETE FROM lesson_activities WHERE lesson_id = 'A1-L7';
DELETE FROM lessons WHERE id = 'A1-L7';

INSERT INTO lessons (id, level, lesson_number, topic) VALUES
('A1-L7', 'A1', 7, 'Home & Rooms')
ON CONFLICT (id) DO UPDATE SET topic = EXCLUDED.topic;

DO $$
DECLARE
    lesson_id_var TEXT := 'A1-L7';
    activity_id_var UUID;
BEGIN
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content) VALUES (lesson_id_var, 'warm_up_speaking', 1, 'Your Home', 'Describe your home', '{"prompt": "Tell me about your home."}'::jsonb) RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content) VALUES (lesson_id_var, 'vocabulary_intro', 2, 'Room Words', 'Learn room vocabulary', '{}'::jsonb) RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'bedroom', 'ห้องนอน', NULL),
    (activity_id_var, 'kitchen', 'ห้องครัว', NULL),
    (activity_id_var, 'bathroom', 'ห้องน้ำ', NULL),
    (activity_id_var, 'living room', 'ห้องนั่งเล่น', NULL),
    (activity_id_var, 'dining room', 'ห้องรับประทานอาหาร', NULL);

    -- 3. Vocabulary Matching Drag #1 (5 pairs - same words)
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content) VALUES (lesson_id_var, 'vocabulary_matching_drag', 3, 'Match Rooms 1', 'Match English words with Thai meanings', '{}'::jsonb) RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'bedroom', 'ห้องนอน', NULL),
    (activity_id_var, 'kitchen', 'ห้องครัว', NULL),
    (activity_id_var, 'bathroom', 'ห้องน้ำ', NULL),
    (activity_id_var, 'living room', 'ห้องนั่งเล่น', NULL),
    (activity_id_var, 'dining room', 'ห้องรับประทานอาหาร', NULL);

    

    -- 4. Vocabulary Fill Blanks #1 (4 words: bedroom, kitchen, bathroom, living room - dining room left out)
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content) VALUES (lesson_id_var, 'vocabulary_fill_blanks', 4, 'Complete the Sentences 1', 'Fill in the blanks with correct words', '{"text": "I sleep in my ___. I cook in the ___. I take a shower in the ___. I relax in the ___.", "blanks": [{"id": "blank1", "text": "bedroom", "options": ["bedroom", "kitchen", "bathroom", "living room"], "correctAnswer": "bedroom"}, {"id": "blank2", "text": "kitchen", "options": ["bedroom", "kitchen", "bathroom", "living room"], "correctAnswer": "kitchen"}, {"id": "blank3", "text": "bathroom", "options": ["bedroom", "kitchen", "bathroom", "living room"], "correctAnswer": "bathroom"}, {"id": "blank4", "text": "living room", "options": ["bedroom", "kitchen", "bathroom", "living room"], "correctAnswer": "living room"}]}'::jsonb) RETURNING id INTO activity_id_var;

    -- 4. Vocabulary Fill Blanks #2 (4 words: bedroom, kitchen, bathroom, dining room - living room left out)
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content) VALUES (lesson_id_var, 'vocabulary_fill_blanks', 5, 'Complete the Sentences 2', 'Fill in the blanks with correct words', '{"text": "My ___ has a bed. The ___ has a stove. The ___ has a shower. We eat in the ___.", "blanks": [{"id": "blank1", "text": "bedroom", "options": ["bedroom", "kitchen", "bathroom", "dining room"], "correctAnswer": "bedroom"}, {"id": "blank2", "text": "kitchen", "options": ["bedroom", "kitchen", "bathroom", "dining room"], "correctAnswer": "kitchen"}, {"id": "blank3", "text": "bathroom", "options": ["bedroom", "kitchen", "bathroom", "dining room"], "correctAnswer": "bathroom"}, {"id": "blank4", "text": "dining room", "options": ["bedroom", "kitchen", "bathroom", "dining room"], "correctAnswer": "dining room"}]}'::jsonb) RETURNING id INTO activity_id_var;

    -- 4. Grammar Explanation (5 examples)
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content) VALUES (lesson_id_var, 'grammar_explanation', 6, 'There is / There are', 'Learn to describe rooms', '{"rules": "Use ''there is'' for singular and ''there are'' for plural:\n\n- There is + singular noun (There is a bed)\n- There are + plural noun (There are two chairs)\n- Is there...? / Are there...? (Is there a table?)\n- Use ''in'' for location (in the bedroom)", "examples": ["There is a bed in the bedroom.", "There are two chairs in the living room.", "Is there a table in the kitchen?", "There are three rooms in my house.", "There is a bathroom on the first floor."]}'::jsonb) RETURNING id INTO activity_id_var;

    -- 4. Grammar Sentences #1
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content) VALUES (lesson_id_var, 'grammar_sentences', 7, 'Build Sentences 1', 'Arrange words to make sentences', '{}'::jsonb) RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'There is a bed in the bedroom', 'There is a bed in the bedroom', '["There", "is", "a", "bed", "in", "the", "bedroom"]'::jsonb),
    (activity_id_var, 'There are two chairs in the living room', 'There are two chairs in the living room', '["There", "are", "two", "chairs", "in", "the", "living", "room"]'::jsonb);
    -- 4. Grammar Sentences #2
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content) VALUES (lesson_id_var, 'grammar_sentences', 8, 'Build Sentences 2', 'Arrange words to make sentences', '{}'::jsonb) RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'Is there a table in the kitchen', 'Is there a table in the kitchen?', '["Is", "there", "a", "table", "in", "the", "kitchen?"]'::jsonb),
    (activity_id_var, 'There are three rooms in my house', 'There are three rooms in my house', '["There", "are", "three", "rooms", "in", "my", "house"]'::jsonb);
    -- 4. Speaking Practice (5 prompts - CEFR A1)
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content) VALUES (lesson_id_var, 'speaking_practice', 9, 'Describe Your Home', 'Practice describing your home', '{"prompts": ["How many rooms are there in your house?", "What is in your bedroom?", "Where do you cook?", "What is in the living room?", "What is in the bathroom?"]}'::jsonb) RETURNING id INTO activity_id_var;

END $$;
