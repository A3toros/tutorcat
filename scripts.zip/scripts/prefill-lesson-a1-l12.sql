-- =========================================
-- Pre-fill Database with Sample Lesson Data
-- A1-L12: Weather & Seasons
-- =========================================

DELETE FROM grammar_sentences WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'A1-L12');
DELETE FROM vocabulary_items WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'A1-L12');
DELETE FROM lesson_activities WHERE lesson_id = 'A1-L12';
DELETE FROM lessons WHERE id = 'A1-L12';

INSERT INTO lessons (id, level, lesson_number, topic) VALUES
('A1-L12', 'A1', 12, 'Weather & Seasons')
ON CONFLICT (id) DO UPDATE SET topic = EXCLUDED.topic;

DO $$
DECLARE
    lesson_id_var TEXT := 'A1-L12';
    activity_id_var UUID;
BEGIN
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'warm_up_speaking', 1, 'Today’s Weather', 'Talk about weather now', '{"prompt": "How is the weather today?"}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_intro', 2, 'Weather Words', 'Learn weather words', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'sunny', 'มีแดด', NULL),
    (activity_id_var, 'rainy', 'ฝนตก', NULL),
    (activity_id_var, 'hot', 'ร้อน', NULL),
    (activity_id_var, 'cold', 'หนาว', NULL),
    (activity_id_var, 'season', 'ฤดูกาล', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_matching_drag', 3, 'Match Weather Words', 'Match weather words', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'sunny', 'มีแดด', NULL),
    (activity_id_var, 'rainy', 'ฝนตก', NULL),
    (activity_id_var, 'hot', 'ร้อน', NULL),
    (activity_id_var, 'cold', 'หนาว', NULL),
    (activity_id_var, 'season', 'ฤดูกาล', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 4, 'Complete the Sentences 1', 'Fill with the correct word', '{"text": "It is ___. It is ___.", "blanks": [{"id": "blank1", "text": "sunny", "options": ["sunny", "rainy", "hot", "cold"], "correctAnswer": "sunny"}, {"id": "blank2", "text": "hot", "options": ["hot", "cold", "rainy", "season"], "correctAnswer": "hot"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 5, 'Complete the Sentences 2', 'Fill with the correct word', '{"text": "It is ___. It is ___.", "blanks": [{"id": "blank1", "text": "rainy", "options": ["rainy", "sunny", "hot", "cold"], "correctAnswer": "rainy"}, {"id": "blank2", "text": "cold", "options": ["cold", "season", "sunny", "rainy"], "correctAnswer": "cold"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_explanation', 6, 'Be + Weather Words', 'Use be to tell weather', '{"rules": "Use be with weather words.\n- It is sunny.\n- It is rainy.\nAsk: How is the weather?", "examples": ["It is sunny.", "It is rainy today.", "It is hot now.", "It is cold this morning.", "How is the weather?"]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 7, 'Build Sentences 1', 'Arrange words', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'It is sunny', 'It is sunny.', '["It", "is", "sunny."]'::jsonb),
    (activity_id_var, 'It is rainy today', 'It is rainy today.', '["It", "is", "rainy", "today."]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 8, 'Build Sentences 2', 'Arrange words', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'It is cold this morning', 'It is cold this morning.', '["It", "is", "cold", "this", "morning."]'::jsonb),
    (activity_id_var, 'How is the weather', 'How is the weather?', '["How", "is", "the", "weather?"]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'speaking_practice', 9, 'Talk About Weather', 'Practice weather questions', '{"prompts": ["How is the weather?", "Do you like rain?", "Is it hot today?", "Do you like cold days?", "What season do you like?"]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (
      lesson_id,
      activity_type,
      activity_order,
      title,
      description,
      content
    ) VALUES (
      'A1-L12',
      'speaking_improvement',
      10,
      'Speaking Improvement',
      'Read the improved version of your speech',
      '{"type": "speaking_improvement", "similarityThreshold": 70}'::jsonb
    );
END $$;

