-- =========================================
-- Pre-fill Database with Sample Lesson Data
-- B2-L9: News & Current Events
-- =========================================

DELETE FROM grammar_sentences WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'B2-L9');
DELETE FROM vocabulary_items WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'B2-L9');
DELETE FROM lesson_activities WHERE lesson_id = 'B2-L9';
DELETE FROM lessons WHERE id = 'B2-L9';

INSERT INTO lessons (id, level, lesson_number, topic) VALUES
('B2-L9', 'B2', 9, 'News & Current Events')
ON CONFLICT (id) DO UPDATE SET topic = EXCLUDED.topic;

DO $$
DECLARE
    lesson_id_var TEXT := 'B2-L9';
    activity_id_var UUID;
BEGIN
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'warm_up_speaking', 1, 'Following News', 'Talk about how you get news', '{"prompt": "Which source do you check first when news breaks?"}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_intro', 2, 'News Words', 'Key words for current events', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'headline', 'พาดหัวข่าว', NULL),
    (activity_id_var, 'source', 'แหล่งข่าว', NULL),
    (activity_id_var, 'verify', 'ตรวจสอบความถูกต้อง', NULL),
    (activity_id_var, 'bias', 'อคติ', NULL),
    (activity_id_var, 'reporting', 'การรายงานข่าว', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_matching_drag', 3, 'Match News Words', 'Match words with meanings', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'headline', 'พาดหัวข่าว', NULL),
    (activity_id_var, 'source', 'แหล่งข่าว', NULL),
    (activity_id_var, 'verify', 'ตรวจสอบความถูกต้อง', NULL),
    (activity_id_var, 'bias', 'อคติ', NULL),
    (activity_id_var, 'reporting', 'การรายงานข่าว', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 4, 'Complete the Sentences 1', 'Fill with the correct word', '{"text": "I read the ___. I check the ___. We must ___ facts.", "blanks": [{"id": "blank1", "text": "headline", "options": ["headline", "source", "verify", "bias"], "correctAnswer": "headline"}, {"id": "blank2", "text": "source", "options": ["source", "headline", "reporting", "verify"], "correctAnswer": "source"}, {"id": "blank3", "text": "verify", "options": ["verify", "bias", "source", "reporting"], "correctAnswer": "verify"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 5, 'Complete the Sentences 2', 'Fill with the correct word', '{"text": "The ___ may be slow. Hidden ___ changes views. Good ___ needs time.", "blanks": [{"id": "blank1", "text": "reporting", "options": ["reporting", "bias", "headline", "verify"], "correctAnswer": "reporting"}, {"id": "blank2", "text": "bias", "options": ["bias", "source", "headline", "reporting"], "correctAnswer": "bias"}, {"id": "blank3", "text": "reporting", "options": ["reporting", "verify", "bias", "source"], "correctAnswer": "reporting"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_explanation', 6, 'Passive with Modals', 'Show necessity or permission in news', '{"rules": "Use modal + be + past participle to focus on the action, not the doer.\\n- Facts must be verified.\\n- Sources should be checked.\\nUse perfect: modal + have + been + past participle for past references.", "examples": ["Headlines must be written carefully.", "Sources should be verified before posting.", "Bias can be hidden.", "Errors might have been missed.", "Updates must be shared quickly."]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 7, 'Build Sentences 1', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'Facts must be verified before sharing', 'Facts must be verified before sharing.', '["Facts", "must", "be", "verified", "before", "sharing."]'::jsonb),
    (activity_id_var, 'Sources should be checked carefully', 'Sources should be checked carefully.', '["Sources", "should", "be", "checked", "carefully."]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 8, 'Build Sentences 2', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'Errors might have been missed in the rush', 'Errors might have been missed in the rush.', '["Errors", "might", "have", "been", "missed", "in", "the", "rush."]'::jsonb),
    (activity_id_var, 'Updates must be shared quickly', 'Updates must be shared quickly.', '["Updates", "must", "be", "shared", "quickly."]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'speaking_practice', 9, 'Talk About News', 'Practice discussing news sources', '{"prompts": ["How do you verify a headline before sharing?", "When have you noticed bias in a story?", "What should be done before posting news in a group chat?"]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (
      lesson_id,
      activity_type,
      activity_order,
      title,
      description,
      content
    ) VALUES (
      'B2-L9',
      'speaking_improvement',
      10,
      'Speaking Improvement',
      'Read the improved version of your speech',
      '{"type": "speaking_improvement", "similarityThreshold": 70}'::jsonb
    );
END $$;


