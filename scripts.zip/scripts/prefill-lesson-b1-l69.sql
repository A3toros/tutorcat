-- ===== LESSON B1-L69 =====

-- =========================================
-- Pre-fill Database with Sample Lesson Data
-- B1-L69: Healthy Habits
-- =========================================

DELETE FROM lesson_activity_results WHERE lesson_id = 'B1-L69';
DELETE FROM user_progress WHERE lesson_id = 'B1-L69';
DELETE FROM lesson_history WHERE lesson_id = 'B1-L69';
DELETE FROM grammar_sentences WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'B1-L69');
DELETE FROM vocabulary_items WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'B1-L69');
DELETE FROM lesson_activities WHERE lesson_id = 'B1-L69';
DELETE FROM lessons WHERE id = 'B1-L69';

INSERT INTO lessons (id, level, lesson_number, topic) VALUES
('B1-L69', 'B1', 69, 'Healthy Habits')
ON CONFLICT (id) DO UPDATE SET topic = EXCLUDED.topic;

DO $$
DECLARE
    lesson_id_var TEXT := 'B1-L69';
    activity_id_var UUID;
BEGIN
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'warm_up_speaking', 1, 'Healthy Habits', 'Talk about staying healthy', '{"prompt": "Do you eat breakfast every day?"}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_intro', 2, 'Health Routine Words', 'Learn words for healthy daily habits', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'routine', 'กิจวัตรประจำวัน', NULL),
    (activity_id_var, 'hydrate', 'ดื่มน้ำ', NULL),
    (activity_id_var, 'stretch', 'ยืดกล้ามเนื้อ', NULL),
    (activity_id_var, 'consistent', 'สม่ำเสมอ', NULL),
    (activity_id_var, 'crash', 'ทรุดลง', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_matching_drag', 3, 'Match Health Words', 'Match healthy habit words', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'routine', 'กิจวัตรประจำวัน', NULL),
    (activity_id_var, 'hydrate', 'ดื่มน้ำ', NULL),
    (activity_id_var, 'stretch', 'ยืดกล้ามเนื้อ', NULL),
    (activity_id_var, 'consistent', 'สม่ำเสมอ', NULL),
    (activity_id_var, 'crash', 'ทรุดลง', NULL);

    -- 4. Vocabulary Fill Blanks #1
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 4, 'Complete the Sentences 1', 'Fill in the blanks with correct words', '{"text": "I have a daily ___. I need to ___ every day. I ___ in the morning.", "blanks": [{"id": "blank1", "text": "routine", "options": ["routine", "hydrate", "stretch", "consistent"], "correctAnswer": "routine"}, {"id": "blank2", "text": "hydrate", "options": ["hydrate", "routine", "stretch", "consistent"], "correctAnswer": "hydrate"}, {"id": "blank3", "text": "stretch", "options": ["stretch", "routine", "hydrate", "consistent"], "correctAnswer": "stretch"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    -- 5. Vocabulary Fill Blanks #2
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 5, 'Complete the Sentences 2', 'Fill in the blanks with correct words', '{"text": "I am ___ with my exercise. If I don''t sleep, I ___. We need to be ___.", "blanks": [{"id": "blank1", "text": "consistent", "options": ["consistent", "routine", "hydrate", "stretch"], "correctAnswer": "consistent"}, {"id": "blank2", "text": "crash", "options": ["crash", "routine", "hydrate", "consistent"], "correctAnswer": "crash"}, {"id": "blank3", "text": "consistent", "options": ["consistent", "routine", "crash", "stretch"], "correctAnswer": "consistent"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    -- 6. Grammar Explanation
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_explanation', 6, 'Zero Conditional for Facts', 'Learn if/when for general truths', '{"rules": "Use zero conditional for general truths and facts:\n\n- Form: If/When + present simple, present simple\n- If you exercise, you feel better\n- When you sleep well, you have energy\n- Use if or when (both mean the same)\n- Both clauses use present simple\n- Expresses general truths, not specific situations", "examples": ["If you exercise regularly, you feel better.", "When you sleep well, you have more energy.", "If you eat healthy food, you stay strong.", "When you hydrate, you feel good.", "If you are consistent, you see results."]}'::jsonb)
    RETURNING id INTO activity_id_var;

    -- 7. Grammar Sentences #1
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 7, 'Build Sentences 1', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'If you exercise regularly you feel better', 'If you exercise regularly, you feel better.', '["If", "you", "exercise", "regularly,", "you", "feel", "better."]'::jsonb),
    (activity_id_var, 'When you sleep well you have more energy', 'When you sleep well, you have more energy.', '["When", "you", "sleep", "well,", "you", "have", "more", "energy."]'::jsonb);

    -- 8. Grammar Sentences #2
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 8, 'Build Sentences 2', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'If you eat healthy food you stay strong', 'If you eat healthy food, you stay strong.', '["If", "you", "eat", "healthy", "food,", "you", "stay", "strong."]'::jsonb),
    (activity_id_var, 'When you hydrate you feel good', 'When you hydrate, you feel good.', '["When", "you", "hydrate,", "you", "feel", "good."]'::jsonb);

    -- 9. Speaking Practice
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'speaking_practice', 9, 'Talk About Health', 'Practice talking about healthy living', '{"prompts": ["What healthy food do you eat?", "How many hours do you sleep?", "What exercise do you do?", "What is your daily routine?", "How do you stay healthy?"]}'::jsonb)
    RETURNING id INTO activity_id_var;

    -- 10. Speaking Improvement
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'speaking_improvement', 10, 'Speaking Improvement', 'Read the improved version of your speech', '{"type": "speaking_improvement", "similarityThreshold": 70}'::jsonb)
    RETURNING id INTO activity_id_var;
END $$;