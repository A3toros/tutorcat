-- =========================================
-- COMPREHENSIVE ACHIEVEMENT FIXES MIGRATION
-- =========================================
-- This migration combines all achievement-related fixes:
-- 1. Fix Multi-Level achievement to check distinct levels
-- 2. Fix score_average achievements to require minimum lesson counts
-- 3. Fix progress calculation for score_average achievements
-- 4. Fix progress calculation for stars achievements
-- 5. Update some achievements from score_average to score_threshold_count
-- 6. Clean up incorrectly awarded achievements
--
-- Date: 2025-01-XX
-- Run this migration to fix all achievement-related bugs

-- =========================================
-- STEP 1: Add requirement_count column if it doesn't exist
-- =========================================
DO $$
BEGIN
    IF NOT EXISTS (
        SELECT 1 FROM information_schema.columns 
        WHERE table_name = 'achievements' AND column_name = 'requirement_count'
    ) THEN
        ALTER TABLE achievements 
        ADD COLUMN requirement_count INTEGER DEFAULT NULL;
        
        RAISE NOTICE 'Added requirement_count column to achievements table';
    ELSE
        RAISE NOTICE 'requirement_count column already exists';
    END IF;
END $$;

-- =========================================
-- STEP 2: Update Multi-Level achievements to use distinct_levels
-- =========================================
UPDATE achievements 
SET requirement_type = 'distinct_levels',
    requirement_value = 3,
    description = 'Complete lessons in 3 different levels'
WHERE code = 'multi_level';

UPDATE achievements 
SET requirement_type = 'distinct_levels',
    requirement_value = 6,
    description = 'Complete lessons in all 6 levels'
WHERE code = 'all_levels';

-- =========================================
-- STEP 3: Update some achievements from score_average to score_threshold_count
-- =========================================
DO $$
BEGIN
    -- Update "Excellent" achievement: Score 90%+ on 10 lessons
    UPDATE achievements
    SET requirement_type = 'score_threshold_count',
        requirement_value = 90,
        requirement_count = 10
    WHERE code = 'excellent'
      AND requirement_type = 'score_average';

    -- Update "Above Average" achievement: Score 80%+ on 20 lessons
    UPDATE achievements
    SET requirement_type = 'score_threshold_count',
        requirement_value = 80,
        requirement_count = 20
    WHERE code = 'above_average'
      AND requirement_type = 'score_average';

    -- Update "Above Average" performance achievement: Score 80%+ on 5 lessons
    UPDATE achievements
    SET requirement_type = 'score_threshold_count',
        requirement_value = 80,
        requirement_count = 5
    WHERE code = 'above_average_perf'
      AND requirement_type = 'score_average';

    -- Update "Outstanding" achievement: Score 95%+ on 5 lessons
    UPDATE achievements
    SET requirement_type = 'score_threshold_count',
        requirement_value = 95,
        requirement_count = 5
    WHERE code = 'outstanding'
      AND requirement_type = 'score_average';

    -- Update "Consistent Performer" achievement: Score 80%+ on 10 lessons
    UPDATE achievements
    SET requirement_type = 'score_threshold_count',
        requirement_value = 80,
        requirement_count = 10
    WHERE code = 'consistent_performer'
      AND requirement_type = 'score_average';

    -- Update "Grammar Guru" achievement: Score 90%+ on 10 grammar activities
    UPDATE achievements
    SET requirement_type = 'score_threshold_count',
        requirement_value = 90,
        requirement_count = 10
    WHERE code = 'grammar_guru'
      AND requirement_type = 'score_average';

    -- Update "Vocabulary Master" achievement: Score 90%+ on 10 vocabulary activities
    UPDATE achievements
    SET requirement_type = 'score_threshold_count',
        requirement_value = 90,
        requirement_count = 10
    WHERE code = 'vocabulary_master'
      AND requirement_type = 'score_average';

    -- Update "Speaking Star" achievement: Score 90%+ on 10 speaking activities
    UPDATE achievements
    SET requirement_type = 'score_threshold_count',
        requirement_value = 90,
        requirement_count = 10
    WHERE code = 'speaking_star'
      AND requirement_type = 'score_average';

    -- Update "Quick Learner" performance achievement: Score 90%+ on 5 lessons
    UPDATE achievements
    SET requirement_type = 'score_threshold_count',
        requirement_value = 90,
        requirement_count = 5
    WHERE code = 'quick_learner_perf'
      AND requirement_type = 'score_average';

    -- Update "Consistency King" achievement: Score 85%+ on 30 lessons
    UPDATE achievements
    SET requirement_type = 'score_threshold_count',
        requirement_value = 85,
        requirement_count = 30
    WHERE code = 'consistency_king'
      AND requirement_type = 'score_average';

    RAISE NOTICE 'Updated achievements from score_average to score_threshold_count';
END $$;

-- =========================================
-- STEP 4: Set requirement_count for remaining score_average achievements
-- =========================================
DO $$
BEGIN
    UPDATE achievements
    SET requirement_count = 25
    WHERE code = 'high_achiever'
      AND requirement_type = 'score_average'
      AND requirement_count IS NULL;

    UPDATE achievements
    SET requirement_count = 25
    WHERE code = 'master_student'
      AND requirement_type = 'score_average'
      AND requirement_count IS NULL;

    UPDATE achievements
    SET requirement_count = 50
    WHERE code = 'excellence'
      AND requirement_type = 'score_average'
      AND requirement_count IS NULL;

    UPDATE achievements
    SET requirement_count = 10
    WHERE code = 'top_performer'
      AND requirement_type = 'score_average'
      AND requirement_count IS NULL;

    UPDATE achievements
    SET requirement_count = 1
    WHERE code = 'good_start'
      AND requirement_type = 'score_average'
      AND requirement_count IS NULL;

    RAISE NOTICE 'Set requirement_count for score_average achievements';
END $$;

-- =========================================
-- STEP 5: Update check_achievements_on_lesson_complete function
-- =========================================
CREATE OR REPLACE FUNCTION check_achievements_on_lesson_complete(p_user_id UUID)
RETURNS TABLE(achievement_code VARCHAR(50), achievement_name VARCHAR(255), icon VARCHAR(50)) AS $$
DECLARE
    v_lesson_count INTEGER;
    v_perfect_scores INTEGER;
    v_avg_score NUMERIC;
    v_stars INTEGER;
    v_level VARCHAR(10);
    v_achievement_record RECORD;
    v_distinct_levels INTEGER;
BEGIN
    -- Get basic stats from existing tables
    SELECT COUNT(*) INTO v_lesson_count
    FROM user_progress
    WHERE user_id = p_user_id AND completed = true;
    
    SELECT COUNT(*) INTO v_perfect_scores
    FROM user_progress
    WHERE user_id = p_user_id AND completed = true AND score >= 100;
    
    SELECT COALESCE(AVG(score), 0) INTO v_avg_score
    FROM user_progress
    WHERE user_id = p_user_id AND completed = true;
    
    SELECT COALESCE(total_stars, 0) INTO v_stars
    FROM users
    WHERE id = p_user_id
    LIMIT 1;
    
    -- Get count of distinct levels with completed lessons
    SELECT COUNT(DISTINCT l.level) INTO v_distinct_levels
    FROM user_progress up
    JOIN lessons l ON up.lesson_id = l.id
    WHERE up.user_id = p_user_id AND up.completed = true;
    
    -- Check all achievements and award if criteria met
    FOR v_achievement_record IN 
        SELECT * FROM achievements 
        WHERE id NOT IN (
            SELECT achievement_id FROM user_achievements WHERE user_id = p_user_id
        )
    LOOP
        DECLARE
            v_should_award BOOLEAN := false;
            v_level_count INTEGER;
            v_total_in_level INTEGER;
        BEGIN
            -- Check achievement based on requirement_type
            CASE v_achievement_record.requirement_type
                WHEN 'lesson_count' THEN
                    IF v_lesson_count >= v_achievement_record.requirement_value THEN
                        v_should_award := true;
                    END IF;
                
                WHEN 'distinct_levels' THEN
                    -- Check if user completed lessons in the required number of distinct levels
                    IF v_distinct_levels >= v_achievement_record.requirement_value THEN
                        v_should_award := true;
                    END IF;
                
                WHEN 'perfect_score_count' THEN
                    IF v_perfect_scores >= v_achievement_record.requirement_value THEN
                        v_should_award := true;
                    END IF;
                
                WHEN 'score_average' THEN
                    -- For score_average, we need both the average score AND minimum lesson count
                    -- requirement_value is the score threshold, requirement_count is the minimum lessons needed
                    -- If requirement_count is NULL, we can't award (need explicit lesson count)
                    IF v_avg_score >= v_achievement_record.requirement_value 
                       AND v_achievement_record.requirement_count IS NOT NULL
                       AND v_lesson_count >= v_achievement_record.requirement_count THEN
                        v_should_award := true;
                    END IF;
                
                WHEN 'score_threshold_count' THEN
                    -- Count lessons with score >= threshold, need requirement_count such lessons
                    DECLARE
                        v_threshold_count INTEGER;
                        v_needed_count INTEGER;
                    BEGIN
                        SELECT COUNT(*) INTO v_threshold_count
                        FROM user_progress
                        WHERE user_id = p_user_id 
                          AND completed = true 
                          AND score >= v_achievement_record.requirement_value;
                        
                        v_needed_count := COALESCE(v_achievement_record.requirement_count, v_achievement_record.requirement_value);
                        
                        IF v_threshold_count >= v_needed_count THEN
                            v_should_award := true;
                        END IF;
                    END;
                
                WHEN 'stars' THEN
                    IF v_stars >= v_achievement_record.requirement_value THEN
                        v_should_award := true;
                    END IF;
                
                WHEN 'level_complete' THEN
                    -- Check if user completed all lessons in a level (dynamic count)
                    -- Extract level from code (e.g., 'a1_master' -> 'A1')
                    DECLARE
                        level_name VARCHAR(10);
                    BEGIN
                        -- Extract level from achievement code (format: 'a1_master', 'b2_master', etc.)
                        IF v_achievement_record.code LIKE 'a1_%' THEN
                            level_name := 'A1';
                        ELSIF v_achievement_record.code LIKE 'a2_%' THEN
                            level_name := 'A2';
                        ELSIF v_achievement_record.code LIKE 'b1_%' THEN
                            level_name := 'B1';
                        ELSIF v_achievement_record.code LIKE 'b2_%' THEN
                            level_name := 'B2';
                        ELSIF v_achievement_record.code LIKE 'c1_%' THEN
                            level_name := 'C1';
                        ELSIF v_achievement_record.code LIKE 'c2_%' THEN
                            level_name := 'C2';
                        END IF;
                        
                        IF level_name IS NOT NULL THEN
                            v_level_count := get_user_completed_lessons_in_level(p_user_id, level_name);
                            v_total_in_level := get_total_lessons_in_level(level_name);
                            
                            -- Award if user completed all lessons in that level (dynamic count)
                            IF v_level_count >= v_total_in_level AND v_total_in_level > 0 THEN
                                v_should_award := true;
                            END IF;
                        END IF;
                    END;
                
                ELSE
                    -- Unknown requirement type - don't award
                    v_should_award := false;
            END CASE;
            
            -- Award achievement if criteria met
            IF v_should_award THEN
                INSERT INTO user_achievements (user_id, achievement_id)
                VALUES (p_user_id, v_achievement_record.id)
                ON CONFLICT (user_id, achievement_id) DO NOTHING;
                
                -- Return newly earned achievement
                RETURN QUERY
                SELECT 
                    v_achievement_record.code,
                    v_achievement_record.name,
                    v_achievement_record.icon;
            END IF;
        END;
    END LOOP;
    
    RETURN;
END;
$$ LANGUAGE plpgsql;

-- =========================================
-- STEP 6: Update get_user_achievements_with_progress function
-- =========================================
CREATE OR REPLACE FUNCTION get_user_achievements_with_progress(p_user_id UUID)
RETURNS TABLE (
    achievement_id UUID,
    code VARCHAR(50),
    name VARCHAR(255),
    description TEXT,
    icon VARCHAR(50),
    category VARCHAR(50),
    rarity VARCHAR(20),
    points INTEGER,
    earned_at TIMESTAMP,
    current_progress INTEGER,
    target_progress INTEGER,
    progress_percentage NUMERIC
) AS $$
BEGIN
    RETURN QUERY
    SELECT 
        a.id,
        a.code,
        a.name,
        a.description,
        a.icon,
        a.category,
        a.rarity,
        a.points,
        ua.earned_at,
        -- Calculate current progress on-the-fly based on requirement_type
        CASE a.requirement_type
            WHEN 'lesson_count' THEN
                (SELECT COUNT(*)::INTEGER FROM user_progress WHERE user_id = p_user_id AND completed = true)
            WHEN 'perfect_score_count' THEN
                (SELECT COUNT(*)::INTEGER FROM user_progress WHERE user_id = p_user_id AND completed = true AND score >= 100)
            WHEN 'score_average' THEN
                -- For score_average, return the number of completed lessons (progress toward requirement_count)
                (SELECT COUNT(*)::INTEGER FROM user_progress WHERE user_id = p_user_id AND completed = true)
            WHEN 'score_threshold_count' THEN
                (SELECT COUNT(*)::INTEGER FROM user_progress WHERE user_id = p_user_id AND completed = true AND score >= a.requirement_value)
            WHEN 'stars' THEN
                (SELECT COALESCE(total_stars, 0) FROM users WHERE id = p_user_id)
            WHEN 'level_complete' THEN
                -- For level completion, calculate based on level in code
                CASE 
                    WHEN a.code LIKE 'a1_master' THEN get_user_completed_lessons_in_level(p_user_id, 'A1')
                    WHEN a.code LIKE 'a2_master' THEN get_user_completed_lessons_in_level(p_user_id, 'A2')
                    WHEN a.code LIKE 'b1_master' THEN get_user_completed_lessons_in_level(p_user_id, 'B1')
                    WHEN a.code LIKE 'b2_master' THEN get_user_completed_lessons_in_level(p_user_id, 'B2')
                    WHEN a.code LIKE 'c1_master' THEN get_user_completed_lessons_in_level(p_user_id, 'C1')
                    WHEN a.code LIKE 'c2_master' THEN get_user_completed_lessons_in_level(p_user_id, 'C2')
                    ELSE 0
                END
            WHEN 'distinct_levels' THEN
                (SELECT COUNT(DISTINCT l.level)::INTEGER
                 FROM user_progress up
                 JOIN lessons l ON up.lesson_id = l.id
                 WHERE up.user_id = p_user_id AND up.completed = true)
            ELSE 0
        END as current_progress,
        -- Target progress: for level_complete, use dynamic total; otherwise use requirement_value
        CASE 
            WHEN a.requirement_type = 'level_complete' THEN
                CASE 
                    WHEN a.code LIKE 'a1_master' THEN get_total_lessons_in_level('A1')
                    WHEN a.code LIKE 'a2_master' THEN get_total_lessons_in_level('A2')
                    WHEN a.code LIKE 'b1_master' THEN get_total_lessons_in_level('B1')
                    WHEN a.code LIKE 'b2_master' THEN get_total_lessons_in_level('B2')
                    WHEN a.code LIKE 'c1_master' THEN get_total_lessons_in_level('C1')
                    WHEN a.code LIKE 'c2_master' THEN get_total_lessons_in_level('C2')
                    ELSE 0
                END
            WHEN a.requirement_type = 'score_threshold_count' THEN
                COALESCE(a.requirement_count, a.requirement_value)
            WHEN a.requirement_type = 'score_average' THEN
                -- For score_average, target is the number of lessons needed (requirement_count)
                COALESCE(a.requirement_count, a.requirement_value)
            WHEN a.requirement_type = 'distinct_levels' THEN
                a.requirement_value
            WHEN a.requirement_type = 'stars' THEN
                -- For stars, target is the number of stars needed (requirement_value)
                a.requirement_value
            ELSE a.requirement_value
        END as target_progress,
        CASE 
            WHEN a.requirement_type = 'level_complete' THEN
                -- For level completion, use dynamic total
                CASE 
                    WHEN a.code LIKE 'a1_master' THEN 
                        ROUND((get_user_completed_lessons_in_level(p_user_id, 'A1')::NUMERIC / NULLIF(get_total_lessons_in_level('A1'), 0)) * 100, 1)
                    WHEN a.code LIKE 'a2_master' THEN 
                        ROUND((get_user_completed_lessons_in_level(p_user_id, 'A2')::NUMERIC / NULLIF(get_total_lessons_in_level('A2'), 0)) * 100, 1)
                    WHEN a.code LIKE 'b1_master' THEN 
                        ROUND((get_user_completed_lessons_in_level(p_user_id, 'B1')::NUMERIC / NULLIF(get_total_lessons_in_level('B1'), 0)) * 100, 1)
                    WHEN a.code LIKE 'b2_master' THEN 
                        ROUND((get_user_completed_lessons_in_level(p_user_id, 'B2')::NUMERIC / NULLIF(get_total_lessons_in_level('B2'), 0)) * 100, 1)
                    WHEN a.code LIKE 'c1_master' THEN 
                        ROUND((get_user_completed_lessons_in_level(p_user_id, 'C1')::NUMERIC / NULLIF(get_total_lessons_in_level('C1'), 0)) * 100, 1)
                    WHEN a.code LIKE 'c2_master' THEN 
                        ROUND((get_user_completed_lessons_in_level(p_user_id, 'C2')::NUMERIC / NULLIF(get_total_lessons_in_level('C2'), 0)) * 100, 1)
                    ELSE 0
                END
            WHEN a.requirement_type = 'score_threshold_count' THEN
                ROUND((SELECT COUNT(*)::NUMERIC FROM user_progress WHERE user_id = p_user_id AND completed = true AND score >= a.requirement_value) / NULLIF(COALESCE(a.requirement_count, a.requirement_value), 0) * 100, 1)
            WHEN a.requirement_type = 'score_average' THEN
                -- For score_average, calculate progress based on lessons completed vs requirement_count
                -- Progress is: lessons_completed / requirement_count * 100
                CASE 
                    WHEN COALESCE(a.requirement_count, a.requirement_value) > 0 THEN
                        ROUND(
                            (SELECT COUNT(*)::NUMERIC FROM user_progress WHERE user_id = p_user_id AND completed = true) 
                            / NULLIF(COALESCE(a.requirement_count, a.requirement_value), 0) * 100, 
                            1
                        )
                    ELSE 0
                END
            WHEN a.requirement_type = 'distinct_levels' THEN
                -- For distinct_levels, calculate progress based on distinct levels completed
                ROUND(
                    (SELECT COUNT(DISTINCT l.level)::NUMERIC
                     FROM user_progress up
                     JOIN lessons l ON up.lesson_id = l.id
                     WHERE up.user_id = p_user_id AND up.completed = true)
                    / NULLIF(a.requirement_value, 0) * 100,
                    1
                )
            WHEN a.requirement_type = 'stars' THEN
                -- For stars, calculate progress as: current_stars / required_stars * 100
                ROUND(
                    (SELECT COALESCE(total_stars, 0)::NUMERIC FROM users WHERE id = p_user_id)
                    / NULLIF(a.requirement_value, 0) * 100,
                    1
                )
            WHEN a.requirement_value > 0 THEN
                ROUND((CASE a.requirement_type
                    WHEN 'lesson_count' THEN (SELECT COUNT(*)::NUMERIC FROM user_progress WHERE user_id = p_user_id AND completed = true)
                    WHEN 'perfect_score_count' THEN (SELECT COUNT(*)::NUMERIC FROM user_progress WHERE user_id = p_user_id AND completed = true AND score >= 100)
                    ELSE 0
                END / a.requirement_value::NUMERIC) * 100, 1)
            ELSE 0
        END as progress_percentage
    FROM achievements a
    LEFT JOIN user_achievements ua ON a.id = ua.achievement_id AND ua.user_id = p_user_id
    ORDER BY 
        CASE WHEN ua.earned_at IS NOT NULL THEN 0 ELSE 1 END,
        a.category,
        a.points DESC;
END;
$$ LANGUAGE plpgsql;

-- =========================================
-- STEP 7: Clean up incorrectly awarded achievements
-- =========================================
DO $$
DECLARE
    v_removed_count INTEGER := 0;
    v_achievement_record RECORD;
BEGIN
    -- Remove incorrectly awarded multi_level achievements (users who only completed lessons in 1 or 2 levels)
    DELETE FROM user_achievements ua
    WHERE ua.achievement_id = (SELECT id FROM achievements WHERE code = 'multi_level')
      AND NOT EXISTS (
        SELECT 1
        FROM user_progress up
        JOIN lessons l ON up.lesson_id = l.id
        WHERE up.user_id = ua.user_id 
          AND up.completed = true
        GROUP BY up.user_id
        HAVING COUNT(DISTINCT l.level) >= 3
      );
    
    GET DIAGNOSTICS v_removed_count = ROW_COUNT;
    IF v_removed_count > 0 THEN
        RAISE NOTICE 'Removed % incorrectly awarded "Multi-Level" achievements', v_removed_count;
    END IF;

    -- Remove incorrectly awarded all_levels achievements (users who haven't completed lessons in all 6 levels)
    DELETE FROM user_achievements ua
    WHERE ua.achievement_id = (SELECT id FROM achievements WHERE code = 'all_levels')
      AND NOT EXISTS (
        SELECT 1
        FROM user_progress up
        JOIN lessons l ON up.lesson_id = l.id
        WHERE up.user_id = ua.user_id 
          AND up.completed = true
        GROUP BY up.user_id
        HAVING COUNT(DISTINCT l.level) >= 6
      );
    
    GET DIAGNOSTICS v_removed_count = ROW_COUNT;
    IF v_removed_count > 0 THEN
        RAISE NOTICE 'Removed % incorrectly awarded "All Levels" achievements', v_removed_count;
    END IF;

    -- Remove incorrectly awarded score_average achievements that require multiple lessons
    -- but were awarded when users only had 1 lesson completed
    FOR v_achievement_record IN
        SELECT a.id, a.code, a.name, a.requirement_count
        FROM achievements a
        WHERE a.requirement_type = 'score_average'
          AND a.requirement_count > 1
    LOOP
        DELETE FROM user_achievements ua
        WHERE ua.achievement_id = v_achievement_record.id
          AND EXISTS (
              SELECT 1 
              FROM user_progress up 
              WHERE up.user_id = ua.user_id 
                AND up.completed = true
              HAVING COUNT(*) < v_achievement_record.requirement_count
          );
        
        GET DIAGNOSTICS v_removed_count = ROW_COUNT;
        IF v_removed_count > 0 THEN
            RAISE NOTICE 'Removed % incorrectly awarded "%" achievements', 
                v_removed_count, v_achievement_record.name;
        END IF;
    END LOOP;
    
    RAISE NOTICE 'Cleanup complete! All incorrectly awarded achievements have been removed.';
END $$;

-- =========================================
-- SUMMARY
-- =========================================
-- This migration fixes:
-- 
-- 1. Multi-Level achievements:
--    - "Multi-Level" now requires 3 distinct levels (not just 3 lessons)
--    - "All Levels" now requires 6 distinct levels (not just 6 lessons)
--
-- 2. score_average achievements:
--    - Now require BOTH average score threshold AND minimum lesson count
--    - Progress calculation fixed: lessons_completed / requirement_count * 100
--    - Examples: "High Achiever" (90%+ across 25 lessons), "Excellence" (90%+ across 50 lessons)
--
-- 3. stars achievements:
--    - Progress calculation fixed: current_stars / required_stars * 100
--    - Example: "Star Collector" (10 stars) shows 4/10 = 40% if 4 stars earned
--
-- 4. Achievement type updates:
--    - Some achievements changed from score_average to score_threshold_count for clarity
--
-- 5. Cleanup:
--    - Removed incorrectly awarded achievements from users who don't meet the criteria

