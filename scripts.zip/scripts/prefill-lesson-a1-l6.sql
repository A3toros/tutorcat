-- =========================================
-- Pre-fill Database with Sample Lesson Data
-- A1-L6: Places in Town
-- =========================================

-- Clear existing sample data for A1-L6 (optional - comment out if you want to keep existing data)
DELETE FROM lesson_activity_results WHERE lesson_id = 'A1-L6';
DELETE FROM user_progress WHERE lesson_id = 'A1-L6';
DELETE FROM lesson_history WHERE lesson_id = 'A1-L6';
DELETE FROM grammar_sentences WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'A1-L6');
DELETE FROM vocabulary_items WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'A1-L6');
DELETE FROM lesson_activities WHERE lesson_id = 'A1-L6';
DELETE FROM lessons WHERE id = 'A1-L6';

INSERT INTO lessons (id, level, lesson_number, topic) VALUES
('A1-L6', 'A1', 6, 'Places in Town')
ON CONFLICT (id) DO UPDATE SET topic = EXCLUDED.topic;

DO $$
DECLARE
    lesson_id_var TEXT := 'A1-L6';
    activity_id_var UUID;
BEGIN
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content) VALUES (lesson_id_var, 'warm_up_speaking', 1, 'Places You Know', 'Where do you go in your town?', '{"prompt": "What places do you visit in your town?"}'::jsonb) RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content) VALUES (lesson_id_var, 'vocabulary_intro', 2, 'Places Words', 'Learn places vocabulary', '{}'::jsonb) RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'hospital', 'โรงพยาบาล', NULL),
    (activity_id_var, 'school', 'โรงเรียน', NULL),
    (activity_id_var, 'market', 'ตลาด', NULL),
    (activity_id_var, 'restaurant', 'ร้านอาหาร', NULL),
    (activity_id_var, 'park', 'สวนสาธารณะ', NULL);

    -- 3. Vocabulary Matching Drag #1 (5 pairs - same words)
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content) VALUES (lesson_id_var, 'vocabulary_matching_drag', 3, 'Match Places 1', 'Match English words with Thai meanings', '{}'::jsonb) RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'hospital', 'โรงพยาบาล', NULL),
    (activity_id_var, 'school', 'โรงเรียน', NULL),
    (activity_id_var, 'market', 'ตลาด', NULL),
    (activity_id_var, 'restaurant', 'ร้านอาหาร', NULL),
    (activity_id_var, 'park', 'สวนสาธารณะ', NULL);

    

    -- 4. Vocabulary Fill Blanks #1 (4 words: hospital, school, market, restaurant - park left out)
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content) VALUES (lesson_id_var, 'vocabulary_fill_blanks', 4, 'Complete the Sentences 1', 'Fill in the blanks with correct words', '{"text": "I go to the ___ when I am sick. My children go to ___. I buy food at the ___. I eat at a ___.", "blanks": [{"id": "blank1", "text": "hospital", "options": ["hospital", "car", "snow", "go"], "correctAnswer": "hospital"}, {"id": "blank2", "text": "school", "options": ["school", "book", "water", "run"], "correctAnswer": "school"}, {"id": "blank3", "text": "market", "options": ["market", "table", "blue", "eat"], "correctAnswer": "market"}, {"id": "blank4", "text": "restaurant", "options": ["restaurant", "door", "red", "sleep"], "correctAnswer": "restaurant"}]}'::jsonb) RETURNING id INTO activity_id_var;

    -- 5. Vocabulary Fill Blanks #2 (4 words: hospital, school, market, park - restaurant left out)
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content) VALUES (lesson_id_var, 'vocabulary_fill_blanks', 5, 'Complete the Sentences 2', 'Fill in the blanks with correct words', '{"text": "The ___ is near my house. I walk to ___. I shop at the ___. I exercise in the ___.", "blanks": [{"id": "blank1", "text": "hospital", "options": ["hospital", "tree", "yellow", "jump"], "correctAnswer": "hospital"}, {"id": "blank2", "text": "school", "options": ["school", "chair", "green", "walk"], "correctAnswer": "school"}, {"id": "blank3", "text": "market", "options": ["market", "window", "black", "sing"], "correctAnswer": "market"}, {"id": "blank4", "text": "park", "options": ["park", "phone", "white", "dance"], "correctAnswer": "park"}]}'::jsonb) RETURNING id INTO activity_id_var;

    -- 6. Grammar Explanation (5 examples)
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content) VALUES (lesson_id_var, 'grammar_explanation', 6, 'Prepositions of Place', 'Learn where things are', '{"rules": "Use prepositions to describe location:\n\n- at (ที่) - at the hospital\n- in (ใน) - in the park\n- near (ใกล้) - near the school\n- on (บน) - on the street\n- behind (ข้างหลัง) - behind the school", "examples": ["I am at the hospital.", "The school is in the city.", "The market is near my house.", "The restaurant is on Main Street.", "The park is behind the school."]}'::jsonb) RETURNING id INTO activity_id_var;

    -- 7. Grammar Sentences #1
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content) VALUES (lesson_id_var, 'grammar_sentences', 7, 'Build Sentences 1', 'Arrange words to make sentences', '{}'::jsonb) RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'I am at the hospital', 'I am at the hospital', '["I", "am", "at", "the", "hospital"]'::jsonb),
    (activity_id_var, 'The school is in the city', 'The school is in the city', '["The", "school", "is", "in", "the", "city"]'::jsonb);
    -- 8. Grammar Sentences #2
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content) VALUES (lesson_id_var, 'grammar_sentences', 8, 'Build Sentences 2', 'Arrange words to make sentences', '{}'::jsonb) RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'The market is near my house', 'The market is near my house', '["The", "market", "is", "near", "my", "house"]'::jsonb),
    (activity_id_var, 'The restaurant is on Main Street', 'The restaurant is on Main Street', '["The", "restaurant", "is", "on", "Main", "Street"]'::jsonb);
    -- 9. Speaking Practice (5 prompts - CEFR A1)
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content) VALUES (lesson_id_var, 'speaking_practice', 9, 'Talk About Places', 'Practice talking about places', '{"prompts": ["Where is the closest shopping mall?", "Is there a school near you?", "Where do you go shopping?", "What is your favorite place in the city?", "What is your favorite cafe?"]}'::jsonb) RETURNING id INTO activity_id_var;

END $$;
