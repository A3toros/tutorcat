-- =========================================
-- Pre-fill Database with Sample Lesson Data
-- A2-L22: Paying by Cash or Card
-- =========================================

DELETE FROM grammar_sentences WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'A2-L22');
DELETE FROM vocabulary_items WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'A2-L22');
DELETE FROM lesson_activities WHERE lesson_id = 'A2-L22';
DELETE FROM lessons WHERE id = 'A2-L22';

INSERT INTO lessons (id, level, lesson_number, topic) VALUES
('A2-L22', 'A2', 22, 'Paying by Cash or Card')
ON CONFLICT (id) DO UPDATE SET topic = EXCLUDED.topic;

DO $$
DECLARE
    lesson_id_var TEXT := 'A2-L22';
    activity_id_var UUID;
BEGIN
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'warm_up_speaking', 1, 'How Do You Pay?', 'Talk about payment choices', '{"prompt": "Do you usually pay by cash or by card?"}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_intro', 2, 'Payment Words', 'Learn payment vocabulary', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'cash', 'เงินสด', NULL),
    (activity_id_var, 'card', 'บัตร', NULL),
    (activity_id_var, 'receipt', 'ใบเสร็จ', NULL),
    (activity_id_var, 'change', 'เงินทอน', NULL),
    (activity_id_var, 'machine', 'เครื่องรูดบัตร', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_matching_drag', 3, 'Match Payment Words', 'Match payment words', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'cash', 'เงินสด', NULL),
    (activity_id_var, 'card', 'บัตร', NULL),
    (activity_id_var, 'receipt', 'ใบเสร็จ', NULL),
    (activity_id_var, 'change', 'เงินทอน', NULL),
    (activity_id_var, 'machine', 'เครื่องรูดบัตร', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 4, 'Complete the Sentences 1', 'Fill with the correct word', '{"text": "Do you take ___? I only have ___. Can I get a ___, please?", "blanks": [{"id": "blank1", "text": "card", "options": ["card", "cash", "receipt", "change"], "correctAnswer": "card"}, {"id": "blank2", "text": "cash", "options": ["cash", "card", "receipt", "machine"], "correctAnswer": "cash"}, {"id": "blank3", "text": "receipt", "options": ["receipt", "change", "cash", "card"], "correctAnswer": "receipt"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 5, 'Complete the Sentences 2', 'Fill with the correct word', '{"text": "This ___ is not working. I need ___ for 100 baht. Do you prefer ___ or card?", "blanks": [{"id": "blank1", "text": "machine", "options": ["machine", "change", "card", "receipt"], "correctAnswer": "machine"}, {"id": "blank2", "text": "change", "options": ["change", "cash", "card", "machine"], "correctAnswer": "change"}, {"id": "blank3", "text": "cash", "options": ["cash", "card", "machine", "receipt"], "correctAnswer": "cash"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_explanation', 6, 'Present Simple Negatives/Questions', 'Ask about payment options', '{"rules": "Use do/does for questions; don''t/doesn''t for negatives.\n- Do you take cards?\n- Does this machine work?\n- We don''t accept cash today.", "examples": ["Do you take cards?", "Does this machine work?", "We don''t accept cash today.", "I don''t have change.", "Do you need a receipt?"]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 7, 'Build Sentences 1', 'Arrange words', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'Do you take cards', 'Do you take cards?', '["Do", "you", "take", "cards?"]'::jsonb),
    (activity_id_var, 'Does this machine work', 'Does this machine work?', '["Does", "this", "machine", "work?"]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 8, 'Build Sentences 2', 'Arrange words', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'We don t accept cash today', 'We don''t accept cash today.', '["We", "don''t", "accept", "cash", "today."]'::jsonb),
    (activity_id_var, 'Do you need a receipt', 'Do you need a receipt?', '["Do", "you", "need", "a", "receipt?"]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'speaking_practice', 9, 'Talk About Paying', 'Practice paying by cash or card', '{"prompts": ["Do you usually pay by cash or by card?", "Have you ever lost a receipt?", "Do you trust card machines in shops?", "When do you prefer to use cash?", "What payment method do you prefer, and why?"]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (
      lesson_id,
      activity_type,
      activity_order,
      title,
      description,
      content
    ) VALUES (
      'A2-L22',
      'speaking_improvement',
      10,
      'Speaking Improvement',
      'Read the improved version of your speech',
      '{"type": "speaking_improvement", "similarityThreshold": 70}'::jsonb
    );
END $$;

