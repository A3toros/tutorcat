-- =========================================
-- Pre-fill Database with Sample Lesson Data
-- B1-L55: Cultural Traditions
-- =========================================

DELETE FROM grammar_sentences WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'B1-L55');
DELETE FROM vocabulary_items WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'B1-L55');
DELETE FROM lesson_activities WHERE lesson_id = 'B1-L55';
DELETE FROM lessons WHERE id = 'B1-L55';

INSERT INTO lessons (id, level, lesson_number, topic) VALUES
('B1-L55', 'B1', 55, 'Cultural Traditions')
ON CONFLICT (id) DO UPDATE SET topic = EXCLUDED.topic;

DO $$
DECLARE
    lesson_id_var TEXT := 'B1-L55';
    activity_id_var UUID;
BEGIN
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'warm_up_speaking', 1, 'Traditions You Keep', 'Talk about traditions that matter to you', '{"prompt": "What tradition matters most to you?"}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_intro', 2, 'Tradition Words', 'Learn vocabulary about cultural traditions', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'ritual', 'พิธีกรรม', NULL),
    (activity_id_var, 'heritage', 'มรดกทางวัฒนธรรม', NULL),
    (activity_id_var, 'symbol', 'สัญลักษณ์', NULL),
    (activity_id_var, 'ceremony', 'พิธีการ', NULL),
    (activity_id_var, 'festival', 'เทศกาล', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_matching_drag', 3, 'Match Tradition Words', 'Match words with meanings', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'ritual', 'พิธีกรรม', NULL),
    (activity_id_var, 'heritage', 'มรดกทางวัฒนธรรม', NULL),
    (activity_id_var, 'symbol', 'สัญลักษณ์', NULL),
    (activity_id_var, 'ceremony', 'พิธีการ', NULL),
    (activity_id_var, 'festival', 'เทศกาล', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 4, 'Complete the Sentences 1', 'Fill with the correct word', '{"text": "This ___ is old. It shows our ___. The ___ is a strong sign.", "blanks": [{"id": "blank1", "text": "ritual", "options": ["ritual", "heritage", "symbol", "festival"], "correctAnswer": "ritual"}, {"id": "blank2", "text": "heritage", "options": ["heritage", "festival", "symbol", "ceremony"], "correctAnswer": "heritage"}, {"id": "blank3", "text": "symbol", "options": ["symbol", "ritual", "ceremony", "heritage"], "correctAnswer": "symbol"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 5, 'Complete the Sentences 2', 'Fill with the correct word', '{"text": "The ___ is celebrated yearly. We join the ___. I love this ___.", "blanks": [{"id": "blank1", "text": "festival", "options": ["festival", "ceremony", "symbol", "ritual"], "correctAnswer": "festival"}, {"id": "blank2", "text": "ceremony", "options": ["ceremony", "festival", "ritual", "symbol"], "correctAnswer": "ceremony"}, {"id": "blank3", "text": "tradition", "options": ["tradition", "festival", "ritual", "symbol"], "correctAnswer": "tradition"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    -- Grammar Explanation: Articles (review) in cultural contexts
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_explanation', 6, 'Articles in Traditions', 'Use the/zero article for specific vs general cultural items', '{"rules": "Use the for specific known items: the festival, the ceremony. Use zero article for general plural/uncountable: celebrate festivals, join ceremonies.\\nKeep it simple; avoid extra articles.", "examples": ["The festival is next week.", "We join ceremonies every year.", "The symbol is on the flag.", "We respect heritage through rituals.", "I share traditions with friends."]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 7, 'Build Sentences 1', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'The festival is next week', 'The festival is next week', '["The", "festival", "is", "next", "week"]'::jsonb),
    (activity_id_var, 'We join ceremonies every year', 'We join ceremonies every year', '["We", "join", "ceremonies", "every", "year"]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 8, 'Build Sentences 2', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'The symbol is on the flag', 'The symbol is on the flag', '["The", "symbol", "is", "on", "the", "flag"]'::jsonb),
    (activity_id_var, 'We respect heritage through rituals', 'We respect heritage through rituals', '["We", "respect", "heritage", "through", "rituals"]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'speaking_practice', 9, 'Talk About Traditions', 'Practice talking about cultural traditions', '{"prompts": ["What tradition matters most to you?", "How do you explain it to friends who do not know it?", "What would you keep or change about it?"]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (
      lesson_id,
      activity_type,
      activity_order,
      title,
      description,
      content
    ) VALUES (
      'B1-L55',
      'speaking_improvement',
      10,
      'Speaking Improvement',
      'Read the improved version of your speech',
      '{"type": "speaking_improvement", "similarityThreshold": 70}'::jsonb
    );
END $$;

