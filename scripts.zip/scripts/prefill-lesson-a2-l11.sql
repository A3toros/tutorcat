-- =========================================
-- Pre-fill Database with Sample Lesson Data
-- A2-L11: Buying a Train or Bus Ticket
-- =========================================

DELETE FROM grammar_sentences WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'A2-L11');
DELETE FROM vocabulary_items WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'A2-L11');
DELETE FROM lesson_activities WHERE lesson_id = 'A2-L11';
DELETE FROM lessons WHERE id = 'A2-L11';

INSERT INTO lessons (id, level, lesson_number, topic) VALUES
('A2-L11', 'A2', 11, 'Buying a Train or Bus Ticket')
ON CONFLICT (id) DO UPDATE SET topic = EXCLUDED.topic;

DO $$
DECLARE
    lesson_id_var TEXT := 'A2-L11';
    activity_id_var UUID;
BEGIN
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'warm_up_speaking', 1, 'Tickets', 'Talk about buying tickets', '{"prompt": "Where do you usually buy bus or train tickets?"}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_intro', 2, 'Ticket Words', 'Learn words for buying tickets', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'ticket', 'ตั๋ว', NULL),
    (activity_id_var, 'platform', 'ชานชาลา', NULL),
    (activity_id_var, 'single', 'เที่ยวเดียว', NULL),
    (activity_id_var, 'return', 'ไปกลับ', NULL),
    (activity_id_var, 'schedule', 'ตารางเวลา', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_matching_drag', 3, 'Match Ticket Words', 'Match travel ticket words', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'ticket', 'ตั๋ว', NULL),
    (activity_id_var, 'platform', 'ชานชาลา', NULL),
    (activity_id_var, 'single', 'เที่ยวเดียว', NULL),
    (activity_id_var, 'return', 'ไปกลับ', NULL),
    (activity_id_var, 'schedule', 'ตารางเวลา', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 4, 'Complete the Sentences 1', 'Fill with the correct word', '{"text": "I want a ___ ticket. The train leaves from ___ 3. The ___ shows 8:30.", "blanks": [{"id": "blank1", "text": "single", "options": ["single", "return", "platform", "schedule"], "correctAnswer": "single"}, {"id": "blank2", "text": "platform", "options": ["platform", "single", "return", "schedule"], "correctAnswer": "platform"}, {"id": "blank3", "text": "schedule", "options": ["schedule", "single", "return", "platform"], "correctAnswer": "schedule"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 5, 'Complete the Sentences 2', 'Fill with the correct word', '{"text": "Can I buy a ___ ticket to Chiang Mai? Which ___ do I use? Is this a ___ or one-way ticket?", "blanks": [{"id": "blank1", "text": "return", "options": ["return", "single", "ticket", "platform"], "correctAnswer": "return"}, {"id": "blank2", "text": "platform", "options": ["platform", "return", "ticket", "single"], "correctAnswer": "platform"}, {"id": "blank3", "text": "single", "options": ["single", "platform", "return", "ticket"], "correctAnswer": "single"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_explanation', 6, 'Present Simple Questions', 'Ask for tickets politely', '{"rules": "Use do/does for present simple questions.\n- Do you have a single ticket?\n- Does this train stop here?\nUse can for polite requests.\n- Can I buy a return ticket?\nShort answers: Yes, I do. No, I don''t.", "examples": ["Do you have the ticket?", "Does the train leave at nine?", "Can I buy a return ticket?", "Do we wait on platform 4?", "Can I see the schedule?"]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 7, 'Build Sentences 1', 'Arrange words', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'Do you have a single ticket', 'Do you have a single ticket?', '["Do", "you", "have", "a", "single", "ticket?"]'::jsonb),
    (activity_id_var, 'Can I buy a return ticket', 'Can I buy a return ticket?', '["Can", "I", "buy", "a", "return", "ticket?"]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 8, 'Build Sentences 2', 'Arrange words', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'Does this train stop here', 'Does this train stop here?', '["Does", "this", "train", "stop", "here?"]'::jsonb),
    (activity_id_var, 'Do we wait on platform four', 'Do we wait on platform four?', '["Do", "we", "wait", "on", "platform", "four?"]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'speaking_practice', 9, 'Talk About Tickets', 'Practice asking for tickets', '{"prompts": ["Where do you usually buy bus or train tickets?", "How do you ask for the time at a station?", "Do you prefer the bus or the train? Why?", "What information do you need when buying a ticket?", "Have you ever missed a bus or train?"]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (
      lesson_id,
      activity_type,
      activity_order,
      title,
      description,
      content
    ) VALUES (
      'A2-L11',
      'speaking_improvement',
      10,
      'Speaking Improvement',
      'Read the improved version of your speech',
      '{"type": "speaking_improvement", "similarityThreshold": 70}'::jsonb
    );
END $$;

