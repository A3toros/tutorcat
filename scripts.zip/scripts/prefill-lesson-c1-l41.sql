-- =========================================
-- Pre-fill Database with Sample Lesson Data
-- C1-L41: Technology Shaping Human Behavior
-- =========================================
DELETE FROM lesson_activity_results WHERE lesson_id = 'C1-L41';
DELETE FROM user_progress WHERE lesson_id = 'C1-L41';
DELETE FROM lesson_history WHERE lesson_id = 'C1-L41';
DELETE FROM grammar_sentences WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'C1-L41');
DELETE FROM vocabulary_items WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'C1-L41');
DELETE FROM lesson_activities WHERE lesson_id = 'C1-L41';
DELETE FROM lessons WHERE id = 'C1-L41';

INSERT INTO lessons (id, level, lesson_number, topic) VALUES
('C1-L41', 'C1', 41, 'Technology Shaping Human Behavior')
ON CONFLICT (id) DO UPDATE SET topic = EXCLUDED.topic;

DO $$
DECLARE
    lesson_id_var TEXT := 'C1-L41';
    activity_id_var UUID;
BEGIN
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'warm_up_speaking', 1, 'Technology and Behavior', 'Discuss technology shaping behavior', '{"prompt": "How has technology changed your habits?"}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_intro', 2, 'Technology Behavior Vocabulary', 'Learn vocabulary about technology and behavior', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'behavior', 'พฤติกรรม', NULL),
    (activity_id_var, 'routine', 'กิจวัตร', NULL),
    (activity_id_var, 'habit', 'นิสัย', NULL),
    (activity_id_var, 'influence', 'อิทธิพล', NULL),
    (activity_id_var, 'management', 'การจัดการ', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_matching_drag', 3, 'Match Technology Behavior Words', 'Match English words with Thai meanings', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'behavior', 'พฤติกรรม', NULL),
    (activity_id_var, 'routine', 'กิจวัตร', NULL),
    (activity_id_var, 'habit', 'นิสัย', NULL),
    (activity_id_var, 'influence', 'อิทธิพล', NULL),
    (activity_id_var, 'management', 'การจัดการ', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 4, 'Complete the Sentences 1', 'Fill with the correct word', '{"text": "Technology shapes human ___. Daily ___ have changed. New ___ emerge from tech ___.", "blanks": [{"id": "blank1", "text": "behavior", "options": ["behavior", "routine", "habit", "influence"], "correctAnswer": "behavior"}, {"id": "blank2", "text": "routines", "options": ["routines", "behavior", "habit", "influence"], "correctAnswer": "routines"}, {"id": "blank3", "text": "habits", "options": ["habits", "behavior", "routine", "influence"], "correctAnswer": "habits"}, {"id": "blank4", "text": "influence", "options": ["influence", "behavior", "routine", "habit"], "correctAnswer": "influence"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 5, 'Complete the Sentences 2', 'Fill with the correct word', '{"text": "Effective ___ of tech ___ requires awareness. Managing ___ helps control ___.", "blanks": [{"id": "blank1", "text": "management", "options": ["management", "behavior", "routine", "habit"], "correctAnswer": "management"}, {"id": "blank2", "text": "influence", "options": ["influence", "behavior", "routine", "habit"], "correctAnswer": "influence"}, {"id": "blank3", "text": "habits", "options": ["habits", "behavior", "routine", "influence"], "correctAnswer": "habits"}, {"id": "blank4", "text": "behavior", "options": ["behavior", "routine", "habit", "influence"], "correctAnswer": "behavior"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_explanation', 6, 'Advanced Perfect Aspect', 'Learn advanced perfect forms', '{"rules": "Advanced perfect aspect:\n- Present perfect: \"I have changed my habits over time.\"\n- Past perfect: \"I had developed routines before technology changed.\"\n- Future perfect: \"I will have adapted by then.\"\n- Perfect continuous: \"I have been using technology for years.\"\n\nUse for:\n- Completed actions with present relevance: \"I have altered my habits over time.\"\n- Past before past: \"I had established routines before tech changed them.\"\n- Future completion: \"I will have adapted to new technology by next year.\"", "examples": ["I have changed my habits over the years.", "I had developed routines before technology altered them.", "I will have adapted to new technology by next year.", "I have been using technology for decades.", "Having changed my habits, I understand tech influence better."]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 7, 'Build Sentences 1', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'I have changed my habits over the years.', 'I have changed my habits over the years.', '["I", "have", "changed", "my", "habits", "over", "the", "years."]'::jsonb),
    (activity_id_var, 'I had developed routines before technology altered them.', 'I had developed routines before technology altered them.', '["I", "had", "developed", "routines", "before", "technology", "altered", "them."]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 8, 'Build Sentences 2', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'I have been using technology for decades.', 'I have been using technology for decades.', '["I", "have", "been", "using", "technology", "for", "decades."]'::jsonb),
    (activity_id_var, 'Having changed my habits, I understand tech influence better.', 'Having changed my habits, I understand tech influence better.', '["Having", "changed", "my", "habits,", "I", "understand", "tech", "influence", "better."]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'speaking_practice', 9, 'Discuss Technology and Behavior', 'Practice speaking about technology shaping behavior', '{"prompts": ["What behaviors have changed over time?", "How has technology shaped routines?", "What habits concern you?", "What benefits have emerged?", "How do you manage tech influence?"]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (
      lesson_id,
      activity_type,
      activity_order,
      title,
      description,
      content
    ) VALUES (
      'C1-L41',
      'speaking_improvement',
      10,
      'Speaking Improvement',
      'Read the improved version of your speech',
      '{"type": "speaking_improvement", "similarityThreshold": 70}'::jsonb
    );
END $$;
