-- =========================================
-- Pre-fill Database with Sample Lesson Data
-- A1-L75: Visiting a Doctor (very basic)
-- =========================================

DELETE FROM grammar_sentences WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'A1-L75');
DELETE FROM vocabulary_items WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'A1-L75');
DELETE FROM lesson_activities WHERE lesson_id = 'A1-L75';
DELETE FROM lessons WHERE id = 'A1-L75';

INSERT INTO lessons (id, level, lesson_number, topic) VALUES
('A1-L75', 'A1', 75, 'Visiting a Doctor (very basic)')
ON CONFLICT (id) DO UPDATE SET topic = EXCLUDED.topic;

DO $$
DECLARE
    lesson_id_var TEXT := 'A1-L75';
    activity_id_var UUID;
BEGIN
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'warm_up_speaking', 1, 'Doctor Visit', 'Talk about asking for help', '{"prompt": "Can you help me?"}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_intro', 2, 'Doctor Words', 'Learn simple doctor words', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'doctor', 'หมอ', NULL),
    (activity_id_var, 'medicine', 'ยา', NULL),
    (activity_id_var, 'pain', 'เจ็บปวด', NULL),
    (activity_id_var, 'head', 'หัว', NULL),
    (activity_id_var, 'arm', 'แขน', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_matching_drag', 3, 'Match Doctor Words', 'Match doctor words', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'doctor', 'หมอ', NULL),
    (activity_id_var, 'medicine', 'ยา', NULL),
    (activity_id_var, 'pain', 'เจ็บปวด', NULL),
    (activity_id_var, 'head', 'หัว', NULL),
    (activity_id_var, 'arm', 'แขน', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 4, 'Complete the Sentences 1', 'Fill with the correct word', '{"text": "I see a ___. I need ___.", "blanks": [{"id": "blank1", "text": "doctor", "options": ["doctor", "medicine", "pain", "head"], "correctAnswer": "doctor"}, {"id": "blank2", "text": "medicine", "options": ["medicine", "doctor", "arm", "pain"], "correctAnswer": "medicine"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 5, 'Complete the Sentences 2', 'Fill with the correct word', '{"text": "My ___ hurts. My ___ has pain.", "blanks": [{"id": "blank1", "text": "head", "options": ["head", "arm", "doctor", "medicine"], "correctAnswer": "head"}, {"id": "blank2", "text": "arm", "options": ["arm", "head", "pain", "medicine"], "correctAnswer": "arm"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_explanation', 6, 'Can (requests)', 'Ask the doctor for help', '{"rules": "Use can to ask for help.\n- Can you help me?\n- Can I have medicine?\nAsk: Where is the pain?", "examples": ["Can you help me?", "Can I have medicine?", "Where is the pain?", "Is your head okay?", "Is your arm hurt?"]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 7, 'Build Sentences 1', 'Arrange words', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'Can you help me', 'Can you help me?', '["Can", "you", "help", "me?"]'::jsonb),
    (activity_id_var, 'Can I have medicine', 'Can I have medicine?', '["Can", "I", "have", "medicine?"]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 8, 'Build Sentences 2', 'Arrange words', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'Where is the pain', 'Where is the pain?', '["Where", "is", "the", "pain?"]'::jsonb),
    (activity_id_var, 'Is your head okay', 'Is your head okay?', '["Is", "your", "head", "okay?"]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'speaking_practice', 9, 'Talk at the Doctor', 'Practice polite doctor requests', '{"prompts": ["Can you help me?", "Where is the pain?", "Do I need medicine?", "Is your head okay?", "Is your arm hurt?"]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (
      lesson_id,
      activity_type,
      activity_order,
      title,
      description,
      content
    ) VALUES (
      'A1-L75',
      'speaking_improvement',
      10,
      'Speaking Improvement',
      'Read the improved version of your speech',
      '{"type": "speaking_improvement", "similarityThreshold": 70}'::jsonb
    );
END $$;

