-- =========================================
-- Pre-fill Database with Sample Lesson Data
-- A2-L84: Eating at Home
-- =========================================

DELETE FROM grammar_sentences WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'A2-L84');
DELETE FROM vocabulary_items WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'A2-L84');
DELETE FROM lesson_activities WHERE lesson_id = 'A2-L84';
DELETE FROM lessons WHERE id = 'A2-L84';

INSERT INTO lessons (id, level, lesson_number, topic) VALUES
('A2-L84', 'A2', 84, 'Eating at Home')
ON CONFLICT (id) DO UPDATE SET topic = EXCLUDED.topic;

DO $$
DECLARE
    lesson_id_var TEXT := 'A2-L84';
    activity_id_var UUID;
BEGIN
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'warm_up_speaking', 1, 'Home Meals', 'Talk about eating at home', '{"prompt": "How often do you cook at home?"}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_intro', 2, 'Home Eating Words', 'Learn eating-at-home vocabulary', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'cook', 'ทำอาหาร', NULL),
    (activity_id_var, 'eat out', 'กินข้าวนอกบ้าน', NULL),
    (activity_id_var, 'often', 'บ่อย', NULL),
    (activity_id_var, 'sometimes', 'บางครั้ง', NULL),
    (activity_id_var, 'rarely', 'ไม่บ่อย', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_matching_drag', 3, 'Match Home Eating Words', 'Match home eating words', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'cook', 'ทำอาหาร', NULL),
    (activity_id_var, 'eat out', 'กินข้าวนอกบ้าน', NULL),
    (activity_id_var, 'often', 'บ่อย', NULL),
    (activity_id_var, 'sometimes', 'บางครั้ง', NULL),
    (activity_id_var, 'rarely', 'ไม่บ่อย', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 4, 'Complete the Sentences 1', 'Fill with the correct word', '{"text": "I ___ at home. We ___ when we are busy. I ___ eat out.", "blanks": [{"id": "blank1", "text": "cook", "options": ["cook", "eat out", "rarely", "often"], "correctAnswer": "cook"}, {"id": "blank2", "text": "eat out", "options": ["eat out", "rarely", "cook", "often"], "correctAnswer": "eat out"}, {"id": "blank3", "text": "rarely", "options": ["rarely", "often", "cook", "eat out"], "correctAnswer": "rarely"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 5, 'Complete the Sentences 2', 'Fill with the correct word', '{"text": "We ___ cook on weekends. We ___ eat out on Fridays.", "blanks": [{"id": "blank1", "text": "often", "options": ["often", "sometimes", "rarely", "cook"], "correctAnswer": "often"}, {"id": "blank2", "text": "sometimes", "options": ["sometimes", "often", "rarely", "eat out"], "correctAnswer": "sometimes"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_explanation', 6, 'Adverbs of Frequency', 'Describe how often you eat at home', '{"rules": "Use always/usually/often/sometimes/rarely/never to show frequency.\nPosition: before main verb; after be.\n- We often cook at home.\n- I am usually hungry at six.", "examples": ["We often cook at home.", "I sometimes eat out.", "She rarely skips breakfast.", "Do you often cook on weekends?", "They are usually hungry at six."]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 7, 'Build Sentences 1', 'Arrange words', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'We often cook at home', 'We often cook at home.', '["We", "often", "cook", "at", "home."]'::jsonb),
    (activity_id_var, 'I sometimes eat out', 'I sometimes eat out.', '["I", "sometimes", "eat", "out."]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 8, 'Build Sentences 2', 'Arrange words', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'She rarely skips breakfast', 'She rarely skips breakfast.', '["She", "rarely", "skips", "breakfast."]'::jsonb),
    (activity_id_var, 'Do you often cook on weekends', 'Do you often cook on weekends?', '["Do", "you", "often", "cook", "on", "weekends?"]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'speaking_practice', 9, 'Talk About Eating at Home', 'Practice home meal routines', '{"prompts": ["How often do you cook at home?", "Who usually cooks in your house?", "What food do you cook most often?", "Do you usually eat at home or outside?", "What do you cook on busy days?"]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (
      lesson_id,
      activity_type,
      activity_order,
      title,
      description,
      content
    ) VALUES (
      'A2-L84',
      'speaking_improvement',
      10,
      'Speaking Improvement',
      'Read the improved version of your speech',
      '{"type": "speaking_improvement", "similarityThreshold": 70}'::jsonb
    );
END $$;

