-- =========================================
-- Pre-fill Database with Sample Lesson Data
-- A1-L14: Numbers 1–100
-- =========================================

DELETE FROM grammar_sentences WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'A1-L14');
DELETE FROM vocabulary_items WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'A1-L14');
DELETE FROM lesson_activities WHERE lesson_id = 'A1-L14';
DELETE FROM lessons WHERE id = 'A1-L14';

INSERT INTO lessons (id, level, lesson_number, topic) VALUES
('A1-L14', 'A1', 14, 'Numbers 1–100')
ON CONFLICT (id) DO UPDATE SET topic = EXCLUDED.topic;

DO $$
DECLARE
    lesson_id_var TEXT := 'A1-L14';
    activity_id_var UUID;
BEGIN
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'warm_up_speaking', 1, 'Numbers', 'Talk about numbers', '{"prompt": "What numbers do you use every day?"}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_intro', 2, 'Number Words', 'Learn number words', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'ten', 'สิบ', NULL),
    (activity_id_var, 'twenty', 'ยี่สิบ', NULL),
    (activity_id_var, 'thirty', 'สามสิบ', NULL),
    (activity_id_var, 'forty', 'สี่สิบ', NULL),
    (activity_id_var, 'hundred', 'ร้อย', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_matching_drag', 3, 'Match Number Words', 'Match number words', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'ten', 'สิบ', NULL),
    (activity_id_var, 'twenty', 'ยี่สิบ', NULL),
    (activity_id_var, 'thirty', 'สามสิบ', NULL),
    (activity_id_var, 'forty', 'สี่สิบ', NULL),
    (activity_id_var, 'hundred', 'ร้อย', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 4, 'Complete the Sentences 1', 'Fill with the correct word', '{"text": "I am __ years old. My friend is __.", "blanks": [{"id": "blank1", "text": "ten", "options": ["ten", "twenty", "thirty", "hundred"], "correctAnswer": "ten"}, {"id": "blank2", "text": "twenty", "options": ["twenty", "thirty", "forty", "ten"], "correctAnswer": "twenty"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 5, 'Complete the Sentences 2', 'Fill with the correct word', '{"text": "There are __ books. There are __ chairs.", "blanks": [{"id": "blank1", "text": "thirty", "options": ["thirty", "ten", "twenty", "hundred"], "correctAnswer": "thirty"}, {"id": "blank2", "text": "forty", "options": ["forty", "hundred", "thirty", "ten"], "correctAnswer": "forty"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_explanation', 6, 'Be + Numbers', 'Use be with age and count', '{"rules": "Use be with numbers for age and quantity.\n- I am ten.\n- It is twenty.\nAsk: How old are you? How many...?", "examples": ["I am ten years old.", "She is twenty.", "There are thirty students.", "How old are you?", "How many books do you have?"]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 7, 'Build Sentences 1', 'Arrange words', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'I am ten years old', 'I am ten years old.', '["I", "am", "ten", "years", "old."]'::jsonb),
    (activity_id_var, 'She is twenty', 'She is twenty.', '["She", "is", "twenty."]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 8, 'Build Sentences 2', 'Arrange words', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'There are thirty students', 'There are thirty students.', '["There", "are", "thirty", "students."]'::jsonb),
    (activity_id_var, 'How many books do you have', 'How many books do you have?', '["How", "many", "books", "do", "you", "have?"]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'speaking_practice', 9, 'Talk About Numbers', 'Practice numbers', '{"prompts": ["How old are you?", "What is your favorite number?", "How many books do you have?", "How many chairs are there?", "Do you like big numbers?"]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (
      lesson_id,
      activity_type,
      activity_order,
      title,
      description,
      content
    ) VALUES (
      'A1-L14',
      'speaking_improvement',
      10,
      'Speaking Improvement',
      'Read the improved version of your speech',
      '{"type": "speaking_improvement", "similarityThreshold": 70}'::jsonb
    );
END $$;

