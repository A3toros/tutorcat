-- =========================================
-- Pre-fill Database with Sample Lesson Data
-- B1-L59: Free Time & Work–Life Balance
-- =========================================

DELETE FROM grammar_sentences WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'B1-L59');
DELETE FROM vocabulary_items WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'B1-L59');
DELETE FROM lesson_activities WHERE lesson_id = 'B1-L59';
DELETE FROM lessons WHERE id = 'B1-L59';

INSERT INTO lessons (id, level, lesson_number, topic) VALUES
('B1-L59', 'B1', 59, 'Free Time & Work–Life Balance')
ON CONFLICT (id) DO UPDATE SET topic = EXCLUDED.topic;

DO $$
DECLARE
    lesson_id_var TEXT := 'B1-L59';
    activity_id_var UUID;
BEGIN
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'warm_up_speaking', 1, 'Protecting Free Time', 'Talk about keeping balance', '{"prompt": "How have you protected your free time lately?"}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_intro', 2, 'Balance Words', 'Learn vocabulary about work–life balance', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'unwind', 'ผ่อนคลาย', NULL),
    (activity_id_var, 'recharge', 'เติมพลัง', NULL),
    (activity_id_var, 'schedule', 'ตารางเวลา', NULL),
    (activity_id_var, 'boundary', 'ขอบเขต', NULL),
    (activity_id_var, 'hobby', 'งานอดิเรก', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_matching_drag', 3, 'Match Balance Words', 'Match words with meanings', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'unwind', 'ผ่อนคลาย', NULL),
    (activity_id_var, 'recharge', 'เติมพลัง', NULL),
    (activity_id_var, 'schedule', 'ตารางเวลา', NULL),
    (activity_id_var, 'boundary', 'ขอบเขต', NULL),
    (activity_id_var, 'hobby', 'งานอดิเรก', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 4, 'Complete the Sentences 1', 'Fill with the correct word', '{"text": "I block my ___. I set a ___. I need time to ___.", "blanks": [{"id": "blank1", "text": "schedule", "options": ["schedule", "boundary", "unwind", "hobby"], "correctAnswer": "schedule"}, {"id": "blank2", "text": "boundary", "options": ["boundary", "schedule", "hobby", "recharge"], "correctAnswer": "boundary"}, {"id": "blank3", "text": "unwind", "options": ["unwind", "recharge", "boundary", "hobby"], "correctAnswer": "unwind"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 5, 'Complete the Sentences 2', 'Fill with the correct word', '{"text": "Breaks help me ___. A simple ___ keeps me happy. A clear ___ protects evenings.", "blanks": [{"id": "blank1", "text": "recharge", "options": ["recharge", "unwind", "boundary", "schedule"], "correctAnswer": "recharge"}, {"id": "blank2", "text": "hobby", "options": ["hobby", "schedule", "recharge", "unwind"], "correctAnswer": "hobby"}, {"id": "blank3", "text": "boundary", "options": ["boundary", "hobby", "recharge", "schedule"], "correctAnswer": "boundary"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    -- Grammar Explanation: Present Perfect (balance experiences)
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_explanation', 6, 'Present Perfect for Balance', 'Use have/has + past participle to share recent balance experiences', '{"rules": "Present perfect for experiences and changes up to now.\\n- I have protected my weekends.\\n- She has added clear boundaries.\\nAvoid exact past times.", "examples": ["I have protected my weekends lately.", "She has added clear boundaries at work.", "They have scheduled breaks into each day.", "We have recharged by taking short walks.", "He has picked up a hobby to unwind."]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 7, 'Build Sentences 1', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'I have protected my weekends lately', 'I have protected my weekends lately', '["I", "have", "protected", "my", "weekends", "lately"]'::jsonb),
    (activity_id_var, 'She has added clear boundaries at work', 'She has added clear boundaries at work', '["She", "has", "added", "clear", "boundaries", "at", "work"]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 8, 'Build Sentences 2', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'They have scheduled breaks into each day', 'They have scheduled breaks into each day', '["They", "have", "scheduled", "breaks", "into", "each", "day"]'::jsonb),
    (activity_id_var, 'He has picked up a hobby to unwind', 'He has picked up a hobby to unwind', '["He", "has", "picked", "up", "a", "hobby", "to", "unwind"]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'speaking_practice', 9, 'Talk About Balance', 'Practice talking about work–life balance', '{"prompts": ["How have you protected your free time lately?", "When did you last feel balanced?", "What hobby brings you back to life?"]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (
      lesson_id,
      activity_type,
      activity_order,
      title,
      description,
      content
    ) VALUES (
      'B1-L59',
      'speaking_improvement',
      10,
      'Speaking Improvement',
      'Read the improved version of your speech',
      '{"type": "speaking_improvement", "similarityThreshold": 70}'::jsonb
    );
END $$;

