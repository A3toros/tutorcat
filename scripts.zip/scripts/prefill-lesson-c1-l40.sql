-- =========================================
-- Pre-fill Database with Sample Lesson Data
-- C1-L40: Language as a Social Divider
-- =========================================
DELETE FROM lesson_activity_results WHERE lesson_id = 'C1-L40';
DELETE FROM user_progress WHERE lesson_id = 'C1-L40';
DELETE FROM lesson_history WHERE lesson_id = 'C1-L40';
DELETE FROM grammar_sentences WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'C1-L40');
DELETE FROM vocabulary_items WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'C1-L40');
DELETE FROM lesson_activities WHERE lesson_id = 'C1-L40';
DELETE FROM lessons WHERE id = 'C1-L40';

INSERT INTO lessons (id, level, lesson_number, topic) VALUES
('C1-L40', 'C1', 40, 'Language as a Social Divider')
ON CONFLICT (id) DO UPDATE SET topic = EXCLUDED.topic;

DO $$
DECLARE
    lesson_id_var TEXT := 'C1-L40';
    activity_id_var UUID;
BEGIN
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'warm_up_speaking', 1, 'Language as Divider', 'Discuss language as a social divider', '{"prompt": "How can language exclude people?"}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_intro', 2, 'Language Divider Vocabulary', 'Learn vocabulary about language divisions', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'barrier', 'อุปสรรค', NULL),
    (activity_id_var, 'exclusion', 'การกีดกัน', NULL),
    (activity_id_var, 'division', 'การแบ่งแยก', NULL),
    (activity_id_var, 'inclusion', 'การรวมเข้า', NULL),
    (activity_id_var, 'adaptation', 'การปรับตัว', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_matching_drag', 3, 'Match Language Divider Words', 'Match English words with Thai meanings', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'barrier', 'อุปสรรค', NULL),
    (activity_id_var, 'exclusion', 'การกีดกัน', NULL),
    (activity_id_var, 'division', 'การแบ่งแยก', NULL),
    (activity_id_var, 'inclusion', 'การรวมเข้า', NULL),
    (activity_id_var, 'adaptation', 'การปรับตัว', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 4, 'Complete the Sentences 1', 'Fill with the correct word', '{"text": "Language ___ create ___. Promoting ___ requires ___.", "blanks": [{"id": "blank1", "text": "barriers", "options": ["barriers", "exclusion", "division", "inclusion"], "correctAnswer": "barriers"}, {"id": "blank2", "text": "division", "options": ["division", "barrier", "exclusion", "inclusion"], "correctAnswer": "division"}, {"id": "blank3", "text": "inclusion", "options": ["inclusion", "barrier", "exclusion", "division"], "correctAnswer": "inclusion"}, {"id": "blank4", "text": "adaptation", "options": ["adaptation", "barrier", "exclusion", "division"], "correctAnswer": "adaptation"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 5, 'Complete the Sentences 2', 'Fill with the correct word', '{"text": "Language ___ affects many. Education plays a role in reducing ___.", "blanks": [{"id": "blank1", "text": "exclusion", "options": ["exclusion", "barrier", "division", "inclusion"], "correctAnswer": "exclusion"}, {"id": "blank2", "text": "barriers", "options": ["barriers", "exclusion", "division", "inclusion"], "correctAnswer": "barriers"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_explanation', 6, 'Advanced Passives', 'Learn advanced passive structures', '{"rules": "Advanced passive forms:\n- \"Language should be used inclusively.\" (obligation)\n- \"Barriers must be removed.\" (necessity)\n- \"Exclusion is being addressed.\" (continuous)\n- \"Divisions have been created.\" (perfect)\n- \"Inclusion will be improved.\" (future)\n\nUse when:\n- Focus is on action, not actor: \"Barriers should be removed.\"\n- Actor is unknown/unimportant: \"Exclusion was caused by language.\"\n- Formal/impersonal tone: \"It is required that inclusion be promoted.\"", "examples": ["Language barriers should be removed to promote inclusion.", "Exclusion must be addressed in multilingual settings.", "Divisions are being created by language differences.", "Inclusion has been improved through education.", "Barriers will be reduced through adaptation."]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 7, 'Build Sentences 1', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'Language barriers should be removed to promote inclusion.', 'Language barriers should be removed to promote inclusion.', '["Language", "barriers", "should", "be", "removed", "to", "promote", "inclusion."]'::jsonb),
    (activity_id_var, 'Exclusion must be addressed in multilingual settings.', 'Exclusion must be addressed in multilingual settings.', '["Exclusion", "must", "be", "addressed", "in", "multilingual", "settings."]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 8, 'Build Sentences 2', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'Divisions are being created by language differences.', 'Divisions are being created by language differences.', '["Divisions", "are", "being", "created", "by", "language", "differences."]'::jsonb),
    (activity_id_var, 'Inclusion has been improved through education.', 'Inclusion has been improved through education.', '["Inclusion", "has", "been", "improved", "through", "education."]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'speaking_practice', 9, 'Discuss Language Divisions', 'Practice speaking about language as a divider', '{"prompts": ["How does language create barriers?", "Who is affected by language divisions?", "How can inclusion be improved?", "Who should adapt in multilingual settings?", "What role does education play?"]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (
      lesson_id,
      activity_type,
      activity_order,
      title,
      description,
      content
    ) VALUES (
      'C1-L40',
      'speaking_improvement',
      10,
      'Speaking Improvement',
      'Read the improved version of your speech',
      '{"type": "speaking_improvement", "similarityThreshold": 70}'::jsonb
    );
END $$;
