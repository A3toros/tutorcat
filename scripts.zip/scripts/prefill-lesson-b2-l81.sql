-- ===== LESSON B2-L81 =====

-- =========================================
-- Pre-fill Database with Sample Lesson Data
-- B2-L81: Evaluating information
-- =========================================

DELETE FROM lesson_activity_results WHERE lesson_id = 'B2-L81';
DELETE FROM user_progress WHERE lesson_id = 'B2-L81';
DELETE FROM lesson_history WHERE lesson_id = 'B2-L81';
DELETE FROM grammar_sentences WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'B2-L81');
DELETE FROM vocabulary_items WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'B2-L81');
DELETE FROM lesson_activities WHERE lesson_id = 'B2-L81';
DELETE FROM lessons WHERE id = 'B2-L81';

INSERT INTO lessons (id, level, lesson_number, topic) VALUES
('B2-L81', 'B2', 81, 'Evaluating information')
ON CONFLICT (id) DO UPDATE SET topic = EXCLUDED.topic;

DO $$
DECLARE
    lesson_id_var TEXT := 'B2-L81';
    activity_id_var UUID;
BEGIN
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'warm_up_speaking', 1, 'Information Check', 'Talk about checking information online', '{"prompt": "How do you know if news is true?"}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_intro', 2, 'Information Words', 'Learn words for checking information', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'opinion', 'ความเห็น', NULL),
    (activity_id_var, 'bias', 'อคติ', NULL),
    (activity_id_var, 'headline', 'หัวข้อข่าว', NULL),
    (activity_id_var, 'verify', 'ตรวจสอบ', NULL),
    (activity_id_var, 'platform', 'แพลตฟอร์ม', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_matching_drag', 3, 'Match Information Words', 'Match information checking words', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'opinion', 'ความเห็น', NULL),
    (activity_id_var, 'bias', 'อคติ', NULL),
    (activity_id_var, 'headline', 'หัวข้อข่าว', NULL),
    (activity_id_var, 'verify', 'ตรวจสอบ', NULL),
    (activity_id_var, 'platform', 'แพลตฟอร์ม', NULL);

    -- 4. Vocabulary Fill Blanks #1
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 4, 'Complete the Sentences 1', 'Fill in the blanks with correct words', '{"text": "This is just an ___. There is ___. Check the ___.", "blanks": [{"id": "blank1", "text": "opinion", "options": ["opinion", "bias", "headline", "verify"], "correctAnswer": "opinion"}, {"id": "blank2", "text": "bias", "options": ["bias", "opinion", "headline", "platform"], "correctAnswer": "bias"}, {"id": "blank3", "text": "headline", "options": ["headline", "opinion", "bias", "verify"], "correctAnswer": "headline"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    -- 5. Vocabulary Fill Blanks #2
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 5, 'Complete the Sentences 2', 'Fill in the blanks with correct words', '{"text": "I need to ___ this information. Which ___ do you use? We should ___.", "blanks": [{"id": "blank1", "text": "verify", "options": ["verify", "opinion", "bias", "headline"], "correctAnswer": "verify"}, {"id": "blank2", "text": "platform", "options": ["platform", "verify", "opinion", "bias"], "correctAnswer": "platform"}, {"id": "blank3", "text": "verify", "options": ["verify", "platform", "opinion", "bias"], "correctAnswer": "verify"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    -- 6. Grammar Explanation
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_explanation', 6, 'Reduced Relative Clauses', 'Learn shortened relative clauses for information', '{"rules": "Use reduced relative clauses to make sentences shorter:\n\n- Remove relative pronoun (who/which/that) and be verb\n- The news (which) we trust → The news we trust\n- Information (which was) checked quickly → Information checked quickly\n- Sources (which were) chosen carefully → Sources chosen carefully\n- Use past participle for passive meaning", "examples": ["The news we trust comes from verified sources.", "Information checked quickly is often accurate.", "Sources chosen carefully build trust.", "Articles written by experts are reliable.", "News shared without checking can be false."]}'::jsonb)
    RETURNING id INTO activity_id_var;

    -- 7. Grammar Sentences #1
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 7, 'Build Sentences 1', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'The news we trust comes from verified sources', 'The news we trust comes from verified sources.', '["The", "news", "we", "trust", "comes", "from", "verified", "sources."]'::jsonb),
    (activity_id_var, 'Information checked quickly is often accurate', 'Information checked quickly is often accurate.', '["Information", "checked", "quickly", "is", "often", "accurate."]'::jsonb);

    -- 8. Grammar Sentences #2
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 8, 'Build Sentences 2', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'Sources chosen carefully build trust', 'Sources chosen carefully build trust.', '["Sources", "chosen", "carefully", "build", "trust."]'::jsonb),
    (activity_id_var, 'Articles written by experts are reliable', 'Articles written by experts are reliable.', '["Articles", "written", "by", "experts", "are", "reliable."]'::jsonb);

    -- 9. Speaking Practice
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'speaking_practice', 9, 'Talk About Information', 'Practice talking about checking information', '{"prompts": ["How do you check if news is real?", "Which websites do you trust?", "When do you share information?", "How do you verify information?", "What platforms do you use for news?"]}'::jsonb)
    RETURNING id INTO activity_id_var;

    -- 10. Speaking Improvement
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'speaking_improvement', 10, 'Speaking Improvement', 'Read the improved version of your speech', '{"type": "speaking_improvement", "similarityThreshold": 70}'::jsonb)
    RETURNING id INTO activity_id_var;
END $$;