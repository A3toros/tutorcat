-- =========================================
-- Pre-fill Database with Sample Lesson Data
-- B2-L29: Online information reliability
-- =========================================

DELETE FROM grammar_sentences WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'B2-L29');
DELETE FROM vocabulary_items WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'B2-L29');
DELETE FROM lesson_activities WHERE lesson_id = 'B2-L29';
DELETE FROM lessons WHERE id = 'B2-L29';

INSERT INTO lessons (id, level, lesson_number, topic) VALUES
('B2-L29', 'B2', 29, 'Online information reliability')
ON CONFLICT (id) DO UPDATE SET topic = EXCLUDED.topic;

DO $$
DECLARE
    lesson_id_var TEXT := 'B2-L29';
    activity_id_var UUID;
BEGIN
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'warm_up_speaking', 1, 'Signal Checks', 'Talk about credibility', '{"prompt": "What signals, which you trust, prove credibility, and when do you flag a post?"}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_intro', 2, 'Credibility Words', 'Key words for reliability', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'credible', 'น่าเชื่อถือ', NULL),
    (activity_id_var, 'cross-check', 'ตรวจซ้ำ/ตรวจหลายแหล่ง', NULL),
    (activity_id_var, 'rumor', 'ข่าวลือ', NULL),
    (activity_id_var, 'flag', 'ทำเครื่องหมาย/รายงาน', NULL),
    (activity_id_var, 'verify', 'ตรวจสอบความถูกต้อง', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_matching_drag', 3, 'Match Credibility Words', 'Match words with meanings', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'credible', 'น่าเชื่อถือ', NULL),
    (activity_id_var, 'cross-check', 'ตรวจซ้ำ/ตรวจหลายแหล่ง', NULL),
    (activity_id_var, 'rumor', 'ข่าวลือ', NULL),
    (activity_id_var, 'flag', 'ทำเครื่องหมาย/รายงาน', NULL),
    (activity_id_var, 'verify', 'ตรวจสอบความถูกต้อง', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 4, 'Complete the Sentences 1', 'Fill with the correct word', '{"text": "Is the site ___? I ___ facts with other sources. That story might be a ___.", "blanks": [{"id": "blank1", "text": "credible", "options": ["credible", "verify", "flag", "rumor"], "correctAnswer": "credible"}, {"id": "blank2", "text": "cross-check", "options": ["cross-check", "verify", "flag", "rumor"], "correctAnswer": "cross-check"}, {"id": "blank3", "text": "rumor", "options": ["rumor", "flag", "credible", "verify"], "correctAnswer": "rumor"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 5, 'Complete the Sentences 2', 'Fill with the correct word', '{"text": "I ___ risky posts. I always ___ details.", "blanks": [{"id": "blank1", "text": "flag", "options": ["flag", "credible", "rumor", "cross-check"], "correctAnswer": "flag"}, {"id": "blank2", "text": "verify", "options": ["verify", "flag", "cross-check", "credible"], "correctAnswer": "verify"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_explanation', 6, 'Relative Clauses (non-defining)', 'Add trusted signals as extra info', '{"rules": "Use commas with who/which/where to add extra, non-essential information. Do not omit the pronoun.\\n- That site, which is peer-reviewed, is reliable.\\n- My friend, who cross-checks everything, spotted the error.", "examples": ["This platform, which I trust, verifies posts fast.", "My mentor, who hates rumors, checks sources twice.", "The article, which cited data, felt credible.", "That report, which was flagged, was removed.", "The study, which we cross-checked, held up well."]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 7, 'Build Sentences 1', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'This platform, which I trust, verifies posts fast', 'This platform, which I trust, verifies posts fast.', '["This", "platform,", "which", "I", "trust,", "verifies", "posts", "fast."]'::jsonb),
    (activity_id_var, 'My friend, who cross-checks everything, spotted the error', 'My friend, who cross-checks everything, spotted the error.', '["My", "friend,", "who", "cross-checks", "everything,", "spotted", "the", "error."]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 8, 'Build Sentences 2', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'The article, which cited data, felt credible', 'The article, which cited data, felt credible.', '["The", "article,", "which", "cited", "data,", "felt", "credible."]'::jsonb),
    (activity_id_var, 'That report, which was flagged, was removed', 'That report, which was flagged, was removed.', '["That", "report,", "which", "was", "flagged,", "was", "removed."]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'speaking_practice', 9, 'Talk About Reliability', 'Practice non-defining relatives', '{"prompts": ["What signals, which you trust, prove credibility?", "When do you flag a post?", "Who in your circle, who you trust, helps verify?"]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (
      lesson_id,
      activity_type,
      activity_order,
      title,
      description,
      content
    ) VALUES (
      'B2-L29',
      'speaking_improvement',
      10,
      'Speaking Improvement',
      'Read the improved version of your speech',
      '{"type": "speaking_improvement", "similarityThreshold": 70}'::jsonb
    );
END $$;


