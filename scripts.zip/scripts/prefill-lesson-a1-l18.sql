-- =========================================
-- Pre-fill Database with Sample Lesson Data
-- A1-L18: Your Bedroom
-- =========================================

DELETE FROM grammar_sentences WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'A1-L18');
DELETE FROM vocabulary_items WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'A1-L18');
DELETE FROM lesson_activities WHERE lesson_id = 'A1-L18';
DELETE FROM lessons WHERE id = 'A1-L18';

INSERT INTO lessons (id, level, lesson_number, topic) VALUES
('A1-L18', 'A1', 18, 'Your Bedroom')
ON CONFLICT (id) DO UPDATE SET topic = EXCLUDED.topic;

DO $$
DECLARE
    lesson_id_var TEXT := 'A1-L18';
    activity_id_var UUID;
BEGIN
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'warm_up_speaking', 1, 'Bedroom Items', 'Talk about your room', '{"prompt": "What is in your bedroom?"}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_intro', 2, 'Bedroom Words', 'Learn bedroom words', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'bed', 'เตียง', NULL),
    (activity_id_var, 'lamp', 'โคมไฟ', NULL),
    (activity_id_var, 'closet', 'ตู้เสื้อผ้า', NULL),
    (activity_id_var, 'window', 'หน้าต่าง', NULL),
    (activity_id_var, 'door', 'ประตู', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_matching_drag', 3, 'Match Bedroom Words', 'Match bedroom words', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'bed', 'เตียง', NULL),
    (activity_id_var, 'lamp', 'โคมไฟ', NULL),
    (activity_id_var, 'closet', 'ตู้เสื้อผ้า', NULL),
    (activity_id_var, 'window', 'หน้าต่าง', NULL),
    (activity_id_var, 'door', 'ประตู', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 4, 'Complete the Sentences 1', 'Fill with the correct word', '{"text": "There is a ___. There is a ___.", "blanks": [{"id": "blank1", "text": "bed", "options": ["bed", "lamp", "closet", "door"], "correctAnswer": "bed"}, {"id": "blank2", "text": "lamp", "options": ["lamp", "window", "closet", "door"], "correctAnswer": "lamp"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 5, 'Complete the Sentences 2', 'Fill with the correct word', '{"text": "There is a ___. There are two ___.", "blanks": [{"id": "blank1", "text": "closet", "options": ["closet", "window", "door", "bed"], "correctAnswer": "closet"}, {"id": "blank2", "text": "windows", "options": ["windows", "doors", "beds", "lamps"], "correctAnswer": "windows"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_explanation', 6, 'There is / There are', 'Describe items in a room', '{"rules": "Use there is for one; there are for many.\n- There is a bed.\n- There are two windows.\nAsk: Is there a lamp?", "examples": ["There is a bed.", "There is a lamp.", "There are two windows.", "Is there a closet?", "Are there two doors?"]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 7, 'Build Sentences 1', 'Arrange words', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'There is a bed', 'There is a bed.', '["There", "is", "a", "bed."]'::jsonb),
    (activity_id_var, 'There are two windows', 'There are two windows.', '["There", "are", "two", "windows."]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 8, 'Build Sentences 2', 'Arrange words', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'Is there a lamp', 'Is there a lamp?', '["Is", "there", "a", "lamp?"]'::jsonb),
    (activity_id_var, 'Are there two doors', 'Are there two doors?', '["Are", "there", "two", "doors?"]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'speaking_practice', 9, 'Talk About Your Room', 'Practice there is/are', '{"prompts": ["What is in your bedroom?", "Is there a lamp?", "How many windows?", "Is your bed big?", "Do you have a closet?"]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (
      lesson_id,
      activity_type,
      activity_order,
      title,
      description,
      content
    ) VALUES (
      'A1-L18',
      'speaking_improvement',
      10,
      'Speaking Improvement',
      'Read the improved version of your speech',
      '{"type": "speaking_improvement", "similarityThreshold": 70}'::jsonb
    );
END $$;

