-- =========================================
-- Pre-fill Database with Sample Lesson Data
-- A2-L69: Exercising With Friends
-- =========================================

DELETE FROM grammar_sentences WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'A2-L69');
DELETE FROM vocabulary_items WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'A2-L69');
DELETE FROM lesson_activities WHERE lesson_id = 'A2-L69';
DELETE FROM lessons WHERE id = 'A2-L69';

INSERT INTO lessons (id, level, lesson_number, topic) VALUES
('A2-L69', 'A2', 69, 'Exercising With Friends')
ON CONFLICT (id) DO UPDATE SET topic = EXCLUDED.topic;

DO $$
DECLARE
    lesson_id_var TEXT := 'A2-L69';
    activity_id_var UUID;
BEGIN
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'warm_up_speaking', 1, 'Exercise Together', 'Talk about working out with friends', '{"prompt": "How do you usually exercise?"}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_intro', 2, 'Together Exercise Words', 'Learn exercise-with-friends words', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'together', 'ด้วยกัน', NULL),
    (activity_id_var, 'slow', 'ช้า', NULL),
    (activity_id_var, 'fast', 'เร็ว', NULL),
    (activity_id_var, 'carefully', 'อย่างระมัดระวัง', NULL),
    (activity_id_var, 'safely', 'อย่างปลอดภัย', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_matching_drag', 3, 'Match Exercise Together Words', 'Match adverbs for exercise', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'together', 'ด้วยกัน', NULL),
    (activity_id_var, 'slow', 'ช้า', NULL),
    (activity_id_var, 'fast', 'เร็ว', NULL),
    (activity_id_var, 'carefully', 'อย่างระมัดระวัง', NULL),
    (activity_id_var, 'safely', 'อย่างปลอดภัย', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 4, 'Complete the Sentences 1', 'Fill with the correct word', '{"text": "We run ___. He runs ___. She lifts weights ___.", "blanks": [{"id": "blank1", "text": "together", "options": ["together", "fast", "slow", "carefully"], "correctAnswer": "together"}, {"id": "blank2", "text": "fast", "options": ["fast", "slow", "together", "safely"], "correctAnswer": "fast"}, {"id": "blank3", "text": "carefully", "options": ["carefully", "fast", "slow", "safely"], "correctAnswer": "carefully"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 5, 'Complete the Sentences 2', 'Fill with the correct word', '{"text": "He lifts weights ___. We stretch ___.", "blanks": [{"id": "blank1", "text": "safely", "options": ["safely", "carefully", "fast", "slow"], "correctAnswer": "safely"}, {"id": "blank2", "text": "slowly", "options": ["slowly", "safely", "fast", "together"], "correctAnswer": "slowly"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_explanation', 6, 'Adverbs of Manner', 'Describe how you exercise', '{"rules": "Use adverbs to say how actions happen: verb + adverb.\n- We run together.\n- She lifts carefully.\nAdd -ly to many adjectives: slow → slowly; careful → carefully.", "examples": ["We run together every weekend.", "He lifts weights safely.", "She stretches slowly.", "They train fast before work.", "Do you warm up carefully?"]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 7, 'Build Sentences 1', 'Arrange words', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'We run together every weekend', 'We run together every weekend.', '["We", "run", "together", "every", "weekend."]'::jsonb),
    (activity_id_var, 'She stretches slowly', 'She stretches slowly.', '["She", "stretches", "slowly."]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 8, 'Build Sentences 2', 'Arrange words', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'He lifts weights safely', 'He lifts weights safely.', '["He", "lifts", "weights", "safely."]'::jsonb),
    (activity_id_var, 'They train fast before work', 'They train fast before work.', '["They", "train", "fast", "before", "work."]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'speaking_practice', 9, 'Talk About Exercising Together', 'Practice how you exercise with friends', '{"prompts": ["How do you usually exercise?", "Do you exercise slowly or quickly?", "How do you exercise safely?", "How do friends help you exercise better?", "Do you exercise differently with friends?"]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (
      lesson_id,
      activity_type,
      activity_order,
      title,
      description,
      content
    ) VALUES (
      'A2-L69',
      'speaking_improvement',
      10,
      'Speaking Improvement',
      'Read the improved version of your speech',
      '{"type": "speaking_improvement", "similarityThreshold": 70}'::jsonb
    );
END $$;

