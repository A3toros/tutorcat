-- =========================================
-- Pre-fill Database with Sample Lesson Data
-- B1-L39: Tech Problems & Fixes
-- =========================================

DELETE FROM grammar_sentences WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'B1-L39');
DELETE FROM vocabulary_items WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'B1-L39');
DELETE FROM lesson_activities WHERE lesson_id = 'B1-L39';
DELETE FROM lessons WHERE id = 'B1-L39';

INSERT INTO lessons (id, level, lesson_number, topic) VALUES
('B1-L39', 'B1', 39, 'Tech Problems & Fixes')
ON CONFLICT (id) DO UPDATE SET topic = EXCLUDED.topic;

DO $$
DECLARE
    lesson_id_var TEXT := 'B1-L39';
    activity_id_var UUID;
BEGIN
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'warm_up_speaking', 1, 'When Tech Fails', 'Talk about handling tech issues', '{"prompt": "What do you actually do when your tech fails?"}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_intro', 2, 'Tech Fix Words', 'Learn vocabulary about tech problems and fixes', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'log in', 'เข้าสู่ระบบ', NULL),
    (activity_id_var, 'run into', 'ประสบ (ปัญหา)', NULL),
    (activity_id_var, 'deal with', 'จัดการกับ', NULL),
    (activity_id_var, 'back up', 'สำรองข้อมูล', NULL),
    (activity_id_var, 'depend on', 'พึ่งพา', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_matching_drag', 3, 'Match Tech Fix Words', 'Match words with meanings', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'log in', 'เข้าสู่ระบบ', NULL),
    (activity_id_var, 'run into', 'ประสบ (ปัญหา)', NULL),
    (activity_id_var, 'deal with', 'จัดการกับ', NULL),
    (activity_id_var, 'back up', 'สำรองข้อมูล', NULL),
    (activity_id_var, 'depend on', 'พึ่งพา', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 4, 'Complete the Sentences 1', 'Fill with the correct word', '{"text": "I cannot ___ to the system. I often ___ errors. I must ___ this issue.", "blanks": [{"id": "blank1", "text": "log in", "options": ["log in", "run into", "deal with", "depend on"], "correctAnswer": "log in"}, {"id": "blank2", "text": "run into", "options": ["run into", "log in", "deal with", "back up"], "correctAnswer": "run into"}, {"id": "blank3", "text": "deal with", "options": ["deal with", "back up", "depend on", "run into"], "correctAnswer": "deal with"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 5, 'Complete the Sentences 2', 'Fill with the correct word', '{"text": "Always ___ your files. What do you ___ to keep data safe? I ___ cloud storage daily.", "blanks": [{"id": "blank1", "text": "back up", "options": ["back up", "deal with", "run into", "log in"], "correctAnswer": "back up"}, {"id": "blank2", "text": "depend on", "options": ["depend on", "back up", "log in", "run into"], "correctAnswer": "depend on"}, {"id": "blank3", "text": "depend on", "options": ["depend on", "back up", "deal with", "run into"], "correctAnswer": "depend on"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    -- Grammar Explanation: Verb + Preposition (tech context)
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_explanation', 6, 'Verb + Preposition for Tech', 'Use correct verb-preposition pairs for tech actions', '{"rules": "Use fixed pairs: log in to, run into, deal with, back up, depend on. Keep the preposition; do not drop it.\\nUse them with clear objects.", "examples": ["I cannot log in to the system today.", "We often run into network errors.", "They deal with bugs every week.", "She backs up her laptop nightly.", "I depend on cloud storage for work."]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 7, 'Build Sentences 1', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'I cannot log in to the system today', 'I cannot log in to the system today', '["I", "cannot", "log", "in", "to", "the", "system", "today"]'::jsonb),
    (activity_id_var, 'We often run into network errors', 'We often run into network errors', '["We", "often", "run", "into", "network", "errors"]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 8, 'Build Sentences 2', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'She backs up her laptop nightly', 'She backs up her laptop nightly', '["She", "backs", "up", "her", "laptop", "nightly"]'::jsonb),
    (activity_id_var, 'I depend on cloud storage for work', 'I depend on cloud storage for work', '["I", "depend", "on", "cloud", "storage", "for", "work"]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'speaking_practice', 9, 'Talk About Tech Fixes', 'Practice talking about tech problems and backups', '{"prompts": ["What do you actually do when your tech fails?", "How do you back up your stuff?", "When do you finally ask someone for help?"]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (
      lesson_id,
      activity_type,
      activity_order,
      title,
      description,
      content
    ) VALUES (
      'B1-L39',
      'speaking_improvement',
      10,
      'Speaking Improvement',
      'Read the improved version of your speech',
      '{"type": "speaking_improvement", "similarityThreshold": 70}'::jsonb
    );
END $$;

