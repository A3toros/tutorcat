# C1 Additional Lessons Plan (L1–L100) — Student-Focused (new topics)

## Requirements & Guidelines (same core as A2)
- **No ambiguity:** One clear fill-blank answer (lesson vocab only); 3 unrelated distractors.
- **Grammar sentences:** Natural, concise; no swap-ambiguous pairs; questions end with “?”; commas placed correctly; contractions OK when natural.
- **Speaking:** Student-friendly, personal, concrete but intellectually rich; avoid workplace-only/adult-only contexts; keep academic/student lens.
- **Speaking improvement:** Include `speaking_improvement` with `similarityThreshold: 70`.
- **Topics spread:** Use the provided 100 topics in order; avoid clustering similar sub-themes in adjacent lessons.
- **Grammar spread:** Cycle C1 grammar points with spaced reviews.

## CEFR C1 Grammar Coverage (from `cefr-grammar-requirements.md`)
- Narrative tenses; time-shifting & emphasis; advanced perfect forms
- Advanced mixed/implied conditionals
- Modals: speculation/criticism in past; degrees of certainty
- Participle clauses; nominal clauses; embedded questions
- Advanced passive forms; cleft sentences; emphatic/fronting/postposing
- Full inversion patterns
- Articles: abstract & generic reference; stylistic use
- Cohesion/transformations; register-aware choices

### Planned Review Counts (approx.)
- Narrative/time-shift: 8
- Advanced perfect: 8
- Mixed/implied conditionals: 8
- Modals (speculation/criticism): 8
- Participle clauses: 7
- Nominal/embedded clauses: 7
- Advanced passives/transformations: 8
- Cleft/fronting/emphasis: 7
- Inversion (negative/rarely/hardly): 7
- Articles (abstract/stylistic): 6
- Cohesion/ellipsis/substitution: 6
- Contrast/result discourse (C1 nuance): 6

## Lesson Map (topics in order; grammar spaced)
Format per lesson:
- Topic — Grammar focus (+review #); two personal/reflective prompts

1. Work–life balance — Cleft/emphatic #1; prompts: What is it that tips your balance? When do you reclaim time?
2. Learning new skills — Participle clauses #1; prompts: How are you learning now? What keeps you practicing?
3. Impact of technology on daily life — Modals (speculation) #1; prompts: How might tech be shaping your habits? What could you change?
4. Making important life decisions — Mixed conditionals #1; prompts: If you’d chosen differently, how would life look now?
5. Social media habits — Inversion (seldom/rarely) #1; prompts: How rarely do you disconnect? What makes you scroll?
6. Travel experiences — Narrative tenses #1; prompts: Tell a trip that changed you. What moment shifted things?
7. Environmental protection — Advanced passives #1; prompts: What should be enforced? Who should be held?
8. Healthy lifestyles — Articles (abstract/stylistic) #1; prompts: What counts as “healthy” for you? How do you define enough?
9. Stress and time management — Cohesion/ellipsis #1; prompts: How do you cut noise in your day? What do you drop first?
10. Role of education — Nominal clauses #1; prompts: What do you think education should deliver? Who decides?
11. Cultural differences — Contrast discourse #1; prompts: Where have you felt a clash? What bridged it?
12. Choosing a career path — Advanced perfect #1; prompts: How has your idea of career evolved? What shifted it?
13. Online communication — Inversion (hardly/scarcely) #2; prompts: When do messages miss meaning? How do you fix it?
14. Public vs private transport — Mixed conditionals #2; prompts: If you had better transit, how would your week change?
15. Entertainment preferences — Cleft/fronting #2; prompts: What is it that makes content “good” for you?
16. News consumption — Modals (certainty/stance) #2; prompts: How sure are you of a source? What proof do you need?
17. Friendship in adulthood — Participle clauses #2; prompts: How are you maintaining close ties now? What shifted from school?
18. Living in cities vs countryside — Contrast discourse #2; prompts: Where do you focus best? What do you miss?
19. Shopping habits — Articles (generic) #2; prompts: What drives your buying choices? How do you define “need”?
20. Advertising influence — Advanced passives #2; prompts: How should ads be checked? Who protects students?
21. Personal goals — Nominal clauses #2; prompts: What do you call a goal worth keeping? How do you test it?
22. Modern family life — Inversion (never/rarely) #3; prompts: When do family norms surprise you? How do you adapt?
23. Free time activities — Cleft/emphatic #3; prompts: What is it that relaxes you fastest? What do you skip?
24. Importance of hobbies — Modals (speculation past) #3; prompts: How might hobbies have saved your stress before?
25. Technology in education — Advanced perfect #2; prompts: How has ed tech changed your learning over years?
26. Climate change awareness — Cohesion/ellipsis #2; prompts: How do you talk about climate daily? What shorthand do you use?
27. Consumer choices — Mixed conditionals #3; prompts: If you had bought differently, what now?
28. Teamwork and cooperation — Advanced passives #3; prompts: How should roles be assigned? Who ensures fairness?
29. Work satisfaction — Articles (abstract) #3; prompts: What is “satisfying” work for you? How do you know?
30. Learning from mistakes — Inversion (little/rarely) #4; prompts: How rarely do you repeat errors? What made that stick?
31. Food culture — Participle clauses #3; prompts: How do you keep food traditions? What have you adopted?
32. Digital privacy — Modals (critique/obligation) #4; prompts: What must platforms do? What will you refuse?
33. Balancing work and study — Cleft/fronting #4; prompts: What is it that keeps both afloat? What breaks first?
34. Health and exercise routines — Advanced perfect #3; prompts: How long have you kept a routine? What changed it?
35. Cultural traditions — Articles (stylistic) #4; prompts: Which traditions feel non-negotiable? Which flex?
36. Social responsibility — Advanced passives #4; prompts: How should responsibility be shared? Who enforces?
37. Influence of celebrities — Modals (speculation) #5; prompts: How might celebrity views shape you? What do you filter?
38. Motivation and ambition — Mixed conditionals #4; prompts: If ambition had faded earlier, where would you be?
39. Public services — Contrast discourse #3; prompts: Which services matter most to you? Why?
40. Lifelong learning — Advanced perfect #4; prompts: How have you kept learning after school? What’s next?
41. Volunteering — Participle clauses #4; prompts: How are you giving time now? What drew you in?
42. Modern communication problems — Inversion (hardly/scarcely) #5; prompts: When do messages derail? How do you repair?
43. Travel planning — Cohesion/ellipsis #3; prompts: How do you compress plans when short on time?
44. Education and job opportunities — Articles (generic) #5; prompts: How does education open doors for you? Where doesn’t it?
45. Managing money — Advanced passives #5; prompts: How should budgets be audited? Who decides?
46. Culture’s influence on behaviour — Nominal clauses #3; prompts: What beliefs shape your actions? Who taught them?
47. Technology and relationships — Modals (certainty/stance) #5; prompts: How sure are you tech helps closeness? When does it hurt?
48. Personal achievements — Cleft/emphatic #5; prompts: What achievement changed you most? Why?
49. Environmental responsibility — Mixed conditionals #5; prompts: If you had started greener habits earlier, how now?
50. Changing lifestyles — Contrast discourse #4; prompts: Which change was hardest? Which easiest?
51. Workplace relationships — Participle clauses #5; prompts: How are you building trust at work/school? What frays it?
52. Leisure and relaxation — Inversion (seldom/rarely) #6; prompts: How rarely do you fully switch off? What lets you?
53. Media and opinions — Modals (speculation past) #6; prompts: How might media have nudged your view? When?
54. Problem-solving in daily life — Advanced perfect #5; prompts: How have your solving habits evolved?
55. Social expectations — Articles (abstract) #6; prompts: What “expectations” press on you? How do you respond?
56. Personal strengths and weaknesses — Cleft/fronting #6; prompts: What is it that you count as your edge? What holds you back?
57. Urban life challenges — Advanced passives #6; prompts: How should cities be improved? Who’s responsible?
58. Importance of tradition — Inversion (never/little) #6; prompts: When has tradition surprised you? How?
59. Learning languages — Nominal clauses #4; prompts: What do you seek in a new language? How do you stick with it?
60. Role of the internet — Mixed conditionals #6; prompts: If internet vanished, what would you do now?
61. Health awareness — Participle clauses #6; prompts: How are you monitoring health? What triggers action?
62. Choosing where to live — Modals (certainty/stance) #6; prompts: How sure are you about your chosen place? What would move you?
63. Work experience — Narrative tenses #2; prompts: Tell a work story that shaped you. What changed?
64. Education systems — Contrast discourse #5; prompts: What works where you are? What fails?
65. Cultural exchange — Advanced perfect #6; prompts: How has exchange changed you over time?
66. Managing stress — Cohesion/ellipsis #4; prompts: How do you trim stress fast? What stays?
67. Career development — Advanced passives #7; prompts: How should mentorship be structured? Who benefits?
68. Impact of advertising — Modals (critique) #7; prompts: What should ads never do? Where’s the line?
69. Technology dependence — Inversion (hardly/scarcely) #7; prompts: How hard is it to unplug? What happens when you do?
70. Personal values — Cleft/emphatic #7; prompts: What is it that you won’t trade? Why?
71. Environmental habits — Mixed conditionals #7; prompts: If habits shifted earlier, how would things look?
72. Planning for the future — Advanced perfect #7; prompts: How will today’s choices have aged in 10 years?
73. Social interactions — Articles (stylistic) #6; prompts: What “rules” do you follow socially? Which do you ignore?
74. Influence of education on society — Nominal clauses #5; prompts: What do you think education builds in society? Evidence?
75. Entertainment and relaxation — Contrast discourse #6; prompts: When do you pick calm vs thrill? Why?
76. Handling change — Participle clauses #7; prompts: How are you managing change now? What anchors you?
77. Cultural identity — Advanced passives #8; prompts: How is identity framed by others? Who resists?
78. Balancing personal and professional life — Inversion (little/rarely) #7; prompts: How rarely do you feel balance? What helps?
79. Travel and cultural understanding — Modals (speculation) #7; prompts: How might travel change your views next?
80. Social media influence — Cleft/fronting #7; prompts: What is it that makes a post persuasive to you?
81. Workplace expectations — Advanced passives #9; prompts: How should expectations be set? Who enforces?
82. Learning independently — Mixed conditionals #8; prompts: If you had relied less on classes, how now?
83. Public opinion — Cohesion/ellipsis #5; prompts: How do you summarize opinion without generalizing too much?
84. Lifestyle choices — Articles (abstract) #7; prompts: What is a “good life” to you? How do you defend it?
85. Importance of communication — Modals (certainty) #7; prompts: How sure are you that your message lands? Why?
86. Social trends — Advanced perfect #8; prompts: How have trends shifted around you? What did you adopt?
87. Education and personal growth — Participle/nominal #7; prompts: How is education shaping you now? What gaps remain?
88. Dealing with challenges — Inversion (hardly/scarcely) #8; prompts: When did you barely push through? Why persist?
89. Technology at work — Advanced passives #10; prompts: How should tools be rolled out? Who trains?
90. Health and well-being — Modals (critique/stance) #8; prompts: What should you have done sooner? What will you change?
91. Cultural awareness — Contrast discourse #7; prompts: Where do you adjust first in new cultures? Why?
92. Time pressure — Cohesion/ellipsis #6; prompts: How do you compress tasks under pressure? What falls away?
93. Making compromises — Mixed conditionals #9; prompts: If you hadn’t compromised earlier, where now?
94. Environmental challenges — Advanced perfect #9; prompts: How have local issues evolved? What remains?
95. Career ambitions — Cleft/emphatic #8; prompts: What is it that you’re aiming for now? Why this?
96. Media influence — Articles (abstract) #8; prompts: How does “media” shape you? What do you resist?
97. Personal responsibility — Inversion (never/little) #8; prompts: When have you ducked responsibility? Why?
98. Social behaviour — Advanced passives #11; prompts: How should norms be guided? Who sets them?
99. Future plans — Nominal clauses #6; prompts: What do you plan for the next five years? How firm is it?
100. Personal development — Advanced perfect #10; prompts: How has your growth arc shifted? What’s next?

## Coverage Checkpoint (indicative)
- Narrative / time shift: L6,63
- Advanced perfect: L12,25,34,40,55,65,72,86,94,100
- Mixed/implied conditionals: L4,14,27,38,50,60,71,82,93
- Modals (speculation/critique/stance): L3,16,24,37,47,53,62,68,79,85,90
- Participle/nominal/embedded: L2,17,31,41,59,76,87
- Advanced passives/transformations: L7,20,28,36,45,57,67,81,89,98
- Cleft/fronting/emphasis: L1,15,23,33,48,56,70,80,95
- Inversion (rarely/hardly/never): L5,13,22,30,42,52,69,78,88,97
- Articles (abstract/stylistic): L8,19,29,35,44,55,73,84,96
- Contrast/result discourse: L11,18,39,50,64,75,91
- Cohesion/ellipsis/substitution: L9,26,43,66,83,92
# C1 Additional Lessons Plan (100 lessons) — Student-Focused

## Requirements & Guidelines (adapted from A2 plan)
- **No ambiguity:** One clear fill-blank answer (lesson vocab only); 3 unrelated distractors.
- **Grammar sentences:** Natural, concise; no ambiguous word swaps; questions carry “?”; commas placed correctly; contractions allowed when natural at C1.
- **Speaking:** Student-friendly, personal, concrete but intellectually engaging; avoid workplace-only or adult-only contexts; keep academic/student lens.
- **Speaking improvement:** Include `speaking_improvement` with `similarityThreshold: 70`.
- **Topics spread:** Use the provided 100 topics in order; avoid clustering similar sub-themes in adjacent lessons.
- **Grammar spread:** Cycle C1 grammar points with spaced reviews for retention.

## CEFR C1 Grammar Coverage (from `cefr-grammar-requirements.md`)
- Narrative tenses; time-shifting & emphasis; advanced perfect forms
- Advanced mixed/implied conditionals
- Modals: speculation/criticism in past; degrees of certainty
- Participle clauses; nominal clauses; embedded questions
- Advanced passive forms; cleft sentences; emphatic structures
- Full inversion patterns
- Articles: abstract & generic reference; stylistic use
- Cohesion/transformations; register-aware choices

### Planned Review Counts (approx.)
- Narrative tenses / time shift: 8
- Advanced perfect forms: 8
- Advanced mixed/implied conditionals: 8
- Modals (speculation/criticism past): 7
- Degrees of certainty (present/past): 7
- Participle clauses: 7
- Nominal clauses / embedded questions: 7
- Advanced passives (incl. reporting): 7
- Cleft / emphatic structures: 6
- Full inversion (negative, only when, little, hardly): 6
- Articles (abstract/generic/stylistic): 6
- Cohesive transformations / substitution / ellipsis: 6
- Discourse linking (concession/contrast/result) at C1 nuance: 6

## Lesson Map (topics in given order; grammar spaced)
Format per lesson:
- Topic
- Grammar focus (+review #)
- Speaking prompts (student-relevant, personal/reflective)

1. Defining success in modern society — Cleft/emphatic #1; prompts: What does success mean for you now? When do you reframe success?
2. Role of education in shaping identity — Nominal clauses #1; prompts: How has education defined who you are? What would change without it?
3. Critical thinking in academic life — Inversion (seldom/rarely) #1; prompts: When do you question assumptions? What triggers doubt?
4. Academic freedom and its limits — Modals (degrees of certainty) #1; prompts: How sure are you that limits help? When might limits harm?
5. Purpose of higher education — Cleft/it-clefts #2; prompts: What is it that you seek from higher ed? What would make it meaningful?
6. Knowledge vs skills in the 21st century — Contrast linking (C1 nuance) #1; prompts: Where do you place value: knowledge or skills? Why?
7. Lifelong learning — Participle clauses #1; prompts: How do you keep learning outside class? What habits keep you growing?
8. Intellectual curiosity — Advanced perfect aspect #1; prompts: What have you pursued purely for curiosity? How has it shaped you?
9. Academic pressure & achievement culture — Narrative tenses #1; prompts: Describe a time pressure peaked. How did it unfold?
10. Value of failure in learning — Mixed conditionals #1; prompts: If you hadn’t failed there, what would you have missed now?
11. Ethics in education — Articles (abstract/stylistic) #1; prompts: Is “ethics” a fixed idea for you? When do you bend rules?
12. Plagiarism & academic integrity — Advanced passives (reporting) #1; prompts: How should integrity be enforced? When is punishment fair?
13. AI use in academic work — Modals (speculation/criticism past) #1; prompts: How might AI have helped or harmed your work?
14. Future of assessment — Nominal clauses #2; prompts: What do you think assessment should prove? Who decides?
15. Fairness in grading systems — Cleft/emphatic #3; prompts: What is it that makes grading fair to you? When do you contest a grade?
16. Standardized testing: benefits/drawbacks — Contrast linking #2; prompts: How have tests helped you? Where have they failed you?
17. Digital surveillance in education — Advanced passives #2; prompts: How should data be handled? What should not be tracked?
18. Access to education worldwide — Inversion (little/rarely) #2; prompts: How rarely do you think about access? What would broaden it?
19. Educational inequality — Articles (generic) #2; prompts: What drives “inequality” where you live? How do you see privilege?
20. Meritocracy in education — Mixed/implied conditionals #2; prompts: If meritocracy truly worked, how would campuses look now?
21. Media literacy & misinformation — Participle clauses #2; prompts: How do you filter news? What signals bias for you?
22. Critical evaluation of sources — Nominal clauses #3; prompts: What do you consider evidence? Who shapes your trust?
23. Bias in news reporting — Modals (degrees of certainty) #2; prompts: How sure are you about media bias? What proof do you need?
24. Impact of algorithms on information — Advanced perfect aspect #2; prompts: How have feeds shaped your views over time?
25. Freedom of speech on campuses — Inversion (hardly/scarcely) #3; prompts: When is speech limited? Have you seen tensions rise?
26. Cancel culture and debate — Contrast linking #3; prompts: When does accountability turn to silencing? How do you respond?
27. Social media and public opinion — Cohesive transformations #1; prompts: How do you shift tone across audiences? What posts backfired?
28. Responsibility of content creators — Advanced passives #3; prompts: What should be held accountable? How should harm be repaired?
29. Emotional manipulation in media — Modals (speculation past) #3; prompts: How might media have shaped an emotion you felt?
30. Media ethics — Articles (abstract) #3; prompts: What is “ethics” in media to you? Where is the line?
31. Cultural identity in a globalized world — Participle clauses #3; prompts: How do you keep your identity while adapting?
32. Preserving traditions in modern societies — Advanced perfect #3; prompts: What have you kept from home? What has changed?
33. Cultural appropriation vs appreciation — Cleft/emphatic #4; prompts: What is it that divides respect from misuse?
34. Language and cultural power — Nominal clauses #4; prompts: How does language set status? What does dominance cost?
35. Multicultural education — Cohesion/ellipsis #2; prompts: How do you navigate mixed classrooms? What helps inclusion?
36. Global citizenship — Inversion (never/rarely) #4; prompts: When have you acted as a “global citizen”? How do you define it?
37. Cross-cultural misunderstandings — Mixed conditionals #3; prompts: If you had known the norm, what would differ now?
38. National identity among youth — Articles (generic) #4; prompts: What does national identity mean to you? How is it shifting?
39. Cultural stereotypes — Modals (certainty) #4; prompts: How sure are you a stereotype is wrong? When did you revise one?
40. Language as a social divider — Advanced passives #4; prompts: How can language gatekeep? Who should adapt?
41. Technology shaping human behavior — Advanced perfect #4; prompts: How has tech altered your habits over years?
42. Ethical limits of artificial intelligence — Modals (criticism past) #4; prompts: How should AI have been limited? Where was harm done?
43. Data privacy and consent — Nominal clauses #5; prompts: What does “consent” mean online? Who owns your data?
44. Digital dependency — Inversion (hardly/rarely) #5; prompts: How rarely are you offline? What happens when you are?
45. Technology and attention span — Articles (abstract) #5; prompts: How do you protect “attention”? What steals it most?
46. Human connection in a digital age — Participle clauses #4; prompts: How do you keep depth online? When does it fail?
47. Virtual communities — Cohesion/substitution #3; prompts: How do you belong in virtual groups? What norms form?
48. Future of human communication — Advanced perfect #5; prompts: How will your communication have changed in 10 years?
49. Automation and society — Advanced passives #5; prompts: What should be automated? What must stay human?
50. Ethical responsibility of tech companies — Modals (degrees past) #5; prompts: How might firms have acted differently? Who pays?
51. Climate responsibility of individuals — Cleft/emphatic #5; prompts: What is it that you can change first?
52. Environmental activism among youth — Inversion (seldom/rarely) #6; prompts: When have you acted? What stopped you?
53. Sustainable lifestyles — Participle clauses #5; prompts: How are you sustaining habits? What has stuck?
54. Climate anxiety — Nominal clauses #6; prompts: What do you tell yourself about the future? What calms you?
55. Science communication & public trust — Advanced passives #6; prompts: How should science be communicated? Who should lead?
56. Environmental education — Articles (generic) #6; prompts: What makes “education” effective here? How to measure?
57. Green technology promises & limits — Contrast linking #4; prompts: What hopes do you have? Where do you see hype?
58. Consumer responsibility — Modals (speculation past) #6; prompts: How could you have bought differently?
59. Ethics of environmental protest — Mixed conditionals #4; prompts: If protests were banned, what would you do now?
60. Long-term thinking in climate policy — Advanced perfect #6; prompts: How will today’s choices have shaped 2040?
61. Moral decision-making in daily life — Articles (abstract) #7; prompts: What is “moral” in small choices? How do you decide?
62. Personal values vs social norms — Cleft/emphatic #6; prompts: What is it that you refuse to change? Why?
63. Ethical dilemmas without clear answers — Mixed/implied conditionals #5; prompts: If no rule fit, how would you choose?
64. Responsibility and privilege — Modals (certainty degrees) #6; prompts: How sure are you of your privilege? How do you act?
65. Freedom and accountability — Contrast linking #5; prompts: Where do you draw the line between them?
66. Justice and fairness — Advanced passives #7; prompts: How should justice be delivered? What must be repaired?
67. Moral courage — Inversion (little/rarely) #6; prompts: When did you show courage? What held you back?
68. Individual impact on society — Participle clauses #6; prompts: How are you contributing now? What accumulates over time?
69. Altruism vs self-interest — Nominal clauses #7; prompts: What do you believe about motives? When do you act selflessly?
70. Defining ethical behavior — Modals (criticism past) #7; prompts: How could you have acted better in a past moment?
71. Psychological well-being of students — Advanced perfect #7; prompts: How has your well-being changed across semesters?
72. Burnout culture in education — Articles (abstract) #8; prompts: What fuels “burnout”? How do you name it?
73. Emotional intelligence — Cleft/emphatic #7; prompts: What is it that you notice first in others? How do you respond?
74. Identity formation in young adulthood — Advanced passives #8; prompts: How is identity shaped by others’ views?
75. Coping with uncertainty — Modals (degrees of certainty) #7; prompts: How do you judge if a risk is worth it?
76. Perfectionism and mental health — Mixed conditionals #6; prompts: If you let go earlier, how would you feel now?
77. Motivation vs discipline — Inversion (hardly/scarcely) #7; prompts: When does motivation vanish? What keeps you moving?
78. Meaning and purpose — Nominal clauses #8; prompts: What do you call “purpose” for yourself? How has it shifted?
79. Resilience in challenging environments — Participle clauses #7; prompts: How have you kept going? What habits anchor you?
80. Self-reflection as a skill — Advanced perfect #8; prompts: How long have you reflected deliberately? What changed?
81. Global mobility of students — Advanced passives #9; prompts: How are students selected/moved? Who benefits?
82. Brain drain and brain circulation — Contrast linking #6; prompts: What do you lose/ gain when people leave?
83. Studying abroad and identity change — Mixed conditionals #7; prompts: If you hadn’t left, who would you be now?
84. Language dominance in academia — Articles (stylistic) #9; prompts: How does one language dominate? What shifts balance?
85. Inequality in global education systems — Inversion (rarely/seldom) #7; prompts: How rarely do you see equality? What would fix it?
86. International cooperation in education — Cohesion/ellipsis #4; prompts: How do partnerships work? What makes them fail?
87. Cultural shock and adaptation — Narrative tenses #2; prompts: Tell the story of your biggest shock. How did it resolve?
88. Education as soft power — Modals (speculation) #8; prompts: How might education influence other nations?
89. Ethical study abroad practices — Advanced passives #10; prompts: What must programs ensure? What should students avoid?
90. Global academic competition — Advanced perfect #9; prompts: How has competition shaped your choices?
91. Influence of philosophy on modern thinking — Nominal clauses #9; prompts: Which ideas frame your worldview? Why?
92. Literature as social commentary — Articles (abstract) #10; prompts: What is “literature” for you? How does it speak socially?
93. Art as political expression — Cleft/emphatic #8; prompts: What is it that art can say better than speech?
94. Role of creativity in learning — Participle clauses #8; prompts: How do you weave creativity into study?
95. Interdisciplinary thinking — Contrast linking #7; prompts: When do fields clash? When do they blend best?
96. Science vs belief systems — Inversion (never/little) #8; prompts: When have beliefs overruled evidence? How did you react?
97. Limits of objectivity — Advanced passives #11; prompts: How objective can research be? Who checks it?
98. Truth in the post-truth era — Modals (degrees of certainty) #8; prompts: How do you decide what is true now?
99. Intellectual responsibility — Mixed conditionals #8; prompts: If you had ignored facts before, where would you be now?
100. Shaping the future through ideas — Future-facing perfect/mixed #10; prompts: How will your ideas have influenced others by 2035?

## Coverage Checkpoint (indicative)
- Narrative tenses / time shift: L9,87
- Advanced perfect forms: L8,24,32,41,48,60,71,80,90
- Mixed/implied conditionals: L10,20,37,59,63,76,83,99
- Modals (speculation/criticism/degree): L13,23,29,42,50,58,64,70,75,88,94,98
- Participle clauses: L7,21,31,46,53,68,79,94
- Nominal clauses / embedded Qs: L2,14,22,34,43,54,69,78,91
- Advanced passives: L12,17,28,40,49,55,66,74,81,89,97
- Cleft/emphatic: L1,5,15,33,51,62,73,93
- Inversion (hardly/rarely/never): L3,18,25,36,44,52,67,77,85,96,100
- Articles (abstract/generic/stylistic): L11,19,30,38,45,56,72,84,92
- Contrast/linking at C1 nuance: L6,16,26,57,65,82,95
- Cohesion/ellipsis/substitution: L27,35,47,86
- Future perfect / forward-looking: L48,60,99


