-- =========================================
-- Pre-fill Database with Sample Lesson Data
-- C1-L29: Emotional Manipulation in Media
-- =========================================
DELETE FROM lesson_activity_results WHERE lesson_id = 'C1-L29';
DELETE FROM user_progress WHERE lesson_id = 'C1-L29';
DELETE FROM lesson_history WHERE lesson_id = 'C1-L29';
DELETE FROM grammar_sentences WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'C1-L29');
DELETE FROM vocabulary_items WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'C1-L29');
DELETE FROM lesson_activities WHERE lesson_id = 'C1-L29';
DELETE FROM lessons WHERE id = 'C1-L29';

INSERT INTO lessons (id, level, lesson_number, topic) VALUES
('C1-L29', 'C1', 29, 'Emotional Manipulation in Media')
ON CONFLICT (id) DO UPDATE SET topic = EXCLUDED.topic;

DO $$
DECLARE
    lesson_id_var TEXT := 'C1-L29';
    activity_id_var UUID;
BEGIN
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'warm_up_speaking', 1, 'Emotional Manipulation', 'Discuss emotional manipulation in media', '{"prompt": "How has media influenced your emotions?"}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_intro', 2, 'Emotional Manipulation Vocabulary', 'Learn vocabulary about emotional manipulation', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'manipulation', 'การบงการ', NULL),
    (activity_id_var, 'appeal', 'การดึงดูด', NULL),
    (activity_id_var, 'technique', 'เทคนิค', NULL),
    (activity_id_var, 'resistance', 'การต่อต้าน', NULL),
    (activity_id_var, 'effectiveness', 'ประสิทธิภาพ', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_matching_drag', 3, 'Match Manipulation Words', 'Match English words with Thai meanings', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'manipulation', 'การบงการ', NULL),
    (activity_id_var, 'appeal', 'การดึงดูด', NULL),
    (activity_id_var, 'technique', 'เทคนิค', NULL),
    (activity_id_var, 'resistance', 'การต่อต้าน', NULL),
    (activity_id_var, 'effectiveness', 'ประสิทธิภาพ', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 4, 'Complete the Sentences 1', 'Fill with the correct word', '{"text": "Emotional ___ uses persuasive ___. Audiences develop ___.", "blanks": [{"id": "blank1", "text": "manipulation", "options": ["manipulation", "appeal", "technique", "resistance"], "correctAnswer": "manipulation"}, {"id": "blank2", "text": "techniques", "options": ["techniques", "manipulation", "appeal", "effectiveness"], "correctAnswer": "techniques"}, {"id": "blank3", "text": "resistance", "options": ["resistance", "manipulation", "appeal", "effectiveness"], "correctAnswer": "resistance"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 5, 'Complete the Sentences 2', 'Fill with the correct word', '{"text": "Emotional ___ targets feelings. The ___ of manipulation concerns viewers.", "blanks": [{"id": "blank1", "text": "appeal", "options": ["appeal", "manipulation", "technique", "resistance"], "correctAnswer": "appeal"}, {"id": "blank2", "text": "effectiveness", "options": ["effectiveness", "manipulation", "appeal", "resistance"], "correctAnswer": "effectiveness"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_explanation', 6, 'Modals: Speculation in the Past', 'Learn modals for past speculation', '{"rules": "Past speculation with modals:\n- \"might/could have + past participle\" (possibility in past): \"Media might have influenced your emotions.\"\n- \"must have + past participle\" (strong probability): \"Media must have shaped your feelings.\"\n- \"may have + past participle\" (uncertainty): \"Media may have affected your mood.\"\n\nUse for:\n- Speculating about past influence: \"Media might have shaped how you felt.\"\n- Expressing probability: \"Media must have influenced your emotions.\"\n- Showing uncertainty: \"Media may have affected your feelings.\"", "examples": ["Media might have shaped how you felt about the issue.", "Media must have influenced your emotional response.", "Media may have affected your mood without you realizing.", "Media could have manipulated your emotions subtly.", "Media might have triggered an emotional reaction."]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 7, 'Build Sentences 1', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'Media might have shaped how you felt about the issue.', 'Media might have shaped how you felt about the issue.', '["Media", "might", "have", "shaped", "how", "you", "felt", "about", "the", "issue."]'::jsonb),
    (activity_id_var, 'Media must have influenced your emotional response.', 'Media must have influenced your emotional response.', '["Media", "must", "have", "influenced", "your", "emotional", "response."]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 8, 'Build Sentences 2', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'Media may have affected your mood without you realizing.', 'Media may have affected your mood without you realizing.', '["Media", "may", "have", "affected", "your", "mood", "without", "you", "realizing."]'::jsonb),
    (activity_id_var, 'Media could have manipulated your emotions subtly.', 'Media could have manipulated your emotions subtly.', '["Media", "could", "have", "manipulated", "your", "emotions", "subtly."]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'speaking_practice', 9, 'Discuss Emotional Manipulation', 'Practice speaking about emotional manipulation', '{"prompts": ["How might media have shaped how you felt?", "What emotional techniques are commonly used?", "When is emotional appeal acceptable?", "How can audiences resist manipulation?", "Why is emotional content effective?"]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (
      lesson_id,
      activity_type,
      activity_order,
      title,
      description,
      content
    ) VALUES (
      'C1-L29',
      'speaking_improvement',
      10,
      'Speaking Improvement',
      'Read the improved version of your speech',
      '{"type": "speaking_improvement", "similarityThreshold": 70}'::jsonb
    );
END $$;
