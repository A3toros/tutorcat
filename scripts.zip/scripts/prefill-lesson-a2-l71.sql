-- =========================================
-- Pre-fill Database with Sample Lesson Data
-- A2-L71: Travel Delays
-- =========================================

DELETE FROM grammar_sentences WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'A2-L71');
DELETE FROM vocabulary_items WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'A2-L71');
DELETE FROM lesson_activities WHERE lesson_id = 'A2-L71';
DELETE FROM lessons WHERE id = 'A2-L71';

INSERT INTO lessons (id, level, lesson_number, topic) VALUES
('A2-L71', 'A2', 71, 'Travel Delays')
ON CONFLICT (id) DO UPDATE SET topic = EXCLUDED.topic;

DO $$
DECLARE
    lesson_id_var TEXT := 'A2-L71';
    activity_id_var UUID;
BEGIN
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'warm_up_speaking', 1, 'Delay Stories', 'Talk about delays', '{"prompt": "Why were you late last time?"}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_intro', 2, 'Delay Words', 'Learn words about delays', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'delay', 'ความล่าช้า', NULL),
    (activity_id_var, 'traffic', 'การจราจร', NULL),
    (activity_id_var, 'weather', 'สภาพอากาศ', NULL),
    (activity_id_var, 'late', 'สาย', NULL),
    (activity_id_var, 'plan', 'แผน', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_matching_drag', 3, 'Match Delay Words', 'Match delay words', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'delay', 'ความล่าช้า', NULL),
    (activity_id_var, 'traffic', 'การจราจร', NULL),
    (activity_id_var, 'weather', 'สภาพอากาศ', NULL),
    (activity_id_var, 'late', 'สาย', NULL),
    (activity_id_var, 'plan', 'แผน', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 4, 'Complete the Sentences 1', 'Fill with the correct word', '{"text": "There was a ___. The ___ was bad. I arrived ___.", "blanks": [{"id": "blank1", "text": "delay", "options": ["delay", "traffic", "late", "plan"], "correctAnswer": "delay"}, {"id": "blank2", "text": "weather", "options": ["weather", "traffic", "delay", "plan"], "correctAnswer": "weather"}, {"id": "blank3", "text": "late", "options": ["late", "plan", "delay", "traffic"], "correctAnswer": "late"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 5, 'Complete the Sentences 2', 'Fill with the correct word', '{"text": "The ___ was blocked. I changed my ___.", "blanks": [{"id": "blank1", "text": "traffic", "options": ["traffic", "delay", "late", "weather"], "correctAnswer": "traffic"}, {"id": "blank2", "text": "plan", "options": ["plan", "traffic", "delay", "late"], "correctAnswer": "plan"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_explanation', 6, 'Linkers: and/but/because/so', 'Explain reasons for delays', '{"rules": "Use because for reasons; so for results; and to add; but for contrast.\n- I was late because of traffic.\n- The bus was full, so I waited.\n- It rained, but I still went.", "examples": ["I was late because of traffic.", "The train was delayed, so I called my friend.", "It was raining, but we waited.", "The bus was full and noisy.", "I changed my plan because the weather was bad."]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 7, 'Build Sentences 1', 'Arrange words', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'I was late because of traffic', 'I was late because of traffic.', '["I", "was", "late", "because", "of", "traffic."]'::jsonb),
    (activity_id_var, 'The train was delayed so I waited', 'The train was delayed, so I waited.', '["The", "train", "was", "delayed,", "so", "I", "waited."]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 8, 'Build Sentences 2', 'Arrange words', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'It was raining but we waited', 'It was raining, but we waited.', '["It", "was", "raining,", "but", "we", "waited."]'::jsonb),
    (activity_id_var, 'The bus was full and noisy', 'The bus was full and noisy.', '["The", "bus", "was", "full", "and", "noisy."]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'speaking_practice', 9, 'Talk About Delays', 'Practice delay stories', '{"prompts": ["I was late because…", "I felt stressed, but I stayed calm.", "There was a delay, so I waited.", "What happened, and how did you react?", "What causes delays, and how do they affect plans?"]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (
      lesson_id,
      activity_type,
      activity_order,
      title,
      description,
      content
    ) VALUES (
      'A2-L71',
      'speaking_improvement',
      10,
      'Speaking Improvement',
      'Read the improved version of your speech',
      '{"type": "speaking_improvement", "similarityThreshold": 70}'::jsonb
    );
END $$;

