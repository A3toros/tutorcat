-- =========================================
-- Pre-fill Database with Sample Lesson Data
-- A1-L34: Shoes and Accessories
-- =========================================

DELETE FROM grammar_sentences WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'A1-L34');
DELETE FROM vocabulary_items WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'A1-L34');
DELETE FROM lesson_activities WHERE lesson_id = 'A1-L34';
DELETE FROM lessons WHERE id = 'A1-L34';

INSERT INTO lessons (id, level, lesson_number, topic) VALUES
('A1-L34', 'A1', 34, 'Shoes and Accessories')
ON CONFLICT (id) DO UPDATE SET topic = EXCLUDED.topic;

DO $$
DECLARE
    lesson_id_var TEXT := 'A1-L34';
    activity_id_var UUID;
BEGIN
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'warm_up_speaking', 1, 'Shoes and Bags', 'Talk about shoes and accessories', '{"prompt": "Are your shoes black?"}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_intro', 2, 'Accessory Words', 'Learn shoes and accessories', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'shoes', 'รองเท้า', NULL),
    (activity_id_var, 'socks', 'ถุงเท้า', NULL),
    (activity_id_var, 'bag', 'กระเป๋า', NULL),
    (activity_id_var, 'belt', 'เข็มขัด', NULL),
    (activity_id_var, 'hat', 'หมวก', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_matching_drag', 3, 'Match Accessory Words', 'Match accessory words', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'shoes', 'รองเท้า', NULL),
    (activity_id_var, 'socks', 'ถุงเท้า', NULL),
    (activity_id_var, 'bag', 'กระเป๋า', NULL),
    (activity_id_var, 'belt', 'เข็มขัด', NULL),
    (activity_id_var, 'hat', 'หมวก', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 4, 'Complete the Sentences 1', 'Fill with the correct word', '{"text": "These are ___. This is a ___.", "blanks": [{"id": "blank1", "text": "shoes", "options": ["shoes", "socks", "bag", "belt"], "correctAnswer": "shoes"}, {"id": "blank2", "text": "bag", "options": ["bag", "hat", "socks", "belt"], "correctAnswer": "bag"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 5, 'Complete the Sentences 2', 'Fill with the correct word', '{"text": "I wear ___. I wear a ___.", "blanks": [{"id": "blank1", "text": "socks", "options": ["socks", "hat", "belt", "bag"], "correctAnswer": "socks"}, {"id": "blank2", "text": "belt", "options": ["belt", "hat", "bag", "shoes"], "correctAnswer": "belt"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_explanation', 6, 'Plurals + Colors', 'Use be with plural + color', '{"rules": "Add s for many items. Put color before noun.\n- The shoes are black.\n- These socks are white.", "examples": ["The shoes are black.", "These socks are white.", "This bag is red.", "That hat is blue.", "Are your shoes black?"]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 7, 'Build Sentences 1', 'Arrange words', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'The shoes are black', 'The shoes are black.', '["The", "shoes", "are", "black."]'::jsonb),
    (activity_id_var, 'This bag is red', 'This bag is red.', '["This", "bag", "is", "red."]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 8, 'Build Sentences 2', 'Arrange words', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'That hat is blue', 'That hat is blue.', '["That", "hat", "is", "blue."]'::jsonb),
    (activity_id_var, 'Are your shoes black', 'Are your shoes black?', '["Are", "your", "shoes", "black?"]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'speaking_practice', 9, 'Talk About Accessories', 'Practice colors and plurals', '{"prompts": ["Are your shoes black?", "Do you wear socks?", "Do you have a bag?", "Do you wear a belt?", "Do you like hats?"]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (
      lesson_id,
      activity_type,
      activity_order,
      title,
      description,
      content
    ) VALUES (
      'A1-L34',
      'speaking_improvement',
      10,
      'Speaking Improvement',
      'Read the improved version of your speech',
      '{"type": "speaking_improvement", "similarityThreshold": 70}'::jsonb
    );
END $$;

