-- =========================================
-- Pre-fill Database with Sample Lesson Data
-- B1-L92: Healthy Habits Check
-- =========================================

DELETE FROM grammar_sentences WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'B1-L92');
DELETE FROM vocabulary_items WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'B1-L92');
DELETE FROM lesson_activities WHERE lesson_id = 'B1-L92';
DELETE FROM lessons WHERE id = 'B1-L92';

INSERT INTO lessons (id, level, lesson_number, topic) VALUES
('B1-L92', 'B1', 92, 'Healthy Habits Check')
ON CONFLICT (id) DO UPDATE SET topic = EXCLUDED.topic;

DO $$
DECLARE
    lesson_id_var TEXT := 'B1-L92';
    activity_id_var UUID;
BEGIN
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'warm_up_speaking', 1, 'Habits That Stick', 'Talk about routines that keep you well', '{"prompt": "What happens to you if you skip your best habit?"}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_intro', 2, 'Habit Words', 'Learn vocabulary about daily health habits', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'routine', 'กิจวัตร', NULL),
    (activity_id_var, 'hydrate', 'ดื่มน้ำให้เพียงพอ', NULL),
    (activity_id_var, 'stretch', 'ยืดกล้ามเนื้อ', NULL),
    (activity_id_var, 'sleep', 'นอนหลับ', NULL),
    (activity_id_var, 'avoid', 'หลีกเลี่ยง', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_matching_drag', 3, 'Match Habit Words', 'Match words with meanings', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'routine', 'กิจวัตร', NULL),
    (activity_id_var, 'hydrate', 'ดื่มน้ำให้เพียงพอ', NULL),
    (activity_id_var, 'stretch', 'ยืดกล้ามเนื้อ', NULL),
    (activity_id_var, 'sleep', 'นอนหลับ', NULL),
    (activity_id_var, 'avoid', 'หลีกเลี่ยง', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 4, 'Complete the Sentences 1', 'Fill with the correct word', '{"text": "I keep a morning ___. I ___ before coffee. I always ___ my back.", "blanks": [{"id": "blank1", "text": "routine", "options": ["routine", "hydrate", "stretch", "sleep"], "correctAnswer": "routine"}, {"id": "blank2", "text": "hydrate", "options": ["hydrate", "stretch", "avoid", "sleep"], "correctAnswer": "hydrate"}, {"id": "blank3", "text": "stretch", "options": ["stretch", "sleep", "routine", "avoid"], "correctAnswer": "stretch"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 5, 'Complete the Sentences 2', 'Fill with the correct word', '{"text": "I try to ___ screens late. Good ___ keeps me calm. Missing sleep makes me ___.", "blanks": [{"id": "blank1", "text": "avoid", "options": ["avoid", "hydrate", "stretch", "routine"], "correctAnswer": "avoid"}, {"id": "blank2", "text": "sleep", "options": ["sleep", "routine", "stretch", "hydrate"], "correctAnswer": "sleep"}, {"id": "blank3", "text": "irritable", "options": ["irritable", "hydrated", "stiff", "alert"], "correctAnswer": "irritable"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    -- Grammar Explanation: Zero Conditional (reinforce)
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_explanation', 6, 'Zero Conditional for Habits', 'If + present, present for general health results', '{"rules": "Zero conditional: If + present simple, present simple for general truths.\\n- If I skip sleep, I feel awful.\\n- If I hydrate, I think better.", "examples": ["If I skip sleep, I feel awful.", "If I hydrate early, I focus better.", "If I stretch daily, my back stays fine.", "If I avoid screens late, I sleep faster.", "If I keep a routine, my mood stays steady."]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 7, 'Build Sentences 1', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'If I skip sleep I feel awful', 'If I skip sleep, I feel awful', '["If", "I", "skip", "sleep,", "I", "feel", "awful"]'::jsonb),
    (activity_id_var, 'If I hydrate early I focus better', 'If I hydrate early, I focus better', '["If", "I", "hydrate", "early,", "I", "focus", "better"]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 8, 'Build Sentences 2', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'If I stretch daily my back stays fine', 'If I stretch daily, my back stays fine', '["If", "I", "stretch", "daily,", "my", "back", "stays", "fine"]'::jsonb),
    (activity_id_var, 'If I avoid screens late I sleep faster', 'If I avoid screens late, I sleep faster', '["If", "I", "avoid", "screens", "late,", "I", "sleep", "faster"]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'speaking_practice', 9, 'Talk About Habits', 'Practice talking about health routines', '{"prompts": ["What happens to you if you skip your best habit?", "Which small habit keeps you steady?", "How do you get back on track after a bad day?"]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (
      lesson_id,
      activity_type,
      activity_order,
      title,
      description,
      content
    ) VALUES (
      'B1-L92',
      'speaking_improvement',
      10,
      'Speaking Improvement',
      'Read the improved version of your speech',
      '{"type": "speaking_improvement", "similarityThreshold": 70}'::jsonb
    );
END $$;

