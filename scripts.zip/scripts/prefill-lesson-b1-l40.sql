-- =========================================
-- Pre-fill Database with Sample Lesson Data
-- B1-L40: Homesickness
-- =========================================

DELETE FROM grammar_sentences WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'B1-L40');
DELETE FROM vocabulary_items WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'B1-L40');
DELETE FROM lesson_activities WHERE lesson_id = 'B1-L40';
DELETE FROM lessons WHERE id = 'B1-L40';

INSERT INTO lessons (id, level, lesson_number, topic) VALUES
('B1-L40', 'B1', 40, 'Homesickness')
ON CONFLICT (id) DO UPDATE SET topic = EXCLUDED.topic;

DO $$
DECLARE
    lesson_id_var TEXT := 'B1-L40';
    activity_id_var UUID;
BEGIN
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'warm_up_speaking', 1, 'Feeling Far From Home', 'Talk about missing home and adapting', '{"prompt": "When have you felt homesick?"}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_intro', 2, 'Homesickness Words', 'Learn vocabulary about homesickness and adapting', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'miss', 'คิดถึง', NULL),
    (activity_id_var, 'adapt', 'ปรับตัว', NULL),
    (activity_id_var, 'connect', 'เชื่อมต่อ', NULL),
    (activity_id_var, 'comfort', 'ปลอบใจ/ความสบายใจ', NULL),
    (activity_id_var, 'familiar', 'คุ้นเคย', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_matching_drag', 3, 'Match Homesickness Words', 'Match words with meanings', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'miss', 'คิดถึง', NULL),
    (activity_id_var, 'adapt', 'ปรับตัว', NULL),
    (activity_id_var, 'connect', 'เชื่อมต่อ', NULL),
    (activity_id_var, 'comfort', 'ปลอบใจ/ความสบายใจ', NULL),
    (activity_id_var, 'familiar', 'คุ้นเคย', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 4, 'Complete the Sentences 1', 'Fill with the correct word', '{"text": "I still ___ my friends. I try to ___. I want to stay ___.", "blanks": [{"id": "blank1", "text": "miss", "options": ["miss", "adapt", "connect", "comfort"], "correctAnswer": "miss"}, {"id": "blank2", "text": "adapt", "options": ["adapt", "comfort", "familiar", "connect"], "correctAnswer": "adapt"}, {"id": "blank3", "text": "connected", "options": ["connected", "adapt", "comfort", "miss"], "correctAnswer": "connected"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 5, 'Complete the Sentences 2', 'Fill with the correct word', '{"text": "Calls bring ___. Familiar places feel ___. I ___ to home online.", "blanks": [{"id": "blank1", "text": "comfort", "options": ["comfort", "familiar", "adapt", "miss"], "correctAnswer": "comfort"}, {"id": "blank2", "text": "familiar", "options": ["familiar", "comfort", "connected", "adapt"], "correctAnswer": "familiar"}, {"id": "blank3", "text": "connect", "options": ["connect", "miss", "adapt", "comfort"], "correctAnswer": "connect"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    -- Grammar Explanation: Present Perfect (homesickness experiences)
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_explanation', 6, 'Present Perfect for Homesickness', 'Use have/has + past participle to talk about feelings/experiences up to now', '{"rules": "Present perfect: have/has + past participle for experiences and ongoing feelings without exact time.\\n- I have missed home often.\\n- She has adapted to a new city.\\nAvoid specific past times; use past simple for finished past.", "examples": ["I have missed home many times this year.", "She has adapted to the new city well.", "They have stayed connected with family online.", "We have found comfort in familiar foods.", "He has felt more at home lately."]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 7, 'Build Sentences 1', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'I have missed home many times this year', 'I have missed home many times this year', '["I", "have", "missed", "home", "many", "times", "this", "year"]'::jsonb),
    (activity_id_var, 'She has adapted to the new city well', 'She has adapted to the new city well', '["She", "has", "adapted", "to", "the", "new", "city", "well"]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 8, 'Build Sentences 2', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'They have stayed connected with family online', 'They have stayed connected with family online', '["They", "have", "stayed", "connected", "with", "family", "online"]'::jsonb),
    (activity_id_var, 'We have found comfort in familiar foods', 'We have found comfort in familiar foods', '["We", "have", "found", "comfort", "in", "familiar", "foods"]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'speaking_practice', 9, 'Talk About Homesickness', 'Practice talking about missing home and adapting', '{"prompts": ["When have you felt homesick?", "What helps you adapt in a new place?", "How do you stay connected to people you miss?"]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (
      lesson_id,
      activity_type,
      activity_order,
      title,
      description,
      content
    ) VALUES (
      'B1-L40',
      'speaking_improvement',
      10,
      'Speaking Improvement',
      'Read the improved version of your speech',
      '{"type": "speaking_improvement", "similarityThreshold": 70}'::jsonb
    );
END $$;

