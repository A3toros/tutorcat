-- =========================================
-- Pre-fill Database with Sample Lesson Data
-- B1-L60: Public Transport vs Cars
-- =========================================

DELETE FROM grammar_sentences WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'B1-L60');
DELETE FROM vocabulary_items WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'B1-L60');
DELETE FROM lesson_activities WHERE lesson_id = 'B1-L60';
DELETE FROM lessons WHERE id = 'B1-L60';

INSERT INTO lessons (id, level, lesson_number, topic) VALUES
('B1-L60', 'B1', 60, 'Public Transport vs Cars')
ON CONFLICT (id) DO UPDATE SET topic = EXCLUDED.topic;

DO $$
DECLARE
    lesson_id_var TEXT := 'B1-L60';
    activity_id_var UUID;
BEGIN
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'warm_up_speaking', 1, 'Choosing Transport', 'Talk about transport choices and tradeoffs', '{"prompt": "If fuel costs rise, what will you choose for commuting?"}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_intro', 2, 'Transport Words', 'Learn vocabulary about transport choices', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'commute', 'เดินทางไปทำงาน', NULL),
    (activity_id_var, 'fare', 'ค่าโดยสาร', NULL),
    (activity_id_var, 'emission', 'การปล่อยก๊าซ', NULL),
    (activity_id_var, 'traffic', 'การจราจร', NULL),
    (activity_id_var, 'route', 'เส้นทาง', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_matching_drag', 3, 'Match Transport Words', 'Match words with meanings', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'commute', 'เดินทางไปทำงาน', NULL),
    (activity_id_var, 'fare', 'ค่าโดยสาร', NULL),
    (activity_id_var, 'emission', 'การปล่อยก๊าซ', NULL),
    (activity_id_var, 'traffic', 'การจราจร', NULL),
    (activity_id_var, 'route', 'เส้นทาง', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 4, 'Complete the Sentences 1', 'Fill with the correct word', '{"text": "The ___ is long. The ___ is high this year. ___ makes buses slow.", "blanks": [{"id": "blank1", "text": "commute", "options": ["commute", "fare", "emission", "traffic"], "correctAnswer": "commute"}, {"id": "blank2", "text": "fare", "options": ["fare", "traffic", "route", "emission"], "correctAnswer": "fare"}, {"id": "blank3", "text": "traffic", "options": ["traffic", "route", "emission", "fare"], "correctAnswer": "traffic"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 5, 'Complete the Sentences 2', 'Fill with the correct word', '{"text": "Pick a shorter ___. Cars add more ___. I still prefer to ___.", "blanks": [{"id": "blank1", "text": "route", "options": ["route", "commute", "traffic", "fare"], "correctAnswer": "route"}, {"id": "blank2", "text": "emission", "options": ["emission", "fare", "traffic", "route"], "correctAnswer": "emission"}, {"id": "blank3", "text": "commute", "options": ["commute", "route", "fare", "emission"], "correctAnswer": "commute"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    -- Grammar Explanation: First Conditional (transport choices)
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_explanation', 6, 'First Conditional for Transport Choices', 'Use if + present, will + base verb to talk about likely choices', '{"rules": "If + present simple, will + base verb for likely results.\\n- If fuel costs rise, I will take the bus.\\n- If traffic is heavy, we will change the route.\\nNo contractions.", "examples": ["If fuel costs rise, I will take the bus.", "If traffic is heavy, we will change the route.", "If fares drop, I will commute by train.", "If emissions worry me, I will carpool.", "If the route is slow, I will leave earlier."]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 7, 'Build Sentences 1', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'If fuel costs rise I will take the bus', 'If fuel costs rise, I will take the bus', '["If", "fuel", "costs", "rise,", "I", "will", "take", "the", "bus"]'::jsonb),
    (activity_id_var, 'If traffic is heavy we will change the route', 'If traffic is heavy, we will change the route', '["If", "traffic", "is", "heavy,", "we", "will", "change", "the", "route"]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 8, 'Build Sentences 2', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'If fares drop I will commute by train', 'If fares drop, I will commute by train', '["If", "fares", "drop,", "I", "will", "commute", "by", "train"]'::jsonb),
    (activity_id_var, 'If emissions worry me I will carpool', 'If emissions worry me, I will carpool', '["If", "emissions", "worry", "me,", "I", "will", "carpool"]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'speaking_practice', 9, 'Talk About Transport Choices', 'Practice talking about commuting options', '{"prompts": ["If fuel costs rise, what will you choose for commuting?", "How do different routes change your day?", "When is a car the only option for you?"]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (
      lesson_id,
      activity_type,
      activity_order,
      title,
      description,
      content
    ) VALUES (
      'B1-L60',
      'speaking_improvement',
      10,
      'Speaking Improvement',
      'Read the improved version of your speech',
      '{"type": "speaking_improvement", "similarityThreshold": 70}'::jsonb
    );
END $$;

