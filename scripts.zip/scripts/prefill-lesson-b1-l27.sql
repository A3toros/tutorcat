-- =========================================
-- Pre-fill Database with Sample Lesson Data
-- B1-L27: Living Abroad
-- =========================================

DELETE FROM grammar_sentences WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'B1-L27');
DELETE FROM vocabulary_items WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'B1-L27');
DELETE FROM lesson_activities WHERE lesson_id = 'B1-L27';
DELETE FROM lessons WHERE id = 'B1-L27';

INSERT INTO lessons (id, level, lesson_number, topic) VALUES
('B1-L27', 'B1', 27, 'Living Abroad')
ON CONFLICT (id) DO UPDATE SET topic = EXCLUDED.topic;

DO $$
DECLARE
    lesson_id_var TEXT := 'B1-L27';
    activity_id_var UUID;
BEGIN
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'warm_up_speaking', 1, 'Moving Abroad', 'Talk about adapting to a new country', '{"prompt": "What would you miss first if you moved abroad?"}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_intro', 2, 'Abroad Words', 'Learn vocabulary about living abroad', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'visa', 'วีซ่า', NULL),
    (activity_id_var, 'host', 'เจ้าบ้าน/เจ้าภาพ', NULL),
    (activity_id_var, 'adapt', 'ปรับตัว', NULL),
    (activity_id_var, 'culture', 'วัฒนธรรม', NULL),
    (activity_id_var, 'routine', 'กิจวัตร', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_matching_drag', 3, 'Match Abroad Words', 'Match words with meanings', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'visa', 'วีซ่า', NULL),
    (activity_id_var, 'host', 'เจ้าบ้าน/เจ้าภาพ', NULL),
    (activity_id_var, 'adapt', 'ปรับตัว', NULL),
    (activity_id_var, 'culture', 'วัฒนธรรม', NULL),
    (activity_id_var, 'routine', 'กิจวัตร', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 4, 'Complete the Sentences 1', 'Fill with the correct word', '{"text": "You need a ___ to stay. A local ___ can guide you. You must ___ to the new ___", "blanks": [{"id": "blank1", "text": "visa", "options": ["visa", "host", "adapt", "culture"], "correctAnswer": "visa"}, {"id": "blank2", "text": "host", "options": ["host", "routine", "culture", "adapt"], "correctAnswer": "host"}, {"id": "blank3", "text": "adapt", "options": ["adapt", "culture", "host", "routine"], "correctAnswer": "adapt"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 5, 'Complete the Sentences 2', 'Fill with the correct word', '{"text": "Understanding ___ helps. A steady ___ keeps you calm. You may ___ slowly.", "blanks": [{"id": "blank1", "text": "culture", "options": ["culture", "routine", "host", "adapt"], "correctAnswer": "culture"}, {"id": "blank2", "text": "routine", "options": ["routine", "culture", "visa", "host"], "correctAnswer": "routine"}, {"id": "blank3", "text": "adapt", "options": ["adapt", "routine", "culture", "host"], "correctAnswer": "adapt"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    -- Grammar Explanation: Articles (definite vs zero) review
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_explanation', 6, 'Articles in Living Abroad', 'Use the/zero article for general vs specific things abroad', '{"rules": "Use the for specific known items: the visa, the host family. Use zero article for general plural or uncountable: make friends, learn culture.\\n- The visa is ready.\\n- We joined a culture class.\\n- I keep the same routine.\\nAvoid unnecessary articles with general nouns.", "examples": ["The visa process was slow.", "I met the host family on day one.", "We joined culture classes in town.", "I keep the same routine every morning.", "We made friends from many countries."]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 7, 'Build Sentences 1', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'The visa process was slow', 'The visa process was slow', '["The", "visa", "process", "was", "slow"]'::jsonb),
    (activity_id_var, 'I met the host family on day one', 'I met the host family on day one', '["I", "met", "the", "host", "family", "on", "day", "one"]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 8, 'Build Sentences 2', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'We joined culture classes in town', 'We joined culture classes in town', '["We", "joined", "culture", "classes", "in", "town"]'::jsonb),
    (activity_id_var, 'I keep the same routine every morning', 'I keep the same routine every morning', '["I", "keep", "the", "same", "routine", "every", "morning"]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'speaking_practice', 9, 'Talk About Living Abroad', 'Practice talking about moving abroad', '{"prompts": ["What would you miss first if you moved abroad?", "How would you make friends in a new country?", "What daily routine would you keep?"]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (
      lesson_id,
      activity_type,
      activity_order,
      title,
      description,
      content
    ) VALUES (
      'B1-L27',
      'speaking_improvement',
      10,
      'Speaking Improvement',
      'Read the improved version of your speech',
      '{"type": "speaking_improvement", "similarityThreshold": 70}'::jsonb
    );
END $$;

