-- =========================================
-- Pre-fill Database with Sample Lesson Data
-- B1-L49: Helping Others
-- =========================================

DELETE FROM grammar_sentences WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'B1-L49');
DELETE FROM vocabulary_items WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'B1-L49');
DELETE FROM lesson_activities WHERE lesson_id = 'B1-L49';
DELETE FROM lessons WHERE id = 'B1-L49';

INSERT INTO lessons (id, level, lesson_number, topic) VALUES
('B1-L49', 'B1', 49, 'Helping Others')
ON CONFLICT (id) DO UPDATE SET topic = EXCLUDED.topic;

DO $$
DECLARE
    lesson_id_var TEXT := 'B1-L49';
    activity_id_var UUID;
BEGIN
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'warm_up_speaking', 1, 'Helping Out', 'Talk about how you help others', '{"prompt": "What do you genuinely enjoy doing to help?"}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_intro', 2, 'Helping Words', 'Learn vocabulary about helping others', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'volunteer', 'อาสาสมัคร', NULL),
    (activity_id_var, 'support', 'สนับสนุน', NULL),
    (activity_id_var, 'donate', 'บริจาค', NULL),
    (activity_id_var, 'mentor', 'ให้คำปรึกษา/พี่เลี้ยง', NULL),
    (activity_id_var, 'assist', 'ช่วยเหลือ', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_matching_drag', 3, 'Match Helping Words', 'Match words with meanings', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'volunteer', 'อาสาสมัคร', NULL),
    (activity_id_var, 'support', 'สนับสนุน', NULL),
    (activity_id_var, 'donate', 'บริจาค', NULL),
    (activity_id_var, 'mentor', 'ให้คำปรึกษา/พี่เลี้ยง', NULL),
    (activity_id_var, 'assist', 'ช่วยเหลือ', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 4, 'Complete the Sentences 1', 'Fill with the correct word', '{"text": "I often ___. I like to ___. I also ___ with time.", "blanks": [{"id": "blank1", "text": "volunteer", "options": ["volunteer", "donate", "mentor", "assist"], "correctAnswer": "volunteer"}, {"id": "blank2", "text": "donate", "options": ["donate", "support", "assist", "mentor"], "correctAnswer": "donate"}, {"id": "blank3", "text": "assist", "options": ["assist", "mentor", "support", "volunteer"], "correctAnswer": "assist"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 5, 'Complete the Sentences 2', 'Fill with the correct word', '{"text": "I try to ___ friends. I ___ new volunteers. I ___ a student weekly.", "blanks": [{"id": "blank1", "text": "support", "options": ["support", "assist", "donate", "volunteer"], "correctAnswer": "support"}, {"id": "blank2", "text": "mentor", "options": ["mentor", "support", "assist", "donate"], "correctAnswer": "mentor"}, {"id": "blank3", "text": "mentor", "options": ["mentor", "support", "assist", "volunteer"], "correctAnswer": "mentor"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    -- Grammar Explanation: Gerunds & Infinitives — helping verbs
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_explanation', 6, 'Gerunds and Infinitives for Helping', 'Use verb-ing or to + verb correctly with helping verbs', '{"rules": "Common patterns: enjoy helping, offer to help, decide to donate, avoid making promises you cannot keep, plan to mentor. Keep pairs natural, no contractions.", "examples": ["I enjoy helping my neighbors.", "They decided to donate weekly.", "She offered to assist after work.", "We plan to mentor new members.", "He avoids making empty promises."]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 7, 'Build Sentences 1', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'I enjoy helping my neighbors', 'I enjoy helping my neighbors', '["I", "enjoy", "helping", "my", "neighbors"]'::jsonb),
    (activity_id_var, 'They decided to donate weekly', 'They decided to donate weekly', '["They", "decided", "to", "donate", "weekly"]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 8, 'Build Sentences 2', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'She offered to assist after work', 'She offered to assist after work', '["She", "offered", "to", "assist", "after", "work"]'::jsonb),
    (activity_id_var, 'We plan to mentor new members', 'We plan to mentor new members', '["We", "plan", "to", "mentor", "new", "members"]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'speaking_practice', 9, 'Talk About Helping', 'Practice talking about helping others', '{"prompts": ["What do you genuinely enjoy doing to help?", "When did you give time or money?", "How do you decide who to help?"]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (
      lesson_id,
      activity_type,
      activity_order,
      title,
      description,
      content
    ) VALUES (
      'B1-L49',
      'speaking_improvement',
      10,
      'Speaking Improvement',
      'Read the improved version of your speech',
      '{"type": "speaking_improvement", "similarityThreshold": 70}'::jsonb
    );
END $$;

