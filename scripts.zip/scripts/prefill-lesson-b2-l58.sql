-- ===== LESSON B2-L58 =====

-- =========================================
-- Pre-fill Database with Sample Lesson Data
-- B2-L58: City life vs small towns
-- =========================================

DELETE FROM lesson_activity_results WHERE lesson_id = 'B2-L58';
DELETE FROM user_progress WHERE lesson_id = 'B2-L58';
DELETE FROM lesson_history WHERE lesson_id = 'B2-L58';
DELETE FROM grammar_sentences WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'B2-L58');
DELETE FROM vocabulary_items WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'B2-L58');
DELETE FROM lesson_activities WHERE lesson_id = 'B2-L58';
DELETE FROM lessons WHERE id = 'B2-L58';

INSERT INTO lessons (id, level, lesson_number, topic) VALUES
('B2-L58', 'B2', 58, 'City life vs small towns')
ON CONFLICT (id) DO UPDATE SET topic = EXCLUDED.topic;

DO $$
DECLARE
    lesson_id_var TEXT := 'B2-L58';
    activity_id_var UUID;
BEGIN
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'warm_up_speaking', 1, 'Urban vs Rural', 'Talk about living in cities versus small towns', '{"prompt": "If you lived elsewhere, how would focus change now?"}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_intro', 2, 'Lifestyle Comparison Words', 'Learn words for comparing urban and rural life', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'commute', 'เดินทาง', NULL),
    (activity_id_var, 'pace', 'จังหวะ', NULL),
    (activity_id_var, 'noise', 'เสียงดัง', NULL),
    (activity_id_var, 'tight-knit', 'ใกล้ชิด', NULL),
    (activity_id_var, 'amenities', 'สิ่งอำนวยความสะดวก', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_matching_drag', 3, 'Match Lifestyle Words', 'Match words for urban vs rural life', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'commute', 'เดินทาง', NULL),
    (activity_id_var, 'pace', 'จังหวะ', NULL),
    (activity_id_var, 'noise', 'เสียงดัง', NULL),
    (activity_id_var, 'tight-knit', 'ใกล้ชิด', NULL),
    (activity_id_var, 'amenities', 'สิ่งอำนวยความสะดวก', NULL);

    -- 4. Vocabulary Fill Blanks #1
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 4, 'Complete the Sentences 1', 'Fill in the blanks with correct words', '{"text": "I ___ to work. The ___ of life is fast. There is too much ___.", "blanks": [{"id": "blank1", "text": "commute", "options": ["commute", "pace", "noise", "tight-knit"], "correctAnswer": "commute"}, {"id": "blank2", "text": "pace", "options": ["pace", "commute", "noise", "amenities"], "correctAnswer": "pace"}, {"id": "blank3", "text": "noise", "options": ["noise", "commute", "pace", "tight-knit"], "correctAnswer": "noise"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    -- 5. Vocabulary Fill Blanks #2
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 5, 'Complete the Sentences 2', 'Fill in the blanks with correct words', '{"text": "We are a ___ community. The city has many ___. I prefer the ___.", "blanks": [{"id": "blank1", "text": "tight-knit", "options": ["tight-knit", "commute", "pace", "noise"], "correctAnswer": "tight-knit"}, {"id": "blank2", "text": "amenities", "options": ["amenities", "commute", "pace", "tight-knit"], "correctAnswer": "amenities"}, {"id": "blank3", "text": "pace", "options": ["pace", "amenities", "commute", "tight-knit"], "correctAnswer": "pace"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    -- 6. Grammar Explanation
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_explanation', 6, 'Mixed Conditionals', 'Learn conditionals mixing past and present', '{"rules": "Use mixed conditionals to connect past conditions with present results:\n\n- If + past perfect, would + base verb (If I had grown up, I would be)\n- If + past simple, would + base verb (If she moved, her lifestyle would change)\n- Connects past actions/conditions to present/future results\n- Shows how past choices affect current situation\n- Combines third and second conditional patterns", "examples": ["If I had grown up in a small town, I would be more relaxed now.", "If she moved to the city, her lifestyle would change completely.", "If they had chosen rural life, they would have fewer amenities.", "If I had studied harder, I would have better opportunities now.", "If you lived elsewhere, how would your focus change?"]}'::jsonb)
    RETURNING id INTO activity_id_var;

    -- 7. Grammar Sentences #1
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 7, 'Build Sentences 1', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'If I had grown up in a small town I would be more relaxed now', 'If I had grown up in a small town, I would be more relaxed now.', '["If", "I", "had", "grown", "up", "in", "a", "small", "town,", "I", "would", "be", "more", "relaxed", "now."]'::jsonb),
    (activity_id_var, 'If she moved to the city her lifestyle would change completely', 'If she moved to the city, her lifestyle would change completely.', '["If", "she", "moved", "to", "the", "city,", "her", "lifestyle", "would", "change", "completely."]'::jsonb);

    -- 8. Grammar Sentences #2
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 8, 'Build Sentences 2', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'If they had chosen rural life they would have fewer amenities', 'If they had chosen rural life, they would have fewer amenities.', '["If", "they", "had", "chosen", "rural", "life,", "they", "would", "have", "fewer", "amenities."]'::jsonb),
    (activity_id_var, 'If I had studied harder I would have better opportunities now', 'If I had studied harder, I would have better opportunities now.', '["If", "I", "had", "studied", "harder,", "I", "would", "have", "better", "opportunities", "now."]'::jsonb);

    -- 9. Speaking Practice
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'speaking_practice', 9, 'Talk About Cities and Towns', 'Practice talking about where people live', '{"prompts": ["Do you live in a big city?", "Is there a farm near your town?", "What stores are in your neighborhood?", "Would you prefer city or small town life?", "How does where you live affect your lifestyle?"]}'::jsonb)
    RETURNING id INTO activity_id_var;

    -- 10. Speaking Improvement
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'speaking_improvement', 10, 'Speaking Improvement', 'Read the improved version of your speech', '{"type": "speaking_improvement", "similarityThreshold": 70}'::jsonb)
    RETURNING id INTO activity_id_var;
END $$;