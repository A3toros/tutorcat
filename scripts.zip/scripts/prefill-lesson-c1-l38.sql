-- =========================================
-- Pre-fill Database with Sample Lesson Data
-- C1-L38: National Identity Among Youth
-- =========================================
DELETE FROM lesson_activity_results WHERE lesson_id = 'C1-L38';
DELETE FROM user_progress WHERE lesson_id = 'C1-L38';
DELETE FROM lesson_history WHERE lesson_id = 'C1-L38';
DELETE FROM grammar_sentences WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'C1-L38');
DELETE FROM vocabulary_items WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'C1-L38');
DELETE FROM lesson_activities WHERE lesson_id = 'C1-L38';
DELETE FROM lessons WHERE id = 'C1-L38';

INSERT INTO lessons (id, level, lesson_number, topic) VALUES
('C1-L38', 'C1', 38, 'National Identity Among Youth')
ON CONFLICT (id) DO UPDATE SET topic = EXCLUDED.topic;

DO $$
DECLARE
    lesson_id_var TEXT := 'C1-L38';
    activity_id_var UUID;
BEGIN
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'warm_up_speaking', 1, 'National Identity', 'Discuss national identity among youth', '{"prompt": "How do young people view national identity today?"}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_intro', 2, 'National Identity Vocabulary', 'Learn vocabulary about national identity', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'identity', 'ตัวตน', NULL),
    (activity_id_var, 'youth', 'เยาวชน', NULL),
    (activity_id_var, 'influence', 'อิทธิพล', NULL),
    (activity_id_var, 'globalization', 'โลกาภิวัตน์', NULL),
    (activity_id_var, 'expression', 'การแสดงออก', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_matching_drag', 3, 'Match National Identity Words', 'Match English words with Thai meanings', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'identity', 'ตัวตน', NULL),
    (activity_id_var, 'youth', 'เยาวชน', NULL),
    (activity_id_var, 'influence', 'อิทธิพล', NULL),
    (activity_id_var, 'globalization', 'โลกาภิวัตน์', NULL),
    (activity_id_var, 'expression', 'การแสดงออก', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 4, 'Complete the Sentences 1', 'Fill with the correct word', '{"text": "National ___ among ___ is changing. Various ___ shape ___.", "blanks": [{"id": "blank1", "text": "identity", "options": ["identity", "youth", "influence", "globalization"], "correctAnswer": "identity"}, {"id": "blank2", "text": "youth", "options": ["youth", "identity", "influence", "expression"], "correctAnswer": "youth"}, {"id": "blank3", "text": "influences", "options": ["influences", "identity", "youth", "globalization"], "correctAnswer": "influences"}, {"id": "blank4", "text": "identity", "options": ["identity", "youth", "influence", "expression"], "correctAnswer": "identity"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 5, 'Complete the Sentences 2', 'Fill with the correct word', '{"text": "___ affects national ___. Young people express ___ through various means.", "blanks": [{"id": "blank1", "text": "Globalization", "options": ["Globalization", "Identity", "Youth", "Influence"], "correctAnswer": "Globalization"}, {"id": "blank2", "text": "identity", "options": ["identity", "youth", "influence", "expression"], "correctAnswer": "identity"}, {"id": "blank3", "text": "identity", "options": ["identity", "youth", "influence", "expression"], "correctAnswer": "identity"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_explanation', 6, 'Articles: Generic Reference', 'Learn articles with generic nouns', '{"rules": "Generic reference with articles:\n- Zero article for general concepts: \"Identity changes over time.\"\n- \"The\" for specific instances: \"The identity of youth is evolving.\"\n- \"A/an\" for classifying: \"Identity is a complex concept.\"\n\nPatterns:\n- General statements: \"National identity shapes values.\"\n- Specific reference: \"The identity of young people differs.\"\n- Classification: \"Identity is a personal construct.\"\n\nUse for:\n- General statements: \"National identity evolves.\"\n- Specific cases: \"The identity we see is changing.\"\n- Classification: \"Identity is a form of belonging.\"", "examples": ["National identity evolves among youth.", "The identity of young people is changing.", "Identity is a complex personal construct.", "The identity we observe reflects globalization.", "National identity shapes how youth express themselves."]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 7, 'Build Sentences 1', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'National identity evolves among youth.', 'National identity evolves among youth.', '["National", "identity", "evolves", "among", "youth."]'::jsonb),
    (activity_id_var, 'The identity of young people is changing.', 'The identity of young people is changing.', '["The", "identity", "of", "young", "people", "is", "changing."]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 8, 'Build Sentences 2', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'Identity is a complex personal construct.', 'Identity is a complex personal construct.', '["Identity", "is", "a", "complex", "personal", "construct."]'::jsonb),
    (activity_id_var, 'The identity we observe reflects globalization.', 'The identity we observe reflects globalization.', '["The", "identity", "we", "observe", "reflects", "globalization."]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'speaking_practice', 9, 'Discuss National Identity', 'Practice speaking about national identity', '{"prompts": ["What does national identity mean to you?", "How is it changing among youth?", "What influences national identity?", "How does globalization affect it?", "How do young people express identity?"]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (
      lesson_id,
      activity_type,
      activity_order,
      title,
      description,
      content
    ) VALUES (
      'C1-L38',
      'speaking_improvement',
      10,
      'Speaking Improvement',
      'Read the improved version of your speech',
      '{"type": "speaking_improvement", "similarityThreshold": 70}'::jsonb
    );
END $$;
