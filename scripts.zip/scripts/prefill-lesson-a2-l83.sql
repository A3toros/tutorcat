-- =========================================
-- Pre-fill Database with Sample Lesson Data
-- A2-L83: Talking About Colleagues
-- =========================================

DELETE FROM grammar_sentences WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'A2-L83');
DELETE FROM vocabulary_items WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'A2-L83');
DELETE FROM lesson_activities WHERE lesson_id = 'A2-L83';
DELETE FROM lessons WHERE id = 'A2-L83';

INSERT INTO lessons (id, level, lesson_number, topic) VALUES
('A2-L83', 'A2', 83, 'Talking About Colleagues')
ON CONFLICT (id) DO UPDATE SET topic = EXCLUDED.topic;

DO $$
DECLARE
    lesson_id_var TEXT := 'A2-L83';
    activity_id_var UUID;
BEGIN
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'warm_up_speaking', 1, 'Colleagues', 'Talk about people at work', '{"prompt": "Who helps you at work?"}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_intro', 2, 'Colleague Words', 'Learn colleague-related words', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'colleague', 'เพื่อนร่วมงาน', NULL),
    (activity_id_var, 'team', 'ทีม', NULL),
    (activity_id_var, 'help', 'ช่วยเหลือ', NULL),
    (activity_id_var, 'support', 'สนับสนุน', NULL),
    (activity_id_var, 'friendly', 'เป็นมิตร', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_matching_drag', 3, 'Match Colleague Words', 'Match colleague words', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'colleague', 'เพื่อนร่วมงาน', NULL),
    (activity_id_var, 'team', 'ทีม', NULL),
    (activity_id_var, 'help', 'ช่วยเหลือ', NULL),
    (activity_id_var, 'support', 'สนับสนุน', NULL),
    (activity_id_var, 'friendly', 'เป็นมิตร', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 4, 'Complete the Sentences 1', 'Fill with the correct word', '{"text": "My ___ is very ___. We work as a ___.", "blanks": [{"id": "blank1", "text": "colleague", "options": ["colleague", "team", "friendly", "support"], "correctAnswer": "colleague"}, {"id": "blank2", "text": "friendly", "options": ["friendly", "support", "team", "help"], "correctAnswer": "friendly"}, {"id": "blank3", "text": "team", "options": ["team", "colleague", "support", "help"], "correctAnswer": "team"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 5, 'Complete the Sentences 2', 'Fill with the correct word', '{"text": "They ___ each other. We ___ new staff.", "blanks": [{"id": "blank1", "text": "help", "options": ["help", "support", "friendly", "team"], "correctAnswer": "help"}, {"id": "blank2", "text": "support", "options": ["support", "help", "team", "colleague"], "correctAnswer": "support"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_explanation', 6, 'Object & Possessive Pronouns', 'Refer to coworkers politely', '{"rules": "Use object pronouns (me, you, him, her, us, them) and possessive pronouns (mine, yours, his, hers, ours, theirs).\n- She helps me. This desk is mine.\n- The idea is theirs.", "examples": ["She helps me with tasks.", "This desk is mine.", "Is that laptop yours?", "We support them every day.", "The project is ours."]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 7, 'Build Sentences 1', 'Arrange words', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'She helps me with tasks', 'She helps me with tasks.', '["She", "helps", "me", "with", "tasks."]'::jsonb),
    (activity_id_var, 'This desk is mine', 'This desk is mine.', '["This", "desk", "is", "mine."]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 8, 'Build Sentences 2', 'Arrange words', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'Is that laptop yours', 'Is that laptop yours?', '["Is", "that", "laptop", "yours?"]'::jsonb),
    (activity_id_var, 'The project is ours', 'The project is ours.', '["The", "project", "is", "ours."]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'speaking_practice', 9, 'Talk About Colleagues', 'Practice talking about coworkers', '{"prompts": ["Who helps you at work, and how do they help you?", "Do you work with them every day?", "How do you support your colleagues?", "Do you share tasks with them?", "How do you work as a team?"]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (
      lesson_id,
      activity_type,
      activity_order,
      title,
      description,
      content
    ) VALUES (
      'A2-L83',
      'speaking_improvement',
      10,
      'Speaking Improvement',
      'Read the improved version of your speech',
      '{"type": "speaking_improvement", "similarityThreshold": 70}'::jsonb
    );
END $$;

