-- =========================================
-- Pre-fill Database with Sample Lesson Data
-- B2-L1: Technology & Society
-- =========================================

DELETE FROM grammar_sentences WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'B2-L1');
DELETE FROM vocabulary_items WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'B2-L1');
DELETE FROM lesson_activities WHERE lesson_id = 'B2-L1';
DELETE FROM lessons WHERE id = 'B2-L1';

INSERT INTO lessons (id, level, lesson_number, topic) VALUES
('B2-L1', 'B2', 1, 'Technology & Society')
ON CONFLICT (id) DO UPDATE SET topic = EXCLUDED.topic;

DO $$
DECLARE
    lesson_id_var TEXT := 'B2-L1';
    activity_id_var UUID;
BEGIN
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'warm_up_speaking', 1, 'Daily Tech Choices', 'Talk about how tech fits your day', '{"prompt": "When does technology really help you in a normal day?"}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_intro', 2, 'Tech & Society Words', 'Key words for tech and social impact', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'algorithm', 'อัลกอริทึม', NULL),
    (activity_id_var, 'data privacy', 'ความเป็นส่วนตัวของข้อมูล', NULL),
    (activity_id_var, 'screen time', 'เวลาหน้าจอ', NULL),
    (activity_id_var, 'digital divide', 'ความเหลื่อมล้ำทางดิจิทัล', NULL),
    (activity_id_var, 'platform', 'แพลตฟอร์ม', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_matching_drag', 3, 'Match Tech & Society Words', 'Match words with meanings', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'algorithm', 'อัลกอริทึม', NULL),
    (activity_id_var, 'data privacy', 'ความเป็นส่วนตัวของข้อมูล', NULL),
    (activity_id_var, 'screen time', 'เวลาหน้าจอ', NULL),
    (activity_id_var, 'digital divide', 'ความเหลื่อมล้ำทางดิจิทัล', NULL),
    (activity_id_var, 'platform', 'แพลตฟอร์ม', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 4, 'Complete the Sentences 1', 'Fill with the correct word', '{"text": "I set limits on my ___ each night. The app uses an ___ to choose my feed. I worry about my ___ when signing up.", "blanks": [{"id": "blank1", "text": "screen time", "options": ["screen time", "algorithm", "data privacy", "platform"], "correctAnswer": "screen time"}, {"id": "blank2", "text": "algorithm", "options": ["algorithm", "platform", "data privacy", "digital divide"], "correctAnswer": "algorithm"}, {"id": "blank3", "text": "data privacy", "options": ["data privacy", "screen time", "digital divide", "platform"], "correctAnswer": "data privacy"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 5, 'Complete the Sentences 2', 'Fill with the correct word', '{"text": "This ___ connects students in one place. Some towns still face a ___ without good internet. I prefer a ___ that is transparent.", "blanks": [{"id": "blank1", "text": "platform", "options": ["platform", "algorithm", "data privacy", "screen time"], "correctAnswer": "platform"}, {"id": "blank2", "text": "digital divide", "options": ["digital divide", "platform", "screen time", "algorithm"], "correctAnswer": "digital divide"}, {"id": "blank3", "text": "platform", "options": ["platform", "data privacy", "digital divide", "screen time"], "correctAnswer": "platform"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_explanation', 6, 'Modals for Deduction', 'Use must/might/can’t to guess reasons', '{"rules": "Use modals to show how sure you are.\\n- must for strong certainty: The server must be down.\\n- might for possibility: It might be a settings issue.\\n- can''t for strong negative: This can''t be the correct login.\\nUse present form + verb for now; use have + past participle for past clues.", "examples": ["The algorithm must be personalizing your feed.", "It might be a privacy setting.", "That can’t be the official site.", "He must have changed his password.", "The outage might have affected the platform."]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 7, 'Build Sentences 1', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'The platform must be down right now', 'The platform must be down right now.', '["The", "platform", "must", "be", "down", "right", "now."]'::jsonb),
    (activity_id_var, 'It might be a privacy setting issue', 'It might be a privacy setting issue.', '["It", "might", "be", "a", "privacy", "setting", "issue."]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 8, 'Build Sentences 2', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'He must have changed the password', 'He must have changed the password.', '["He", "must", "have", "changed", "the", "password."]'::jsonb),
    (activity_id_var, 'That can’t be the official algorithm', 'That can’t be the official algorithm.', '["That", "can’t", "be", "the", "official", "algorithm."]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'speaking_practice', 9, 'Talk About Tech & Society', 'Practice sharing views on tech impact', '{"prompts": ["When does technology help you learn faster?", "What data about you do you really want private?", "How do you limit your screen time on busy days?"]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (
      lesson_id,
      activity_type,
      activity_order,
      title,
      description,
      content
    ) VALUES (
      'B2-L1',
      'speaking_improvement',
      10,
      'Speaking Improvement',
      'Read the improved version of your speech',
      '{"type": "speaking_improvement", "similarityThreshold": 70}'::jsonb
    );
END $$;


