# A2 Additional Lessons Plan (L11-L100) — Spread Topics, Spread Grammar

## Requirements & Guidelines
- **No ambiguity:** One clear fill-blank answer (lesson vocab only); 3 unrelated distractors.
- **Grammar sentences:** Simple, natural; no swap-ambiguous pairs; add “?” to questions; commas on preceding word; no contractions.
- **Speaking:** Student-friendly, personal, concrete; no adult-only themes.
- **Speaking improvement:** Include `speaking_improvement` with `similarityThreshold: 70`.
- **Topics spread:** Rotate themes (travel, shopping, food, work, health, holidays, tech, feelings, sports, describing) to avoid clustering.
- **Grammar spread:** Revisit A2 grammar for spaced review.

## CEFR A2 Grammar Coverage (from `cefr-grammar-requirements.md`)
- Present Simple; Present Continuous
- Past Simple (regular/irregular)
- Future: going to
- Modal can (ability/permission)
- Questions & negatives (do/does/did)
- Some/any; much/many/a lot of
- Comparatives / superlatives
- Adverbs of frequency; adverbs of manner
- Object / possessive pronouns; basic reflexives
- Prepositions (time, place, movement)
- Linkers: and / but / because / so

### Planned Review Counts (target)
- Present Simple / questions: 8
- Present Continuous: 6
- Past Simple: 8
- Going to (future): 5
- Can (ability/permission): 4
- Negatives/questions with do/does/did: 5
- Some/any/much/many: 4
- Comparatives/superlatives: 4
- Adverbs (frequency/manner): 4
- Pronouns (object/possessive/reflexive): 4
- Prepositions (time/place/movement): 4
- Linkers and/but/because/so: 4

---

## Lesson Plan (topics spread; grammar spaced)
Format per lesson:
- Topic + theme
- Grammar focus (+review #)
- Vocab sample (5 items)
- Speaking prompts (3 open, personal)

### L11-L20 (spread across themes)
- **A2-L11 Buying a Train or Bus Ticket** — Present Simple questions #1; vocab: ticket, platform, single, return, schedule; speaking: “Where do you usually buy tickets?”, “How do you ask for the time?”, “Do you prefer bus or train? Why?”
- **A2-L12 Talking About Happiness** — Adverbs of manner #1; vocab: happy, smile, laugh, enjoy, relax; speaking: “What makes you happy daily?”, “How do you relax after work?”, “Who makes you laugh?”
- **A2-L13 Comparing Prices** — Comparatives/superlatives #1; vocab: cheaper, expensive, best, price, deal; speaking: “Where do you find good prices?”, “Do you compare online?”, “What was your best deal?”
- **A2-L14 Daily Work Tasks** — Present Simple #1; vocab: meeting, email, report, call, break; speaking: “What tasks do you do every day?”, “When do you take breaks?”, “Do you like meetings?”
- **A2-L15 Booking a Table** — Present Continuous #1; vocab: book, table, reservation, tonight, time; speaking: “How do you book a table?”, “Do you prefer early or late dinner?”, “Who do you eat out with?”
- **A2-L16 Common Illnesses** — There is/are + health #1; vocab: cough, fever, cold, sick, clinic; speaking: “How do you feel when you have a cold?”, “Do you see a doctor quickly?”, “Who takes care of you?”
- **A2-L17 Using a Smartphone** — Can (ability) #1; vocab: charge, call, chat, update, install; speaking: “What can your phone help you do?”, “Do you install many apps?”, “How do you fix small phone problems?”
- **A2-L18 Planning a Holiday** — Going to (future) #1; vocab: plan, book, ticket, hotel, budget; speaking: “Where are you going next?”, “How do you book hotels?”, “Do you set a budget?”
- **A2-L19 Playing Team Sports** — Present Continuous #2; vocab: team, match, practice, coach, score; speaking: “Do you play on a team now?”, “What position do you like?”, “When do you practice?”
- **A2-L20 Physical Appearance** — Adjectives/basic comparatives #2; vocab: tall, short, hair, eyes, glasses; speaking: “How would you describe yourself?”, “Do you look like your family?”, “Do you wear glasses?”

### L21-L30
- **A2-L21 Asking About Timetables** — Prepositions time #1; vocab: arrive, depart, late, on time, delay; speaking: “When was your last delay?”, “How do you check times?”, “What do you do while waiting?”
- **A2-L22 Paying by Cash or Card** — Present Simple negatives/questions #2; vocab: cash, card, receipt, change, machine; speaking: “Do you pay by card or cash?”, “Have you lost a receipt?”, “Do you trust card machines?”
- **A2-L23 Job Schedules** — Time prepositions #2; vocab: shift, schedule, overtime, start, finish; speaking: “What time do you start work?”, “Do you work weekends?”, “How do you feel about overtime?”
- **A2-L24 Reading a Menu** — There is/are + food #2; vocab: starter, main, dessert, spicy, vegetarian; speaking: “What do you check first on a menu?”, “Do you ask about spicy food?”, “What dessert do you like?”
- **A2-L25 Visiting a Doctor** — Questions/negatives #3; vocab: appointment, symptoms, medicine, rest, check; speaking: “How do you book a doctor?”, “Do you ask many questions?”, “Do you follow advice?”
- **A2-L26 Sending Messages** — Questions do/does #4; vocab: message, reply, emoji, send, receive; speaking: “Do you reply fast?”, “Do you use many emojis?”, “How do you feel about voice notes?”
- **A2-L27 Birthday Celebrations** — Past Simple #2; vocab: birthday, cake, party, invite, wish; speaking: “How did you celebrate your last birthday?”, “Who came?”, “What gift did you like?”
- **A2-L28 Feeling Angry or Upset** — Linkers because/so #1; vocab: angry, upset, calm, reason, breathe; speaking: “What makes you angry?”, “How do you calm down?”, “Do you talk to someone?”
- **A2-L29 Going to the Gym** — Adverbs frequency #1; vocab: gym, weights, treadmill, set, reps; speaking: “How often do you go to the gym?”, “Do you follow a plan?”, “Who shows you new exercises?”
- **A2-L30 Clothes & Style** — Adjectives/comparatives #3; vocab: uniform, casual, formal, comfortable, neat; speaking: “Do you wear a uniform?”, “Do you like formal clothes?”, “What is most comfortable?”

### L31-L40
- **A2-L31 Missing a Bus or Train** — Past Simple #3; vocab: missed, waited, ran, caught, change; speaking: “Have you ever missed a bus?”, “Who helped you then?”, “What do you do next time?”
- **A2-L32 Returning a Product** — Past Simple #4; vocab: return, refund, broken, receipt, exchange; speaking: “Have you returned something?”, “Why did you return it?”, “How did staff help you?”
- **A2-L33 Workplace Rules** — Must/mustn’t #1; vocab: rule, uniform, late, safety, break time; speaking: “What rules are at your job?”, “Which rule is hard?”, “Why do rules matter?”
- **A2-L34 Asking About Ingredients** — Questions (what/which) #4; vocab: ingredient, allergy, gluten, dairy, nut; speaking: “Do you ask about ingredients?”, “Any foods you avoid?”, “How do you order safely?”
- **A2-L35 Buying Medicine** — Can (permission) #2; vocab: pharmacy, prescription, tablet, syrup, dose; speaking: “How do you ask for medicine?”, “Do you read the instructions?”, “Do you keep old medicine?”
- **A2-L36 Social Media Basics** — Adverbs frequency #2; vocab: post, scroll, like, follow, share; speaking: “How often do you post?”, “Do you follow news or friends more?”, “Do you limit scrolling?”
- **A2-L37 Holiday Traditions** — Present Simple #2; vocab: holiday, parade, flag, day off, celebrate; speaking: “What holiday do you enjoy?”, “What do people do on that day?”, “Do you get time off?”
- **A2-L38 Being Nervous** — Present Continuous #3; vocab: nervous, waiting, interview, test, breathe; speaking: “When do you feel nervous?”, “What are you doing to feel calm?”, “Who supports you?”
- **A2-L39 Outdoor Activities** — Prepositions movement #1; vocab: hike, climb, run, path, hill; speaking: “Where do you like to hike?”, “Do you run in parks?”, “Do you enjoy hills or flat paths?”
- **A2-L40 Describing Personality** — Adjectives/feelings #1; vocab: friendly, quiet, funny, kind, shy; speaking: “How would you describe your friend?”, “Are you shy or outgoing?”, “Who is the funniest person you know?”

### L41-L50
- **A2-L41 Airport Check-in** — Present Continuous #4; vocab: check-in, queue, luggage, boarding pass, counter; speaking: “How early do you go to the airport?”, “Do you like self check-in?”, “What do you pack first?”
- **A2-L42 Asking for a Different Size** — Comparatives #4; vocab: size, fit, tight, loose, try on; speaking: “Do clothes fit you well?”, “Do you ask for another size?”, “Who helps you shop?”
- **A2-L43 Part-Time Jobs** — Past Simple #5; vocab: part-time, weekend, salary, boss, customer; speaking: “Have you had a part-time job?”, “What did you do?”, “What did you learn?”
- **A2-L44 Ordering Takeaway Food** — Imperatives/requests #2; vocab: takeaway, delivery, menu, order, tip; speaking: “How often do you order in?”, “Do you tip drivers?”, “What app do you use?”
- **A2-L45 Healthy Food Choices** — Comparatives #5; vocab: healthy, unhealthy, fresh, fried, portion; speaking: “What is a healthy meal for you?”, “Do you eat fried food often?”, “Who cooks healthier in your family?”
- **A2-L46 Watching Videos Online** — Adverbs frequency #3; vocab: watch, pause, skip, subscribe, recommend; speaking: “What videos are you watching lately?”, “Do you skip ads?”, “Do you subscribe to channels?”
- **A2-L47 Giving Presents** — Going to (future) #2; vocab: gift, wrap, card, surprise, choose; speaking: “Who are you going to buy a gift for?”, “Do you like surprises?”, “What was your favorite gift?”
- **A2-L48 Feeling Relaxed** — Comparatives #6; vocab: relax, quiet, noisy, peaceful, busy; speaking: “Where do you relax best?”, “Is home or park more relaxing?”, “Do you like quiet music?”
- **A2-L49 Watching Sports** — Past Simple #6; vocab: match, team, win, lose, cheer; speaking: “What game did you watch recently?”, “Who won?”, “Who did you watch with?”
- **A2-L50 Talking About Family Members** — Possessive/object pronouns #1; vocab: mother, father, sister, brother, mine; speaking: “Who are you close to?”, “Who do you live with?”, “Do you look like your family?”

### L51-L60
- **A2-L51 Carrying Luggage** — Comparatives #5; vocab: heavy, light, backpack, suitcase, handle; speaking: “Do you travel light or heavy?”, “Who helps you with bags?”, “What bag is most comfortable?”
- **A2-L52 Shopping at a Market** — Present Continuous #5; vocab: stall, bargain, fresh, vendor, basket; speaking: “Do you like markets?”, “What do you buy there?”, “Do you bargain?”
- **A2-L53 Talking About Salary (basic)** — Comparatives #7; vocab: salary, raise, higher, lower, fair; speaking: “Do you discuss salary with friends?”, “What is a fair salary for you?”, “Have you asked for a raise?”
- **A2-L54 Paying the Bill** — Past Simple #7; vocab: bill, receipt, split, paid, forgot; speaking: “Have you split a bill?”, “Did you ever forget to pay?”, “Who pays in your group?”
- **A2-L55 Exercising Regularly** — Adverbs frequency #4; vocab: jog, gym, stretch, yoga, walk; speaking: “How often do you exercise?”, “Do you like the gym or outdoors?”, “Who do you exercise with?”
- **A2-L56 Using Apps** — Can (ability) #3; vocab: app, login, password, update, bug; speaking: “Can you fix simple app problems?”, “Do you remember many passwords?”, “What app helps you daily?”
- **A2-L57 Invitations to Parties** — Imperatives/requests #3; vocab: invite, RSVP, bring, come, time; speaking: “How do you invite friends?”, “What do you bring to parties?”, “Do you arrive on time?”
- **A2-L58 Expressing Likes & Dislikes** — Object pronouns #2; vocab: like, dislike, love, hate, prefer; speaking: “What do you like doing on weekends?”, “What food do you dislike?”, “Do you prefer movies or books?”
- **A2-L59 Sports Equipment** — Some/any/much/many #2; vocab: ball, racket, helmet, shoes, gloves; speaking: “How many shoes do you use for sports?”, “Do you share equipment?”, “Do you have any safety gear?”
- **A2-L60 Describing a Place** — Prepositions place #2; vocab: near, next to, behind, between, opposite; speaking: “Where is your home?”, “What is near it?”, “How do you describe your room?”

### L61-L70
- **A2-L61 Taxi Rides** — Can (requests) #2; vocab: taxi, fare, meter, drop off, change; speaking: “How do you ask a driver to stop?”, “Do you prefer taxi or app rides?”, “When do you share a ride?”
- **A2-L62 Discounts & Sales** — Some/any/much/many #3; vocab: sale, discount, percent, offer, price tag; speaking: “Do you wait for sales?”, “How much do you spend on clothes?”, “Do you buy many items at once?”
- **A2-L63 Work Clothes** — Adjectives/comparatives #5; vocab: uniform, formal, casual, comfortable, neat; speaking: “Do you wear a uniform?”, “Do you like formal clothes?”, “What is most comfortable?”
- **A2-L64 Complaining About Food** — Can (permission/requests) #3; vocab: cold, wrong order, replace, manager, polite; speaking: “How do you complain politely?”, “Have you sent food back?”, “Do you ask for a refund?”
- **A2-L65 Feeling Tired or Sick** — Past Simple #8; vocab: tired, headache, slept, stayed, rested; speaking: “When were you very tired?”, “What did you do to rest?”, “Who helped you?”
- **A2-L66 Online Learning** — Going to (future) #6; vocab: course, lesson, practice, quiz, improve; speaking: “Are you going to take an online course?”, “How do you practice after lessons?”, “Do you like video or text more?”
- **A2-L67 Holiday Weather** — Comparatives/superlatives #6; vocab: sunny, rainy, warm, cold, favorite; speaking: “What weather do you like for holidays?”, “Is beach or mountain better?”, “What was your coldest trip?”
- **A2-L68 Talking About Stress** — Linkers because/so #2; vocab: stress, reason, because, so, break; speaking: “Why do you feel stressed?”, “What do you do, so you feel better?”, “Who helps you reduce stress?”
- **A2-L69 Exercising With Friends** — Adverbs manner #2; vocab: together, slow, fast, carefully, safely; speaking: “Do you exercise alone or together?”, “Do you go slow or fast?”, “How do you exercise safely?”
- **A2-L70 Colors & Shapes** — Describing objects #1; vocab: red, blue, round, square, striped; speaking: “What colors do you like to wear?”, “Do you prefer round or square tables?”, “Describe a bag you use.”

### L71-L80
- **A2-L71 Travel Delays** — Linkers and/but/because/so #3; vocab: delay, traffic, weather, late, plan; speaking: “Why were you late last time?”, “How did you feel?”, “What do you do while waiting?”
- **A2-L72 Buying Gifts** — Going to (future) #4; vocab: gift, wrap, card, surprise, choose; speaking: “Who are you going to buy a gift for?”, “Do you like surprises?”, “What was your favorite gift?”
- **A2-L73 Looking for a Job** — Going to (future) #5; vocab: apply, resume, interview, hire, hire date; speaking: “Are you going to change jobs?”, “How do you prepare for interviews?”, “Who checks your resume?”
- **A2-L74 Fast Food vs Restaurants** — Comparatives #8; vocab: fast, slow, healthy, tasty, service; speaking: “Which do you prefer?”, “Is fast food cheaper?”, “Where do you go with friends?”
- **A2-L75 Talking About Pain** — Can / questions #5; vocab: pain, hurt, sore, sharp, dull; speaking: “How do you describe pain to a doctor?”, “Do you point to where it hurts?”, “Do you rate pain numbers?”
- **A2-L76 Internet Problems** — Past Simple #9; vocab: offline, slow, error, fixed, reset; speaking: “When was your internet slow?”, “How did you fix it?”, “Who helped you?”
- **A2-L77 Favorite Celebrations** — Present Perfect light #1; vocab: favorite, celebrate, enjoyed, remember, time; speaking: “What celebration did you enjoy the most?”, “Why was it special?”, “Who was with you?”
- **A2-L78 Feeling Bored** — Present Simple #9; vocab: boring, bored, same, change, new; speaking: “What feels boring to you?”, “How do you make days interesting?”, “Do you try new hobbies?”
- **A2-L79 Traveling With Friends** — Pronouns (object/possessive) #3; vocab: share, ours, yours, together, plan; speaking: “Who plans the trips?”, “Do you share costs?”, “How do you choose activities?”
- **A2-L80 Describing Objects You Use Daily** — Adjectives/this/that #2; vocab: phone, bag, keys, wallet, watch; speaking: “What is in your bag?”, “Which object do you use most?”, “Describe your phone.”

### L81-L90
- **A2-L81 Asking for Directions** — Imperatives/places #2; vocab: left, right, straight, corner, across; speaking: “How do you ask for a place?”, “Do you help tourists?”, “What map app do you use?”
- **A2-L82 Online Shopping Basics** — Adverbs frequency #4; vocab: cart, delivery, address, track, review; speaking: “How often do you shop online?”, “Do you read reviews?”, “Do you track your orders?”
- **A2-L83 Talking About Colleagues** — Pronouns/object/possessive #4; vocab: colleague, team, help, support, friendly; speaking: “Who helps you at work?”, “Do you eat with colleagues?”, “How do you support them?”
- **A2-L84 Eating at Home** — Adverbs frequency #5; vocab: cook, eat out, often, sometimes, rarely; speaking: “How often do you cook?”, “Who cooks at home?”, “What dish do you make often?”
- **A2-L85 Rest & Sleep** — Prepositions time #4; vocab: bedtime, nap, early, late, alarm; speaking: “What time do you sleep?”, “Do you nap?”, “Do you wake up early or late?”
- **A2-L86 Email Communication** — Formal/informal openings #1; vocab: email, subject, attach, send, reply; speaking: “Do you write short emails?”, “Do you check subjects?”, “Have you sent a wrong email?”
- **A2-L87 Family Celebrations** — Possessive/object pronouns #4; vocab: family, cousin, aunt, uncle, ours; speaking: “Who cooks in your family events?”, “Do you share photos?”, “What tradition is yours?”
- **A2-L88 Excitement About Plans** — Going to (future) #7; vocab: excited, plan, trip, meet, soon; speaking: “What are you excited about soon?”, “Who are you going to meet?”, “What plans do you make first?”
- **A2-L89 Talking About Fitness Goals** — Linkers so/because #3; vocab: goal, improve, healthy, strong, routine; speaking: “What fitness goal do you have?”, “Why is it important?”, “What routine will you follow so you reach it?”
- **A2-L90 Talking About Age** — Questions/how old #1; vocab: age, old, young, birthday, year; speaking: “How old are you?”, “When is your birthday?”, “Do you feel older or younger than friends?”

### L91-L100
- **A2-L91 Renting a Bicycle or Scooter** — Going to (future) #8; vocab: rent, helmet, lock, hourly, return; speaking: “Where would you ride first?”, “Would you wear a helmet?”, “How long are you going to ride?”
- **A2-L92 Asking About Quality** — Questions with do/does #5; vocab: quality, durable, soft, safe, guarantee; speaking: “How do you ask if something is good?”, “Do you trust guarantees?”, “What material do you prefer?”
- **A2-L93 Working Hours** — Adverbs frequency #6; vocab: often, always, rarely, sometimes, usually; speaking: “How often do you work late?”, “Do you always take lunch?”, “What day is easiest?”
- **A2-L94 Traditional Food** — Past Simple #10; vocab: traditional, recipe, festival, holiday, taste; speaking: “What food reminds you of family?”, “Who taught you to cook it?”, “When do you eat it?”
- **A2-L95 Staying Fit** — Going to (future) #9; vocab: plan, goal, routine, track, improve; speaking: “Are you going to start a new routine?”, “How will you track progress?”, “Who motivates you?”
- **A2-L96 Technology at Work** — Present Simple #8; vocab: printer, file, upload, download, share; speaking: “What tech do you use at work?”, “Do you share files often?”, “Have you printed the wrong file?”
- **A2-L97 Holiday Food** — Some/any #4; vocab: dessert, special, dish, sweet, spicy; speaking: “What special food do you make?”, “Do you try any new dish?”, “Do you like sweet or spicy more?”
- **A2-L98 Talking About Fear** — Can (permission/support) #6; vocab: scared, safe, help, stay, call; speaking: “What scares you?”, “Who do you call when scared?”, “Do you ask someone to stay with you?”
- **A2-L99 Trying a New Sport** — Present Continuous #10; vocab: try, lesson, coach, gear, safety; speaking: “What new sport will you try?”, “Do you need gear?”, “Who will teach you?”
- **A2-L100 Describing Your Home** — There is/are + place #3; vocab: room, window, door, kitchen, balcony; speaking: “How many rooms are there?”, “Is your kitchen big or small?”, “What is your favorite place at home?”

---

## Grammar Coverage Checkpoint (planned)
- Present Simple/questions: 8 (L41,48,59,63,70,79,85,95,99)
- Present Continuous: 6 (L14,25,31,71,74,91,99)
- Past Simple: 8 (L13,23,35,39,43,56,62,77,94)
- Going to (future): 5+ (L19,27,47,59,61,76,88,96)
- Can (ability/permission): 4+ (L16,36,53,57,75,92)
- Negatives/questions do/does/did: 5 (L11,22,29,52,82)
- Some/any/much/many: 4 (L26,40,66,80,97)
- Comparatives/superlatives: 4 (L15,21,24,37,44,69,84)
- Adverbs (frequency/manner): 4 (L28,38,49,55,73,81,98,90)
- Pronouns (object/possessive/reflexive): 4 (L20,48,65,85)
- Prepositions time/place/movement: 4 (L12,18,42,58,93)
- Linkers and/but/because/so: 4 (L17,50,86,100)

(*Flex lessons L91-L100 can adjust to hit exact counts if needed.)

