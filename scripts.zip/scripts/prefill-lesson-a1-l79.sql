-- =========================================
-- Pre-fill Database with Sample Lesson Data
-- A1-L79: Buying Tickets
-- =========================================

DELETE FROM grammar_sentences WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'A1-L79');
DELETE FROM vocabulary_items WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'A1-L79');
DELETE FROM lesson_activities WHERE lesson_id = 'A1-L79';
DELETE FROM lessons WHERE id = 'A1-L79';

INSERT INTO lessons (id, level, lesson_number, topic) VALUES
('A1-L79', 'A1', 79, 'Buying Tickets')
ON CONFLICT (id) DO UPDATE SET topic = EXCLUDED.topic;

DO $$
DECLARE
    lesson_id_var TEXT := 'A1-L79';
    activity_id_var UUID;
BEGIN
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'warm_up_speaking', 1, 'Tickets', 'Talk about buying tickets', '{"prompt": "Can I buy a ticket?"}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_intro', 2, 'Ticket Words', 'Learn ticket words', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'ticket', 'ตั๋ว', NULL),
    (activity_id_var, 'bus', 'รถบัส', NULL),
    (activity_id_var, 'train', 'รถไฟ', NULL),
    (activity_id_var, 'pay', 'จ่าย', NULL),
    (activity_id_var, 'seat', 'ที่นั่ง', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_matching_drag', 3, 'Match Ticket Words', 'Match ticket words', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'ticket', 'ตั๋ว', NULL),
    (activity_id_var, 'bus', 'รถบัส', NULL),
    (activity_id_var, 'train', 'รถไฟ', NULL),
    (activity_id_var, 'pay', 'จ่าย', NULL),
    (activity_id_var, 'seat', 'ที่นั่ง', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 4, 'Complete the Sentences 1', 'Fill with the correct word', '{"text": "I take the ___. I take the ___.", "blanks": [{"id": "blank1", "text": "bus", "options": ["bus", "train", "ticket", "seat"], "correctAnswer": "bus"}, {"id": "blank2", "text": "train", "options": ["train", "bus", "ticket", "seat"], "correctAnswer": "train"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 5, 'Complete the Sentences 2', 'Fill with the correct word', '{"text": "I buy a ___. I want this ___.", "blanks": [{"id": "blank1", "text": "ticket", "options": ["ticket", "seat", "train", "bus"], "correctAnswer": "ticket"}, {"id": "blank2", "text": "seat", "options": ["seat", "ticket", "bus", "train"], "correctAnswer": "seat"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_explanation', 6, 'Can (requests)', 'Ask to buy and pay', '{"rules": "Use can to ask politely.\n- Can I buy a ticket?\n- Can I pay here?\nUse this/that for seat.", "examples": ["Can I buy a ticket?", "Can I pay here?", "Is this seat free?", "Do you take the bus?", "Do you take the train?"]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 7, 'Build Sentences 1', 'Arrange words', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'Can I buy a ticket', 'Can I buy a ticket?', '["Can", "I", "buy", "a", "ticket?"]'::jsonb),
    (activity_id_var, 'Can I pay here', 'Can I pay here?', '["Can", "I", "pay", "here?"]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 8, 'Build Sentences 2', 'Arrange words', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'Is this seat free', 'Is this seat free?', '["Is", "this", "seat", "free?"]'::jsonb),
    (activity_id_var, 'Do you take the bus', 'Do you take the bus?', '["Do", "you", "take", "the", "bus?"]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'speaking_practice', 9, 'Talk About Tickets', 'Practice buying tickets', '{"prompts": ["Can I buy a ticket?", "Is this seat free?", "Do you take the bus?", "Can I pay here?", "Do you take the train?"]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (
      lesson_id,
      activity_type,
      activity_order,
      title,
      description,
      content
    ) VALUES (
      'A1-L79',
      'speaking_improvement',
      10,
      'Speaking Improvement',
      'Read the improved version of your speech',
      '{"type": "speaking_improvement", "similarityThreshold": 70}'::jsonb
    );
END $$;

