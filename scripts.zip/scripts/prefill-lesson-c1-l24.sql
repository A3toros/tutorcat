-- =========================================
-- Pre-fill Database with Sample Lesson Data
-- C1-L24: Impact of Algorithms on Information
-- =========================================
DELETE FROM lesson_activity_results WHERE lesson_id = 'C1-L24';
DELETE FROM user_progress WHERE lesson_id = 'C1-L24';
DELETE FROM lesson_history WHERE lesson_id = 'C1-L24';
DELETE FROM grammar_sentences WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'C1-L24');
DELETE FROM vocabulary_items WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'C1-L24');
DELETE FROM lesson_activities WHERE lesson_id = 'C1-L24';
DELETE FROM lessons WHERE id = 'C1-L24';

INSERT INTO lessons (id, level, lesson_number, topic) VALUES
('C1-L24', 'C1', 24, 'Impact of Algorithms on Information')
ON CONFLICT (id) DO UPDATE SET topic = EXCLUDED.topic;

DO $$
DECLARE
    lesson_id_var TEXT := 'C1-L24';
    activity_id_var UUID;
BEGIN
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'warm_up_speaking', 1, 'Algorithms and Information', 'Discuss algorithms and information', '{"prompt": "How have algorithms shaped what you see online?"}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_intro', 2, 'Algorithm Vocabulary', 'Learn vocabulary about algorithms', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'algorithm', 'อัลกอริทึม', NULL),
    (activity_id_var, 'filtering', 'การกรอง', NULL),
    (activity_id_var, 'recommendation', 'คำแนะนำ', NULL),
    (activity_id_var, 'personalization', 'การปรับแต่ง', NULL),
    (activity_id_var, 'echo', 'เสียงสะท้อน', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_matching_drag', 3, 'Match Algorithm Words', 'Match English words with Thai meanings', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'algorithm', 'อัลกอริทึม', NULL),
    (activity_id_var, 'filtering', 'การกรอง', NULL),
    (activity_id_var, 'recommendation', 'คำแนะนำ', NULL),
    (activity_id_var, 'personalization', 'การปรับแต่ง', NULL),
    (activity_id_var, 'echo', 'เสียงสะท้อน', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 4, 'Complete the Sentences 1', 'Fill with the correct word', '{"text": "The ___ controls content ___. ___ systems create ___.", "blanks": [{"id": "blank1", "text": "algorithm", "options": ["algorithm", "filtering", "recommendation", "personalization"], "correctAnswer": "algorithm"}, {"id": "blank2", "text": "filtering", "options": ["filtering", "algorithm", "recommendation", "echo"], "correctAnswer": "filtering"}, {"id": "blank3", "text": "Recommendation", "options": ["Recommendation", "Algorithm", "Filtering", "Personalization"], "correctAnswer": "Recommendation"}, {"id": "blank4", "text": "echo", "options": ["echo", "algorithm", "filtering", "personalization"], "correctAnswer": "echo"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 5, 'Complete the Sentences 2', 'Fill with the correct word', '{"text": "Content ___ shapes user experience. ___ creates filter bubbles.", "blanks": [{"id": "blank1", "text": "personalization", "options": ["personalization", "algorithm", "filtering", "recommendation"], "correctAnswer": "personalization"}, {"id": "blank2", "text": "Filtering", "options": ["Filtering", "Algorithm", "Recommendation", "Personalization"], "correctAnswer": "Filtering"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_explanation', 6, 'Advanced Perfect Aspect', 'Learn advanced perfect forms', '{"rules": "Advanced perfect aspect:\n- Present perfect: \"I have seen how algorithms work.\"\n- Past perfect: \"I had noticed changes before.\"\n- Future perfect: \"I will have adapted by then.\"\n- Perfect continuous: \"I have been influenced for years.\"\n\nUse for:\n- Completed actions with present relevance: \"I have noticed algorithm changes.\"\n- Past before past: \"I had seen this before algorithms changed.\"\n- Future completion: \"I will have adapted to algorithms by next year.\"", "examples": ["I have noticed how algorithms shape my feed.", "I had seen different content before algorithms changed.", "I will have adapted to new algorithms by next month.", "I have been influenced by recommendations for years.", "Having experienced algorithm changes, I understand their impact."]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 7, 'Build Sentences 1', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'I have noticed how algorithms shape my feed.', 'I have noticed how algorithms shape my feed.', '["I", "have", "noticed", "how", "algorithms", "shape", "my", "feed."]'::jsonb),
    (activity_id_var, 'I had seen different content before algorithms changed.', 'I had seen different content before algorithms changed.', '["I", "had", "seen", "different", "content", "before", "algorithms", "changed."]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 8, 'Build Sentences 2', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'I have been influenced by recommendations for years.', 'I have been influenced by recommendations for years.', '["I", "have", "been", "influenced", "by", "recommendations", "for", "years."]'::jsonb),
    (activity_id_var, 'Having experienced algorithm changes, I understand their impact.', 'Having experienced algorithm changes, I understand their impact.', '["Having", "experienced", "algorithm", "changes,", "I", "understand", "their", "impact."]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'speaking_practice', 9, 'Discuss Algorithms', 'Practice speaking about algorithms', '{"prompts": ["How have recommendations influenced your views?", "What role do algorithms play in daily life?", "How has your information diet changed?", "What risks come with algorithmic filtering?", "How can users stay informed despite algorithms?"]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (
      lesson_id,
      activity_type,
      activity_order,
      title,
      description,
      content
    ) VALUES (
      'C1-L24',
      'speaking_improvement',
      10,
      'Speaking Improvement',
      'Read the improved version of your speech',
      '{"type": "speaking_improvement", "similarityThreshold": 70}'::jsonb
    );
END $$;
