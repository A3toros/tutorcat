-- =========================================
-- Pre-fill Database with Sample Lesson Data
-- C1-L4: Academic Freedom and Its Limits
-- =========================================

DELETE FROM grammar_sentences WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'C1-L4');
DELETE FROM vocabulary_items WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'C1-L4');
DELETE FROM lesson_activities WHERE lesson_id = 'C1-L4';
DELETE FROM lessons WHERE id = 'C1-L4';

INSERT INTO lessons (id, level, lesson_number, topic) VALUES
('C1-L4', 'C1', 4, 'Academic Freedom and Its Limits')
ON CONFLICT (id) DO UPDATE SET topic = EXCLUDED.topic;

DO $$
DECLARE
    lesson_id_var TEXT := 'C1-L4';
    activity_id_var UUID;
BEGIN
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'warm_up_speaking', 1, 'Academic Freedom', 'Discuss academic freedom and limits', '{"prompt": "How confident are you that limits are necessary?"}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_intro', 2, 'Academic Freedom Vocabulary', 'Learn vocabulary about academic freedom', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'freedom', 'เสรีภาพ', NULL),
    (activity_id_var, 'restriction', 'ข้อจำกัด', NULL),
    (activity_id_var, 'expression', 'การแสดงออก', NULL),
    (activity_id_var, 'boundary', 'ขอบเขต', NULL),
    (activity_id_var, 'responsibility', 'ความรับผิดชอบ', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_matching_drag', 3, 'Match Academic Freedom Words', 'Match English words with Thai meanings', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'freedom', 'เสรีภาพ', NULL),
    (activity_id_var, 'restriction', 'ข้อจำกัด', NULL),
    (activity_id_var, 'expression', 'การแสดงออก', NULL),
    (activity_id_var, 'boundary', 'ขอบเขต', NULL),
    (activity_id_var, 'responsibility', 'ความรับผิดชอบ', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 4, 'Complete the Sentences 1', 'Fill with the correct word', '{"text": "Academic ___ allows open ___. However, some ___ protect students.", "blanks": [{"id": "blank1", "text": "freedom", "options": ["freedom", "restriction", "expression", "boundary"], "correctAnswer": "freedom"}, {"id": "blank2", "text": "expression", "options": ["expression", "freedom", "restriction", "responsibility"], "correctAnswer": "expression"}, {"id": "blank3", "text": "restrictions", "options": ["restrictions", "freedom", "expression", "boundary"], "correctAnswer": "restrictions"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 5, 'Complete the Sentences 2', 'Fill with the correct word', '{"text": "Clear ___ define acceptable behavior. Academic ___ requires ___.", "blanks": [{"id": "blank1", "text": "boundaries", "options": ["boundaries", "freedom", "restriction", "expression"], "correctAnswer": "boundaries"}, {"id": "blank2", "text": "freedom", "options": ["freedom", "restriction", "expression", "boundary"], "correctAnswer": "freedom"}, {"id": "blank3", "text": "responsibility", "options": ["responsibility", "freedom", "restriction", "boundary"], "correctAnswer": "responsibility"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_explanation', 6, 'Modals: Degrees of Certainty', 'Learn modals expressing degrees of certainty', '{"rules": "Modals for degrees of certainty:\n- \"must\" (high certainty): \"Limits must be necessary.\"\n- \"should\" (probable): \"Limits should help academic environments.\"\n- \"might/may\" (possible): \"Limits might harm freedom.\"\n- \"could\" (less certain): \"Limits could restrict expression.\"\n\nUse for:\n- Expressing confidence: \"I am certain that limits help.\"\n- Showing uncertainty: \"I am not sure if limits are needed.\"\n- Speculating: \"Limits might be necessary in some cases.\"", "examples": ["Limits must be necessary for academic safety.", "I should be certain that limits help academic environments.", "Limits might harm academic freedom if too strict.", "I could be wrong about the need for restrictions.", "You may be confident that boundaries protect students."]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 7, 'Build Sentences 1', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'Limits must be necessary for academic safety.', 'Limits must be necessary for academic safety.', '["Limits", "must", "be", "necessary", "for", "academic", "safety."]'::jsonb),
    (activity_id_var, 'I should be certain that limits help academic environments.', 'I should be certain that limits help academic environments.', '["I", "should", "be", "certain", "that", "limits", "help", "academic", "environments."]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 8, 'Build Sentences 2', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'Limits might harm academic freedom if too strict.', 'Limits might harm academic freedom if too strict.', '["Limits", "might", "harm", "academic", "freedom", "if", "too", "strict."]'::jsonb),
    (activity_id_var, 'You may be confident that boundaries protect students.', 'You may be confident that boundaries protect students.', '["You", "may", "be", "confident", "that", "boundaries", "protect", "students."]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'speaking_practice', 9, 'Discuss Academic Freedom', 'Practice speaking about academic freedom', '{"prompts": ["How certain are you that limits help academic environments?", "When might limits harm academic freedom?", "What limits should exist in academic settings?", "How should freedom and responsibility be balanced?", "When should academic expression be restricted?"]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (
      lesson_id,
      activity_type,
      activity_order,
      title,
      description,
      content
    ) VALUES (
      'C1-L4',
      'speaking_improvement',
      10,
      'Speaking Improvement',
      'Read the improved version of your speech',
      '{"type": "speaking_improvement", "similarityThreshold": 70}'::jsonb
    );
END $$;
