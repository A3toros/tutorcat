-- ===== LESSON A1-L49 =====

-- =========================================
-- Pre-fill Database with Sample Lesson Data
-- A1-L49: Pets
-- =========================================

DELETE FROM grammar_sentences WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'A1-L49');
DELETE FROM vocabulary_items WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'A1-L49');
DELETE FROM lesson_activities WHERE lesson_id = 'A1-L49';
DELETE FROM lessons WHERE id = 'A1-L49';

INSERT INTO lessons (id, level, lesson_number, topic) VALUES
('A1-L49', 'A1', 49, 'Pets')
ON CONFLICT (id) DO UPDATE SET topic = EXCLUDED.topic;

DO $$
DECLARE
    lesson_id_var TEXT := 'A1-L49';
    activity_id_var UUID;
BEGIN
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'warm_up_speaking', 1, 'Do you have pets?', 'Talk about pets', '{"prompt": "Do you have a dog?"}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_intro', 2, 'Pet Words', 'Learn pet words', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'cat', 'แมว', NULL),
    (activity_id_var, 'dog', 'สุนัข', NULL),
    (activity_id_var, 'fish', 'ปลา', NULL),
    (activity_id_var, 'bird', 'นก', NULL),
    (activity_id_var, 'hamster', 'แฮมสเตอร์', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_matching_drag', 3, 'Match Pet Words', 'Match pet words', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'cat', 'แมว', NULL),
    (activity_id_var, 'dog', 'สุนัข', NULL),
    (activity_id_var, 'fish', 'ปลา', NULL),
    (activity_id_var, 'bird', 'นก', NULL),
    (activity_id_var, 'hamster', 'แฮมสเตอร์', NULL);

    -- 4. Vocabulary Fill Blanks #1
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 4, 'Complete the Sentences 1', 'Fill in the blanks with correct words', '{"text": "I have a ___. She has a ___. We have a ___.", "blanks": [{"id": "blank1", "text": "cat", "options": ["cat", "dog", "fish", "bird"], "correctAnswer": "cat"}, {"id": "blank2", "text": "dog", "options": ["dog", "cat", "fish", "hamster"], "correctAnswer": "dog"}, {"id": "blank3", "text": "fish", "options": ["fish", "cat", "dog", "bird"], "correctAnswer": "fish"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    -- 5. Vocabulary Fill Blanks #2
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 5, 'Complete the Sentences 2', 'Fill in the blanks with correct words', '{"text": "They have a ___. I have a ___. She has a ___.", "blanks": [{"id": "blank1", "text": "bird", "options": ["bird", "cat", "dog", "fish"], "correctAnswer": "bird"}, {"id": "blank2", "text": "hamster", "options": ["hamster", "cat", "dog", "bird"], "correctAnswer": "hamster"}, {"id": "blank3", "text": "cat", "options": ["cat", "dog", "fish", "bird"], "correctAnswer": "cat"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    -- 6. Grammar Explanation
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_explanation', 6, 'Have Got / Has Got', 'Learn have/has got for possession', '{"rules": "Use have got/has got to talk about what you own:\n\n- I/You/We/They have got (I have got a cat)\n- He/She/It has got (She has got a dog)\n- Have got = have (informal)\n- Use a/an with singular pets", "examples": ["I have got a cat.", "She has got a dog.", "They have got fish.", "We have got a bird.", "He has got a hamster."]}'::jsonb)
    RETURNING id INTO activity_id_var;

    -- 7. Grammar Sentences #1
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 7, 'Build Sentences 1', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'I have got a cat', 'I have got a cat.', '["I", "have", "got", "a", "cat."]'::jsonb),
    (activity_id_var, 'She has got a dog', 'She has got a dog.', '["She", "has", "got", "a", "dog."]'::jsonb);

    -- 8. Grammar Sentences #2
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 8, 'Build Sentences 2', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'They have got fish', 'They have got fish.', '["They", "have", "got", "fish."]'::jsonb),
    (activity_id_var, 'We have got a bird', 'We have got a bird.', '["We", "have", "got", "a", "bird."]'::jsonb);

    -- 9. Speaking Practice
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'speaking_practice', 9, 'Talk About Pets', 'Practice talking about pets', '{"prompts": ["Do you have a pet?", "What animals do you like?", "Do you want a dog or cat?", "What is your favorite pet?", "Do you like cats or dogs?"]}'::jsonb)
    RETURNING id INTO activity_id_var;

    -- 10. Speaking Improvement
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'speaking_improvement', 10, 'Speaking Improvement', 'Read the improved version of your speech', '{"type": "speaking_improvement", "similarityThreshold": 70}'::jsonb)
    RETURNING id INTO activity_id_var;
END $$;