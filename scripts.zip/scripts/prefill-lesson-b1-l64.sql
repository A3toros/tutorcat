-- ===== LESSON B1-L64 =====

-- =========================================
-- Pre-fill Database with Sample Lesson Data
-- B1-L64: Technology Predictions
-- =========================================

DELETE FROM lesson_activity_results WHERE lesson_id = 'B1-L64';
DELETE FROM user_progress WHERE lesson_id = 'B1-L64';
DELETE FROM lesson_history WHERE lesson_id = 'B1-L64';
DELETE FROM grammar_sentences WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'B1-L64');
DELETE FROM vocabulary_items WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'B1-L64');
DELETE FROM lesson_activities WHERE lesson_id = 'B1-L64';
DELETE FROM lessons WHERE id = 'B1-L64';

INSERT INTO lessons (id, level, lesson_number, topic) VALUES
('B1-L64', 'B1', 64, 'Technology Predictions')
ON CONFLICT (id) DO UPDATE SET topic = EXCLUDED.topic;

DO $$
DECLARE
    lesson_id_var TEXT := 'B1-L64';
    activity_id_var UUID;
BEGIN
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'warm_up_speaking', 1, 'Future Technology', 'Talk about how technology will change life', '{"prompt": "What tech do you think will change your daily life?"}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_intro', 2, 'Tech Future Words', 'Learn words related to technology predictions', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'predict', 'ทำนาย', NULL),
    (activity_id_var, 'expect', 'คาดหวัง', NULL),
    (activity_id_var, 'advance', 'ก้าวหน้า', NULL),
    (activity_id_var, 'replace', 'แทนที่', NULL),
    (activity_id_var, 'automate', 'ทำให้เป็นอัตโนมัติ', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_matching_drag', 3, 'Match Tech Words', 'Match technology prediction words', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'predict', 'ทำนาย', NULL),
    (activity_id_var, 'expect', 'คาดหวัง', NULL),
    (activity_id_var, 'advance', 'ก้าวหน้า', NULL),
    (activity_id_var, 'replace', 'แทนที่', NULL),
    (activity_id_var, 'automate', 'ทำให้เป็นอัตโนมัติ', NULL);

    -- 4. Vocabulary Fill Blanks #1
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 4, 'Complete the Sentences 1', 'Fill in the blanks with correct words', '{"text": "Experts ___ that AI will change work. We ___ technology to ___.", "blanks": [{"id": "blank1", "text": "predict", "options": ["predict", "expect", "advance", "replace"], "correctAnswer": "predict"}, {"id": "blank2", "text": "expect", "options": ["expect", "predict", "advance", "automate"], "correctAnswer": "expect"}, {"id": "blank3", "text": "advance", "options": ["advance", "predict", "expect", "replace"], "correctAnswer": "advance"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    -- 5. Vocabulary Fill Blanks #2
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 5, 'Complete the Sentences 2', 'Fill in the blanks with correct words', '{"text": "Robots will ___ some jobs. Machines will ___ many tasks. Technology will ___.", "blanks": [{"id": "blank1", "text": "replace", "options": ["replace", "predict", "expect", "advance"], "correctAnswer": "replace"}, {"id": "blank2", "text": "automate", "options": ["automate", "replace", "predict", "advance"], "correctAnswer": "automate"}, {"id": "blank3", "text": "advance", "options": ["advance", "replace", "automate", "predict"], "correctAnswer": "advance"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    -- 6. Grammar Explanation
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_explanation', 6, 'Will vs Going to for Predictions', 'Learn future forms for predictions', '{"rules": "Use will and going to for future predictions:\n\n- Will for general predictions (Technology will change)\n- Going to for plans/intentions (I am going to learn)\n- Will + base verb (will change, will replace)\n- Be + going to + base verb (am going to learn)\n- Both can be used for predictions", "examples": ["Technology will change everything.", "I am going to learn about AI.", "Robots will replace some jobs.", "We are going to see big changes.", "AI will automate many tasks."]}'::jsonb)
    RETURNING id INTO activity_id_var;

    -- 7. Grammar Sentences #1
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 7, 'Build Sentences 1', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'Technology will change everything', 'Technology will change everything.', '["Technology", "will", "change", "everything."]'::jsonb),
    (activity_id_var, 'I am going to learn about AI', 'I am going to learn about AI.', '["I", "am", "going", "to", "learn", "about", "AI."]'::jsonb);

    -- 8. Grammar Sentences #2
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 8, 'Build Sentences 2', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'Robots will replace some jobs', 'Robots will replace some jobs.', '["Robots", "will", "replace", "some", "jobs."]'::jsonb),
    (activity_id_var, 'We are going to see big changes', 'We are going to see big changes.', '["We", "are", "going", "to", "see", "big", "changes."]'::jsonb);

    -- 9. Speaking Practice
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'speaking_practice', 9, 'Talk About Technology', 'Practice talking about computers and phones', '{"prompts": ["What do you use your phone for?", "Do you play computer games?", "Who taught you to use the computer?", "How will technology change in the future?", "What technology do you want to learn about?"]}'::jsonb)
    RETURNING id INTO activity_id_var;

    -- 10. Speaking Improvement
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'speaking_improvement', 10, 'Speaking Improvement', 'Read the improved version of your speech', '{"type": "speaking_improvement", "similarityThreshold": 70}'::jsonb)
    RETURNING id INTO activity_id_var;
END $$;