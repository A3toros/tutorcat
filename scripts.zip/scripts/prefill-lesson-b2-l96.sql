-- =========================================
-- Pre-fill Database with Sample Lesson Data
-- B2-L96: Belonging to a group
-- =========================================

DELETE FROM grammar_sentences WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'B2-L96');
DELETE FROM vocabulary_items WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'B2-L96');
DELETE FROM lesson_activities WHERE lesson_id = 'B2-L96';
DELETE FROM lessons WHERE id = 'B2-L96';

INSERT INTO lessons (id, level, lesson_number, topic) VALUES
('B2-L96', 'B2', 96, 'Belonging to a group')
ON CONFLICT (id) DO UPDATE SET topic = EXCLUDED.topic;

DO $$
DECLARE
    lesson_id_var TEXT := 'B2-L96';
    activity_id_var UUID;
BEGIN
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'warm_up_speaking', 1, 'Group Membership', 'Talk about inclusion', '{"prompt": "If you hadn’t joined, what would you miss now, and how do you welcome others?"}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_intro', 2, 'Belonging Words', 'Key words for inclusion', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'include', 'รวม/ทำให้มีส่วนร่วม', NULL),
    (activity_id_var, 'isolate', 'แยก/โดดเดี่ยว', NULL),
    (activity_id_var, 'welcome', 'ต้อนรับ', NULL),
    (activity_id_var, 'cohesion', 'ความเหนียวแน่น', NULL),
    (activity_id_var, 'belong', 'เป็นส่วนหนึ่ง', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_matching_drag', 3, 'Match Belonging Words', 'Match words with meanings', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'include', 'รวม/ทำให้มีส่วนร่วม', NULL),
    (activity_id_var, 'isolate', 'แยก/โดดเดี่ยว', NULL),
    (activity_id_var, 'welcome', 'ต้อนรับ', NULL),
    (activity_id_var, 'cohesion', 'ความเหนียวแน่น', NULL),
    (activity_id_var, 'belong', 'เป็นส่วนหนึ่ง', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 4, 'Complete the Sentences 1', 'Fill with the correct word', '{"text": "We ___ new members. No one should feel ___.", "blanks": [{"id": "blank1", "text": "welcome", "options": ["welcome", "include", "cohesion", "isolate"], "correctAnswer": "welcome"}, {"id": "blank2", "text": "isolated", "options": ["isolated", "belong", "cohesion", "welcome"], "correctAnswer": "isolated"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 5, 'Complete the Sentences 2', 'Fill with the correct word', '{"text": "Strong ___ helps people ___.", "blanks": [{"id": "blank1", "text": "cohesion", "options": ["cohesion", "include", "welcome", "isolate"], "correctAnswer": "cohesion"}, {"id": "blank2", "text": "belong", "options": ["belong", "include", "cohesion", "welcome"], "correctAnswer": "belong"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_explanation', 6, 'Third Conditional', 'Reflect on past joining choices', '{"rules": "Use if + past perfect + would have + past participle for unreal past; could/might have for less certain.\\n- If I hadn’t joined, I would have missed this group.", "examples": ["If I hadn’t joined, I would have missed these friends.", "If we had welcomed earlier, we might have built cohesion faster.", "If she had felt included, she would have stayed.", "If they had invited you sooner, you could have belonged earlier.", "If the team had isolated no one, we would have kept everyone."]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 7, 'Build Sentences 1', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'If I hadn’t joined, I would have missed these friends', 'If I hadn’t joined, I would have missed these friends.', '["If", "I", "hadn’t", "joined,", "I", "would", "have", "missed", "these", "friends."]'::jsonb),
    (activity_id_var, 'If we had welcomed earlier, we might have built cohesion faster', 'If we had welcomed earlier, we might have built cohesion faster.', '["If", "we", "had", "welcomed", "earlier,", "we", "might", "have", "built", "cohesion", "faster."]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 8, 'Build Sentences 2', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'If she had felt included, she would have stayed', 'If she had felt included, she would have stayed.', '["If", "she", "had", "felt", "included,", "she", "would", "have", "stayed."]'::jsonb),
    (activity_id_var, 'If they had invited you sooner, you could have belonged earlier', 'If they had invited you sooner, you could have belonged earlier.', '["If", "they", "had", "invited", "you", "sooner,", "you", "could", "have", "belonged", "earlier."]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'speaking_practice', 9, 'Talk About Belonging', 'Practice third conditional', '{"prompts": ["If you hadn’t joined, what would you miss now?", "How do you welcome new people so they belong?", "What would have helped you feel included sooner?"]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (
      lesson_id,
      activity_type,
      activity_order,
      title,
      description,
      content
    ) VALUES (
      'B2-L96',
      'speaking_improvement',
      10,
      'Speaking Improvement',
      'Read the improved version of your speech',
      '{"type": "speaking_improvement", "similarityThreshold": 70}'::jsonb
    );
END $$;


