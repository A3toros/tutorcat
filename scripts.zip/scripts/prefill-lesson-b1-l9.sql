-- =========================================
-- Pre-fill Database with Sample Lesson Data
-- B1-L9: Goals & Future Plans
-- =========================================

-- Clear existing sample data for B1-L9 (optional - comment out if you want to keep existing data)
DELETE FROM grammar_sentences WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'B1-L9');
DELETE FROM vocabulary_items WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'B1-L9');
DELETE FROM lesson_activities WHERE lesson_id = 'B1-L9';
DELETE FROM lessons WHERE id = 'B1-L9';

INSERT INTO lessons (id, level, lesson_number, topic) VALUES
('B1-L9', 'B1', 9, 'Goals & Future Plans')
ON CONFLICT (id) DO UPDATE SET topic = EXCLUDED.topic;

DO $$
DECLARE
    lesson_id_var TEXT := 'B1-L9';
    activity_id_var UUID;
BEGIN
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content) VALUES (lesson_id_var, 'warm_up_speaking', 1, 'Future Goals', 'Talk about goals', '{"prompt": "What are your goals for the next five years?"}'::jsonb) RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content) VALUES (lesson_id_var, 'vocabulary_intro', 2, 'Goal Words', 'Learn goal vocabulary', '{}'::jsonb) RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'ambition', 'ความทะเยอทะยาน', NULL),
    (activity_id_var, 'objective', 'เป้าหมาย', NULL),
    (activity_id_var, 'strategy', 'กลยุทธ์', NULL),
    (activity_id_var, 'progress', 'ความก้าวหน้า', NULL),
    (activity_id_var, 'milestone', 'จุดสำคัญ', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content) VALUES (lesson_id_var, 'vocabulary_matching_drag', 3, 'Match Goal Words', 'Match English words with Thai meanings', '{}'::jsonb) RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'ambition', 'ความทะเยอทะยาน', NULL),
    (activity_id_var, 'objective', 'เป้าหมาย', NULL),
    (activity_id_var, 'strategy', 'กลยุทธ์', NULL),
    (activity_id_var, 'progress', 'ความก้าวหน้า', NULL),
    (activity_id_var, 'milestone', 'จุดสำคัญ', NULL);

    -- 4. Vocabulary Fill Blanks #1 (4 words: ambition, objective, strategy, progress - milestone left out)
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content) VALUES (lesson_id_var, 'vocabulary_fill_blanks', 4, 'Complete the Sentences 1', 'Fill in the blanks with correct words', '{"text": "I have a big ___. My ___ is clear. I have a ___. I am making ___.", "blanks": [{"id": "blank1", "text": "ambition", "options": ["ambition", "objective", "strategy", "progress"], "correctAnswer": "ambition"}, {"id": "blank2", "text": "objective", "options": ["ambition", "objective", "strategy", "progress"], "correctAnswer": "objective"}, {"id": "blank3", "text": "strategy", "options": ["ambition", "objective", "strategy", "progress"], "correctAnswer": "strategy"}, {"id": "blank4", "text": "progress", "options": ["ambition", "objective", "strategy", "progress"], "correctAnswer": "progress"}]}'::jsonb) RETURNING id INTO activity_id_var;

    -- 4. Vocabulary Fill Blanks #2 (4 words: ambition, objective, strategy, milestone - progress left out)
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content) VALUES (lesson_id_var, 'vocabulary_fill_blanks', 5, 'Complete the Sentences 2', 'Fill in the blanks with correct words', '{"text": "My ___ is strong. The ___ is important. My ___ works. I reached a ___.", "blanks": [{"id": "blank1", "text": "ambition", "options": ["ambition", "objective", "strategy", "milestone"], "correctAnswer": "ambition"}, {"id": "blank2", "text": "objective", "options": ["ambition", "objective", "strategy", "milestone"], "correctAnswer": "objective"}, {"id": "blank3", "text": "strategy", "options": ["ambition", "objective", "strategy", "milestone"], "correctAnswer": "strategy"}, {"id": "blank4", "text": "milestone", "options": ["ambition", "objective", "strategy", "milestone"], "correctAnswer": "milestone"}]}'::jsonb) RETURNING id INTO activity_id_var;

    -- 4. Grammar Explanation (5 examples - CEFR B1: Future forms, conditionals)
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content) VALUES (lesson_id_var, 'grammar_explanation', 6, 'Future Forms & Conditionals', 'Learn to express future plans and goals', '{"rules": "Use different future forms for plans:\n\n- I am going to + verb (I am going to study)\n- I will + verb (I will work hard)\n- I plan to + verb (I plan to travel)\n- First conditional: If + present, will + verb (If I study hard, I will succeed)\n- Use ''hope to'' and ''intend to'' for goals", "examples": ["I am going to start a new course next year.", "If I work hard, I will achieve my goals.", "I plan to travel to Europe.", "I hope to get a promotion.", "I intend to learn a new language."]}'::jsonb) RETURNING id INTO activity_id_var;

    -- 4. Grammar Sentences #1
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content) VALUES (lesson_id_var, 'grammar_sentences', 7, 'Build Sentences 1', 'Arrange words to make sentences', '{}'::jsonb) RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'I am going to start a new course next year', 'I am going to start a new course next year', '["I", "am", "going", "to", "start", "a", "new", "course", "next", "year"]'::jsonb),
    (activity_id_var, 'If I work hard I will achieve my goals', 'If I work hard, I will achieve my goals', '["If", "I", "work", "hard,", "I", "will", "achieve", "my", "goals"]'::jsonb);
    -- 4. Grammar Sentences #2
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content) VALUES (lesson_id_var, 'grammar_sentences', 8, 'Build Sentences 2', 'Arrange words to make sentences', '{}'::jsonb) RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'I plan to travel to Europe', 'I plan to travel to Europe', '["I", "plan", "to", "travel", "to", "Europe"]'::jsonb),
    (activity_id_var, 'I hope to get a promotion', 'I hope to get a promotion', '["I", "hope", "to", "get", "a", "promotion"]'::jsonb);
    -- 4. Speaking Practice (5 prompts - CEFR B1: Goals and future plans)
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content) VALUES (lesson_id_var, 'speaking_practice', 9, 'Talk About Goals', 'Practice talking about future plans', '{"prompts": ["What are your goals for the next five years?", "What do you plan to achieve this year?", "What would you do if you had more time?", "How do you plan to reach your goals?", "What is your biggest ambition?"]}'::jsonb) RETURNING id INTO activity_id_var;

END $$;
INSERT INTO lesson_activities (
  lesson_id,
  activity_type,
  activity_order,
  title,
  description,
  content
) VALUES (
  'B1-L9',
  'speaking_improvement',
  10,
  'Speaking Improvement',
  'Read the improved version of your speech',
  '{"type": "speaking_improvement", "similarityThreshold": 70}'::jsonb
);