-- =========================================
-- Pre-fill Database with Sample Lesson Data
-- A1-L60: Work Time (morning/afternoon)
-- =========================================

DELETE FROM grammar_sentences WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'A1-L60');
DELETE FROM vocabulary_items WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'A1-L60');
DELETE FROM lesson_activities WHERE lesson_id = 'A1-L60';
DELETE FROM lessons WHERE id = 'A1-L60';

INSERT INTO lessons (id, level, lesson_number, topic) VALUES
('A1-L60', 'A1', 60, 'Work Time (morning/afternoon)')
ON CONFLICT (id) DO UPDATE SET topic = EXCLUDED.topic;

DO $$
DECLARE
    lesson_id_var TEXT := 'A1-L60';
    activity_id_var UUID;
BEGIN
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'warm_up_speaking', 1, 'Work Time', 'Talk about when you work', '{"prompt": "Do you work in the morning?"}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_intro', 2, 'Time Words', 'Learn work time words', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'morning', 'ตอนเช้า', NULL),
    (activity_id_var, 'afternoon', 'ตอนบ่าย', NULL),
    (activity_id_var, 'night', 'ตอนกลางคืน', NULL),
    (activity_id_var, 'early', 'เช้า/เร็ว', NULL),
    (activity_id_var, 'late', 'สาย/ดึก', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_matching_drag', 3, 'Match Time Words', 'Match time words', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'morning', 'ตอนเช้า', NULL),
    (activity_id_var, 'afternoon', 'ตอนบ่าย', NULL),
    (activity_id_var, 'night', 'ตอนกลางคืน', NULL),
    (activity_id_var, 'early', 'เช้า/เร็ว', NULL),
    (activity_id_var, 'late', 'สาย/ดึก', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 4, 'Complete the Sentences 1', 'Fill with the correct word', '{"text": "I work in the ___. I wake up ___.", "blanks": [{"id": "blank1", "text": "morning", "options": ["morning", "afternoon", "night", "late"], "correctAnswer": "morning"}, {"id": "blank2", "text": "early", "options": ["early", "late", "night", "afternoon"], "correctAnswer": "early"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 5, 'Complete the Sentences 2', 'Fill with the correct word', '{"text": "She works at ___. He works at ___.", "blanks": [{"id": "blank1", "text": "night", "options": ["night", "morning", "early", "late"], "correctAnswer": "night"}, {"id": "blank2", "text": "afternoon", "options": ["afternoon", "night", "morning", "late"], "correctAnswer": "afternoon"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_explanation', 6, 'Time Words + Be', 'Use be with time words', '{"rules": "Use be with time words.\n- I am early. I am late.\nAsk: Are you early?", "examples": ["I am early today.", "I am late this morning.", "She is at work in the afternoon.", "Are you early?", "Are you at work at night?"]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 7, 'Build Sentences 1', 'Arrange words', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'I am early today', 'I am early today.', '["I", "am", "early", "today."]'::jsonb),
    (activity_id_var, 'I am late this morning', 'I am late this morning.', '["I", "am", "late", "this", "morning."]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 8, 'Build Sentences 2', 'Arrange words', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'Are you early', 'Are you early?', '["Are", "you", "early?"]'::jsonb),
    (activity_id_var, 'Are you at work at night', 'Are you at work at night?', '["Are", "you", "at", "work", "at", "night?"]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'speaking_practice', 9, 'Talk About Work Time', 'Practice time words', '{"prompts": ["Do you work in the morning?", "Do you work in the afternoon?", "Are you early?", "Are you late?", "Do you work at night?"]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (
      lesson_id,
      activity_type,
      activity_order,
      title,
      description,
      content
    ) VALUES (
      'A1-L60',
      'speaking_improvement',
      10,
      'Speaking Improvement',
      'Read the improved version of your speech',
      '{"type": "speaking_improvement", "similarityThreshold": 70}'::jsonb
    );
END $$;

