-- =========================================
-- Pre-fill Database with Sample Lesson Data
-- C1-L2: Role of Education in Shaping Identity
-- =========================================

DELETE FROM grammar_sentences WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'C1-L2');
DELETE FROM vocabulary_items WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'C1-L2');
DELETE FROM lesson_activities WHERE lesson_id = 'C1-L2';
DELETE FROM lessons WHERE id = 'C1-L2';

INSERT INTO lessons (id, level, lesson_number, topic) VALUES
('C1-L2', 'C1', 2, 'Role of Education in Shaping Identity')
ON CONFLICT (id) DO UPDATE SET topic = EXCLUDED.topic;

DO $$
DECLARE
    lesson_id_var TEXT := 'C1-L2';
    activity_id_var UUID;
BEGIN
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'warm_up_speaking', 1, 'Education and Identity', 'Discuss how education shapes identity', '{"prompt": "How has education shaped who you are?"}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_intro', 2, 'Identity Vocabulary', 'Learn vocabulary about identity and education', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'identity', 'ตัวตน', NULL),
    (activity_id_var, 'formation', 'การก่อตัว', NULL),
    (activity_id_var, 'influence', 'อิทธิพล', NULL),
    (activity_id_var, 'perspective', 'มุมมอง', NULL),
    (activity_id_var, 'development', 'การพัฒนา', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_matching_drag', 3, 'Match Identity Words', 'Match English words with Thai meanings', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'identity', 'ตัวตน', NULL),
    (activity_id_var, 'formation', 'การก่อตัว', NULL),
    (activity_id_var, 'influence', 'อิทธิพล', NULL),
    (activity_id_var, 'perspective', 'มุมมอง', NULL),
    (activity_id_var, 'development', 'การพัฒนา', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 4, 'Complete the Sentences 1', 'Fill with the correct word', '{"text": "Education plays a key role in ___ ___. The ___ of teachers shapes student ___.", "blanks": [{"id": "blank1", "text": "identity", "options": ["identity", "formation", "influence", "perspective"], "correctAnswer": "identity"}, {"id": "blank2", "text": "formation", "options": ["formation", "identity", "influence", "development"], "correctAnswer": "formation"}, {"id": "blank3", "text": "influence", "options": ["influence", "identity", "formation", "perspective"], "correctAnswer": "influence"}, {"id": "blank4", "text": "development", "options": ["development", "identity", "formation", "influence"], "correctAnswer": "development"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 5, 'Complete the Sentences 2', 'Fill with the correct word', '{"text": "Different ___ broaden understanding. Personal ___ continues throughout life.", "blanks": [{"id": "blank1", "text": "perspectives", "options": ["perspectives", "identities", "influences", "formations"], "correctAnswer": "perspectives"}, {"id": "blank2", "text": "development", "options": ["development", "identity", "formation", "influence"], "correctAnswer": "development"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_explanation', 6, 'Nominal Clauses', 'Learn about nominal clauses', '{"rules": "Nominal clauses function as nouns:\n- Subject: \"What education teaches shapes identity.\"\n- Object: \"I believe that education influences development.\"\n- Complement: \"The question is how education shapes us.\"\n\nTypes:\n- That-clauses: \"I think that education matters.\"\n- Wh-clauses: \"What you learn determines your perspective.\"\n- Whether/if: \"The issue is whether education changes identity.\"\n\nUse for:\n- Expressing opinions: \"What I think is that education shapes identity.\"\n- Asking questions: \"How does education influence development?\"\n- Making statements: \"That education matters is clear.\"", "examples": ["What education teaches shapes personal identity.", "I believe that education influences development.", "The question is how education shapes perspective.", "Whether education changes identity remains debated.", "That education matters is widely accepted."]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 7, 'Build Sentences 1', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'What education teaches shapes personal identity.', 'What education teaches shapes personal identity.', '["What", "education", "teaches", "shapes", "personal", "identity."]'::jsonb),
    (activity_id_var, 'I believe that education influences development.', 'I believe that education influences development.', '["I", "believe", "that", "education", "influences", "development."]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 8, 'Build Sentences 2', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'The question is how education shapes perspective.', 'The question is how education shapes perspective.', '["The", "question", "is", "how", "education", "shapes", "perspective."]'::jsonb),
    (activity_id_var, 'Whether education changes identity remains uncertain.', 'Whether education changes identity remains uncertain.', '["Whether", "education", "changes", "identity", "remains", "uncertain."]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'speaking_practice', 9, 'Discuss Education and Identity', 'Practice speaking about education shaping identity', '{"prompts": ["How has education shaped your identity?", "What would change if you had a different educational background?", "In what ways does education influence personal development?", "What role does education play in shaping identity?", "How do school experiences affect values and beliefs?"]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (
      lesson_id,
      activity_type,
      activity_order,
      title,
      description,
      content
    ) VALUES (
      'C1-L2',
      'speaking_improvement',
      10,
      'Speaking Improvement',
      'Read the improved version of your speech',
      '{"type": "speaking_improvement", "similarityThreshold": 70}'::jsonb
    );
END $$;
