-- =========================================
-- Pre-fill Database with Sample Lesson Data
-- A1-L42: Furniture
-- =========================================

DELETE FROM grammar_sentences WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'A1-L42');
DELETE FROM vocabulary_items WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'A1-L42');
DELETE FROM lesson_activities WHERE lesson_id = 'A1-L42';
DELETE FROM lessons WHERE id = 'A1-L42';

INSERT INTO lessons (id, level, lesson_number, topic) VALUES
('A1-L42', 'A1', 42, 'Furniture')
ON CONFLICT (id) DO UPDATE SET topic = EXCLUDED.topic;

DO $$
DECLARE
    lesson_id_var TEXT := 'A1-L42';
    activity_id_var UUID;
BEGIN
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'warm_up_speaking', 1, 'Home Furniture', 'Talk about furniture', '{"prompt": "Is there a sofa?"}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_intro', 2, 'Furniture Words', 'Learn furniture words', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'table', 'โต๊ะ', NULL),
    (activity_id_var, 'chair', 'เก้าอี้', NULL),
    (activity_id_var, 'sofa', 'โซฟา', NULL),
    (activity_id_var, 'bed', 'เตียง', NULL),
    (activity_id_var, 'shelf', 'ชั้นวางของ', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_matching_drag', 3, 'Match Furniture Words', 'Match furniture words', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'table', 'โต๊ะ', NULL),
    (activity_id_var, 'chair', 'เก้าอี้', NULL),
    (activity_id_var, 'sofa', 'โซฟา', NULL),
    (activity_id_var, 'bed', 'เตียง', NULL),
    (activity_id_var, 'shelf', 'ชั้นวางของ', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 4, 'Complete the Sentences 1', 'Fill with the correct word', '{"text": "There is a ___. There is a ___.", "blanks": [{"id": "blank1", "text": "sofa", "options": ["sofa", "table", "bed", "shelf"], "correctAnswer": "sofa"}, {"id": "blank2", "text": "chair", "options": ["chair", "table", "bed", "sofa"], "correctAnswer": "chair"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 5, 'Complete the Sentences 2', 'Fill with the correct word', '{"text": "There is a ___. The ___ is next to it.", "blanks": [{"id": "blank1", "text": "table", "options": ["table", "bed", "sofa", "chair"], "correctAnswer": "table"}, {"id": "blank2", "text": "shelf", "options": ["shelf", "bed", "chair", "table"], "correctAnswer": "shelf"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_explanation', 6, 'There is / There are', 'Describe furniture in a room', '{"rules": "Use there is for one; there are for many.\n- There is a sofa.\n- There are two chairs.\nAsk: Is there a bed?", "examples": ["There is a sofa.", "There is a table.", "There are two chairs.", "Is there a bed?", "Are there shelves here?"]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 7, 'Build Sentences 1', 'Arrange words', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'There is a sofa', 'There is a sofa.', '["There", "is", "a", "sofa."]'::jsonb),
    (activity_id_var, 'There are two chairs', 'There are two chairs.', '["There", "are", "two", "chairs."]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 8, 'Build Sentences 2', 'Arrange words', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'Is there a bed', 'Is there a bed?', '["Is", "there", "a", "bed?"]'::jsonb),
    (activity_id_var, 'Are there shelves here', 'Are there shelves here?', '["Are", "there", "shelves", "here?"]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'speaking_practice', 9, 'Talk About Furniture', 'Practice there is/are', '{"prompts": ["Is there a sofa?", "How many chairs?", "Is there a bed?", "Is the shelf next to the table?", "Do you have a table?"]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (
      lesson_id,
      activity_type,
      activity_order,
      title,
      description,
      content
    ) VALUES (
      'A1-L42',
      'speaking_improvement',
      10,
      'Speaking Improvement',
      'Read the improved version of your speech',
      '{"type": "speaking_improvement", "similarityThreshold": 70}'::jsonb
    );
END $$;

