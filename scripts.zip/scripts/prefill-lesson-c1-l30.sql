-- =========================================
-- Pre-fill Database with Sample Lesson Data
-- C1-L30: Media Ethics
-- =========================================
DELETE FROM lesson_activity_results WHERE lesson_id = 'C1-L30';
DELETE FROM user_progress WHERE lesson_id = 'C1-L30';
DELETE FROM lesson_history WHERE lesson_id = 'C1-L30';
DELETE FROM grammar_sentences WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'C1-L30');
DELETE FROM vocabulary_items WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'C1-L30');
DELETE FROM lesson_activities WHERE lesson_id = 'C1-L30';
DELETE FROM lessons WHERE id = 'C1-L30';

INSERT INTO lessons (id, level, lesson_number, topic) VALUES
('C1-L30', 'C1', 30, 'Media Ethics')
ON CONFLICT (id) DO UPDATE SET topic = EXCLUDED.topic;

DO $$
DECLARE
    lesson_id_var TEXT := 'C1-L30';
    activity_id_var UUID;
BEGIN
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'warm_up_speaking', 1, 'Media Ethics', 'Discuss media ethics', '{"prompt": "Where should media draw ethical boundaries?"}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_intro', 2, 'Media Ethics Vocabulary', 'Learn vocabulary about media ethics', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'ethics', 'จริยธรรม', NULL),
    (activity_id_var, 'boundary', 'ขอบเขต', NULL),
    (activity_id_var, 'violation', 'การละเมิด', NULL),
    (activity_id_var, 'reporting', 'การรายงาน', NULL),
    (activity_id_var, 'enforcement', 'การบังคับใช้', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_matching_drag', 3, 'Match Media Ethics Words', 'Match English words with Thai meanings', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'ethics', 'จริยธรรม', NULL),
    (activity_id_var, 'boundary', 'ขอบเขต', NULL),
    (activity_id_var, 'violation', 'การละเมิด', NULL),
    (activity_id_var, 'reporting', 'การรายงาน', NULL),
    (activity_id_var, 'enforcement', 'การบังคับใช้', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 4, 'Complete the Sentences 1', 'Fill with the correct word', '{"text": "Media ___ requires clear ___. Ethical ___ prevents ___.", "blanks": [{"id": "blank1", "text": "ethics", "options": ["ethics", "boundary", "violation", "reporting"], "correctAnswer": "ethics"}, {"id": "blank2", "text": "boundaries", "options": ["boundaries", "ethics", "violation", "enforcement"], "correctAnswer": "boundaries"}, {"id": "blank3", "text": "reporting", "options": ["reporting", "ethics", "boundary", "violation"], "correctAnswer": "reporting"}, {"id": "blank4", "text": "violations", "options": ["violations", "ethics", "boundary", "reporting"], "correctAnswer": "violations"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 5, 'Complete the Sentences 2', 'Fill with the correct word', '{"text": "Ethical ___ ensures accuracy. ___ of standards protects integrity.", "blanks": [{"id": "blank1", "text": "reporting", "options": ["reporting", "ethics", "boundary", "violation"], "correctAnswer": "reporting"}, {"id": "blank2", "text": "Enforcement", "options": ["Enforcement", "Ethics", "Boundary", "Violation"], "correctAnswer": "Enforcement"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_explanation', 6, 'Articles: Abstract Reference', 'Learn articles with abstract nouns', '{"rules": "Articles with abstract nouns:\n- Use \"the\" when referring to a specific abstract concept: \"the ethics of media\"\n- Omit article for general abstract concepts: \"ethics is important\"\n- Use \"a/an\" when classifying: \"an ethical violation\"\n\nStylistic use:\n- \"The\" can emphasize importance: \"the boundary of ethics\"\n- Zero article for broad concepts: \"media requires ethics\"\n\nUse for:\n- General statements: \"Ethics guides media practice.\"\n- Specific reference: \"The ethics of journalism are complex.\"\n- Classification: \"A violation occurred.\"", "examples": ["The ethics of media are complex.", "Ethics is fundamental to journalism.", "A violation of ethical standards occurred.", "The boundary of ethics must be respected.", "Media requires ethics from all practitioners."]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 7, 'Build Sentences 1', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'The ethics of media are complex.', 'The ethics of media are complex.', '["The", "ethics", "of", "media", "are", "complex."]'::jsonb),
    (activity_id_var, 'Ethics is fundamental to journalism.', 'Ethics is fundamental to journalism.', '["Ethics", "is", "fundamental", "to", "journalism."]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 8, 'Build Sentences 2', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'A violation of ethical standards occurred.', 'A violation of ethical standards occurred.', '["A", "violation", "of", "ethical", "standards", "occurred."]'::jsonb),
    (activity_id_var, 'The boundary of ethics must be respected.', 'The boundary of ethics must be respected.', '["The", "boundary", "of", "ethics", "must", "be", "respected."]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'speaking_practice', 9, 'Discuss Media Ethics', 'Practice speaking about media ethics', '{"prompts": ["What does media ethics mean to you?", "What actions cross ethical lines?", "How do you judge ethical reporting?", "What violations worry you most?", "How can ethical standards be enforced?"]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (
      lesson_id,
      activity_type,
      activity_order,
      title,
      description,
      content
    ) VALUES (
      'C1-L30',
      'speaking_improvement',
      10,
      'Speaking Improvement',
      'Read the improved version of your speech',
      '{"type": "speaking_improvement", "similarityThreshold": 70}'::jsonb
    );
END $$;
