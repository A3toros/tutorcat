-- =========================================
-- Pre-fill Database with Sample Lesson Data
-- C1-L34: Language and Cultural Power
-- =========================================
DELETE FROM lesson_activity_results WHERE lesson_id = 'C1-L34';
DELETE FROM user_progress WHERE lesson_id = 'C1-L34';
DELETE FROM lesson_history WHERE lesson_id = 'C1-L34';
DELETE FROM grammar_sentences WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'C1-L34');
DELETE FROM vocabulary_items WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'C1-L34');
DELETE FROM lesson_activities WHERE lesson_id = 'C1-L34';
DELETE FROM lessons WHERE id = 'C1-L34';

INSERT INTO lessons (id, level, lesson_number, topic) VALUES
('C1-L34', 'C1', 34, 'Language and Cultural Power')
ON CONFLICT (id) DO UPDATE SET topic = EXCLUDED.topic;

DO $$
DECLARE
    lesson_id_var TEXT := 'C1-L34';
    activity_id_var UUID;
BEGIN
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'warm_up_speaking', 1, 'Language and Power', 'Discuss language and cultural power', '{"prompt": "How does language influence power?"}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_intro', 2, 'Language Power Vocabulary', 'Learn vocabulary about language and power', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'dominance', 'การครอบงำ', NULL),
    (activity_id_var, 'status', 'สถานะ', NULL),
    (activity_id_var, 'opportunity', 'โอกาส', NULL),
    (activity_id_var, 'diversity', 'ความหลากหลาย', NULL),
    (activity_id_var, 'minority', 'ชนกลุ่มน้อย', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_matching_drag', 3, 'Match Language Power Words', 'Match English words with Thai meanings', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'dominance', 'การครอบงำ', NULL),
    (activity_id_var, 'status', 'สถานะ', NULL),
    (activity_id_var, 'opportunity', 'โอกาส', NULL),
    (activity_id_var, 'diversity', 'ความหลากหลาย', NULL),
    (activity_id_var, 'minority', 'ชนกลุ่มน้อย', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 4, 'Complete the Sentences 1', 'Fill with the correct word', '{"text": "Language ___ signals ___. Linguistic ___ affects ___.", "blanks": [{"id": "blank1", "text": "dominance", "options": ["dominance", "status", "opportunity", "diversity"], "correctAnswer": "dominance"}, {"id": "blank2", "text": "status", "options": ["status", "dominance", "opportunity", "minority"], "correctAnswer": "status"}, {"id": "blank3", "text": "diversity", "options": ["diversity", "dominance", "status", "opportunity"], "correctAnswer": "diversity"}, {"id": "blank4", "text": "opportunity", "options": ["opportunity", "dominance", "status", "diversity"], "correctAnswer": "opportunity"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 5, 'Complete the Sentences 2', 'Fill with the correct word', '{"text": "Protecting ___ languages preserves ___. ___ communities need support.", "blanks": [{"id": "blank1", "text": "minority", "options": ["minority", "dominance", "status", "diversity"], "correctAnswer": "minority"}, {"id": "blank2", "text": "diversity", "options": ["diversity", "dominance", "status", "opportunity"], "correctAnswer": "diversity"}, {"id": "blank3", "text": "Minority", "options": ["Minority", "Dominance", "Status", "Diversity"], "correctAnswer": "Minority"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_explanation', 6, 'Nominal Clauses', 'Learn about nominal clauses', '{"rules": "Nominal clauses function as nouns:\n- Subject: \"What language signals affects status.\"\n- Object: \"I believe that language influences power.\"\n- Complement: \"The question is how language affects opportunity.\"\n\nTypes:\n- That-clauses: \"I think that language matters.\"\n- Wh-clauses: \"What you speak determines your access.\"\n- Whether/if: \"The issue is whether dominance is harmful.\"\n\nUse for:\n- Expressing opinions: \"What I think is that language shapes power.\"\n- Asking questions: \"How does language affect opportunity?\"\n- Making statements: \"That language matters is clear.\"", "examples": ["What language signals affects social status.", "I believe that language influences opportunity.", "The question is how language affects power.", "Whether linguistic dominance is harmful remains debated.", "That language matters is widely accepted."]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 7, 'Build Sentences 1', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'What language signals affects social status.', 'What language signals affects social status.', '["What", "language", "signals", "affects", "social", "status."]'::jsonb),
    (activity_id_var, 'I believe that language influences opportunity.', 'I believe that language influences opportunity.', '["I", "believe", "that", "language", "influences", "opportunity."]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 8, 'Build Sentences 2', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'The question is how language affects power.', 'The question is how language affects power.', '["The", "question", "is", "how", "language", "affects", "power."]'::jsonb),
    (activity_id_var, 'Whether linguistic dominance is harmful remains debated.', 'Whether linguistic dominance is harmful remains debated.', '["Whether", "linguistic", "dominance", "is", "harmful", "remains", "debated."]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'speaking_practice', 9, 'Discuss Language and Power', 'Practice speaking about language and power', '{"prompts": ["How does language signal status?", "What happens when one language dominates?", "How does language affect opportunity?", "Why is linguistic diversity important?", "How can minority languages be protected?"]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (
      lesson_id,
      activity_type,
      activity_order,
      title,
      description,
      content
    ) VALUES (
      'C1-L34',
      'speaking_improvement',
      10,
      'Speaking Improvement',
      'Read the improved version of your speech',
      '{"type": "speaking_improvement", "similarityThreshold": 70}'::jsonb
    );
END $$;
