-- =========================================
-- Pre-fill Database with Sample Lesson Data
-- C1-L25: Freedom of Speech on Campuses
-- =========================================
DELETE FROM lesson_activity_results WHERE lesson_id = 'C1-L25';
DELETE FROM user_progress WHERE lesson_id = 'C1-L25';
DELETE FROM lesson_history WHERE lesson_id = 'C1-L25';
DELETE FROM grammar_sentences WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'C1-L25');
DELETE FROM vocabulary_items WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'C1-L25');
DELETE FROM lesson_activities WHERE lesson_id = 'C1-L25';
DELETE FROM lessons WHERE id = 'C1-L25';

INSERT INTO lessons (id, level, lesson_number, topic) VALUES
('C1-L25', 'C1', 25, 'Freedom of Speech on Campuses')
ON CONFLICT (id) DO UPDATE SET topic = EXCLUDED.topic;

DO $$
DECLARE
    lesson_id_var TEXT := 'C1-L25';
    activity_id_var UUID;
BEGIN
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'warm_up_speaking', 1, 'Campus Speech', 'Discuss freedom of speech on campuses', '{"prompt": "When should speech be limited at universities?"}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_intro', 2, 'Speech Freedom Vocabulary', 'Learn vocabulary about speech freedom', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'expression', 'การแสดงออก', NULL),
    (activity_id_var, 'restriction', 'ข้อจำกัด', NULL),
    (activity_id_var, 'boundary', 'ขอบเขต', NULL),
    (activity_id_var, 'tension', 'ความตึงเครียด', NULL),
    (activity_id_var, 'safety', 'ความปลอดภัย', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_matching_drag', 3, 'Match Speech Freedom Words', 'Match English words with Thai meanings', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'expression', 'การแสดงออก', NULL),
    (activity_id_var, 'restriction', 'ข้อจำกัด', NULL),
    (activity_id_var, 'boundary', 'ขอบเขต', NULL),
    (activity_id_var, 'tension', 'ความตึงเครียด', NULL),
    (activity_id_var, 'safety', 'ความปลอดภัย', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 4, 'Complete the Sentences 1', 'Fill with the correct word', '{"text": "Free ___ faces ___. Clear ___ protect ___.", "blanks": [{"id": "blank1", "text": "expression", "options": ["expression", "restriction", "boundary", "tension"], "correctAnswer": "expression"}, {"id": "blank2", "text": "restrictions", "options": ["restrictions", "expression", "boundary", "tension"], "correctAnswer": "restrictions"}, {"id": "blank3", "text": "boundaries", "options": ["boundaries", "expression", "restriction", "tension"], "correctAnswer": "boundaries"}, {"id": "blank4", "text": "safety", "options": ["safety", "expression", "restriction", "tension"], "correctAnswer": "safety"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 5, 'Complete the Sentences 2', 'Fill with the correct word', '{"text": "Campus ___ arises around speech. Balancing ___ and ___ is challenging.", "blanks": [{"id": "blank1", "text": "tension", "options": ["tension", "expression", "restriction", "boundary"], "correctAnswer": "tension"}, {"id": "blank2", "text": "expression", "options": ["expression", "tension", "restriction", "safety"], "correctAnswer": "expression"}, {"id": "blank3", "text": "safety", "options": ["safety", "expression", "tension", "restriction"], "correctAnswer": "safety"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_explanation', 6, 'Inversion: Hardly/Scarcely', 'Learn inversion with hardly and scarcely', '{"rules": "Inversion with hardly/scarcely:\n- \"Hardly had speech begun when tensions rose.\" (formal emphasis)\n- \"Scarcely do students speak freely.\" (emphasis on infrequency)\n- \"Hardly ever is speech unrestricted.\" (emphasis on rarity)\n\nStructure:\n- Hardly/Scarcely + auxiliary + subject + verb\n- Used for emphasis and formal tone\n\nUse for:\n- Emphasizing rarity: \"Hardly ever is speech completely free.\"\n- Formal statements: \"Scarcely had they spoken when restrictions appeared.\"\n- Highlighting infrequency: \"Hardly do tensions arise without reason.\"", "examples": ["Hardly ever is speech completely unrestricted on campus.", "Scarcely do students speak freely without boundaries.", "Hardly had tensions risen when restrictions were imposed.", "Scarcely is expression limited without reason.", "Hardly do safety concerns override free expression."]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 7, 'Build Sentences 1', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'Hardly ever is speech completely unrestricted on campus.', 'Hardly ever is speech completely unrestricted on campus.', '["Hardly", "ever", "is", "speech", "completely", "unrestricted", "on", "campus."]'::jsonb),
    (activity_id_var, 'Scarcely do students speak freely without boundaries.', 'Scarcely do students speak freely without boundaries.', '["Scarcely", "do", "students", "speak", "freely", "without", "boundaries."]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 8, 'Build Sentences 2', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'Hardly had tensions risen when restrictions were imposed.', 'Hardly had tensions risen when restrictions were imposed.', '["Hardly", "had", "tensions", "risen", "when", "restrictions", "were", "imposed."]'::jsonb),
    (activity_id_var, 'Scarcely is expression limited without reason.', 'Scarcely is expression limited without reason.', '["Scarcely", "is", "expression", "limited", "without", "reason."]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'speaking_practice', 9, 'Discuss Campus Speech', 'Practice speaking about freedom of speech', '{"prompts": ["When is free speech restricted on campus?", "Why do tensions arise around speech?", "What limits are reasonable?", "How can safety and expression coexist?", "Who should decide speech boundaries?"]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (
      lesson_id,
      activity_type,
      activity_order,
      title,
      description,
      content
    ) VALUES (
      'C1-L25',
      'speaking_improvement',
      10,
      'Speaking Improvement',
      'Read the improved version of your speech',
      '{"type": "speaking_improvement", "similarityThreshold": 70}'::jsonb
    );
END $$;
