-- =========================================
-- Pre-fill Database with Sample Lesson Data
-- B1-L31: Remote Work
-- =========================================

DELETE FROM grammar_sentences WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'B1-L31');
DELETE FROM vocabulary_items WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'B1-L31');
DELETE FROM lesson_activities WHERE lesson_id = 'B1-L31';
DELETE FROM lessons WHERE id = 'B1-L31';

INSERT INTO lessons (id, level, lesson_number, topic) VALUES
('B1-L31', 'B1', 31, 'Remote Work')
ON CONFLICT (id) DO UPDATE SET topic = EXCLUDED.topic;

DO $$
DECLARE
    lesson_id_var TEXT := 'B1-L31';
    activity_id_var UUID;
BEGIN
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'warm_up_speaking', 1, 'Work From Home', 'Talk about your remote setup and plans', '{"prompt": "How will remote work change your daily life?"}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_intro', 2, 'Remote Work Words', 'Learn vocabulary about remote work', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'remote', 'ทางไกล', NULL),
    (activity_id_var, 'hybrid', 'แบบผสม (ออฟฟิศ/ทางไกล)', NULL),
    (activity_id_var, 'schedule', 'ตารางเวลา', NULL),
    (activity_id_var, 'focus', 'จดจ่อ', NULL),
    (activity_id_var, 'commute', 'เดินทางไปทำงาน', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_matching_drag', 3, 'Match Remote Words', 'Match words with meanings', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'remote', 'ทางไกล', NULL),
    (activity_id_var, 'hybrid', 'แบบผสม (ออฟฟิศ/ทางไกล)', NULL),
    (activity_id_var, 'schedule', 'ตารางเวลา', NULL),
    (activity_id_var, 'focus', 'จดจ่อ', NULL),
    (activity_id_var, 'commute', 'เดินทางไปทำงาน', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 4, 'Complete the Sentences 1', 'Fill with the correct word', '{"text": "I work ___ now. My team is ___. A clear ___ helps me ___.", "blanks": [{"id": "blank1", "text": "remote", "options": ["remote", "hybrid", "schedule", "commute"], "correctAnswer": "remote"}, {"id": "blank2", "text": "hybrid", "options": ["hybrid", "remote", "focus", "schedule"], "correctAnswer": "hybrid"}, {"id": "blank3", "text": "schedule", "options": ["schedule", "focus", "commute", "remote"], "correctAnswer": "schedule"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 5, 'Complete the Sentences 2', 'Fill with the correct word', '{"text": "I try to ___ before calls. No long ___ saves energy. A lighter ___ keeps stress down.", "blanks": [{"id": "blank1", "text": "focus", "options": ["focus", "schedule", "remote", "hybrid"], "correctAnswer": "focus"}, {"id": "blank2", "text": "commute", "options": ["commute", "focus", "hybrid", "schedule"], "correctAnswer": "commute"}, {"id": "blank3", "text": "schedule", "options": ["schedule", "remote", "focus", "commute"], "correctAnswer": "schedule"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    -- Grammar Explanation: Future (will vs going to) — remote plans
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_explanation', 6, 'Future: Will vs Going To (Remote Work)', 'Use will for decisions/uncertainty; going to for plans/intentions', '{"rules": "Use will for quick decisions and uncertain ideas. Use going to for intentions or scheduled plans.\\n- I will try a new schedule.\\n- I am going to set up a standing desk.\\nAvoid contractions.", "examples": ["I am going to change my work schedule next week.", "We will see if hybrid works for our team.", "She is going to add breaks to focus better.", "They will decide about office days soon.", "He is going to reduce his commute this month."]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 7, 'Build Sentences 1', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'I am going to change my work schedule next week', 'I am going to change my work schedule next week', '["I", "am", "going", "to", "change", "my", "work", "schedule", "next", "week"]'::jsonb),
    (activity_id_var, 'We will see if hybrid works for our team', 'We will see if hybrid works for our team', '["We", "will", "see", "if", "hybrid", "works", "for", "our", "team"]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 8, 'Build Sentences 2', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'She is going to add breaks to focus better', 'She is going to add breaks to focus better', '["She", "is", "going", "to", "add", "breaks", "to", "focus", "better"]'::jsonb),
    (activity_id_var, 'They will decide about office days soon', 'They will decide about office days soon', '["They", "will", "decide", "about", "office", "days", "soon"]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'speaking_practice', 9, 'Talk About Remote Work', 'Practice talking about remote work plans', '{"prompts": ["How will remote work change your daily life?", "What are you going to fix about your home setup?", "What is the best and worst part of working from home for you?"]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (
      lesson_id,
      activity_type,
      activity_order,
      title,
      description,
      content
    ) VALUES (
      'B1-L31',
      'speaking_improvement',
      10,
      'Speaking Improvement',
      'Read the improved version of your speech',
      '{"type": "speaking_improvement", "similarityThreshold": 70}'::jsonb
    );
END $$;

