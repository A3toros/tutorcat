# Penetration Testing Guide for TutorCat

This directory contains comprehensive penetration testing scripts to identify security vulnerabilities in the TutorCat application.

## Overview

The penetration testing suite covers:

1. **SQL Injection** - Tests for SQL injection vulnerabilities in database queries
2. **Authentication Bypass** - Tests JWT validation and authentication mechanisms
3. **Authorization/Privilege Escalation** - Tests admin endpoints and user data access
4. **XSS (Cross-Site Scripting)** - Tests input sanitization and output encoding
5. **CSRF (Cross-Site Request Forgery)** - Tests CSRF protection mechanisms
6. **Rate Limiting** - Tests brute force protection
7. **Input Validation** - Tests various malformed inputs
8. **Information Disclosure** - Tests error messages and debug information
9. **Session Management** - Tests cookie security and session handling
10. **CORS Configuration** - Tests CORS headers and configuration
11. **Security Headers** - Tests HTTP security headers
12. **JWT Security** - Tests JWT token manipulation and validation
13. **Dependency Vulnerabilities** - Checks for known vulnerable packages

## Prerequisites

- Node.js (v14 or higher)
- Access to the TutorCat API (local or remote)
- Network access to the target server

## Usage

### Basic Testing

Run the main penetration testing suite:

```bash
# Test against local development server
node scripts/penetration-test.js

# Test against production/staging
API_BASE_URL=https://your-domain.com node scripts/penetration-test.js

# Verbose output
node scripts/penetration-test.js --verbose
```

### Advanced Testing

Run additional security tests:

```bash
node scripts/penetration-test-advanced.js
```

### Combined Testing

Run both test suites:

```bash
node scripts/penetration-test.js && node scripts/penetration-test-advanced.js
```

## Test Results

The scripts generate a JSON report: `penetration-test-report.json`

### Report Structure

```json
{
  "timestamp": "2024-01-01T00:00:00.000Z",
  "baseUrl": "http://localhost:8888",
  "summary": {
    "total": 10,
    "passed": 8,
    "failed": 2,
    "warnings": 3
  },
  "results": {
    "passed": [...],
    "failed": [...],
    "warnings": [...]
  }
}
```

## Test Categories

### Critical Severity Issues

These should be fixed immediately:

- SQL Injection vulnerabilities
- Authentication bypass
- Privilege escalation
- Remote code execution

### High Severity Issues

These should be fixed soon:

- XSS vulnerabilities
- Missing rate limiting
- Weak authentication
- Information disclosure

### Medium Severity Issues

These should be addressed:

- CORS misconfiguration
- Missing security headers
- Weak input validation
- Session management issues

### Low Severity Issues

These are recommendations:

- Missing security headers (non-critical)
- Verbose error messages
- Information disclosure (minor)

## Manual Testing Checklist

Some tests require manual verification:

### Authentication & Authorization

- [ ] Test JWT token expiration handling
- [ ] Test session revocation
- [ ] Test admin token expiration
- [ ] Test privilege escalation attempts
- [ ] Test access to other users' data

### Input Validation

- [ ] Test all user input fields with XSS payloads
- [ ] Test file uploads (if applicable)
- [ ] Test path traversal attempts
- [ ] Test command injection (if applicable)

### Session Management

- [ ] Verify cookies have HttpOnly flag
- [ ] Verify cookies have Secure flag (in production)
- [ ] Verify SameSite attribute is set
- [ ] Test session fixation
- [ ] Test concurrent session limits

### Business Logic

- [ ] Test race conditions
- [ ] Test workflow bypass
- [ ] Test payment/score manipulation (if applicable)
- [ ] Test data integrity

## Security Best Practices

### Code Review Checklist

When reviewing code for security:

1. **SQL Injection**
   - ✅ All queries use parameterized statements (template literals with `neon`)
   - ✅ No string concatenation in SQL queries
   - ✅ Input validation before database operations

2. **Authentication**
   - ✅ JWT tokens are properly validated
   - ✅ Secrets are stored in environment variables
   - ✅ Password hashing uses bcrypt
   - ✅ Session tokens are properly managed

3. **Authorization**
   - ✅ Admin endpoints check for admin role
   - ✅ Users can only access their own data
   - ✅ Role-based access control is enforced

4. **Input Validation**
   - ✅ All user input is sanitized
   - ✅ Input length limits are enforced
   - ✅ Type validation is performed
   - ✅ XSS prevention (output encoding)

5. **Error Handling**
   - ✅ No stack traces in production
   - ✅ Generic error messages for users
   - ✅ Detailed errors only in logs

6. **Security Headers**
   - ✅ X-Content-Type-Options: nosniff
   - ✅ X-Frame-Options: DENY
   - ✅ X-XSS-Protection: 1; mode=block
   - ✅ Content-Security-Policy configured
   - ✅ Strict-Transport-Security (if HTTPS)

## Continuous Security Testing

### Automated Testing

Consider integrating these tests into CI/CD:

```yaml
# Example GitHub Actions workflow
name: Security Testing
on: [push, pull_request]
jobs:
  penetration-test:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v2
      - name: Run Penetration Tests
        run: |
          npm install
          node scripts/penetration-test.js
```

### Regular Audits

- Run penetration tests before each release
- Review dependency vulnerabilities monthly (`npm audit`)
- Perform manual security reviews quarterly
- Keep dependencies updated

## Known Limitations

1. **Authentication Required**: Some tests require valid authentication tokens
2. **Environment Specific**: Results may vary between dev/staging/production
3. **False Positives**: Some tests may report issues that are false positives
4. **Manual Verification**: Some security aspects require manual testing

## Remediation

When vulnerabilities are found:

1. **Document** the vulnerability in the test report
2. **Assess** the severity and impact
3. **Fix** the vulnerability following security best practices
4. **Re-test** to verify the fix
5. **Update** tests if needed

## Resources

- [OWASP Top 10](https://owasp.org/www-project-top-ten/)
- [OWASP Testing Guide](https://owasp.org/www-project-web-security-testing-guide/)
- [Node.js Security Best Practices](https://nodejs.org/en/docs/guides/security/)
- [JWT Security Best Practices](https://tools.ietf.org/html/rfc8725)

## Reporting Issues

If you find security vulnerabilities:

1. **Do NOT** create public GitHub issues
2. Contact the security team directly
3. Provide detailed information about the vulnerability
4. Include steps to reproduce
5. Wait for confirmation before disclosing

## License

This testing suite is part of the TutorCat project and follows the same license.
