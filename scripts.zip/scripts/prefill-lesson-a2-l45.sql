-- =========================================
-- Pre-fill Database with Sample Lesson Data
-- A2-L45: Healthy Food Choices
-- =========================================

DELETE FROM grammar_sentences WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'A2-L45');
DELETE FROM vocabulary_items WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'A2-L45');
DELETE FROM lesson_activities WHERE lesson_id = 'A2-L45';
DELETE FROM lessons WHERE id = 'A2-L45';

INSERT INTO lessons (id, level, lesson_number, topic) VALUES
('A2-L45', 'A2', 45, 'Healthy Food Choices')
ON CONFLICT (id) DO UPDATE SET topic = EXCLUDED.topic;

DO $$
DECLARE
    lesson_id_var TEXT := 'A2-L45';
    activity_id_var UUID;
BEGIN
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'warm_up_speaking', 1, 'Healthy Eating', 'Talk about healthy food', '{"prompt": "Which food is healthier: home-cooked or fast food?"}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_intro', 2, 'Healthy Food Words', 'Learn healthy food vocabulary', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'healthy', 'สุขภาพดี', NULL),
    (activity_id_var, 'unhealthy', 'ไม่ดีต่อสุขภาพ', NULL),
    (activity_id_var, 'fresh', 'สด', NULL),
    (activity_id_var, 'fried', 'ทอด', NULL),
    (activity_id_var, 'portion', 'ส่วน', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_matching_drag', 3, 'Match Food Words', 'Match healthy food words', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'healthy', 'สุขภาพดี', NULL),
    (activity_id_var, 'unhealthy', 'ไม่ดีต่อสุขภาพ', NULL),
    (activity_id_var, 'fresh', 'สด', NULL),
    (activity_id_var, 'fried', 'ทอด', NULL),
    (activity_id_var, 'portion', 'ส่วน', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 4, 'Complete the Sentences 1', 'Fill with the correct word', '{"text": "This meal is ___. The salad is ___. The chicken is ___.", "blanks": [{"id": "blank1", "text": "healthy", "options": ["healthy", "fresh", "fried", "portion"], "correctAnswer": "healthy"}, {"id": "blank2", "text": "fresh", "options": ["fresh", "fried", "healthy", "portion"], "correctAnswer": "fresh"}, {"id": "blank3", "text": "fried", "options": ["fried", "fresh", "unhealthy", "portion"], "correctAnswer": "fried"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 5, 'Complete the Sentences 2', 'Fill with the correct word', '{"text": "A big ___ can be ___. Smaller ___ are better.", "blanks": [{"id": "blank1", "text": "portion", "options": ["portion", "unhealthy", "fried", "fresh"], "correctAnswer": "portion"}, {"id": "blank2", "text": "unhealthy", "options": ["unhealthy", "healthy", "fresh", "portion"], "correctAnswer": "unhealthy"}, {"id": "blank3", "text": "portions", "options": ["portions", "portion", "fried", "fresh"], "correctAnswer": "portions"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_explanation', 6, 'Comparatives', 'Compare healthy choices', '{"rules": "Use comparatives: healthy → healthier; fresh → fresher; fried → more fried (avoid), unhealthy → more unhealthy.\nPattern: This meal is healthier than that one.", "examples": ["This meal is healthier than fast food.", "Fresh food is better than fried food.", "Smaller portions are healthier.", "This salad is fresher than yesterday.", "Fried snacks are less healthy."]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 7, 'Build Sentences 1', 'Arrange words', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'This meal is healthier than fast food', 'This meal is healthier than fast food.', '["This", "meal", "is", "healthier", "than", "fast", "food."]'::jsonb),
    (activity_id_var, 'Fresh food is better than fried food', 'Fresh food is better than fried food.', '["Fresh", "food", "is", "better", "than", "fried", "food."]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 8, 'Build Sentences 2', 'Arrange words', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'Smaller portions are healthier', 'Smaller portions are healthier.', '["Smaller", "portions", "are", "healthier."]'::jsonb),
    (activity_id_var, 'This salad is fresher than yesterday', 'This salad is fresher than yesterday.', '["This", "salad", "is", "fresher", "than", "yesterday."]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'speaking_practice', 9, 'Talk About Healthy Food', 'Practice healthy choices', '{"prompts": ["Which food is healthier: home-cooked or fast food?", "Do you eat fried food more or less often now?", "Who eats healthier food in your family?", "What makes one meal healthier than another?", "How do you choose healthy food when eating out?"]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (
      lesson_id,
      activity_type,
      activity_order,
      title,
      description,
      content
    ) VALUES (
      'A2-L45',
      'speaking_improvement',
      10,
      'Speaking Improvement',
      'Read the improved version of your speech',
      '{"type": "speaking_improvement", "similarityThreshold": 70}'::jsonb
    );
END $$;

