-- =========================================
-- Pre-fill Database with Sample Lesson Data
-- B2-L32: Using AI and digital tools for learning
-- =========================================

DELETE FROM grammar_sentences WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'B2-L32');
DELETE FROM vocabulary_items WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'B2-L32');
DELETE FROM lesson_activities WHERE lesson_id = 'B2-L32';
DELETE FROM lessons WHERE id = 'B2-L32';

INSERT INTO lessons (id, level, lesson_number, topic) VALUES
('B2-L32', 'B2', 32, 'Using AI and digital tools for learning')
ON CONFLICT (id) DO UPDATE SET topic = EXCLUDED.topic;

DO $$
DECLARE
    lesson_id_var TEXT := 'B2-L32';
    activity_id_var UUID;
BEGIN
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'warm_up_speaking', 1, 'AI in Study', 'Talk about reliance on tools', '{"prompt": "If AI failed mid-project, what would you do, and who would you ask for review?"}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_intro', 2, 'AI Study Words', 'Key words for AI use', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'prompt', 'พรอมต์/ข้อความสั่งงาน', NULL),
    (activity_id_var, 'iterate', 'วนทำซ้ำ/ปรับปรุง', NULL),
    (activity_id_var, 'refine', 'ขัดเกลา/ปรับละเอียด', NULL),
    (activity_id_var, 'constraint', 'ข้อจำกัด', NULL),
    (activity_id_var, 'misuse', 'ใช้ผิดวิธี', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_matching_drag', 3, 'Match AI Study Words', 'Match words with meanings', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'prompt', 'พรอมต์/ข้อความสั่งงาน', NULL),
    (activity_id_var, 'iterate', 'วนทำซ้ำ/ปรับปรุง', NULL),
    (activity_id_var, 'refine', 'ขัดเกลา/ปรับละเอียด', NULL),
    (activity_id_var, 'constraint', 'ข้อจำกัด', NULL),
    (activity_id_var, 'misuse', 'ใช้ผิดวิธี', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 4, 'Complete the Sentences 1', 'Fill with the correct word', '{"text": "I adjust my ___. I ___ drafts. I watch for ___.", "blanks": [{"id": "blank1", "text": "prompt", "options": ["prompt", "refine", "constraint", "misuse"], "correctAnswer": "prompt"}, {"id": "blank2", "text": "refine", "options": ["refine", "iterate", "prompt", "constraint"], "correctAnswer": "refine"}, {"id": "blank3", "text": "constraint", "options": ["constraint", "misuse", "prompt", "iterate"], "correctAnswer": "constraint"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 5, 'Complete the Sentences 2', 'Fill with the correct word', '{"text": "I ___ outputs to improve them. I avoid ___.", "blanks": [{"id": "blank1", "text": "iterate", "options": ["iterate", "prompt", "refine", "constraint"], "correctAnswer": "iterate"}, {"id": "blank2", "text": "misuse", "options": ["misuse", "iterate", "refine", "constraint"], "correctAnswer": "misuse"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_explanation', 6, 'Second Conditional', 'Plan for AI failures or choices', '{"rules": "Use if + past simple + would + base verb for unreal/hypothetical present/future.\\n- If AI failed, I would switch to notes.\\nUse were after I/he/she/it in formal style.", "examples": ["If the model failed, I would revert to my outline.", "If prompts were clearer, outputs would improve.", "If I were unsure, I would ask a friend to review.", "If constraints were strict, I would iterate more.", "If there were misuse, we would pause the tool."]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 7, 'Build Sentences 1', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'If the model failed, I would revert to my outline', 'If the model failed, I would revert to my outline.', '["If", "the", "model", "failed,", "I", "would", "revert", "to", "my", "outline."]'::jsonb),
    (activity_id_var, 'If prompts were clearer, outputs would improve', 'If prompts were clearer, outputs would improve.', '["If", "prompts", "were", "clearer,", "outputs", "would", "improve."]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 8, 'Build Sentences 2', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'If I were unsure, I would ask a friend to review', 'If I were unsure, I would ask a friend to review.', '["If", "I", "were", "unsure,", "I", "would", "ask", "a", "friend", "to", "review."]'::jsonb),
    (activity_id_var, 'If there were misuse, we would pause the tool', 'If there were misuse, we would pause the tool.', '["If", "there", "were", "misuse,", "we", "would", "pause", "the", "tool."]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'speaking_practice', 9, 'Talk About AI Plans', 'Practice hypotheticals', '{"prompts": ["If AI failed mid-project, what would you do?", "Who would you ask to review outputs?", "When would you pause a tool because of misuse?"]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (
      lesson_id,
      activity_type,
      activity_order,
      title,
      description,
      content
    ) VALUES (
      'B2-L32',
      'speaking_improvement',
      10,
      'Speaking Improvement',
      'Read the improved version of your speech',
      '{"type": "speaking_improvement", "similarityThreshold": 70}'::jsonb
    );
END $$;


