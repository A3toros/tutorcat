# B1 Speaking Prompts

This file contains all warm-up and speaking practice prompts for B1 lessons.

---

## Lesson 1: Life Experiences

**Warm-up Prompt:**

What is the most interesting experience you have had?

**Speaking Practice Prompts:**

- What is the most exciting thing you have ever done?
- Have you ever traveled alone?
- What challenges have you overcome?
- What opportunities have you taken?
- Describe a journey that changed you.

---

## Lesson 2: Education & Learning

**Warm-up Prompt:**

What is the most important thing you have learned?

**Speaking Practice Prompts:**

- What is the most important thing you have learned?
- What skills have you developed recently?
- How has education changed your life?
- What course would you like to take?
- Do you think formal education is necessary?

---

## Lesson 3: Work & Career Plans

**Warm-up Prompt:**

What are your career goals?

**Speaking Practice Prompts:**

- What are your career goals?
- Where do you see yourself in five years?
- Do you think education is important for your career?
- How important is salary to you?
- What qualifications do you need for your dream job?

---

## Lesson 4: Health & Lifestyle Choices

**Warm-up Prompt:**

What do you do to stay healthy?

**Speaking Practice Prompts:**

- What do you do to stay healthy?
- How important is exercise to you?
- What changes have you made to improve your health?
- What advice would you give someone about staying healthy?
- How do you balance work and wellness?

---

## Lesson 5: Relationships

**Warm-up Prompt:**

What makes a good relationship?

**Speaking Practice Prompts:**

- What makes a good relationship?
- How long have you known your best friend?
- What is the most important quality in a relationship?
- How do you handle conflicts in relationships?
- What role does communication play in your relationships?

---

## Lesson 6: Entertainment & Media

**Warm-up Prompt:**

What is your favorite form of entertainment?

**Speaking Practice Prompts:**

- What is your favorite form of entertainment?
- What movies or series have you watched recently?
- Do you prefer streaming or going to the cinema?
- What podcasts do you listen to?
- How do you choose what to watch?

---

## Lesson 7: Travel Experiences

**Warm-up Prompt:**

What is the best trip you have ever taken?

**Speaking Practice Prompts:**

- What is the best trip you have ever taken?
- What countries have you visited?
- What do you enjoy most about traveling?
- How do you plan your trips?
- What is your dream destination?

---

## Lesson 8: Technology & Internet Use

**Warm-up Prompt:**

How has technology changed your life?

**Speaking Practice Prompts:**

- How has technology changed your life?
- What devices do you use every day?
- How long have you been using the internet?
- What do you think about social media?
- How do you protect your online security?

---

## Lesson 9: Goals & Future Plans

**Warm-up Prompt:**

What are your goals for the next five years?

**Speaking Practice Prompts:**

- What are your goals for the next five years?
- What do you plan to achieve this year?
- What would you do if you had more time?
- How do you plan to reach your goals?
- What is your biggest ambition?

---

## Lesson 10: Problems & Solutions

**Warm-up Prompt:**

What is a problem you have solved recently?

**Speaking Practice Prompts:**

- What is a problem you have solved recently?
- How do you usually approach problems?
- What would you do if you faced a difficult challenge?
- What solutions have worked for you in the past?
- How do you help others solve problems?

---

## Lesson 11: Daily Life Changes

**Warm-up Prompt:**

What change did you make recently that really helped you?

**Speaking Practice Prompts:**

- What change did you make recently that really helped you?
- Which habit have you kept the longest and why?
- Tell me about a small change you are proud of.

---

## Lesson 12: Social Media Influence

**Warm-up Prompt:**

When did social media pull you in for too long?

**Speaking Practice Prompts:**

- When did social media pull you in for too long?
- Which trend actually changed what you did?
- Describe a post that genuinely inspired you.

---

## Lesson 13: Travel Planning

**Warm-up Prompt:**

How do you actually plan a trip step by step?

**Speaking Practice Prompts:**

- How do you actually plan a trip step by step?
- When do you change plans mid-trip?
- What makes you pick one destination over another?

---

## Lesson 14: Workplace Communication

**Warm-up Prompt:**

How do you handle unclear instructions from someone?

**Speaking Practice Prompts:**

- How do you handle unclear instructions from someone?
- When do you feel you should push back?
- Describe the best work message you have sent or received.

---

## Lesson 15: Personal Finances

**Warm-up Prompt:**

How do you keep track of your money in real life?

**Speaking Practice Prompts:**

- How do you keep track of your money in real life?
- What is the smartest purchase you have made?
- When do you decide to save instead of spend?

---

## Lesson 16: Health Problems & Advice

**Warm-up Prompt:**

What do you do first when you feel sick?

**Speaking Practice Prompts:**

- What do you do first when you feel sick?
- Who gives you health advice you trust?
- How do you decide it is time to see a doctor?

---

## Lesson 17: Relationships at Work

**Warm-up Prompt:**

How do you build trust with coworkers?

**Speaking Practice Prompts:**

- How do you build trust with coworkers?
- Tell me about a conflict you helped resolve.
- What do you enjoy doing with colleagues outside tasks?

---

## Lesson 18: Environmental Problems

**Warm-up Prompt:**

What local issue bothers you most?

**Speaking Practice Prompts:**

- What local issue bothers you most?
- How is trash actually handled where you live?
- What small action did you take that felt impactful?

---

## Lesson 19: Childhood Memories

**Warm-up Prompt:**

What were you doing in a favorite childhood memory?

**Speaking Practice Prompts:**

- What were you doing in a favorite childhood memory?
- Tell me about a place you explored as a kid.
- Who made your childhood feel safe or fun?

---

## Lesson 20: Online Communication

**Warm-up Prompt:**

Which app do you use most and why?

**Speaking Practice Prompts:**

- Which app do you use most and why?
- How do you fix misunderstandings online?
- What message from someone really made you feel heard?

---

## Lesson 21: Cultural Differences

**Warm-up Prompt:**

How do you avoid awkward moments in a new culture?

**Speaking Practice Prompts:**

- How do you avoid awkward moments in a new culture?
- What surprised you most when you traveled?
- When do you decide to adapt your behavior?

---

## Lesson 22: Teamwork

**Warm-up Prompt:**

How do you pass on feedback without drama?

**Speaking Practice Prompts:**

- How do you pass on feedback without drama?
- Tell me about sharing news with your team.
- When does teamwork feel great for you?

---

## Lesson 23: Saving & Spending Money

**Warm-up Prompt:**

What have you saved up for recently?

**Speaking Practice Prompts:**

- What have you saved up for recently?
- When did you regret spending?
- How do you decide something is worth the price?

---

## Lesson 24: Mental Health Awareness

**Warm-up Prompt:**

Who do you actually talk to when stressed?

**Speaking Practice Prompts:**

- Who do you actually talk to when stressed?
- Describe a routine that calms you down.
- What signs show you need a break?

---

## Lesson 25: Family Roles

**Warm-up Prompt:**

How do you split chores at home?

**Speaking Practice Prompts:**

- How do you split chores at home?
- When do you rely on family most?
- What do you try to teach younger relatives?

---

## Lesson 26: Recycling & Waste

**Warm-up Prompt:**

How is trash really handled where you live?

**Speaking Practice Prompts:**

- How is trash really handled where you live?
- What rule changed your recycling habits?
- Which new rule would help most?

---

## Lesson 27: Living Abroad

**Warm-up Prompt:**

What would you miss first if you moved abroad?

**Speaking Practice Prompts:**

- What would you miss first if you moved abroad?
- How would you make friends in a new country?
- What daily routine would you keep?

---

## Lesson 28: Tech: Pros/Cons

**Warm-up Prompt:**

At what point do you put your phone away?

**Speaking Practice Prompts:**

- At what point do you put your phone away?
- Is 3 hours of scrolling TikTok too much for you? Why?
- Tell me about a day when tech made things worse for you.

---

## Lesson 29: Dealing with Stress

**Warm-up Prompt:**

What must you do first when stress hits?

**Speaking Practice Prompts:**

- What must you do first when stress hits?
- What should schools actually teach about stress?
- Describe your go-to coping move.

---

## Lesson 30: Food Cultures

**Warm-up Prompt:**

What new dish have you tried lately?

**Speaking Practice Prompts:**

- What new dish have you tried lately?
- Which food memory sticks with you?
- How do you talk yourself into trying new food?

---

## Lesson 31: Remote Work

**Warm-up Prompt:**

How will remote work change your daily life?

**Speaking Practice Prompts:**

- How will remote work change your daily life?
- What are you going to fix about your home setup?
- What is the best and worst part of working from home for you?

---

## Lesson 32: News & Information

**Warm-up Prompt:**

How do you check if news is real?

**Speaking Practice Prompts:**

- How do you check if news is real?
- What do you do when a headline feels fake?
- When do you decide to stop doomscrolling?

---

## Lesson 33: Strengths & Weaknesses

**Warm-up Prompt:**

What do you enjoy getting better at?

**Speaking Practice Prompts:**

- What do you enjoy getting better at?
- What task do you avoid?
- Tell me about practicing a skill until it finally worked.

---

## Lesson 34: Problems While Traveling

**Warm-up Prompt:**

What were you doing when a trip went wrong?

**Speaking Practice Prompts:**

- What were you doing when a trip went wrong?
- How did you get out of it?
- Who stepped in to help you?

---

## Lesson 35: Customer Service Experiences

**Warm-up Prompt:**

What service experience really impressed you?

**Speaking Practice Prompts:**

- What service experience really impressed you?
- How should a complaint be handled?
- Describe a fair solution you received.

---

## Lesson 36: Fitness Routines

**Warm-up Prompt:**

What makes a workout so motivating for you?

**Speaking Practice Prompts:**

- What makes a workout so motivating for you?
- What is such a tiring exercise that you still do?
- How do you keep a routine when you are busy?

---

## Lesson 37: Conflict & Agreement

**Warm-up Prompt:**

How do you sort out disagreements with friends or coworkers?

**Speaking Practice Prompts:**

- How do you sort out disagreements with friends or coworkers?
- Who is someone that mediates well in your life?
- When do you decide to compromise?

---

## Lesson 38: Comparing Products

**Warm-up Prompt:**

How do you decide between two similar products?

**Speaking Practice Prompts:**

- How do you decide between two similar products?
- When is quality worth paying more?
- Describe something that was not good enough and why.

---

## Lesson 39: Tech Problems & Fixes

**Warm-up Prompt:**

What do you actually do when your tech fails?

**Speaking Practice Prompts:**

- What do you actually do when your tech fails?
- How do you back up your stuff?
- When do you finally ask someone for help?

---

## Lesson 40: Homesickness

**Warm-up Prompt:**

When have you felt homesick?

**Speaking Practice Prompts:**

- When have you felt homesick?
- What helps you adapt in a new place?
- How do you stay connected to people you miss?

---

## Lesson 41: Making Decisions

**Warm-up Prompt:**

How do you decide when you are under pressure?

**Speaking Practice Prompts:**

- How do you decide when you are under pressure?
- What decision are you going to make soon?
- When do you change your mind and why?

---

## Lesson 42: Language Barriers

**Warm-up Prompt:**

How do you retell something you heard in another language?

**Speaking Practice Prompts:**

- How do you retell something you heard in another language?
- Describe a misunderstanding you had.
- How did you fix it in the moment?

---

## Lesson 43: Budgeting

**Warm-up Prompt:**

How do you actually plan a monthly budget?

**Speaking Practice Prompts:**

- How do you actually plan a monthly budget?
- What expense surprised you lately?
- When do you decide to cut costs?

---

## Lesson 44: Sleep & Energy

**Warm-up Prompt:**

What happens to you if you sleep too little?

**Speaking Practice Prompts:**

- What happens to you if you sleep too little?
- What keeps you awake on a rough day?
- Describe a daily routine that really works for you.

---

## Lesson 45: Giving Opinions Politely

**Warm-up Prompt:**

How do you share a tough opinion without sounding rude?

**Speaking Practice Prompts:**

- How do you share a tough opinion without sounding rude?
- When do you soften your words?
- Describe a polite disagreement you had.

---

## Lesson 46: Trusting Information Online

**Warm-up Prompt:**

If a post feels fake, what do you do?

**Speaking Practice Prompts:**

- If a post feels fake, what do you do?
- How do you decide a source is trustworthy?
- What makes you doubt information?

---

## Lesson 47: City vs Countryside

**Warm-up Prompt:**

What were you doing last time a city felt overwhelming?

**Speaking Practice Prompts:**

- What were you doing last time a city felt overwhelming?
- How does countryside pace change how you feel?
- Where do you focus better and why?

---

## Lesson 48: Advertising & Consumers

**Warm-up Prompt:**

Which ad actually influenced you?

**Speaking Practice Prompts:**

- Which ad actually influenced you?
- How were buyers targeted in a campaign you saw?
- Describe a campaign that failed for you.

---

## Lesson 49: Helping Others

**Warm-up Prompt:**

What do you genuinely enjoy doing to help?

**Speaking Practice Prompts:**

- What do you genuinely enjoy doing to help?
- When did you give time or money?
- How do you decide who to help?

---

## Lesson 50: Energy Use at Home

**Warm-up Prompt:**

How is energy really used at home?

**Speaking Practice Prompts:**

- How is energy really used at home?
- What are you improving now?
- What change saved the most for you?

---

## Lesson 51: Online Shopping

**Warm-up Prompt:**

What have you bought online recently that you loved?

**Speaking Practice Prompts:**

- What have you bought online recently that you loved?
- When did a review save you from a bad buy?
- Describe your smoothest delivery ever.

---

## Lesson 52: Work Responsibilities

**Warm-up Prompt:**

Who is someone that supports you most at work?

**Speaking Practice Prompts:**

- Who is someone that supports you most at work?
- Which tasks drain you the most?
- How do you share responsibility fairly?

---

## Lesson 53: Diet Choices

**Warm-up Prompt:**

What food is so satisfying you crave it?

**Speaking Practice Prompts:**

- What food is so satisfying you crave it?
- What is such a hard craving to resist for you?
- How do you balance taste and health personally?

---

## Lesson 54: Conflict Resolution (Work)

**Warm-up Prompt:**

How do you deal with a tense meeting in real life?

**Speaking Practice Prompts:**

- How do you deal with a tense meeting in real life?
- Who do you listen to most before you decide?
- When do you compromise even if you disagree?

---

## Lesson 55: Cultural Traditions

**Warm-up Prompt:**

What tradition matters most to you?

**Speaking Practice Prompts:**

- What tradition matters most to you?
- How do you explain it to friends who do not know it?
- What would you keep or change about it?

---

## Lesson 56: Remote Learning

**Warm-up Prompt:**

How will online learning change your study life?

**Speaking Practice Prompts:**

- How will online learning change your study life?
- What are you going to improve in your habits?
- When do you still prefer in-person classes?

---

## Lesson 57: Making Complaints

**Warm-up Prompt:**

Describe a complaint you actually made.

**Speaking Practice Prompts:**

- Describe a complaint you actually made.
- What finally got resolved?
- How should staff respond to you?

---

## Lesson 58: Financial Goals

**Warm-up Prompt:**

What must you do to hit a money goal?

**Speaking Practice Prompts:**

- What must you do to hit a money goal?
- How do you track progress day to day?
- When do you change the plan?

---

## Lesson 59: Free Time & Work–Life Balance

**Warm-up Prompt:**

How have you protected your free time lately?

**Speaking Practice Prompts:**

- How have you protected your free time lately?
- When did you last feel balanced?
- What hobby brings you back to life?

---

## Lesson 60: Public Transport vs Cars

**Warm-up Prompt:**

If fuel costs rise, what will you choose for commuting?

**Speaking Practice Prompts:**

- If fuel costs rise, what will you choose for commuting?
- How do different routes change your day?
- When is a car the only option for you?

---

## Lesson 61: Social Responsibilities

**Warm-up Prompt:**

Who inspires you to help others?

**Speaking Practice Prompts:**

- Do you help people in your neighborhood?
- What do you do to help your family?
- Who is your favorite person to help?
- Do you volunteer anywhere?
- What causes do you support?

---

## Lesson 62: Protecting Nature

**Warm-up Prompt:**

What places near you are being protected?

**Speaking Practice Prompts:**

- Do you like going to the park?
- What animals live near your home?
- Do you recycle at home?
- What can we do to protect nature?
- Are there protected areas near you?

---

## Lesson 63: Learning New Skills

**Warm-up Prompt:**

What skill are you trying to master right now?

**Speaking Practice Prompts:**

- What subject do you like best?
- Who helps you with homework?
- What do you do when you don
- t understand?
- What skill are you trying to learn?
- How do you practice new skills?

---

## Lesson 64: Technology Predictions

**Warm-up Prompt:**

What tech do you think will change your daily life?

**Speaking Practice Prompts:**

- What do you use your phone for?
- Do you play computer games?
- Who taught you to use the computer?
- How will technology change in the future?
- What technology do you want to learn about?

---

## Lesson 65: Balancing Health and Work

**Warm-up Prompt:**

What must you do to stay healthy at work?

**Speaking Practice Prompts:**

- What time do you wake up?
- When do you eat dinner?
- Do you exercise every day?
- How do you stay healthy at work?
- What should people do to stay healthy?

---

## Lesson 66: Travel Tips

**Warm-up Prompt:**

What were you doing when a travel tip saved you?

**Speaking Practice Prompts:**

- Where did you go last summer?
- Did you take pictures on your trip?
- What did you buy as a souvenir?
- What travel tips do you know?
- Have you ever gotten lost while traveling?

---

## Lesson 67: Language Learning & Barriers

**Warm-up Prompt:**

How do you repeat instructions for friends?

**Speaking Practice Prompts:**

- Can you speak English?
- What language does your family speak?
- Do you learn Chinese at school?
- How do you practice speaking English?
- Have you ever needed a translator?

---

## Lesson 68: Comparing Housing Options

**Warm-up Prompt:**

When is a place too noisy for you?

**Speaking Practice Prompts:**

- How many rooms are in your house?
- Do you have a garden?
- What is your favorite room?
- Is your home too small or big enough?
- What makes a good place to live?

---

## Lesson 69: Healthy Habits

**Warm-up Prompt:**

Do you eat breakfast every day?

**Speaking Practice Prompts:**

- What healthy food do you eat?
- How many hours do you sleep?
- What exercise do you do?
- What is your daily routine?
- How do you stay healthy?

---

## Lesson 70: Career Changes

**Warm-up Prompt:**

Have you changed career paths?

**Speaking Practice Prompts:**

- What job does your father have?
- Do you want to be a teacher?
- Where do you want to work?
- Have you ever changed jobs?
- What career would you like to switch to?

---

## Lesson 71: Community Life

**Warm-up Prompt:**

What makes your community feel strong?

**Speaking Practice Prompts:**

- What makes your community feel strong?
- Which local event do you actually enjoy?
- How do you get involved where you live?

---

## Lesson 72: Digital Privacy

**Warm-up Prompt:**

What should you never post online?

**Speaking Practice Prompts:**

- What should you never post online?
- When do you have to refuse sharing data?
- How do you keep your accounts safe?

---

## Lesson 73: Studying Online vs Offline

**Warm-up Prompt:**

How will classes change for you?

**Speaking Practice Prompts:**

- How will classes change for you?
- What are you going to keep from online study?
- When do you insist on in-person learning?

---

## Lesson 74: Work Under Pressure

**Warm-up Prompt:**

What helps you cope when deadlines stack up?

**Speaking Practice Prompts:**

- What helps you cope when deadlines stack up?
- What do you avoid when you are overloaded?
- Describe delivering on a tight deadline in your life.

---

## Lesson 75: Environmental Solutions

**Warm-up Prompt:**

Which solutions are being put in place near you?

**Speaking Practice Prompts:**

- Which solutions are being put in place near you?
- How are rules enforced where you live?
- What project actually inspired you?

---

## Lesson 76: Helping in Emergencies

**Warm-up Prompt:**

If you saw an accident, what would you do first?

**Speaking Practice Prompts:**

- If you saw an accident, what would you do first?
- How do you keep calm in a crisis?
- Who do you call right away?

---

## Lesson 77: Reporting News

**Warm-up Prompt:**

How do you repeat urgent news accurately?

**Speaking Practice Prompts:**

- How do you repeat urgent news accurately?
- When do you add context?
- Describe sharing breaking news with friends.

---

## Lesson 78: Volunteering

**Warm-up Prompt:**

What have you learned from volunteering?

**Speaking Practice Prompts:**

- What have you learned from volunteering?
- Which cause matters most to you?
- How has volunteering changed your outlook?

---

## Lesson 79: Travel Alone vs With Others

**Warm-up Prompt:**

What were you doing the first time you traveled alone?

**Speaking Practice Prompts:**

- What were you doing the first time you traveled alone?
- How is traveling with friends different for you?
- When did a companion really help?

---

## Lesson 80: Social Media & Mental Health

**Warm-up Prompt:**

How do you deal with negative posts in your feed?

**Speaking Practice Prompts:**

- How do you deal with negative posts in your feed?
- When do you decide to log off?
- How do you stop comparing yourself online?

---

## Lesson 81: Trust & Misinformation

**Warm-up Prompt:**

Who do you actually trust for news?

**Speaking Practice Prompts:**

- Who do you actually trust for news?
- How do you debunk a rumor with friends?
- When do you just ignore a story?

---

## Lesson 82: Team Projects

**Warm-up Prompt:**

What must a team do to keep you sane?

**Speaking Practice Prompts:**

- What must a team do to keep you sane?
- When should you escalate an issue?
- Describe a project that felt smooth.

---

## Lesson 83: Making Suggestions

**Warm-up Prompt:**

How do you suggest ideas without sounding bossy?

**Speaking Practice Prompts:**

- How do you suggest ideas without sounding bossy?
- When do you propose changes?
- What is the best suggestion someone gave you?

---

## Lesson 84: Giving Health Advice

**Warm-up Prompt:**

If a friend feels ill, what do you say first?

**Speaking Practice Prompts:**

- If a friend feels ill, what do you say first?
- What advice always seems to work for you?
- When should someone see a doctor?

---

## Lesson 85: Remote Work Challenges

**Warm-up Prompt:**

What challenges have you faced working remotely?

**Speaking Practice Prompts:**

- What challenges have you faced working remotely?
- How have you adapted at home?
- What keeps you motivated when alone?

---

## Lesson 86: Community Volunteering

**Warm-up Prompt:**

How are local events organized where you live?

**Speaking Practice Prompts:**

- How are local events organized where you live?
- Who is being helped right now?
- What makes volunteers feel appreciated?

---

## Lesson 87: Travel Mishaps

**Warm-up Prompt:**

What were you doing when your travel plans failed?

**Speaking Practice Prompts:**

- What were you doing when your travel plans failed?
- How did staff explain it to you?
- What lesson did you take away?

---

## Lesson 88: Budget Travel

**Warm-up Prompt:**

How do you travel cheaply enough for your budget?

**Speaking Practice Prompts:**

- How do you travel cheaply enough for your budget?
- When is a deal too good to trust?
- What is your best budget travel tip?

---

## Lesson 89: Future Tech Ethics

**Warm-up Prompt:**

What tech do you think will need strict rules?

**Speaking Practice Prompts:**

- What tech do you think will need strict rules?
- How are you going to handle AI tools in your life?
- What impact worries you most?

---

## Lesson 90: Wrap-Up Mix

**Warm-up Prompt:**

Which topic was most useful to you?

**Speaking Practice Prompts:**

- Which topic was most useful to you?
- What will you practice next?
- How did your skills actually improve?

---

## Lesson 91: Community Safety

**Warm-up Prompt:**

Who do you call first when there is a problem on your street?

**Speaking Practice Prompts:**

- Who do you actually trust for quick help?
- How do you share alerts with neighbors?
- When do you decide to step in?

---

## Lesson 92: Healthy Habits Check

**Warm-up Prompt:**

What happens to you if you skip your best habit?

**Speaking Practice Prompts:**

- What happens to you if you skip your best habit?
- Which small habit keeps you steady?
- How do you get back on track after a bad day?

---

## Lesson 93: Money Emergencies

**Warm-up Prompt:**

What is your plan when a big unexpected bill arrives?

**Speaking Practice Prompts:**

- What is your plan when a big unexpected bill arrives?
- When do you call the provider to negotiate?
- How do you decide to accept a payment plan?

---

## Lesson 94: Tech Boundaries

**Warm-up Prompt:**

When do you log off even if you do not want to?

**Speaking Practice Prompts:**

- When do you log off even if you do not want to?
- What rule do you set for late-night screens?
- How do you balance work apps and personal apps?

---

## Lesson 95: Relationship Advice

**Warm-up Prompt:**

What advice actually helped you in a conflict?

**Speaking Practice Prompts:**

- What advice actually helped you in a conflict?
- When do you decide to compromise?
- How do you forgive without forgetting?

---

## Lesson 96: Energy Saver at Home

**Warm-up Prompt:**

What change saved the most energy for you at home?

**Speaking Practice Prompts:**

- What change saved the most energy for you at home?
- How do you remind yourself to switch things off?
- Which upgrade felt worth the cost?

---

## Lesson 97: Social Media Breaks

**Warm-up Prompt:**

When do you decide to log off for your mental health?

**Speaking Practice Prompts:**

- When do you decide to log off for your mental health?
- How long is a break that feels enough for you?
- What do you do in your quiet time?

---

## Lesson 98: Food Budgeting

**Warm-up Prompt:**

How do you keep food costs under control?

**Speaking Practice Prompts:**

- How do you keep food costs under control?
- What meal prep trick saves you most?
- How do you cut waste at home?

---

## Lesson 99: Career Decisions

**Warm-up Prompt:**

When do you decide it is time to change jobs?

**Speaking Practice Prompts:**

- When do you decide it is time to change jobs?
- What matters more to you: benefits or growth?
- How do you discuss offers with friends or family?

---

## Lesson 100: Personal Growth Wrap-Up

**Warm-up Prompt:**

What will you focus on improving next month?

**Speaking Practice Prompts:**

- Which topic was most useful to you?
- What will you focus on improving next month?
- How will you keep yourself on track?

---

