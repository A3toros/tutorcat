-- =========================================
-- Pre-fill Database with Sample Lesson Data
-- A1-L55: Street Names
-- =========================================

DELETE FROM grammar_sentences WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'A1-L55');
DELETE FROM vocabulary_items WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'A1-L55');
DELETE FROM lesson_activities WHERE lesson_id = 'A1-L55';
DELETE FROM lessons WHERE id = 'A1-L55';

INSERT INTO lessons (id, level, lesson_number, topic) VALUES
('A1-L55', 'A1', 55, 'Street Names')
ON CONFLICT (id) DO UPDATE SET topic = EXCLUDED.topic;

DO $$
DECLARE
    lesson_id_var TEXT := 'A1-L55';
    activity_id_var UUID;
BEGIN
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'warm_up_speaking', 1, 'Street', 'Talk about street names', '{"prompt": "What is the street name here?"}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_intro', 2, 'Street Words', 'Learn street words', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'street', 'ถนน', NULL),
    (activity_id_var, 'road', 'ถนน', NULL),
    (activity_id_var, 'name', 'ชื่อ', NULL),
    (activity_id_var, 'address', 'ที่อยู่', NULL),
    (activity_id_var, 'map', 'แผนที่', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_matching_drag', 3, 'Match Street Words', 'Match street words', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'street', 'ถนน', NULL),
    (activity_id_var, 'road', 'ถนน', NULL),
    (activity_id_var, 'name', 'ชื่อ', NULL),
    (activity_id_var, 'address', 'ที่อยู่', NULL),
    (activity_id_var, 'map', 'แผนที่', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 4, 'Complete the Sentences 1', 'Fill with the correct word', '{"text": "This ___ is long. This ___ is clear.", "blanks": [{"id": "blank1", "text": "street", "options": ["street", "road", "name", "map"], "correctAnswer": "street"}, {"id": "blank2", "text": "map", "options": ["map", "address", "road", "name"], "correctAnswer": "map"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 5, 'Complete the Sentences 2', 'Fill with the correct word', '{"text": "My ___ is here. This ___ is Main Road.", "blanks": [{"id": "blank1", "text": "address", "options": ["address", "name", "street", "road"], "correctAnswer": "address"}, {"id": "blank2", "text": "street", "options": ["street", "road", "map", "name"], "correctAnswer": "street"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_explanation', 6, 'Be + Names', 'Use be with names and addresses', '{"rules": "Use be to state names/addresses.\n- This is Main Road.\n- My address is 10 Park St.\nAsk: Is this your address?", "examples": ["This is Main Road.", "This is Oak Street.", "My address is 10 Park Street.", "Is this your address?", "Is that the street name?"]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 7, 'Build Sentences 1', 'Arrange words', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'This is Main Road', 'This is Main Road.', '["This", "is", "Main", "Road."]'::jsonb),
    (activity_id_var, 'This is Oak Street', 'This is Oak Street.', '["This", "is", "Oak", "Street."]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 8, 'Build Sentences 2', 'Arrange words', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'My address is 10 Park Street', 'My address is 10 Park Street.', '["My", "address", "is", "10", "Park", "Street."]'::jsonb),
    (activity_id_var, 'Is this your address', 'Is this your address?', '["Is", "this", "your", "address?"]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'speaking_practice', 9, 'Talk About Streets', 'Practice names and addresses', '{"prompts": ["What is the street name here?", "Is this your address?", "Do you have a map?", "Is this Oak Street?", "What is your street name?"]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (
      lesson_id,
      activity_type,
      activity_order,
      title,
      description,
      content
    ) VALUES (
      'A1-L55',
      'speaking_improvement',
      10,
      'Speaking Improvement',
      'Read the improved version of your speech',
      '{"type": "speaking_improvement", "similarityThreshold": 70}'::jsonb
    );
END $$;

