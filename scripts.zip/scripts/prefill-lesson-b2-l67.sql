-- =========================================
-- Pre-fill Database with Sample Lesson Data
-- B2-L67: Online collaboration
-- =========================================

DELETE FROM grammar_sentences WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'B2-L67');
DELETE FROM vocabulary_items WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'B2-L67');
DELETE FROM lesson_activities WHERE lesson_id = 'B2-L67';
DELETE FROM lessons WHERE id = 'B2-L67';

INSERT INTO lessons (id, level, lesson_number, topic) VALUES
('B2-L67', 'B2', 67, 'Online collaboration')
ON CONFLICT (id) DO UPDATE SET topic = EXCLUDED.topic;

DO $$
DECLARE
    lesson_id_var TEXT := 'B2-L67';
    activity_id_var UUID;
BEGIN
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'warm_up_speaking', 1, 'Shared Docs', 'Talk about roles online', '{"prompt": "What must be versioned, and what should be shared early?"}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_intro', 2, 'Collaboration Words', 'Key words for shared work', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'assign', 'มอบหมาย', NULL),
    (activity_id_var, 'version', 'จัดเวอร์ชัน/บันทึกเวอร์ชัน', NULL),
    (activity_id_var, 'merge', 'รวม/ผสาน', NULL),
    (activity_id_var, 'notify', 'แจ้งเตือน', NULL),
    (activity_id_var, 'editable', 'แก้ไขได้', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_matching_drag', 3, 'Match Collaboration Words', 'Match words with meanings', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'assign', 'มอบหมาย', NULL),
    (activity_id_var, 'version', 'จัดเวอร์ชัน/บันทึกเวอร์ชัน', NULL),
    (activity_id_var, 'merge', 'รวม/ผสาน', NULL),
    (activity_id_var, 'notify', 'แจ้งเตือน', NULL),
    (activity_id_var, 'editable', 'แก้ไขได้', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 4, 'Complete the Sentences 1', 'Fill with the correct word', '{"text": "We ___ tasks in the doc. Files must be ___. We plan to ___ changes.", "blanks": [{"id": "blank1", "text": "assign", "options": ["assign", "version", "merge", "notify"], "correctAnswer": "assign"}, {"id": "blank2", "text": "versioned", "options": ["versioned", "editable", "notify", "merge"], "correctAnswer": "versioned"}, {"id": "blank3", "text": "merge", "options": ["merge", "notify", "assign", "version"], "correctAnswer": "merge"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 5, 'Complete the Sentences 2', 'Fill with the correct word', '{"text": "We keep docs ___ and ___ people on updates.", "blanks": [{"id": "blank1", "text": "editable", "options": ["editable", "assigned", "merge", "version"], "correctAnswer": "editable"}, {"id": "blank2", "text": "notify", "options": ["notify", "assign", "merge", "version"], "correctAnswer": "notify"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_explanation', 6, 'Passive with Modals', 'Set collaboration rules', '{"rules": "Use modal + be + past participle to focus on necessity.\\n- Files must be versioned.\\n- Changes should be merged.\\nUse modal + have + been + past participle for past duties.", "examples": ["Files must be versioned daily.", "Drafts should be shared early.", "Comments can be resolved before merge.", "Tasks should have been assigned already.", "Everyone must be notified of final versions."]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 7, 'Build Sentences 1', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'Files must be versioned daily', 'Files must be versioned daily.', '["Files", "must", "be", "versioned", "daily."]'::jsonb),
    (activity_id_var, 'Drafts should be shared early', 'Drafts should be shared early.', '["Drafts", "should", "be", "shared", "early."]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 8, 'Build Sentences 2', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'Tasks should have been assigned already', 'Tasks should have been assigned already.', '["Tasks", "should", "have", "been", "assigned", "already."]'::jsonb),
    (activity_id_var, 'Everyone must be notified of final versions', 'Everyone must be notified of final versions.', '["Everyone", "must", "be", "notified", "of", "final", "versions."]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'speaking_practice', 9, 'Talk About Collaboration Rules', 'Practice passive with modals', '{"prompts": ["What must be versioned first?", "What should be shared early?", "Who must be notified of changes?"]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (
      lesson_id,
      activity_type,
      activity_order,
      title,
      description,
      content
    ) VALUES (
      'B2-L67',
      'speaking_improvement',
      10,
      'Speaking Improvement',
      'Read the improved version of your speech',
      '{"type": "speaking_improvement", "similarityThreshold": 70}'::jsonb
    );
END $$;


