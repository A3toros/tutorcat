-- =========================================
-- Pre-fill Database with Sample Lesson Data
-- A2-L20: Physical Appearance
-- =========================================

DELETE FROM grammar_sentences WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'A2-L20');
DELETE FROM vocabulary_items WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'A2-L20');
DELETE FROM lesson_activities WHERE lesson_id = 'A2-L20';
DELETE FROM lessons WHERE id = 'A2-L20';

INSERT INTO lessons (id, level, lesson_number, topic) VALUES
('A2-L20', 'A2', 20, 'Physical Appearance')
ON CONFLICT (id) DO UPDATE SET topic = EXCLUDED.topic;

DO $$
DECLARE
    lesson_id_var TEXT := 'A2-L20';
    activity_id_var UUID;
BEGIN
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'warm_up_speaking', 1, 'Describe People', 'Talk about how people look', '{"prompt": "How would you describe yourself physically?"}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_intro', 2, 'Appearance Words', 'Learn words to describe people', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'tall', 'สูง', NULL),
    (activity_id_var, 'short', 'เตี้ย', NULL),
    (activity_id_var, 'hair', 'ผม', NULL),
    (activity_id_var, 'eyes', 'ตา', NULL),
    (activity_id_var, 'glasses', 'แว่นตา', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_matching_drag', 3, 'Match Appearance Words', 'Match words about looks', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'tall', 'สูง', NULL),
    (activity_id_var, 'short', 'เตี้ย', NULL),
    (activity_id_var, 'hair', 'ผม', NULL),
    (activity_id_var, 'eyes', 'ตา', NULL),
    (activity_id_var, 'glasses', 'แว่นตา', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 4, 'Complete the Sentences 1', 'Fill with the correct word', '{"text": "He is very ___. She is ___. He has brown ___. She wears ___.", "blanks": [{"id": "blank1", "text": "tall", "options": ["tall", "short", "hair", "glasses"], "correctAnswer": "tall"}, {"id": "blank2", "text": "short", "options": ["short", "tall", "hair", "eyes"], "correctAnswer": "short"}, {"id": "blank3", "text": "hair", "options": ["hair", "glasses", "eyes", "tall"], "correctAnswer": "hair"}, {"id": "blank4", "text": "glasses", "options": ["glasses", "hair", "short", "eyes"], "correctAnswer": "glasses"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 5, 'Complete the Sentences 2', 'Fill with the correct word', '{"text": "I have dark ___. My ___ are green. He is ___ than me.", "blanks": [{"id": "blank1", "text": "hair", "options": ["hair", "eyes", "tall", "glasses"], "correctAnswer": "hair"}, {"id": "blank2", "text": "eyes", "options": ["eyes", "hair", "glasses", "short"], "correctAnswer": "eyes"}, {"id": "blank3", "text": "taller", "options": ["taller", "shorter", "tall", "short"], "correctAnswer": "taller"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_explanation', 6, 'Adjectives & Comparatives', 'Describe and compare people', '{"rules": "Use be + adjective: She is tall. Use comparatives to compare two people: taller/shorter.\nPattern: X is taller than Y. Use than after the comparative.", "examples": ["She is tall.", "He is shorter than me.", "My hair is long.", "His eyes are blue.", "I am taller than my sister."]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 7, 'Build Sentences 1', 'Arrange words', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'She is tall', 'She is tall.', '["She", "is", "tall."]'::jsonb),
    (activity_id_var, 'He is shorter than me', 'He is shorter than me.', '["He", "is", "shorter", "than", "me."]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 8, 'Build Sentences 2', 'Arrange words', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'My eyes are green', 'My eyes are green.', '["My", "eyes", "are", "green."]'::jsonb),
    (activity_id_var, 'I wear glasses every day', 'I wear glasses every day.', '["I", "wear", "glasses", "every", "day."]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'speaking_practice', 9, 'Talk About Appearance', 'Practice describing looks', '{"prompts": ["How would you describe yourself?", "Do you look like anyone in your family?", "Do you wear glasses or contact lenses?", "What color is your hair?", "Are you taller or shorter than your friends?"]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (
      lesson_id,
      activity_type,
      activity_order,
      title,
      description,
      content
    ) VALUES (
      'A2-L20',
      'speaking_improvement',
      10,
      'Speaking Improvement',
      'Read the improved version of your speech',
      '{"type": "speaking_improvement", "similarityThreshold": 70}'::jsonb
    );
END $$;

