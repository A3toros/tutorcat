# CEFR Grammar Requirements by Level

## 🟢 A1 — Beginner (Foundation Grammar)

### Sentence & Word Basics
- Word order (SVO)
- Capital letters & punctuation
- Statements, questions, short answers

### Verbs
- Verb to be (am/is/are)
- Subject pronouns
- There is / There are
- Present Simple (affirmative)
- Imperatives (basic commands)

### Nouns & Articles
- Singular / plural nouns
- Countable vs uncountable (basic)
- Articles: a / an / the
- Possessive 's

### Adjectives & Adverbs
- Adjective order (basic)
- Comparatives (short adjectives)
- Expressing preferences (like/don't like)

### Determiners
- This / That / These / Those
- My / your / his / her

### Questions
- Yes/No questions
- Wh- questions (who, what, where)

### Prepositions
- Place: in / on / under / next to / at / near / behind
- Time: at / on / in

### Modal Verbs
- Can (ability, permission, prohibition)
- Must / Cannot (rules, obligations)

### Other Essential Structures
- Giving directions (imperatives)
- Describing locations and places
- Expressing possession (possessive adjectives)
- Talking about daily routines
- Making complaints and requests
- Seasonal activities and weather
- Public places and transportation
- Home and room descriptions

## 🟡 A2 — Elementary

### Verb Tenses
- Present Simple (full use)
- Present Continuous
- Past Simple (regular & irregular)
- Future: going to
- Modal can (ability, permission)

### Questions & Negatives
- Question forms in all basic tenses
- Negatives with do/does/did

### Nouns & Determiners
- Much / many / a lot of
- Some / any / no
- Quantifiers (few / little)

### Adjectives & Adverbs
- Comparative & superlative forms
- Adverbs of frequency
- Adverbs of manner

### Pronouns
- Object pronouns
- Possessive pronouns
- Reflexive pronouns (basic)

### Prepositions
- Time & place (expanded)
- Prepositions of movement

### Linking
- And / but / because / so

## 🟠 B1 — Intermediate

### Verb Tenses
- Present Perfect (experience, result)
- Past Continuous
- Future: will vs going to
- First Conditional
- Modal verbs: must / have to / should

### Verb Patterns
- Gerunds & infinitives (like, want, enjoy)
- Verb + preposition

### Voice
- Passive voice (present & past)

### Conditionals
- Zero Conditional
- First Conditional

### Reported Speech
- Statements (basic)

### Relative Clauses
- Who / which / that (defining)

### Comparison
- Too / enough
- So / such

### Articles
- Definite vs zero article

## 🔵 B2 — Upper Intermediate

### Advanced Tenses
- Present Perfect Continuous
- Past Perfect
- Future Continuous
- Future Perfect

### Conditionals
- Second Conditional
- Third Conditional
- Mixed Conditionals

### Modal Verbs
- Deduction (must / might / can't)
- Past modals (should have, could have)

### Passive Voice
- Passive with modals
- Causative: have / get something done

### Reported Speech
- Questions & commands
- Reporting verbs

### Relative Clauses
- Non-defining clauses
- Reduced relative clauses

### Linking & Discourse
- Contrast & concession (although, however)
- Reason & result

### Inversion
- Negative adverbials (Never have I...)

## 🔴 C1 — Advanced

### Tense Nuance & Aspect
- Narrative tenses
- Time-shifting & emphasis
- Advanced perfect forms

### Conditionals
- Advanced mixed conditionals
- Implied conditionals

### Modal Verbs
- Speculation & criticism in past
- Degrees of certainty

### Clause Structures
- Participle clauses
- Nominal clauses
- Embedded questions

### Voice & Emphasis
- Advanced passive forms
- Cleft sentences
- Emphatic structures

### Inversion
- Full range of inversion patterns

### Articles
- Abstract & generic reference
- Stylistic article use

## 🟣 C2 — Proficiency / Mastery

### Grammar as Style
- Register-based grammar choices
- Formal vs informal syntax
- Ellipsis & substitution

### Advanced Clause Control
- Complex subordination
- Multiple embedding
- Fronting & postposing

### Verb & Modal Mastery
- Subtle modal distinctions
- Hypothetical past discourse
- Literary tense usage

### Discourse Grammar
- Cohesion & coherence devices
- Reference chains
- Information structure

### Transformations
- Sentence re-writing at native level
- Meaning-preserving transformations

### Idiomatic & Fixed Structures
- Lexicalized grammar
- Set grammatical phrases
