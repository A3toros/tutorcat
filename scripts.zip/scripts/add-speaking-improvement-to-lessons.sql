-- =========================================
-- Add speaking_improvement activity to all lessons
-- This script adds the speaking_improvement activity after speaking_practice
-- for all lessons that don't already have it
-- =========================================

DO $$
DECLARE
    lesson_record RECORD;
    speaking_activity_record RECORD;
    max_activity_order INTEGER;
    improvement_exists BOOLEAN;
BEGIN
    -- Loop through all lessons
    FOR lesson_record IN 
        SELECT DISTINCT lesson_id 
        FROM lesson_activities 
        WHERE activity_type IN ('speaking_practice', 'speaking_with_feedback')
        AND active = TRUE
    LOOP
        -- Check if speaking_improvement already exists for this lesson
        SELECT EXISTS(
            SELECT 1 
            FROM lesson_activities 
            WHERE lesson_id = lesson_record.lesson_id 
            AND activity_type = 'speaking_improvement'
            AND active = TRUE
        ) INTO improvement_exists;
        
        -- Only add if it doesn't exist
        IF NOT improvement_exists THEN
            -- Find the highest activity_order for speaking practice activities in this lesson
            SELECT MAX(activity_order) 
            INTO max_activity_order
            FROM lesson_activities
            WHERE lesson_id = lesson_record.lesson_id
            AND activity_type IN ('speaking_practice', 'speaking_with_feedback')
            AND active = TRUE;
            
            -- If we found a speaking activity, add improvement activity after it
            IF max_activity_order IS NOT NULL THEN
                INSERT INTO lesson_activities (
                    lesson_id,
                    activity_type,
                    activity_order,
                    title,
                    description,
                    content,
                    active
                ) VALUES (
                    lesson_record.lesson_id,
                    'speaking_improvement',
                    max_activity_order + 1,
                    'Speaking Improvement',
                    'Read the improved version of your speech',
                    '{"type": "speaking_improvement", "similarityThreshold": 70}'::jsonb,
                    TRUE
                );
                
                RAISE NOTICE 'Added speaking_improvement to lesson % at order %', lesson_record.lesson_id, max_activity_order + 1;
            END IF;
        ELSE
            RAISE NOTICE 'Lesson % already has speaking_improvement, skipping', lesson_record.lesson_id;
        END IF;
    END LOOP;
    
    RAISE NOTICE 'Finished adding speaking_improvement activities to all lessons';
END $$;

-- Verify the results
SELECT 
    l.id as lesson_id,
    l.topic,
    COUNT(CASE WHEN la.activity_type = 'speaking_practice' OR la.activity_type = 'speaking_with_feedback' THEN 1 END) as speaking_activities,
    COUNT(CASE WHEN la.activity_type = 'speaking_improvement' THEN 1 END) as improvement_activities,
    MAX(CASE WHEN la.activity_type IN ('speaking_practice', 'speaking_with_feedback') THEN la.activity_order END) as last_speaking_order,
    MAX(CASE WHEN la.activity_type = 'speaking_improvement' THEN la.activity_order END) as improvement_order
FROM lessons l
LEFT JOIN lesson_activities la ON l.id = la.lesson_id AND la.active = TRUE
WHERE EXISTS (
    SELECT 1 
    FROM lesson_activities 
    WHERE lesson_id = l.id 
    AND activity_type IN ('speaking_practice', 'speaking_with_feedback')
    AND active = TRUE
)
GROUP BY l.id, l.topic
ORDER BY l.id;
