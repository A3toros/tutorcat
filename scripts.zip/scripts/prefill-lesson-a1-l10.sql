-- =========================================
-- Pre-fill Database with Sample Lesson Data
-- A1-L10: Basic Directions
-- =========================================

-- Clear existing sample data for A1-L10 (optional - comment out if you want to keep existing data)
DELETE FROM lesson_activity_results WHERE lesson_id = 'A1-L10';
DELETE FROM user_progress WHERE lesson_id = 'A1-L10';
DELETE FROM lesson_history WHERE lesson_id = 'A1-L10';
DELETE FROM grammar_sentences WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'A1-L10');
DELETE FROM vocabulary_items WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'A1-L10');
DELETE FROM lesson_activities WHERE lesson_id = 'A1-L10';
DELETE FROM lessons WHERE id = 'A1-L10';

INSERT INTO lessons (id, level, lesson_number, topic) VALUES
('A1-L10', 'A1', 10, 'Basic Directions')
ON CONFLICT (id) DO UPDATE SET topic = EXCLUDED.topic;

DO $$
DECLARE
    lesson_id_var TEXT := 'A1-L10';
    activity_id_var UUID;
BEGIN
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content) VALUES (lesson_id_var, 'warm_up_speaking', 1, 'Finding Places', 'How do you find places?', '{"prompt": "How do you get to school?"}'::jsonb) RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content) VALUES (lesson_id_var, 'vocabulary_intro', 2, 'Direction Words', 'Learn direction vocabulary', '{}'::jsonb) RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'left', 'ซ้าย', NULL),
    (activity_id_var, 'right', 'ขวา', NULL),
    (activity_id_var, 'straight', 'ตรง', NULL),
    (activity_id_var, 'turn', 'เลี้ยว', NULL),
    (activity_id_var, 'corner', 'มุม', NULL);

    -- 3. Vocabulary Matching Drag #1 (5 pairs - same words)
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content) VALUES (lesson_id_var, 'vocabulary_matching_drag', 3, 'Match Direction Words 1', 'Match English words with Thai meanings', '{}'::jsonb) RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'left', 'ซ้าย', NULL),
    (activity_id_var, 'right', 'ขวา', NULL),
    (activity_id_var, 'straight', 'ตรง', NULL),
    (activity_id_var, 'turn', 'เลี้ยว', NULL),
    (activity_id_var, 'corner', 'มุม', NULL);

    

    -- 4. Vocabulary Fill Blanks #1 (4 words: left, right, straight, turn - corner left out)
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content) VALUES (lesson_id_var, 'vocabulary_fill_blanks', 4, 'Complete the Sentences 1', 'Fill in the blanks with correct words', '{"text": "Go ___ ahead for 100 meters. Then ___ left at the traffic light. After that, turn ___ at the next street. And finally, turn ___ again", "blanks": [{"id": "blank1", "text": "straight", "options": ["sit", "go", "straight", "stand"], "correctAnswer": "straight"}, {"id": "blank2", "text": "turn", "options": ["left", "right", "straight", "turn"], "correctAnswer": "turn"}, {"id": "blank3", "text": "left", "options": ["left", "move", "stand", "turn"], "correctAnswer": "left"}, {"id": "blank4", "text": "right", "options": ["pay", "right", "go", "down"], "correctAnswer": "right"}]}'::jsonb) RETURNING id INTO activity_id_var;

    -- 4. Vocabulary Fill Blanks #2 (4 words: left, right, straight, corner - turn left out)
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content) VALUES (lesson_id_var, 'vocabulary_fill_blanks', 5, 'Complete the Sentences 2', 'Fill in the blanks with correct words', '{"text": "Go ___ for two blocks. Turn ___ at the ___. Then turn ___ at the next street.", "blanks": [{"id": "blank1", "text": "straight", "options": ["go", "some", "straight", "more"], "correctAnswer": "straight"}, {"id": "blank2", "text": "left", "options": ["left", "pay", "see", "corner"], "correctAnswer": "left"}, {"id": "blank3", "text": "corner", "options": ["left", "right", "straight", "corner"], "correctAnswer": "corner"}, {"id": "blank4", "text": "right", "options": ["cross", "right", "say", "walk"], "correctAnswer": "right"}]}'::jsonb) RETURNING id INTO activity_id_var;

    -- 4. Grammar Explanation (5 examples)
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content) VALUES (lesson_id_var, 'grammar_explanation', 6, 'Giving Directions', 'Learn to give directions', '{"rules": "Use imperative form to give directions:\n\n- Go + direction (Go straight)\n- Turn + direction (Turn left)\n- Use ''at'' for locations (Turn at the corner)\n- Use ''on'' for streets (It is on Main Street)\n- Use ''past'' for passing (Go past the school)", "examples": ["Go straight ahead.", "Turn left at the corner.", "Turn right at the traffic light.", "Go past the school.", "It is on your left."]}'::jsonb) RETURNING id INTO activity_id_var;

    -- 4. Grammar Sentences #1
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content) VALUES (lesson_id_var, 'grammar_sentences', 7, 'Build Sentences 1', 'Arrange words to make sentences', '{}'::jsonb) RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'Go straight ahead', 'Go straight ahead', '["Go", "straight", "ahead"]'::jsonb),
    (activity_id_var, 'Turn left at the corner', 'Turn left at the corner', '["Turn", "left", "at", "the", "corner"]'::jsonb);
    -- 4. Grammar Sentences #2
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content) VALUES (lesson_id_var, 'grammar_sentences', 8, 'Build Sentences 2', 'Arrange words to make sentences', '{}'::jsonb) RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'Turn right at the traffic light', 'Turn right at the traffic light', '["Turn", "right", "at", "the", "traffic", "light"]'::jsonb),
    (activity_id_var, 'It is on your left', 'It is on your left', '["It", "is", "on", "your", "left"]'::jsonb);
    -- 4. Speaking Practice (5 prompts - CEFR A1)
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content) VALUES (lesson_id_var, 'speaking_practice', 9, 'Give Directions', 'Practice giving directions', '{"prompts": ["How do you get to the hospital from here?", "Where is the school?", "Can you tell me the way to the grocery store?", "Is the mall far from here?", "Which way is the cinema?"]}'::jsonb) RETURNING id INTO activity_id_var;

END $$;
INSERT INTO lesson_activities (
  lesson_id,
  activity_type,
  activity_order,
  title,
  description,
  content
) VALUES (
  'A1-L10',
  'speaking_improvement',
  10,
  'Speaking Improvement',
  'Read the improved version of your speech',
  '{"type": "speaking_improvement", "similarityThreshold": 70}'::jsonb
);
