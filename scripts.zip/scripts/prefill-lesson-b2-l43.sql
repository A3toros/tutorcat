-- =========================================
-- Pre-fill Database with Sample Lesson Data
-- B2-L43: Sleep and productivity (signals)
-- =========================================

DELETE FROM grammar_sentences WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'B2-L43');
DELETE FROM vocabulary_items WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'B2-L43');
DELETE FROM lesson_activities WHERE lesson_id = 'B2-L43';
DELETE FROM lessons WHERE id = 'B2-L43';

INSERT INTO lessons (id, level, lesson_number, topic) VALUES
('B2-L43', 'B2', 43, 'Sleep and productivity (signals)')
ON CONFLICT (id) DO UPDATE SET topic = EXCLUDED.topic;

DO $$
DECLARE
    lesson_id_var TEXT := 'B2-L43';
    activity_id_var UUID;
BEGIN
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'warm_up_speaking', 1, 'Rest Cues', 'Talk about signs of good/poor sleep', '{"prompt": "What signals poor sleep, and how can you tell you’re alert?"}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_intro', 2, 'Sleep Signal Words', 'Key words for rest cues', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'alert', 'ตื่นตัว', NULL),
    (activity_id_var, 'groggy', 'งัวเงีย/มึนงง', NULL),
    (activity_id_var, 'nap', 'งีบ', NULL),
    (activity_id_var, 'routine', 'กิจวัตร', NULL),
    (activity_id_var, 'cycle', 'รอบ/วงจร', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_matching_drag', 3, 'Match Sleep Signal Words', 'Match words with meanings', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'alert', 'ตื่นตัว', NULL),
    (activity_id_var, 'groggy', 'งัวเงีย/มึนงง', NULL),
    (activity_id_var, 'nap', 'งีบ', NULL),
    (activity_id_var, 'routine', 'กิจวัตร', NULL),
    (activity_id_var, 'cycle', 'รอบ/วงจร', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 4, 'Complete the Sentences 1', 'Fill with the correct word', '{"text": "A solid sleep ___ keeps me ___. A short ___ helps midday.", "blanks": [{"id": "blank1", "text": "cycle", "options": ["cycle", "alert", "nap", "routine"], "correctAnswer": "cycle"}, {"id": "blank2", "text": "alert", "options": ["alert", "groggy", "nap", "routine"], "correctAnswer": "alert"}, {"id": "blank3", "text": "nap", "options": ["nap", "groggy", "cycle", "routine"], "correctAnswer": "nap"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 5, 'Complete the Sentences 2', 'Fill with the correct word', '{"text": "Without a steady ____, I feel ___.", "blanks": [{"id": "blank1", "text": "routine", "options": ["routine", "cycle", "nap", "alert"], "correctAnswer": "routine"}, {"id": "blank2", "text": "groggy", "options": ["groggy", "alert", "cycle", "nap"], "correctAnswer": "groggy"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_explanation', 6, 'Modals for Deduction', 'Judge rest quality', '{"rules": "Use must/might/can’t + base verb to deduce now; use modal + have + past participle for past clues.\\n- He must be tired; he looks groggy.\\n- She might have slept early; she is alert.", "examples": ["I must be under-slept; I can’t focus.", "She might be fully rested; she looks alert.", "He can’t be rested; he is yawning.", "They must have stayed up; they are groggy.", "You might have hit a good cycle; you are focused."]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 7, 'Build Sentences 1', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'I must be under-slept; I can’t focus', 'I must be under-slept; I can’t focus.', '["I", "must", "be", "under-slept;", "I", "can’t", "focus."]'::jsonb),
    (activity_id_var, 'She might be fully rested; she looks alert', 'She might be fully rested; she looks alert.', '["She", "might", "be", "fully", "rested;", "she", "looks", "alert."]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 8, 'Build Sentences 2', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'They must have stayed up; they are groggy', 'They must have stayed up; they are groggy.', '["They", "must", "have", "stayed", "up;", "they", "are", "groggy."]'::jsonb),
    (activity_id_var, 'This can’t be enough rest; I’m still yawning', 'This can’t be enough rest; I’m still yawning.', '["This", "can’t", "be", "enough", "rest;", "I’m", "still", "yawning."]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'speaking_practice', 9, 'Talk About Sleep Signals', 'Practice deduction', '{"prompts": ["What signals poor sleep for you?", "How can you tell you are alert?", "When do you decide to nap?"]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (
      lesson_id,
      activity_type,
      activity_order,
      title,
      description,
      content
    ) VALUES (
      'B2-L43',
      'speaking_improvement',
      10,
      'Speaking Improvement',
      'Read the improved version of your speech',
      '{"type": "speaking_improvement", "similarityThreshold": 70}'::jsonb
    );
END $$;


