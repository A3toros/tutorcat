# A1 Speaking Prompts

This file contains all warm-up and speaking practice prompts for A1 lessons.

---

## Lesson 1: Personal Information

**Warm-up Prompt:**

Tell me your name and where you are from.

**Speaking Practice Prompts:**

- What is your name?
- Where are you from?
- Where do you study?
- How old are you?
- What is your hobby?

---

## Lesson 2: Family & Friends

**Warm-up Prompt:**

Tell me about your family.

**Speaking Practice Prompts:**

- How many people are there in your family?
- What does your mother do?
- Do you have brothers or sisters?
- What does your father do?
- Who is your best friend?

---

## Lesson 3: Daily Routines

**Warm-up Prompt:**

What do you do every day?

**Speaking Practice Prompts:**

- What time do you wake up?
- What do you do in the morning?
- When do you go to school?
- What time do you have lunch?
- When do you go to bed?

---

## Lesson 4: Food & Drinks

**Warm-up Prompt:**

What is your favorite food?

**Speaking Practice Prompts:**

- What food do you like?
- What food don
- t you like?
- What is your favorite dish?
- Do you like spicy food?
- What do you eat for breakfast?

---

## Lesson 5: Hobbies & Free Time

**Warm-up Prompt:**

What do you like to do in your free time?

**Speaking Practice Prompts:**

- What do you do in your free time?
- Do you like reading? What do you read?
- What sports do you play?
- Do you watch TV? What do you watch?
- What music do you like?

---

## Lesson 6: Places in Town

**Warm-up Prompt:**

What places do you visit in your town?

**Speaking Practice Prompts:**

- Where is the closest shopping mall?
- Is there a school near you?
- Where do you go shopping?
- What is your favorite place in the city?
- What is your favorite cafe?

---

## Lesson 7: Home & Rooms

**Warm-up Prompt:**

Tell me about your home.

**Speaking Practice Prompts:**

- How many rooms are there in your house?
- What is in your bedroom?
- Where do you cook?
- What is in the living room?
- What is in the bathroom?

---

## Lesson 8: Numbers, Dates & Time

**Warm-up Prompt:**

What time do you usually wake up?

**Speaking Practice Prompts:**

- What time is it now?
- What time do you wake up?
- When do you have lunch?
- What time do you go to bed?
- What do you do on weekends?

---

## Lesson 9: Weather & Seasons

**Warm-up Prompt:**

What is the weather like today?

**Speaking Practice Prompts:**

- What is the weather like today?
- Do you like sunny weather?
- What weather do you prefer?
- What do you do when it is cold?
- What do you do when it rains?

---

## Lesson 10: Basic Directions

**Warm-up Prompt:**

How do you get to school?

**Speaking Practice Prompts:**

- How do you get to the hospital from here?
- Where is the school?
- Can you tell me the way to the grocery store?
- Is the mall far from here?
- Which way is the cinema?

---

## Lesson 11: Classroom Objects

**Warm-up Prompt:**

What do you have on your desk?

**Speaking Practice Prompts:**

- Is this your pen?
- What is that?
- Where is your book?
- Is this desk yours?
- Do you like this chair?

---

## Lesson 12: Weather & Seasons

**Warm-up Prompt:**

How is the weather today?

**Speaking Practice Prompts:**

- How is the weather?
- Do you like rain?
- Is it hot today?
- Do you like cold days?
- What season do you like?

---

## Lesson 13: Clothes

**Warm-up Prompt:**

What do you wear today?

**Speaking Practice Prompts:**

- What do you wear today?
- Do you like hats?
- Are your shoes new?
- Is this your jacket?
- Do you wear pants or a skirt?

---

## Lesson 14: Numbers 1–100

**Warm-up Prompt:**

What numbers do you use every day?

**Speaking Practice Prompts:**

- How old are you?
- What is your favorite number?
- How many books do you have?
- How many chairs are there?
- Do you like big numbers?

---

## Lesson 15: Family & Friends

**Warm-up Prompt:**

Who is in your family?

**Speaking Practice Prompts:**

- Who is in your family?
- Is he your brother?
- Do you have sisters?
- Who is your friend?
- Do you live with your mother?

---

## Lesson 16: Food You Like

**Warm-up Prompt:**

What food do you like?

**Speaking Practice Prompts:**

- What food do you like?
- Do you like rice?
- Do you like salad?
- Do you like soup?
- Do you cook at home?

---

## Lesson 17: Countries & Nationalities

**Warm-up Prompt:**

Where are you from?

**Speaking Practice Prompts:**

- Where are you from?
- Are you from Thailand?
- What city are you from?
- Is your friend Thai?
- Is he from Korea?

---

## Lesson 18: Your Bedroom

**Warm-up Prompt:**

What is in your bedroom?

**Speaking Practice Prompts:**

- What is in your bedroom?
- Is there a lamp?
- How many windows?
- Is your bed big?
- Do you have a closet?

---

## Lesson 19: Saying Hello and Goodbye

**Warm-up Prompt:**

How do you say hello?

**Speaking Practice Prompts:**

- How do you say hello?
- Do you wave goodbye?
- Do you say good morning?
- Do you say good night?
- Are you free now?

---

## Lesson 20: Transport (car, bus, train)

**Warm-up Prompt:**

Do you take the bus?

**Speaking Practice Prompts:**

- Do you take the bus?
- Can you drive?
- Do you like trains?
- Do you buy a ticket?
- Is the driver kind?

---

## Lesson 21: Colors

**Warm-up Prompt:**

What is your favorite color?

**Speaking Practice Prompts:**

- What is your favorite color?
- Is your bag blue?
- Do you like red shoes?
- Are your shoes black?
- Is the board white?

---

## Lesson 22: Daily Routines

**Warm-up Prompt:**

When do you wake up?

**Speaking Practice Prompts:**

- When do you wake up?
- Do you study at night?
- Do you sleep early?
- Do you eat breakfast?
- Do you go to school?

---

## Lesson 23: Animals

**Warm-up Prompt:**

Do you have a pet?

**Speaking Practice Prompts:**

- Do you have a pet?
- Is the cat small?
- Do you like dogs?
- Can the bird fly?
- Is the fish in water?

---

## Lesson 24: Asking Simple Questions

**Warm-up Prompt:**

What is your name?

**Speaking Practice Prompts:**

- What is your name?
- Where are you?
- Who is he?
- Are you here?
- Is she a student?

---

## Lesson 25: Places in Town

**Warm-up Prompt:**

Is there a park?

**Speaking Practice Prompts:**

- Is there a park?
- Where is the bank?
- Do you go to the shop?
- Is there a school near you?
- Is the street busy?

---

## Lesson 26: Fruits

**Warm-up Prompt:**

Do you like apples?

**Speaking Practice Prompts:**

- Do you like apples?
- How many bananas do you eat?
- Do you like oranges?
- Do you like mango?
- Do you like grapes?

---

## Lesson 27: Jobs (basic)

**Warm-up Prompt:**

Are you a student?

**Speaking Practice Prompts:**

- Are you a student?
- Is he a driver?
- Is she a doctor?
- Are you a teacher?
- Do you like this job?

---

## Lesson 28: Telling the Time (basic)

**Warm-up Prompt:**

What time is it?

**Speaking Practice Prompts:**

- What time is it?
- Is it morning?
- Is it evening?
- Do you wake up at six?
- Do you sleep at ten?

---

## Lesson 29: Personal Objects

**Warm-up Prompt:**

Is this your phone?

**Speaking Practice Prompts:**

- Is this your phone?
- Where are your keys?
- Is that your bag?
- Is this your watch?
- Do you have your wallet?

---

## Lesson 30: Sports You Play

**Warm-up Prompt:**

Can you swim?

**Speaking Practice Prompts:**

- Can you swim?
- Do you play soccer?
- Do you run fast?
- Do you have a ball?
- Do you play with friends?

---

## Lesson 31: Months of the Year

**Warm-up Prompt:**

When is your birthday?

**Speaking Practice Prompts:**

- When is your birthday?
- Do you travel in April?
- Is your exam in February?
- Do you rest in January?
- Is school in March?

---

## Lesson 32: Home & Rooms

**Warm-up Prompt:**

How many rooms are in your home?

**Speaking Practice Prompts:**

- How many rooms are in your home?
- Is there a kitchen?
- Is there a bathroom?
- Is the door open?
- Is there a living room?

---

## Lesson 33: Teacher and Students

**Warm-up Prompt:**

Do you listen in class?

**Speaking Practice Prompts:**

- Do you listen in class?
- Do you write notes?
- Do you stand up in class?
- Do you read in class?
- Do you sit in front?

---

## Lesson 34: Shoes and Accessories

**Warm-up Prompt:**

Are your shoes black?

**Speaking Practice Prompts:**

- Are your shoes black?
- Do you wear socks?
- Do you have a bag?
- Do you wear a belt?
- Do you like hats?

---

## Lesson 35: Zoo and Farm Animals

**Warm-up Prompt:**

Do you like cows?

**Speaking Practice Prompts:**

- Do you like cows?
- Is the tiger big?
- Is the pig small?
- Are monkeys funny?
- Do you like elephants?

---

## Lesson 36: Prices (cheap / expensive)

**Warm-up Prompt:**

Is it cheap?

**Speaking Practice Prompts:**

- Is it cheap?
- Is it expensive?
- What is the price?
- Do you have coins?
- Do you pay with cash?

---

## Lesson 37: Your Body

**Warm-up Prompt:**

How many eyes do you have?

**Speaking Practice Prompts:**

- How many eyes do you have?
- Do you have long legs?
- Do you have big hands?
- Do you have a small head?
- Do you have a big mouth?

---

## Lesson 38: Shopping for Clothes

**Warm-up Prompt:**

Can I try this?

**Speaking Practice Prompts:**

- Can I try this?
- Can I see this size?
- Can I pay here?
- Do you like this shirt?
- Do you want to buy it?

---

## Lesson 39: Languages You Speak

**Warm-up Prompt:**

Can you speak English?

**Speaking Practice Prompts:**

- Can you speak English?
- Can you speak Thai?
- Do you want to learn?
- Is English easy?
- Do you speak with friends?

---

## Lesson 40: Basic Directions

**Warm-up Prompt:**

Go left or right?

**Speaking Practice Prompts:**

- Go left or right?
- Do I turn here?
- Do I go straight?
- Do you go to the park?
- Do you turn right?

---

## Lesson 41: Breakfast, Lunch, Dinner

**Warm-up Prompt:**

What do you eat for breakfast?

**Speaking Practice Prompts:**

- What do you eat for breakfast?
- Do you eat breakfast?
- Do you drink juice in the morning?
- Do you eat lunch at school?
- Do you eat dinner early?

---

## Lesson 42: Furniture

**Warm-up Prompt:**

Is there a sofa?

**Speaking Practice Prompts:**

- Is there a sofa?
- How many chairs?
- Is there a bed?
- Is the shelf next to the table?
- Do you have a table?

---

## Lesson 43: Likes and Dislikes

**Warm-up Prompt:**

What do you like?

**Speaking Practice Prompts:**

- What do you like?
- Do you like rice?
- Do you like tea?
- Do you hate rain?
- What is your favorite food?

---

## Lesson 44: Days of the Week

**Warm-up Prompt:**

What day is today?

**Speaking Practice Prompts:**

- What day is today?
- Do you study on Monday?
- Do you work on Tuesday?
- Do you rest on Friday?
- What day do you like?

---

## Lesson 45: Going to School or Work

**Warm-up Prompt:**

Do you walk to school?

**Speaking Practice Prompts:**

- How do you go to school?
- Do you like walking?
- What time do you leave home?
- Are you ever late?
- What do you carry to school?

---

## Lesson 46: Bathroom Objects

**Warm-up Prompt:**

Is there a towel?

**Speaking Practice Prompts:**

- What do you see in your bathroom?
- Is there a mirror in the bathroom?
- What color is your towel?
- Where is the soap?
- Is there a sink?

---

## Lesson 47: Favorite Things

**Warm-up Prompt:**

Do you like rice?

**Speaking Practice Prompts:**

- What is your favorite food?
- Do you like listening to music?
- What games do you play?
- What is your favorite movie?
- Do you like reading books?

---

## Lesson 48: Near and Far

**Warm-up Prompt:**

Is this near?

**Speaking Practice Prompts:**

- Where is your school?
- Is your home near the school?
- What is near your house?
- What is far from your house?
- Where are you now?

---

## Lesson 49: Pets

**Warm-up Prompt:**

Do you have a dog?

**Speaking Practice Prompts:**

- Do you have a pet?
- What animals do you like?
- Do you want a dog or cat?
- What is your favorite pet?
- Do you like cats or dogs?

---

## Lesson 50: Money (coins and notes)

**Warm-up Prompt:**

How much is this?

**Speaking Practice Prompts:**

- How much is your lunch?
- Do you save money?
- What do you buy with coins?
- How much money do you have?
- Do you use coins or notes?

---

## Lesson 51: Your House

**Warm-up Prompt:**

Is there a garden?

**Speaking Practice Prompts:**

- Is there a garden?
- How many floors?
- Is the gate big?
- Is there a roof?
- Is there one house or two?

---

## Lesson 52: Left and Right

**Warm-up Prompt:**

Turn left or right?

**Speaking Practice Prompts:**

- Turn left or right?
- Do I stop here?
- Do I walk straight?
- Do you run or walk?
- Do you turn at the gate?

---

## Lesson 53: Meat and Fish

**Warm-up Prompt:**

Do you eat fish?

**Speaking Practice Prompts:**

- Do you eat fish?
- Do you eat meat?
- Do you like chicken?
- Do you eat beef?
- Do you like pork?

---

## Lesson 54: What You Are Wearing

**Warm-up Prompt:**

What are you wearing?

**Speaking Practice Prompts:**

- What are you wearing?
- Are you wearing shoes?
- Is your shirt blue?
- Are your pants black?
- Is he wearing a hat?

---

## Lesson 55: Street Names

**Warm-up Prompt:**

What is the street name here?

**Speaking Practice Prompts:**

- What is the street name here?
- Is this your address?
- Do you have a map?
- Is this Oak Street?
- What is your street name?

---

## Lesson 56: Parts of the Face

**Warm-up Prompt:**

Do you have long hair?

**Speaking Practice Prompts:**

- Do you have long hair?
- Do you have big eyes?
- Do you have a small nose?
- Do you have big ears?
- Do you have a big mouth?

---

## Lesson 57: At the Supermarket

**Warm-up Prompt:**

Can I have a bag?

**Speaking Practice Prompts:**

- Can I have a bag?
- What is the price?
- Where do I pay?
- Can I stand in this line?
- Can you show the price?

---

## Lesson 58: Simple Games

**Warm-up Prompt:**

Do you play cards?

**Speaking Practice Prompts:**

- Do you play cards?
- Do you play with a ball?
- Do I move here?
- Do you like to win?
- Do you wait your turn?

---

## Lesson 59: Saying Hungry / Thirsty

**Warm-up Prompt:**

Are you hungry?

**Speaking Practice Prompts:**

- Are you hungry?
- Are you thirsty?
- Are you full?
- Are you tired now?
- Are you okay?

---

## Lesson 60: Work Time (morning/afternoon)

**Warm-up Prompt:**

Do you work in the morning?

**Speaking Practice Prompts:**

- Do you work in the morning?
- Do you work in the afternoon?
- Are you early?
- Are you late?
- Do you work at night?

---

## Lesson 61: Kitchen Objects

**Warm-up Prompt:**

Is there a spoon?

**Speaking Practice Prompts:**

- Is there a spoon?
- How many cups?
- Is there a bowl?
- Do you have a plate?
- Is there a fork?

---

## Lesson 62: Introducing Yourself

**Warm-up Prompt:**

What is your name?

**Speaking Practice Prompts:**

- What is your name?
- How old are you?
- Where are you from?
- Where do you live?
- Can you say hello?

---

## Lesson 63: Maps (very basic)

**Warm-up Prompt:**

Is this the right place?

**Speaking Practice Prompts:**

- Is this the right place?
- Do I go here?
- Do I go there?
- Can you point to your home?
- Is this the line?

---

## Lesson 64: Drinks You Like

**Warm-up Prompt:**

Do you like juice?

**Speaking Practice Prompts:**

- Do you like juice?
- Do you like tea?
- Do you like coffee?
- Do you like water?
- Do you like milk?

---

## Lesson 65: Cleaning and Tidying

**Warm-up Prompt:**

Do you clean your room?

**Speaking Practice Prompts:**

- Do you clean your room?
- Do you wash dishes?
- Do you sweep the floor?
- Do you tidy the bed?
- Do you take out trash?

---

## Lesson 66: Feeling Tired / Sick / Well

**Warm-up Prompt:**

Are you tired?

**Speaking Practice Prompts:**

- Are you tired?
- Are you sick?
- Are you well today?
- Do you need rest?
- Are you fine now?

---

## Lesson 67: School Subjects

**Warm-up Prompt:**

Do you like math?

**Speaking Practice Prompts:**

- Do you like math?
- Do you like English?
- Do you like art?
- Do you like music?
- Do you like sport?

---

## Lesson 68: Traffic Lights

**Warm-up Prompt:**

Do you wait at red lights?

**Speaking Practice Prompts:**

- Do you wait at red lights?
- Do you go on green?
- Is yellow slow?
- Do you stop here?
- Do you run on red?

---

## Lesson 69: Choosing Things

**Warm-up Prompt:**

Can I choose this?

**Speaking Practice Prompts:**

- Can I choose this?
- Do you want that?
- Do you need this?
- Can I have that?
- Do you like this one?

---

## Lesson 70: Uniforms

**Warm-up Prompt:**

Do you wear a uniform?

**Speaking Practice Prompts:**

- Do you wear a uniform?
- Is your shirt white?
- Are your shoes black?
- Do you wear pants?
- Is your skirt long?

---

## Lesson 71: Personal Information

**Warm-up Prompt:**

What is your name?

**Speaking Practice Prompts:**

- What is your name?
- How old are you?
- Where are you from?
- Where do you live?
- What is your email?

---

## Lesson 72: Snacks

**Warm-up Prompt:**

Do you like snacks?

**Speaking Practice Prompts:**

- Do you like snacks?
- Do you want some chips?
- Do you like cookies?
- Do you like candy?
- Do you eat fruit?

---

## Lesson 73: Asking Where Something Is

**Warm-up Prompt:**

Where is the bag?

**Speaking Practice Prompts:**

- Where is the bag?
- Is it here?
- Is it there?
- Is it near?
- Where is the book?

---

## Lesson 74: Simple Preferences

**Warm-up Prompt:**

Do you like tea or coffee?

**Speaking Practice Prompts:**

- Do you like tea or coffee?
- Do you prefer rice?
- Do you hate rain?
- Do you love music?
- Is rice okay?

---

## Lesson 75: Visiting a Doctor (very basic)

**Warm-up Prompt:**

Can you help me?

**Speaking Practice Prompts:**

- Can you help me?
- Where is the pain?
- Do I need medicine?
- Is your head okay?
- Is your arm hurt?

---

## Lesson 76: Work or Study

**Warm-up Prompt:**

Do you work?

**Speaking Practice Prompts:**

- Do you work?
- Do you study?
- Are you busy?
- Do you have a job?
- Do you go to school?

---

## Lesson 77: Where Things Are (in/on/under)

**Warm-up Prompt:**

Is it on the table?

**Speaking Practice Prompts:**

- Is it on the table?
- Is it under the bed?
- Is it next to you?
- Is it in the box?
- Is it between the chairs?

---

## Lesson 78: Favorite Colors

**Warm-up Prompt:**

Do you like pink?

**Speaking Practice Prompts:**

- Do you like pink?
- Do you like purple?
- Is your bag orange?
- Is your shirt gray?
- What color do you like?

---

## Lesson 79: Buying Tickets

**Warm-up Prompt:**

Can I buy a ticket?

**Speaking Practice Prompts:**

- Can I buy a ticket?
- Is this seat free?
- Do you take the bus?
- Can I pay here?
- Do you take the train?

---

## Lesson 80: Simple Work Tools

**Warm-up Prompt:**

Is this your pen?

**Speaking Practice Prompts:**

- Is this your pen?
- Is that your key?
- Do you need this card?
- Is this your box?
- Do you have paper?

---

## Lesson 81: Sizes (big, small, long, short)

**Warm-up Prompt:**

Is it big or small?

**Speaking Practice Prompts:**

- Is it big or small?
- Is the road long?
- Is the ruler short?
- Are you tall?
- Is your bag big?

---

## Lesson 82: Vegetables

**Warm-up Prompt:**

Do you like carrots?

**Speaking Practice Prompts:**

- Do you like carrots?
- Do you like tomatoes?
- Do you buy onions?
- Do you like potatoes?
- Is corn sweet?

---

## Lesson 83: People at Work

**Warm-up Prompt:**

Is he a chef?

**Speaking Practice Prompts:**

- Is he a chef?
- Is she a nurse?
- Is he a guard?
- Is she a clerk?
- Is he a farmer?

---

## Lesson 84: Crossing the Street

**Warm-up Prompt:**

Do you look left?

**Speaking Practice Prompts:**

- Do you look left?
- Do you look right?
- Do you stop first?
- Do you run or walk?
- Do you cross now?

---

## Lesson 85: Hobbies & Free Time

**Warm-up Prompt:**

Do you like to read?

**Speaking Practice Prompts:**

- Do you like to read?
- Do you like to draw?
- Do you like to sing?
- Do you like to dance?
- Do you like to play games?

---

## Lesson 86: Ordering Simple Food

**Warm-up Prompt:**

Can I order rice?

**Speaking Practice Prompts:**

- Can I order rice?
- Can I have water?
- Can I see the menu?
- Can I pay here?
- Do you want the bill?

---

## Lesson 87: Tidy Your Room

**Warm-up Prompt:**

Do you tidy your room?

**Speaking Practice Prompts:**

- Do you tidy your room?
- Do you fold clothes?
- Do you pick toys?
- Do you take out trash?
- Do you clean the room?

---

## Lesson 88: Dream Job (simple)

**Warm-up Prompt:**

What job do you want?

**Speaking Practice Prompts:**

- What job do you want?
- Is that your dream job?
- Do you like this job?
- Do you want to be a doctor?
- Do you want to be a chef?

---

## Lesson 89: Please, Thank You, Sorry

**Warm-up Prompt:**

Do you say please?

**Speaking Practice Prompts:**

- Do you say please?
- Do you say thank you?
- Do you say sorry?
- Do you say excuse me?
- Do you say welcome?

---

## Lesson 90: Describing Objects (basic)

**Warm-up Prompt:**

Is the bag red?

**Speaking Practice Prompts:**

- Is the bag red?
- Is the box big?
- Is the cup small?
- Is the book old?
- Is the phone new?

---

## Lesson 91: Time Words (today / yesterday / tomorrow)

**Warm-up Prompt:**

Is your test today?

**Speaking Practice Prompts:**

- Is your test today?
- Was your homework yesterday?
- Is the trip tomorrow?
- Are we studying now?
- Do we rest later?

---

