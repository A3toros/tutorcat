-- =========================================
-- Pre-fill Database with Sample Lesson Data
-- B1-L83: Making Suggestions
-- =========================================

DELETE FROM grammar_sentences WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'B1-L83');
DELETE FROM vocabulary_items WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'B1-L83');
DELETE FROM lesson_activities WHERE lesson_id = 'B1-L83';
DELETE FROM lessons WHERE id = 'B1-L83';

INSERT INTO lessons (id, level, lesson_number, topic) VALUES
('B1-L83', 'B1', 83, 'Making Suggestions')
ON CONFLICT (id) DO UPDATE SET topic = EXCLUDED.topic;

DO $$
DECLARE
    lesson_id_var TEXT := 'B1-L83';
    activity_id_var UUID;
BEGIN
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'warm_up_speaking', 1, 'Suggesting Ideas', 'Talk about sharing ideas kindly', '{"prompt": "How do you suggest ideas without sounding bossy?"}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_intro', 2, 'Suggestion Words', 'Learn vocabulary about making suggestions', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'suggest', 'แนะนำ', NULL),
    (activity_id_var, 'propose', 'เสนอ', NULL),
    (activity_id_var, 'recommend', 'แนะนำ (อย่างเป็นทางการกว่า)', NULL),
    (activity_id_var, 'consider', 'พิจารณา', NULL),
    (activity_id_var, 'try', 'ลอง', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_matching_drag', 3, 'Match Suggestion Words', 'Match words with meanings', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'suggest', 'แนะนำ', NULL),
    (activity_id_var, 'propose', 'เสนอ', NULL),
    (activity_id_var, 'recommend', 'แนะนำ (อย่างเป็นทางการกว่า)', NULL),
    (activity_id_var, 'consider', 'พิจารณา', NULL),
    (activity_id_var, 'try', 'ลอง', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 4, 'Complete the Sentences 1', 'Fill with the correct word', '{"text": "May I ___ a change? I want to ___ an option. I strongly ___ this idea.", "blanks": [{"id": "blank1", "text": "suggest", "options": ["suggest", "propose", "recommend", "consider"], "correctAnswer": "suggest"}, {"id": "blank2", "text": "propose", "options": ["propose", "recommend", "consider", "try"], "correctAnswer": "propose"}, {"id": "blank3", "text": "recommend", "options": ["recommend", "suggest", "try", "consider"], "correctAnswer": "recommend"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 5, 'Complete the Sentences 2', 'Fill with the correct word', '{"text": "Let us ___ other angles. We can ___ a small test. I will ___ it tomorrow.", "blanks": [{"id": "blank1", "text": "consider", "options": ["consider", "try", "suggest", "recommend"], "correctAnswer": "consider"}, {"id": "blank2", "text": "try", "options": ["try", "consider", "propose", "recommend"], "correctAnswer": "try"}, {"id": "blank3", "text": "try", "options": ["try", "recommend", "suggest", "consider"], "correctAnswer": "try"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    -- Grammar Explanation: Gerunds & Infinitives (suggestions)
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_explanation', 6, 'Gerunds and Infinitives for Suggestions', 'Use verb-ing or to + verb correctly when making suggestions', '{"rules": "Common patterns: suggest doing, recommend trying, propose to present is formal but prefer propose + verb-ing? Keep natural: suggest + verb-ing; recommend + verb-ing; try to + base; decide to; consider + verb-ing.\\nAvoid contractions.", "examples": ["I suggest starting with a small test.", "We recommend trying one change first.", "They decided to try a new plan.", "She considered adding more data.", "He offered to help with slides."]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 7, 'Build Sentences 1', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'I suggest starting with a small test', 'I suggest starting with a small test', '["I", "suggest", "starting", "with", "a", "small", "test"]'::jsonb),
    (activity_id_var, 'We recommend trying one change first', 'We recommend trying one change first', '["We", "recommend", "trying", "one", "change", "first"]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 8, 'Build Sentences 2', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'They decided to try a new plan', 'They decided to try a new plan', '["They", "decided", "to", "try", "a", "new", "plan"]'::jsonb),
    (activity_id_var, 'She considered adding more data', 'She considered adding more data', '["She", "considered", "adding", "more", "data"]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'speaking_practice', 9, 'Talk About Suggestions', 'Practice giving gentle suggestions', '{"prompts": ["How do you suggest ideas without sounding bossy?", "When do you propose changes?", "What is the best suggestion someone gave you?"]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (
      lesson_id,
      activity_type,
      activity_order,
      title,
      description,
      content
    ) VALUES (
      'B1-L83',
      'speaking_improvement',
      10,
      'Speaking Improvement',
      'Read the improved version of your speech',
      '{"type": "speaking_improvement", "similarityThreshold": 70}'::jsonb
    );
END $$;

