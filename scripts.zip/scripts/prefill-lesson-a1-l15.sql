-- =========================================
-- Pre-fill Database with Sample Lesson Data
-- A1-L15: Family & Friends
-- =========================================

DELETE FROM grammar_sentences WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'A1-L15');
DELETE FROM vocabulary_items WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'A1-L15');
DELETE FROM lesson_activities WHERE lesson_id = 'A1-L15';
DELETE FROM lessons WHERE id = 'A1-L15';

INSERT INTO lessons (id, level, lesson_number, topic) VALUES
('A1-L15', 'A1', 15, 'Family & Friends')
ON CONFLICT (id) DO UPDATE SET topic = EXCLUDED.topic;

DO $$
DECLARE
    lesson_id_var TEXT := 'A1-L15';
    activity_id_var UUID;
BEGIN
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'warm_up_speaking', 1, 'Family', 'Talk about family', '{"prompt": "Who is in your family?"}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_intro', 2, 'Family Words', 'Learn family words', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'mother', 'แม่', NULL),
    (activity_id_var, 'father', 'พ่อ', NULL),
    (activity_id_var, 'sister', 'พี่สาว/น้องสาว', NULL),
    (activity_id_var, 'brother', 'พี่ชาย/น้องชาย', NULL),
    (activity_id_var, 'friend', 'เพื่อน', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_matching_drag', 3, 'Match Family Words', 'Match family words', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'mother', 'แม่', NULL),
    (activity_id_var, 'father', 'พ่อ', NULL),
    (activity_id_var, 'sister', 'พี่สาว/น้องสาว', NULL),
    (activity_id_var, 'brother', 'พี่ชาย/น้องชาย', NULL),
    (activity_id_var, 'friend', 'เพื่อน', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 4, 'Complete the Sentences 1', 'Fill with the correct word', '{"text": "My ___ is kind. My ___ is funny.", "blanks": [{"id": "blank1", "text": "mother", "options": ["mother", "father", "sister", "friend"], "correctAnswer": "mother"}, {"id": "blank2", "text": "father", "options": ["father", "brother", "friend", "mother"], "correctAnswer": "father"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 5, 'Complete the Sentences 2', 'Fill with the correct word', '{"text": "I have one ___. I have one ___.", "blanks": [{"id": "blank1", "text": "sister", "options": ["sister", "brother", "friend", "mother"], "correctAnswer": "sister"}, {"id": "blank2", "text": "brother", "options": ["brother", "sister", "friend", "father"], "correctAnswer": "brother"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_explanation', 6, 'Possessive Adjectives', 'Use my/your/his/her', '{"rules": "Use my, your, his, her before nouns.\n- This is my mother.\n- That is his friend.\n- Is she your sister?", "examples": ["This is my mother.", "That is his friend.", "Is she your sister?", "He is her brother.", "Where is your father?"]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 7, 'Build Sentences 1', 'Arrange words', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'This is my mother', 'This is my mother.', '["This", "is", "my", "mother."]'::jsonb),
    (activity_id_var, 'That is his friend', 'That is his friend.', '["That", "is", "his", "friend."]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 8, 'Build Sentences 2', 'Arrange words', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'Is she your sister', 'Is she your sister?', '["Is", "she", "your", "sister?"]'::jsonb),
    (activity_id_var, 'He is her brother', 'He is her brother.', '["He", "is", "her", "brother."]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'speaking_practice', 9, 'Talk About Family', 'Practice my/your/his/her', '{"prompts": ["Who is in your family?", "Is he your brother?", "Do you have sisters?", "Who is your friend?", "Do you live with your mother?"]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (
      lesson_id,
      activity_type,
      activity_order,
      title,
      description,
      content
    ) VALUES (
      'A1-L15',
      'speaking_improvement',
      10,
      'Speaking Improvement',
      'Read the improved version of your speech',
      '{"type": "speaking_improvement", "similarityThreshold": 70}'::jsonb
    );
END $$;

