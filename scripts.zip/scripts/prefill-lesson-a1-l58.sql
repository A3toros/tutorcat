-- =========================================
-- Pre-fill Database with Sample Lesson Data
-- A1-L58: Simple Games
-- =========================================

DELETE FROM grammar_sentences WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'A1-L58');
DELETE FROM vocabulary_items WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'A1-L58');
DELETE FROM lesson_activities WHERE lesson_id = 'A1-L58';
DELETE FROM lessons WHERE id = 'A1-L58';

INSERT INTO lessons (id, level, lesson_number, topic) VALUES
('A1-L58', 'A1', 58, 'Simple Games')
ON CONFLICT (id) DO UPDATE SET topic = EXCLUDED.topic;

DO $$
DECLARE
    lesson_id_var TEXT := 'A1-L58';
    activity_id_var UUID;
BEGIN
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'warm_up_speaking', 1, 'Games', 'Talk about simple games', '{"prompt": "Do you play cards?"}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_intro', 2, 'Game Words', 'Learn simple game words', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'play', 'เล่น', NULL),
    (activity_id_var, 'card', 'ไพ่', NULL),
    (activity_id_var, 'ball', 'ลูกบอล', NULL),
    (activity_id_var, 'move', 'ขยับ', NULL),
    (activity_id_var, 'win', 'ชนะ', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_matching_drag', 3, 'Match Game Words', 'Match game words', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'play', 'เล่น', NULL),
    (activity_id_var, 'card', 'ไพ่', NULL),
    (activity_id_var, 'ball', 'ลูกบอล', NULL),
    (activity_id_var, 'move', 'ขยับ', NULL),
    (activity_id_var, 'win', 'ชนะ', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 4, 'Complete the Sentences 1', 'Fill with the correct word', '{"text": "We ___. We play with a ___.", "blanks": [{"id": "blank1", "text": "play", "options": ["play", "move", "win", "card"], "correctAnswer": "play"}, {"id": "blank2", "text": "ball", "options": ["ball", "card", "win", "move"], "correctAnswer": "ball"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 5, 'Complete the Sentences 2', 'Fill with the correct word', '{"text": "___ here. Do you want to ___?", "blanks": [{"id": "blank1", "text": "Move", "options": ["Move", "Play", "Win", "Card"], "correctAnswer": "Move"}, {"id": "blank2", "text": "win", "options": ["win", "play", "move", "ball"], "correctAnswer": "win"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_explanation', 6, 'Imperatives (play)', 'Give simple play commands', '{"rules": "Use base verb to give game moves.\n- Move here. Play now.\nAdd please for polite tone.", "examples": ["Move here.", "Play now.", "Do not run.", "Wait your turn, please.", "Can you pass the ball?"]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 7, 'Build Sentences 1', 'Arrange words', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'Move here', 'Move here.', '["Move", "here."]'::jsonb),
    (activity_id_var, 'Play now', 'Play now.', '["Play", "now."]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 8, 'Build Sentences 2', 'Arrange words', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'Do not run', 'Do not run.', '["Do", "not", "run."]'::jsonb),
    (activity_id_var, 'Wait your turn please', 'Wait your turn, please.', '["Wait", "your", "turn,", "please."]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'speaking_practice', 9, 'Talk About Games', 'Practice play commands', '{"prompts": ["Do you play cards?", "Do you play with a ball?", "Do I move here?", "Do you like to win?", "Do you wait your turn?"]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (
      lesson_id,
      activity_type,
      activity_order,
      title,
      description,
      content
    ) VALUES (
      'A1-L58',
      'speaking_improvement',
      10,
      'Speaking Improvement',
      'Read the improved version of your speech',
      '{"type": "speaking_improvement", "similarityThreshold": 70}'::jsonb
    );
END $$;

