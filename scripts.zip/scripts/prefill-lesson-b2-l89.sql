-- ===== LESSON B2-L89 =====

-- =========================================
-- Pre-fill Database with Sample Lesson Data
-- B2-L89: Ambition and motivation
-- =========================================

DELETE FROM lesson_activity_results WHERE lesson_id = 'B2-L89';
DELETE FROM user_progress WHERE lesson_id = 'B2-L89';
DELETE FROM lesson_history WHERE lesson_id = 'B2-L89';
DELETE FROM grammar_sentences WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'B2-L89');
DELETE FROM vocabulary_items WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'B2-L89');
DELETE FROM lesson_activities WHERE lesson_id = 'B2-L89';
DELETE FROM lessons WHERE id = 'B2-L89';

INSERT INTO lessons (id, level, lesson_number, topic) VALUES
('B2-L89', 'B2', 89, 'Ambition and motivation')
ON CONFLICT (id) DO UPDATE SET topic = EXCLUDED.topic;

DO $$
DECLARE
    lesson_id_var TEXT := 'B2-L89';
    activity_id_var UUID;
BEGIN
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'warm_up_speaking', 1, 'Goals and Motivation', 'Talk about your goals', '{"prompt": "What do you want to achieve this year?"}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_intro', 2, 'Motivation Words', 'Learn words related to ambition and drive', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'drive', 'แรงผลักดัน', NULL),
    (activity_id_var, 'plateau', 'ที่ราบสูง', NULL),
    (activity_id_var, 'spark', 'ประกายไฟ', NULL),
    (activity_id_var, 'momentum', 'แรงผลักดัน', NULL),
    (activity_id_var, 'setback', 'ความล้มเหลว', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_matching_drag', 3, 'Match Motivation Words', 'Match words related to ambition', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'drive', 'แรงผลักดัน', NULL),
    (activity_id_var, 'plateau', 'ที่ราบสูง', NULL),
    (activity_id_var, 'spark', 'ประกายไฟ', NULL),
    (activity_id_var, 'momentum', 'แรงผลักดัน', NULL),
    (activity_id_var, 'setback', 'ความล้มเหลว', NULL);

    -- 4. Vocabulary Fill Blanks #1
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 4, 'Complete the Sentences 1', 'Fill in the blanks with correct words', '{"text": "I have the ___. I hit a ___. I need a ___.", "blanks": [{"id": "blank1", "text": "drive", "options": ["drive", "plateau", "spark", "momentum"], "correctAnswer": "drive"}, {"id": "blank2", "text": "plateau", "options": ["plateau", "drive", "spark", "setback"], "correctAnswer": "plateau"}, {"id": "blank3", "text": "spark", "options": ["spark", "drive", "plateau", "momentum"], "correctAnswer": "spark"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    -- 5. Vocabulary Fill Blanks #2
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 5, 'Complete the Sentences 2', 'Fill in the blanks with correct words', '{"text": "I have ___. I faced a ___. We need ___.", "blanks": [{"id": "blank1", "text": "momentum", "options": ["momentum", "drive", "plateau", "spark"], "correctAnswer": "momentum"}, {"id": "blank2", "text": "setback", "options": ["setback", "drive", "plateau", "momentum"], "correctAnswer": "setback"}, {"id": "blank3", "text": "momentum", "options": ["momentum", "setback", "drive", "plateau"], "correctAnswer": "momentum"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    -- 6. Grammar Explanation
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_explanation', 6, 'Passive with Modals', 'Learn passive voice with modal verbs', '{"rules": "Use passive voice with modal verbs to show obligation or possibility:\n\n- Form: modal + be + past participle (should be pursued, must be set)\n- Use when the action is more important than who does it\n- Modal + be + past participle (should be, must be, can be)\n- Use by to show who does the action (by success, by you)\n- Common modals: must, should, can, might, could", "examples": ["Ambitions should be pursued with passion.", "Goals must be set realistically.", "Motivation can be sparked by success.", "Dreams should be followed.", "Challenges can be overcome with effort."]}'::jsonb)
    RETURNING id INTO activity_id_var;

    -- 7. Grammar Sentences #1
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 7, 'Build Sentences 1', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'Ambitions should be pursued with passion', 'Ambitions should be pursued with passion.', '["Ambitions", "should", "be", "pursued", "with", "passion."]'::jsonb),
    (activity_id_var, 'Goals must be set realistically', 'Goals must be set realistically.', '["Goals", "must", "be", "set", "realistically."]'::jsonb);

    -- 8. Grammar Sentences #2
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 8, 'Build Sentences 2', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'Motivation can be sparked by success', 'Motivation can be sparked by success.', '["Motivation", "can", "be", "sparked", "by", "success."]'::jsonb),
    (activity_id_var, 'Dreams should be followed', 'Dreams should be followed.', '["Dreams", "should", "be", "followed."]'::jsonb);

    -- 9. Speaking Practice
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'speaking_practice', 9, 'Talk About Goals', 'Practice talking about ambitions', '{"prompts": ["What job do you want in the future?", "How do you stay motivated?", "Who encourages you?", "What drives you to succeed?", "How do you handle setbacks?"]}'::jsonb)
    RETURNING id INTO activity_id_var;

    -- 10. Speaking Improvement
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'speaking_improvement', 10, 'Speaking Improvement', 'Read the improved version of your speech', '{"type": "speaking_improvement", "similarityThreshold": 70}'::jsonb)
    RETURNING id INTO activity_id_var;
END $$;