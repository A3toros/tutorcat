-- =========================================
-- Pre-fill Database with Sample Lesson Data
-- A2-L49: Watching Sports
-- =========================================

DELETE FROM grammar_sentences WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'A2-L49');
DELETE FROM vocabulary_items WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'A2-L49');
DELETE FROM lesson_activities WHERE lesson_id = 'A2-L49';
DELETE FROM lessons WHERE id = 'A2-L49';

INSERT INTO lessons (id, level, lesson_number, topic) VALUES
('A2-L49', 'A2', 49, 'Watching Sports')
ON CONFLICT (id) DO UPDATE SET topic = EXCLUDED.topic;

DO $$
DECLARE
    lesson_id_var TEXT := 'A2-L49';
    activity_id_var UUID;
BEGIN
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'warm_up_speaking', 1, 'Games You Watch', 'Talk about watching sports', '{"prompt": "What sports game did you watch recently?"}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_intro', 2, 'Sports Watching Words', 'Learn words for watching games', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'match', 'การแข่งขัน', NULL),
    (activity_id_var, 'team', 'ทีม', NULL),
    (activity_id_var, 'win', 'ชนะ', NULL),
    (activity_id_var, 'lose', 'แพ้', NULL),
    (activity_id_var, 'cheer', 'เชียร์', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_matching_drag', 3, 'Match Sports Watching Words', 'Match watching sports words', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'match', 'การแข่งขัน', NULL),
    (activity_id_var, 'team', 'ทีม', NULL),
    (activity_id_var, 'win', 'ชนะ', NULL),
    (activity_id_var, 'lose', 'แพ้', NULL),
    (activity_id_var, 'cheer', 'เชียร์', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 4, 'Complete the Sentences 1', 'Fill with the correct word', '{"text": "The ___ was exciting. My ___ did not ___. We ___ loudly.", "blanks": [{"id": "blank1", "text": "match", "options": ["match", "team", "win", "cheer"], "correctAnswer": "match"}, {"id": "blank2", "text": "team", "options": ["team", "win", "lose", "cheer"], "correctAnswer": "team"}, {"id": "blank3", "text": "win", "options": ["win", "cheer", "match", "team"], "correctAnswer": "win"}, {"id": "blank4", "text": "cheered", "options": ["cheered", "lose", "team", "match"], "correctAnswer": "cheered"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 5, 'Complete the Sentences 2', 'Fill with the correct word', '{"text": "They did not ___. My ___ lost. We still ___.", "blanks": [{"id": "blank1", "text": "win", "options": ["win", "lose", "cheer", "team"], "correctAnswer": "win"}, {"id": "blank2", "text": "team", "options": ["team", "match", "win", "cheer"], "correctAnswer": "team"}, {"id": "blank3", "text": "cheered", "options": ["cheered", "win", "lose", "team"], "correctAnswer": "cheered"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_explanation', 6, 'Past Simple', 'Talk about a game you watched', '{"rules": "Use past simple for finished events.\n- I watched a match yesterday.\n- They won.\nQuestions: Did your team win?\nNegatives: didn''t + verb.", "examples": ["I watched a match yesterday.", "Our team won the game.", "Did your team win?", "We didn''t lose.", "They cheered loudly."]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 7, 'Build Sentences 1', 'Arrange words', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'I watched a match yesterday', 'I watched a match yesterday.', '["I", "watched", "a", "match", "yesterday."]'::jsonb),
    (activity_id_var, 'Did your team win', 'Did your team win?', '["Did", "your", "team", "win?"]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 8, 'Build Sentences 2', 'Arrange words', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'We didn t lose', 'We didn''t lose.', '["We", "didn''t", "lose."]'::jsonb),
    (activity_id_var, 'They cheered loudly', 'They cheered loudly.', '["They", "cheered", "loudly."]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'speaking_practice', 9, 'Talk About Watching Sports', 'Practice game stories', '{"prompts": ["What sports game did you watch recently?", "Which team or player won the game?", "Who did you watch it with?", "Where did you watch the game?", "How did you feel about the result?"]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (
      lesson_id,
      activity_type,
      activity_order,
      title,
      description,
      content
    ) VALUES (
      'A2-L49',
      'speaking_improvement',
      10,
      'Speaking Improvement',
      'Read the improved version of your speech',
      '{"type": "speaking_improvement", "similarityThreshold": 70}'::jsonb
    );
END $$;

