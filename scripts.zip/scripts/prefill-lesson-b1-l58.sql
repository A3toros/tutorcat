-- =========================================
-- Pre-fill Database with Sample Lesson Data
-- B1-L58: Financial Goals
-- =========================================

DELETE FROM grammar_sentences WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'B1-L58');
DELETE FROM vocabulary_items WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'B1-L58');
DELETE FROM lesson_activities WHERE lesson_id = 'B1-L58';
DELETE FROM lessons WHERE id = 'B1-L58';

INSERT INTO lessons (id, level, lesson_number, topic) VALUES
('B1-L58', 'B1', 58, 'Financial Goals')
ON CONFLICT (id) DO UPDATE SET topic = EXCLUDED.topic;

DO $$
DECLARE
    lesson_id_var TEXT := 'B1-L58';
    activity_id_var UUID;
BEGIN
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'warm_up_speaking', 1, 'Money Goals', 'Talk about hitting money targets', '{"prompt": "What must you do to hit a money goal?"}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_intro', 2, 'Goal Words', 'Learn vocabulary about financial goals', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'invest', 'ลงทุน', NULL),
    (activity_id_var, 'budget', 'งบประมาณ', NULL),
    (activity_id_var, 'track', 'ติดตาม', NULL),
    (activity_id_var, 'reduce', 'ลด', NULL),
    (activity_id_var, 'target', 'เป้าหมาย', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_matching_drag', 3, 'Match Goal Words', 'Match words with meanings', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'invest', 'ลงทุน', NULL),
    (activity_id_var, 'budget', 'งบประมาณ', NULL),
    (activity_id_var, 'track', 'ติดตาม', NULL),
    (activity_id_var, 'reduce', 'ลด', NULL),
    (activity_id_var, 'target', 'เป้าหมาย', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 4, 'Complete the Sentences 1', 'Fill with the correct word', '{"text": "I set a ___. I must ___. I will ___ spending.", "blanks": [{"id": "blank1", "text": "target", "options": ["target", "invest", "budget", "track"], "correctAnswer": "target"}, {"id": "blank2", "text": "budget", "options": ["budget", "target", "reduce", "track"], "correctAnswer": "budget"}, {"id": "blank3", "text": "reduce", "options": ["reduce", "budget", "invest", "track"], "correctAnswer": "reduce"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 5, 'Complete the Sentences 2', 'Fill with the correct word', '{"text": "I ___ progress weekly. I will ___ small amounts. This helps reach the ___.", "blanks": [{"id": "blank1", "text": "track", "options": ["track", "reduce", "budget", "invest"], "correctAnswer": "track"}, {"id": "blank2", "text": "invest", "options": ["invest", "track", "budget", "reduce"], "correctAnswer": "invest"}, {"id": "blank3", "text": "target", "options": ["target", "budget", "track", "invest"], "correctAnswer": "target"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    -- Grammar Explanation: Modals (must / have to) for goals
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_explanation', 6, 'Modals for Hitting Goals', 'Use must / have to to state necessities for financial targets', '{"rules": "Use must and have to for strong necessity and obligations.\\n- I must reduce spending.\\n- We have to track every expense.\\nKeep statements direct; no contractions.", "examples": ["I must reduce spending this month.", "We have to track every expense daily.", "She must invest a fixed amount weekly.", "They have to review the budget on Fridays.", "You must set a clear target first."]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 7, 'Build Sentences 1', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'I must reduce spending this month', 'I must reduce spending this month', '["I", "must", "reduce", "spending", "this", "month"]'::jsonb),
    (activity_id_var, 'We have to track every expense daily', 'We have to track every expense daily', '["We", "have", "to", "track", "every", "expense", "daily"]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 8, 'Build Sentences 2', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'She must invest a fixed amount weekly', 'She must invest a fixed amount weekly', '["She", "must", "invest", "a", "fixed", "amount", "weekly"]'::jsonb),
    (activity_id_var, 'They have to review the budget on Fridays', 'They have to review the budget on Fridays', '["They", "have", "to", "review", "the", "budget", "on", "Fridays"]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'speaking_practice', 9, 'Talk About Financial Goals', 'Practice talking about money targets', '{"prompts": ["What must you do to hit a money goal?", "How do you track progress day to day?", "When do you change the plan?"]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (
      lesson_id,
      activity_type,
      activity_order,
      title,
      description,
      content
    ) VALUES (
      'B1-L58',
      'speaking_improvement',
      10,
      'Speaking Improvement',
      'Read the improved version of your speech',
      '{"type": "speaking_improvement", "similarityThreshold": 70}'::jsonb
    );
END $$;

