-- Migration: Add Email Login Support
-- Description: Adds database indexes and constraints to support email-based login
-- Date: 2026-01-05

-- Add index on email column for faster email lookups
-- This is important for performance when users login with email addresses
CREATE INDEX IF NOT EXISTS idx_users_email ON users(email);

-- Add index on username column for case-insensitive lookups
-- This ensures username lookups remain fast
CREATE INDEX IF NOT EXISTS idx_users_username_lower ON users(LOWER(username));

-- Note: Email field is already UNIQUE and NOT NULL in the schema
-- No need to add additional unique constraint

-- Add check constraint to ensure email format is valid (only if not exists)
-- This prevents invalid email addresses from being stored
DO $$
BEGIN
    IF NOT EXISTS (
        SELECT 1 FROM pg_constraint
        WHERE conname = 'users_email_format_check'
    ) THEN
        ALTER TABLE users ADD CONSTRAINT users_email_format_check
        CHECK (email ~* '^[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}$');
    END IF;
END $$;

-- Add comment to document the changes
COMMENT ON INDEX idx_users_email IS 'Index for email-based login lookups';
COMMENT ON INDEX idx_users_username_lower IS 'Index for case-insensitive username lookups';
COMMENT ON CONSTRAINT users_email_format_check ON users IS 'Validates email format';
-- Note: Email uniqueness is enforced by UNIQUE constraint in table definition

-- Log the migration completion
DO $$
BEGIN
    RAISE NOTICE 'Email login support migration completed successfully';
    RAISE NOTICE 'Added indexes: idx_users_email, idx_users_username_lower';
    RAISE NOTICE 'Added constraints: users_email_format_check (email unique constraint already exists)';
END $$;
