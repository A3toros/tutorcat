-- =========================================
-- Pre-fill Database with Sample Lesson Data
-- A1-L29: Personal Objects
-- =========================================

DELETE FROM grammar_sentences WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'A1-L29');
DELETE FROM vocabulary_items WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'A1-L29');
DELETE FROM lesson_activities WHERE lesson_id = 'A1-L29';
DELETE FROM lessons WHERE id = 'A1-L29';

INSERT INTO lessons (id, level, lesson_number, topic) VALUES
('A1-L29', 'A1', 29, 'Personal Objects')
ON CONFLICT (id) DO UPDATE SET topic = EXCLUDED.topic;

DO $$
DECLARE
    lesson_id_var TEXT := 'A1-L29';
    activity_id_var UUID;
BEGIN
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'warm_up_speaking', 1, 'Your Things', 'Talk about your things', '{"prompt": "Is this your phone?"}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_intro', 2, 'Object Words', 'Learn personal object words', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'phone', 'โทรศัพท์', NULL),
    (activity_id_var, 'bag', 'กระเป๋า', NULL),
    (activity_id_var, 'keys', 'กุญแจ', NULL),
    (activity_id_var, 'watch', 'นาฬิกา', NULL),
    (activity_id_var, 'wallet', 'กระเป๋าสตางค์', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_matching_drag', 3, 'Match Object Words', 'Match personal object words', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'phone', 'โทรศัพท์', NULL),
    (activity_id_var, 'bag', 'กระเป๋า', NULL),
    (activity_id_var, 'keys', 'กุญแจ', NULL),
    (activity_id_var, 'watch', 'นาฬิกา', NULL),
    (activity_id_var, 'wallet', 'กระเป๋าสตางค์', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 4, 'Complete the Sentences 1', 'Fill with the correct word', '{"text": "This is my ___. That is my ___.", "blanks": [{"id": "blank1", "text": "phone", "options": ["phone", "bag", "keys", "watch"], "correctAnswer": "phone"}, {"id": "blank2", "text": "bag", "options": ["bag", "wallet", "watch", "keys"], "correctAnswer": "bag"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 5, 'Complete the Sentences 2', 'Fill with the correct word', '{"text": "These are my ___. This is my ___.", "blanks": [{"id": "blank1", "text": "keys", "options": ["keys", "phone", "bag", "watch"], "correctAnswer": "keys"}, {"id": "blank2", "text": "watch", "options": ["watch", "wallet", "keys", "bag"], "correctAnswer": "watch"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_explanation', 6, 'This / That + Possession', 'Point to near/far things', '{"rules": "Use this for near, that for far. Add my/your for possession.\n- This is my phone.\n- That is your bag.", "examples": ["This is my phone.", "That is your bag.", "These are my keys.", "Is this your watch?", "Is that your wallet?"]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 7, 'Build Sentences 1', 'Arrange words', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'This is my phone', 'This is my phone.', '["This", "is", "my", "phone."]'::jsonb),
    (activity_id_var, 'That is your bag', 'That is your bag.', '["That", "is", "your", "bag."]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 8, 'Build Sentences 2', 'Arrange words', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'These are my keys', 'These are my keys.', '["These", "are", "my", "keys."]'::jsonb),
    (activity_id_var, 'Is this your watch', 'Is this your watch?', '["Is", "this", "your", "watch?"]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'speaking_practice', 9, 'Talk About Your Things', 'Practice this/that and my/your', '{"prompts": ["Is this your phone?", "Where are your keys?", "Is that your bag?", "Is this your watch?", "Do you have your wallet?"]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (
      lesson_id,
      activity_type,
      activity_order,
      title,
      description,
      content
    ) VALUES (
      'A1-L29',
      'speaking_improvement',
      10,
      'Speaking Improvement',
      'Read the improved version of your speech',
      '{"type": "speaking_improvement", "similarityThreshold": 70}'::jsonb
    );
END $$;

