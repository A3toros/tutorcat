-- =========================================
-- Pre-fill Database with Sample Lesson Data
-- A2-L18: Planning a Holiday
-- =========================================

DELETE FROM grammar_sentences WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'A2-L18');
DELETE FROM vocabulary_items WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'A2-L18');
DELETE FROM lesson_activities WHERE lesson_id = 'A2-L18';
DELETE FROM lessons WHERE id = 'A2-L18';

INSERT INTO lessons (id, level, lesson_number, topic) VALUES
('A2-L18', 'A2', 18, 'Planning a Holiday')
ON CONFLICT (id) DO UPDATE SET topic = EXCLUDED.topic;

DO $$
DECLARE
    lesson_id_var TEXT := 'A2-L18';
    activity_id_var UUID;
BEGIN
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'warm_up_speaking', 1, 'Holiday Plans', 'Talk about your next trip', '{"prompt": "Where are you going to travel next?"}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_intro', 2, 'Holiday Planning Words', 'Learn planning vocabulary', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'plan', 'วางแผน', NULL),
    (activity_id_var, 'book', 'จอง', NULL),
    (activity_id_var, 'ticket', 'ตั๋ว', NULL),
    (activity_id_var, 'hotel', 'โรงแรม', NULL),
    (activity_id_var, 'budget', 'งบประมาณ', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_matching_drag', 3, 'Match Holiday Words', 'Match travel planning words', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'plan', 'วางแผน', NULL),
    (activity_id_var, 'book', 'จอง', NULL),
    (activity_id_var, 'ticket', 'ตั๋ว', NULL),
    (activity_id_var, 'hotel', 'โรงแรม', NULL),
    (activity_id_var, 'budget', 'งบประมาณ', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 4, 'Complete the Sentences 1', 'Fill with the correct word', '{"text": "I need to ___ my ___ this week. We will ___ a ___ and set a ___.", "blanks": [{"id": "blank1", "text": "book", "options": ["book", "ticket", "hotel", "budget"], "correctAnswer": "book"}, {"id": "blank2", "text": "ticket", "options": ["ticket", "hotel", "budget", "plan"], "correctAnswer": "ticket"}, {"id": "blank3", "text": "plan", "options": ["plan", "book", "hotel", "budget"], "correctAnswer": "plan"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 5, 'Complete the Sentences 2', 'Fill with the correct word', '{"text": "She wants a cheap ___. We have a small ___. Let us ___ rooms early.", "blanks": [{"id": "blank1", "text": "hotel", "options": ["hotel", "ticket", "plan", "budget"], "correctAnswer": "hotel"}, {"id": "blank2", "text": "budget", "options": ["budget", "hotel", "ticket", "plan"], "correctAnswer": "budget"}, {"id": "blank3", "text": "book", "options": ["book", "plan", "budget", "ticket"], "correctAnswer": "book"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_explanation', 6, 'Going to (Future)', 'Talk about future travel plans', '{"rules": "Use going to for planned future actions.\n- I am going to book a hotel.\n- We are going to visit the beach.\nForm: am/is/are + going to + verb.", "examples": ["I am going to buy tickets tomorrow.", "She is going to stay in a hotel.", "We are going to set a budget.", "Are you going to travel with family?", "They are going to plan together."]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 7, 'Build Sentences 1', 'Arrange words', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'I am going to book a hotel', 'I am going to book a hotel.', '["I", "am", "going", "to", "book", "a", "hotel."]'::jsonb),
    (activity_id_var, 'We are going to buy tickets tomorrow', 'We are going to buy tickets tomorrow.', '["We", "are", "going", "to", "buy", "tickets", "tomorrow."]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 8, 'Build Sentences 2', 'Arrange words', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'Are you going to travel with family', 'Are you going to travel with family?', '["Are", "you", "going", "to", "travel", "with", "family?"]'::jsonb),
    (activity_id_var, 'They are going to set a budget', 'They are going to set a budget.', '["They", "are", "going", "to", "set", "a", "budget."]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'speaking_practice', 9, 'Talk About Holiday Plans', 'Practice planning travel', '{"prompts": ["Where are you going to travel next?", "How do you book hotels or places to stay?", "Do you set a budget for your holiday?", "What are you going to pack for your holiday?", "Who are you going to travel with?"]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (
      lesson_id,
      activity_type,
      activity_order,
      title,
      description,
      content
    ) VALUES (
      'A2-L18',
      'speaking_improvement',
      10,
      'Speaking Improvement',
      'Read the improved version of your speech',
      '{"type": "speaking_improvement", "similarityThreshold": 70}'::jsonb
    );
END $$;

