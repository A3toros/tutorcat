-- =========================================
-- Pre-fill Database with Sample Lesson Data
-- B1-L32: News & Information
-- =========================================

DELETE FROM grammar_sentences WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'B1-L32');
DELETE FROM vocabulary_items WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'B1-L32');
DELETE FROM lesson_activities WHERE lesson_id = 'B1-L32';
DELETE FROM lessons WHERE id = 'B1-L32';

INSERT INTO lessons (id, level, lesson_number, topic) VALUES
('B1-L32', 'B1', 32, 'News & Information')
ON CONFLICT (id) DO UPDATE SET topic = EXCLUDED.topic;

DO $$
DECLARE
    lesson_id_var TEXT := 'B1-L32';
    activity_id_var UUID;
BEGIN
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'warm_up_speaking', 1, 'Trusting News', 'Talk about checking headlines', '{"prompt": "How do you check if news is real?"}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_intro', 2, 'News Words', 'Learn vocabulary about news and information', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'headline', 'พาดหัวข่าว', NULL),
    (activity_id_var, 'source', 'แหล่งที่มา', NULL),
    (activity_id_var, 'verify', 'ตรวจสอบความถูกต้อง', NULL),
    (activity_id_var, 'bias', 'อคติ', NULL),
    (activity_id_var, 'rumor', 'ข่าวลือ', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_matching_drag', 3, 'Match News Words', 'Match words with meanings', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'headline', 'พาดหัวข่าว', NULL),
    (activity_id_var, 'source', 'แหล่งที่มา', NULL),
    (activity_id_var, 'verify', 'ตรวจสอบความถูกต้อง', NULL),
    (activity_id_var, 'bias', 'อคติ', NULL),
    (activity_id_var, 'rumor', 'ข่าวลือ', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 4, 'Complete the Sentences 1', 'Fill with the correct word', '{"text": "The ___ looks shocking. Check the ___. Always ___ before sharing.", "blanks": [{"id": "blank1", "text": "headline", "options": ["headline", "source", "verify", "bias"], "correctAnswer": "headline"}, {"id": "blank2", "text": "source", "options": ["source", "bias", "verify", "rumor"], "correctAnswer": "source"}, {"id": "blank3", "text": "verify", "options": ["verify", "headline", "bias", "rumor"], "correctAnswer": "verify"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 5, 'Complete the Sentences 2', 'Fill with the correct word', '{"text": "Watch for ___. This might be a ___. Double-check the ___.", "blanks": [{"id": "blank1", "text": "bias", "options": ["bias", "rumor", "source", "verify"], "correctAnswer": "bias"}, {"id": "blank2", "text": "rumor", "options": ["rumor", "bias", "verify", "headline"], "correctAnswer": "rumor"}, {"id": "blank3", "text": "source", "options": ["source", "verify", "headline", "bias"], "correctAnswer": "source"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    -- Grammar Explanation: First Conditional (news actions)
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_explanation', 6, 'First Conditional for News Checking', 'Use if + present, will + base verb for likely results', '{"rules": "If + present simple, will + base verb to talk about likely results when checking news.\\n- If a headline feels fake, I will verify it.\\n- If the source is unknown, I will wait.\\nNo contractions.", "examples": ["If a headline looks fake, I will verify it.", "If the source is unknown, I will wait to share.", "If I see bias, I will compare other sites.", "If friends spread a rumor, I will ask for proof.", "If the story is verified, I will discuss it."]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 7, 'Build Sentences 1', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'If a headline looks fake I will verify it', 'If a headline looks fake, I will verify it', '["If", "a", "headline", "looks", "fake,", "I", "will", "verify", "it"]'::jsonb),
    (activity_id_var, 'If the source is unknown I will wait to share', 'If the source is unknown, I will wait to share', '["If", "the", "source", "is", "unknown,", "I", "will", "wait", "to", "share"]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 8, 'Build Sentences 2', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'If I see bias I will compare other sites', 'If I see bias, I will compare other sites', '["If", "I", "see", "bias,", "I", "will", "compare", "other", "sites"]'::jsonb),
    (activity_id_var, 'If friends spread a rumor I will ask for proof', 'If friends spread a rumor, I will ask for proof', '["If", "friends", "spread", "a", "rumor,", "I", "will", "ask", "for", "proof"]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'speaking_practice', 9, 'Talk About News', 'Practice talking about checking information', '{"prompts": ["How do you check if news is real?", "What do you do when a headline feels fake?", "When do you decide to stop doomscrolling?"]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (
      lesson_id,
      activity_type,
      activity_order,
      title,
      description,
      content
    ) VALUES (
      'B1-L32',
      'speaking_improvement',
      10,
      'Speaking Improvement',
      'Read the improved version of your speech',
      '{"type": "speaking_improvement", "similarityThreshold": 70}'::jsonb
    );
END $$;

