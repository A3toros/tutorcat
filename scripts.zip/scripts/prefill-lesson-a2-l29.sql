-- =========================================
-- Pre-fill Database with Sample Lesson Data
-- A2-L29: Going to the Gym
-- =========================================

DELETE FROM grammar_sentences WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'A2-L29');
DELETE FROM vocabulary_items WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'A2-L29');
DELETE FROM lesson_activities WHERE lesson_id = 'A2-L29';
DELETE FROM lessons WHERE id = 'A2-L29';

INSERT INTO lessons (id, level, lesson_number, topic) VALUES
('A2-L29', 'A2', 29, 'Going to the Gym')
ON CONFLICT (id) DO UPDATE SET topic = EXCLUDED.topic;

DO $$
DECLARE
    lesson_id_var TEXT := 'A2-L29';
    activity_id_var UUID;
BEGIN
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'warm_up_speaking', 1, 'Gym Habits', 'Talk about gym routines', '{"prompt": "How often do you go to the gym or exercise?"}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_intro', 2, 'Gym Words', 'Learn gym vocabulary', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'gym', 'ยิม', NULL),
    (activity_id_var, 'weights', 'ดัมเบล/น้ำหนัก', NULL),
    (activity_id_var, 'treadmill', 'ลู่วิ่ง', NULL),
    (activity_id_var, 'set', 'เซต', NULL),
    (activity_id_var, 'reps', 'ครั้ง', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_matching_drag', 3, 'Match Gym Words', 'Match gym words', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'gym', 'ยิม', NULL),
    (activity_id_var, 'weights', 'ดัมเบล/น้ำหนัก', NULL),
    (activity_id_var, 'treadmill', 'ลู่วิ่ง', NULL),
    (activity_id_var, 'set', 'เซต', NULL),
    (activity_id_var, 'reps', 'ครั้ง', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 4, 'Complete the Sentences 1', 'Fill with the correct word', '{"text": "I go to the ___. I lift ___. I run on the ___.", "blanks": [{"id": "blank1", "text": "gym", "options": ["gym", "weights", "treadmill", "reps"], "correctAnswer": "gym"}, {"id": "blank2", "text": "weights", "options": ["weights", "treadmill", "set", "reps"], "correctAnswer": "weights"}, {"id": "blank3", "text": "treadmill", "options": ["treadmill", "weights", "set", "reps"], "correctAnswer": "treadmill"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 5, 'Complete the Sentences 2', 'Fill with the correct word', '{"text": "I do three ___ of 10 ___. My friend uses the ___.", "blanks": [{"id": "blank1", "text": "sets", "options": ["sets", "reps", "treadmill", "weights"], "correctAnswer": "sets"}, {"id": "blank2", "text": "reps", "options": ["reps", "weights", "treadmill", "gym"], "correctAnswer": "reps"}, {"id": "blank3", "text": "treadmill", "options": ["treadmill", "weights", "gym", "sets"], "correctAnswer": "treadmill"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_explanation', 6, 'Adverbs of Frequency', 'Talk about how often you go', '{"rules": "Use adverbs to show frequency: always, usually, often, sometimes, rarely, never.\nPosition: before the main verb; after be.\n- I often go to the gym.\n- She is usually early.", "examples": ["I often go to the gym.", "She is usually early.", "We sometimes skip Monday.", "Do you always stretch first?", "He rarely uses weights."]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 7, 'Build Sentences 1', 'Arrange words', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'I often go to the gym', 'I often go to the gym.', '["I", "often", "go", "to", "the", "gym."]'::jsonb),
    (activity_id_var, 'She is usually early', 'She is usually early.', '["She", "is", "usually", "early."]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 8, 'Build Sentences 2', 'Arrange words', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'Do you always stretch first', 'Do you always stretch first?', '["Do", "you", "always", "stretch", "first?"]'::jsonb),
    (activity_id_var, 'He rarely uses weights', 'He rarely uses weights.', '["He", "rarely", "uses", "weights."]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'speaking_practice', 9, 'Talk About the Gym', 'Practice gym habits', '{"prompts": ["How often do you go to the gym or exercise?", "Do you follow an exercise plan?", "Who shows you new exercises?", "What equipment do you usually use?", "Do you exercise alone or with friends?"]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (
      lesson_id,
      activity_type,
      activity_order,
      title,
      description,
      content
    ) VALUES (
      'A2-L29',
      'speaking_improvement',
      10,
      'Speaking Improvement',
      'Read the improved version of your speech',
      '{"type": "speaking_improvement", "similarityThreshold": 70}'::jsonb
    );
END $$;

