-- =========================================
-- Pre-fill Database with Sample Lesson Data
-- B1-L100: Personal Growth Wrap-Up
-- =========================================

DELETE FROM grammar_sentences WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'B1-L100');
DELETE FROM vocabulary_items WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'B1-L100');
DELETE FROM lesson_activities WHERE lesson_id = 'B1-L100';
DELETE FROM lessons WHERE id = 'B1-L100';

INSERT INTO lessons (id, level, lesson_number, topic) VALUES
('B1-L100', 'B1', 100, 'Personal Growth Wrap-Up')
ON CONFLICT (id) DO UPDATE SET topic = EXCLUDED.topic;

DO $$
DECLARE
    lesson_id_var TEXT := 'B1-L100';
    activity_id_var UUID;
BEGIN
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'warm_up_speaking', 1, 'Looking Ahead', 'Reflect on growth and next steps', '{"prompt": "What will you focus on improving next month?"}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_intro', 2, 'Growth Words', 'Review and plan personal growth vocabulary', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'reflect', 'สะท้อนคิด', NULL),
    (activity_id_var, 'plan', 'วางแผน', NULL),
    (activity_id_var, 'commit', 'มุ่งมั่น', NULL),
    (activity_id_var, 'progress', 'ความก้าวหน้า', NULL),
    (activity_id_var, 'habit', 'นิสัย/พฤติกรรม', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_matching_drag', 3, 'Match Growth Words', 'Match words with meanings', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'reflect', 'สะท้อนคิด', NULL),
    (activity_id_var, 'plan', 'วางแผน', NULL),
    (activity_id_var, 'commit', 'มุ่งมั่น', NULL),
    (activity_id_var, 'progress', 'ความก้าวหน้า', NULL),
    (activity_id_var, 'habit', 'นิสัย/พฤติกรรม', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 4, 'Complete the Sentences 1', 'Fill with the correct word', '{"text": "I ___ on this month. I will ___ one clear step. I want steady ___.", "blanks": [{"id": "blank1", "text": "reflect", "options": ["reflect", "plan", "commit", "habit"], "correctAnswer": "reflect"}, {"id": "blank2", "text": "plan", "options": ["plan", "progress", "commit", "reflect"], "correctAnswer": "plan"}, {"id": "blank3", "text": "progress", "options": ["progress", "habit", "plan", "reflect"], "correctAnswer": "progress"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 5, 'Complete the Sentences 2', 'Fill with the correct word', '{"text": "I will ___ to one ___ daily. Small wins show ___.", "blanks": [{"id": "blank1", "text": "commit", "options": ["commit", "reflect", "plan", "progress"], "correctAnswer": "commit"}, {"id": "blank2", "text": "habit", "options": ["habit", "progress", "commit", "plan"], "correctAnswer": "habit"}, {"id": "blank3", "text": "progress", "options": ["progress", "habit", "plan", "reflect"], "correctAnswer": "progress"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    -- Grammar Explanation: Mixed Review (relative, conditional, modals) capstone
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_explanation', 6, 'Mixed Grammar Capstone', 'Combine relative clauses, first conditional, modals for planning', '{"rules": "Relative clauses: who/which/that for essential details. First conditional: If + present, will + base for likely results. Modals should/must for advice/necessity. Keep sentences clear, no contractions.", "examples": ["The habit that I will build is reading daily.", "If I track progress weekly, I will stay motivated.", "I must plan one small action per day.", "You should reflect on what actually worked.", "The routine that helps most is sleep on time."]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 7, 'Build Sentences 1', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'The habit that I will build is reading daily', 'The habit that I will build is reading daily', '["The", "habit", "that", "I", "will", "build", "is", "reading", "daily"]'::jsonb),
    (activity_id_var, 'If I track progress weekly I will stay motivated', 'If I track progress weekly, I will stay motivated', '["If", "I", "track", "progress", "weekly,", "I", "will", "stay", "motivated"]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 8, 'Build Sentences 2', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'I must plan one small action per day', 'I must plan one small action per day', '["I", "must", "plan", "one", "small", "action", "per", "day"]'::jsonb),
    (activity_id_var, 'You should reflect on what actually worked', 'You should reflect on what actually worked', '["You", "should", "reflect", "on", "what", "actually", "worked"]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'speaking_practice', 9, 'Talk About Next Steps', 'Reflect on growth and future focus', '{"prompts": ["Which topic was most useful to you?", "What will you focus on improving next month?", "How will you keep yourself on track?"]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (
      lesson_id,
      activity_type,
      activity_order,
      title,
      description,
      content
    ) VALUES (
      'B1-L100',
      'speaking_improvement',
      10,
      'Speaking Improvement',
      'Read the improved version of your speech',
      '{"type": "speaking_improvement", "similarityThreshold": 70}'::jsonb
    );
END $$;

