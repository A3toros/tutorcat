-- =========================================
-- Pre-fill Database with Sample Lesson Data
-- B1-L19: Childhood Memories
-- =========================================

DELETE FROM grammar_sentences WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'B1-L19');
DELETE FROM vocabulary_items WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'B1-L19');
DELETE FROM lesson_activities WHERE lesson_id = 'B1-L19';
DELETE FROM lessons WHERE id = 'B1-L19';

INSERT INTO lessons (id, level, lesson_number, topic) VALUES
('B1-L19', 'B1', 19, 'Childhood Memories')
ON CONFLICT (id) DO UPDATE SET topic = EXCLUDED.topic;

DO $$
DECLARE
    lesson_id_var TEXT := 'B1-L19';
    activity_id_var UUID;
BEGIN
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'warm_up_speaking', 1, 'Childhood Moments', 'Talk about strong childhood memories', '{"prompt": "What were you doing in a favorite childhood memory?"}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_intro', 2, 'Memory Words', 'Learn vocabulary about childhood memories', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'remember', 'จำ', NULL),
    (activity_id_var, 'pretend', 'แกล้งทำ', NULL),
    (activity_id_var, 'explore', 'สำรวจ', NULL),
    (activity_id_var, 'discover', 'ค้นพบ', NULL),
    (activity_id_var, 'favorite', 'ชื่นชอบ', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_matching_drag', 3, 'Match Memory Words', 'Match words with meanings', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'remember', 'จำ', NULL),
    (activity_id_var, 'pretend', 'แกล้งทำ', NULL),
    (activity_id_var, 'explore', 'สำรวจ', NULL),
    (activity_id_var, 'discover', 'ค้นพบ', NULL),
    (activity_id_var, 'favorite', 'ชื่นชอบ', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 4, 'Complete the Sentences 1', 'Fill with the correct word', '{"text": "I clearly ___. We used to ___ we were heroes. We loved to ___ the woods.", "blanks": [{"id": "blank1", "text": "remember", "options": ["remember", "pretend", "explore", "discover"], "correctAnswer": "remember"}, {"id": "blank2", "text": "pretend", "options": ["pretend", "remember", "explore", "favorite"], "correctAnswer": "pretend"}, {"id": "blank3", "text": "explore", "options": ["explore", "discover", "remember", "pretend"], "correctAnswer": "explore"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 5, 'Complete the Sentences 2', 'Fill with the correct word', '{"text": "We would ___ new places. That park is my ___ spot. I still ___ that day.", "blanks": [{"id": "blank1", "text": "discover", "options": ["discover", "explore", "pretend", "favorite"], "correctAnswer": "discover"}, {"id": "blank2", "text": "favorite", "options": ["favorite", "remember", "discover", "pretend"], "correctAnswer": "favorite"}, {"id": "blank3", "text": "remember", "options": ["remember", "favorite", "explore", "discover"], "correctAnswer": "remember"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    -- Grammar Explanation: Past Continuous (background memories)
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_explanation', 6, 'Past Continuous for Background Actions', 'Use was/were + verb-ing to describe what was happening in the background of a memory', '{"rules": "Past continuous: was/were + verb-ing to describe an action in progress in the past, often background for another event.\\n- I was playing outside when it started to rain.\\n- We were exploring when we found the lake.", "examples": ["I was playing outside when it started to rain.", "We were exploring the park when we discovered a pond.", "She was reading while I was drawing.", "They were pretending to be heroes all afternoon.", "We were laughing when the lights went out."]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 7, 'Build Sentences 1', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'I was playing outside when it started to rain', 'I was playing outside when it started to rain', '["I", "was", "playing", "outside", "when", "it", "started", "to", "rain"]'::jsonb),
    (activity_id_var, 'We were exploring the park when we discovered a pond', 'We were exploring the park when we discovered a pond', '["We", "were", "exploring", "the", "park", "when", "we", "discovered", "a", "pond"]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 8, 'Build Sentences 2', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'They were pretending to be heroes all afternoon', 'They were pretending to be heroes all afternoon', '["They", "were", "pretending", "to", "be", "heroes", "all", "afternoon"]'::jsonb),
    (activity_id_var, 'She was reading while I was drawing', 'She was reading while I was drawing', '["She", "was", "reading", "while", "I", "was", "drawing"]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'speaking_practice', 9, 'Talk About Childhood Memories', 'Practice talking about strong memories', '{"prompts": ["What were you doing in a favorite childhood memory?", "Tell me about a place you explored as a kid.", "Who made your childhood feel safe or fun?"]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (
      lesson_id,
      activity_type,
      activity_order,
      title,
      description,
      content
    ) VALUES (
      'B1-L19',
      'speaking_improvement',
      10,
      'Speaking Improvement',
      'Read the improved version of your speech',
      '{"type": "speaking_improvement", "similarityThreshold": 70}'::jsonb
    );
END $$;


