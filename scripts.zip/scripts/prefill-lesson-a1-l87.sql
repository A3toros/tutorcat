-- =========================================
-- Pre-fill Database with Sample Lesson Data
-- A1-L87: Tidy Your Room
-- =========================================

DELETE FROM grammar_sentences WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'A1-L87');
DELETE FROM vocabulary_items WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'A1-L87');
DELETE FROM lesson_activities WHERE lesson_id = 'A1-L87';
DELETE FROM lessons WHERE id = 'A1-L87';

INSERT INTO lessons (id, level, lesson_number, topic) VALUES
('A1-L87', 'A1', 87, 'Tidy Your Room')
ON CONFLICT (id) DO UPDATE SET topic = EXCLUDED.topic;

DO $$
DECLARE
    lesson_id_var TEXT := 'A1-L87';
    activity_id_var UUID;
BEGIN
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'warm_up_speaking', 1, 'Room Clean', 'Talk about tidying', '{"prompt": "Do you tidy your room?"}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_intro', 2, 'Tidy Words', 'Learn tidy words', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'tidy', 'จัดให้เรียบร้อย', NULL),
    (activity_id_var, 'clean', 'ทำความสะอาด', NULL),
    (activity_id_var, 'pick', 'เก็บ', NULL),
    (activity_id_var, 'fold', 'พับ', NULL),
    (activity_id_var, 'trash', 'ขยะ', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_matching_drag', 3, 'Match Tidy Words', 'Match tidy words', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'tidy', 'จัดให้เรียบร้อย', NULL),
    (activity_id_var, 'clean', 'ทำความสะอาด', NULL),
    (activity_id_var, 'pick', 'เก็บ', NULL),
    (activity_id_var, 'fold', 'พับ', NULL),
    (activity_id_var, 'trash', 'ขยะ', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 4, 'Complete the Sentences 1', 'Fill with the correct word', '{"text": "___ the bed. ___ the clothes.", "blanks": [{"id": "blank1", "text": "Tidy", "options": ["Tidy", "Clean", "Fold", "Pick"], "correctAnswer": "Tidy"}, {"id": "blank2", "text": "Fold", "options": ["Fold", "Pick", "Tidy", "Trash"], "correctAnswer": "Fold"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 5, 'Complete the Sentences 2', 'Fill with the correct word', '{"text": "___ toys. Take out the ___.", "blanks": [{"id": "blank1", "text": "Pick", "options": ["Pick", "Fold", "Clean", "Tidy"], "correctAnswer": "Pick"}, {"id": "blank2", "text": "trash", "options": ["trash", "bed", "clothes", "toys"], "correctAnswer": "trash"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_explanation', 6, 'Imperatives (home)', 'Give tidy commands', '{"rules": "Use base verb to tell actions.\n- Tidy the bed. Fold clothes. Pick toys. Clean the room.", "examples": ["Tidy the bed.", "Fold the clothes.", "Pick the toys.", "Take out the trash.", "Clean the room."]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 7, 'Build Sentences 1', 'Arrange words', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'Tidy the bed', 'Tidy the bed.', '["Tidy", "the", "bed."]'::jsonb),
    (activity_id_var, 'Fold the clothes', 'Fold the clothes.', '["Fold", "the", "clothes."]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 8, 'Build Sentences 2', 'Arrange words', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'Pick the toys', 'Pick the toys.', '["Pick", "the", "toys."]'::jsonb),
    (activity_id_var, 'Take out the trash', 'Take out the trash.', '["Take", "out", "the", "trash."]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'speaking_practice', 9, 'Talk About Tidying', 'Practice tidy commands', '{"prompts": ["Do you tidy your room?", "Do you fold clothes?", "Do you pick toys?", "Do you take out trash?", "Do you clean the room?"]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (
      lesson_id,
      activity_type,
      activity_order,
      title,
      description,
      content
    ) VALUES (
      'A1-L87',
      'speaking_improvement',
      10,
      'Speaking Improvement',
      'Read the improved version of your speech',
      '{"type": "speaking_improvement", "similarityThreshold": 70}'::jsonb
    );
END $$;

