-- =========================================
-- Pre-fill Database with Sample Lesson Data
-- B1-L17: Relationships at Work
-- =========================================

DELETE FROM grammar_sentences WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'B1-L17');
DELETE FROM vocabulary_items WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'B1-L17');
DELETE FROM lesson_activities WHERE lesson_id = 'B1-L17';
DELETE FROM lessons WHERE id = 'B1-L17';

INSERT INTO lessons (id, level, lesson_number, topic) VALUES
('B1-L17', 'B1', 17, 'Relationships at Work')
ON CONFLICT (id) DO UPDATE SET topic = EXCLUDED.topic;

DO $$
DECLARE
    lesson_id_var TEXT := 'B1-L17';
    activity_id_var UUID;
BEGIN
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'warm_up_speaking', 1, 'Trust at Work', 'Talk about building trust with coworkers', '{"prompt": "How do you build trust with coworkers?"}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_intro', 2, 'Work Relationship Words', 'Learn vocabulary about workplace relationships', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'cooperate', 'ร่วมมือ', NULL),
    (activity_id_var, 'support', 'สนับสนุน', NULL),
    (activity_id_var, 'resolve', 'แก้ไข', NULL),
    (activity_id_var, 'mentor', 'พี่เลี้ยง', NULL),
    (activity_id_var, 'feedback', 'ข้อเสนอแนะ', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_matching_drag', 3, 'Match Relationship Words', 'Match words with meanings', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'cooperate', 'ร่วมมือ', NULL),
    (activity_id_var, 'support', 'สนับสนุน', NULL),
    (activity_id_var, 'resolve', 'แก้ไข', NULL),
    (activity_id_var, 'mentor', 'พี่เลี้ยง', NULL),
    (activity_id_var, 'feedback', 'ข้อเสนอแนะ', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 4, 'Complete the Sentences 1', 'Fill with the correct word', '{"text": "We ___ on projects. Managers ___ the team. A good ___ helps us grow.", "blanks": [{"id": "blank1", "text": "cooperate", "options": ["cooperate", "mentor", "resolve", "feedback"], "correctAnswer": "cooperate"}, {"id": "blank2", "text": "support", "options": ["support", "cooperate", "resolve", "feedback"], "correctAnswer": "support"}, {"id": "blank3", "text": "mentor", "options": ["mentor", "feedback", "resolve", "support"], "correctAnswer": "mentor"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 5, 'Complete the Sentences 2', 'Fill with the correct word', '{"text": "We need to ___ conflicts. Clear ___ keeps trust. Leaders should ___ fairly.", "blanks": [{"id": "blank1", "text": "resolve", "options": ["resolve", "cooperate", "mentor", "support"], "correctAnswer": "resolve"}, {"id": "blank2", "text": "feedback", "options": ["feedback", "support", "cooperate", "resolve"], "correctAnswer": "feedback"}, {"id": "blank3", "text": "support", "options": ["support", "mentor", "resolve", "feedback"], "correctAnswer": "support"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    -- Grammar Explanation: Gerunds and Infinitives (work relationships)
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_explanation', 6, 'Gerunds and Infinitives', 'When to use verb-ing or to + verb with workplace verbs', '{"rules": "Some verbs take gerunds (verb-ing), some take infinitives (to + verb).\\n- enjoy working, avoid arguing, keep improving\\n- decide to meet, agree to help, plan to support\\nUse correct patterns for clarity at work.", "examples": ["I enjoy working with supportive teammates.", "We agreed to meet at three.", "They decided to resolve the issue today.", "She avoids arguing with clients.", "He plans to give feedback tomorrow."]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 7, 'Build Sentences 1', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'I enjoy working with supportive teammates', 'I enjoy working with supportive teammates', '["I", "enjoy", "working", "with", "supportive", "teammates"]'::jsonb),
    (activity_id_var, 'We agreed to meet at three', 'We agreed to meet at three', '["We", "agreed", "to", "meet", "at", "three"]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 8, 'Build Sentences 2', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'They decided to resolve the issue today', 'They decided to resolve the issue today', '["They", "decided", "to", "resolve", "the", "issue", "today"]'::jsonb),
    (activity_id_var, 'She avoids arguing with clients', 'She avoids arguing with clients', '["She", "avoids", "arguing", "with", "clients"]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'speaking_practice', 9, 'Talk About Work Relationships', 'Practice talking about trust and teamwork', '{"prompts": ["How do you build trust with coworkers?", "Tell me about a conflict you helped resolve.", "What do you enjoy doing with colleagues outside tasks?"]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (
      lesson_id,
      activity_type,
      activity_order,
      title,
      description,
      content
    ) VALUES (
      'B1-L17',
      'speaking_improvement',
      10,
      'Speaking Improvement',
      'Read the improved version of your speech',
      '{"type": "speaking_improvement", "similarityThreshold": 70}'::jsonb
    );
END $$;


