-- =========================================
-- Pre-fill Database with Sample Lesson Data
-- B1-L33: Strengths & Weaknesses
-- =========================================

DELETE FROM grammar_sentences WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'B1-L33');
DELETE FROM vocabulary_items WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'B1-L33');
DELETE FROM lesson_activities WHERE lesson_id = 'B1-L33';
DELETE FROM lessons WHERE id = 'B1-L33';

INSERT INTO lessons (id, level, lesson_number, topic) VALUES
('B1-L33', 'B1', 33, 'Strengths & Weaknesses')
ON CONFLICT (id) DO UPDATE SET topic = EXCLUDED.topic;

DO $$
DECLARE
    lesson_id_var TEXT := 'B1-L33';
    activity_id_var UUID;
BEGIN
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'warm_up_speaking', 1, 'Skills and Habits', 'Talk about improving skills', '{"prompt": "What do you enjoy getting better at?"}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_intro', 2, 'Skill Words', 'Learn vocabulary about strengths and weaknesses', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'improve', 'พัฒนา', NULL),
    (activity_id_var, 'practice', 'ฝึกฝน', NULL),
    (activity_id_var, 'avoid', 'หลีกเลี่ยง', NULL),
    (activity_id_var, 'prefer', 'ชอบมากกว่า', NULL),
    (activity_id_var, 'challenge', 'ท้าทาย', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_matching_drag', 3, 'Match Skill Words', 'Match words with meanings', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'improve', 'พัฒนา', NULL),
    (activity_id_var, 'practice', 'ฝึกฝน', NULL),
    (activity_id_var, 'avoid', 'หลีกเลี่ยง', NULL),
    (activity_id_var, 'prefer', 'ชอบมากกว่า', NULL),
    (activity_id_var, 'challenge', 'ท้าทาย', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 4, 'Complete the Sentences 1', 'Fill with the correct word', '{"text": "I want to ___. I need to ___ daily. I usually ___ calm work.", "blanks": [{"id": "blank1", "text": "improve", "options": ["improve", "practice", "avoid", "challenge"], "correctAnswer": "improve"}, {"id": "blank2", "text": "practice", "options": ["practice", "avoid", "prefer", "challenge"], "correctAnswer": "practice"}, {"id": "blank3", "text": "prefer", "options": ["prefer", "challenge", "improve", "avoid"], "correctAnswer": "prefer"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 5, 'Complete the Sentences 2', 'Fill with the correct word', '{"text": "I try to ___ distractions. I love a good ___. I ___ speaking tasks now.", "blanks": [{"id": "blank1", "text": "avoid", "options": ["avoid", "practice", "prefer", "improve"], "correctAnswer": "avoid"}, {"id": "blank2", "text": "challenge", "options": ["challenge", "avoid", "practice", "improve"], "correctAnswer": "challenge"}, {"id": "blank3", "text": "enjoy", "options": ["enjoy", "practice", "prefer", "avoid"], "correctAnswer": "enjoy"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    -- Grammar Explanation: Gerunds & Infinitives (review)
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_explanation', 6, 'Gerunds and Infinitives', 'When to use verb-ing or to + verb with skill verbs', '{"rules": "Some verbs take gerund (verb-ing), others infinitive (to + verb).\\n- enjoy practicing, avoid making excuses, prefer to work early, decide to improve, try to learn.\\nKeep pairs natural and avoid contractions.", "examples": ["I enjoy practicing every morning.", "They decided to improve their presentations.", "She prefers to work in silence.", "He avoids making excuses at work.", "We plan to take on a new challenge."]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 7, 'Build Sentences 1', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'I enjoy practicing every morning', 'I enjoy practicing every morning', '["I", "enjoy", "practicing", "every", "morning"]'::jsonb),
    (activity_id_var, 'They decided to improve their presentations', 'They decided to improve their presentations', '["They", "decided", "to", "improve", "their", "presentations"]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 8, 'Build Sentences 2', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'She prefers to work in silence', 'She prefers to work in silence', '["She", "prefers", "to", "work", "in", "silence"]'::jsonb),
    (activity_id_var, 'He avoids making excuses at work', 'He avoids making excuses at work', '["He", "avoids", "making", "excuses", "at", "work"]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'speaking_practice', 9, 'Talk About Strengths', 'Practice talking about skills and habits', '{"prompts": ["What do you enjoy getting better at?", "What task do you avoid?", "Tell me about practicing a skill until it finally worked."]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (
      lesson_id,
      activity_type,
      activity_order,
      title,
      description,
      content
    ) VALUES (
      'B1-L33',
      'speaking_improvement',
      10,
      'Speaking Improvement',
      'Read the improved version of your speech',
      '{"type": "speaking_improvement", "similarityThreshold": 70}'::jsonb
    );
END $$;

