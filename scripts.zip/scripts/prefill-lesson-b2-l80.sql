-- =========================================
-- Pre-fill Database with Sample Lesson Data
-- B2-L80: Personal growth through travel
-- =========================================

DELETE FROM grammar_sentences WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'B2-L80');
DELETE FROM vocabulary_items WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'B2-L80');
DELETE FROM lesson_activities WHERE lesson_id = 'B2-L80';
DELETE FROM lessons WHERE id = 'B2-L80';

INSERT INTO lessons (id, level, lesson_number, topic) VALUES
('B2-L80', 'B2', 80, 'Personal growth through travel')
ON CONFLICT (id) DO UPDATE SET topic = EXCLUDED.topic;

DO $$
DECLARE
    lesson_id_var TEXT := 'B2-L80';
    activity_id_var UUID;
BEGIN
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'warm_up_speaking', 1, 'Travel Lessons', 'Talk about outcomes of trips', '{"prompt": "If you hadn’t traveled, what growth would be missing, and what stayed with you?"}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_intro', 2, 'Growth Words', 'Key words for travel lessons', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'perspective', 'มุมมอง', NULL),
    (activity_id_var, 'humble', 'ถ่อมตัว', NULL),
    (activity_id_var, 'resilience', 'ความยืดหยุ่น/ฟื้นตัวได้', NULL),
    (activity_id_var, 'adapt', 'ปรับตัว', NULL),
    (activity_id_var, 'lesson', 'บทเรียน', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_matching_drag', 3, 'Match Growth Words', 'Match words with meanings', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'perspective', 'มุมมอง', NULL),
    (activity_id_var, 'humble', 'ถ่อมตัว', NULL),
    (activity_id_var, 'resilience', 'ความยืดหยุ่น/ฟื้นตัวได้', NULL),
    (activity_id_var, 'adapt', 'ปรับตัว', NULL),
    (activity_id_var, 'lesson', 'บทเรียน', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 4, 'Complete the Sentences 1', 'Fill with the correct word', '{"text": "Travel changed my ___. It taught me to ___. It built ___.", "blanks": [{"id": "blank1", "text": "perspective", "options": ["perspective", "resilience", "lesson", "humble"], "correctAnswer": "perspective"}, {"id": "blank2", "text": "adapt", "options": ["adapt", "humble", "resilience", "lesson"], "correctAnswer": "adapt"}, {"id": "blank3", "text": "resilience", "options": ["resilience", "lesson", "humble", "perspective"], "correctAnswer": "resilience"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 5, 'Complete the Sentences 2', 'Fill with the correct word', '{"text": "I feel more ___. One __ stayed with me.", "blanks": [{"id": "blank1", "text": "humble", "options": ["humble", "adapt", "resilience", "perspective"], "correctAnswer": "humble"}, {"id": "blank2", "text": "lesson", "options": ["lesson", "resilience", "humble", "adapt"], "correctAnswer": "lesson"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_explanation', 6, 'Third Conditional', 'Reflect on past travel and present growth', '{"rules": "Use if + past perfect + would have + past participle for unreal past; could/might have for less certain.\\n- If I hadn’t traveled, I would have missed this perspective.", "examples": ["If I hadn’t traveled, I would have missed this perspective.", "If we had skipped that trip, we might have stayed less adaptable.", "If she had not gone abroad, she would have been less humble.", "If they had traveled earlier, they could have learned sooner.", "If you had faced that challenge, you might have built resilience."]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 7, 'Build Sentences 1', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'If I hadn’t traveled, I would have missed this perspective', 'If I hadn’t traveled, I would have missed this perspective.', '["If", "I", "hadn’t", "traveled,", "I", "would", "have", "missed", "this", "perspective."]'::jsonb),
    (activity_id_var, 'If we had skipped that trip, we might have stayed less adaptable', 'If we had skipped that trip, we might have stayed less adaptable.', '["If", "we", "had", "skipped", "that", "trip,", "we", "might", "have", "stayed", "less", "adaptable."]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 8, 'Build Sentences 2', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'If she had not gone abroad, she would have been less humble', 'If she had not gone abroad, she would have been less humble.', '["If", "she", "had", "not", "gone", "abroad,", "she", "would", "have", "been", "less", "humble."]'::jsonb),
    (activity_id_var, 'If they had traveled earlier, they could have learned sooner', 'If they had traveled earlier, they could have learned sooner.', '["If", "they", "had", "traveled", "earlier,", "they", "could", "have", "learned", "sooner."]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'speaking_practice', 9, 'Talk About Growth from Travel', 'Practice third conditional', '{"prompts": ["If you hadn’t traveled, what growth would be missing?", "What lesson stayed with you from a trip?", "How did travel make you more humble?"]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (
      lesson_id,
      activity_type,
      activity_order,
      title,
      description,
      content
    ) VALUES (
      'B2-L80',
      'speaking_improvement',
      10,
      'Speaking Improvement',
      'Read the improved version of your speech',
      '{"type": "speaking_improvement", "similarityThreshold": 70}'::jsonb
    );
END $$;


