-- =========================================
-- Pre-fill Database with Sample Lesson Data
-- A2-L14: Daily Work Tasks
-- =========================================

DELETE FROM grammar_sentences WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'A2-L14');
DELETE FROM vocabulary_items WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'A2-L14');
DELETE FROM lesson_activities WHERE lesson_id = 'A2-L14';
DELETE FROM lessons WHERE id = 'A2-L14';

INSERT INTO lessons (id, level, lesson_number, topic) VALUES
('A2-L14', 'A2', 14, 'Daily Work Tasks')
ON CONFLICT (id) DO UPDATE SET topic = EXCLUDED.topic;

DO $$
DECLARE
    lesson_id_var TEXT := 'A2-L14';
    activity_id_var UUID;
BEGIN
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'warm_up_speaking', 1, 'Work Day', 'Talk about your daily work', '{"prompt": "What tasks do you do every day at work or school?"}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_intro', 2, 'Work Words', 'Learn daily work vocabulary', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'meeting', 'การประชุม', NULL),
    (activity_id_var, 'email', 'อีเมล', NULL),
    (activity_id_var, 'report', 'รายงาน', NULL),
    (activity_id_var, 'call', 'โทร', NULL),
    (activity_id_var, 'break', 'พัก', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_matching_drag', 3, 'Match Work Words', 'Match daily work words', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'meeting', 'การประชุม', NULL),
    (activity_id_var, 'email', 'อีเมล', NULL),
    (activity_id_var, 'report', 'รายงาน', NULL),
    (activity_id_var, 'call', 'โทร', NULL),
    (activity_id_var, 'break', 'พัก', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 4, 'Complete the Sentences 1', 'Fill with the correct word', '{"text": "I read my ___ in the morning. We have a team ___ at 10. I write a ___ every Friday.", "blanks": [{"id": "blank1", "text": "emails", "options": ["emails", "meeting", "report", "call"], "correctAnswer": "emails"}, {"id": "blank2", "text": "meeting", "options": ["meeting", "report", "emails", "call"], "correctAnswer": "meeting"}, {"id": "blank3", "text": "report", "options": ["report", "call", "meeting", "emails"], "correctAnswer": "report"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 5, 'Complete the Sentences 2', 'Fill with the correct word', '{"text": "I take a short ___ at 3 p.m. I make a ___ to a client. After the ___, I send an ___ summary.", "blanks": [{"id": "blank1", "text": "break", "options": ["break", "call", "meeting", "email"], "correctAnswer": "break"}, {"id": "blank2", "text": "call", "options": ["call", "email", "report", "break"], "correctAnswer": "call"}, {"id": "blank3", "text": "meeting", "options": ["meeting", "call", "break", "email"], "correctAnswer": "meeting"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_explanation', 6, 'Present Simple', 'Talk about daily routines', '{"rules": "Use present simple for routines and facts.\n- I read emails every morning.\n- She has a meeting at ten.\nQuestions: Do/Does + subject + verb?\nNegatives: don''t/doesn''t + verb.", "examples": ["I read emails every day.", "She writes a report on Friday.", "Do you take a break?", "We don''t call clients at night.", "Does he join the meeting?"]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 7, 'Build Sentences 1', 'Arrange words', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'I read emails every morning', 'I read emails every morning.', '["I", "read", "emails", "every", "morning."]'::jsonb),
    (activity_id_var, 'She writes a report on Friday', 'She writes a report on Friday.', '["She", "writes", "a", "report", "on", "Friday."]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 8, 'Build Sentences 2', 'Arrange words', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'Do you take a break at three', 'Do you take a break at three?', '["Do", "you", "take", "a", "break", "at", "three?"]'::jsonb),
    (activity_id_var, 'We don t call clients at night', 'We don''t call clients at night.', '["We", "don''t", "call", "clients", "at", "night."]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'speaking_practice', 9, 'Talk About Work Tasks', 'Practice daily work talk', '{"prompts": ["What tasks do you do every day?", "When do you usually take breaks?", "Do you like meetings or group work?", "What is your first task in the morning?", "How do you organize your work or school day?"]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (
      lesson_id,
      activity_type,
      activity_order,
      title,
      description,
      content
    ) VALUES (
      'A2-L14',
      'speaking_improvement',
      10,
      'Speaking Improvement',
      'Read the improved version of your speech',
      '{"type": "speaking_improvement", "similarityThreshold": 70}'::jsonb
    );
END $$;

