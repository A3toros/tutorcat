#!/usr/bin/env python3
"""
Combine all C1 lesson SQL files into a single file
"""

import os
from pathlib import Path

script_dir = Path(__file__).parent
output_file = script_dir / 'all-c1-lessons.sql'

# Get all C1 lesson files and sort them numerically
c1_files = []
for i in range(1, 101):  # L1 to L100
    file_path = script_dir / f'prefill-lesson-c1-l{i}.sql'
    if file_path.exists():
        c1_files.append((i, file_path))

print(f"Found {len(c1_files)} C1 lesson files")

# Combine all files
with open(output_file, 'w', encoding='utf-8') as out:
    out.write("-- =========================================\n")
    out.write("-- All C1 Lessons (L1-L100) Combined\n")
    out.write("-- =========================================\n\n")
    
    for lesson_num, file_path in c1_files:
        print(f"Processing C1-L{lesson_num}...")
        with open(file_path, 'r', encoding='utf-8') as f:
            content = f.read()
            # Add a separator comment between lessons
            out.write(f"\n-- =========================================\n")
            out.write(f"-- C1 Lesson {lesson_num}\n")
            out.write(f"-- =========================================\n\n")
            out.write(content)
            out.write("\n\n")

print(f"\nCombined all C1 lessons into: {output_file}")
print(f"Total lessons: {len(c1_files)}")
