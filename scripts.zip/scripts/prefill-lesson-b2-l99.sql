-- =========================================
-- Pre-fill Database with Sample Lesson Data
-- B2-L99: Future Perfect wrap
-- =========================================

DELETE FROM grammar_sentences WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'B2-L99');
DELETE FROM vocabulary_items WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'B2-L99');
DELETE FROM lesson_activities WHERE lesson_id = 'B2-L99';
DELETE FROM lessons WHERE id = 'B2-L99';

INSERT INTO lessons (id, level, lesson_number, topic) VALUES
('B2-L99', 'B2', 99, 'Future Perfect wrap')
ON CONFLICT (id) DO UPDATE SET topic = EXCLUDED.topic;

DO $$
DECLARE
    lesson_id_var TEXT := 'B2-L99';
    activity_id_var UUID;
BEGIN
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'warm_up_speaking', 1, 'Looking Ahead', 'Talk about achievements by a future point', '{"prompt": "By three years out, what will you have done and prepared?"}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_intro', 2, 'Future Wrap Words', 'Key words for goals and prep', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'achieve', 'บรรลุ', NULL),
    (activity_id_var, 'prepare', 'เตรียม', NULL),
    (activity_id_var, 'anticipate', 'คาดการณ์/คาดหวัง', NULL),
    (activity_id_var, 'transition', 'การเปลี่ยนผ่าน', NULL),
    (activity_id_var, 'save', 'ออม/เก็บ', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_matching_drag', 3, 'Match Future Wrap Words', 'Match words with meanings', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'achieve', 'บรรลุ', NULL),
    (activity_id_var, 'prepare', 'เตรียม', NULL),
    (activity_id_var, 'anticipate', 'คาดการณ์/คาดหวัง', NULL),
    (activity_id_var, 'transition', 'การเปลี่ยนผ่าน', NULL),
    (activity_id_var, 'save', 'ออม/เก็บ', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 4, 'Complete the Sentences 1', 'Fill with the correct word', '{"text": "By then I will ___ two goals. I will ___ for the next step.", "blanks": [{"id": "blank1", "text": "achieve", "options": ["achieve", "prepare", "anticipate", "save"], "correctAnswer": "achieve"}, {"id": "blank2", "text": "prepare", "options": ["prepare", "transition", "anticipate", "save"], "correctAnswer": "prepare"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 5, 'Complete the Sentences 2', 'Fill with the correct word', '{"text": "I will ___ the ___. I hope to ___ enough.", "blanks": [{"id": "blank1", "text": "anticipate", "options": ["anticipate", "achieve", "prepare", "transition"], "correctAnswer": "anticipate"}, {"id": "blank2", "text": "transition", "options": ["transition", "anticipate", "save", "prepare"], "correctAnswer": "transition"}, {"id": "blank3", "text": "save", "options": ["save", "anticipate", "achieve", "prepare"], "correctAnswer": "save"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_explanation', 6, 'Future Perfect', 'Describe completed actions before a future time', '{"rules": "Use will have + past participle to show actions completed before a future point.\\n- By next year, I will have finished the degree.\\nInclude time markers (by, by the time, before).", "examples": ["By three years out, I will have achieved my main goal.", "By next summer, I will have prepared for the transition.", "I will have saved enough before moving.", "By the time I graduate, I will have built a portfolio.", "By next term, we will have anticipated the changes."]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 7, 'Build Sentences 1', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'By three years out, I will have achieved my main goal', 'By three years out, I will have achieved my main goal.', '["By", "three", "years", "out,", "I", "will", "have", "achieved", "my", "main", "goal."]'::jsonb),
    (activity_id_var, 'I will have saved enough before moving', 'I will have saved enough before moving.', '["I", "will", "have", "saved", "enough", "before", "moving."]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 8, 'Build Sentences 2', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'By next summer, I will have prepared for the transition', 'By next summer, I will have prepared for the transition.', '["By", "next", "summer,", "I", "will", "have", "prepared", "for", "the", "transition."]'::jsonb),
    (activity_id_var, 'By the time I graduate, I will have built a portfolio', 'By the time I graduate, I will have built a portfolio.', '["By", "the", "time", "I", "graduate,", "I", "will", "have", "built", "a", "portfolio."]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'speaking_practice', 9, 'Talk About Future Perfect Goals', 'Practice future perfect', '{"prompts": ["By three years out, what will you have done?", "What will you have prepared for your transition?", "How much will you have saved before moving?"]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (
      lesson_id,
      activity_type,
      activity_order,
      title,
      description,
      content
    ) VALUES (
      'B2-L99',
      'speaking_improvement',
      10,
      'Speaking Improvement',
      'Read the improved version of your speech',
      '{"type": "speaking_improvement", "similarityThreshold": 70}'::jsonb
    );
END $$;


