-- =========================================
-- Pre-fill Database with Sample Lesson Data
-- B1-L98: Food Budgeting
-- =========================================

DELETE FROM grammar_sentences WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'B1-L98');
DELETE FROM vocabulary_items WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'B1-L98');
DELETE FROM lesson_activities WHERE lesson_id = 'B1-L98';
DELETE FROM lessons WHERE id = 'B1-L98';

INSERT INTO lessons (id, level, lesson_number, topic) VALUES
('B1-L98', 'B1', 98, 'Food Budgeting')
ON CONFLICT (id) DO UPDATE SET topic = EXCLUDED.topic;

DO $$
DECLARE
    lesson_id_var TEXT := 'B1-L98';
    activity_id_var UUID;
BEGIN
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'warm_up_speaking', 1, 'Groceries on a Budget', 'Talk about saving money on food', '{"prompt": "How do you keep food costs under control?"}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_intro', 2, 'Food Budget Words', 'Learn vocabulary about budgeting for food', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'bulk', 'ปริมาณมาก', NULL),
    (activity_id_var, 'leftovers', 'ของเหลือ', NULL),
    (activity_id_var, 'coupon', 'คูปองส่วนลด', NULL),
    (activity_id_var, 'seasonal', 'ตามฤดูกาล', NULL),
    (activity_id_var, 'waste', 'ของเสีย/ทิ้ง', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_matching_drag', 3, 'Match Food Budget Words', 'Match words with meanings', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'bulk', 'ปริมาณมาก', NULL),
    (activity_id_var, 'leftovers', 'ของเหลือ', NULL),
    (activity_id_var, 'coupon', 'คูปองส่วนลด', NULL),
    (activity_id_var, 'seasonal', 'ตามฤดูกาล', NULL),
    (activity_id_var, 'waste', 'ของเสีย/ทิ้ง', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 4, 'Complete the Sentences 1', 'Fill with the correct word', '{"text": "We buy in ___. We use a ___. We plan for ___.", "blanks": [{"id": "blank1", "text": "bulk", "options": ["bulk", "coupon", "leftovers", "waste"], "correctAnswer": "bulk"}, {"id": "blank2", "text": "coupon", "options": ["coupon", "seasonal", "bulk", "waste"], "correctAnswer": "coupon"}, {"id": "blank3", "text": "leftovers", "options": ["leftovers", "waste", "bulk", "coupon"], "correctAnswer": "leftovers"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 5, 'Complete the Sentences 2', 'Fill with the correct word', '{"text": "We avoid ___. We cook ___ meals. We choose ___ produce to save.", "blanks": [{"id": "blank1", "text": "waste", "options": ["waste", "leftovers", "bulk", "coupon"], "correctAnswer": "waste"}, {"id": "blank2", "text": "batch", "options": ["batch", "waste", "coupon", "bulk"], "correctAnswer": "batch"}, {"id": "blank3", "text": "seasonal", "options": ["seasonal", "batch", "waste", "coupon"], "correctAnswer": "seasonal"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    -- Grammar Explanation: Articles (a/the/zero) review
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_explanation', 6, 'Articles for Food Budgeting', 'Use a/the/zero for general vs specific items when budgeting', '{"rules": "Use a/an for single new items; the for specific known ones; zero for general plurals/uncountables.\\n- Buy a seasonal fruit.\\n- Store the leftovers.\\n- Avoid waste.", "examples": ["We plan a weekly budget for food.", "Buy seasonal vegetables at the market.", "Store the leftovers in the fridge.", "Avoid waste when cooking meals.", "Use a coupon if the store offers one."]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 7, 'Build Sentences 1', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'We plan a weekly budget for food', 'We plan a weekly budget for food', '["We", "plan", "a", "weekly", "budget", "for", "food"]'::jsonb),
    (activity_id_var, 'Buy seasonal vegetables at the market', 'Buy seasonal vegetables at the market', '["Buy", "seasonal", "vegetables", "at", "the", "market"]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 8, 'Build Sentences 2', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'Store the leftovers in the fridge', 'Store the leftovers in the fridge', '["Store", "the", "leftovers", "in", "the", "fridge"]'::jsonb),
    (activity_id_var, 'Use a coupon if the store offers one', 'Use a coupon if the store offers one', '["Use", "a", "coupon", "if", "the", "store", "offers", "one"]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'speaking_practice', 9, 'Talk About Food Budgeting', 'Practice talking about saving on food', '{"prompts": ["How do you keep food costs under control?", "What meal prep trick saves you most?", "How do you cut waste at home?"]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (
      lesson_id,
      activity_type,
      activity_order,
      title,
      description,
      content
    ) VALUES (
      'B1-L98',
      'speaking_improvement',
      10,
      'Speaking Improvement',
      'Read the improved version of your speech',
      '{"type": "speaking_improvement", "similarityThreshold": 70}'::jsonb
    );
END $$;

