-- =========================================
-- COMPREHENSIVE A2-L2 VALIDATION CHECK
-- =========================================

-- 1. Check if lesson exists
SELECT 
    id,
    level,
    lesson_number,
    topic,
    created_at
FROM lessons
WHERE id = 'A2-L2';

-- 2. Count total activities (should be 10)
SELECT 
    COUNT(*) as total_activities,
    COUNT(*) FILTER (WHERE active = TRUE) as active_activities,
    COUNT(*) FILTER (WHERE active = FALSE) as inactive_activities
FROM lesson_activities
WHERE lesson_id = 'A2-L2';

-- 3. Check expected activity sequence (should be 1-10)
SELECT 
    la.activity_order,
    la.activity_type,
    la.title,
    la.active,
    CASE 
        WHEN la.activity_order = 1 AND la.activity_type = 'warm_up_speaking' THEN '✓'
        WHEN la.activity_order = 2 AND la.activity_type = 'vocabulary_intro' THEN '✓'
        WHEN la.activity_order = 3 AND la.activity_type = 'vocabulary_matching_drag' THEN '✓'
        WHEN la.activity_order IN (4, 5) AND la.activity_type = 'vocabulary_fill_blanks' THEN '✓'
        WHEN la.activity_order = 6 AND la.activity_type = 'grammar_explanation' THEN '✓'
        WHEN la.activity_order IN (7, 8) AND la.activity_type = 'grammar_sentences' THEN '✓'
        WHEN la.activity_order = 9 AND la.activity_type = 'speaking_practice' THEN '✓'
        WHEN la.activity_order = 10 AND la.activity_type = 'speaking_improvement' THEN '✓'
        ELSE '✗'
    END as status
FROM lesson_activities la
WHERE la.lesson_id = 'A2-L2'
ORDER BY la.activity_order;

-- 4. Check for duplicate activity_order values (should return 0 rows)
SELECT 
    activity_order,
    COUNT(*) as count,
    STRING_AGG(activity_type::text, ', ') as activity_types
FROM lesson_activities
WHERE lesson_id = 'A2-L2'
GROUP BY activity_order
HAVING COUNT(*) > 1;

-- 5. Check warm-up prompt (should be improved version)
SELECT 
    activity_order,
    activity_type,
    content->>'prompt' as warm_up_prompt,
    CASE 
        WHEN content->>'prompt' = 'What do you usually buy when you go shopping?' THEN '✓ Correct (improved)'
        WHEN content->>'prompt' = 'Do you like shopping? What do you buy?' THEN '✗ Old version'
        ELSE '? Unknown'
    END as prompt_status
FROM lesson_activities
WHERE lesson_id = 'A2-L2' AND activity_type = 'warm_up_speaking';

-- 6. Check speaking practice prompts (should be improved versions)
SELECT 
    activity_order,
    activity_type,
    content->'prompts' as speaking_prompts,
    jsonb_array_length(content->'prompts') as prompt_count
FROM lesson_activities
WHERE lesson_id = 'A2-L2' AND activity_type = 'speaking_practice';

-- 7. Check vocabulary items count (should be 5 for intro + 5 for matching = 10 total)
SELECT 
    la.activity_order,
    la.activity_type,
    COUNT(vi.id) as vocabulary_count
FROM lesson_activities la
LEFT JOIN vocabulary_items vi ON vi.activity_id = la.id
WHERE la.lesson_id = 'A2-L2' 
    AND la.activity_type IN ('vocabulary_intro', 'vocabulary_matching_drag')
GROUP BY la.activity_order, la.activity_type
ORDER BY la.activity_order;

-- 8. Check grammar sentences count (should be 2 for each grammar_sentences activity = 4 total)
SELECT 
    la.activity_order,
    la.activity_type,
    COUNT(gs.id) as grammar_sentence_count
FROM lesson_activities la
LEFT JOIN grammar_sentences gs ON gs.activity_id = la.id
WHERE la.lesson_id = 'A2-L2' 
    AND la.activity_type = 'grammar_sentences'
GROUP BY la.activity_order, la.activity_type
ORDER BY la.activity_order;

-- 9. Check for missing speaking_improvement activity
SELECT 
    CASE 
        WHEN EXISTS (
            SELECT 1 FROM lesson_activities 
            WHERE lesson_id = 'A2-L2' 
            AND activity_type = 'speaking_improvement'
            AND activity_order = 10
        ) THEN '✓ Present'
        ELSE '✗ MISSING'
    END as speaking_improvement_status;

-- 10. Full activity list with all details
SELECT 
    la.id,
    la.activity_order,
    la.activity_type,
    la.title,
    la.description,
    la.active,
    la.content
FROM lesson_activities la
WHERE la.lesson_id = 'A2-L2'
ORDER BY la.activity_order;

-- Check ONLY active activities (what users see)
SELECT 
    la.id,
    la.activity_order,
    la.activity_type,
    la.title,
    la.description,
    la.content
FROM lesson_activities la
WHERE la.lesson_id = 'A2-L2' AND la.active = TRUE
ORDER BY la.activity_order;

-- Check ONLY inactive/soft-deleted activities (if any)
SELECT 
    la.id,
    la.activity_order,
    la.activity_type,
    la.title,
    la.description,
    la.content
FROM lesson_activities la
WHERE la.lesson_id = 'A2-L2' AND la.active = FALSE
ORDER BY la.activity_order;

-- Count activities by type
SELECT 
    activity_type,
    COUNT(*) as count
FROM lesson_activities
WHERE lesson_id = 'A2-L2'
GROUP BY activity_type
ORDER BY activity_type;

-- Check for duplicate activity_order values
SELECT 
    activity_order,
    COUNT(*) as count,
    STRING_AGG(activity_type::text, ', ') as activity_types
FROM lesson_activities
WHERE lesson_id = 'A2-L2'
GROUP BY activity_order
HAVING COUNT(*) > 1;

-- Check vocabulary items
SELECT 
    vi.id,
    vi.english_word,
    vi.thai_translation,
    la.activity_type,
    la.activity_order
FROM vocabulary_items vi
JOIN lesson_activities la ON vi.activity_id = la.id
WHERE la.lesson_id = 'A2-L2'
ORDER BY la.activity_order, vi.id;

-- Check grammar sentences
SELECT 
    gs.id,
    gs.original_sentence,
    gs.correct_sentence,
    la.activity_type,
    la.activity_order
FROM grammar_sentences gs
JOIN lesson_activities la ON gs.activity_id = la.id
WHERE la.lesson_id = 'A2-L2'
ORDER BY la.activity_order, gs.id;
