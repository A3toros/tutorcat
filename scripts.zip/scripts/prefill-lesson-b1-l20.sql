-- =========================================
-- Pre-fill Database with Sample Lesson Data
-- B1-L20: Online Communication
-- =========================================

DELETE FROM grammar_sentences WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'B1-L20');
DELETE FROM vocabulary_items WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'B1-L20');
DELETE FROM lesson_activities WHERE lesson_id = 'B1-L20';
DELETE FROM lessons WHERE id = 'B1-L20';

INSERT INTO lessons (id, level, lesson_number, topic) VALUES
('B1-L20', 'B1', 20, 'Online Communication')
ON CONFLICT (id) DO UPDATE SET topic = EXCLUDED.topic;

DO $$
DECLARE
    lesson_id_var TEXT := 'B1-L20';
    activity_id_var UUID;
BEGIN
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'warm_up_speaking', 1, 'Messaging Online', 'Talk about apps and online messages', '{"prompt": "Which app do you use most and why?"}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_intro', 2, 'Communication Words', 'Learn vocabulary about online communication', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'platform', 'แพลตฟอร์ม', NULL),
    (activity_id_var, 'thread', 'กระทู้/เธรด', NULL),
    (activity_id_var, 'notify', 'แจ้งเตือน', NULL),
    (activity_id_var, 'reply', 'ตอบ', NULL),
    (activity_id_var, 'attach', 'แนบ', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_matching_drag', 3, 'Match Communication Words', 'Match words with meanings', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'platform', 'แพลตฟอร์ม', NULL),
    (activity_id_var, 'thread', 'กระทู้/เธรด', NULL),
    (activity_id_var, 'notify', 'แจ้งเตือน', NULL),
    (activity_id_var, 'reply', 'ตอบ', NULL),
    (activity_id_var, 'attach', 'แนบ', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 4, 'Complete the Sentences 1', 'Fill with the correct word', '{"text": "I post on a ___. The app will ___ me. I always ___ to friends.", "blanks": [{"id": "blank1", "text": "thread", "options": ["thread", "platform", "reply", "attach"], "correctAnswer": "thread"}, {"id": "blank2", "text": "notify", "options": ["notify", "reply", "attach", "platform"], "correctAnswer": "notify"}, {"id": "blank3", "text": "reply", "options": ["reply", "notify", "attach", "platform"], "correctAnswer": "reply"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 5, 'Complete the Sentences 2', 'Fill with the correct word', '{"text": "We use one ___ for class. I can ___ files to emails. I read every ___.", "blanks": [{"id": "blank1", "text": "platform", "options": ["platform", "thread", "notify", "attach"], "correctAnswer": "platform"}, {"id": "blank2", "text": "attach", "options": ["attach", "reply", "platform", "thread"], "correctAnswer": "attach"}, {"id": "blank3", "text": "thread", "options": ["thread", "platform", "reply", "attach"], "correctAnswer": "thread"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    -- Grammar Explanation: Relative Clauses (defining)
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_explanation', 6, 'Relative Clauses (who/which/that)', 'Use defining relative clauses to add essential information', '{"rules": "Defining relative clauses add essential information with who/which/that. No commas.\\n- The app that I use most is free.\\n- The friend who replies fastest is Sam.\\n- The thread which we follow is helpful.", "examples": ["The app that I use most is free.", "The friend who replies fastest is Sam.", "This is the thread that helps me study.", "The platform which we chose is stable.", "The file that you attached is too large."]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 7, 'Build Sentences 1', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'The app that I use most is free', 'The app that I use most is free', '["The", "app", "that", "I", "use", "most", "is", "free"]'::jsonb),
    (activity_id_var, 'The friend who replies fastest is Sam', 'The friend who replies fastest is Sam', '["The", "friend", "who", "replies", "fastest", "is", "Sam"]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 8, 'Build Sentences 2', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'This is the thread that helps me study', 'This is the thread that helps me study', '["This", "is", "the", "thread", "that", "helps", "me", "study"]'::jsonb),
    (activity_id_var, 'The platform which we chose is stable', 'The platform which we chose is stable', '["The", "platform", "which", "we", "chose", "is", "stable"]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'speaking_practice', 9, 'Talk About Online Communication', 'Practice talking about messaging and apps', '{"prompts": ["Which app do you use most and why?", "How do you fix misunderstandings online?", "What message from someone really made you feel heard?"]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (
      lesson_id,
      activity_type,
      activity_order,
      title,
      description,
      content
    ) VALUES (
      'B1-L20',
      'speaking_improvement',
      10,
      'Speaking Improvement',
      'Read the improved version of your speech',
      '{"type": "speaking_improvement", "similarityThreshold": 70}'::jsonb
    );
END $$;


