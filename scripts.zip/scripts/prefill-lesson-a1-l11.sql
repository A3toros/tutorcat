-- =========================================
-- Pre-fill Database with Sample Lesson Data
-- A1-L11: Classroom Objects
-- =========================================

DELETE FROM grammar_sentences WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'A1-L11');
DELETE FROM vocabulary_items WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'A1-L11');
DELETE FROM lesson_activities WHERE lesson_id = 'A1-L11';
DELETE FROM lessons WHERE id = 'A1-L11';

INSERT INTO lessons (id, level, lesson_number, topic) VALUES
('A1-L11', 'A1', 11, 'Classroom Objects')
ON CONFLICT (id) DO UPDATE SET topic = EXCLUDED.topic;

DO $$
DECLARE
    lesson_id_var TEXT := 'A1-L11';
    activity_id_var UUID;
BEGIN
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'warm_up_speaking', 1, 'Things in Class', 'Talk about objects', '{"prompt": "What do you have on your desk?"}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_intro', 2, 'Classroom Words', 'Learn classroom objects', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'pen', 'ปากกา', NULL),
    (activity_id_var, 'pencil', 'ดินสอ', NULL),
    (activity_id_var, 'book', 'หนังสือ', NULL),
    (activity_id_var, 'desk', 'โต๊ะ', NULL),
    (activity_id_var, 'chair', 'เก้าอี้', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_matching_drag', 3, 'Match Classroom Words', 'Match words to meaning', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'pen', 'ปากกา', NULL),
    (activity_id_var, 'pencil', 'ดินสอ', NULL),
    (activity_id_var, 'book', 'หนังสือ', NULL),
    (activity_id_var, 'desk', 'โต๊ะ', NULL),
    (activity_id_var, 'chair', 'เก้าอี้', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 4, 'Complete the Sentences 1', 'Fill with the correct word', '{"text": "This is my ___. That is your ___.", "blanks": [{"id": "blank1", "text": "pen", "options": ["pen", "pencil", "book", "desk"], "correctAnswer": "pen"}, {"id": "blank2", "text": "book", "options": ["book", "desk", "chair", "pen"], "correctAnswer": "book"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 5, 'Complete the Sentences 2', 'Fill with the correct word', '{"text": "Put the ___ on the ___.", "blanks": [{"id": "blank1", "text": "pencil", "options": ["pencil", "pen", "chair", "desk"], "correctAnswer": "pencil"}, {"id": "blank2", "text": "desk", "options": ["desk", "chair", "book", "pen"], "correctAnswer": "desk"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_explanation', 6, 'This / That', 'Point to near and far objects', '{"rules": "Use this for near, that for far.\n- This is my pen.\n- That is your book.", "examples": ["This is my pen.", "That is your book.", "This chair is new.", "Is that your desk?", "Is this a pencil?"]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 7, 'Build Sentences 1', 'Arrange words', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'This is my pen', 'This is my pen.', '["This", "is", "my", "pen."]'::jsonb),
    (activity_id_var, 'That is your book', 'That is your book.', '["That", "is", "your", "book."]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 8, 'Build Sentences 2', 'Arrange words', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'Is this your desk', 'Is this your desk?', '["Is", "this", "your", "desk?"]'::jsonb),
    (activity_id_var, 'Is that your chair', 'Is that your chair?', '["Is", "that", "your", "chair?"]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'speaking_practice', 9, 'Talk About Class Items', 'Practice near/far objects', '{"prompts": ["Is this your pen?", "What is that?", "Where is your book?", "Is this desk yours?", "Do you like this chair?"]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (
      lesson_id,
      activity_type,
      activity_order,
      title,
      description,
      content
    ) VALUES (
      'A1-L11',
      'speaking_improvement',
      10,
      'Speaking Improvement',
      'Read the improved version of your speech',
      '{"type": "speaking_improvement", "similarityThreshold": 70}'::jsonb
    );
END $$;

