-- =========================================
-- Pre-fill Database with Sample Lesson Data
-- B1-L93: Money Emergencies
-- =========================================

DELETE FROM grammar_sentences WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'B1-L93');
DELETE FROM vocabulary_items WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'B1-L93');
DELETE FROM lesson_activities WHERE lesson_id = 'B1-L93';
DELETE FROM lessons WHERE id = 'B1-L93';

INSERT INTO lessons (id, level, lesson_number, topic) VALUES
('B1-L93', 'B1', 93, 'Money Emergencies')
ON CONFLICT (id) DO UPDATE SET topic = EXCLUDED.topic;

DO $$
DECLARE
    lesson_id_var TEXT := 'B1-L93';
    activity_id_var UUID;
BEGIN
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'warm_up_speaking', 1, 'Unexpected Costs', 'Talk about handling sudden expenses', '{"prompt": "What is your plan when a big unexpected bill arrives?"}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_intro', 2, 'Emergency Money Words', 'Learn vocabulary about financial emergencies', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'reserve', 'เงินสำรอง', NULL),
    (activity_id_var, 'insurance', 'ประกัน', NULL),
    (activity_id_var, 'deductible', 'ส่วนที่ต้องจ่ายเอง', NULL),
    (activity_id_var, 'overdue', 'เกินกำหนด', NULL),
    (activity_id_var, 'payment plan', 'แผนการชำระเงิน', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_matching_drag', 3, 'Match Money Emergency Words', 'Match words with meanings', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'reserve', 'เงินสำรอง', NULL),
    (activity_id_var, 'insurance', 'ประกัน', NULL),
    (activity_id_var, 'deductible', 'ส่วนที่ต้องจ่ายเอง', NULL),
    (activity_id_var, 'overdue', 'เกินกำหนด', NULL),
    (activity_id_var, 'payment plan', 'แผนการชำระเงิน', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 4, 'Complete the Sentences 1', 'Fill with the correct word', '{"text": "I keep a small ___. My ___ covers accidents. The ___ is 5,000 baht.", "blanks": [{"id": "blank1", "text": "reserve", "options": ["reserve", "insurance", "deductible", "overdue"], "correctAnswer": "reserve"}, {"id": "blank2", "text": "insurance", "options": ["insurance", "payment plan", "overdue", "deductible"], "correctAnswer": "insurance"}, {"id": "blank3", "text": "deductible", "options": ["deductible", "reserve", "payment plan", "overdue"], "correctAnswer": "deductible"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 5, 'Complete the Sentences 2', 'Fill with the correct word', '{"text": "The bill is ___. We set a ___ to finish it. I add cash to my ___.", "blanks": [{"id": "blank1", "text": "overdue", "options": ["overdue", "reserve", "deductible", "insurance"], "correctAnswer": "overdue"}, {"id": "blank2", "text": "payment plan", "options": ["payment plan", "insurance", "reserve", "overdue"], "correctAnswer": "payment plan"}, {"id": "blank3", "text": "reserve", "options": ["reserve", "overdue", "payment plan", "deductible"], "correctAnswer": "reserve"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    -- Grammar Explanation: First Conditional (money decisions)
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_explanation', 6, 'First Conditional for Money Emergencies', 'Use if + present, will + base verb for likely money choices', '{"rules": "If + present simple, will + base verb for likely outcomes.\\n- If a bill is overdue, I will call the provider.\\n- If the deductible is high, we will adjust the plan.\\nNo contractions.", "examples": ["If a bill is overdue, I will call the provider.", "If the deductible is high, we will adjust the plan.", "If my reserve is low, I will pause big purchases.", "If insurance covers it, we will file a claim.", "If the payment plan is fair, I will accept it."]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 7, 'Build Sentences 1', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'If a bill is overdue I will call the provider', 'If a bill is overdue, I will call the provider', '["If", "a", "bill", "is", "overdue,", "I", "will", "call", "the", "provider"]'::jsonb),
    (activity_id_var, 'If the deductible is high we will adjust the plan', 'If the deductible is high, we will adjust the plan', '["If", "the", "deductible", "is", "high,", "we", "will", "adjust", "the", "plan"]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 8, 'Build Sentences 2', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'If my reserve is low I will pause big purchases', 'If my reserve is low, I will pause big purchases', '["If", "my", "reserve", "is", "low,", "I", "will", "pause", "big", "purchases"]'::jsonb),
    (activity_id_var, 'If insurance covers it we will file a claim', 'If insurance covers it, we will file a claim', '["If", "insurance", "covers", "it,", "we", "will", "file", "a", "claim"]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'speaking_practice', 9, 'Talk About Money Emergencies', 'Practice talking about sudden expenses', '{"prompts": ["What is your plan when a big unexpected bill arrives?", "When do you call the provider to negotiate?", "How do you decide to accept a payment plan?"]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (
      lesson_id,
      activity_type,
      activity_order,
      title,
      description,
      content
    ) VALUES (
      'B1-L93',
      'speaking_improvement',
      10,
      'Speaking Improvement',
      'Read the improved version of your speech',
      '{"type": "speaking_improvement", "similarityThreshold": 70}'::jsonb
    );
END $$;

