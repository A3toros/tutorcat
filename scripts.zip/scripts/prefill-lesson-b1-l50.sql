-- =========================================
-- Pre-fill Database with Sample Lesson Data
-- B1-L50: Energy Use at Home
-- =========================================

DELETE FROM grammar_sentences WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'B1-L50');
DELETE FROM vocabulary_items WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'B1-L50');
DELETE FROM lesson_activities WHERE lesson_id = 'B1-L50';
DELETE FROM lessons WHERE id = 'B1-L50';

INSERT INTO lessons (id, level, lesson_number, topic) VALUES
('B1-L50', 'B1', 50, 'Energy Use at Home')
ON CONFLICT (id) DO UPDATE SET topic = EXCLUDED.topic;

DO $$
DECLARE
    lesson_id_var TEXT := 'B1-L50';
    activity_id_var UUID;
BEGIN
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'warm_up_speaking', 1, 'Home Energy', 'Talk about how you use and save energy at home', '{"prompt": "How is energy really used at home?"}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_intro', 2, 'Energy Words', 'Learn vocabulary about energy use at home', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'consume', 'ใช้พลังงาน', NULL),
    (activity_id_var, 'reduce', 'ลด', NULL),
    (activity_id_var, 'insulate', 'ป้องกันความร้อน/ฉนวน', NULL),
    (activity_id_var, 'switch', 'สวิตช์/ปิดเปิด', NULL),
    (activity_id_var, 'monitor', 'ติดตาม/เฝ้าดู', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_matching_drag', 3, 'Match Energy Words', 'Match words with meanings', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'consume', 'ใช้พลังงาน', NULL),
    (activity_id_var, 'reduce', 'ลด', NULL),
    (activity_id_var, 'insulate', 'ป้องกันความร้อน/ฉนวน', NULL),
    (activity_id_var, 'switch', 'สวิตช์/ปิดเปิด', NULL),
    (activity_id_var, 'monitor', 'ติดตาม/เฝ้าดู', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 4, 'Complete the Sentences 1', 'Fill with the correct word', '{"text": "AC units ___ power. We try to ___. Good windows can ___.", "blanks": [{"id": "blank1", "text": "consume", "options": ["consume", "reduce", "insulate", "monitor"], "correctAnswer": "consume"}, {"id": "blank2", "text": "reduce", "options": ["reduce", "consume", "monitor", "switch"], "correctAnswer": "reduce"}, {"id": "blank3", "text": "insulate", "options": ["insulate", "reduce", "consume", "switch"], "correctAnswer": "insulate"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 5, 'Complete the Sentences 2', 'Fill with the correct word', '{"text": "We ___ off lights. I ___ usage weekly. This helps ___ costs.", "blanks": [{"id": "blank1", "text": "switch", "options": ["switch", "monitor", "reduce", "consume"], "correctAnswer": "switch"}, {"id": "blank2", "text": "monitor", "options": ["monitor", "switch", "consume", "insulate"], "correctAnswer": "monitor"}, {"id": "blank3", "text": "reduce", "options": ["reduce", "monitor", "switch", "consume"], "correctAnswer": "reduce"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    -- Grammar Explanation: Passive Voice (Present) — energy use
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_explanation', 6, 'Passive Voice (Present) for Energy Use', 'Use am/is/are + past participle to describe processes/results', '{"rules": "Passive present: am/is/are + past participle. Use to focus on action or result.\\n- Energy is consumed at night.\\n- Lights are switched off at ten.\\nAvoid contractions; keep commas on preceding words.", "examples": ["Energy is consumed most in the evening.", "Lights are switched off at ten.", "Walls are insulated for summer heat.", "Usage is monitored every week.", "Costs are reduced by small changes."]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 7, 'Build Sentences 1', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'Energy is consumed most in the evening', 'Energy is consumed most in the evening', '["Energy", "is", "consumed", "most", "in", "the", "evening"]'::jsonb),
    (activity_id_var, 'Lights are switched off at ten', 'Lights are switched off at ten', '["Lights", "are", "switched", "off", "at", "ten"]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 8, 'Build Sentences 2', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'Walls are insulated for summer heat', 'Walls are insulated for summer heat', '["Walls", "are", "insulated", "for", "summer", "heat"]'::jsonb),
    (activity_id_var, 'Costs are reduced by small changes', 'Costs are reduced by small changes', '["Costs", "are", "reduced", "by", "small", "changes"]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'speaking_practice', 9, 'Talk About Home Energy', 'Practice talking about energy use and savings', '{"prompts": ["How is energy really used at home?", "What are you improving now?", "What change saved the most for you?"]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (
      lesson_id,
      activity_type,
      activity_order,
      title,
      description,
      content
    ) VALUES (
      'B1-L50',
      'speaking_improvement',
      10,
      'Speaking Improvement',
      'Read the improved version of your speech',
      '{"type": "speaking_improvement", "similarityThreshold": 70}'::jsonb
    );
END $$;

