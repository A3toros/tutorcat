-- =========================================
-- Pre-fill Database with Sample Lesson Data
-- B2-L73: Handling responsibility
-- =========================================

DELETE FROM grammar_sentences WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'B2-L73');
DELETE FROM vocabulary_items WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'B2-L73');
DELETE FROM lesson_activities WHERE lesson_id = 'B2-L73';
DELETE FROM lessons WHERE id = 'B2-L73';

INSERT INTO lessons (id, level, lesson_number, topic) VALUES
('B2-L73', 'B2', 73, 'Handling responsibility')
ON CONFLICT (id) DO UPDATE SET topic = EXCLUDED.topic;

DO $$
DECLARE
    lesson_id_var TEXT := 'B2-L73';
    activity_id_var UUID;
BEGIN
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'warm_up_speaking', 1, 'Duties & Standards', 'Talk about ongoing duties', '{"prompt": "How have you carried duties lately, and what keeps you consistent?"}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_intro', 2, 'Responsibility Words', 'Key words for duties and oversight', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'entrusted', 'มอบหมาย/ไว้ใจให้รับผิดชอบ', NULL),
    (activity_id_var, 'obligation', 'ภาระหน้าที่', NULL),
    (activity_id_var, 'deadline', 'กำหนดส่ง', NULL),
    (activity_id_var, 'oversight', 'การกำกับดูแล/ข้อผิดพลาดที่มองข้าม', NULL),
    (activity_id_var, 'standard', 'มาตรฐาน', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_matching_drag', 3, 'Match Responsibility Words', 'Match words with meanings', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'entrusted', 'มอบหมาย/ไว้ใจให้รับผิดชอบ', NULL),
    (activity_id_var, 'obligation', 'ภาระหน้าที่', NULL),
    (activity_id_var, 'deadline', 'กำหนดส่ง', NULL),
    (activity_id_var, 'oversight', 'การกำกับดูแล/ข้อผิดพลาดที่มองข้าม', NULL),
    (activity_id_var, 'standard', 'มาตรฐาน', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 4, 'Complete the Sentences 1', 'Fill with the correct word', '{"text": "We were ___ with tasks. Each ___ has a ___.", "blanks": [{"id": "blank1", "text": "entrusted", "options": ["entrusted", "deadline", "standard", "obligation"], "correctAnswer": "entrusted"}, {"id": "blank2", "text": "task", "options": ["deadline", "standard", "task", "obligation"], "correctAnswer": "deadline"}, {"id": "blank3", "text": "standard", "options": ["standard", "oversight", "deadline", "obligation"], "correctAnswer": "standard"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 5, 'Complete the Sentences 2', 'Fill with the correct word', '{"text": "Missing an ___ is serious. ___ prevents mistakes.", "blanks": [{"id": "blank1", "text": "obligation", "options": ["obligation", "oversight", "entrusted", "standard"], "correctAnswer": "obligation"}, {"id": "blank2", "text": "Oversight", "options": ["Oversight", "Standard", "Deadline", "Entrusted"], "correctAnswer": "Oversight"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_explanation', 6, 'Present Perfect Continuous', 'Show ongoing responsibility habits', '{"rules": "Use have/has + been + -ing for actions started in the past and continuing now, often with for/since.\\n- I have been carrying these duties all term.\\n- We have been keeping the standard for weeks.", "examples": ["I have been tracking deadlines weekly.", "She has been preventing oversight with checklists.", "They have been meeting standards since onboarding.", "We have been reminding each other of obligations.", "He has been reviewing tasks before sign-off."]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 7, 'Build Sentences 1', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'I have been tracking deadlines weekly', 'I have been tracking deadlines weekly.', '["I", "have", "been", "tracking", "deadlines", "weekly."]'::jsonb),
    (activity_id_var, 'She has been preventing oversight with checklists', 'She has been preventing oversight with checklists.', '["She", "has", "been", "preventing", "oversight", "with", "checklists."]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 8, 'Build Sentences 2', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'They have been meeting standards since onboarding', 'They have been meeting standards since onboarding.', '["They", "have", "been", "meeting", "standards", "since", "onboarding."]'::jsonb),
    (activity_id_var, 'We have been reminding each other of obligations', 'We have been reminding each other of obligations.', '["We", "have", "been", "reminding", "each", "other", "of", "obligations."]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'speaking_practice', 9, 'Talk About Responsibility', 'Practice present perfect continuous', '{"prompts": ["How have you carried duties lately?", "What keeps you consistent with standards?", "How do you prevent oversight in your team?"]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (
      lesson_id,
      activity_type,
      activity_order,
      title,
      description,
      content
    ) VALUES (
      'B2-L73',
      'speaking_improvement',
      10,
      'Speaking Improvement',
      'Read the improved version of your speech',
      '{"type": "speaking_improvement", "similarityThreshold": 70}'::jsonb
    );
END $$;


