-- =========================================
-- Pre-fill Database with Sample Lesson Data
-- A2-L62: Discounts & Sales
-- =========================================

DELETE FROM grammar_sentences WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'A2-L62');
DELETE FROM vocabulary_items WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'A2-L62');
DELETE FROM lesson_activities WHERE lesson_id = 'A2-L62';
DELETE FROM lessons WHERE id = 'A2-L62';

INSERT INTO lessons (id, level, lesson_number, topic) VALUES
('A2-L62', 'A2', 62, 'Discounts & Sales')
ON CONFLICT (id) DO UPDATE SET topic = EXCLUDED.topic;

DO $$
DECLARE
    lesson_id_var TEXT := 'A2-L62';
    activity_id_var UUID;
BEGIN
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'warm_up_speaking', 1, 'Sales', 'Talk about discounts', '{"prompt": "Do you buy many things during sales?"}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_intro', 2, 'Sale Words', 'Learn discount vocabulary', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'sale', 'ลดราคา', NULL),
    (activity_id_var, 'discount', 'ส่วนลด', NULL),
    (activity_id_var, 'percent', 'เปอร์เซ็นต์', NULL),
    (activity_id_var, 'offer', 'ข้อเสนอ', NULL),
    (activity_id_var, 'price tag', 'ป้ายราคา', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_matching_drag', 3, 'Match Sale Words', 'Match sale words', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'sale', 'ลดราคา', NULL),
    (activity_id_var, 'discount', 'ส่วนลด', NULL),
    (activity_id_var, 'percent', 'เปอร์เซ็นต์', NULL),
    (activity_id_var, 'offer', 'ข้อเสนอ', NULL),
    (activity_id_var, 'price tag', 'ป้ายราคา', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 4, 'Complete the Sentences 1', 'Fill with the correct word', '{"text": "There is a ___ today. The ___ is 30 ___. The ___ shows it.", "blanks": [{"id": "blank1", "text": "sale", "options": ["sale", "discount", "percent", "price tag"], "correctAnswer": "sale"}, {"id": "blank2", "text": "discount", "options": ["discount", "percent", "sale", "offer"], "correctAnswer": "discount"}, {"id": "blank3", "text": "percent", "options": ["percent", "price tag", "discount", "sale"], "correctAnswer": "percent"}, {"id": "blank4", "text": "price tag", "options": ["price tag", "discount", "percent", "offer"], "correctAnswer": "price tag"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 5, 'Complete the Sentences 2', 'Fill with the correct word', '{"text": "This ___ is for members. Is the ___ real?", "blanks": [{"id": "blank1", "text": "offer", "options": ["offer", "sale", "discount", "percent"], "correctAnswer": "offer"}, {"id": "blank2", "text": "discount", "options": ["discount", "offer", "sale", "percent"], "correctAnswer": "discount"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_explanation', 6, 'Some / Any / Much / Many', 'Talk about amounts in sales', '{"rules": "Use many with countable, much with uncountable, some/any for general.\n- How many items are on sale?\n- Do you have any discount codes?\n- I don''t spend much money.", "examples": ["How many items are on sale?", "Do you have any discount codes?", "I don''t spend much money.", "We have some offers today.", "There aren''t many price tags left."]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 7, 'Build Sentences 1', 'Arrange words', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'How many items are on sale', 'How many items are on sale?', '["How", "many", "items", "are", "on", "sale?"]'::jsonb),
    (activity_id_var, 'Do you have any discount codes', 'Do you have any discount codes?', '["Do", "you", "have", "any", "discount", "codes?"]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 8, 'Build Sentences 2', 'Arrange words', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'I don t spend much money', 'I don''t spend much money.', '["I", "don''t", "spend", "much", "money."]'::jsonb),
    (activity_id_var, 'We have some offers today', 'We have some offers today.', '["We", "have", "some", "offers", "today."]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'speaking_practice', 9, 'Talk About Sales', 'Practice talking about discounts', '{"prompts": ["Do you buy many things during sales?", "How much money do you usually spend?", "Do you buy any clothes online?", "Are there many discounts at your favorite store?", "How much can you save during sales?"]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (
      lesson_id,
      activity_type,
      activity_order,
      title,
      description,
      content
    ) VALUES (
      'A2-L62',
      'speaking_improvement',
      10,
      'Speaking Improvement',
      'Read the improved version of your speech',
      '{"type": "speaking_improvement", "similarityThreshold": 70}'::jsonb
    );
END $$;

