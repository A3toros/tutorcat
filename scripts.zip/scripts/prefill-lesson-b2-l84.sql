-- ===== LESSON B2-L84 =====

-- =========================================
-- Pre-fill Database with Sample Lesson Data
-- B2-L84: Public transport experiences (compare)
-- =========================================

DELETE FROM lesson_activity_results WHERE lesson_id = 'B2-L84';
DELETE FROM user_progress WHERE lesson_id = 'B2-L84';
DELETE FROM lesson_history WHERE lesson_id = 'B2-L84';
DELETE FROM grammar_sentences WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'B2-L84');
DELETE FROM vocabulary_items WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'B2-L84');
DELETE FROM lesson_activities WHERE lesson_id = 'B2-L84';
DELETE FROM lessons WHERE id = 'B2-L84';

INSERT INTO lessons (id, level, lesson_number, topic) VALUES
('B2-L84', 'B2', 84, 'Public transport experiences (compare)')
ON CONFLICT (id) DO UPDATE SET topic = EXCLUDED.topic;

DO $$
DECLARE
    lesson_id_var TEXT := 'B2-L84';
    activity_id_var UUID;
BEGIN
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'warm_up_speaking', 1, 'Transit Tales', 'Talk about public transportation experiences', '{"prompt": "Although delays happen, what keeps you calm?"}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_intro', 2, 'Transport Experience Words', 'Learn words related to transit experiences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'delay', 'ล่าช้า', NULL),
    (activity_id_var, 'route', 'เส้นทาง', NULL),
    (activity_id_var, 'announcement', 'ประกาศ', NULL),
    (activity_id_var, 'crowd', 'ฝูงชน', NULL),
    (activity_id_var, 'validate', 'ตรวจสอบ', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_matching_drag', 3, 'Match Transport Words', 'Match words related to public transport', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'delay', 'ล่าช้า', NULL),
    (activity_id_var, 'route', 'เส้นทาง', NULL),
    (activity_id_var, 'announcement', 'ประกาศ', NULL),
    (activity_id_var, 'crowd', 'ฝูงชน', NULL),
    (activity_id_var, 'validate', 'ตรวจสอบ', NULL);

    -- 4. Vocabulary Fill Blanks #1
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 4, 'Complete the Sentences 1', 'Fill in the blanks with correct words', '{"text": "There was a ___. I took a different ___. I heard the ___.", "blanks": [{"id": "blank1", "text": "delay", "options": ["delay", "route", "announcement", "crowd"], "correctAnswer": "delay"}, {"id": "blank2", "text": "route", "options": ["route", "delay", "announcement", "validate"], "correctAnswer": "route"}, {"id": "blank3", "text": "announcement", "options": ["announcement", "delay", "route", "crowd"], "correctAnswer": "announcement"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    -- 5. Vocabulary Fill Blanks #2
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 5, 'Complete the Sentences 2', 'Fill in the blanks with correct words', '{"text": "There was a big ___. I need to ___ my ticket. We should ___.", "blanks": [{"id": "blank1", "text": "crowd", "options": ["crowd", "delay", "route", "announcement"], "correctAnswer": "crowd"}, {"id": "blank2", "text": "validate", "options": ["validate", "delay", "route", "crowd"], "correctAnswer": "validate"}, {"id": "blank3", "text": "validate", "options": ["validate", "crowd", "delay", "route"], "correctAnswer": "validate"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    -- 6. Grammar Explanation
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_explanation', 6, 'Contrast with Although/However', 'Learn although/however for contrast', '{"rules": "Use although and however to show contrast:\n\n- Although = at the start of a clause (Although the train was delayed, I arrived)\n- However = between sentences or clauses (The bus was crowded; however, the ride was smooth)\n- But = in the middle of a sentence (It was delayed, but I arrived)\n- All show contrast between two ideas\n- Although and but are similar, but different positions", "examples": ["Although the train was delayed, I arrived on time.", "The bus was crowded; however, the ride was smooth.", "Although announcements were clear, many missed their stop.", "It was late; however, I didn''t mind.", "Although it was busy, the service was good."]}'::jsonb)
    RETURNING id INTO activity_id_var;

    -- 7. Grammar Sentences #1
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 7, 'Build Sentences 1', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'Although the train was delayed I arrived on time', 'Although the train was delayed, I arrived on time.', '["Although", "the", "train", "was", "delayed,", "I", "arrived", "on", "time."]'::jsonb),
    (activity_id_var, 'The bus was crowded however the ride was smooth', 'The bus was crowded; however, the ride was smooth.', '["The", "bus", "was", "crowded;", "however,", "the", "ride", "was", "smooth."]'::jsonb);

    -- 8. Grammar Sentences #2
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 8, 'Build Sentences 2', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'Although announcements were clear many missed their stop', 'Although announcements were clear, many missed their stop.', '["Although", "announcements", "were", "clear,", "many", "missed", "their", "stop."]'::jsonb),
    (activity_id_var, 'It was late however I did not mind', 'It was late; however, I didn''t mind.', '["It", "was", "late;", "however,", "I", "didn''t", "mind."]'::jsonb);

    -- 9. Speaking Practice
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'speaking_practice', 9, 'Talk About Transportation', 'Practice talking about getting around', '{"prompts": ["How do you get to school?", "Do you take the bus to town?", "Who do you sit with on the bus?", "Have you ever experienced a delay?", "How do you handle crowded transport?"]}'::jsonb)
    RETURNING id INTO activity_id_var;

    -- 10. Speaking Improvement
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'speaking_improvement', 10, 'Speaking Improvement', 'Read the improved version of your speech', '{"type": "speaking_improvement", "similarityThreshold": 70}'::jsonb)
    RETURNING id INTO activity_id_var;
END $$;