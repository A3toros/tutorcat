-- =========================================
-- Pre-fill Database with Sample Lesson Data
-- A2-L39: Outdoor Activities
-- =========================================

DELETE FROM grammar_sentences WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'A2-L39');
DELETE FROM vocabulary_items WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'A2-L39');
DELETE FROM lesson_activities WHERE lesson_id = 'A2-L39';
DELETE FROM lessons WHERE id = 'A2-L39';

INSERT INTO lessons (id, level, lesson_number, topic) VALUES
('A2-L39', 'A2', 39, 'Outdoor Activities')
ON CONFLICT (id) DO UPDATE SET topic = EXCLUDED.topic;

DO $$
DECLARE
    lesson_id_var TEXT := 'A2-L39';
    activity_id_var UUID;
BEGIN
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'warm_up_speaking', 1, 'Outdoor Fun', 'Talk about outdoor activities', '{"prompt": "Where do you usually go for outdoor activities?"}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_intro', 2, 'Outdoor Words', 'Learn outdoor activity words', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'hike', 'เดินป่า/เดินเขา', NULL),
    (activity_id_var, 'climb', 'ปีน', NULL),
    (activity_id_var, 'run', 'วิ่ง', NULL),
    (activity_id_var, 'path', 'ทางเดิน', NULL),
    (activity_id_var, 'hill', 'เนินเขา', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_matching_drag', 3, 'Match Outdoor Words', 'Match outdoor words', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'hike', 'เดินป่า/เดินเขา', NULL),
    (activity_id_var, 'climb', 'ปีน', NULL),
    (activity_id_var, 'run', 'วิ่ง', NULL),
    (activity_id_var, 'path', 'ทางเดิน', NULL),
    (activity_id_var, 'hill', 'เนินเขา', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 4, 'Complete the Sentences 1', 'Fill with the correct word', '{"text": "I like to ___ on a mountain ___. I ___ in the park. I ___ a small hill.", "blanks": [{"id": "blank1", "text": "hike", "options": ["hike", "path", "run", "climb"], "correctAnswer": "hike"}, {"id": "blank2", "text": "path", "options": ["path", "hike", "hill", "climb"], "correctAnswer": "path"}, {"id": "blank3", "text": "run", "options": ["run", "climb", "hike", "hill"], "correctAnswer": "run"}, {"id": "blank4", "text": "climb", "options": ["climb", "run", "path", "hill"], "correctAnswer": "climb"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 5, 'Complete the Sentences 2', 'Fill with the correct word', '{"text": "The ___ is steep. The ___ is easy. I ___ early in the morning.", "blanks": [{"id": "blank1", "text": "hill", "options": ["hill", "path", "run", "climb"], "correctAnswer": "hill"}, {"id": "blank2", "text": "path", "options": ["path", "hill", "climb", "run"], "correctAnswer": "path"}, {"id": "blank3", "text": "run", "options": ["run", "climb", "hike", "hill"], "correctAnswer": "run"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_explanation', 6, 'Prepositions of Movement', 'Talk about where you move', '{"rules": "Use along, up, down, across for movement.\n- I walk along the path.\n- We climb up the hill.\n- He runs down the road.\n- They walk across the park.", "examples": ["I walk along the path.", "We climb up the hill.", "He runs down the hill.", "They walk across the park.", "Do you run along the river?"]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 7, 'Build Sentences 1', 'Arrange words', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'I walk along the path', 'I walk along the path.', '["I", "walk", "along", "the", "path."]'::jsonb),
    (activity_id_var, 'We climb up the hill', 'We climb up the hill.', '["We", "climb", "up", "the", "hill."]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 8, 'Build Sentences 2', 'Arrange words', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'He runs down the hill', 'He runs down the hill.', '["He", "runs", "down", "the", "hill."]'::jsonb),
    (activity_id_var, 'They walk across the park', 'They walk across the park.', '["They", "walk", "across", "the", "park."]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'speaking_practice', 9, 'Talk About Outdoor Fun', 'Practice outdoor activities', '{"prompts": ["Where do you usually go for outdoor activities?", "Do you walk through parks or along paths?", "Do you like walking up hills or on flat ground?", "What outdoor activities do you enjoy?", "When do you usually go outside?"]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (
      lesson_id,
      activity_type,
      activity_order,
      title,
      description,
      content
    ) VALUES (
      'A2-L39',
      'speaking_improvement',
      10,
      'Speaking Improvement',
      'Read the improved version of your speech',
      '{"type": "speaking_improvement", "similarityThreshold": 70}'::jsonb
    );
END $$;

