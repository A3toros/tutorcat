-- =========================================
-- Pre-fill Database with Sample Lesson Data
-- B2-L100: Media influence on youth
-- =========================================

DELETE FROM grammar_sentences WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'B2-L100');
DELETE FROM vocabulary_items WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'B2-L100');
DELETE FROM lesson_activities WHERE lesson_id = 'B2-L100';
DELETE FROM lessons WHERE id = 'B2-L100';

INSERT INTO lessons (id, level, lesson_number, topic) VALUES
('B2-L100', 'B2', 100, 'Media influence on youth')
ON CONFLICT (id) DO UPDATE SET topic = EXCLUDED.topic;

DO $$
DECLARE
    lesson_id_var TEXT := 'B2-L100';
    activity_id_var UUID;
BEGIN
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'warm_up_speaking', 1, 'Fast Trends', 'Talk about reacting to trends', '{"prompt": "Hardly had a trend started when what happened, and how do you counter it?"}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_intro', 2, 'Youth Trend Words', 'Key words for trends and safeguards', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'trend', 'กระแส/แนวโน้ม', NULL),
    (activity_id_var, 'safeguard', 'ป้องกัน/คุ้มครอง', NULL),
    (activity_id_var, 'exposure', 'การสัมผัส/รับข้อมูล', NULL),
    (activity_id_var, 'counter', 'ต่อต้าน/รับมือ', NULL),
    (activity_id_var, 'impressionable', 'หวั่นไหว/ง่ายต่อการได้รับอิทธิพล', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_matching_drag', 3, 'Match Youth Trend Words', 'Match words with meanings', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'trend', 'กระแส/แนวโน้ม', NULL),
    (activity_id_var, 'safeguard', 'ป้องกัน/คุ้มครอง', NULL),
    (activity_id_var, 'exposure', 'การสัมผัส/รับข้อมูล', NULL),
    (activity_id_var, 'counter', 'ต่อต้าน/รับมือ', NULL),
    (activity_id_var, 'impressionable', 'หวั่นไหว/ง่ายต่อการได้รับอิทธิพล', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 4, 'Complete the Sentences 1', 'Fill with the correct word', '{"text": "That ___ spread fast. We set a ___ to limit ___.", "blanks": [{"id": "blank1", "text": "trend", "options": ["trend", "safeguard", "exposure", "counter"], "correctAnswer": "trend"}, {"id": "blank2", "text": "safeguard", "options": ["safeguard", "counter", "exposure", "impressionable"], "correctAnswer": "safeguard"}, {"id": "blank3", "text": "exposure", "options": ["exposure", "trend", "counter", "safeguard"], "correctAnswer": "exposure"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 5, 'Complete the Sentences 2', 'Fill with the correct word', '{"text": "We ___ it to protect the ___.", "blanks": [{"id": "blank1", "text": "countered", "options": ["countered", "safeguarded", "exposed", "trended"], "correctAnswer": "countered"}, {"id": "blank2", "text": "impressionable", "options": ["impressionable", "trend", "safeguard", "exposure"], "correctAnswer": "impressionable"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_explanation', 6, 'Inversion (Hardly/Scarcely)', 'Emphasize how fast trends appear', '{"rules": "Use Hardly/Scarcely + had + subject + past participle + when + clause to show an action happened right after another.\\n- Hardly had the trend started when it went viral.", "examples": ["Hardly had the trend started when it went viral.", "Scarcely had we shared the rule when it was copied.", "Hardly had they seen it when they tried it.", "Scarcely had we set safeguards when a new trend appeared.", "Hardly had the post gone up when students reacted."]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 7, 'Build Sentences 1', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'Hardly had the trend started when it went viral', 'Hardly had the trend started when it went viral.', '["Hardly", "had", "the", "trend", "started", "when", "it", "went", "viral."]'::jsonb),
    (activity_id_var, 'Scarcely had we shared the rule when it was copied', 'Scarcely had we shared the rule when it was copied.', '["Scarcely", "had", "we", "shared", "the", "rule", "when", "it", "was", "copied."]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 8, 'Build Sentences 2', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'Hardly had they seen it when they tried it', 'Hardly had they seen it when they tried it.', '["Hardly", "had", "they", "seen", "it", "when", "they", "tried", "it."]'::jsonb),
    (activity_id_var, 'Scarcely had we set safeguards when a new trend appeared', 'Scarcely had we set safeguards when a new trend appeared.', '["Scarcely", "had", "we", "set", "safeguards", "when", "a", "new", "trend", "appeared."]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'speaking_practice', 9, 'Talk About Fast Trends', 'Practice inversion emphasis', '{"prompts": ["Hardly had a trend started when what happened?", "How do you counter fast trends?", "What safeguard protects impressionable students?"]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (
      lesson_id,
      activity_type,
      activity_order,
      title,
      description,
      content
    ) VALUES (
      'B2-L100',
      'speaking_improvement',
      10,
      'Speaking Improvement',
      'Read the improved version of your speech',
      '{"type": "speaking_improvement", "similarityThreshold": 70}'::jsonb
    );
END $$;


