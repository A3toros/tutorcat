-- =========================================
-- Pre-fill Database with Sample Lesson Data
-- B2-L72: Freedom of expression (campus)
-- =========================================

DELETE FROM grammar_sentences WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'B2-L72');
DELETE FROM vocabulary_items WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'B2-L72');
DELETE FROM lesson_activities WHERE lesson_id = 'B2-L72';
DELETE FROM lessons WHERE id = 'B2-L72';

INSERT INTO lessons (id, level, lesson_number, topic) VALUES
('B2-L72', 'B2', 72, 'Freedom of expression (campus)')
ON CONFLICT (id) DO UPDATE SET topic = EXCLUDED.topic;

DO $$
DECLARE
    lesson_id_var TEXT := 'B2-L72';
    activity_id_var UUID;
BEGIN
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'warm_up_speaking', 1, 'Campus Speech', 'Talk about fairness/unfairness', '{"prompt": "Share a case that, which you recall, felt fair or unfair, and who set the boundary?"}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_intro', 2, 'Campus Expression Words', 'Key words for speech on campus', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'express', 'แสดงออก', NULL),
    (activity_id_var, 'censor', 'เซ็นเซอร์/ปิดกั้น', NULL),
    (activity_id_var, 'nuance', 'ความละเอียดอ่อน', NULL),
    (activity_id_var, 'offend', 'ทำให้ไม่พอใจ', NULL),
    (activity_id_var, 'debate', 'อภิปราย/ถกเถียง', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_matching_drag', 3, 'Match Campus Expression Words', 'Match words with meanings', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'express', 'แสดงออก', NULL),
    (activity_id_var, 'censor', 'เซ็นเซอร์/ปิดกั้น', NULL),
    (activity_id_var, 'nuance', 'ความละเอียดอ่อน', NULL),
    (activity_id_var, 'offend', 'ทำให้ไม่พอใจ', NULL),
    (activity_id_var, 'debate', 'อภิปราย/ถกเถียง', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 4, 'Complete the Sentences 1', 'Fill with the correct word', '{"text": "We ___ ideas. Some posts were ___. We asked for ___.", "blanks": [{"id": "blank1", "text": "express", "options": ["express", "censored", "nuance", "debate"], "correctAnswer": "express"}, {"id": "blank2", "text": "censored", "options": ["censored", "debated", "expressed", "nuance"], "correctAnswer": "censored"}, {"id": "blank3", "text": "nuance", "options": ["nuance", "offend", "debate", "censor"], "correctAnswer": "nuance"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 5, 'Complete the Sentences 2', 'Fill with the correct word', '{"text": "We ___ tough topics. We avoid posts that ___.", "blanks": [{"id": "blank1", "text": "debate", "options": ["debate", "express", "censor", "nuance"], "correctAnswer": "debate"}, {"id": "blank2", "text": "offend", "options": ["offend", "nuance", "debate", "censor"], "correctAnswer": "offend"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_explanation', 6, 'Relative Clauses (non-defining)', 'Add context about cases fairly/unfairly handled', '{"rules": "Use commas with who/which/where to add extra, non-essential info. Keep clause removable.\\n- The case, which students recalled, felt unfair.\\n- The boundary, which the dean set, was debated.", "examples": ["The rule, which was posted online, sparked debate.", "That speech, which offended some students, was reviewed.", "The panel, which valued nuance, avoided censoring.", "The guideline, which the dean wrote, was revised.", "The case, which you recall, felt fair to some."]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 7, 'Build Sentences 1', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'The rule, which was posted online, sparked debate', 'The rule, which was posted online, sparked debate.', '["The", "rule,", "which", "was", "posted", "online,", "sparked", "debate."]'::jsonb),
    (activity_id_var, 'The panel, which valued nuance, avoided censoring', 'The panel, which valued nuance, avoided censoring.', '["The", "panel,", "which", "valued", "nuance,", "avoided", "censoring."]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 8, 'Build Sentences 2', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'The boundary, which the dean set, was debated', 'The boundary, which the dean set, was debated.', '["The", "boundary,", "which", "the", "dean", "set,", "was", "debated."]'::jsonb),
    (activity_id_var, 'The case, which you recall, felt fair to some', 'The case, which you recall, felt fair to some.', '["The", "case,", "which", "you", "recall,", "felt", "fair", "to", "some."]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'speaking_practice', 9, 'Talk About Campus Speech', 'Practice non-defining relatives', '{"prompts": ["Share a case that felt fair or unfair to you.", "Who set the boundary, which students debated?", "How do you keep nuance when topics offend some?"]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (
      lesson_id,
      activity_type,
      activity_order,
      title,
      description,
      content
    ) VALUES (
      'B2-L72',
      'speaking_improvement',
      10,
      'Speaking Improvement',
      'Read the improved version of your speech',
      '{"type": "speaking_improvement", "similarityThreshold": 70}'::jsonb
    );
END $$;


