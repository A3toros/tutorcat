-- =========================================
-- Pre-fill Database with Sample Lesson Data
-- C1-L46: Human Connection in a Digital Age
-- =========================================
DELETE FROM lesson_activity_results WHERE lesson_id = 'C1-L46';
DELETE FROM user_progress WHERE lesson_id = 'C1-L46';
DELETE FROM lesson_history WHERE lesson_id = 'C1-L46';
DELETE FROM grammar_sentences WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'C1-L46');
DELETE FROM vocabulary_items WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'C1-L46');
DELETE FROM lesson_activities WHERE lesson_id = 'C1-L46';
DELETE FROM lessons WHERE id = 'C1-L46';

INSERT INTO lessons (id, level, lesson_number, topic) VALUES
('C1-L46', 'C1', 46, 'Human Connection in a Digital Age')
ON CONFLICT (id) DO UPDATE SET topic = EXCLUDED.topic;

DO $$
DECLARE
    lesson_id_var TEXT := 'C1-L46';
    activity_id_var UUID;
BEGIN
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'warm_up_speaking', 1, 'Human Connection', 'Discuss human connection in digital age', '{"prompt": "How do digital tools affect relationships?"}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_intro', 2, 'Connection Vocabulary', 'Learn vocabulary about human connection', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'connection', 'การเชื่อมต่อ', NULL),
    (activity_id_var, 'interaction', 'การโต้ตอบ', NULL),
    (activity_id_var, 'authenticity', 'ความจริงใจ', NULL),
    (activity_id_var, 'balance', 'ความสมดุล', NULL),
    (activity_id_var, 'challenge', 'ความท้าทาย', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_matching_drag', 3, 'Match Connection Words', 'Match English words with Thai meanings', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'connection', 'การเชื่อมต่อ', NULL),
    (activity_id_var, 'interaction', 'การโต้ตอบ', NULL),
    (activity_id_var, 'authenticity', 'ความจริงใจ', NULL),
    (activity_id_var, 'balance', 'ความสมดุล', NULL),
    (activity_id_var, 'challenge', 'ความท้าทาย', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 4, 'Complete the Sentences 1', 'Fill with the correct word', '{"text": "Meaningful ___ requires ___. Digital ___ can feel ___.", "blanks": [{"id": "blank1", "text": "connections", "options": ["connections", "interaction", "authenticity", "balance"], "correctAnswer": "connections"}, {"id": "blank2", "text": "authenticity", "options": ["authenticity", "connection", "interaction", "balance"], "correctAnswer": "authenticity"}, {"id": "blank3", "text": "interactions", "options": ["interactions", "connection", "authenticity", "balance"], "correctAnswer": "interactions"}, {"id": "blank4", "text": "shallow", "options": ["shallow", "connection", "authenticity", "balance"], "correctAnswer": "shallow"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 5, 'Complete the Sentences 2', 'Fill with the correct word', '{"text": "Maintaining ___ between online and offline ___ is a ___.", "blanks": [{"id": "blank1", "text": "balance", "options": ["balance", "connection", "interaction", "authenticity"], "correctAnswer": "balance"}, {"id": "blank2", "text": "connection", "options": ["connection", "interaction", "authenticity", "challenge"], "correctAnswer": "connection"}, {"id": "blank3", "text": "challenge", "options": ["challenge", "connection", "interaction", "authenticity"], "correctAnswer": "challenge"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_explanation', 6, 'Participle Clauses', 'Learn participle clauses', '{"rules": "Participle clauses:\n- Present participle (-ing): \"Maintaining connections, people stay engaged.\"\n- Past participle (-ed): \"Affected by technology, relationships change.\"\n- Perfect participle (having + past participle): \"Having connected online, people build relationships.\"\n\nUse for:\n- Showing simultaneous actions: \"Maintaining connections, you build relationships.\"\n- Showing cause: \"Affected by digital tools, interactions evolve.\"\n- Showing time sequence: \"Having connected online, people maintain relationships.\"", "examples": ["Maintaining meaningful connections, people stay engaged online.", "Affected by digital tools, relationships evolve.", "Having connected online, people build authentic relationships.", "Balancing online and offline, people maintain connections.", "Shaped by technology, human interaction changes."]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 7, 'Build Sentences 1', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'Maintaining meaningful connections, people stay engaged online.', 'Maintaining meaningful connections, people stay engaged online.', '["Maintaining", "meaningful", "connections,", "people", "stay", "engaged", "online."]'::jsonb),
    (activity_id_var, 'Affected by digital tools, relationships evolve.', 'Affected by digital tools, relationships evolve.', '["Affected", "by", "digital", "tools,", "relationships", "evolve."]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 8, 'Build Sentences 2', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'Having connected online, people build authentic relationships.', 'Having connected online, people build authentic relationships.', '["Having", "connected", "online,", "people", "build", "authentic", "relationships."]'::jsonb),
    (activity_id_var, 'Balancing online and offline, people maintain connections.', 'Balancing online and offline, people maintain connections.', '["Balancing", "online", "and", "offline,", "people", "maintain", "connections."]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'speaking_practice', 9, 'Discuss Human Connection', 'Practice speaking about human connection', '{"prompts": ["How do you maintain meaningful connections online?", "When do digital interactions feel shallow?", "What makes communication authentic?", "How do you balance online and offline connection?", "What challenges exist in digital relationships?"]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (
      lesson_id,
      activity_type,
      activity_order,
      title,
      description,
      content
    ) VALUES (
      'C1-L46',
      'speaking_improvement',
      10,
      'Speaking Improvement',
      'Read the improved version of your speech',
      '{"type": "speaking_improvement", "similarityThreshold": 70}'::jsonb
    );
END $$;
