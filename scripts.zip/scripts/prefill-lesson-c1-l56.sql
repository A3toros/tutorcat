-- =========================================
-- Pre-fill Database with Sample Lesson Data
-- C1-L56: Environmental Education
-- =========================================
DELETE FROM lesson_activity_results WHERE lesson_id = 'C1-L56';
DELETE FROM user_progress WHERE lesson_id = 'C1-L56';
DELETE FROM lesson_history WHERE lesson_id = 'C1-L56';
DELETE FROM grammar_sentences WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'C1-L56');
DELETE FROM vocabulary_items WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'C1-L56');
DELETE FROM lesson_activities WHERE lesson_id = 'C1-L56';
DELETE FROM lessons WHERE id = 'C1-L56';

INSERT INTO lessons (id, level, lesson_number, topic) VALUES
('C1-L56', 'C1', 56, 'Environmental Education')
ON CONFLICT (id) DO UPDATE SET topic = EXCLUDED.topic;

DO $$
DECLARE
    lesson_id_var TEXT := 'C1-L56';
    activity_id_var UUID;
BEGIN
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'warm_up_speaking', 1, 'Environmental Education', 'Discuss environmental education', '{"prompt": "What makes environmental education effective?"}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_intro', 2, 'Environmental Education Vocabulary', 'Learn vocabulary about environmental education', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'education', 'การศึกษา', NULL),
    (activity_id_var, 'effectiveness', 'ประสิทธิภาพ', NULL),
    (activity_id_var, 'measurement', 'การวัด', NULL),
    (activity_id_var, 'impact', 'ผลกระทบ', NULL),
    (activity_id_var, 'assessment', 'การประเมิน', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_matching_drag', 3, 'Match Environmental Education Words', 'Match English words with Thai meanings', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'education', 'การศึกษา', NULL),
    (activity_id_var, 'effectiveness', 'ประสิทธิภาพ', NULL),
    (activity_id_var, 'measurement', 'การวัด', NULL),
    (activity_id_var, 'impact', 'ผลกระทบ', NULL),
    (activity_id_var, 'assessment', 'การประเมิน', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 4, 'Complete the Sentences 1', 'Fill with the correct word', '{"text": "Environmental ___ requires ___. Success should be measured through ___.", "blanks": [{"id": "blank1", "text": "education", "options": ["education", "effectiveness", "measurement", "impact"], "correctAnswer": "education"}, {"id": "blank2", "text": "effectiveness", "options": ["effectiveness", "education", "measurement", "impact"], "correctAnswer": "effectiveness"}, {"id": "blank3", "text": "assessment", "options": ["assessment", "education", "measurement", "impact"], "correctAnswer": "assessment"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 5, 'Complete the Sentences 2', 'Fill with the correct word', '{"text": "Effective ___ creates ___. ___ of learning requires careful ___.", "blanks": [{"id": "blank1", "text": "education", "options": ["education", "effectiveness", "measurement", "impact"], "correctAnswer": "education"}, {"id": "blank2", "text": "impact", "options": ["impact", "education", "measurement", "effectiveness"], "correctAnswer": "impact"}, {"id": "blank3", "text": "Measurement", "options": ["Measurement", "Education", "Effectiveness", "Impact"], "correctAnswer": "Measurement"}, {"id": "blank4", "text": "assessment", "options": ["assessment", "education", "measurement", "impact"], "correctAnswer": "assessment"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_explanation', 6, 'Articles: Generic Reference', 'Learn articles with generic nouns', '{"rules": "Generic reference with articles:\n- Zero article for general concepts: \"Education shapes understanding.\"\n- \"The\" for specific instances: \"The education we receive matters.\"\n- \"A/an\" for classifying: \"Education is a powerful tool.\"\n\nPatterns:\n- General statements: \"Environmental education influences behavior.\"\n- Specific reference: \"The education provided in schools differs.\"\n- Classification: \"Education is a form of empowerment.\"\n\nUse for:\n- General statements: \"Education evolves.\"\n- Specific cases: \"The education we see is changing.\"\n- Classification: \"Education is a lifelong process.\"", "examples": ["Environmental education shapes understanding.", "The education provided in schools creates impact.", "Education is a powerful tool for change.", "The education we receive influences behavior.", "Environmental education requires effective methods."]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 7, 'Build Sentences 1', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'Environmental education shapes understanding.', 'Environmental education shapes understanding.', '["Environmental", "education", "shapes", "understanding."]'::jsonb),
    (activity_id_var, 'The education provided in schools creates impact.', 'The education provided in schools creates impact.', '["The", "education", "provided", "in", "schools", "creates", "impact."]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 8, 'Build Sentences 2', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'Education is a powerful tool for change.', 'Education is a powerful tool for change.', '["Education", "is", "a", "powerful", "tool", "for", "change."]'::jsonb),
    (activity_id_var, 'The education we receive influences behavior.', 'The education we receive influences behavior.', '["The", "education", "we", "receive", "influences", "behavior."]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'speaking_practice', 9, 'Discuss Environmental Education', 'Practice speaking about environmental education', '{"prompts": ["What makes environmental education effective?", "How should success in environmental education be measured?", "How should environmental topics be taught?", "What makes environmental education impactful?", "How is learning about the environment assessed?"]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (
      lesson_id,
      activity_type,
      activity_order,
      title,
      description,
      content
    ) VALUES (
      'C1-L56',
      'speaking_improvement',
      10,
      'Speaking Improvement',
      'Read the improved version of your speech',
      '{"type": "speaking_improvement", "similarityThreshold": 70}'::jsonb
    );
END $$;
