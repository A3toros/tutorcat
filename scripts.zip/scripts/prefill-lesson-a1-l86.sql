-- =========================================
-- Pre-fill Database with Sample Lesson Data
-- A1-L86: Ordering Simple Food
-- =========================================

DELETE FROM grammar_sentences WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'A1-L86');
DELETE FROM vocabulary_items WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'A1-L86');
DELETE FROM lesson_activities WHERE lesson_id = 'A1-L86';
DELETE FROM lessons WHERE id = 'A1-L86';

INSERT INTO lessons (id, level, lesson_number, topic) VALUES
('A1-L86', 'A1', 86, 'Ordering Simple Food')
ON CONFLICT (id) DO UPDATE SET topic = EXCLUDED.topic;

DO $$
DECLARE
    lesson_id_var TEXT := 'A1-L86';
    activity_id_var UUID;
BEGIN
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'warm_up_speaking', 1, 'Order Food', 'Talk about ordering', '{"prompt": "Can I order rice?"}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_intro', 2, 'Order Words', 'Learn simple order words', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'menu', 'เมนู', NULL),
    (activity_id_var, 'order', 'สั่ง', NULL),
    (activity_id_var, 'water', 'น้ำ', NULL),
    (activity_id_var, 'rice', 'ข้าว', NULL),
    (activity_id_var, 'pay', 'จ่าย', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_matching_drag', 3, 'Match Order Words', 'Match order words', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'menu', 'เมนู', NULL),
    (activity_id_var, 'order', 'สั่ง', NULL),
    (activity_id_var, 'water', 'น้ำ', NULL),
    (activity_id_var, 'rice', 'ข้าว', NULL),
    (activity_id_var, 'pay', 'จ่าย', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 4, 'Complete the Sentences 1', 'Fill with the correct word', '{"text": "Can I see the ___? I want to ___ rice.", "blanks": [{"id": "blank1", "text": "menu", "options": ["menu", "order", "water", "pay"], "correctAnswer": "menu"}, {"id": "blank2", "text": "order", "options": ["order", "pay", "rice", "water"], "correctAnswer": "order"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 5, 'Complete the Sentences 2', 'Fill with the correct word', '{"text": "Can I have ___? Where do I ___?", "blanks": [{"id": "blank1", "text": "water", "options": ["water", "menu", "order", "pay"], "correctAnswer": "water"}, {"id": "blank2", "text": "pay", "options": ["pay", "order", "water", "menu"], "correctAnswer": "pay"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_explanation', 6, 'Can (requests)', 'Ask politely when ordering', '{"rules": "Use can to order and ask.\n- Can I order rice?\n- Can I have water?\n- Can I pay here?", "examples": ["Can I order rice?", "Can I have water?", "Can I see the menu?", "Can I pay here?", "Can I have the bill?"]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 7, 'Build Sentences 1', 'Arrange words', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'Can I order rice', 'Can I order rice?', '["Can", "I", "order", "rice?"]'::jsonb),
    (activity_id_var, 'Can I have water', 'Can I have water?', '["Can", "I", "have", "water?"]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 8, 'Build Sentences 2', 'Arrange words', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'Can I see the menu', 'Can I see the menu?', '["Can", "I", "see", "the", "menu?"]'::jsonb),
    (activity_id_var, 'Can I pay here', 'Can I pay here?', '["Can", "I", "pay", "here?"]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'speaking_practice', 9, 'Talk About Ordering', 'Practice ordering politely', '{"prompts": ["Can I order rice?", "Can I have water?", "Can I see the menu?", "Can I pay here?", "Do you want the bill?"]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (
      lesson_id,
      activity_type,
      activity_order,
      title,
      description,
      content
    ) VALUES (
      'A1-L86',
      'speaking_improvement',
      10,
      'Speaking Improvement',
      'Read the improved version of your speech',
      '{"type": "speaking_improvement", "similarityThreshold": 70}'::jsonb
    );
END $$;

