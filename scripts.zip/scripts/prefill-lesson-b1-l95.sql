-- =========================================
-- Pre-fill Database with Sample Lesson Data
-- B1-L95: Relationship Advice
-- =========================================

DELETE FROM grammar_sentences WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'B1-L95');
DELETE FROM vocabulary_items WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'B1-L95');
DELETE FROM lesson_activities WHERE lesson_id = 'B1-L95';
DELETE FROM lessons WHERE id = 'B1-L95';

INSERT INTO lessons (id, level, lesson_number, topic) VALUES
('B1-L95', 'B1', 95, 'Relationship Advice')
ON CONFLICT (id) DO UPDATE SET topic = EXCLUDED.topic;

DO $$
DECLARE
    lesson_id_var TEXT := 'B1-L95';
    activity_id_var UUID;
BEGIN
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'warm_up_speaking', 1, 'Handling Conflict', 'Talk about giving and receiving advice in relationships', '{"prompt": "What advice actually helped you in a conflict?"}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_intro', 2, 'Advice Words', 'Learn vocabulary about relationship advice', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'apologize', 'ขอโทษ', NULL),
    (activity_id_var, 'listen', 'ฟัง', NULL),
    (activity_id_var, 'respect', 'เคารพ', NULL),
    (activity_id_var, 'compromise', 'ประนีประนอม', NULL),
    (activity_id_var, 'forgive', 'ให้อภัย', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_matching_drag', 3, 'Match Advice Words', 'Match words with meanings', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'apologize', 'ขอโทษ', NULL),
    (activity_id_var, 'listen', 'ฟัง', NULL),
    (activity_id_var, 'respect', 'เคารพ', NULL),
    (activity_id_var, 'compromise', 'ประนีประนอม', NULL),
    (activity_id_var, 'forgive', 'ให้อภัย', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 4, 'Complete the Sentences 1', 'Fill with the correct word', '{"text": "I learned to ___. I must ___. We try to ___.", "blanks": [{"id": "blank1", "text": "apologize", "options": ["apologize", "listen", "respect", "forgive"], "correctAnswer": "apologize"}, {"id": "blank2", "text": "listen", "options": ["listen", "respect", "forgive", "compromise"], "correctAnswer": "listen"}, {"id": "blank3", "text": "compromise", "options": ["compromise", "listen", "respect", "apologize"], "correctAnswer": "compromise"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 5, 'Complete the Sentences 2', 'Fill with the correct word', '{"text": "Deep down I still ___. We keep ___ space. We both try to ___.", "blanks": [{"id": "blank1", "text": "respect", "options": ["respect", "listen", "forgive", "compromise"], "correctAnswer": "respect"}, {"id": "blank2", "text": "forgive", "options": ["forgive", "respect", "apologize", "compromise"], "correctAnswer": "forgive"}, {"id": "blank3", "text": "forgive", "options": ["forgive", "apologize", "listen", "respect"], "correctAnswer": "forgive"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    -- Grammar Explanation: Gerunds & Infinitives (advice language)
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_explanation', 6, 'Gerunds and Infinitives for Advice', 'Use correct patterns when giving advice', '{"rules": "Common patterns: suggest apologizing, recommend listening, decide to compromise, try to respect, avoid blaming. Keep pairs natural.", "examples": ["I suggest apologizing first.", "They decided to listen before reacting.", "We try to respect each other daily.", "She avoids blaming during conflict.", "He offered to compromise on the plan."]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 7, 'Build Sentences 1', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'I suggest apologizing first', 'I suggest apologizing first', '["I", "suggest", "apologizing", "first"]'::jsonb),
    (activity_id_var, 'They decided to listen before reacting', 'They decided to listen before reacting', '["They", "decided", "to", "listen", "before", "reacting"]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 8, 'Build Sentences 2', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'We try to respect each other daily', 'We try to respect each other daily', '["We", "try", "to", "respect", "each", "other", "daily"]'::jsonb),
    (activity_id_var, 'She avoids blaming during conflict', 'She avoids blaming during conflict', '["She", "avoids", "blaming", "during", "conflict"]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'speaking_practice', 9, 'Talk About Relationship Advice', 'Practice talking about advice that works', '{"prompts": ["What advice actually helped you in a conflict?", "When do you decide to compromise?", "How do you forgive without forgetting?"]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (
      lesson_id,
      activity_type,
      activity_order,
      title,
      description,
      content
    ) VALUES (
      'B1-L95',
      'speaking_improvement',
      10,
      'Speaking Improvement',
      'Read the improved version of your speech',
      '{"type": "speaking_improvement", "similarityThreshold": 70}'::jsonb
    );
END $$;

