-- =========================================
-- Pre-fill Database with Sample Lesson Data
-- C1-L14: Future of Assessment
-- =========================================

DELETE FROM grammar_sentences WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'C1-L14');
DELETE FROM vocabulary_items WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'C1-L14');
DELETE FROM lesson_activities WHERE lesson_id = 'C1-L14';
DELETE FROM lessons WHERE id = 'C1-L14';

INSERT INTO lessons (id, level, lesson_number, topic) VALUES
('C1-L14', 'C1', 14, 'Future of Assessment')
ON CONFLICT (id) DO UPDATE SET topic = EXCLUDED.topic;

DO $$
DECLARE
    lesson_id_var TEXT := 'C1-L14';
    activity_id_var UUID;
BEGIN
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'warm_up_speaking', 1, 'Assessment Future', 'Discuss the future of assessment', '{"prompt": "What should assessment really measure?"}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_intro', 2, 'Assessment Vocabulary', 'Learn vocabulary about assessment', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'evaluation', 'การประเมิน', NULL),
    (activity_id_var, 'criterion', 'เกณฑ์', NULL),
    (activity_id_var, 'authentic', 'แท้จริง', NULL),
    (activity_id_var, 'portfolio', 'ผลงานสะสม', NULL),
    (activity_id_var, 'rubric', 'เกณฑ์การให้คะแนน', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_matching_drag', 3, 'Match Assessment Words', 'Match English words with Thai meanings', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'evaluation', 'การประเมิน', NULL),
    (activity_id_var, 'criterion', 'เกณฑ์', NULL),
    (activity_id_var, 'authentic', 'แท้จริง', NULL),
    (activity_id_var, 'portfolio', 'ผลงานสะสม', NULL),
    (activity_id_var, 'rubric', 'เกณฑ์การให้คะแนน', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 4, 'Complete the Sentences 1', 'Fill with the correct word', '{"text": "Modern ___ requires clear ___. A ___ helps standardize grading.", "blanks": [{"id": "blank1", "text": "evaluation", "options": ["evaluation", "criterion", "authentic", "rubric"], "correctAnswer": "evaluation"}, {"id": "blank2", "text": "criteria", "options": ["criteria", "evaluation", "portfolio", "rubric"], "correctAnswer": "criteria"}, {"id": "blank3", "text": "rubric", "options": ["rubric", "evaluation", "criterion", "portfolio"], "correctAnswer": "rubric"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 5, 'Complete the Sentences 2', 'Fill with the correct word', '{"text": "A ___ assessment measures real skills. Students compile work in a ___.", "blanks": [{"id": "blank1", "text": "authentic", "options": ["authentic", "evaluation", "criterion", "rubric"], "correctAnswer": "authentic"}, {"id": "blank2", "text": "portfolio", "options": ["portfolio", "evaluation", "criterion", "rubric"], "correctAnswer": "portfolio"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_explanation', 6, 'Nominal Clauses', 'Learn about nominal clauses', '{"rules": "Nominal clauses function as nouns:\n- Subject: \"What assessment proves matters.\"\n- Object: \"I think that assessment should change.\"\n- Complement: \"The question is who decides.\"\n\nTypes:\n- That-clauses: \"I believe that evaluation needs reform.\"\n- Wh-clauses: \"What you think determines your approach.\"\n- Whether/if: \"The issue is whether portfolios work.\"\n\nUse for:\n- Expressing opinions: \"What I think is that...\"\n- Asking questions: \"Who decides the criteria?\"\n- Making statements: \"That assessment matters is clear.\"", "examples": ["What assessment should prove is a key question.", "I think that evaluation methods need updating.", "The question is who decides the criteria.", "Whether portfolios are effective remains debated.", "That authentic assessment matters is widely accepted."]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 7, 'Build Sentences 1', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'What assessment should prove is a complex question.', 'What assessment should prove is a complex question.', '["What", "assessment", "should", "prove", "is", "a", "complex", "question."]'::jsonb),
    (activity_id_var, 'I think that evaluation methods need reform.', 'I think that evaluation methods need reform.', '["I", "think", "that", "evaluation", "methods", "need", "reform."]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 8, 'Build Sentences 2', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'The question is who decides the criteria.', 'The question is who decides the criteria.', '["The", "question", "is", "who", "decides", "the", "criteria."]'::jsonb),
    (activity_id_var, 'Whether portfolios are effective remains uncertain.', 'Whether portfolios are effective remains uncertain.', '["Whether", "portfolios", "are", "effective", "remains", "uncertain."]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'speaking_practice', 9, 'Discuss Assessment', 'Practice speaking about assessment', '{"prompts": ["What do you think assessment should prove?", "Who should decide how students are evaluated?", "Are exams still effective today?", "Are portfolios a better alternative?", "What makes assessment fair and meaningful?"]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (
      lesson_id,
      activity_type,
      activity_order,
      title,
      description,
      content
    ) VALUES (
      'C1-L14',
      'speaking_improvement',
      10,
      'Speaking Improvement',
      'Read the improved version of your speech',
      '{"type": "speaking_improvement", "similarityThreshold": 70}'::jsonb
    );
END $$;
