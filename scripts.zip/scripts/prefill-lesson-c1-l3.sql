-- =========================================
-- Pre-fill Database with Sample Lesson Data
-- C1-L3: Critical Thinking in Academic Life
-- =========================================

DELETE FROM grammar_sentences WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'C1-L3');
DELETE FROM vocabulary_items WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'C1-L3');
DELETE FROM lesson_activities WHERE lesson_id = 'C1-L3';
DELETE FROM lessons WHERE id = 'C1-L3';

INSERT INTO lessons (id, level, lesson_number, topic) VALUES
('C1-L3', 'C1', 3, 'Critical Thinking in Academic Life')
ON CONFLICT (id) DO UPDATE SET topic = EXCLUDED.topic;

DO $$
DECLARE
    lesson_id_var TEXT := 'C1-L3';
    activity_id_var UUID;
BEGIN
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'warm_up_speaking', 1, 'Critical Thinking', 'Discuss critical thinking', '{"prompt": "When do you question assumptions?"}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_intro', 2, 'Critical Thinking Vocabulary', 'Learn vocabulary about critical thinking', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'analysis', 'การวิเคราะห์', NULL),
    (activity_id_var, 'evaluation', 'การประเมิน', NULL),
    (activity_id_var, 'reasoning', 'การให้เหตุผล', NULL),
    (activity_id_var, 'assumption', 'สมมติฐาน', NULL),
    (activity_id_var, 'evidence', 'หลักฐาน', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_matching_drag', 3, 'Match Critical Thinking Words', 'Match English words with Thai meanings', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'analysis', 'การวิเคราะห์', NULL),
    (activity_id_var, 'evaluation', 'การประเมิน', NULL),
    (activity_id_var, 'reasoning', 'การให้เหตุผล', NULL),
    (activity_id_var, 'assumption', 'สมมติฐาน', NULL),
    (activity_id_var, 'evidence', 'หลักฐาน', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 4, 'Complete the Sentences 1', 'Fill with the correct word', '{"text": "Critical ___ requires careful ___. Strong ___ supports sound ___.", "blanks": [{"id": "blank1", "text": "analysis", "options": ["analysis", "evaluation", "reasoning", "assumption"], "correctAnswer": "analysis"}, {"id": "blank2", "text": "evaluation", "options": ["evaluation", "analysis", "reasoning", "evidence"], "correctAnswer": "evaluation"}, {"id": "blank3", "text": "evidence", "options": ["evidence", "analysis", "assumption", "reasoning"], "correctAnswer": "evidence"}, {"id": "blank4", "text": "reasoning", "options": ["reasoning", "analysis", "evaluation", "assumption"], "correctAnswer": "reasoning"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 5, 'Complete the Sentences 2', 'Fill with the correct word', '{"text": "Questioning ___ leads to deeper understanding. Valid ___ requires solid ___.", "blanks": [{"id": "blank1", "text": "assumptions", "options": ["assumptions", "analysis", "evaluation", "reasoning"], "correctAnswer": "assumptions"}, {"id": "blank2", "text": "reasoning", "options": ["reasoning", "analysis", "assumption", "evidence"], "correctAnswer": "reasoning"}, {"id": "blank3", "text": "evidence", "options": ["evidence", "analysis", "assumption", "evaluation"], "correctAnswer": "evidence"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_explanation', 6, 'Inversion: Seldom/Rarely', 'Learn inversion with seldom and rarely', '{"rules": "Inversion with seldom/rarely:\n- \"Seldom do students question assumptions.\" (formal emphasis)\n- \"Rarely do we challenge authority.\" (emphasis on infrequency)\n- \"Seldom have I seen such critical thinking.\" (past emphasis)\n\nStructure:\n- Seldom/Rarely + auxiliary + subject + verb\n- Used for emphasis and formal tone\n\nUse for:\n- Emphasizing rarity: \"Rarely do we question information.\"\n- Formal statements: \"Seldom did they challenge assumptions.\"\n- Highlighting infrequency: \"Rarely is critical thinking encouraged.\"", "examples": ["Seldom do students question assumptions without prompting.", "Rarely do we challenge information we receive.", "Seldom have I encountered such thorough analysis.", "Rarely is critical thinking fully developed in students.", "Seldom does evaluation occur without evidence."]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 7, 'Build Sentences 1', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'Seldom do students question assumptions without prompting.', 'Seldom do students question assumptions without prompting.', '["Seldom", "do", "students", "question", "assumptions", "without", "prompting."]'::jsonb),
    (activity_id_var, 'Rarely do we challenge information we receive.', 'Rarely do we challenge information we receive.', '["Rarely", "do", "we", "challenge", "information", "we", "receive."]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 8, 'Build Sentences 2', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'Seldom have I encountered such thorough analysis.', 'Seldom have I encountered such thorough analysis.', '["Seldom", "have", "I", "encountered", "such", "thorough", "analysis."]'::jsonb),
    (activity_id_var, 'Rarely is critical thinking fully developed in students.', 'Rarely is critical thinking fully developed in students.', '["Rarely", "is", "critical", "thinking", "fully", "developed", "in", "students."]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'speaking_practice', 9, 'Discuss Critical Thinking', 'Practice speaking about critical thinking', '{"prompts": ["When do you question information you are given?", "What triggers doubt in your academic work?", "How do you develop critical thinking skills?", "What makes an argument worth challenging?", "When is it important to challenge ideas?"]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (
      lesson_id,
      activity_type,
      activity_order,
      title,
      description,
      content
    ) VALUES (
      'C1-L3',
      'speaking_improvement',
      10,
      'Speaking Improvement',
      'Read the improved version of your speech',
      '{"type": "speaking_improvement", "similarityThreshold": 70}'::jsonb
    );
END $$;
