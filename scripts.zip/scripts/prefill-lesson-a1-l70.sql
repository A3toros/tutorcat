-- =========================================
-- Pre-fill Database with Sample Lesson Data
-- A1-L70: Uniforms
-- =========================================

DELETE FROM grammar_sentences WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'A1-L70');
DELETE FROM vocabulary_items WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'A1-L70');
DELETE FROM lesson_activities WHERE lesson_id = 'A1-L70';
DELETE FROM lessons WHERE id = 'A1-L70';

INSERT INTO lessons (id, level, lesson_number, topic) VALUES
('A1-L70', 'A1', 70, 'Uniforms')
ON CONFLICT (id) DO UPDATE SET topic = EXCLUDED.topic;

DO $$
DECLARE
    lesson_id_var TEXT := 'A1-L70';
    activity_id_var UUID;
BEGIN
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'warm_up_speaking', 1, 'Uniform', 'Talk about uniforms', '{"prompt": "Do you wear a uniform?"}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_intro', 2, 'Uniform Words', 'Learn uniform words', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'uniform', 'เครื่องแบบ', NULL),
    (activity_id_var, 'shirt', 'เสื้อเชิ้ต', NULL),
    (activity_id_var, 'skirt', 'กระโปรง', NULL),
    (activity_id_var, 'pants', 'กางเกง', NULL),
    (activity_id_var, 'shoes', 'รองเท้า', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_matching_drag', 3, 'Match Uniform Words', 'Match uniform words', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'uniform', 'เครื่องแบบ', NULL),
    (activity_id_var, 'shirt', 'เสื้อเชิ้ต', NULL),
    (activity_id_var, 'skirt', 'กระโปรง', NULL),
    (activity_id_var, 'pants', 'กางเกง', NULL),
    (activity_id_var, 'shoes', 'รองเท้า', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 4, 'Complete the Sentences 1', 'Fill with the correct word', '{"text": "I wear a ___. I wear ___.", "blanks": [{"id": "blank1", "text": "uniform", "options": ["uniform", "shirt", "pants", "shoes"], "correctAnswer": "uniform"}, {"id": "blank2", "text": "shoes", "options": ["shoes", "skirt", "pants", "shirt"], "correctAnswer": "shoes"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 5, 'Complete the Sentences 2', 'Fill with the correct word', '{"text": "This is a ___. These are ___.", "blanks": [{"id": "blank1", "text": "skirt", "options": ["skirt", "shirt", "pants", "uniform"], "correctAnswer": "skirt"}, {"id": "blank2", "text": "pants", "options": ["pants", "shoes", "shirt", "skirt"], "correctAnswer": "pants"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_explanation', 6, 'Be + Clothes', 'Describe uniform items', '{"rules": "Use be to describe clothes.\n- My shirt is white. My shoes are black.\nAsk: Is your shirt white?", "examples": ["My uniform is blue.", "My shirt is white.", "My pants are black.", "Is your shirt white?", "Are your shoes black?"]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 7, 'Build Sentences 1', 'Arrange words', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'My uniform is blue', 'My uniform is blue.', '["My", "uniform", "is", "blue."]'::jsonb),
    (activity_id_var, 'My shirt is white', 'My shirt is white.', '["My", "shirt", "is", "white."]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 8, 'Build Sentences 2', 'Arrange words', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'My pants are black', 'My pants are black.', '["My", "pants", "are", "black."]'::jsonb),
    (activity_id_var, 'Are your shoes black', 'Are your shoes black?', '["Are", "your", "shoes", "black?"]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'speaking_practice', 9, 'Talk About Uniforms', 'Practice describing uniform', '{"prompts": ["Do you wear a uniform?", "Is your shirt white?", "Are your shoes black?", "Do you wear pants?", "Is your skirt long?"]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (
      lesson_id,
      activity_type,
      activity_order,
      title,
      description,
      content
    ) VALUES (
      'A1-L70',
      'speaking_improvement',
      10,
      'Speaking Improvement',
      'Read the improved version of your speech',
      '{"type": "speaking_improvement", "similarityThreshold": 70}'::jsonb
    );
END $$;

