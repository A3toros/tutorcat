-- =========================================
-- Pre-fill Database with Sample Lesson Data
-- B2-L15: Friendship in student life
-- =========================================

DELETE FROM grammar_sentences WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'B2-L15');
DELETE FROM vocabulary_items WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'B2-L15');
DELETE FROM lesson_activities WHERE lesson_id = 'B2-L15';
DELETE FROM lessons WHERE id = 'B2-L15';

INSERT INTO lessons (id, level, lesson_number, topic) VALUES
('B2-L15', 'B2', 15, 'Friendship in student life')
ON CONFLICT (id) DO UPDATE SET topic = EXCLUDED.topic;

DO $$
DECLARE
    lesson_id_var TEXT := 'B2-L15';
    activity_id_var UUID;
BEGIN
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'warm_up_speaking', 1, 'Friends Check', 'Talk about trust signs', '{"prompt": "How can you tell a friend is stressed, and who notices first?"}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_intro', 2, 'Friendship Words', 'Key words for friendships', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'bond', 'สายสัมพันธ์', NULL),
    (activity_id_var, 'trust', 'ความไว้วางใจ', NULL),
    (activity_id_var, 'drift', 'ห่างกันไป', NULL),
    (activity_id_var, 'reconnect', 'กลับมาติดต่ออีกครั้ง', NULL),
    (activity_id_var, 'lean on', 'พึ่งพา', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_matching_drag', 3, 'Match Friendship Words', 'Match words with meanings', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'bond', 'สายสัมพันธ์', NULL),
    (activity_id_var, 'trust', 'ความไว้วางใจ', NULL),
    (activity_id_var, 'drift', 'ห่างกันไป', NULL),
    (activity_id_var, 'reconnect', 'กลับมาติดต่ออีกครั้ง', NULL),
    (activity_id_var, 'lean on', 'พึ่งพา', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 4, 'Complete the Sentences 1', 'Fill with the correct word', '{"text": "We ___ when projects get hard. After exams we plan to ___. Years of study built our ___.", "blanks": [{"id": "blank1", "text": "lean on", "options": ["lean on", "reconnect", "bond", "trust"], "correctAnswer": "lean on"}, {"id": "blank2", "text": "reconnect", "options": ["reconnect", "drift", "bond", "trust"], "correctAnswer": "reconnect"}, {"id": "blank3", "text": "bond", "options": ["bond", "trust", "lean on", "drift"], "correctAnswer": "bond"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 5, 'Complete the Sentences 2', 'Fill with the correct word', '{"text": "We try not to ___. Small actions build ___.", "blanks": [{"id": "blank1", "text": "drift", "options": ["drift", "bond", "reconnect", "lean on"], "correctAnswer": "drift"}, {"id": "blank2", "text": "trust", "options": ["trust", "bond", "reconnect", "drift"], "correctAnswer": "trust"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_explanation', 6, 'Modals for Deduction', 'Use must/might/can’t to read situations', '{"rules": "Use must for strong certainty, might for possibility, and can’t for strong negative. For past clues, use must/might/can’t have + past participle.\\n- She must be tired; she hasn’t slept.\\n- He might be busy.\\n- They can’t be angry; they just smiled.", "examples": ["She must be stressed; her messages are short.", "He might be studying late tonight.", "They can’t be upset; they were laughing.", "She must have stayed up; she looks exhausted.", "He might have forgotten to reply."]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 7, 'Build Sentences 1', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'She must be stressed; her messages are short', 'She must be stressed; her messages are short.', '["She", "must", "be", "stressed;", "her", "messages", "are", "short."]'::jsonb),
    (activity_id_var, 'He might be studying late tonight', 'He might be studying late tonight.', '["He", "might", "be", "studying", "late", "tonight."]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 8, 'Build Sentences 2', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'They can’t be upset; they were laughing', 'They can’t be upset; they were laughing.', '["They", "can’t", "be", "upset;", "they", "were", "laughing."]'::jsonb),
    (activity_id_var, 'She must have stayed up; she looks exhausted', 'She must have stayed up; she looks exhausted.', '["She", "must", "have", "stayed", "up;", "she", "looks", "exhausted."]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'speaking_practice', 9, 'Talk About Friends', 'Practice deduction with friends', '{"prompts": ["How can you tell a friend is stressed?", "Who notices your mood first?", "When do you reconnect after drifting?"]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (
      lesson_id,
      activity_type,
      activity_order,
      title,
      description,
      content
    ) VALUES (
      'B2-L15',
      'speaking_improvement',
      10,
      'Speaking Improvement',
      'Read the improved version of your speech',
      '{"type": "speaking_improvement", "similarityThreshold": 70}'::jsonb
    );
END $$;


