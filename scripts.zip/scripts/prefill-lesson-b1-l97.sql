-- =========================================
-- Pre-fill Database with Sample Lesson Data
-- B1-L97: Social Media Breaks
-- =========================================

DELETE FROM grammar_sentences WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'B1-L97');
DELETE FROM vocabulary_items WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'B1-L97');
DELETE FROM lesson_activities WHERE lesson_id = 'B1-L97';
DELETE FROM lessons WHERE id = 'B1-L97';

INSERT INTO lessons (id, level, lesson_number, topic) VALUES
('B1-L97', 'B1', 97, 'Social Media Breaks')
ON CONFLICT (id) DO UPDATE SET topic = EXCLUDED.topic;

DO $$
DECLARE
    lesson_id_var TEXT := 'B1-L97';
    activity_id_var UUID;
BEGIN
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'warm_up_speaking', 1, 'Taking Breaks', 'Talk about taking breaks from social media', '{"prompt": "When do you decide to log off for your mental health?"}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_intro', 2, 'Break Words', 'Learn vocabulary about taking social media breaks', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'overload', 'ล้น/มากเกินไป', NULL),
    (activity_id_var, 'detox', 'ล้างพิษ/พัก', NULL),
    (activity_id_var, 'quiet time', 'เวลาสงบ', NULL),
    (activity_id_var, 'mute', 'ปิดเสียง', NULL),
    (activity_id_var, 'boundary', 'ขอบเขต', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_matching_drag', 3, 'Match Break Words', 'Match words with meanings', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'overload', 'ล้น/มากเกินไป', NULL),
    (activity_id_var, 'detox', 'ล้างพิษ/พัก', NULL),
    (activity_id_var, 'quiet time', 'เวลาสงบ', NULL),
    (activity_id_var, 'mute', 'ปิดเสียง', NULL),
    (activity_id_var, 'boundary', 'ขอบเขต', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 4, 'Complete the Sentences 1', 'Fill with the correct word', '{"text": "My feed feels like ___. I plan a weekend ___. I schedule ___ for myself.", "blanks": [{"id": "blank1", "text": "overload", "options": ["overload", "detox", "quiet time", "boundary"], "correctAnswer": "overload"}, {"id": "blank2", "text": "detox", "options": ["detox", "mute", "boundary", "quiet time"], "correctAnswer": "detox"}, {"id": "blank3", "text": "quiet time", "options": ["quiet time", "boundary", "mute", "overload"], "correctAnswer": "quiet time"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 5, 'Complete the Sentences 2', 'Fill with the correct word', '{"text": "I ___ loud chats. A clear ___ keeps me calm. Breaks help reduce ___.", "blanks": [{"id": "blank1", "text": "mute", "options": ["mute", "boundary", "detox", "quiet time"], "correctAnswer": "mute"}, {"id": "blank2", "text": "boundary", "options": ["boundary", "mute", "overload", "detox"], "correctAnswer": "boundary"}, {"id": "blank3", "text": "overload", "options": ["overload", "boundary", "quiet time", "mute"], "correctAnswer": "overload"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    -- Grammar Explanation: Too / Enough (stress & breaks)
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_explanation', 6, 'Too / Enough for Break Decisions', 'Use too + adj for excess; adj + enough for sufficiency', '{"rules": "Use too + adjective: too noisy, too negative. Use adjective + enough: calm enough, quiet enough.\\nKeep usage natural.", "examples": ["The feed is too noisy at night.", "My mind is not calm enough to sleep.", "This detox is long enough for me.", "The chat was too negative to stay.", "The break was short but enough to reset."]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 7, 'Build Sentences 1', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'The feed is too noisy at night', 'The feed is too noisy at night', '["The", "feed", "is", "too", "noisy", "at", "night"]'::jsonb),
    (activity_id_var, 'My mind is not calm enough to sleep', 'My mind is not calm enough to sleep', '["My", "mind", "is", "not", "calm", "enough", "to", "sleep"]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 8, 'Build Sentences 2', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'This detox is long enough for me', 'This detox is long enough for me', '["This", "detox", "is", "long", "enough", "for", "me"]'::jsonb),
    (activity_id_var, 'The chat was too negative to stay', 'The chat was too negative to stay', '["The", "chat", "was", "too", "negative", "to", "stay"]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'speaking_practice', 9, 'Talk About Social Breaks', 'Practice talking about taking social media breaks', '{"prompts": ["When do you decide to log off for your mental health?", "How long is a break that feels enough for you?", "What do you do in your quiet time?"]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (
      lesson_id,
      activity_type,
      activity_order,
      title,
      description,
      content
    ) VALUES (
      'B1-L97',
      'speaking_improvement',
      10,
      'Speaking Improvement',
      'Read the improved version of your speech',
      '{"type": "speaking_improvement", "similarityThreshold": 70}'::jsonb
    );
END $$;

