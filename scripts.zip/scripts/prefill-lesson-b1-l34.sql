-- =========================================
-- Pre-fill Database with Sample Lesson Data
-- B1-L34: Problems While Traveling
-- =========================================

DELETE FROM grammar_sentences WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'B1-L34');
DELETE FROM vocabulary_items WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'B1-L34');
DELETE FROM lesson_activities WHERE lesson_id = 'B1-L34';
DELETE FROM lessons WHERE id = 'B1-L34';

INSERT INTO lessons (id, level, lesson_number, topic) VALUES
('B1-L34', 'B1', 34, 'Problems While Traveling')
ON CONFLICT (id) DO UPDATE SET topic = EXCLUDED.topic;

DO $$
DECLARE
    lesson_id_var TEXT := 'B1-L34';
    activity_id_var UUID;
BEGIN
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'warm_up_speaking', 1, 'Travel Problems', 'Talk about trips that went wrong', '{"prompt": "What were you doing when a trip went wrong?"}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_intro', 2, 'Travel Problem Words', 'Learn vocabulary about travel issues', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'delay', 'ความล่าช้า', NULL),
    (activity_id_var, 'miss', 'พลาด', NULL),
    (activity_id_var, 'lose', 'ทำหาย', NULL),
    (activity_id_var, 'reroute', 'เปลี่ยนเส้นทาง', NULL),
    (activity_id_var, 'assist', 'ช่วยเหลือ', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_matching_drag', 3, 'Match Travel Problem Words', 'Match words with meanings', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'delay', 'ความล่าช้า', NULL),
    (activity_id_var, 'miss', 'พลาด', NULL),
    (activity_id_var, 'lose', 'ทำหาย', NULL),
    (activity_id_var, 'reroute', 'เปลี่ยนเส้นทาง', NULL),
    (activity_id_var, 'assist', 'ช่วยเหลือ', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 4, 'Complete the Sentences 1', 'Fill with the correct word', '{"text": "A long ___ happened. We might ___ the flight. They will ___ us to another route.", "blanks": [{"id": "blank1", "text": "delay", "options": ["delay", "miss", "reroute", "assist"], "correctAnswer": "delay"}, {"id": "blank2", "text": "miss", "options": ["miss", "lose", "assist", "delay"], "correctAnswer": "miss"}, {"id": "blank3", "text": "reroute", "options": ["reroute", "assist", "miss", "delay"], "correctAnswer": "reroute"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 5, 'Complete the Sentences 2', 'Fill with the correct word', '{"text": "I might ___ my bag. Staff will ___ you. A short ___ can still ruin plans.", "blanks": [{"id": "blank1", "text": "lose", "options": ["lose", "assist", "miss", "delay"], "correctAnswer": "lose"}, {"id": "blank2", "text": "assist", "options": ["assist", "reroute", "delay", "miss"], "correctAnswer": "assist"}, {"id": "blank3", "text": "delay", "options": ["delay", "lose", "assist", "miss"], "correctAnswer": "delay"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    -- Grammar Explanation: Past Continuous (background for problems)
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_explanation', 6, 'Past Continuous for Travel Problems', 'Use was/were + verb-ing to describe actions in progress when problems happened', '{"rules": "Past continuous: was/were + verb-ing for background actions and interruptions.\\n- I was boarding when the delay was announced.\\n- We were waiting when they rerouted us.", "examples": ["I was boarding when the delay was announced.", "We were waiting when they rerouted us.", "She was looking for help when the gate changed.", "They were checking bags when they lost a tag.", "We were running when the doors closed."]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 7, 'Build Sentences 1', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'I was boarding when the delay was announced', 'I was boarding when the delay was announced', '["I", "was", "boarding", "when", "the", "delay", "was", "announced"]'::jsonb),
    (activity_id_var, 'We were waiting when they rerouted us', 'We were waiting when they rerouted us', '["We", "were", "waiting", "when", "they", "rerouted", "us"]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 8, 'Build Sentences 2', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'She was looking for help when the gate changed', 'She was looking for help when the gate changed', '["She", "was", "looking", "for", "help", "when", "the", "gate", "changed"]'::jsonb),
    (activity_id_var, 'They were checking bags when they lost a tag', 'They were checking bags when they lost a tag', '["They", "were", "checking", "bags", "when", "they", "lost", "a", "tag"]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'speaking_practice', 9, 'Talk About Travel Problems', 'Practice talking about travel mishaps', '{"prompts": ["What were you doing when a trip went wrong?", "How did you get out of it?", "Who stepped in to help you?"]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (
      lesson_id,
      activity_type,
      activity_order,
      title,
      description,
      content
    ) VALUES (
      'B1-L34',
      'speaking_improvement',
      10,
      'Speaking Improvement',
      'Read the improved version of your speech',
      '{"type": "speaking_improvement", "similarityThreshold": 70}'::jsonb
    );
END $$;

