-- =========================================
-- Pre-fill Database with Sample Lesson Data
-- A2-L67: Holiday Weather
-- =========================================

DELETE FROM grammar_sentences WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'A2-L67');
DELETE FROM vocabulary_items WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'A2-L67');
DELETE FROM lesson_activities WHERE lesson_id = 'A2-L67';
DELETE FROM lessons WHERE id = 'A2-L67';

INSERT INTO lessons (id, level, lesson_number, topic) VALUES
('A2-L67', 'A2', 67, 'Holiday Weather')
ON CONFLICT (id) DO UPDATE SET topic = EXCLUDED.topic;

DO $$
DECLARE
    lesson_id_var TEXT := 'A2-L67';
    activity_id_var UUID;
BEGIN
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'warm_up_speaking', 1, 'Weather on Holidays', 'Talk about weather you like', '{"prompt": "What is the best weather for a holiday?"}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_intro', 2, 'Weather Words', 'Learn holiday weather words', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'sunny', 'แดดออก', NULL),
    (activity_id_var, 'rainy', 'ฝนตก', NULL),
    (activity_id_var, 'warm', 'อบอุ่น', NULL),
    (activity_id_var, 'cold', 'หนาว', NULL),
    (activity_id_var, 'favorite', 'ชอบที่สุด', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_matching_drag', 3, 'Match Weather Words', 'Match weather words', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'sunny', 'แดดออก', NULL),
    (activity_id_var, 'rainy', 'ฝนตก', NULL),
    (activity_id_var, 'warm', 'อบอุ่น', NULL),
    (activity_id_var, 'cold', 'หนาว', NULL),
    (activity_id_var, 'favorite', 'ชอบที่สุด', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 4, 'Complete the Sentences 1', 'Fill with the correct word', '{"text": "I like ___ days. She likes ___ weather. Winter is ___ for him.", "blanks": [{"id": "blank1", "text": "sunny", "options": ["sunny", "rainy", "warm", "cold"], "correctAnswer": "sunny"}, {"id": "blank2", "text": "rainy", "options": ["rainy", "sunny", "warm", "cold"], "correctAnswer": "rainy"}, {"id": "blank3", "text": "cold", "options": ["cold", "warm", "sunny", "favorite"], "correctAnswer": "cold"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 5, 'Complete the Sentences 2', 'Fill with the correct word', '{"text": "Summer is my ___ season. The beach is ___ than the mountains.", "blanks": [{"id": "blank1", "text": "favorite", "options": ["favorite", "warm", "sunny", "cold"], "correctAnswer": "favorite"}, {"id": "blank2", "text": "warmer", "options": ["warmer", "colder", "rainier", "sunnier"], "correctAnswer": "warmer"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_explanation', 6, 'Comparatives/Superlatives', 'Compare weather for trips', '{"rules": "Use comparatives: warm → warmer; cold → colder; sunny → sunnier; rainy → rainier.\nUse superlatives: the warmest, the coldest.\nPattern: X is warmer than Y.", "examples": ["The beach is warmer than the mountains.", "This city is sunnier than my hometown.", "That week was the coldest.", "Today is rainier than yesterday.", "Summer is the warmest season for me."]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 7, 'Build Sentences 1', 'Arrange words', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'The beach is warmer than the mountains', 'The beach is warmer than the mountains.', '["The", "beach", "is", "warmer", "than", "the", "mountains."]'::jsonb),
    (activity_id_var, 'This city is sunnier than my hometown', 'This city is sunnier than my hometown.', '["This", "city", "is", "sunnier", "than", "my", "hometown."]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 8, 'Build Sentences 2', 'Arrange words', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'That week was the coldest', 'That week was the coldest.', '["That", "week", "was", "the", "coldest."]'::jsonb),
    (activity_id_var, 'Today is rainier than yesterday', 'Today is rainier than yesterday.', '["Today", "is", "rainier", "than", "yesterday."]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'speaking_practice', 9, 'Talk About Holiday Weather', 'Practice comparing weather', '{"prompts": ["What is the best weather for a holiday?", "Is hot weather better than cold weather?", "What was the coldest place you visited?", "What season is best for travel?", "How does weather change your plans?"]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (
      lesson_id,
      activity_type,
      activity_order,
      title,
      description,
      content
    ) VALUES (
      'A2-L67',
      'speaking_improvement',
      10,
      'Speaking Improvement',
      'Read the improved version of your speech',
      '{"type": "speaking_improvement", "similarityThreshold": 70}'::jsonb
    );
END $$;

