-- ===== LESSON B2-L82 =====

-- =========================================
-- Pre-fill Database with Sample Lesson Data
-- B2-L82: Responsible media use (habits)
-- =========================================

DELETE FROM lesson_activity_results WHERE lesson_id = 'B2-L82';
DELETE FROM user_progress WHERE lesson_id = 'B2-L82';
DELETE FROM lesson_history WHERE lesson_id = 'B2-L82';
DELETE FROM grammar_sentences WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'B2-L82');
DELETE FROM vocabulary_items WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'B2-L82');
DELETE FROM lesson_activities WHERE lesson_id = 'B2-L82';
DELETE FROM lessons WHERE id = 'B2-L82';

INSERT INTO lessons (id, level, lesson_number, topic) VALUES
('B2-L82', 'B2', 82, 'Responsible media use (habits)')
ON CONFLICT (id) DO UPDATE SET topic = EXCLUDED.topic;

DO $$
DECLARE
    lesson_id_var TEXT := 'B2-L82';
    activity_id_var UUID;
BEGIN
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'warm_up_speaking', 1, 'Screen Time', 'Talk about how you use social media', '{"prompt": "How much time do you spend on your phone?"}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_intro', 2, 'Media Responsibility Words', 'Learn words for responsible media use', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'moderate', 'ควบคุม', NULL),
    (activity_id_var, 'report', 'รายงาน', NULL),
    (activity_id_var, 'restrict', 'จำกัด', NULL),
    (activity_id_var, 'verify', 'ตรวจสอบ', NULL),
    (activity_id_var, 'consent', 'ความยินยอม', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_matching_drag', 3, 'Match Media Words', 'Match responsible media words', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'moderate', 'ควบคุม', NULL),
    (activity_id_var, 'report', 'รายงาน', NULL),
    (activity_id_var, 'restrict', 'จำกัด', NULL),
    (activity_id_var, 'verify', 'ตรวจสอบ', NULL),
    (activity_id_var, 'consent', 'ความยินยอม', NULL);

    -- 4. Vocabulary Fill Blanks #1
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 4, 'Complete the Sentences 1', 'Fill in the blanks with correct words', '{"text": "I need to ___ my use. I will ___ bad content. We should ___.", "blanks": [{"id": "blank1", "text": "moderate", "options": ["moderate", "report", "restrict", "verify"], "correctAnswer": "moderate"}, {"id": "blank2", "text": "report", "options": ["report", "moderate", "restrict", "consent"], "correctAnswer": "report"}, {"id": "blank3", "text": "restrict", "options": ["restrict", "moderate", "report", "verify"], "correctAnswer": "restrict"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    -- 5. Vocabulary Fill Blanks #2
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 5, 'Complete the Sentences 2', 'Fill in the blanks with correct words', '{"text": "I need to ___ this first. Get their ___. We must ___.", "blanks": [{"id": "blank1", "text": "verify", "options": ["verify", "moderate", "report", "restrict"], "correctAnswer": "verify"}, {"id": "blank2", "text": "consent", "options": ["consent", "moderate", "report", "verify"], "correctAnswer": "consent"}, {"id": "blank3", "text": "verify", "options": ["verify", "consent", "moderate", "report"], "correctAnswer": "verify"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    -- 6. Grammar Explanation
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_explanation', 6, 'Present Perfect Continuous for Habits', 'Learn present perfect continuous for ongoing habits', '{"rules": "Use present perfect continuous for habits that started in the past and continue now:\n\n- Form: have/has + been + verb-ing (have been moderating)\n- Use for ongoing habits or repeated actions\n- Emphasizes duration and continuity\n- Often used with time expressions (for months, since last year)\n- Shows habits that are still happening", "examples": ["I have been moderating my social media use.", "She has been reporting inappropriate content.", "They have been verifying information before sharing.", "We have been restricting screen time.", "He has been checking sources regularly."]}'::jsonb)
    RETURNING id INTO activity_id_var;

    -- 7. Grammar Sentences #1
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 7, 'Build Sentences 1', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'I have been moderating my social media use', 'I have been moderating my social media use.', '["I", "have", "been", "moderating", "my", "social", "media", "use."]'::jsonb),
    (activity_id_var, 'She has been reporting inappropriate content', 'She has been reporting inappropriate content.', '["She", "has", "been", "reporting", "inappropriate", "content."]'::jsonb);

    -- 8. Grammar Sentences #2
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 8, 'Build Sentences 2', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'They have been verifying information before sharing', 'They have been verifying information before sharing.', '["They", "have", "been", "verifying", "information", "before", "sharing."]'::jsonb),
    (activity_id_var, 'We have been restricting screen time', 'We have been restricting screen time.', '["We", "have", "been", "restricting", "screen", "time."]'::jsonb);

    -- 9. Speaking Practice
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'speaking_practice', 9, 'Talk About Social Media', 'Practice talking about online habits', '{"prompts": ["What apps do you use most?", "When do you take breaks from your phone?", "Who do you talk to online?", "How do you moderate your media use?", "What habits have you been developing?"]}'::jsonb)
    RETURNING id INTO activity_id_var;

    -- 10. Speaking Improvement
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'speaking_improvement', 10, 'Speaking Improvement', 'Read the improved version of your speech', '{"type": "speaking_improvement", "similarityThreshold": 70}'::jsonb)
    RETURNING id INTO activity_id_var;
END $$;