# C1 Speaking Prompts Reference
## Warm-up and Speaking Practice Prompts for All C1 Lessons

This file contains all warm-up speaking prompts and speaking practice prompts for C1 lessons (L1-L100).

---

## Lesson 1: Defining Success in Modern Society
**Grammar Focus:** Cleft/emphatic #1

**Warm-up Prompt:**
- What does success mean to you now?

**Speaking Practice Prompts:**
- What does success mean to you at this stage of your life?
- When do people usually redefine success?
- How do you define success in your academic life?
- What factors influence your idea of success?
- How has your view of success changed over time?

---

## Lesson 2: Role of Education in Shaping Identity
**Grammar Focus:** Nominal clauses #1

**Warm-up Prompt:**
- How has education shaped who you are?

**Speaking Practice Prompts:**
- How has education shaped your identity?
- What would change if you had a different educational background?
- In what ways does education influence personal development?
- What role does education play in shaping identity?
- How do school experiences affect values and beliefs?

---

## Lesson 3: Critical Thinking in Academic Life
**Grammar Focus:** Inversion (seldom/rarely) #1

**Warm-up Prompt:**
- When do you question assumptions?

**Speaking Practice Prompts:**
- When do you question information you are given?
- What triggers doubt in your academic work?
- How do you develop critical thinking skills?
- What makes an argument worth challenging?
- When is it important to challenge ideas?

---

## Lesson 4: Academic Freedom and Its Limits
**Grammar Focus:** Modals (degrees of certainty) #1

**Warm-up Prompt:**
- How confident are you that limits are necessary?

**Speaking Practice Prompts:**
- How certain are you that limits help academic environments?
- When might limits harm academic freedom?
- What limits should exist in academic settings?
- How should freedom and responsibility be balanced?
- When should academic expression be restricted?

---

## Lesson 5: Purpose of Higher Education
**Grammar Focus:** Cleft/it-clefts #2

**Warm-up Prompt:**
- What do you seek from higher education?

**Speaking Practice Prompts:**
- What do you seek from higher education?
- What makes higher education meaningful?
- What are your main goals for university study?
- How do you measure the value of education?
- What outcomes do you expect from your studies?

---

## Lesson 6: Knowledge vs Skills in the 21st Century
**Grammar Focus:** Contrast linking (C1 nuance) #1

**Warm-up Prompt:**
- Which do you value more today: knowledge or skills?

**Speaking Practice Prompts:**
- Which is more important today: knowledge or skills?
- Why might one be valued over the other?
- How do knowledge and skills complement each other?
- What balance between knowledge and skills is ideal?
- How has their importance changed over time?

---

## Lesson 7: Lifelong Learning
**Grammar Focus:** Participle clauses #1

**Warm-up Prompt:**
- How do you continue learning outside the classroom?

**Speaking Practice Prompts:**
- How do you keep learning beyond formal education?
- What habits support lifelong learning?
- What motivates you to continue learning?
- How do you include learning in daily life?
- What resources do you use for self-directed learning?

---

## Lesson 8: Intellectual Curiosity
**Grammar Focus:** Advanced perfect aspect #1

**Warm-up Prompt:**
- What have you pursued purely out of curiosity?

**Speaking Practice Prompts:**
- What have you explored purely for curiosity?
- How has curiosity shaped your thinking?
- What topics spark your intellectual interest?
- How do you maintain curiosity over time?
- What have you discovered by following curiosity?

---

## Lesson 9: Academic Pressure & Achievement Culture
**Grammar Focus:** Narrative tenses #1

**Warm-up Prompt:**
- Describe a time when academic pressure was highest.

**Speaking Practice Prompts:**
- Describe a time when academic pressure peaked.
- How did the situation unfold?
- What creates pressure in academic environments?
- How does achievement culture affect students?
- What strategies help you manage pressure?

---

## Lesson 10: Value of Failure in Learning
**Grammar Focus:** Mixed conditionals #1

**Warm-up Prompt:**
- If you had not failed at a key moment, what might you have missed?

**Speaking Practice Prompts:**
- If you had not failed, what would you have missed?
- How has failure contributed to your learning?
- What lessons have you learned from failure?
- How can failure be reframed as opportunity?
- What role should failure play in education?

---

## Lesson 11: Ethics in Education
**Grammar Focus:** Articles (abstract/stylistic) #1

**Warm-up Prompt:**
- When should rules be flexible in education?

**Speaking Practice Prompts:**
- Is ethics fixed or changeable in your view?
- When, if ever, is it acceptable to bend rules?
- How do you define academic integrity?
- What ethical dilemmas can students face at school?
- Why is transparency important in education?

---

## Lesson 12: Plagiarism & Academic Integrity
**Grammar Focus:** Advanced passives (reporting) #1

**Warm-up Prompt:**
- How should plagiarism be handled in schools?

**Speaking Practice Prompts:**
- What actions are considered plagiarism?
- Why is plagiarism taken seriously?
- How can students avoid academic dishonesty?
- When is punishment fair or unfair?
- What consequences are appropriate for violations?

---

## Lesson 13: AI Use in Academic Work
**Grammar Focus:** Modals (speculation/criticism past) #1

**Warm-up Prompt:**
- How has AI affected the way you study?

**Speaking Practice Prompts:**
- How might AI have helped your learning?
- How might it have caused problems?
- Should AI be allowed in assignments?
- What ethical concerns does AI raise?
- How can AI be used responsibly in education?

---

## Lesson 14: Future of Assessment
**Grammar Focus:** Nominal clauses #2

**Warm-up Prompt:**
- What should assessment really measure?

**Speaking Practice Prompts:**
- What do you think assessment should prove?
- Who should decide how students are evaluated?
- Are exams still effective today?
- Are portfolios a better alternative?
- What makes assessment fair and meaningful?

---

## Lesson 15: Fairness in Grading Systems
**Grammar Focus:** Cleft/emphatic #3

**Warm-up Prompt:**
- What makes grading fair in your opinion?

**Speaking Practice Prompts:**
- What makes a grading system fair?
- When do students question grades?
- How important is objectivity in grading?
- What causes inconsistencies in grading?
- How can grading systems be improved?

---

## Lesson 16: Standardized Testing: Benefits and Drawbacks
**Grammar Focus:** Contrast linking #2

**Warm-up Prompt:**
- How have standardized tests affected you?

**Speaking Practice Prompts:**
- How have tests helped your learning?
- Where have they caused stress or problems?
- What are the benefits of standardized testing?
- What are the main drawbacks?
- How can testing be made more equitable?

---

## Lesson 17: Digital Surveillance in Education
**Grammar Focus:** Advanced passives #2

**Warm-up Prompt:**
- How much student data should schools collect?

**Speaking Practice Prompts:**
- What student data is commonly tracked?
- When does monitoring go too far?
- Is surveillance ever justified in schools?
- How can privacy be protected?
- What does informed consent mean for students?

---

## Lesson 18: Access to Education Worldwide
**Grammar Focus:** Inversion (little/rarely) #2

**Warm-up Prompt:**
- Why do some students lack access to education?

**Speaking Practice Prompts:**
- What limits access to education globally?
- How rarely is access equal across countries?
- What barriers affect disadvantaged students?
- How can access be expanded?
- What does equal opportunity require?

---

## Lesson 19: Educational Inequality
**Grammar Focus:** Articles (generic) #2

**Warm-up Prompt:**
- What causes inequality in education?

**Speaking Practice Prompts:**
- What factors create educational inequality?
- How does family background affect opportunity?
- Where do you see inequality in your community?
- How does privilege influence outcomes?
- What steps could reduce inequality?

---

## Lesson 20: Meritocracy in Education
**Grammar Focus:** Mixed/implied conditionals #2

**Warm-up Prompt:**
- Does effort always lead to success in education?

**Speaking Practice Prompts:**
- If meritocracy worked perfectly, what would change?
- What limits fair competition in education?
- Does talent matter more than opportunity?
- How can systems reward effort fairly?
- What role does support play in achievement?

---

## Lesson 21: Media Literacy & Misinformation
**Grammar Focus:** Participle clauses #2

**Warm-up Prompt:**
- How do you decide what information to trust?

**Speaking Practice Prompts:**
- How do you check if news is reliable?
- What signs suggest bias or misinformation?
- How do social media platforms influence beliefs?
- What habits help you stay informed?
- How do you deal with conflicting information?

Lesson 22: Critical Evaluation of Sources

Grammar Focus: Nominal clauses #3

Warm-up Prompt:

What makes a source trustworthy?

Speaking Practice Prompts:

What do you consider strong evidence?

How do you judge credibility?

Who influences what you trust?

What criteria do you use to evaluate sources?

How do you avoid unreliable information?

Lesson 23: Bias in News Reporting

Grammar Focus: Modals (degrees of certainty) #2

Warm-up Prompt:

How confident are you in detecting media bias?

Speaking Practice Prompts:

How sure are you when news is biased?

What evidence convinces you?

What types of bias concern you most?

Can bias ever be unintentional?

How can journalists reduce bias?

Lesson 24: Impact of Algorithms on Information

Grammar Focus: Advanced perfect aspect #2

Warm-up Prompt:

How have algorithms shaped what you see online?

Speaking Practice Prompts:

How have recommendations influenced your views?

What role do algorithms play in daily life?

How has your information diet changed?

What risks come with algorithmic filtering?

How can users stay informed despite algorithms?

Lesson 25: Freedom of Speech on Campuses

Grammar Focus: Inversion (hardly/scarcely) #3

Warm-up Prompt:

When should speech be limited at universities?

Speaking Practice Prompts:

When is free speech restricted on campus?

Why do tensions arise around speech?

What limits are reasonable?

How can safety and expression coexist?

Who should decide speech boundaries?

Lesson 26: Cancel Culture and Debate

Grammar Focus: Contrast linking #3

Warm-up Prompt:

When does accountability become silencing?

Speaking Practice Prompts:

How do you define cancel culture?

When is public criticism justified?

How can debate remain respectful?

What risks come with online outrage?

How should disagreements be handled?

Lesson 27: Social Media and Public Opinion

Grammar Focus: Cohesive transformations #1

Warm-up Prompt:

How does social media shape opinions?

Speaking Practice Prompts:

How do posts influence public views?

How do you adapt messages for different platforms?

What posts have caused controversy?

How do trends spread online?

How do you manage your digital image?

Lesson 28: Responsibility of Content Creators

Grammar Focus: Advanced passives #3

Warm-up Prompt:

What responsibilities come with a large audience?

Speaking Practice Prompts:

What should creators be accountable for?

How should harm be addressed?

What role do platforms play?

How should misinformation be corrected?

What ethical standards should creators follow?

Lesson 29: Emotional Manipulation in Media

Grammar Focus: Modals (speculation past) #3

Warm-up Prompt:

How has media influenced your emotions?

Speaking Practice Prompts:

How might media have shaped how you felt?

What emotional techniques are commonly used?

When is emotional appeal acceptable?

How can audiences resist manipulation?

Why is emotional content effective?

Lesson 30: Media Ethics

Grammar Focus: Articles (abstract) #3

Warm-up Prompt:

Where should media draw ethical boundaries?

Speaking Practice Prompts:

What does media ethics mean to you?

What actions cross ethical lines?

How do you judge ethical reporting?

What violations worry you most?

How can ethical standards be enforced?

Lesson 31: Cultural Identity in a Globalized World

Grammar Focus: Participle clauses #3

Warm-up Prompt:

How do you balance identity and adaptation?

Speaking Practice Prompts:

What defines your cultural identity?

How has globalization affected it?

What traditions do you keep?

What changes have you accepted?

How do you adapt without losing identity?

Lesson 32: Preserving Traditions in Modern Societies

Grammar Focus: Advanced perfect #3

Warm-up Prompt:

What traditions have you kept over time?

Speaking Practice Prompts:

What traditions remain important to you?

What traditions have changed?

How are traditions preserved today?

Why do some traditions disappear?

How can traditions adapt to modern life?

Lesson 33: Cultural Appropriation vs Appreciation

Grammar Focus: Cleft/emphatic #4

Warm-up Prompt:

What separates appreciation from misuse?

Speaking Practice Prompts:

How do you define cultural appropriation?

When does appreciation become harmful?

What makes cultural exchange respectful?

Why is intent important?

How can people engage respectfully with cultures?

Lesson 34: Language and Cultural Power

Grammar Focus: Nominal clauses #4

Warm-up Prompt:

How does language influence power?

Speaking Practice Prompts:

How does language signal status?

What happens when one language dominates?

How does language affect opportunity?

Why is linguistic diversity important?

How can minority languages be protected?

Lesson 35: Multicultural Education

Grammar Focus: Cohesion/ellipsis #2

Warm-up Prompt:

What makes classrooms inclusive?

Speaking Practice Prompts:

How do diverse classrooms benefit students?

What challenges arise in multicultural settings?

How can inclusion be improved?

What role do teachers play?

How do students support inclusion?

Lesson 36: Global Citizenship

Grammar Focus: Inversion (never/rarely) #4

Warm-up Prompt:

What does being a global citizen mean to you?

Speaking Practice Prompts:

What responsibilities come with global citizenship?

How do global issues affect you?

What actions show global awareness?

How can students engage globally?

Why is global citizenship important today?

Lesson 37: Cross-cultural Misunderstandings

Grammar Focus: Mixed conditionals #3

Warm-up Prompt:

What misunderstandings arise across cultures?

Speaking Practice Prompts:

What cultural misunderstandings have you seen?

How could they have been avoided?

What helps prevent conflict?

How do you learn cultural norms?

How should mistakes be handled?

Lesson 38: National Identity Among Youth

Grammar Focus: Articles (generic) #4

Warm-up Prompt:

How do young people view national identity today?

Speaking Practice Prompts:

What does national identity mean to you?

How is it changing among youth?

What influences national identity?

How does globalization affect it?

How do young people express identity?

Lesson 39: Cultural Stereotypes

Grammar Focus: Modals (certainty) #4

Warm-up Prompt:

Why do stereotypes persist?

Speaking Practice Prompts:

How do stereotypes form?

How sure can we be they are inaccurate?

What harm do stereotypes cause?

When did you change a belief?

How can stereotypes be challenged?

Lesson 40: Language as a Social Divider

Grammar Focus: Advanced passives #4

Warm-up Prompt:

How can language exclude people?

Speaking Practice Prompts:

How does language create barriers?

Who is affected by language divisions?

How can inclusion be improved?

Who should adapt in multilingual settings?

What role does education play?

Lesson 41: Technology Shaping Human Behavior

Grammar Focus: Advanced perfect #4

Warm-up Prompt:

How has technology changed your habits?

Speaking Practice Prompts:

What behaviors have changed over time?

How has technology shaped routines?

What habits concern you?

What benefits have emerged?

How do you manage tech influence?

Lesson 42: Ethical Limits of Artificial Intelligence

Grammar Focus: Modals (criticism past) #4

Warm-up Prompt:

Where should limits be placed on AI?

Speaking Practice Prompts:

What ethical boundaries should AI respect?

Where has AI caused harm?

How should AI development be regulated?

What uses of AI concern you most?

Who should be responsible for oversight?

Lesson 43: Data Privacy and Consent

Grammar Focus: Nominal clauses #5

Warm-up Prompt:

What does consent mean online?

Speaking Practice Prompts:

Who owns personal data?

What data do you share knowingly?

How do you protect your privacy?

When is consent unclear?

How should companies handle user data?

Lesson 44: Digital Dependency

Grammar Focus: Inversion (hardly/rarely) #5

Warm-up Prompt:

How dependent are you on digital devices?

Speaking Practice Prompts:

How often are you offline?

What happens when you disconnect?

What signs show dependency?

What benefits does technology provide?

How can balance be maintained?

Lesson 45: Technology and Attention Span

Grammar Focus: Articles (abstract) #5

Warm-up Prompt:

What affects your ability to focus?

Speaking Practice Prompts:

How has technology affected attention?

What distracts you most?

How do you protect concentration?

What strategies help maintain focus?

How can attention be improved?

Lesson 46: Human Connection in a Digital Age

Grammar Focus: Participle clauses #4

Warm-up Prompt:

How do digital tools affect relationships?

Speaking Practice Prompts:

How do you maintain meaningful connections online?

When do digital interactions feel shallow?

What makes communication authentic?

How do you balance online and offline connection?

What challenges exist in digital relationships?

Lesson 47: Virtual Communities

Grammar Focus: Cohesion/substitution #3

Warm-up Prompt:

Why do people join virtual communities?

Speaking Practice Prompts:

What creates belonging online?

What norms form in virtual groups?

How do online communities differ from offline ones?

What benefits do they offer?

What challenges do they face?

Lesson 48: Future of Human Communication

Grammar Focus: Advanced perfect #5

Warm-up Prompt:

How will communication change in the future?

Speaking Practice Prompts:

How will communication have evolved in 10 years?

What trends do you predict?

What will remain the same?

How will technology shape interaction?

How should people adapt?

Lesson 49: Automation and Society

Grammar Focus: Advanced passives #5

Warm-up Prompt:

What should remain human in an automated world?

Speaking Practice Prompts:

What tasks should be automated?

What should never be automated?

How does automation affect jobs?

What ethical concerns exist?

How should society adapt to automation?

Lesson 50: Ethical Responsibility of Tech Companies

Grammar Focus: Modals (degrees past) #5

Warm-up Prompt:

How could tech companies have acted differently in the past?

Speaking Practice Prompts:

How could tech companies have acted differently?

Who pays for mistakes made by tech firms?

What responsibilities do tech companies have?

How should tech companies be regulated?

Who should be accountable for technology’s impact?

Lesson 51: Climate Responsibility of Individuals

Grammar Focus: Cleft/emphatic #5

Warm-up Prompt:

What is it that you can change first in your daily life?

Speaking Practice Prompts:

What is it that you can change first?

How do you take action on climate issues?

What individual actions matter most?

How do you balance personal and collective responsibility?

What changes have you already made for the climate?

Lesson 52: Environmental Activism Among Youth

Grammar Focus: Inversion (seldom/rarely) #6

Warm-up Prompt:

When have you taken action for the environment?

Speaking Practice Prompts:

When have you taken action?

What stopped you from acting more?

How do young people engage in environmental activism?

What motivates youth environmental action?

What barriers prevent young people from acting?

Lesson 53: Sustainable Lifestyles

Grammar Focus: Participle clauses #5

Warm-up Prompt:

What habits have you kept while trying to live sustainably?

Speaking Practice Prompts:

What habits have you kept?

What sustainable practices do you maintain?

How do you make sustainability part of daily life?

What changes have become permanent for you?

What makes sustainable habits hard to maintain?

Lesson 54: Climate Anxiety

Grammar Focus: Nominal clauses #6

Warm-up Prompt:

What helps you stay calm when thinking about the future?

Speaking Practice Prompts:

What do you tell yourself about the future?

What helps you feel calmer?

How do you manage climate anxiety?

What helps you stay hopeful?

How do you balance concern with action?

Lesson 55: Science Communication & Public Trust

Grammar Focus: Advanced passives #6

Warm-up Prompt:

How should scientific information be communicated to the public?

Speaking Practice Prompts:

How should science be communicated?

Who should lead science communication?

How is trust in science built or lost?

What makes scientific communication effective?

How are scientific claims evaluated by the public?

Lesson 56: Environmental Education

Grammar Focus: Articles (generic) #6

Warm-up Prompt:

What makes environmental education effective?

Speaking Practice Prompts:

What makes environmental education effective?

How should success in environmental education be measured?

How should environmental topics be taught?

What makes environmental education impactful?

How is learning about the environment assessed?

Lesson 57: Green Technology Promises & Limits

Grammar Focus: Contrast linking #4

Warm-up Prompt:

What hopes do you have for green technology?

Speaking Practice Prompts:

What hopes do you have for green technology?

Where do you see exaggeration or hype?

What green technologies excite you?

What limitations concern you?

How do you balance optimism with realism?

Lesson 58: Consumer Responsibility

Grammar Focus: Modals (speculation past) #6

Warm-up Prompt:

How could you have made different buying choices in the past?

Speaking Practice Prompts:

How could you have bought differently?

What consumer choices matter for the environment?

How do you make responsible purchasing decisions?

What influences your buying choices most?

How do you balance cost and sustainability?

Lesson 59: Ethics of Environmental Protest

Grammar Focus: Mixed conditionals #4

Warm-up Prompt:

If environmental protests were banned, what would you do now?

Speaking Practice Prompts:

If protests were banned, what would you do now?

When is environmental protest justified?

What forms of protest are ethical?

How do you balance disruption and message?

What alternatives to protest exist?

Lesson 60: Long-term Thinking in Climate Policy

Grammar Focus: Advanced perfect #6

Warm-up Prompt:

How will today’s decisions have shaped the world by 2040?

Speaking Practice Prompts:

How will today’s choices have shaped the future?

What long-term consequences concern you most?

How do you think about future generations?

What policies require long-term vision?

How do you balance present and future needs?

Lesson 61: Moral Decision-making in Daily Life

Grammar Focus: Articles (abstract) #7

Warm-up Prompt:

What makes a small choice a moral one?

Speaking Practice Prompts:

What makes a small choice moral?

How do you decide what is right?

How do you make moral decisions daily?

What guides your ethical choices?

When do small choices become morally important?

Lesson 62: Personal Values vs Social Norms

Grammar Focus: Cleft/emphatic #6

Warm-up Prompt:

What is it that you refuse to change about yourself?

Speaking Practice Prompts:

What is it that you refuse to change?

Why is that important to you?

How do you balance personal values and social expectations?

When do you prioritize your values?

What conflicts arise between values and norms?

Lesson 63: Ethical Dilemmas Without Clear Answers

Grammar Focus: Mixed/implied conditionals #5

Warm-up Prompt:

If no rule clearly applied, how would you decide?

Speaking Practice Prompts:

If no rule fit, how would you choose?

How do you handle ethical dilemmas?

What guides you when rules conflict?

How do you make difficult moral choices?

What frameworks help in unclear situations?

Lesson 64: Responsibility and Privilege

Grammar Focus: Modals (certainty degrees) #6

Warm-up Prompt:

How aware are you of your own privilege?

Speaking Practice Prompts:

How sure are you about your privilege?

How do you act on that awareness?

How do you recognize your advantages?

What responsibilities come with privilege?

How should privilege be used responsibly?

Lesson 65: Freedom and Accountability

Grammar Focus: Contrast linking #5

Warm-up Prompt:

Where should the line be drawn between freedom and accountability?

Speaking Practice Prompts:

Where do you draw the line between freedom and accountability?

How do you balance freedom and responsibility?

When should freedom be limited?

What forms of accountability are necessary?

How do these concepts interact in society?

Lesson 66: Justice and Fairness

Grammar Focus: Advanced passives #7

Warm-up Prompt:

How should justice be delivered in society?

Speaking Practice Prompts:

How should justice be delivered?

What harms must be repaired?

What does justice mean to you?

How is fairness achieved?

What systems are designed to ensure justice?

Lesson 67: Moral Courage

Grammar Focus: Inversion (little/rarely) #6

Warm-up Prompt:

When have you needed courage to do the right thing?

Speaking Practice Prompts:

When did you show moral courage?

What held you back?

What does moral courage mean to you?

When is courage required?

How can moral courage be developed?

Lesson 68: Individual Impact on Society

Grammar Focus: Participle clauses #6

Warm-up Prompt:

How are your actions contributing to society over time?

Speaking Practice Prompts:

How are you contributing now?

What effects accumulate over time?

How do individual actions create change?

What impact can one person have?

How do small contributions add up?

Lesson 69: Altruism vs Self-interest

Grammar Focus: Nominal clauses #7

Warm-up Prompt:

What do you believe motivates people’s actions?

Speaking Practice Prompts:

What do you believe about human motives?

When do you act selflessly?

Can actions be purely altruistic?

How do you balance self-interest and helping others?

What motivates selfless behavior?

Lesson 70: Defining Ethical Behavior

Grammar Focus: Modals (criticism past) #7

Warm-up Prompt:

How could you have acted more ethically in a past situation?

Speaking Practice Prompts:

How could you have acted better in that moment?

How do you define ethical behavior?

What makes behavior ethical?

How do you learn from ethical mistakes?

What standards guide your behavior?

Lesson 71: Psychological Well-being of Students

Grammar Focus: Advanced perfect #7

Warm-up Prompt:

How has your well-being changed over recent semesters?

Speaking Practice Prompts:

How has your well-being changed over time?

What affects student mental health most?

How do you maintain well-being during studies?

What support do students need?

How do you recognize when you need help?

Lesson 72: Burnout Culture in Education

Grammar Focus: Articles (abstract) #8

Warm-up Prompt:

What contributes most to burnout in education?

Speaking Practice Prompts:

What contributes to burnout?

How do you recognize burnout?

What creates burnout in education systems?

How does burnout affect learning?

What helps prevent or recover from burnout?

Lesson 73: Emotional Intelligence

Grammar Focus: Cleft/emphatic #7

Warm-up Prompt:

What is it that you notice first about other people’s emotions?

Speaking Practice Prompts:

What is it that you notice first in others?

How do you respond emotionally?

How can emotional intelligence be developed?

What role does empathy play?

How do you manage emotions effectively?

Lesson 74: Identity Formation in Young Adulthood

Grammar Focus: Advanced passives #8

Warm-up Prompt:

How is identity shaped by others’ expectations?

Speaking Practice Prompts:

How is identity shaped by others’ views?

What factors influence identity formation?

How do you define yourself?

What role do others play in identity development?

How does identity change in young adulthood?

Lesson 75: Coping with Uncertainty

Grammar Focus: Modals (degrees of certainty) #7

Warm-up Prompt:

How do you decide whether a risk is worth taking?

Speaking Practice Prompts:

How do you judge if a risk is worth it?

How do you handle uncertainty?

What helps you cope with unknown outcomes?

How do you make decisions with limited information?

What strategies help with uncertainty?

Lesson 76: Perfectionism and Mental Health

Grammar Focus: Mixed conditionals #6

Warm-up Prompt:

If you had let go earlier, how would you feel now?

Speaking Practice Prompts:

If you had let go earlier, how would you feel now?

How does perfectionism affect you?

What drives perfectionist behavior?

How do you balance high standards and well-being?

What helps you let go of perfectionism?

Lesson 77: Motivation vs Discipline

Grammar Focus: Inversion (hardly/scarcely) #7

Warm-up Prompt:

When does motivation disappear, and what keeps you going?

Speaking Practice Prompts:

When does motivation vanish?

What keeps you moving forward?

How do you maintain discipline?

What is the difference between motivation and discipline?

How do you stay committed without motivation?

Lesson 78: Meaning and Purpose

Grammar Focus: Nominal clauses #8

Warm-up Prompt:

What gives your life a sense of purpose right now?

Speaking Practice Prompts:

What do you call “purpose” in your life?

How has your sense of purpose changed?

How do you find meaning in daily life?

What gives your life direction?

How does purpose evolve over time?

Lesson 79: Resilience in Challenging Environments

Grammar Focus: Participle clauses #7

Warm-up Prompt:

What has helped you keep going during difficult periods?

Speaking Practice Prompts:

How have you kept going?

What habits support your resilience?

How do you build resilience?

What helps you recover from setbacks?

How do you stay strong during challenges?

Lesson 80: Self-reflection as a Skill

Grammar Focus: Advanced perfect #8

Warm-up Prompt:

How long have you practiced deliberate self-reflection?

Speaking Practice Prompts:

How long have you reflected deliberately?

What changes have you noticed?

How do you practice self-reflection?

What insights come from reflection?

How does reflection improve your life?

Lesson 81: Global Mobility of Students

Grammar Focus: Advanced passives #9

Warm-up Prompt:

How are students moved across borders for education?

Speaking Practice Prompts:

How are students selected or relocated?

Who benefits from student mobility?

What drives global student movement?

How does studying abroad work?

Who gains from international education?

Lesson 82: Brain Drain and Brain Circulation

Grammar Focus: Contrast linking #6

Warm-up Prompt:

What is gained and lost when skilled people leave a country?

Speaking Practice Prompts:

What is gained and lost when people leave?

How does brain drain affect countries?

What is brain circulation?

How do you balance personal opportunity and national need?

What policies address brain drain?

Lesson 83: Studying Abroad and Identity Change

Grammar Focus: Mixed conditionals #7

Warm-up Prompt:

If you had not studied abroad, how might you be different now?

Speaking Practice Prompts:

If you hadn’t left, who would you be now?

How does studying abroad change identity?

What personal changes occur abroad?

How do you maintain identity while adapting?

What do you gain from international experience?

Lesson 84: Language Dominance in Academia

Grammar Focus: Articles (stylistic) #9

Warm-up Prompt:

How does one language come to dominate academic fields?

Speaking Practice Prompts:

How does one language dominate academia?

What factors shift the balance?

What role does English play in academia?

How does language dominance affect access?

What might a multilingual academic world look like?

Lesson 85: Inequality in Global Education Systems

Grammar Focus: Inversion (rarely/seldom) #7

Warm-up Prompt:

How rarely do you see true equality in education systems?

Speaking Practice Prompts:

How rarely do you see equality in education?

What would help reduce inequality?

What inequalities exist in global education?

How can global education become more equal?

What systemic changes are needed?

Lesson 86: International Cooperation in Education

Grammar Focus: Cohesion/ellipsis #4

Warm-up Prompt:

How do international education partnerships succeed or fail?

Speaking Practice Prompts:

How do educational partnerships work?

What causes partnerships to fail?

What enables successful international cooperation?

What challenges arise in cross-border partnerships?

How is trust built between institutions?

Lesson 87: Cultural Shock and Adaptation

Grammar Focus: Narrative tenses #2

Warm-up Prompt:

Describe a moment of cultural shock and how it ended.

Speaking Practice Prompts:

Describe your biggest cultural shock and its outcome.

What cultural shocks have you experienced?

How do you adapt to new cultures?

What helps with cultural adjustment?

How do you manage cultural differences?

Lesson 88: Education as Soft Power

Grammar Focus: Modals (speculation) #8

Warm-up Prompt:

How might education influence international relationships?

Speaking Practice Prompts:

How might education influence other nations?

What does “soft power” mean in education?

How does education shape international relations?

What influence do exchange programs have?

How do countries use education diplomatically?

Lesson 89: Ethical Study Abroad Practices

Grammar Focus: Advanced passives #10

Warm-up Prompt:

What responsibilities must be upheld in study abroad programs?

Speaking Practice Prompts:

What must be ensured by study abroad programs?

What should students avoid when studying abroad?

What ethical standards should programs follow?

How can students engage ethically in host cultures?

What responsibilities are held by institutions?

Lesson 90: Global Academic Competition

Grammar Focus: Advanced perfect #9

Warm-up Prompt:

How has academic competition shaped your decisions over time?

Speaking Practice Prompts:

How has competition shaped your academic choices?

What drives global academic competition?

How does competition affect students?

What are the benefits and costs of competition?

How do you navigate competitive environments?

Lesson 91: Influence of Philosophy on Modern Thinking

Grammar Focus: Nominal clauses #9

Warm-up Prompt:

Which philosophical ideas influence how you see the world?

Speaking Practice Prompts:

Which ideas shape your worldview?

Why do those ideas matter to you?

How has philosophy influenced your thinking?

What philosophical concepts guide modern society?

How do philosophical ideas affect daily decisions?

Lesson 92: Literature as Social Commentary

Grammar Focus: Articles (abstract) #10

Warm-up Prompt:

How does literature reflect society?

Speaking Practice Prompts:

What is literature to you?

How does literature comment on society?

What social issues are explored through literature?

How does literature challenge social norms?

How do you read literature critically?

Lesson 93: Art as Political Expression

Grammar Focus: Cleft/emphatic #8

Warm-up Prompt:

What is it that art communicates more powerfully than words?

Speaking Practice Prompts:

What is it that art expresses better than speech?

How does art convey political ideas?

What makes art politically powerful?

How do you interpret political art?

What role does art play in social change?

Lesson 94: Role of Creativity in Learning

Grammar Focus: Participle clauses #8

Warm-up Prompt:

How do you incorporate creativity into your learning process?

Speaking Practice Prompts:

How do you include creativity in your studies?

What role does creativity play in learning?

How can learning be made more creative?

What creative strategies help you learn?

How does creativity deepen understanding?

Lesson 95: Interdisciplinary Thinking

Grammar Focus: Contrast linking #7

Warm-up Prompt:

When do academic disciplines combine most effectively?

Speaking Practice Prompts:

When do academic fields clash?

When do they work best together?

How do you connect different disciplines?

What benefits come from interdisciplinary thinking?

What challenges arise when combining fields?

Lesson 96: Science vs Belief Systems

Grammar Focus: Inversion (never/little) #8

Warm-up Prompt:

When have personal beliefs overridden evidence?

Speaking Practice Prompts:

When have beliefs overridden evidence?

How did you respond in that situation?

How do you balance science and belief?

When do beliefs conflict with facts?

How can different worldviews be reconciled?

Lesson 97: Limits of Objectivity

Grammar Focus: Advanced passives #11

Warm-up Prompt:

How objective can research truly be?

Speaking Practice Prompts:

How objective can research be?

Who is responsible for checking objectivity?

What limits exist in academic research?

How are biases introduced into research?

What safeguards protect research integrity?

Lesson 98: Truth in the Post-truth Era

Grammar Focus: Modals (degrees of certainty) #8

Warm-up Prompt:

How do you judge whether information is trustworthy today?

Speaking Practice Prompts:

How do you decide what is true?

What makes information reliable?

How do you verify facts?

What challenges exist in finding truth?

How do you respond to misinformation?

Lesson 99: Intellectual Responsibility

Grammar Focus: Mixed conditionals #8

Warm-up Prompt:

If you had ignored evidence before, how might your views differ now?

Speaking Practice Prompts:

If you had ignored facts before, where would you be now?

What does intellectual responsibility mean to you?

How do you engage responsibly with information?

What happens when evidence is dismissed?

How do you maintain intellectual integrity?

Lesson 100: Shaping the Future Through Ideas

Grammar Focus: Future-facing perfect/mixed #10

Warm-up Prompt:

How will your ideas have influenced others by 2035?

Speaking Practice Prompts:

How will your ideas have influenced others by 2035?

What ideas do you want to contribute to society?

How do ideas shape the future?

What impact do you hope to make?

How do you participate in future-oriented thinking?

---

## Notes

- **Warm-up prompts** are single questions designed to introduce the topic and get students thinking
- **Speaking practice prompts** (5 per lesson) provide varied practice on the lesson topic
- All prompts are designed for C1 level students and encourage personal reflection and critical thinking
- Prompts align with the grammar focus of each lesson to provide natural practice opportunities
