-- =========================================
-- Pre-fill Database with Sample Lesson Data
-- B1-L24: Mental Health Awareness
-- =========================================

DELETE FROM grammar_sentences WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'B1-L24');
DELETE FROM vocabulary_items WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'B1-L24');
DELETE FROM lesson_activities WHERE lesson_id = 'B1-L24';
DELETE FROM lessons WHERE id = 'B1-L24';

INSERT INTO lessons (id, level, lesson_number, topic) VALUES
('B1-L24', 'B1', 24, 'Mental Health Awareness')
ON CONFLICT (id) DO UPDATE SET topic = EXCLUDED.topic;

DO $$
DECLARE
    lesson_id_var TEXT := 'B1-L24';
    activity_id_var UUID;
BEGIN
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'warm_up_speaking', 1, 'Staying Balanced', 'Talk about stress and support', '{"prompt": "Who do you actually talk to when stressed?"}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_intro', 2, 'Mental Health Words', 'Learn vocabulary about mental health awareness', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'mood', 'อารมณ์', NULL),
    (activity_id_var, 'support', 'การสนับสนุน', NULL),
    (activity_id_var, 'counselor', 'ที่ปรึกษา', NULL),
    (activity_id_var, 'overwhelm', 'ทำให้หนักใจ', NULL),
    (activity_id_var, 'calm', 'สงบ', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_matching_drag', 3, 'Match Mental Health Words', 'Match words with meanings', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'mood', 'อารมณ์', NULL),
    (activity_id_var, 'support', 'การสนับสนุน', NULL),
    (activity_id_var, 'counselor', 'ที่ปรึกษา', NULL),
    (activity_id_var, 'overwhelm', 'ทำให้หนักใจ', NULL),
    (activity_id_var, 'calm', 'สงบ', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 4, 'Complete the Sentences 1', 'Fill with the correct word', '{"text": "My ___ shifts during exams. I look for ___. Talking to a ___ helps.", "blanks": [{"id": "blank1", "text": "mood", "options": ["mood", "support", "counselor", "calm"], "correctAnswer": "mood"}, {"id": "blank2", "text": "support", "options": ["support", "overwhelm", "counselor", "calm"], "correctAnswer": "support"}, {"id": "blank3", "text": "counselor", "options": ["counselor", "support", "mood", "calm"], "correctAnswer": "counselor"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 5, 'Complete the Sentences 2', 'Fill with the correct word', '{"text": "Too many tasks can ___. Slow breathing can ___. Simple routines keep me ___.", "blanks": [{"id": "blank1", "text": "overwhelm", "options": ["overwhelm", "support", "calm", "mood"], "correctAnswer": "overwhelm"}, {"id": "blank2", "text": "calm", "options": ["calm", "overwhelm", "support", "counselor"], "correctAnswer": "calm"}, {"id": "blank3", "text": "calm", "options": ["calm", "mood", "overwhelm", "support"], "correctAnswer": "calm"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    -- Grammar Explanation: So / Such for emphasis
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_explanation', 6, 'So / Such for Emphasis', 'Use so + adjective; such a/an + adjective + noun to emphasize feelings or situations', '{"rules": "Use so + adjective: so stressed, so calm. Use such a/an + adjective + noun: such a heavy week. Do not overuse; keep natural.\\n- It was such a busy day.\\n- I felt so calm after the walk.", "examples": ["It was such a heavy week for me.", "I felt so calm after talking to a friend.", "She had such a supportive counselor.", "He was so overwhelmed by tasks.", "We had such a calming routine last month."]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 7, 'Build Sentences 1', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'It was such a heavy week for me', 'It was such a heavy week for me', '["It", "was", "such", "a", "heavy", "week", "for", "me"]'::jsonb),
    (activity_id_var, 'I felt so calm after talking to a friend', 'I felt so calm after talking to a friend', '["I", "felt", "so", "calm", "after", "talking", "to", "a", "friend"]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 8, 'Build Sentences 2', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'She had such a supportive counselor', 'She had such a supportive counselor', '["She", "had", "such", "a", "supportive", "counselor"]'::jsonb),
    (activity_id_var, 'He was so overwhelmed by tasks', 'He was so overwhelmed by tasks', '["He", "was", "so", "overwhelmed", "by", "tasks"]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'speaking_practice', 9, 'Talk About Mental Health', 'Practice talking about mental health awareness', '{"prompts": ["Who do you actually talk to when stressed?", "Describe a routine that calms you down.", "What signs show you need a break?"]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (
      lesson_id,
      activity_type,
      activity_order,
      title,
      description,
      content
    ) VALUES (
      'B1-L24',
      'speaking_improvement',
      10,
      'Speaking Improvement',
      'Read the improved version of your speech',
      '{"type": "speaking_improvement", "similarityThreshold": 70}'::jsonb
    );
END $$;

