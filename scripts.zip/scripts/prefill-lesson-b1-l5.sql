-- =========================================
-- Pre-fill Database with Sample Lesson Data
-- B1-L5: Relationships
-- =========================================

-- Clear existing sample data for B1-L5 (optional - comment out if you want to keep existing data)
DELETE FROM grammar_sentences WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'B1-L5');
DELETE FROM vocabulary_items WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'B1-L5');
DELETE FROM lesson_activities WHERE lesson_id = 'B1-L5';
DELETE FROM lessons WHERE id = 'B1-L5';

INSERT INTO lessons (id, level, lesson_number, topic) VALUES
('B1-L5', 'B1', 5, 'Relationships')
ON CONFLICT (id) DO UPDATE SET topic = EXCLUDED.topic;

DO $$
DECLARE
    lesson_id_var TEXT := 'B1-L5';
    activity_id_var UUID;
BEGIN
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content) VALUES (lesson_id_var, 'warm_up_speaking', 1, 'Relationships', 'Talk about relationships', '{"prompt": "What makes a good relationship?"}'::jsonb) RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content) VALUES (lesson_id_var, 'vocabulary_intro', 2, 'Relationship Words', 'Learn relationship vocabulary', '{}'::jsonb) RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'trust', 'ความไว้วางใจ', NULL),
    (activity_id_var, 'respect', 'ความเคารพ', NULL),
    (activity_id_var, 'communication', 'การสื่อสาร', NULL),
    (activity_id_var, 'support', 'การสนับสนุน', NULL),
    (activity_id_var, 'conflict', 'ความขัดแย้ง', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content) VALUES (lesson_id_var, 'vocabulary_matching_drag', 3, 'Match Relationship Words', 'Match English words with Thai meanings', '{}'::jsonb) RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'trust', 'ความไว้วางใจ', NULL),
    (activity_id_var, 'respect', 'ความเคารพ', NULL),
    (activity_id_var, 'communication', 'การสื่อสาร', NULL),
    (activity_id_var, 'support', 'การสนับสนุน', NULL),
    (activity_id_var, 'conflict', 'ความขัดแย้ง', NULL);

    -- 4. Vocabulary Fill Blanks #1 (4 words: trust, respect, communication, support - conflict left out)
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content) VALUES (lesson_id_var, 'vocabulary_fill_blanks', 4, 'Complete the Sentences 1', 'Fill in the blanks with correct words', '{"text": "We have ___ in each other. We show ___ for different opinions. Good ___ is key to understanding. We give each other ___ during difficult times.", "blanks": [{"id": "blank1", "text": "trust", "options": ["trust", "respect", "communication", "support"], "correctAnswer": "trust"}, {"id": "blank2", "text": "respect", "options": ["trust", "respect", "communication", "support"], "correctAnswer": "respect"}, {"id": "blank3", "text": "communication", "options": ["trust", "respect", "communication", "support"], "correctAnswer": "communication"}, {"id": "blank4", "text": "support", "options": ["trust", "respect", "communication", "support"], "correctAnswer": "support"}]}'::jsonb) RETURNING id INTO activity_id_var;

    -- 4. Vocabulary Fill Blanks #2 (4 words: trust, respect, communication, conflict - support left out)
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content) VALUES (lesson_id_var, 'vocabulary_fill_blanks', 5, 'Complete the Sentences 2', 'Fill in the blanks with correct words', '{"text": "We built ___ over many years. We have ___ for each other''s feelings. We talk about problems through open ___. We solve ___ by listening and compromising.", "blanks": [{"id": "blank1", "text": "trust", "options": ["trust", "respect", "communication", "conflict"], "correctAnswer": "trust"}, {"id": "blank2", "text": "respect", "options": ["trust", "respect", "communication", "conflict"], "correctAnswer": "respect"}, {"id": "blank3", "text": "communication", "options": ["trust", "respect", "communication", "conflict"], "correctAnswer": "communication"}, {"id": "blank4", "text": "conflict", "options": ["trust", "respect", "communication", "conflict"], "correctAnswer": "conflict"}]}'::jsonb) RETURNING id INTO activity_id_var;

    -- 4. Grammar Explanation (5 examples - CEFR B1: Present perfect, expressing opinions)
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content) VALUES (lesson_id_var, 'grammar_explanation', 6, 'Present Perfect - Relationships', 'Learn to talk about relationships', '{"rules": "Use present perfect for relationship experiences:\n\n- I have known + person + for/since (I have known her for 5 years)\n- We have been + relationship + for/since (We have been friends since 2020)\n- Express opinions: I think/believe/feel that...\n- Use ''for'' with periods, ''since'' with points in time\n- Use past simple for specific past events", "examples": ["I have known my best friend for ten years.", "We have been together since 2019.", "I think trust is very important.", "We have always supported each other.", "They have never had a serious conflict."]}'::jsonb) RETURNING id INTO activity_id_var;
    -- 4. Grammar Sentences #1
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content) VALUES (lesson_id_var, 'grammar_sentences', 7, 'Build Sentences 1', 'Arrange words to make sentences', '{}'::jsonb) RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'I have known my best friend for ten years', 'I have known my best friend for ten years', '["I", "have", "known", "my", "best", "friend", "for", "ten", "years"]'::jsonb),
    (activity_id_var, 'We have been together since two thousand nineteen', 'We have been together since 2019', '["We", "have", "been", "together", "since", "2019"]'::jsonb);
    -- 4. Grammar Sentences #2
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content) VALUES (lesson_id_var, 'grammar_sentences', 8, 'Build Sentences 2', 'Arrange words to make sentences', '{}'::jsonb) RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'I think trust is very important', 'I think trust is very important', '["I", "think", "trust", "is", "very", "important"]'::jsonb),
    (activity_id_var, 'We have always supported each other', 'We have always supported each other', '["We", "have", "always", "supported", "each", "other"]'::jsonb);
    -- 4. Speaking Practice (5 prompts - CEFR B1: Relationships)
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content) VALUES (lesson_id_var, 'speaking_practice', 9, 'Talk About Relationships', 'Practice talking about relationships', '{"prompts": ["What makes a good relationship?", "How long have you known your best friend?", "What is the most important quality in a relationship?", "How do you handle conflicts in relationships?", "What role does communication play in your relationships?"]}'::jsonb) RETURNING id INTO activity_id_var;

END $$;
INSERT INTO lesson_activities (
  lesson_id,
  activity_type,
  activity_order,
  title,
  description,
  content
) VALUES (
  'B1-L5',
  'speaking_improvement',
  10,
  'Speaking Improvement',
  'Read the improved version of your speech',
  '{"type": "speaking_improvement", "similarityThreshold": 70}'::jsonb
);