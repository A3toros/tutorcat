-- =========================================
-- Pre-fill Database with Sample Lesson Data
-- B1-L6: Entertainment & Media
-- =========================================

-- Clear existing sample data for B1-L6 (optional - comment out if you want to keep existing data)
DELETE FROM grammar_sentences WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'B1-L6');
DELETE FROM vocabulary_items WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'B1-L6');
DELETE FROM lesson_activities WHERE lesson_id = 'B1-L6';
DELETE FROM lessons WHERE id = 'B1-L6';

INSERT INTO lessons (id, level, lesson_number, topic) VALUES
('B1-L6', 'B1', 6, 'Entertainment & Media')
ON CONFLICT (id) DO UPDATE SET topic = EXCLUDED.topic;

DO $$
DECLARE
    lesson_id_var TEXT := 'B1-L6';
    activity_id_var UUID;
BEGIN
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content) VALUES (lesson_id_var, 'warm_up_speaking', 1, 'Entertainment', 'Talk about entertainment', '{"prompt": "What is your favorite form of entertainment?"}'::jsonb) RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content) VALUES (lesson_id_var, 'vocabulary_intro', 2, 'Media Words', 'Learn entertainment vocabulary', '{}'::jsonb) RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'movie', 'ภาพยนตร์', NULL),
    (activity_id_var, 'series', 'ซีรีส์', NULL),
    (activity_id_var, 'podcast', 'พอดคาสต์', NULL),
    (activity_id_var, 'streaming', 'สตรีมมิ่ง', NULL),
    (activity_id_var, 'review', 'รีวิว', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content) VALUES (lesson_id_var, 'vocabulary_matching_drag', 3, 'Match Media Words', 'Match English words with Thai meanings', '{}'::jsonb) RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'movie', 'ภาพยนตร์', NULL),
    (activity_id_var, 'series', 'ซีรีส์', NULL),
    (activity_id_var, 'podcast', 'พอดคาสต์', NULL),
    (activity_id_var, 'streaming', 'สตรีมมิ่ง', NULL),
    (activity_id_var, 'review', 'รีวิว', NULL);

    -- 4. Vocabulary Fill Blanks #1 (4 words: movie, series, podcast, streaming - review left out)
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content) VALUES (lesson_id_var, 'vocabulary_fill_blanks', 4, 'Complete the Sentences 1', 'Fill in the blanks with correct words', '{"text": "I watched a great ___. I love this ___. I listen to a ___. I use ___ services.", "blanks": [{"id": "blank1", "text": "movie", "options": ["movie", "series", "podcast", "streaming"], "correctAnswer": "movie"}, {"id": "blank2", "text": "series", "options": ["movie", "series", "podcast", "streaming"], "correctAnswer": "series"}, {"id": "blank3", "text": "podcast", "options": ["movie", "series", "podcast", "streaming"], "correctAnswer": "podcast"}, {"id": "blank4", "text": "streaming", "options": ["movie", "series", "podcast", "streaming"], "correctAnswer": "streaming"}]}'::jsonb) RETURNING id INTO activity_id_var;

    -- 4. Vocabulary Fill Blanks #2 (4 words: movie, series, podcast, review - streaming left out)
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content) VALUES (lesson_id_var, 'vocabulary_fill_blanks', 5, 'Complete the Sentences 2', 'Fill in the blanks with correct words', '{"text": "The ___ was amazing. The ___ is interesting. I heard a ___. I read a good ___.", "blanks": [{"id": "blank1", "text": "movie", "options": ["movie", "series", "podcast", "review"], "correctAnswer": "movie"}, {"id": "blank2", "text": "series", "options": ["movie", "series", "podcast", "review"], "correctAnswer": "series"}, {"id": "blank3", "text": "podcast", "options": ["movie", "series", "podcast", "review"], "correctAnswer": "podcast"}, {"id": "blank4", "text": "review", "options": ["movie", "series", "podcast", "review"], "correctAnswer": "review"}]}'::jsonb) RETURNING id INTO activity_id_var;

    -- 4. Grammar Explanation (5 examples - CEFR B1: Present perfect, expressing preferences)
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content) VALUES (lesson_id_var, 'grammar_explanation', 6, 'Present Perfect - Entertainment', 'Learn to talk about entertainment', '{"rules": "Use present perfect for entertainment experiences:\n\n- I have watched/seen + noun (I have watched many movies)\n- I have listened to + noun (I have listened to podcasts)\n- Express preferences: I prefer/enjoy/love + verb-ing\n- Use ''recently'' and ''lately'' with present perfect\n- Use past simple for specific times (I watched it yesterday)", "examples": ["I have watched many movies this year.", "I have been listening to podcasts lately.", "I prefer watching series to movies.", "I have never seen that show.", "I enjoyed the movie we watched last week."]}'::jsonb) RETURNING id INTO activity_id_var;

    -- 4. Grammar Sentences #1
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content) VALUES (lesson_id_var, 'grammar_sentences', 7, 'Build Sentences 1', 'Arrange words to make sentences', '{}'::jsonb) RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'I have watched many movies this year', 'I have watched many movies this year', '["I", "have", "watched", "many", "movies", "this", "year"]'::jsonb),
    (activity_id_var, 'I have been listening to podcasts lately', 'I have been listening to podcasts lately', '["I", "have", "been", "listening", "to", "podcasts", "lately"]'::jsonb);
    -- 4. Grammar Sentences #2
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content) VALUES (lesson_id_var, 'grammar_sentences', 8, 'Build Sentences 2', 'Arrange words to make sentences', '{}'::jsonb) RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'I prefer watching series to movies', 'I prefer watching series to movies', '["I", "prefer", "watching", "series", "to", "movies"]'::jsonb),
    (activity_id_var, 'I have never seen that show', 'I have never seen that show', '["I", "have", "never", "seen", "that", "show"]'::jsonb);
    -- 4. Speaking Practice (5 prompts - CEFR B1: Entertainment and media)
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content) VALUES (lesson_id_var, 'speaking_practice', 9, 'Talk About Entertainment', 'Practice talking about media', '{"prompts": ["What is your favorite form of entertainment?", "What movies or series have you watched recently?", "Do you prefer streaming or going to the cinema?", "What podcasts do you listen to?", "How do you choose what to watch?"]}'::jsonb) RETURNING id INTO activity_id_var;

END $$;
INSERT INTO lesson_activities (
  lesson_id,
  activity_type,
  activity_order,
  title,
  description,
  content
) VALUES (
  'B1-L6',
  'speaking_improvement',
  10,
  'Speaking Improvement',
  'Read the improved version of your speech',
  '{"type": "speaking_improvement", "similarityThreshold": 70}'::jsonb
);