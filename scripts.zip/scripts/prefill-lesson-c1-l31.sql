-- =========================================
-- Pre-fill Database with Sample Lesson Data
-- C1-L31: Cultural Identity in a Globalized World
-- =========================================
DELETE FROM lesson_activity_results WHERE lesson_id = 'C1-L31';
DELETE FROM user_progress WHERE lesson_id = 'C1-L31';
DELETE FROM lesson_history WHERE lesson_id = 'C1-L31';
DELETE FROM grammar_sentences WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'C1-L31');
DELETE FROM vocabulary_items WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'C1-L31');
DELETE FROM lesson_activities WHERE lesson_id = 'C1-L31';
DELETE FROM lessons WHERE id = 'C1-L31';

INSERT INTO lessons (id, level, lesson_number, topic) VALUES
('C1-L31', 'C1', 31, 'Cultural Identity in a Globalized World')
ON CONFLICT (id) DO UPDATE SET topic = EXCLUDED.topic;

DO $$
DECLARE
    lesson_id_var TEXT := 'C1-L31';
    activity_id_var UUID;
BEGIN
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'warm_up_speaking', 1, 'Cultural Identity', 'Discuss cultural identity', '{"prompt": "How do you balance identity and adaptation?"}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_intro', 2, 'Cultural Identity Vocabulary', 'Learn vocabulary about cultural identity', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'identity', 'ตัวตน', NULL),
    (activity_id_var, 'globalization', 'โลกาภิวัตน์', NULL),
    (activity_id_var, 'tradition', 'ประเพณี', NULL),
    (activity_id_var, 'adaptation', 'การปรับตัว', NULL),
    (activity_id_var, 'heritage', 'มรดก', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_matching_drag', 3, 'Match Cultural Identity Words', 'Match English words with Thai meanings', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'identity', 'ตัวตน', NULL),
    (activity_id_var, 'globalization', 'โลกาภิวัตน์', NULL),
    (activity_id_var, 'tradition', 'ประเพณี', NULL),
    (activity_id_var, 'adaptation', 'การปรับตัว', NULL),
    (activity_id_var, 'heritage', 'มรดก', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 4, 'Complete the Sentences 1', 'Fill with the correct word', '{"text": "Cultural ___ faces challenges from ___. Preserving ___ requires ___.", "blanks": [{"id": "blank1", "text": "identity", "options": ["identity", "globalization", "tradition", "adaptation"], "correctAnswer": "identity"}, {"id": "blank2", "text": "globalization", "options": ["globalization", "identity", "tradition", "heritage"], "correctAnswer": "globalization"}, {"id": "blank3", "text": "heritage", "options": ["heritage", "identity", "tradition", "adaptation"], "correctAnswer": "heritage"}, {"id": "blank4", "text": "adaptation", "options": ["adaptation", "identity", "tradition", "globalization"], "correctAnswer": "adaptation"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 5, 'Complete the Sentences 2', 'Fill with the correct word', '{"text": "Traditional ___ connect to ___. Successful ___ maintains ___.", "blanks": [{"id": "blank1", "text": "traditions", "options": ["traditions", "identity", "globalization", "adaptation"], "correctAnswer": "traditions"}, {"id": "blank2", "text": "heritage", "options": ["heritage", "identity", "tradition", "adaptation"], "correctAnswer": "heritage"}, {"id": "blank3", "text": "adaptation", "options": ["adaptation", "identity", "tradition", "globalization"], "correctAnswer": "adaptation"}, {"id": "blank4", "text": "identity", "options": ["identity", "tradition", "globalization", "heritage"], "correctAnswer": "identity"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_explanation', 6, 'Participle Clauses', 'Learn participle clauses', '{"rules": "Participle clauses:\n- Present participle (-ing): \"Balancing identity, people adapt.\"\n- Past participle (-ed): \"Influenced by globalization, cultures change.\"\n- Perfect participle (having + past participle): \"Having preserved traditions, they maintain identity.\"\n\nUse for:\n- Showing simultaneous actions: \"Balancing identity, you adapt to change.\"\n- Showing cause: \"Influenced by globalization, people modify traditions.\"\n- Showing time sequence: \"Having kept traditions, they preserve heritage.\"", "examples": ["Balancing identity and adaptation, people navigate globalization.", "Influenced by globalization, cultures evolve while maintaining heritage.", "Having preserved traditions, communities maintain cultural identity.", "Adapting to change, people keep their heritage alive.", "Shaped by both tradition and globalization, identity evolves."]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 7, 'Build Sentences 1', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'Balancing identity and adaptation, people navigate globalization.', 'Balancing identity and adaptation, people navigate globalization.', '["Balancing", "identity", "and", "adaptation,", "people", "navigate", "globalization."]'::jsonb),
    (activity_id_var, 'Influenced by globalization, cultures evolve while maintaining heritage.', 'Influenced by globalization, cultures evolve while maintaining heritage.', '["Influenced", "by", "globalization,", "cultures", "evolve", "while", "maintaining", "heritage."]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 8, 'Build Sentences 2', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'Having preserved traditions, communities maintain cultural identity.', 'Having preserved traditions, communities maintain cultural identity.', '["Having", "preserved", "traditions,", "communities", "maintain", "cultural", "identity."]'::jsonb),
    (activity_id_var, 'Adapting to change, people keep their heritage alive.', 'Adapting to change, people keep their heritage alive.', '["Adapting", "to", "change,", "people", "keep", "their", "heritage", "alive."]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'speaking_practice', 9, 'Discuss Cultural Identity', 'Practice speaking about cultural identity', '{"prompts": ["What defines your cultural identity?", "How has globalization affected it?", "What traditions do you keep?", "What changes have you accepted?", "How do you adapt without losing identity?"]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (
      lesson_id,
      activity_type,
      activity_order,
      title,
      description,
      content
    ) VALUES (
      'C1-L31',
      'speaking_improvement',
      10,
      'Speaking Improvement',
      'Read the improved version of your speech',
      '{"type": "speaking_improvement", "similarityThreshold": 70}'::jsonb
    );
END $$;
