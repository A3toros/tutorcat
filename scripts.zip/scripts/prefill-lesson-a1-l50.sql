-- ===== LESSON A1-L50 =====

-- =========================================
-- Pre-fill Database with Sample Lesson Data
-- A1-L50: Money (coins and notes)
-- =========================================

DELETE FROM grammar_sentences WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'A1-L50');
DELETE FROM vocabulary_items WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'A1-L50');
DELETE FROM lesson_activities WHERE lesson_id = 'A1-L50';
DELETE FROM lessons WHERE id = 'A1-L50';

INSERT INTO lessons (id, level, lesson_number, topic) VALUES
('A1-L50', 'A1', 50, 'Money (coins and notes)')
ON CONFLICT (id) DO UPDATE SET topic = EXCLUDED.topic;

DO $$
DECLARE
    lesson_id_var TEXT := 'A1-L50';
    activity_id_var UUID;
BEGIN
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'warm_up_speaking', 1, 'How much?', 'Talk about money and prices', '{"prompt": "How much is this?"}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_intro', 2, 'Money Words', 'Learn money words', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'coin', 'เหรียญ', NULL),
    (activity_id_var, 'note', 'ธนบัตร', NULL),
    (activity_id_var, 'dollar', 'ดอลลาร์', NULL),
    (activity_id_var, 'baht', 'บาท', NULL),
    (activity_id_var, 'pay', 'จ่าย', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_matching_drag', 3, 'Match Money Words', 'Match money words', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'coin', 'เหรียญ', NULL),
    (activity_id_var, 'note', 'ธนบัตร', NULL),
    (activity_id_var, 'dollar', 'ดอลลาร์', NULL),
    (activity_id_var, 'baht', 'บาท', NULL),
    (activity_id_var, 'pay', 'จ่าย', NULL);

    -- 4. Vocabulary Fill Blanks #1
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 4, 'Complete the Sentences 1', 'Fill in the blanks with correct words', '{"text": "I have a ___. I have a ___. I ___ with money.", "blanks": [{"id": "blank1", "text": "coin", "options": ["coin", "note", "dollar", "baht"], "correctAnswer": "coin"}, {"id": "blank2", "text": "note", "options": ["note", "coin", "dollar", "baht"], "correctAnswer": "note"}, {"id": "blank3", "text": "pay", "options": ["pay", "coin", "note", "dollar"], "correctAnswer": "pay"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    -- 5. Vocabulary Fill Blanks #2
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 5, 'Complete the Sentences 2', 'Fill in the blanks with correct words', '{"text": "This costs 10 ___. I have 5 ___. She pays with ___.", "blanks": [{"id": "blank1", "text": "baht", "options": ["baht", "dollar", "coin", "note"], "correctAnswer": "baht"}, {"id": "blank2", "text": "coins", "options": ["coins", "notes", "dollars", "baht"], "correctAnswer": "coins"}, {"id": "blank3", "text": "notes", "options": ["notes", "coins", "dollars", "baht"], "correctAnswer": "notes"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    -- 6. Grammar Explanation
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_explanation', 6, 'Numbers + Prices', 'Learn numbers with prices', '{"rules": "Use numbers with money words:\n\n- This costs + number + money (This costs 10 baht)\n- I have + number + coins/notes (I have 5 coins)\n- Pay with + money (She pays with notes)\n- Use plural for coins/notes when counting", "examples": ["This costs 10 baht.", "I have 5 coins.", "She pays with notes.", "It costs 20 dollars.", "We have 3 notes."]}'::jsonb)
    RETURNING id INTO activity_id_var;

    -- 7. Grammar Sentences #1
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 7, 'Build Sentences 1', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'This costs 10 baht', 'This costs 10 baht.', '["This", "costs", "10", "baht."]'::jsonb),
    (activity_id_var, 'I have 5 coins', 'I have 5 coins.', '["I", "have", "5", "coins."]'::jsonb);

    -- 8. Grammar Sentences #2
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 8, 'Build Sentences 2', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'She pays with notes', 'She pays with notes.', '["She", "pays", "with", "notes."]'::jsonb),
    (activity_id_var, 'It costs 20 dollars', 'It costs 20 dollars.', '["It", "costs", "20", "dollars."]'::jsonb);

    -- 9. Speaking Practice
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'speaking_practice', 9, 'Talk About Money', 'Practice talking about money', '{"prompts": ["How much is your lunch?", "Do you save money?", "What do you buy with coins?", "How much money do you have?", "Do you use coins or notes?"]}'::jsonb)
    RETURNING id INTO activity_id_var;

    -- 10. Speaking Improvement
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'speaking_improvement', 10, 'Speaking Improvement', 'Read the improved version of your speech', '{"type": "speaking_improvement", "similarityThreshold": 70}'::jsonb)
    RETURNING id INTO activity_id_var;
END $$;


-- ===== B1 MISSING LESSONS 61-70 =====