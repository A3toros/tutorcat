-- =========================================
-- Pre-fill Database with Sample Lesson Data
-- C1-L27: Social Media and Public Opinion
-- =========================================
DELETE FROM lesson_activity_results WHERE lesson_id = 'C1-L27';
DELETE FROM user_progress WHERE lesson_id = 'C1-L27';
DELETE FROM lesson_history WHERE lesson_id = 'C1-L27';
DELETE FROM grammar_sentences WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'C1-L27');
DELETE FROM vocabulary_items WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'C1-L27');
DELETE FROM lesson_activities WHERE lesson_id = 'C1-L27';
DELETE FROM lessons WHERE id = 'C1-L27';

INSERT INTO lessons (id, level, lesson_number, topic) VALUES
('C1-L27', 'C1', 27, 'Social Media and Public Opinion')
ON CONFLICT (id) DO UPDATE SET topic = EXCLUDED.topic;

DO $$
DECLARE
    lesson_id_var TEXT := 'C1-L27';
    activity_id_var UUID;
BEGIN
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'warm_up_speaking', 1, 'Social Media and Opinion', 'Discuss social media and public opinion', '{"prompt": "How does social media shape opinions?"}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_intro', 2, 'Social Media Vocabulary', 'Learn vocabulary about social media', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'influence', 'อิทธิพล', NULL),
    (activity_id_var, 'platform', 'แพลตฟอร์ม', NULL),
    (activity_id_var, 'controversy', 'ข้อโต้แย้ง', NULL),
    (activity_id_var, 'trend', 'เทรนด์', NULL),
    (activity_id_var, 'image', 'ภาพลักษณ์', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_matching_drag', 3, 'Match Social Media Words', 'Match English words with Thai meanings', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'influence', 'อิทธิพล', NULL),
    (activity_id_var, 'platform', 'แพลตฟอร์ม', NULL),
    (activity_id_var, 'controversy', 'ข้อโต้แย้ง', NULL),
    (activity_id_var, 'trend', 'เทรนด์', NULL),
    (activity_id_var, 'image', 'ภาพลักษณ์', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 4, 'Complete the Sentences 1', 'Fill with the correct word', '{"text": "Social media ___ public views. Different ___ require different approaches.", "blanks": [{"id": "blank1", "text": "influences", "options": ["influences", "platform", "controversy", "trend"], "correctAnswer": "influences"}, {"id": "blank2", "text": "platforms", "options": ["platforms", "influence", "controversy", "trend"], "correctAnswer": "platforms"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 5, 'Complete the Sentences 2', 'Fill with the correct word', '{"text": "Posts create ___. Online ___ spread rapidly. Managing digital ___ is important.", "blanks": [{"id": "blank1", "text": "controversy", "options": ["controversy", "influence", "platform", "trend"], "correctAnswer": "controversy"}, {"id": "blank2", "text": "trends", "options": ["trends", "influence", "controversy", "platform"], "correctAnswer": "trends"}, {"id": "blank3", "text": "image", "options": ["image", "influence", "controversy", "trend"], "correctAnswer": "image"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_explanation', 6, 'Cohesive Transformations', 'Learn cohesive transformations', '{"rules": "Cohesive transformations:\n- Substitution: \"Social media influences views, and so do posts.\"\n- Ellipsis: \"Posts influence views, and trends do too.\"\n- Reference: \"Platforms shape opinions; this affects society.\"\n- Lexical cohesion: \"Posts influence views; such influence matters.\"\n\nUse for:\n- Avoiding repetition: \"Posts shape opinions; so do videos.\"\n- Creating flow: \"Platforms influence views; this impact is significant.\"\n- Connecting ideas: \"Social media shapes opinions; such influence spreads quickly.\"", "examples": ["Posts influence public views, and videos do too.", "Platforms shape opinions; this impact is significant.", "Social media affects beliefs; such influence spreads quickly.", "Trends emerge online; these trends shape culture.", "Controversy arises; such controversy affects reputation."]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 7, 'Build Sentences 1', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'Posts influence public views, and videos do too.', 'Posts influence public views, and videos do too.', '["Posts", "influence", "public", "views,", "and", "videos", "do", "too."]'::jsonb),
    (activity_id_var, 'Platforms shape opinions; this impact is significant.', 'Platforms shape opinions; this impact is significant.', '["Platforms", "shape", "opinions;", "this", "impact", "is", "significant."]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 8, 'Build Sentences 2', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'Social media affects beliefs; such influence spreads quickly.', 'Social media affects beliefs; such influence spreads quickly.', '["Social", "media", "affects", "beliefs;", "such", "influence", "spreads", "quickly."]'::jsonb),
    (activity_id_var, 'Trends emerge online; these trends shape culture.', 'Trends emerge online; these trends shape culture.', '["Trends", "emerge", "online;", "these", "trends", "shape", "culture."]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'speaking_practice', 9, 'Discuss Social Media', 'Practice speaking about social media', '{"prompts": ["How do posts influence public views?", "How do you adapt messages for different platforms?", "What posts have caused controversy?", "How do trends spread online?", "How do you manage your digital image?"]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (
      lesson_id,
      activity_type,
      activity_order,
      title,
      description,
      content
    ) VALUES (
      'C1-L27',
      'speaking_improvement',
      10,
      'Speaking Improvement',
      'Read the improved version of your speech',
      '{"type": "speaking_improvement", "similarityThreshold": 70}'::jsonb
    );
END $$;
