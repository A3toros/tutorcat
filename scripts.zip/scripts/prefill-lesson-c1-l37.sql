-- =========================================
-- Pre-fill Database with Sample Lesson Data
-- C1-L37: Cross-cultural Misunderstandings
-- =========================================
DELETE FROM lesson_activity_results WHERE lesson_id = 'C1-L37';
DELETE FROM user_progress WHERE lesson_id = 'C1-L37';
DELETE FROM lesson_history WHERE lesson_id = 'C1-L37';
DELETE FROM grammar_sentences WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'C1-L37');
DELETE FROM vocabulary_items WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'C1-L37');
DELETE FROM lesson_activities WHERE lesson_id = 'C1-L37';
DELETE FROM lessons WHERE id = 'C1-L37';

INSERT INTO lessons (id, level, lesson_number, topic) VALUES
('C1-L37', 'C1', 37, 'Cross-cultural Misunderstandings')
ON CONFLICT (id) DO UPDATE SET topic = EXCLUDED.topic;

DO $$
DECLARE
    lesson_id_var TEXT := 'C1-L37';
    activity_id_var UUID;
BEGIN
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'warm_up_speaking', 1, 'Cross-cultural Misunderstandings', 'Discuss cross-cultural misunderstandings', '{"prompt": "What misunderstandings arise across cultures?"}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_intro', 2, 'Misunderstanding Vocabulary', 'Learn vocabulary about misunderstandings', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'misunderstanding', 'ความเข้าใจผิด', NULL),
    (activity_id_var, 'conflict', 'ความขัดแย้ง', NULL),
    (activity_id_var, 'prevention', 'การป้องกัน', NULL),
    (activity_id_var, 'norm', 'บรรทัดฐาน', NULL),
    (activity_id_var, 'mistake', 'ข้อผิดพลาด', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_matching_drag', 3, 'Match Misunderstanding Words', 'Match English words with Thai meanings', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'misunderstanding', 'ความเข้าใจผิด', NULL),
    (activity_id_var, 'conflict', 'ความขัดแย้ง', NULL),
    (activity_id_var, 'prevention', 'การป้องกัน', NULL),
    (activity_id_var, 'norm', 'บรรทัดฐาน', NULL),
    (activity_id_var, 'mistake', 'ข้อผิดพลาด', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 4, 'Complete the Sentences 1', 'Fill with the correct word', '{"text": "Cultural ___ lead to ___. Understanding ___ helps ___.", "blanks": [{"id": "blank1", "text": "misunderstandings", "options": ["misunderstandings", "conflict", "prevention", "norm"], "correctAnswer": "misunderstandings"}, {"id": "blank2", "text": "conflict", "options": ["conflict", "misunderstanding", "prevention", "mistake"], "correctAnswer": "conflict"}, {"id": "blank3", "text": "norms", "options": ["norms", "misunderstanding", "conflict", "prevention"], "correctAnswer": "norms"}, {"id": "blank4", "text": "prevention", "options": ["prevention", "misunderstanding", "conflict", "norm"], "correctAnswer": "prevention"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 5, 'Complete the Sentences 2', 'Fill with the correct word', '{"text": "Learning from ___ improves understanding. Cultural ___ prevent ___.", "blanks": [{"id": "blank1", "text": "mistakes", "options": ["mistakes", "misunderstanding", "conflict", "norm"], "correctAnswer": "mistakes"}, {"id": "blank2", "text": "norms", "options": ["norms", "misunderstanding", "conflict", "prevention"], "correctAnswer": "norms"}, {"id": "blank3", "text": "conflict", "options": ["conflict", "misunderstanding", "norm", "mistake"], "correctAnswer": "conflict"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_explanation', 6, 'Mixed Conditionals', 'Learn mixed conditional structures', '{"rules": "Mixed conditionals combine different time references:\n- Mixed 2/3: \"If I had known the norm (past), I would act differently now (present).\"\n- Mixed 3/2: \"If I had understood (past), I would not make mistakes now (present).\"\n\nStructures:\n- If + past perfect, would + base form (past condition, present result)\n- If + past simple, would have + past participle (present condition, past result)\n\nUse for:\n- Hypothetical past affecting present: \"If I had known the norm, I would avoid conflict now.\"\n- Unreal present affecting past: \"If I were more aware, I would not have misunderstood.\"", "examples": ["If I had known the norm, I would act differently now.", "If I had understood the culture, I would avoid misunderstandings now.", "If I were more aware, I would not have made that mistake.", "If I had learned the norms earlier, I would communicate better now.", "If I had known the customs, I would not have caused conflict."]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 7, 'Build Sentences 1', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'If I had known the norm, I would act differently now.', 'If I had known the norm, I would act differently now.', '["If", "I", "had", "known", "the", "norm,", "I", "would", "act", "differently", "now."]'::jsonb),
    (activity_id_var, 'If I had understood the culture, I would avoid misunderstandings now.', 'If I had understood the culture, I would avoid misunderstandings now.', '["If", "I", "had", "understood", "the", "culture,", "I", "would", "avoid", "misunderstandings", "now."]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 8, 'Build Sentences 2', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'If I had learned the norms earlier, I would communicate better now.', 'If I had learned the norms earlier, I would communicate better now.', '["If", "I", "had", "learned", "the", "norms", "earlier,", "I", "would", "communicate", "better", "now."]'::jsonb),
    (activity_id_var, 'If I had known the customs, I would not have caused conflict.', 'If I had known the customs, I would not have caused conflict.', '["If", "I", "had", "known", "the", "customs,", "I", "would", "not", "have", "caused", "conflict."]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'speaking_practice', 9, 'Discuss Misunderstandings', 'Practice speaking about cross-cultural misunderstandings', '{"prompts": ["What cultural misunderstandings have you seen?", "How could they have been avoided?", "What helps prevent conflict?", "How do you learn cultural norms?", "How should mistakes be handled?"]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (
      lesson_id,
      activity_type,
      activity_order,
      title,
      description,
      content
    ) VALUES (
      'C1-L37',
      'speaking_improvement',
      10,
      'Speaking Improvement',
      'Read the improved version of your speech',
      '{"type": "speaking_improvement", "similarityThreshold": 70}'::jsonb
    );
END $$;
