-- =========================================
-- Pre-fill Database with Sample Lesson Data
-- A2-L16: Common Illnesses
-- =========================================

DELETE FROM grammar_sentences WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'A2-L16');
DELETE FROM vocabulary_items WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'A2-L16');
DELETE FROM lesson_activities WHERE lesson_id = 'A2-L16';
DELETE FROM lessons WHERE id = 'A2-L16';

INSERT INTO lessons (id, level, lesson_number, topic) VALUES
('A2-L16', 'A2', 16, 'Common Illnesses')
ON CONFLICT (id) DO UPDATE SET topic = EXCLUDED.topic;

DO $$
DECLARE
    lesson_id_var TEXT := 'A2-L16';
    activity_id_var UUID;
BEGIN
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'warm_up_speaking', 1, 'Feeling Sick', 'Talk about being sick', '{"prompt": "How do you feel when you have a cold or fever?"}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_intro', 2, 'Illness Words', 'Learn words about common sickness', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'cough', 'ไอ', NULL),
    (activity_id_var, 'fever', 'ไข้', NULL),
    (activity_id_var, 'cold', 'หวัด', NULL),
    (activity_id_var, 'sick', 'ป่วย', NULL),
    (activity_id_var, 'clinic', 'คลินิก', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_matching_drag', 3, 'Match Illness Words', 'Match health words', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'cough', 'ไอ', NULL),
    (activity_id_var, 'fever', 'ไข้', NULL),
    (activity_id_var, 'cold', 'หวัด', NULL),
    (activity_id_var, 'sick', 'ป่วย', NULL),
    (activity_id_var, 'clinic', 'คลินิก', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 4, 'Complete the Sentences 1', 'Fill with the correct word', '{"text": "I have a ___ and a ___. I feel ___. I will go to the ___.", "blanks": [{"id": "blank1", "text": "cough", "options": ["cough", "fever", "sick", "clinic"], "correctAnswer": "cough"}, {"id": "blank2", "text": "fever", "options": ["fever", "cough", "sick", "clinic"], "correctAnswer": "fever"}, {"id": "blank3", "text": "sick", "options": ["sick", "clinic", "fever", "cough"], "correctAnswer": "sick"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 5, 'Complete the Sentences 2', 'Fill with the correct word', '{"text": "There is a ___ near my home. Do you have a ___. She has a ___.", "blanks": [{"id": "blank1", "text": "clinic", "options": ["clinic", "cough", "fever", "cold"], "correctAnswer": "clinic"}, {"id": "blank2", "text": "cold", "options": ["cold", "fever", "clinic", "cough"], "correctAnswer": "cold"}, {"id": "blank3", "text": "fever", "options": ["fever", "cold", "clinic", "cough"], "correctAnswer": "fever"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_explanation', 6, 'There is / There are', 'Talk about places and symptoms', '{"rules": "Use there is/are to say something exists.\n- There is a clinic near my house.\n- There are two doctors inside.\nUse it for symptoms: There is a cough. There are many sick people today.", "examples": ["There is a clinic nearby.", "There are two nurses here.", "There is a long line.", "There are many people with a cold.", "There is a doctor at the front."]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 7, 'Build Sentences 1', 'Arrange words', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'There is a clinic near my house', 'There is a clinic near my house.', '["There", "is", "a", "clinic", "near", "my", "house."]'::jsonb),
    (activity_id_var, 'There are two doctors inside', 'There are two doctors inside.', '["There", "are", "two", "doctors", "inside."]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 8, 'Build Sentences 2', 'Arrange words', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'There is a long line today', 'There is a long line today.', '["There", "is", "a", "long", "line", "today."]'::jsonb),
    (activity_id_var, 'There are many people with a cold', 'There are many people with a cold.', '["There", "are", "many", "people", "with", "a", "cold."]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'speaking_practice', 9, 'Talk About Illness', 'Practice talking about feeling sick', '{"prompts": ["How do you feel when you have a cold?", "Do you see a doctor quickly when you feel sick?", "Who takes care of you when you are ill?", "What symptoms do you usually have when you are sick?", "How do you prevent getting sick?"]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (
      lesson_id,
      activity_type,
      activity_order,
      title,
      description,
      content
    ) VALUES (
      'A2-L16',
      'speaking_improvement',
      10,
      'Speaking Improvement',
      'Read the improved version of your speech',
      '{"type": "speaking_improvement", "similarityThreshold": 70}'::jsonb
    );
END $$;

