-- =========================================
-- Pre-fill Database with Sample Lesson Data
-- B1-L82: Team Projects
-- =========================================

DELETE FROM grammar_sentences WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'B1-L82');
DELETE FROM vocabulary_items WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'B1-L82');
DELETE FROM lesson_activities WHERE lesson_id = 'B1-L82';
DELETE FROM lessons WHERE id = 'B1-L82';

INSERT INTO lessons (id, level, lesson_number, topic) VALUES
('B1-L82', 'B1', 82, 'Team Projects')
ON CONFLICT (id) DO UPDATE SET topic = EXCLUDED.topic;

DO $$
DECLARE
    lesson_id_var TEXT := 'B1-L82';
    activity_id_var UUID;
BEGIN
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'warm_up_speaking', 1, 'Smooth Projects', 'Talk about keeping projects healthy', '{"prompt": "What must a team do to keep you sane?"}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_intro', 2, 'Project Words', 'Learn vocabulary about team projects', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'collaborate', 'ร่วมมือ', NULL),
    (activity_id_var, 'divide', 'แบ่ง', NULL),
    (activity_id_var, 'align', 'ทำให้ตรงกัน', NULL),
    (activity_id_var, 'review', 'ทบทวน', NULL),
    (activity_id_var, 'deliver', 'ส่งมอบ', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_matching_drag', 3, 'Match Project Words', 'Match words with meanings', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'collaborate', 'ร่วมมือ', NULL),
    (activity_id_var, 'divide', 'แบ่ง', NULL),
    (activity_id_var, 'align', 'ทำให้ตรงกัน', NULL),
    (activity_id_var, 'review', 'ทบทวน', NULL),
    (activity_id_var, 'deliver', 'ส่งมอบ', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 4, 'Complete the Sentences 1', 'Fill with the correct word', '{"text": "We must ___. We ___ tasks fairly. We ___ every week.", "blanks": [{"id": "blank1", "text": "collaborate", "options": ["collaborate", "divide", "align", "review"], "correctAnswer": "collaborate"}, {"id": "blank2", "text": "divide", "options": ["divide", "collaborate", "deliver", "review"], "correctAnswer": "divide"}, {"id": "blank3", "text": "review", "options": ["review", "align", "divide", "deliver"], "correctAnswer": "review"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 5, 'Complete the Sentences 2', 'Fill with the correct word', '{"text": "We ___ goals often. We want to ___ on time. Teams that ___ well stay calm.", "blanks": [{"id": "blank1", "text": "align", "options": ["align", "deliver", "collaborate", "divide"], "correctAnswer": "align"}, {"id": "blank2", "text": "deliver", "options": ["deliver", "align", "review", "collaborate"], "correctAnswer": "deliver"}, {"id": "blank3", "text": "collaborate", "options": ["collaborate", "review", "align", "divide"], "correctAnswer": "collaborate"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    -- Grammar Explanation: Modals (should/must) reinforce
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_explanation', 6, 'Modals Should/Must for Projects', 'Use should/must to state team duties and expectations', '{"rules": "Use must for strict needs. Use should for strong advice.\\n- We must align before we start.\\n- We should divide tasks clearly.\\nNo contractions.", "examples": ["We must align before we start.", "We should divide tasks clearly.", "You must deliver on time for the team.", "They should review progress weekly.", "Leads must support people when issues appear."]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 7, 'Build Sentences 1', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'We must align before we start', 'We must align before we start', '["We", "must", "align", "before", "we", "start"]'::jsonb),
    (activity_id_var, 'We should divide tasks clearly', 'We should divide tasks clearly', '["We", "should", "divide", "tasks", "clearly"]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 8, 'Build Sentences 2', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'You must deliver on time for the team', 'You must deliver on time for the team', '["You", "must", "deliver", "on", "time", "for", "the", "team"]'::jsonb),
    (activity_id_var, 'They should review progress weekly', 'They should review progress weekly', '["They", "should", "review", "progress", "weekly"]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'speaking_practice', 9, 'Talk About Team Projects', 'Practice talking about smooth projects', '{"prompts": ["What must a team do to keep you sane?", "When should you escalate an issue?", "Describe a project that felt smooth."]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (
      lesson_id,
      activity_type,
      activity_order,
      title,
      description,
      content
    ) VALUES (
      'B1-L82',
      'speaking_improvement',
      10,
      'Speaking Improvement',
      'Read the improved version of your speech',
      '{"type": "speaking_improvement", "similarityThreshold": 70}'::jsonb
    );
END $$;

