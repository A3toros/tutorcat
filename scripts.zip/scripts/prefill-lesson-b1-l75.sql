-- =========================================
-- Pre-fill Database with Sample Lesson Data
-- B1-L75: Environmental Solutions
-- =========================================

DELETE FROM grammar_sentences WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'B1-L75');
DELETE FROM vocabulary_items WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'B1-L75');
DELETE FROM lesson_activities WHERE lesson_id = 'B1-L75';
DELETE FROM lessons WHERE id = 'B1-L75';

INSERT INTO lessons (id, level, lesson_number, topic) VALUES
('B1-L75', 'B1', 75, 'Environmental Solutions')
ON CONFLICT (id) DO UPDATE SET topic = EXCLUDED.topic;

DO $$
DECLARE
    lesson_id_var TEXT := 'B1-L75';
    activity_id_var UUID;
BEGIN
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'warm_up_speaking', 1, 'Green Solutions', 'Talk about local environmental actions', '{"prompt": "Which solutions are being put in place near you?"}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_intro', 2, 'Solution Words', 'Learn vocabulary about environmental solutions', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'implemented', 'นำมาใช้', NULL),
    (activity_id_var, 'funded', 'ได้รับทุน', NULL),
    (activity_id_var, 'developed', 'ถูกพัฒนา', NULL),
    (activity_id_var, 'adopted', 'นำมาใช้/ยอมรับ', NULL),
    (activity_id_var, 'enforced', 'บังคับใช้', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_matching_drag', 3, 'Match Solution Words', 'Match words with meanings', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'implemented', 'นำมาใช้', NULL),
    (activity_id_var, 'funded', 'ได้รับทุน', NULL),
    (activity_id_var, 'developed', 'ถูกพัฒนา', NULL),
    (activity_id_var, 'adopted', 'นำมาใช้/ยอมรับ', NULL),
    (activity_id_var, 'enforced', 'บังคับใช้', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 4, 'Complete the Sentences 1', 'Fill with the correct word', '{"text": "A policy was ___. The project was ___. A new system was ___.", "blanks": [{"id": "blank1", "text": "implemented", "options": ["implemented", "funded", "developed", "enforced"], "correctAnswer": "implemented"}, {"id": "blank2", "text": "funded", "options": ["funded", "implemented", "adopted", "developed"], "correctAnswer": "funded"}, {"id": "blank3", "text": "developed", "options": ["developed", "adopted", "funded", "enforced"], "correctAnswer": "developed"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 5, 'Complete the Sentences 2', 'Fill with the correct word', '{"text": "These rules were ___. The idea was quickly ___. Standards were ___.", "blanks": [{"id": "blank1", "text": "enforced", "options": ["enforced", "adopted", "implemented", "funded"], "correctAnswer": "enforced"}, {"id": "blank2", "text": "adopted", "options": ["adopted", "enforced", "developed", "funded"], "correctAnswer": "adopted"}, {"id": "blank3", "text": "enforced", "options": ["enforced", "adopted", "developed", "funded"], "correctAnswer": "enforced"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    -- Grammar Explanation: Passive Voice mix (present & past) for solutions
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_explanation', 6, 'Passive Voice Mix for Solutions', 'Use passive present/past to describe solutions being done', '{"rules": "Passive present: am/is/are + past participle (ongoing). Passive past: was/were + past participle (completed).\\n- The plan is implemented now.\\n- The rule was enforced last year.\\nAvoid contractions.", "examples": ["The solution is implemented in this district.", "The program was funded by the city.", "Solar panels are being adopted widely.", "The rule was enforced last year.", "New guidelines are developed with experts."]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 7, 'Build Sentences 1', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'The solution is implemented in this district', 'The solution is implemented in this district', '["The", "solution", "is", "implemented", "in", "this", "district"]'::jsonb),
    (activity_id_var, 'The program was funded by the city', 'The program was funded by the city', '["The", "program", "was", "funded", "by", "the", "city"]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 8, 'Build Sentences 2', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'Solar panels are being adopted widely', 'Solar panels are being adopted widely', '["Solar", "panels", "are", "being", "adopted", "widely"]'::jsonb),
    (activity_id_var, 'The rule was enforced last year', 'The rule was enforced last year', '["The", "rule", "was", "enforced", "last", "year"]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'speaking_practice', 9, 'Talk About Solutions', 'Practice talking about environmental solutions', '{"prompts": ["Which solutions are being put in place near you?", "How are rules enforced where you live?", "What project actually inspired you?"]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (
      lesson_id,
      activity_type,
      activity_order,
      title,
      description,
      content
    ) VALUES (
      'B1-L75',
      'speaking_improvement',
      10,
      'Speaking Improvement',
      'Read the improved version of your speech',
      '{"type": "speaking_improvement", "similarityThreshold": 70}'::jsonb
    );
END $$;

