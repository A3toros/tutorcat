-- =========================================
-- Pre-fill Database with Sample Lesson Data
-- C1-L42: Ethical Limits of Artificial Intelligence
-- =========================================
DELETE FROM lesson_activity_results WHERE lesson_id = 'C1-L42';
DELETE FROM user_progress WHERE lesson_id = 'C1-L42';
DELETE FROM lesson_history WHERE lesson_id = 'C1-L42';
DELETE FROM grammar_sentences WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'C1-L42');
DELETE FROM vocabulary_items WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'C1-L42');
DELETE FROM lesson_activities WHERE lesson_id = 'C1-L42';
DELETE FROM lessons WHERE id = 'C1-L42';

INSERT INTO lessons (id, level, lesson_number, topic) VALUES
('C1-L42', 'C1', 42, 'Ethical Limits of Artificial Intelligence')
ON CONFLICT (id) DO UPDATE SET topic = EXCLUDED.topic;

DO $$
DECLARE
    lesson_id_var TEXT := 'C1-L42';
    activity_id_var UUID;
BEGIN
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'warm_up_speaking', 1, 'AI Ethical Limits', 'Discuss ethical limits of AI', '{"prompt": "Where should limits be placed on AI?"}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_intro', 2, 'AI Ethics Vocabulary', 'Learn vocabulary about AI ethics', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'boundary', 'ขอบเขต', NULL),
    (activity_id_var, 'regulation', 'การควบคุม', NULL),
    (activity_id_var, 'harm', 'อันตราย', NULL),
    (activity_id_var, 'oversight', 'การกำกับดูแล', NULL),
    (activity_id_var, 'responsibility', 'ความรับผิดชอบ', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_matching_drag', 3, 'Match AI Ethics Words', 'Match English words with Thai meanings', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'boundary', 'ขอบเขต', NULL),
    (activity_id_var, 'regulation', 'การควบคุม', NULL),
    (activity_id_var, 'harm', 'อันตราย', NULL),
    (activity_id_var, 'oversight', 'การกำกับดูแล', NULL),
    (activity_id_var, 'responsibility', 'ความรับผิดชอบ', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 4, 'Complete the Sentences 1', 'Fill with the correct word', '{"text": "Ethical ___ must be respected. AI ___ requires ___.", "blanks": [{"id": "blank1", "text": "boundaries", "options": ["boundaries", "regulation", "harm", "oversight"], "correctAnswer": "boundaries"}, {"id": "blank2", "text": "regulation", "options": ["regulation", "boundary", "harm", "oversight"], "correctAnswer": "regulation"}, {"id": "blank3", "text": "oversight", "options": ["oversight", "boundary", "regulation", "harm"], "correctAnswer": "oversight"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 5, 'Complete the Sentences 2', 'Fill with the correct word', '{"text": "AI ___ must be prevented. ___ requires clear ___.", "blanks": [{"id": "blank1", "text": "harm", "options": ["harm", "boundary", "regulation", "oversight"], "correctAnswer": "harm"}, {"id": "blank2", "text": "Responsibility", "options": ["Responsibility", "Boundary", "Regulation", "Oversight"], "correctAnswer": "Responsibility"}, {"id": "blank3", "text": "regulation", "options": ["regulation", "boundary", "harm", "oversight"], "correctAnswer": "regulation"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_explanation', 6, 'Modals: Criticism in the Past', 'Learn modals for past criticism', '{"rules": "Past criticism with modals:\n- \"should have + past participle\" (criticism/regret): \"AI should have been limited earlier.\"\n- \"ought to have + past participle\" (stronger criticism): \"AI ought to have been regulated.\"\n- \"could have + past participle\" (missed opportunity): \"AI could have been controlled better.\"\n\nUse for:\n- Criticizing past actions: \"AI should have been limited before harm occurred.\"\n- Expressing regret: \"AI ought to have been regulated earlier.\"\n- Showing missed opportunities: \"AI could have been developed more carefully.\"", "examples": ["AI should have been limited before causing harm.", "AI ought to have been regulated from the start.", "AI could have been developed more ethically.", "AI should have been restricted where harm was done.", "AI ought to have been overseen more carefully."]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 7, 'Build Sentences 1', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'AI should have been limited before causing harm.', 'AI should have been limited before causing harm.', '["AI", "should", "have", "been", "limited", "before", "causing", "harm."]'::jsonb),
    (activity_id_var, 'AI ought to have been regulated from the start.', 'AI ought to have been regulated from the start.', '["AI", "ought", "to", "have", "been", "regulated", "from", "the", "start."]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 8, 'Build Sentences 2', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'AI could have been developed more ethically.', 'AI could have been developed more ethically.', '["AI", "could", "have", "been", "developed", "more", "ethically."]'::jsonb),
    (activity_id_var, 'AI should have been restricted where harm was done.', 'AI should have been restricted where harm was done.', '["AI", "should", "have", "been", "restricted", "where", "harm", "was", "done."]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'speaking_practice', 9, 'Discuss AI Ethics', 'Practice speaking about AI ethical limits', '{"prompts": ["What ethical boundaries should AI respect?", "Where has AI caused harm?", "How should AI development be regulated?", "What uses of AI concern you most?", "Who should be responsible for oversight?"]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (
      lesson_id,
      activity_type,
      activity_order,
      title,
      description,
      content
    ) VALUES (
      'C1-L42',
      'speaking_improvement',
      10,
      'Speaking Improvement',
      'Read the improved version of your speech',
      '{"type": "speaking_improvement", "similarityThreshold": 70}'::jsonb
    );
END $$;
