# B1 Additional Lessons Plan (L11-L100) — Spread Topics, Spread Grammar

## Requirements & Guidelines
- **No ambiguity**: One correct fill-blank answer (lesson vocab only); 3 unrelated distractors; no same-category all-options.
- **Grammar sentences**: Natural, non-robotic; no swap-ambiguous “noun and noun”; attach “?” to last word; commas on the preceding word; no contractions.
- **Speaking**: Student-appropriate, open, lively; personal stories; no adult-only themes.
- **Speaking improvement**: Include `speaking_improvement` activity with `similarityThreshold: 70`.
- **Topics spread**: Rotate themes every few lessons (daily life, tech, travel, work, money, health, relationships, environment, community); no clustering.
- **Grammar spread**: Each grammar point recurs later for spaced review.

## CEFR B1 Grammar Coverage (from `cefr-grammar-requirements.md`)
- Present Perfect (experience, result)
- Past Continuous
- Future: will vs going to
- First Conditional; Zero Conditional
- Modal verbs: must / have to / should
- Gerunds & infinitives; Verb + preposition
- Passive voice (present & past)
- Reported speech (statements, basic)
- Relative clauses: defining (who/which/that)
- Comparison: too/enough; so/such
- Articles: definite vs zero article

### Planned Review Counts
- Present Perfect: 8
- Past Continuous: 6
- Future (will vs going to): 6
- First Conditional: 5
- Zero Conditional: 3
- Modals (must/have to/should): 6
- Gerunds & Infinitives: 5
- Verb + Preposition: 4
- Passive (present): 4
- Passive (past): 3
- Reported Speech (statements): 3
- Relative Clauses (defining): 4
- Too/Enough: 3
- So/Such: 3
- Articles (definite vs zero): 3

---

## Lesson Plan (topics spread; grammar spaced)
Format per lesson:
- Topic + theme
- Grammar focus (+review #)
- Vocab sample (5 items)
- Speaking prompts (3 open, student-friendly)

### L11-L20
- **B1-L11 Daily Life Changes** — Present Perfect #1; vocab: routine, adjust, improve, habit, change; speaking: “What change did you make recently that really helped you?”, “Which habit have you kept the longest and why?”, “Tell me about a small change you’re proud of.”
- **B1-L12 Social Media Influence** — Past Continuous #1; vocab: feed, trend, influence, scroll, distract; speaking: “When did social media pull you in for too long?”, “Which trend actually changed what you did?”, “Describe a post that genuinely inspired you.”
- **B1-L13 Travel Planning** — Future (will vs going to) #1; vocab: itinerary, budget, booking, reserve, cancel; speaking: “How do you actually plan a trip step by step?”, “When do you change plans mid-trip?”, “What makes you pick one destination over another?”
- **B1-L14 Workplace Communication** — Modals must/have to/should #1; vocab: brief, clarify, confirm, respond, deadline; speaking: “How do you handle unclear instructions from someone?”, “When do you feel you should push back?”, “Describe the best work message you’ve sent or received.”
- **B1-L15 Personal Finances** — Articles (def/zero) #1; vocab: expense, income, bill, budget, wallet; speaking: “How do you keep track of your money in real life?”, “What’s the smartest purchase you’ve made?”, “When do you decide to save instead of spend?”
- **B1-L16 Health Problems & Advice** — Zero Conditional #1; vocab: symptom, rest, consult, remedy, clinic; speaking: “What do you do first when you feel sick?”, “Who gives you health advice you trust?”, “How do you decide it’s time to see a doctor?”
- **B1-L17 Relationships at Work** — Gerunds/Infinitives #1; vocab: cooperate, support, resolve, mentor, feedback; speaking: “How do you build trust with coworkers?”, “Tell me about a conflict you helped resolve,” “What do you enjoy doing with colleagues outside tasks?”
- **B1-L18 Environmental Problems** — Passive (present) #1; vocab: pollution, waste, emit, reduce, protect; speaking: “What local issue bothers you most?”, “How is trash actually handled where you live?”, “What small action did you take that felt useful?”
- **B1-L19 Childhood Memories** — Past Continuous #2; vocab: remember, pretend, explore, discover, favorite; speaking: “What were you doing in a favorite childhood memory?”, “Tell me about a place you explored as a kid,” “Who made your childhood feel safe or fun?”
- **B1-L20 Online Communication** — Relative Clauses #1; vocab: platform, thread, notify, reply, attach; speaking: “Which app do you use most and why?”, “How do you fix misunderstandings online?”, “What message from someone really made you feel heard?”

### L21-L30
- **B1-L21 Cultural Differences** — First Conditional #1; vocab: greet, gesture, custom, polite, offend; speaking: “How do you avoid awkward moments in a new culture?”, “What surprised you most when you traveled?”, “When do you decide to adapt your behavior?”
- **B1-L22 Teamwork** — Reported Speech #1; vocab: assign, delegate, align, decide, update; speaking: “How do you pass on feedback without drama?”, “Tell me about sharing news with your team,” “When does teamwork feel great for you?”
- **B1-L23 Saving & Spending Money** — Present Perfect #2; vocab: save, spend, invest, waste, goal; speaking: “What have you saved up for recently?”, “When did you regret spending?”, “How do you decide something is worth the price?”
- **B1-L24 Mental Health Awareness** — So/Such #1; vocab: mood, support, counselor, overwhelm, calm; speaking: “Who do you actually talk to when stressed?”, “Describe a routine that calms you down,” “What signs show you need a break?”
- **B1-L25 Family Roles** — Verb + Preposition #1; vocab: rely on, care for, argue with, agree on, provide for; speaking: “How do you split chores at home?”, “When do you rely on family most?”, “What do you try to teach younger relatives?”
- **B1-L26 Recycling & Waste** — Passive (past) #1; vocab: sorted, collected, recycled, banned, reduced; speaking: “How is trash really handled where you live?”, “What rule changed your recycling habits?”, “Which new rule would help most?”
- **B1-L27 Living Abroad** — Articles #2; vocab: visa, host, adapt, culture, routine; speaking: “What would you miss first if you moved abroad?”, “How would you make friends in a new country?”, “What daily routine would you keep?”
- **B1-L28 Tech: Pros/Cons** — Too/Enough #1; vocab: fast enough, too distracting, efficient, reliable, secure; speaking: “At what point do you put your phone away?”, “Is 3 hours of scrolling TikTok too much for you? Why?”, “Tell me about a day when tech made things worse for you.”
- **B1-L29 Dealing with Stress** — Modals (must/should) #2; vocab: pause, breathe, prioritize, postpone, cope; speaking: “What must you do first when stress hits?”, “What should schools actually teach about stress?”, “Describe your go-to coping move.”
- **B1-L30 Food Cultures** — Present Perfect #3; vocab: cuisine, spice, recipe, flavor, tradition; speaking: “What new dish have you tried lately?”, “Which food memory sticks with you?”, “How do you talk yourself into trying new food?”

### L31-L40
- **B1-L31 Remote Work** — Future (will vs going to) #2; vocab: remote, hybrid, schedule, focus, commute; speaking: “How will remote work change your daily life?”, “What are you going to fix about your home setup?”, “What’s the best and worst part of working from home for you?”
- **B1-L32 News & Information** — First Conditional #2; vocab: headline, source, verify, bias, rumor; speaking: “How do you check if news is real?”, “What do you do when a headline feels fake?”, “When do you decide to stop doomscrolling?”
- **B1-L33 Strengths & Weaknesses** — Gerunds/Infinitives #2; vocab: improve, practice, avoid, prefer, challenge; speaking: “What do you enjoy getting better at?”, “What task do you avoid?”, “Tell me about practicing a skill until it finally worked.”
- **B1-L34 Problems While Traveling** — Past Continuous #3; vocab: delay, miss, lose, reroute, assist; speaking: “What were you doing when a trip went wrong?”, “How did you get out of it?”, “Who stepped in to help you?”
- **B1-L35 Customer Service Experiences** — Passive (present) #2; vocab: serve, resolve, deliver, apologize, refund; speaking: “What service experience really impressed you?”, “How should a complaint be handled?”, “Describe a fair solution you received.”
- **B1-L36 Fitness Routines** — So/Such #2; vocab: routine, stamina, stretch, rest, hydrate; speaking: “What makes a workout so motivating for you?”, “What’s such a tiring exercise that you still do?”, “How do you keep a routine when you’re busy?”
- **B1-L37 Conflict & Agreement** — Relative Clauses #2; vocab: disagree, compromise, mediate, align, respect; speaking: “How do you sort out disagreements with friends or coworkers?”, “Who is someone that mediates well in your life?”, “When do you decide to compromise?”
- **B1-L38 Comparing Products** — Too/Enough #2; vocab: durable, affordable, reliable, too pricey, good enough; speaking: “How do you decide between two similar products?”, “When is quality worth paying more?”, “Describe something that wasn’t good enough and why.”
- **B1-L39 Tech Problems & Fixes** — Verb + Prep #2; vocab: log in, run into, deal with, back up, depend on; speaking: “What do you actually do when your tech fails?”, “How do you back up your stuff?”, “When do you finally ask someone for help?”
- **B1-L40 Homesickness** — Present Perfect #4; vocab: miss, adapt, connect, comfort, familiar; speaking: “When have you felt homesick?”, “What helps you adapt in a new place?”, “How do you stay connected to people you miss?”

### L41-L50
- **B1-L41 Making Decisions** — Future (will vs going to) #3; vocab: decide, choose, weigh, risk, option; speaking: “How do you decide when you’re under pressure?”, “What decision are you going to make soon?”, “When do you change your mind and why?”
- **B1-L42 Language Barriers** — Reported Speech #2; vocab: clarify, translate, repeat, understand, mishear; speaking: “How do you retell something you heard in another language?”, “Describe a misunderstanding you had,” “How did you fix it in the moment?”
- **B1-L43 Budgeting** — Articles #3; vocab: budget, expense, category, total, leftover; speaking: “How do you actually plan a monthly budget?”, “What expense surprised you lately?”, “When do you decide to cut costs?”
- **B1-L44 Sleep & Energy** — Zero Conditional #2; vocab: rest, nap, caffeine, routine, alert; speaking: “What happens to you if you sleep too little?”, “What keeps you awake on a rough day?”, “Describe a daily routine that really works for you.”
- **B1-L45 Giving Opinions Politely** — Modals (should) #3; vocab: suggest, recommend, agree, disagree, consider; speaking: “How do you share a tough opinion without sounding rude?”, “When do you soften your words?”, “Describe a polite disagreement you had.”
- **B1-L46 Trusting Information Online** — First Conditional #3; vocab: verify, source, fact-check, claim, cite; speaking: “If a post feels fake, what do you do?”, “How do you decide a source is trustworthy?”, “What makes you doubt information?”
- **B1-L47 City vs Countryside** — Past Continuous #4; vocab: commute, crowd, quiet, scenery, pace; speaking: “What were you doing last time a city felt overwhelming?”, “How does countryside pace change how you feel?”, “Where do you focus better and why?”
- **B1-L48 Advertising & Consumers** — Passive (past) #2; vocab: advertised, targeted, influenced, launched, reviewed; speaking: “Which ad actually influenced you?”, “How were buyers targeted in a campaign you saw?”, “Describe a campaign that failed for you.”
- **B1-L49 Helping Others** — Gerunds/Infinitives #3; vocab: volunteer, support, donate, mentor, assist; speaking: “What do you genuinely enjoy doing to help?”, “When did you give time or money?”, “How do you decide who to help?”
- **B1-L50 Energy Use at Home** — Passive (present) #3; vocab: consume, reduce, insulate, switch, monitor; speaking: “How is energy really used at home?”, “What are you improving now?”, “What change saved the most for you?”

### L51-L60
- **B1-L51 Online Shopping** — Present Perfect #5; vocab: cart, checkout, return, warranty, review; speaking: “What have you bought online recently that you loved?”, “When did a review save you from a bad buy?”, “Describe your smoothest delivery ever.”
- **B1-L52 Work Responsibilities** — Relative Clauses #3; vocab: assign, own, accountable, supervise, deliver; speaking: “Who is someone that supports you most at work?”, “Which tasks drain you the most?”, “How do you share responsibility fairly?”
- **B1-L53 Diet Choices** — So/Such #3; vocab: balanced, portion, craving, nutrient, variety; speaking: “What food is so satisfying you crave it?”, “What’s such a hard craving to resist for you?”, “How do you balance taste and health personally?”
- **B1-L54 Conflict Resolution (Work)** — Verb + Prep #3; vocab: deal with, agree on, listen to, respond to, compromise on; speaking: “How do you deal with a tense meeting in real life?”, “Who do you listen to most before you decide?”, “When do you compromise even if you disagree?”
- **B1-L55 Cultural Traditions** — Articles (review) #4; vocab: ritual, heritage, symbol, ceremony, festival; speaking: “What tradition matters most to you?”, “How do you explain it to friends who don’t know it?”, “What would you keep or change about it?”
- **B1-L56 Remote Learning** — Future (will vs going to) #4; vocab: platform, module, submit, access, interact; speaking: “How will online learning change your study life?”, “What are you going to improve in your habits?”, “When do you still prefer in-person classes?”
- **B1-L57 Making Complaints** — Passive (past) #3; vocab: damaged, delayed, mishandled, resolved, escalated; speaking: “Describe a complaint you actually made,” “What finally got resolved?”, “How should staff respond to you?”
- **B1-L58 Financial Goals** — Modals (must/have to) #4; vocab: invest, budget, track, reduce, target; speaking: “What must you do to hit a money goal?”, “How do you track progress day to day?”, “When do you change the plan?”
- **B1-L59 Free Time & Work–Life Balance** — Present Perfect #6; vocab: unwind, recharge, schedule, boundary, hobby; speaking: “How have you protected your free time lately?”, “When did you last feel balanced?”, “What hobby brings you back to life?”
- **B1-L60 Public Transport vs Cars** — First Conditional #4; vocab: commute, fare, emission, traffic, route; speaking: “If fuel costs rise, what will you choose for commuting?”, “How do different routes change your day?”, “When is a car the only option for you?”

### L61-L70
- **B1-L61 Social Responsibilities** — Relative Clauses #4; vocab: volunteer, donate, organize, advocate, participate; speaking: “Who inspires you to help others?”, “What local group do you support and why?”, “How do you actually participate in your community?”
- **B1-L62 Protecting Nature** — Passive (present) #4; vocab: conserved, protected, restored, cleaned, planted; speaking: “What places near you are being protected?”, “How is nature being restored where you live?”, “Which project impressed you personally?”
- **B1-L63 Learning New Skills** — Gerunds/Infinitives #4; vocab: practice, attempt, master, struggle, repeat; speaking: “What skill are you trying to master right now?”, “What’s hard for you to start?”, “Who helps you practice when you’re stuck?”
- **B1-L64 Technology Predictions** — Future (will vs going to) #5; vocab: predict, expect, advance, replace, automate; speaking: “What tech do you think will change your daily life?”, “What are you going to learn next to keep up?”, “Which job might machines replace in your world?”
- **B1-L65 Balancing Health and Work** — Modals (should/must) #5; vocab: prioritize, rest, hydrate, pause, stretch; speaking: “What must you do to stay healthy at work?”, “What should your workplace provide?”, “How do you take breaks on busy days?”
- **B1-L66 Travel Tips** — Past Continuous #5; vocab: pack, navigate, bargain, warn, avoid; speaking: “What were you doing when a travel tip saved you?”, “Which advice helped you most?”, “How did you learn that lesson?”
- **B1-L67 Language Learning & Barriers** — Reported Speech #3; vocab: explain, repeat, clarify, translate, interpret; speaking: “How do you repeat instructions for friends?”, “What phrase helped you most abroad?”, “Tell me about explaining a rule to someone.”
- **B1-L68 Comparing Housing Options** — Too/Enough #3; vocab: spacious, noisy, affordable, safe, convenient; speaking: “When is a place too noisy for you?”, “What is enough space for your life?”, “How do you rank your housing priorities?”
- **B1-L69 Healthy Habits** — Zero Conditional #3; vocab: routine, hydrate, stretch, sleep, avoid; speaking: “What happens to you if you skip breakfast?”, “Which daily habit helps you most?”, “How do you build a habit that sticks?”
- **B1-L70 Career Changes** — Present Perfect #7; vocab: switch, promote, resign, retrain, adjust; speaking: “Have you changed career paths?”, “What pushed you to switch?”, “How did you adapt to the new role?”

### L71-L80
- **B1-L71 Community Life** — Articles (review) #5; vocab: neighbor, event, park, service, support; speaking: “What makes your community feel strong?”, “Which local event do you actually enjoy?”, “How do you get involved where you live?”
- **B1-L72 Digital Privacy** — Modals (have to/should) #6; vocab: consent, encrypt, password, share, leak; speaking: “What should you never post online?”, “When do you have to refuse sharing data?”, “How do you keep your accounts safe?”
- **B1-L73 Studying Online vs Offline** — Future (will vs going to) #6; vocab: lecture, interact, focus, distract, resource; speaking: “How will classes change for you?”, “What are you going to keep from online study?”, “When do you insist on in-person learning?”
- **B1-L74 Work Under Pressure** — Gerunds/Infinitives #5; vocab: multitask, prioritize, deliver, cope, decompress; speaking: “What helps you cope when deadlines stack up?”, “What do you avoid when you’re overloaded?”, “Describe delivering on a tight deadline in your life.”
- **B1-L75 Environmental Solutions** — Passive mix *capstone*; vocab: implemented, funded, developed, adopted, enforced; speaking: “Which solutions are being put in place near you?”, “How are rules enforced where you live?”, “What project actually inspired you?”
- **B1-L76 Helping in Emergencies** — First Conditional #5; vocab: assist, call, respond, calm, protect; speaking: “If you saw an accident, what would you do first?”, “How do you keep calm in a crisis?”, “Who do you call right away?”
- **B1-L77 Reporting News** — Reported Speech *capstone*; vocab: report, quote, confirm, deny, announce; speaking: “How do you repeat urgent news accurately?”, “When do you add context?”, “Describe sharing breaking news with friends.”
- **B1-L78 Volunteering** — Present Perfect #8; vocab: volunteer, mentor, donate, organize, impact; speaking: “What have you learned from volunteering?”, “Which cause matters most to you?”, “How has volunteering changed your outlook?”
- **B1-L79 Travel Alone vs With Others** — Past Continuous #6; vocab: solo, companion, plan, safety, adjust; speaking: “What were you doing the first time you traveled alone?”, “How is traveling with friends different for you?”, “When did a companion really help?”
- **B1-L80 Social Media & Mental Health** — Verb + Prep #4; vocab: log off, check on, compare to, depend on, deal with; speaking: “How do you deal with negative posts in your feed?”, “When do you decide to log off?”, “How do you stop comparing yourself online?”

### L81-L90
- **B1-L81 Trust & Misinformation** — Relative Clauses reinforce; vocab: rumor, source, claim, verify, debunk; speaking: “Who do you actually trust for news?”, “How do you debunk a rumor with friends?”, “When do you just ignore a story?”
- **B1-L82 Team Projects** — Modals (should/must) reinforce; vocab: collaborate, divide, align, review, deliver; speaking: “What must a team do to keep you sane?”, “When should you escalate an issue?”, “Describe a project that felt smooth.”
- **B1-L83 Making Suggestions** — Gerunds/Infinitives light; vocab: suggest, propose, recommend, consider, try; speaking: “How do you suggest ideas without sounding bossy?”, “When do you propose changes?”, “What’s the best suggestion someone gave you?”
- **B1-L84 Giving Health Advice** — Zero/First Conditional blend; vocab: hydrate, rest, consult, prevent, recover; speaking: “If a friend feels ill, what do you say first?”, “What advice always seems to work for you?”, “When should someone see a doctor?”
- **B1-L85 Remote Work Challenges** — Present Perfect light; vocab: isolate, distract, coordinate, adapt, motivate; speaking: “What challenges have you faced working remotely?”, “How have you adapted at home?”, “What keeps you motivated when alone?”
- **B1-L86 Community Volunteering** — Passive light; vocab: organized, supported, funded, staffed, appreciated; speaking: “How are local events organized where you live?”, “Who is being helped right now?”, “What makes volunteers feel appreciated?”
- **B1-L87 Travel Mishaps** — Past Continuous/Reported Speech light; vocab: lost, delayed, rerouted, explained, apologized; speaking: “What were you doing when your travel plans failed?”, “How did staff explain it to you?”, “What lesson did you take away?”
- **B1-L88 Budget Travel** — Articles/Too-Enough light; vocab: hostel, fare, budget, cheap, enough; speaking: “How do you travel cheaply enough for your budget?”, “When is a deal too good to trust?”, “What’s your best budget travel tip?”
- **B1-L89 Future Tech Ethics** — Future (will vs going to) light; vocab: ethics, bias, regulate, predict, impact; speaking: “What tech do you think will need strict rules?”, “How are you going to handle AI tools in your life?”, “What impact worries you most?”
- **B1-L90 Wrap-Up Mix** — Mixed grammar capstone; vocab: review set; speaking: “Which topic was most useful to you?”, “What will you practice next?”, “How did your skills actually improve?”

### L91-L100 (Flex Reviews)
- Use these to reinforce any under-covered grammar; keep topic variety (community, environment, health, money, tech, relationships, travel). Add speaking prompts per lesson following the rules above.

---

## Grammar Coverage Checkpoint (planned)
- Present Perfect: 8 (L11,23,40,51,59,70,78,85*)
- Past Continuous: 6 (L12,19,34,47,66,79)
- Future (will vs going to): 6 (L13,31,41,56,64,73,89*)
- First Conditional: 5 (L21,32,46,60,76,84*)
- Zero Conditional: 3 (L16,44,69,84*)
- Modals must/have to/should: 6 (L14,29,45,58,65,72,82)
- Gerunds & Infinitives: 5 (L17,33,49,63,74,83)
- Verb + Preposition: 4 (L25,39,54,80)
- Passive (present): 4 (L18,35,50,62,86*)
- Passive (past): 3 (L26,48,57,75)
- Reported Speech (statements): 3 (L22,42,67,77)
- Relative Clauses (defining): 4 (L20,37,52,61,81)
- Too/Enough: 3 (L28,38,68,88)
- So/Such: 3 (L24,36,53)
- Articles (def/zero): 3 (L15,27,43,55,71,88)

*Flex/capstone lessons can be tuned during script creation to hit exact counts based on progress.

