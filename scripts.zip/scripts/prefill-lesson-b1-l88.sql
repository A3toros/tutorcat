-- =========================================
-- Pre-fill Database with Sample Lesson Data
-- B1-L88: Budget Travel
-- =========================================

DELETE FROM grammar_sentences WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'B1-L88');
DELETE FROM vocabulary_items WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'B1-L88');
DELETE FROM lesson_activities WHERE lesson_id = 'B1-L88';
DELETE FROM lessons WHERE id = 'B1-L88';

INSERT INTO lessons (id, level, lesson_number, topic) VALUES
('B1-L88', 'B1', 88, 'Budget Travel')
ON CONFLICT (id) DO UPDATE SET topic = EXCLUDED.topic;

DO $$
DECLARE
    lesson_id_var TEXT := 'B1-L88';
    activity_id_var UUID;
BEGIN
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'warm_up_speaking', 1, 'Cheap Trips', 'Talk about saving money while traveling', '{"prompt": "How do you travel cheaply enough for your budget?"}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_intro', 2, 'Budget Travel Words', 'Learn vocabulary about budget travel', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'hostel', 'โฮสเทล', NULL),
    (activity_id_var, 'fare', 'ค่าโดยสาร', NULL),
    (activity_id_var, 'budget', 'งบประมาณ', NULL),
    (activity_id_var, 'cheap', 'ราคาถูก', NULL),
    (activity_id_var, 'enough', 'เพียงพอ', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_matching_drag', 3, 'Match Budget Travel Words', 'Match words with meanings', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'hostel', 'โฮสเทล', NULL),
    (activity_id_var, 'fare', 'ค่าโดยสาร', NULL),
    (activity_id_var, 'budget', 'งบประมาณ', NULL),
    (activity_id_var, 'cheap', 'ราคาถูก', NULL),
    (activity_id_var, 'enough', 'เพียงพอ', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 4, 'Complete the Sentences 1', 'Fill with the correct word', '{"text": "We stayed in a ___. The ___ was low. The trip fit our ___.", "blanks": [{"id": "blank1", "text": "hostel", "options": ["hostel", "fare", "budget", "cheap"], "correctAnswer": "hostel"}, {"id": "blank2", "text": "fare", "options": ["fare", "budget", "cheap", "enough"], "correctAnswer": "fare"}, {"id": "blank3", "text": "budget", "options": ["budget", "fare", "hostel", "enough"], "correctAnswer": "budget"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 5, 'Complete the Sentences 2', 'Fill with the correct word', '{"text": "The hotel was too ___. The room was good ___. We had ___ money left.", "blanks": [{"id": "blank1", "text": "expensive", "options": ["expensive", "cheap", "enough", "budget"], "correctAnswer": "expensive"}, {"id": "blank2", "text": "enough", "options": ["enough", "cheap", "budget", "fare"], "correctAnswer": "enough"}, {"id": "blank3", "text": "enough", "options": ["enough", "expensive", "fare", "hostel"], "correctAnswer": "enough"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    -- Grammar Explanation: Articles + Too/Enough (light)
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_explanation', 6, 'Articles with Too/Enough', 'Use the/a/zero with travel nouns; use too/enough for cost/value', '{"rules": "Use a/an for singular new info; the for known items. Use too + adjective for excess; adjective + enough for sufficiency.\\n- The fare was too high.\\n- The hostel was cheap enough for us.", "examples": ["The fare was too high for our budget.", "We found a hostel that was cheap enough.", "The room was good enough for one night.", "A cheap ticket is not always good enough.", "The bus was too crowded for luggage."]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 7, 'Build Sentences 1', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'The fare was too high for our budget', 'The fare was too high for our budget', '["The", "fare", "was", "too", "high", "for", "our", "budget"]'::jsonb),
    (activity_id_var, 'We found a hostel that was cheap enough', 'We found a hostel that was cheap enough', '["We", "found", "a", "hostel", "that", "was", "cheap", "enough"]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 8, 'Build Sentences 2', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'The room was good enough for one night', 'The room was good enough for one night', '["The", "room", "was", "good", "enough", "for", "one", "night"]'::jsonb),
    (activity_id_var, 'A cheap ticket is not always good enough', 'A cheap ticket is not always good enough', '["A", "cheap", "ticket", "is", "not", "always", "good", "enough"]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'speaking_practice', 9, 'Talk About Budget Travel', 'Practice talking about saving while traveling', '{"prompts": ["How do you travel cheaply enough for your budget?", "When is a deal too good to trust?", "What is your best budget travel tip?"]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (
      lesson_id,
      activity_type,
      activity_order,
      title,
      description,
      content
    ) VALUES (
      'B1-L88',
      'speaking_improvement',
      10,
      'Speaking Improvement',
      'Read the improved version of your speech',
      '{"type": "speaking_improvement", "similarityThreshold": 70}'::jsonb
    );
END $$;

