-- =========================================
-- Pre-fill Database with Sample Lesson Data
-- B2-L46: Making new friends (habits)
-- =========================================

DELETE FROM grammar_sentences WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'B2-L46');
DELETE FROM vocabulary_items WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'B2-L46');
DELETE FROM lesson_activities WHERE lesson_id = 'B2-L46';
DELETE FROM lessons WHERE id = 'B2-L46';

INSERT INTO lessons (id, level, lesson_number, topic) VALUES
('B2-L46', 'B2', 46, 'Making new friends (habits)')
ON CONFLICT (id) DO UPDATE SET topic = EXCLUDED.topic;

DO $$
DECLARE
    lesson_id_var TEXT := 'B2-L46';
    activity_id_var UUID;
BEGIN
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'warm_up_speaking', 1, 'Meeting People', 'Talk about online vs offline', '{"prompt": "Where do you meet people, how do you keep conversations going, and what feels different online vs offline?"}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_intro', 2, 'Friendship Habit Words', 'Key words for maintaining connections', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'intro', 'การแนะนำตัว', NULL),
    (activity_id_var, 'approach', 'เข้าหา/วิธีเข้าหา', NULL),
    (activity_id_var, 'invite', 'เชิญ', NULL),
    (activity_id_var, 'mingle', 'ปะปน/เข้าสังคม', NULL),
    (activity_id_var, 'follow-up', 'การติดตามภายหลัง', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_matching_drag', 3, 'Match Friendship Habit Words', 'Match words with meanings', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'intro', 'การแนะนำตัว', NULL),
    (activity_id_var, 'approach', 'เข้าหา/วิธีเข้าหา', NULL),
    (activity_id_var, 'invite', 'เชิญ', NULL),
    (activity_id_var, 'mingle', 'ปะปน/เข้าสังคม', NULL),
    (activity_id_var, 'follow-up', 'การติดตามภายหลัง', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 4, 'Complete the Sentences 1', 'Fill with the correct word', '{"text": "I practice my ___. I plan my ___. I ___ people to small meetups.", "blanks": [{"id": "blank1", "text": "intro", "options": ["intro", "approach", "invite", "mingle"], "correctAnswer": "intro"}, {"id": "blank2", "text": "approach", "options": ["approach", "follow-up", "intro", "mingle"], "correctAnswer": "approach"}, {"id": "blank3", "text": "invite", "options": ["invite", "mingle", "intro", "follow-up"], "correctAnswer": "invite"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 5, 'Complete the Sentences 2', 'Fill with the correct word', '{"text": "I like to ___ at events. I always send a ___.", "blanks": [{"id": "blank1", "text": "mingle", "options": ["mingle", "invite", "follow-up", "approach"], "correctAnswer": "mingle"}, {"id": "blank2", "text": "follow-up", "options": ["follow-up", "approach", "invite", "intro"], "correctAnswer": "follow-up"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_explanation', 6, 'Contrast & Concession (whereas/however)', 'Compare online/offline habits', '{"rules": "Use whereas to contrast two subjects; use however to contrast sentences. Keep parallel structure.\\n- I meet people offline, whereas my friend meets them online.\\n- I enjoy chats; however, I get tired in crowds.", "examples": ["I prefer small meetups, whereas my friend likes big events.", "Online chats are fast; however, they can feel shallow.", "I mingle offline, whereas she connects by message.", "I enjoy calls; however, I follow up with texts.", "Some people share fast online, whereas others wait in person."]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 7, 'Build Sentences 1', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'I prefer small meetups, whereas my friend likes big events', 'I prefer small meetups, whereas my friend likes big events.', '["I", "prefer", "small", "meetups,", "whereas", "my", "friend", "likes", "big", "events."]'::jsonb),
    (activity_id_var, 'Online chats are fast; however, they can feel shallow', 'Online chats are fast; however, they can feel shallow.', '["Online", "chats", "are", "fast;", "however,", "they", "can", "feel", "shallow."]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 8, 'Build Sentences 2', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'I mingle offline, whereas she connects by message', 'I mingle offline, whereas she connects by message.', '["I", "mingle", "offline,", "whereas", "she", "connects", "by", "message."]'::jsonb),
    (activity_id_var, 'I enjoy calls; however, I follow up with texts', 'I enjoy calls; however, I follow up with texts.', '["I", "enjoy", "calls;", "however,", "I", "follow", "up", "with", "texts."]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'speaking_practice', 9, 'Talk About Meeting Habits', 'Practice contrast', '{"prompts": ["Where do you meet people?", "How do you keep conversations going?", "What feels different online vs offline for you?"]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (
      lesson_id,
      activity_type,
      activity_order,
      title,
      description,
      content
    ) VALUES (
      'B2-L46',
      'speaking_improvement',
      10,
      'Speaking Improvement',
      'Read the improved version of your speech',
      '{"type": "speaking_improvement", "similarityThreshold": 70}'::jsonb
    );
END $$;


