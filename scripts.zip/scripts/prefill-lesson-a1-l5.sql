-- =========================================
-- Pre-fill Database with Sample Lesson Data
-- A1-L5: Hobbies & Free Time
-- =========================================

-- Clear existing sample data for A1-L5 (optional - comment out if you want to keep existing data)
-- Delete in correct order to respect foreign key constraints
DELETE FROM lesson_activity_results WHERE lesson_id = 'A1-L5';
DELETE FROM user_progress WHERE lesson_id = 'A1-L5';
DELETE FROM lesson_history WHERE lesson_id = 'A1-L5';
DELETE FROM grammar_sentences WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'A1-L5');
DELETE FROM vocabulary_items WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'A1-L5');
DELETE FROM lesson_activities WHERE lesson_id = 'A1-L5';
DELETE FROM lessons WHERE id = 'A1-L5';

INSERT INTO lessons (id, level, lesson_number, topic) VALUES
('A1-L5', 'A1', 5, 'Hobbies & Free Time')
ON CONFLICT (id) DO UPDATE SET topic = EXCLUDED.topic;

DO $$
DECLARE
    lesson_id_var TEXT := 'A1-L5';
    activity_id_var UUID;
BEGIN
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content) VALUES (lesson_id_var, 'warm_up_speaking', 1, 'Your Hobbies', 'What do you do in your free time?', '{"prompt": "What do you like to do in your free time?"}'::jsonb) RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content) VALUES (lesson_id_var, 'vocabulary_intro', 2, 'Hobby Words', 'Learn hobby vocabulary', '{}'::jsonb) RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'reading', 'อ่านหนังสือ', NULL),
    (activity_id_var, 'watching TV', 'ดูทีวี', NULL),
    (activity_id_var, 'listening to music', 'ฟังเพลง', NULL),
    (activity_id_var, 'playing sports', 'เล่นกีฬา', NULL),
    (activity_id_var, 'cooking', 'ทำอาหาร', NULL);

    -- 3. Vocabulary Matching Drag #1 (5 pairs - same words)
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content) VALUES (lesson_id_var, 'vocabulary_matching_drag', 3, 'Match Hobby Words 1', 'Match English phrases with Thai meanings', '{}'::jsonb) RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'reading', 'อ่านหนังสือ', NULL),
    (activity_id_var, 'watching TV', 'ดูทีวี', NULL),
    (activity_id_var, 'listening to music', 'ฟังเพลง', NULL),
    (activity_id_var, 'playing sports', 'เล่นกีฬา', NULL),
    (activity_id_var, 'cooking', 'ทำอาหาร', NULL);

    

    -- 4. Vocabulary Fill Blanks #1 (4 words: reading, watching TV, listening to music, playing sports - cooking left out)
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content) VALUES (lesson_id_var, 'vocabulary_fill_blanks', 4, 'Complete the Sentences 1', 'Fill in the blanks with correct words', '{"text": "I like ___ books every evening. I enjoy ___ in the afternoon. I also like ___ while I work. I go ___ on weekends.", "blanks": [{"id": "blank1", "text": "reading", "options": ["reading", "book", "car", "table"], "correctAnswer": "reading"}, {"id": "blank2", "text": "watching TV", "options": ["watching TV", "chair", "door", "window"], "correctAnswer": "watching TV"}, {"id": "blank3", "text": "listening to music", "options": ["listening to music", "phone", "water", "tree"], "correctAnswer": "listening to music"}, {"id": "blank4", "text": "playing sports", "options": ["playing sports", "pen", "paper", "desk"], "correctAnswer": "playing sports"}]}'::jsonb) RETURNING id INTO activity_id_var;

    -- 4. Vocabulary Fill Blanks #2 (4 words: reading, watching TV, listening to music, cooking - playing sports left out)
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content) VALUES (lesson_id_var, 'vocabulary_fill_blanks', 5, 'Complete the Sentences 2', 'Fill in the blanks with correct words', '{"text": "I like ___ books before bed. I also enjoy ___ shows in the evening. I like ___ while I exercise. On weekends, I like ___ dinner for my family.", "blanks": [{"id": "blank1", "text": "reading", "options": ["reading", "car", "book", "table"], "correctAnswer": "reading"}, {"id": "blank2", "text": "watching TV", "options": ["watching TV", "chair", "door", "window"], "correctAnswer": "watching TV"}, {"id": "blank3", "text": "listening to music", "options": ["listening to music", "phone", "water", "tree"], "correctAnswer": "listening to music"}, {"id": "blank4", "text": "cooking", "options": ["cooking", "pen", "paper", "desk"], "correctAnswer": "cooking"}]}'::jsonb) RETURNING id INTO activity_id_var;

    -- 4. Grammar Explanation (5 examples)
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content) VALUES (lesson_id_var, 'grammar_explanation', 6, 'Present Simple - Hobbies', 'Learn to talk about hobbies', '{"rules": "Use present simple to talk about regular activities:\n\n- I + verb (I read books)\n- He/She + verb + s (She watches TV)\n- Questions: Do/Does + subject + verb? (Do you play sports?)\n- Negative: don''t/doesn''t + verb (I don''t watch TV)", "examples": ["I read books every day.", "She watches TV in the evening.", "Do you play sports?", "He listens to music.", "We cook on weekends."]}'::jsonb) RETURNING id INTO activity_id_var;

    -- 4. Grammar Sentences #1
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content) VALUES (lesson_id_var, 'grammar_sentences', 7, 'Build Sentences 1', 'Arrange words to make sentences', '{}'::jsonb) RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'I read books every day', 'I read books every day', '["I", "read", "books", "every", "day"]'::jsonb),
    (activity_id_var, 'She watches TV in the evening', 'She watches TV in the evening', '["She", "watches", "TV", "in", "the", "evening"]'::jsonb);
    -- 4. Grammar Sentences #2
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content) VALUES (lesson_id_var, 'grammar_sentences', 8, 'Build Sentences 2', 'Arrange words to make sentences', '{}'::jsonb) RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'Do you play sports', 'Do you play sports', '["Do", "you", "play", "sports"]'::jsonb),
    (activity_id_var, 'He listens to music', 'He listens to music', '["He", "listens", "to", "music"]'::jsonb);
    -- 4. Speaking Practice (5 prompts - CEFR A1)
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content) VALUES (lesson_id_var, 'speaking_practice', 9, 'Talk About Your Hobbies', 'Practice talking about hobbies', '{"prompts": ["What do you do in your free time?", "Do you like reading? What do you read?", "What sports do you play?", "Do you watch TV? What do you watch?", "What music do you like?"]}'::jsonb) RETURNING id INTO activity_id_var;

END $$;
