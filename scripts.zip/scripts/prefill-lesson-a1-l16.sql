-- =========================================
-- Pre-fill Database with Sample Lesson Data
-- A1-L16: Food You Like
-- =========================================

DELETE FROM grammar_sentences WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'A1-L16');
DELETE FROM vocabulary_items WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'A1-L16');
DELETE FROM lesson_activities WHERE lesson_id = 'A1-L16';
DELETE FROM lessons WHERE id = 'A1-L16';

INSERT INTO lessons (id, level, lesson_number, topic) VALUES
('A1-L16', 'A1', 16, 'Food You Like')
ON CONFLICT (id) DO UPDATE SET topic = EXCLUDED.topic;

DO $$
DECLARE
    lesson_id_var TEXT := 'A1-L16';
    activity_id_var UUID;
BEGIN
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'warm_up_speaking', 1, 'Favorite Food', 'Talk about food you like', '{"prompt": "What food do you like?"}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_intro', 2, 'Food Words', 'Learn food words', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'rice', 'ข้าว', NULL),
    (activity_id_var, 'chicken', 'ไก่', NULL),
    (activity_id_var, 'soup', 'ซุป', NULL),
    (activity_id_var, 'salad', 'สลัด', NULL),
    (activity_id_var, 'bread', 'ขนมปัง', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_matching_drag', 3, 'Match Food Words', 'Match food words', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'rice', 'ข้าว', NULL),
    (activity_id_var, 'chicken', 'ไก่', NULL),
    (activity_id_var, 'soup', 'ซุป', NULL),
    (activity_id_var, 'salad', 'สลัด', NULL),
    (activity_id_var, 'bread', 'ขนมปัง', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 4, 'Complete the Sentences 1', 'Fill with the correct word', '{"text": "I like ___. I like ___.", "blanks": [{"id": "blank1", "text": "rice", "options": ["rice", "chicken", "soup", "salad"], "correctAnswer": "rice"}, {"id": "blank2", "text": "chicken", "options": ["chicken", "bread", "soup", "salad"], "correctAnswer": "chicken"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 5, 'Complete the Sentences 2', 'Fill with the correct word', '{"text": "I like ___. I do not like ___.", "blanks": [{"id": "blank1", "text": "soup", "options": ["soup", "salad", "rice", "bread"], "correctAnswer": "soup"}, {"id": "blank2", "text": "bread", "options": ["bread", "salad", "soup", "rice"], "correctAnswer": "bread"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_explanation', 6, 'Like / Don’t Like', 'Say what you like', '{"rules": "Use like / don''t like + noun.\n- I like rice.\n- I don''t like soup.\nAsk: Do you like ___?", "examples": ["I like rice.", "I like chicken and salad.", "I don''t like cold soup.", "Do you like bread?", "Do you like salad?"]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 7, 'Build Sentences 1', 'Arrange words', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'I like rice', 'I like rice.', '["I", "like", "rice."]'::jsonb),
    (activity_id_var, 'I don t like soup', 'I don''t like soup.', '["I", "don''t", "like", "soup."]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 8, 'Build Sentences 2', 'Arrange words', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'Do you like chicken', 'Do you like chicken?', '["Do", "you", "like", "chicken?"]'::jsonb),
    (activity_id_var, 'Do you like salad', 'Do you like salad?', '["Do", "you", "like", "salad?"]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'speaking_practice', 9, 'Talk About Food', 'Practice likes', '{"prompts": ["What food do you like?", "Do you like rice?", "Do you like salad?", "Do you like soup?", "Do you cook at home?"]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (
      lesson_id,
      activity_type,
      activity_order,
      title,
      description,
      content
    ) VALUES (
      'A1-L16',
      'speaking_improvement',
      10,
      'Speaking Improvement',
      'Read the improved version of your speech',
      '{"type": "speaking_improvement", "similarityThreshold": 70}'::jsonb
    );
END $$;

