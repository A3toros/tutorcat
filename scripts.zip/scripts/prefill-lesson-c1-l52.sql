-- =========================================
-- Pre-fill Database with Sample Lesson Data
-- C1-L52: Environmental Activism Among Youth
-- =========================================
DELETE FROM lesson_activity_results WHERE lesson_id = 'C1-L52';
DELETE FROM user_progress WHERE lesson_id = 'C1-L52';
DELETE FROM lesson_history WHERE lesson_id = 'C1-L52';
DELETE FROM grammar_sentences WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'C1-L52');
DELETE FROM vocabulary_items WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'C1-L52');
DELETE FROM lesson_activities WHERE lesson_id = 'C1-L52';
DELETE FROM lessons WHERE id = 'C1-L52';

INSERT INTO lessons (id, level, lesson_number, topic) VALUES
('C1-L52', 'C1', 52, 'Environmental Activism Among Youth')
ON CONFLICT (id) DO UPDATE SET topic = EXCLUDED.topic;

DO $$
DECLARE
    lesson_id_var TEXT := 'C1-L52';
    activity_id_var UUID;
BEGIN
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'warm_up_speaking', 1, 'Environmental Activism', 'Discuss environmental activism', '{"prompt": "When have you taken action for the environment?"}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_intro', 2, 'Activism Vocabulary', 'Learn vocabulary about activism', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'activism', 'การเคลื่อนไหว', NULL),
    (activity_id_var, 'action', 'การกระทำ', NULL),
    (activity_id_var, 'engagement', 'การมีส่วนร่วม', NULL),
    (activity_id_var, 'motivation', 'แรงจูงใจ', NULL),
    (activity_id_var, 'barrier', 'อุปสรรค', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_matching_drag', 3, 'Match Activism Words', 'Match English words with Thai meanings', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'activism', 'การเคลื่อนไหว', NULL),
    (activity_id_var, 'action', 'การกระทำ', NULL),
    (activity_id_var, 'engagement', 'การมีส่วนร่วม', NULL),
    (activity_id_var, 'motivation', 'แรงจูงใจ', NULL),
    (activity_id_var, 'barrier', 'อุปสรรค', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 4, 'Complete the Sentences 1', 'Fill with the correct word', '{"text": "Youth ___ drives change. Environmental ___ requires ___.", "blanks": [{"id": "blank1", "text": "activism", "options": ["activism", "action", "engagement", "motivation"], "correctAnswer": "activism"}, {"id": "blank2", "text": "action", "options": ["action", "activism", "engagement", "motivation"], "correctAnswer": "action"}, {"id": "blank3", "text": "commitment", "options": ["commitment", "activism", "action", "engagement"], "correctAnswer": "commitment"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 5, 'Complete the Sentences 2', 'Fill with the correct word', '{"text": "Strong ___ supports ___. ___ prevent young people from acting.", "blanks": [{"id": "blank1", "text": "motivation", "options": ["motivation", "activism", "action", "engagement"], "correctAnswer": "motivation"}, {"id": "blank2", "text": "engagement", "options": ["engagement", "activism", "action", "motivation"], "correctAnswer": "engagement"}, {"id": "blank3", "text": "Barriers", "options": ["Barriers", "Activism", "Action", "Motivation"], "correctAnswer": "Barriers"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_explanation', 6, 'Inversion: Seldom/Rarely', 'Learn inversion with seldom and rarely', '{"rules": "Inversion with seldom/rarely:\n- \"Seldom do young people take action.\" (formal emphasis)\n- \"Rarely have I seen such activism.\" (past emphasis)\n- \"Seldom is environmental action easy.\" (emphasis on difficulty)\n\nStructure:\n- Seldom/Rarely + auxiliary + subject + verb\n- Used for emphasis and formal tone\n\nUse for:\n- Emphasizing rarity: \"Seldom do youth engage in activism.\"\n- Formal statements: \"Rarely have I witnessed such commitment.\"\n- Highlighting infrequency: \"Seldom is environmental action taken.\"", "examples": ["Seldom do young people take environmental action.", "Rarely have I seen such youth activism.", "Seldom is environmental engagement easy.", "Rarely do barriers prevent determined youth.", "Seldom have I witnessed such commitment."]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 7, 'Build Sentences 1', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'Seldom do young people take environmental action.', 'Seldom do young people take environmental action.', '["Seldom", "do", "young", "people", "take", "environmental", "action."]'::jsonb),
    (activity_id_var, 'Rarely have I seen such youth activism.', 'Rarely have I seen such youth activism.', '["Rarely", "have", "I", "seen", "such", "youth", "activism."]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 8, 'Build Sentences 2', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'Seldom is environmental engagement easy.', 'Seldom is environmental engagement easy.', '["Seldom", "is", "environmental", "engagement", "easy."]'::jsonb),
    (activity_id_var, 'Rarely do barriers prevent determined youth.', 'Rarely do barriers prevent determined youth.', '["Rarely", "do", "barriers", "prevent", "determined", "youth."]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'speaking_practice', 9, 'Discuss Environmental Activism', 'Practice speaking about environmental activism', '{"prompts": ["When have you taken action?", "What stopped you from acting more?", "How do young people engage in environmental activism?", "What motivates youth environmental action?", "What barriers prevent young people from acting?"]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (
      lesson_id,
      activity_type,
      activity_order,
      title,
      description,
      content
    ) VALUES (
      'C1-L52',
      'speaking_improvement',
      10,
      'Speaking Improvement',
      'Read the improved version of your speech',
      '{"type": "speaking_improvement", "similarityThreshold": 70}'::jsonb
    );
END $$;
