-- =========================================
-- Pre-fill Database with Sample Lesson Data
-- A2-L90: Talking About Age
-- =========================================

DELETE FROM grammar_sentences WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'A2-L90');
DELETE FROM vocabulary_items WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'A2-L90');
DELETE FROM lesson_activities WHERE lesson_id = 'A2-L90';
DELETE FROM lessons WHERE id = 'A2-L90';

INSERT INTO lessons (id, level, lesson_number, topic) VALUES
('A2-L90', 'A2', 90, 'Talking About Age')
ON CONFLICT (id) DO UPDATE SET topic = EXCLUDED.topic;

DO $$
DECLARE
    lesson_id_var TEXT := 'A2-L90';
    activity_id_var UUID;
BEGIN
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'warm_up_speaking', 1, 'Age Questions', 'Talk about age politely', '{"prompt": "How old are you?"}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_intro', 2, 'Age Words', 'Learn words about age', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'age', 'อายุ', NULL),
    (activity_id_var, 'old', 'แก่/อายุ', NULL),
    (activity_id_var, 'young', 'อายุน้อย', NULL),
    (activity_id_var, 'birthday', 'วันเกิด', NULL),
    (activity_id_var, 'year', 'ปี', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_matching_drag', 3, 'Match Age Words', 'Match age words', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'age', 'อายุ', NULL),
    (activity_id_var, 'old', 'แก่/อายุ', NULL),
    (activity_id_var, 'young', 'อายุน้อย', NULL),
    (activity_id_var, 'birthday', 'วันเกิด', NULL),
    (activity_id_var, 'year', 'ปี', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 4, 'Complete the Sentences 1', 'Fill with the correct word', '{"text": "How ___ are you? My ___ is in May. I am 25 ___ old.", "blanks": [{"id": "blank1", "text": "old", "options": ["old", "age", "birthday", "year"], "correctAnswer": "old"}, {"id": "blank2", "text": "birthday", "options": ["birthday", "age", "year", "young"], "correctAnswer": "birthday"}, {"id": "blank3", "text": "years", "options": ["years", "old", "age", "young"], "correctAnswer": "years"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 5, 'Complete the Sentences 2', 'Fill with the correct word', '{"text": "He is very ___. She is ___. My ___ is 30.", "blanks": [{"id": "blank1", "text": "young", "options": ["young", "old", "age", "birthday"], "correctAnswer": "young"}, {"id": "blank2", "text": "old", "options": ["old", "young", "age", "birthday"], "correctAnswer": "old"}, {"id": "blank3", "text": "age", "options": ["age", "birthday", "year", "young"], "correctAnswer": "age"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_explanation', 6, 'Questions with How + old', 'Ask and answer age politely', '{"rules": "Use How old + be to ask age.\n- How old are you?\nAnswers: I am 25 years old. She is 30.\nUse in sentences: My brother is 20.", "examples": ["How old are you?", "I am 25 years old.", "How old is she?", "She is 30.", "My birthday is in May."]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 7, 'Build Sentences 1', 'Arrange words', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'How old are you', 'How old are you?', '["How", "old", "are", "you?"]'::jsonb),
    (activity_id_var, 'I am twenty five years old', 'I am twenty five years old.', '["I", "am", "twenty", "five", "years", "old."]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 8, 'Build Sentences 2', 'Arrange words', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'How old is she', 'How old is she?', '["How", "old", "is", "she?"]'::jsonb),
    (activity_id_var, 'My birthday is in May', 'My birthday is in May.', '["My", "birthday", "is", "in", "May."]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'speaking_practice', 9, 'Talk About Age', 'Practice polite age questions', '{"prompts": ["How old are you?", "When is your birthday?", "Do you feel older or younger than your friends?", "How do you usually celebrate birthdays?", "What age do you think is the best, and why?"]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (
      lesson_id,
      activity_type,
      activity_order,
      title,
      description,
      content
    ) VALUES (
      'A2-L90',
      'speaking_improvement',
      10,
      'Speaking Improvement',
      'Read the improved version of your speech',
      '{"type": "speaking_improvement", "similarityThreshold": 70}'::jsonb
    );
END $$;

