-- =========================================
-- Pre-fill Database with Sample Lesson Data
-- B1-L90: Wrap-Up Mix
-- =========================================

DELETE FROM grammar_sentences WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'B1-L90');
DELETE FROM vocabulary_items WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'B1-L90');
DELETE FROM lesson_activities WHERE lesson_id = 'B1-L90';
DELETE FROM lessons WHERE id = 'B1-L90';

INSERT INTO lessons (id, level, lesson_number, topic) VALUES
('B1-L90', 'B1', 90, 'Wrap-Up Mix')
ON CONFLICT (id) DO UPDATE SET topic = EXCLUDED.topic;

DO $$
DECLARE
    lesson_id_var TEXT := 'B1-L90';
    activity_id_var UUID;
BEGIN
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'warm_up_speaking', 1, 'Looking Back', 'Talk about what helped you most', '{"prompt": "Which topic was most useful to you?"}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_intro', 2, 'Review Words', 'Review key words from the course', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'review', 'ทบทวน', NULL),
    (activity_id_var, 'improve', 'ปรับปรุง', NULL),
    (activity_id_var, 'practice', 'ฝึกฝน', NULL),
    (activity_id_var, 'confident', 'มั่นใจ', NULL),
    (activity_id_var, 'progress', 'ความก้าวหน้า', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_matching_drag', 3, 'Match Review Words', 'Match words with meanings', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'review', 'ทบทวน', NULL),
    (activity_id_var, 'improve', 'ปรับปรุง', NULL),
    (activity_id_var, 'practice', 'ฝึกฝน', NULL),
    (activity_id_var, 'confident', 'มั่นใจ', NULL),
    (activity_id_var, 'progress', 'ความก้าวหน้า', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 4, 'Complete the Sentences 1', 'Fill with the correct word', '{"text": "I ___ key lessons. I want to ___. Daily ___ builds skill.", "blanks": [{"id": "blank1", "text": "review", "options": ["review", "improve", "practice", "progress"], "correctAnswer": "review"}, {"id": "blank2", "text": "improve", "options": ["improve", "practice", "confident", "progress"], "correctAnswer": "improve"}, {"id": "blank3", "text": "practice", "options": ["practice", "progress", "review", "confident"], "correctAnswer": "practice"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 5, 'Complete the Sentences 2', 'Fill with the correct word', '{"text": "I feel more ___. I see my ___. I will ___ every week.", "blanks": [{"id": "blank1", "text": "confident", "options": ["confident", "review", "practice", "progress"], "correctAnswer": "confident"}, {"id": "blank2", "text": "progress", "options": ["progress", "improve", "review", "practice"], "correctAnswer": "progress"}, {"id": "blank3", "text": "review", "options": ["review", "practice", "progress", "improve"], "correctAnswer": "review"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    -- Grammar Explanation: Mixed Review (relative, conditional, modals)
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_explanation', 6, 'Mixed Grammar Review', 'Refresh key patterns: relative clauses, conditionals, modals', '{"rules": "Review: Relative clauses (who/which/that) for essential info; First conditional (if + present, will + base) for likely results; Modals should/must for advice/necessity. Use clear punctuation and no contractions.", "examples": ["This is the topic that helped me most.", "If I review weekly, I will improve faster.", "You should keep practicing speaking.", "We must set realistic goals to see progress.", "The exercise that I enjoyed was speaking practice."]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 7, 'Build Sentences 1', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'This is the topic that helped me most', 'This is the topic that helped me most', '["This", "is", "the", "topic", "that", "helped", "me", "most"]'::jsonb),
    (activity_id_var, 'If I review weekly I will improve faster', 'If I review weekly, I will improve faster', '["If", "I", "review", "weekly,", "I", "will", "improve", "faster"]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 8, 'Build Sentences 2', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'You should keep practicing speaking', 'You should keep practicing speaking', '["You", "should", "keep", "practicing", "speaking"]'::jsonb),
    (activity_id_var, 'We must set realistic goals to see progress', 'We must set realistic goals to see progress', '["We", "must", "set", "realistic", "goals", "to", "see", "progress"]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'speaking_practice', 9, 'Talk About Your Progress', 'Reflect on what worked and what is next', '{"prompts": ["Which topic was most useful to you?", "What will you practice next?", "How did your skills actually improve?"]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (
      lesson_id,
      activity_type,
      activity_order,
      title,
      description,
      content
    ) VALUES (
      'B1-L90',
      'speaking_improvement',
      10,
      'Speaking Improvement',
      'Read the improved version of your speech',
      '{"type": "speaking_improvement", "similarityThreshold": 70}'::jsonb
    );
END $$;

