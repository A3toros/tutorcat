-- =========================================
-- Pre-fill Database with Sample Lesson Data
-- A1-L35: Zoo and Farm Animals
-- =========================================

DELETE FROM grammar_sentences WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'A1-L35');
DELETE FROM vocabulary_items WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'A1-L35');
DELETE FROM lesson_activities WHERE lesson_id = 'A1-L35';
DELETE FROM lessons WHERE id = 'A1-L35';

INSERT INTO lessons (id, level, lesson_number, topic) VALUES
('A1-L35', 'A1', 35, 'Zoo and Farm Animals')
ON CONFLICT (id) DO UPDATE SET topic = EXCLUDED.topic;

DO $$
DECLARE
    lesson_id_var TEXT := 'A1-L35';
    activity_id_var UUID;
BEGIN
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'warm_up_speaking', 1, 'Animals', 'Talk about animals', '{"prompt": "Do you like cows?"}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_intro', 2, 'Animal Words', 'Learn zoo and farm animals', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'elephant', 'ช้าง', NULL),
    (activity_id_var, 'cow', 'วัว', NULL),
    (activity_id_var, 'pig', 'หมู', NULL),
    (activity_id_var, 'tiger', 'เสือ', NULL),
    (activity_id_var, 'monkey', 'ลิง', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_matching_drag', 3, 'Match Animal Words', 'Match animal words', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'elephant', 'ช้าง', NULL),
    (activity_id_var, 'cow', 'วัว', NULL),
    (activity_id_var, 'pig', 'หมู', NULL),
    (activity_id_var, 'tiger', 'เสือ', NULL),
    (activity_id_var, 'monkey', 'ลิง', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 4, 'Complete the Sentences 1', 'Fill with the correct word', '{"text": "The ___ is big. The ___ is small.", "blanks": [{"id": "blank1", "text": "elephant", "options": ["elephant", "cow", "pig", "monkey"], "correctAnswer": "elephant"}, {"id": "blank2", "text": "pig", "options": ["pig", "cow", "tiger", "monkey"], "correctAnswer": "pig"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 5, 'Complete the Sentences 2', 'Fill with the correct word', '{"text": "The ___ is strong. The ___ is funny.", "blanks": [{"id": "blank1", "text": "tiger", "options": ["tiger", "cow", "pig", "monkey"], "correctAnswer": "tiger"}, {"id": "blank2", "text": "monkey", "options": ["monkey", "elephant", "pig", "cow"], "correctAnswer": "monkey"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_explanation', 6, 'Be + Animals', 'Use be to describe animals', '{"rules": "Use be with animals and adjectives.\n- The tiger is big.\n- Cows are strong.\nAsk: Is the pig small?", "examples": ["The tiger is big.", "The cow is strong.", "The elephant is large.", "Is the pig small?", "Are monkeys funny?"]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 7, 'Build Sentences 1', 'Arrange words', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'The tiger is big', 'The tiger is big.', '["The", "tiger", "is", "big."]'::jsonb),
    (activity_id_var, 'The cow is strong', 'The cow is strong.', '["The", "cow", "is", "strong."]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 8, 'Build Sentences 2', 'Arrange words', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'Is the pig small', 'Is the pig small?', '["Is", "the", "pig", "small?"]'::jsonb),
    (activity_id_var, 'Are monkeys funny', 'Are monkeys funny?', '["Are", "monkeys", "funny?"]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'speaking_practice', 9, 'Talk About Animals', 'Practice animal be sentences', '{"prompts": ["Do you like cows?", "Is the tiger big?", "Is the pig small?", "Are monkeys funny?", "Do you like elephants?"]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (
      lesson_id,
      activity_type,
      activity_order,
      title,
      description,
      content
    ) VALUES (
      'A1-L35',
      'speaking_improvement',
      10,
      'Speaking Improvement',
      'Read the improved version of your speech',
      '{"type": "speaking_improvement", "similarityThreshold": 70}'::jsonb
    );
END $$;

