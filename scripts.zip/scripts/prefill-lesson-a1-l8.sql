-- =========================================
-- Pre-fill Database with Sample Lesson Data
-- A1-L8: Numbers, Dates & Time
-- =========================================

-- Clear existing sample data for A1-L8 (optional - comment out if you want to keep existing data)
DELETE FROM grammar_sentences WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'A1-L8');
DELETE FROM vocabulary_items WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'A1-L8');
DELETE FROM lesson_activities WHERE lesson_id = 'A1-L8';
DELETE FROM lessons WHERE id = 'A1-L8';

INSERT INTO lessons (id, level, lesson_number, topic) VALUES
('A1-L8', 'A1', 8, 'Numbers, Dates & Time')
ON CONFLICT (id) DO UPDATE SET topic = EXCLUDED.topic;

DO $$
DECLARE
    lesson_id_var TEXT := 'A1-L8';
    activity_id_var UUID;
BEGIN
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content) VALUES (lesson_id_var, 'warm_up_speaking', 1, 'Time and Dates', 'Talk about time', '{"prompt": "What time do you usually wake up?"}'::jsonb) RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content) VALUES (lesson_id_var, 'vocabulary_intro', 2, 'Time Words', 'Learn time vocabulary', '{}'::jsonb) RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'morning', 'เช้า', NULL),
    (activity_id_var, 'afternoon', 'บ่าย', NULL),
    (activity_id_var, 'evening', 'เย็น', NULL),
    (activity_id_var, 'night', 'กลางคืน', NULL),
    (activity_id_var, 'weekend', 'วันหยุดสุดสัปดาห์', NULL);

    -- 3. Vocabulary Matching Drag #1 (5 pairs - same words)
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content) VALUES (lesson_id_var, 'vocabulary_matching_drag', 3, 'Match Time Words 1', 'Match English words with Thai meanings', '{}'::jsonb) RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'morning', 'เช้า', NULL),
    (activity_id_var, 'afternoon', 'บ่าย', NULL),
    (activity_id_var, 'evening', 'เย็น', NULL),
    (activity_id_var, 'night', 'กลางคืน', NULL),
    (activity_id_var, 'weekend', 'วันหยุดสุดสัปดาห์', NULL);

    

    -- 4. Vocabulary Fill Blanks #1 (4 words: morning, afternoon, evening, night - weekend left out)
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content) VALUES (lesson_id_var, 'vocabulary_fill_blanks', 4, 'Complete the Sentences 1', 'Fill in the blanks with correct words', '{"text": "I wake up in the ___. I have lunch in the ___. I relax in the ___. I sleep at ___.", "blanks": [{"id": "blank1", "text": "morning", "options": ["morning", "afternoon", "evening", "night"], "correctAnswer": "morning"}, {"id": "blank2", "text": "afternoon", "options": ["morning", "afternoon", "evening", "night"], "correctAnswer": "afternoon"}, {"id": "blank3", "text": "evening", "options": ["morning", "afternoon", "evening", "night"], "correctAnswer": "evening"}, {"id": "blank4", "text": "night", "options": ["morning", "afternoon", "evening", "night"], "correctAnswer": "night"}]}'::jsonb) RETURNING id INTO activity_id_var;

    -- 4. Vocabulary Fill Blanks #2 (4 words: morning, afternoon, evening, weekend - night left out)
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content) VALUES (lesson_id_var, 'vocabulary_fill_blanks', 5, 'Complete the Sentences 2', 'Fill in the blanks with correct words', '{"text": "I work in the ___. I have a break in the ___. I watch TV in the ___. I rest on the ___.", "blanks": [{"id": "blank1", "text": "morning", "options": ["morning", "afternoon", "evening", "weekend"], "correctAnswer": "morning"}, {"id": "blank2", "text": "afternoon", "options": ["morning", "afternoon", "evening", "weekend"], "correctAnswer": "afternoon"}, {"id": "blank3", "text": "evening", "options": ["morning", "afternoon", "evening", "weekend"], "correctAnswer": "evening"}, {"id": "blank4", "text": "weekend", "options": ["morning", "afternoon", "evening", "weekend"], "correctAnswer": "weekend"}]}'::jsonb) RETURNING id INTO activity_id_var;

    -- 4. Grammar Explanation (5 examples)
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content) VALUES (lesson_id_var, 'grammar_explanation', 6, 'Telling Time', 'Learn to tell time', '{"rules": "Use ''It is'' or ''It''''s'' to tell time:\n\n- It is + hour + PM (It is 3 PM)\n- It is + hour + minutes (It is 3:30)\n- Use ''at'' for specific times (at 9 AM)\n- Use ''in'' for parts of day (in the morning)\n- Use ''on'' for days (on Monday)", "examples": ["It is 3 PM.", "It is 3:30 PM.", "I wake up at 7 AM.", "I work in the morning.", "I sleep at night."]}'::jsonb) RETURNING id INTO activity_id_var;

    -- 4. Grammar Sentences #1
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content) VALUES (lesson_id_var, 'grammar_sentences', 7, 'Build Sentences 1', 'Arrange words to make sentences', '{}'::jsonb) RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'It is three PM', 'It is three PM', '["It", "is", "three", "PM"]'::jsonb),
    (activity_id_var, 'I wake up at seven AM', 'I wake up at 7 AM', '["I", "wake", "up", "at", "7", "AM"]'::jsonb);
    -- 4. Grammar Sentences #2
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content) VALUES (lesson_id_var, 'grammar_sentences', 8, 'Build Sentences 2', 'Arrange words to make sentences', '{}'::jsonb) RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'I work in the morning', 'I work in the morning', '["I", "work", "in", "the", "morning"]'::jsonb),
    (activity_id_var, 'I sleep at night', 'I sleep at night', '["I", "sleep", "at", "night"]'::jsonb);
    -- 4. Speaking Practice (5 prompts - CEFR A1)
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content) VALUES (lesson_id_var, 'speaking_practice', 9, 'Talk About Time', 'Practice talking about time', '{"prompts": ["What time is it now?", "What time do you wake up?", "When do you have lunch?", "What time do you go to bed?", "What do you do on weekends?"]}'::jsonb) RETURNING id INTO activity_id_var;

END $$;
