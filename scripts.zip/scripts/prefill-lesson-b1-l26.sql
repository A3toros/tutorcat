-- =========================================
-- Pre-fill Database with Sample Lesson Data
-- B1-L26: Recycling & Waste
-- =========================================

DELETE FROM grammar_sentences WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'B1-L26');
DELETE FROM vocabulary_items WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'B1-L26');
DELETE FROM lesson_activities WHERE lesson_id = 'B1-L26';
DELETE FROM lessons WHERE id = 'B1-L26';

INSERT INTO lessons (id, level, lesson_number, topic) VALUES
('B1-L26', 'B1', 26, 'Recycling & Waste')
ON CONFLICT (id) DO UPDATE SET topic = EXCLUDED.topic;

DO $$
DECLARE
    lesson_id_var TEXT := 'B1-L26';
    activity_id_var UUID;
BEGIN
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'warm_up_speaking', 1, 'Waste Handling', 'Talk about recycling rules and habits', '{"prompt": "How is trash really handled where you live?"}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_intro', 2, 'Recycling Words', 'Learn vocabulary about recycling and waste', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'sorted', 'แยกประเภท', NULL),
    (activity_id_var, 'collected', 'เก็บรวบรวม', NULL),
    (activity_id_var, 'recycled', 'รีไซเคิล', NULL),
    (activity_id_var, 'banned', 'ถูกห้าม', NULL),
    (activity_id_var, 'reduced', 'ถูกลดลง', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_matching_drag', 3, 'Match Recycling Words', 'Match words with meanings', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'sorted', 'แยกประเภท', NULL),
    (activity_id_var, 'collected', 'เก็บรวบรวม', NULL),
    (activity_id_var, 'recycled', 'รีไซเคิล', NULL),
    (activity_id_var, 'banned', 'ถูกห้าม', NULL),
    (activity_id_var, 'reduced', 'ถูกลดลง', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 4, 'Complete the Sentences 1', 'Fill with the correct word', '{"text": "Plastic was ___ by type. Waste was ___ early. Glass was ___ later.", "blanks": [{"id": "blank1", "text": "sorted", "options": ["sorted", "collected", "recycled", "banned"], "correctAnswer": "sorted"}, {"id": "blank2", "text": "collected", "options": ["collected", "sorted", "recycled", "banned"], "correctAnswer": "collected"}, {"id": "blank3", "text": "recycled", "options": ["recycled", "collected", "sorted", "banned"], "correctAnswer": "recycled"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 5, 'Complete the Sentences 2', 'Fill with the correct word', '{"text": "Single-use bags were ___. Trash was ___ by new rules. Use was ___ in many shops.", "blanks": [{"id": "blank1", "text": "banned", "options": ["banned", "reduced", "sorted", "recycled"], "correctAnswer": "banned"}, {"id": "blank2", "text": "reduced", "options": ["reduced", "banned", "collected", "sorted"], "correctAnswer": "reduced"}, {"id": "blank3", "text": "reduced", "options": ["reduced", "recycled", "banned", "sorted"], "correctAnswer": "reduced"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    -- Grammar Explanation: Passive Voice (Past)
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_explanation', 6, 'Passive Voice (Past)', 'Use was/were + past participle to describe past processes and rules', '{"rules": "Passive past: was/were + past participle for actions done to the object.\\n- Trash was sorted last night.\\n- Bags were banned in 2022.\\nUse to focus on action, not actor. Avoid contractions.", "examples": ["Trash was sorted by volunteers.", "Bottles were collected early.", "Rules were enforced last year.", "Waste was reduced by new policies.", "Plastic bags were banned in many stores."]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 7, 'Build Sentences 1', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'Trash was sorted by volunteers', 'Trash was sorted by volunteers', '["Trash", "was", "sorted", "by", "volunteers"]'::jsonb),
    (activity_id_var, 'Bottles were collected early', 'Bottles were collected early', '["Bottles", "were", "collected", "early"]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 8, 'Build Sentences 2', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'Rules were enforced last year', 'Rules were enforced last year', '["Rules", "were", "enforced", "last", "year"]'::jsonb),
    (activity_id_var, 'Plastic bags were banned in many stores', 'Plastic bags were banned in many stores', '["Plastic", "bags", "were", "banned", "in", "many", "stores"]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'speaking_practice', 9, 'Talk About Recycling', 'Practice talking about recycling and rules', '{"prompts": ["How is trash really handled where you live?", "What rule changed your recycling habits?", "Which new rule would help most?"]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (
      lesson_id,
      activity_type,
      activity_order,
      title,
      description,
      content
    ) VALUES (
      'B1-L26',
      'speaking_improvement',
      10,
      'Speaking Improvement',
      'Read the improved version of your speech',
      '{"type": "speaking_improvement", "similarityThreshold": 70}'::jsonb
    );
END $$;

