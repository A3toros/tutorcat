-- =========================================
-- Pre-fill Database with Sample Lesson Data
-- C1-L12: Plagiarism & Academic Integrity
-- =========================================

DELETE FROM grammar_sentences WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'C1-L12');
DELETE FROM vocabulary_items WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'C1-L12');
DELETE FROM lesson_activities WHERE lesson_id = 'C1-L12';
DELETE FROM lessons WHERE id = 'C1-L12';

INSERT INTO lessons (id, level, lesson_number, topic) VALUES
('C1-L12', 'C1', 12, 'Plagiarism & Academic Integrity')
ON CONFLICT (id) DO UPDATE SET topic = EXCLUDED.topic;

DO $$
DECLARE
    lesson_id_var TEXT := 'C1-L12';
    activity_id_var UUID;
BEGIN
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'warm_up_speaking', 1, 'Academic Integrity', 'Discuss academic integrity', '{"prompt": "How should plagiarism be handled in schools?"}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_intro', 2, 'Academic Integrity Vocabulary', 'Learn vocabulary about plagiarism and integrity', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'plagiarism', 'การลอกเลียน', NULL),
    (activity_id_var, 'citation', 'การอ้างอิง', NULL),
    (activity_id_var, 'attribution', 'การให้เครดิต', NULL),
    (activity_id_var, 'sanction', 'การลงโทษ', NULL),
    (activity_id_var, 'violation', 'การละเมิด', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_matching_drag', 3, 'Match Academic Integrity Words', 'Match English words with Thai meanings', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'plagiarism', 'การลอกเลียน', NULL),
    (activity_id_var, 'citation', 'การอ้างอิง', NULL),
    (activity_id_var, 'attribution', 'การให้เครดิต', NULL),
    (activity_id_var, 'sanction', 'การลงโทษ', NULL),
    (activity_id_var, 'violation', 'การละเมิด', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 4, 'Complete the Sentences 1', 'Fill with the correct word', '{"text": "___ is a serious academic ___. Proper ___ is required for all sources.", "blanks": [{"id": "blank1", "text": "Plagiarism", "options": ["Plagiarism", "Citation", "Attribution", "Sanction"], "correctAnswer": "Plagiarism"}, {"id": "blank2", "text": "violation", "options": ["violation", "citation", "attribution", "sanction"], "correctAnswer": "violation"}, {"id": "blank3", "text": "citation", "options": ["citation", "plagiarism", "attribution", "sanction"], "correctAnswer": "citation"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 5, 'Complete the Sentences 2', 'Fill with the correct word', '{"text": "Correct ___ gives credit to original authors. Academic ___ may include suspension.", "blanks": [{"id": "blank1", "text": "attribution", "options": ["attribution", "citation", "plagiarism", "violation"], "correctAnswer": "attribution"}, {"id": "blank2", "text": "sanctions", "options": ["sanctions", "violations", "citations", "attributions"], "correctAnswer": "sanctions"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_explanation', 6, 'Advanced Passives: Reporting Structures', 'Learn advanced passive forms in reporting', '{"rules": "Advanced passive reporting structures:\n- \"It is said/reported/believed that...\" (impersonal)\n- \"X is said/reported/believed to...\" (personal)\n- \"X should be enforced/held accountable\" (obligation)\n- \"X must be maintained/upheld\" (necessity)\n\nUse when the focus is on the action, not the doer:\n- \"Integrity should be enforced by institutions.\"\n- \"It is believed that sanctions deter violations.\"", "examples": ["It is reported that plagiarism cases have increased.", "Students are expected to maintain academic integrity.", "Sanctions should be enforced fairly.", "It is believed that proper citation prevents violations.", "Academic standards must be upheld by all."]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 7, 'Build Sentences 1', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'It is reported that plagiarism has increased significantly.', 'It is reported that plagiarism has increased significantly.', '["It", "is", "reported", "that", "plagiarism", "has", "increased", "significantly."]'::jsonb),
    (activity_id_var, 'Academic integrity should be enforced by all institutions.', 'Academic integrity should be enforced by all institutions.', '["Academic", "integrity", "should", "be", "enforced", "by", "all", "institutions."]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 8, 'Build Sentences 2', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'Students are expected to provide proper attribution.', 'Students are expected to provide proper attribution.', '["Students", "are", "expected", "to", "provide", "proper", "attribution."]'::jsonb),
    (activity_id_var, 'It is believed that sanctions deter future violations.', 'It is believed that sanctions deter future violations.', '["It", "is", "believed", "that", "sanctions", "deter", "future", "violations."]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'speaking_practice', 9, 'Discuss Academic Integrity', 'Practice speaking about plagiarism and integrity', '{"prompts": ["What actions are considered plagiarism?", "Why is plagiarism taken seriously?", "How can students avoid academic dishonesty?", "When is punishment fair or unfair?", "What consequences are appropriate for violations?"]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (
      lesson_id,
      activity_type,
      activity_order,
      title,
      description,
      content
    ) VALUES (
      'C1-L12',
      'speaking_improvement',
      10,
      'Speaking Improvement',
      'Read the improved version of your speech',
      '{"type": "speaking_improvement", "similarityThreshold": 70}'::jsonb
    );
END $$;
