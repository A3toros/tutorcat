-- =========================================
-- Pre-fill Database with Sample Lesson Data
-- A2-L47: Giving Presents
-- =========================================

DELETE FROM grammar_sentences WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'A2-L47');
DELETE FROM vocabulary_items WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'A2-L47');
DELETE FROM lesson_activities WHERE lesson_id = 'A2-L47';
DELETE FROM lessons WHERE id = 'A2-L47';

INSERT INTO lessons (id, level, lesson_number, topic) VALUES
('A2-L47', 'A2', 47, 'Giving Presents')
ON CONFLICT (id) DO UPDATE SET topic = EXCLUDED.topic;

DO $$
DECLARE
    lesson_id_var TEXT := 'A2-L47';
    activity_id_var UUID;
BEGIN
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'warm_up_speaking', 1, 'Gift Plans', 'Talk about giving gifts', '{"prompt": "Who are you going to give a present to next?"}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_intro', 2, 'Gift Words', 'Learn gift-giving vocabulary', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'gift', 'ของขวัญ', NULL),
    (activity_id_var, 'wrap', 'ห่อ', NULL),
    (activity_id_var, 'card', 'การ์ด', NULL),
    (activity_id_var, 'surprise', 'เซอร์ไพรส์', NULL),
    (activity_id_var, 'choose', 'เลือก', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_matching_drag', 3, 'Match Gift Words', 'Match gift words', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'gift', 'ของขวัญ', NULL),
    (activity_id_var, 'wrap', 'ห่อ', NULL),
    (activity_id_var, 'card', 'การ์ด', NULL),
    (activity_id_var, 'surprise', 'เซอร์ไพรส์', NULL),
    (activity_id_var, 'choose', 'เลือก', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 4, 'Complete the Sentences 1', 'Fill with the correct word', '{"text": "I will buy a ___. I will ___ it and add a ___.", "blanks": [{"id": "blank1", "text": "gift", "options": ["gift", "wrap", "card", "surprise"], "correctAnswer": "gift"}, {"id": "blank2", "text": "wrap", "options": ["wrap", "card", "choose", "gift"], "correctAnswer": "wrap"}, {"id": "blank3", "text": "card", "options": ["card", "gift", "surprise", "wrap"], "correctAnswer": "card"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 5, 'Complete the Sentences 2', 'Fill with the correct word', '{"text": "I want to ___ my friend. I will ___ a nice present.", "blanks": [{"id": "blank1", "text": "surprise", "options": ["surprise", "choose", "wrap", "gift"], "correctAnswer": "surprise"}, {"id": "blank2", "text": "choose", "options": ["choose", "surprise", "card", "wrap"], "correctAnswer": "choose"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_explanation', 6, 'Going to (Future Plans)', 'Talk about planned gifts', '{"rules": "Use going to for future plans.\n- I am going to buy a gift.\n- She is going to wrap it.\nForm: am/is/are + going to + verb.", "examples": ["I am going to buy a gift tomorrow.", "She is going to wrap it tonight.", "We are going to surprise him.", "Are you going to add a card?", "They are going to choose something small."]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 7, 'Build Sentences 1', 'Arrange words', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'I am going to buy a gift tomorrow', 'I am going to buy a gift tomorrow.', '["I", "am", "going", "to", "buy", "a", "gift", "tomorrow."]'::jsonb),
    (activity_id_var, 'She is going to wrap it tonight', 'She is going to wrap it tonight.', '["She", "is", "going", "to", "wrap", "it", "tonight."]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 8, 'Build Sentences 2', 'Arrange words', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'Are you going to add a card', 'Are you going to add a card?', '["Are", "you", "going", "to", "add", "a", "card?"]'::jsonb),
    (activity_id_var, 'They are going to choose something small', 'They are going to choose something small.', '["They", "are", "going", "to", "choose", "something", "small."]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'speaking_practice', 9, 'Talk About Gifts', 'Practice gift plans', '{"prompts": ["Who are you going to give a present to next?", "What kind of gift are you going to buy?", "When are you going to give it?", "How do you usually choose presents?", "Do you prefer giving or receiving gifts?"]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (
      lesson_id,
      activity_type,
      activity_order,
      title,
      description,
      content
    ) VALUES (
      'A2-L47',
      'speaking_improvement',
      10,
      'Speaking Improvement',
      'Read the improved version of your speech',
      '{"type": "speaking_improvement", "similarityThreshold": 70}'::jsonb
    );
END $$;

