-- =========================================
-- Pre-fill Database with Sample Lesson Data
-- C1-L23: Bias in News Reporting
-- =========================================
DELETE FROM lesson_activity_results WHERE lesson_id = 'C1-L23';
DELETE FROM user_progress WHERE lesson_id = 'C1-L23';
DELETE FROM lesson_history WHERE lesson_id = 'C1-L23';
DELETE FROM grammar_sentences WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'C1-L23');
DELETE FROM vocabulary_items WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'C1-L23');
DELETE FROM lesson_activities WHERE lesson_id = 'C1-L23';
DELETE FROM lessons WHERE id = 'C1-L23';

INSERT INTO lessons (id, level, lesson_number, topic) VALUES
('C1-L23', 'C1', 23, 'Bias in News Reporting')
ON CONFLICT (id) DO UPDATE SET topic = EXCLUDED.topic;

DO $$
DECLARE
    lesson_id_var TEXT := 'C1-L23';
    activity_id_var UUID;
BEGIN
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'warm_up_speaking', 1, 'Media Bias', 'Discuss bias in news reporting', '{"prompt": "How confident are you in detecting media bias?"}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_intro', 2, 'Bias Vocabulary', 'Learn vocabulary about bias', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'prejudice', 'อคติ', NULL),
    (activity_id_var, 'partiality', 'ความลำเอียง', NULL),
    (activity_id_var, 'objectivity', 'ความเป็นกลาง', NULL),
    (activity_id_var, 'distortion', 'การบิดเบือน', NULL),
    (activity_id_var, 'fairness', 'ความยุติธรรม', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_matching_drag', 3, 'Match Bias Words', 'Match English words with Thai meanings', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'prejudice', 'อคติ', NULL),
    (activity_id_var, 'partiality', 'ความลำเอียง', NULL),
    (activity_id_var, 'objectivity', 'ความเป็นกลาง', NULL),
    (activity_id_var, 'distortion', 'การบิดเบือน', NULL),
    (activity_id_var, 'fairness', 'ความยุติธรรม', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 4, 'Complete the Sentences 1', 'Fill with the correct word', '{"text": "Hidden ___ affects reporting. True ___ requires ___.", "blanks": [{"id": "blank1", "text": "prejudice", "options": ["prejudice", "partiality", "objectivity", "distortion"], "correctAnswer": "prejudice"}, {"id": "blank2", "text": "objectivity", "options": ["objectivity", "prejudice", "partiality", "fairness"], "correctAnswer": "objectivity"}, {"id": "blank3", "text": "fairness", "options": ["fairness", "prejudice", "objectivity", "distortion"], "correctAnswer": "fairness"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 5, 'Complete the Sentences 2', 'Fill with the correct word', '{"text": "Journalistic ___ undermines trust. ___ of facts misleads readers.", "blanks": [{"id": "blank1", "text": "partiality", "options": ["partiality", "prejudice", "objectivity", "distortion"], "correctAnswer": "partiality"}, {"id": "blank2", "text": "Distortion", "options": ["Distortion", "Prejudice", "Partiality", "Objectivity"], "correctAnswer": "Distortion"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_explanation', 6, 'Modals: Degrees of Certainty', 'Learn modals expressing degrees of certainty', '{"rules": "Modals for degrees of certainty:\n- \"must\" (high certainty): \"The news must be biased.\"\n- \"should\" (probable): \"The report should be accurate.\"\n- \"might/may\" (possible): \"The article might contain bias.\"\n- \"could\" (less certain): \"The source could be unreliable.\"\n\nUse for:\n- Expressing confidence: \"I am certain the news is biased.\"\n- Showing uncertainty: \"I am not sure if bias exists.\"\n- Speculating: \"The reporting might be influenced by bias.\"", "examples": ["The news must be biased given the evidence.", "I should be certain the report is accurate.", "The article might contain unintentional bias.", "I could be wrong about detecting bias.", "You may be confident that journalists reduce bias."]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 7, 'Build Sentences 1', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'The news must be biased given the evidence.', 'The news must be biased given the evidence.', '["The", "news", "must", "be", "biased", "given", "the", "evidence."]'::jsonb),
    (activity_id_var, 'I should be certain the report is accurate.', 'I should be certain the report is accurate.', '["I", "should", "be", "certain", "the", "report", "is", "accurate."]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 8, 'Build Sentences 2', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'The article might contain unintentional bias.', 'The article might contain unintentional bias.', '["The", "article", "might", "contain", "unintentional", "bias."]'::jsonb),
    (activity_id_var, 'You may be confident that journalists reduce bias.', 'You may be confident that journalists reduce bias.', '["You", "may", "be", "confident", "that", "journalists", "reduce", "bias."]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'speaking_practice', 9, 'Discuss Media Bias', 'Practice speaking about bias in news', '{"prompts": ["How sure are you when news is biased?", "What evidence convinces you?", "What types of bias concern you most?", "Can bias ever be unintentional?", "How can journalists reduce bias?"]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (
      lesson_id,
      activity_type,
      activity_order,
      title,
      description,
      content
    ) VALUES (
      'C1-L23',
      'speaking_improvement',
      10,
      'Speaking Improvement',
      'Read the improved version of your speech',
      '{"type": "speaking_improvement", "similarityThreshold": 70}'::jsonb
    );
END $$;
