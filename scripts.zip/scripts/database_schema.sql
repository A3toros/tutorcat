-- TutorCat Language Learning App Database Schema
-- This file contains all tables, functions, and views for the application

-- =========================================
-- CORE TABLES
-- =========================================

-- Users table
CREATE TABLE users (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    email VARCHAR(255) UNIQUE NOT NULL,
    username VARCHAR(100),
    first_name VARCHAR(100) NOT NULL,
    last_name VARCHAR(100) NOT NULL,
    password_hash VARCHAR(255) NOT NULL, -- bcrypt hashed password (includes salt)
    level VARCHAR(10), -- NULL until evaluation completed
    role VARCHAR(20) DEFAULT 'user', -- 'user' or 'admin'
    current_lesson INTEGER DEFAULT 1,
    total_stars INTEGER DEFAULT 0,
    eval_test_result JSONB, -- evaluation test results (null if not taken)
    created_at TIMESTAMP DEFAULT NOW(),
    last_login TIMESTAMP,
    email_verified BOOLEAN DEFAULT FALSE
);

-- Email format validation constraint
ALTER TABLE users ADD CONSTRAINT users_email_format_check
CHECK (email ~* '^[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}$');

-- OTP verification table (secure with hashing and salt)
CREATE TABLE otp_verifications (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    identifier VARCHAR(255) NOT NULL, -- email address
    purpose VARCHAR(50) NOT NULL DEFAULT 'email_verification', -- 'email_verification', 'login', 'signup'
    otp_hash VARCHAR(128) NOT NULL, -- SHA256 hash of OTP
    otp_salt VARCHAR(32) NOT NULL, -- Random salt for hashing
    expires_at TIMESTAMP NOT NULL,
    attempts INTEGER DEFAULT 0,
    max_attempts INTEGER DEFAULT 5,
    used BOOLEAN DEFAULT FALSE,
    used_at TIMESTAMP NULL,
    created_at TIMESTAMP DEFAULT NOW(),
    updated_at TIMESTAMP DEFAULT NOW()
);

-- User progress table
CREATE TABLE user_progress (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id UUID REFERENCES users(id),
    lesson_id VARCHAR(20) NOT NULL REFERENCES lessons(id),
    score INTEGER DEFAULT 0,
    completed BOOLEAN DEFAULT FALSE,
    completed_at TIMESTAMP,
    attempts INTEGER DEFAULT 0
);

-- Lessons table (lesson metadata)
CREATE TABLE lessons (
    id VARCHAR(20) PRIMARY KEY, -- e.g., "A1-T1-L1"
    level VARCHAR(10) NOT NULL,
    topic VARCHAR(255) NOT NULL,
    lesson_number INTEGER NOT NULL,
    version INTEGER DEFAULT 1, -- Version number for tracking changes
    last_modified_at TIMESTAMP DEFAULT NOW(), -- Last modification timestamp
    created_at TIMESTAMP DEFAULT NOW(),
    updated_at TIMESTAMP DEFAULT NOW()
);

-- Lesson history table for audit trail
CREATE TABLE lesson_history (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    lesson_id VARCHAR(20) NOT NULL REFERENCES lessons(id),
    version INTEGER NOT NULL,
    changed_by UUID REFERENCES users(id), -- Admin who made changes
    changes JSONB, -- What changed (before/after snapshot)
    changed_at TIMESTAMP DEFAULT NOW(),
    UNIQUE(lesson_id, version)
);

-- Index for lesson history lookups
CREATE INDEX IF NOT EXISTS idx_lesson_history_lesson_id 
ON lesson_history(lesson_id, version DESC);

-- Lesson activities table (all activity types with typed content)
CREATE TABLE lesson_activities (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    lesson_id VARCHAR(20) NOT NULL REFERENCES lessons(id),
    activity_type VARCHAR(50) NOT NULL, -- 'warm_up_speaking', 'vocabulary_intro', 'vocab_match_drag', 'vocab_fill_dropdown', 'grammar_drag_sentence', 'speaking_with_feedback', 'language_improvement_reading'
    activity_order INTEGER NOT NULL, -- Order within the lesson (1, 2, 3, etc.)
    content JSONB NOT NULL, -- Activity-specific content (different structure per activity_type)
    title VARCHAR(255), -- Display title for the activity (optional)
    description TEXT, -- Description or instructions for the activity
    estimated_time_seconds INTEGER, -- Estimated time to complete this activity in seconds
    active BOOLEAN DEFAULT TRUE, -- Soft delete flag: FALSE means activity is removed but preserved for student data
    created_at TIMESTAMP DEFAULT NOW(),
    updated_at TIMESTAMP DEFAULT NOW(),
    UNIQUE(lesson_id, activity_order)
);

-- Index for filtering active activities
CREATE INDEX IF NOT EXISTS idx_lesson_activities_active 
ON lesson_activities(lesson_id, active) 
WHERE active = TRUE;

-- Vocabulary items table (normalized vocabulary data)
CREATE TABLE vocabulary_items (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    activity_id UUID NOT NULL REFERENCES lesson_activities(id) ON DELETE RESTRICT, -- Links to vocab activity
    english_word VARCHAR(100) NOT NULL,
    thai_translation VARCHAR(100) NOT NULL,
    audio_url VARCHAR(255), -- Optional audio file URL
    created_at TIMESTAMP DEFAULT NOW()
);

-- Grammar sentences table (normalized grammar data)
CREATE TABLE grammar_sentences (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    activity_id UUID NOT NULL REFERENCES lesson_activities(id) ON DELETE RESTRICT, -- Links to grammar activity
    original_sentence TEXT NOT NULL,
    correct_sentence TEXT NOT NULL,
    words_array JSONB NOT NULL, -- Array of words to drag
    created_at TIMESTAMP DEFAULT NOW()
);

-- Sessions table for JWT rotation
CREATE TABLE user_sessions (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id UUID REFERENCES users(id),
    session_token VARCHAR(255) UNIQUE NOT NULL,
    expires_at TIMESTAMP NOT NULL,
    created_at TIMESTAMP DEFAULT NOW()
);

-- Evaluation test results table (comprehensive results for any evaluation test)
CREATE TABLE evaluation_results (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id UUID NOT NULL REFERENCES users(id),
    test_id VARCHAR(20) NOT NULL REFERENCES evaluation_test(id),
    overall_score INTEGER NOT NULL,
    max_score INTEGER NOT NULL,
    overall_percentage DECIMAL(5,2) NOT NULL,
    passed BOOLEAN NOT NULL DEFAULT FALSE,
    time_spent INTEGER, -- Total time in seconds
    calculated_level VARCHAR(10), -- Optional: calculated level if applicable
    question_results JSONB NOT NULL, -- Detailed results for each question
    completed_at TIMESTAMP NOT NULL,
    created_at TIMESTAMP DEFAULT NOW()
);

-- Lesson activity results table for detailed activity tracking
CREATE TABLE lesson_activity_results (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id UUID NOT NULL REFERENCES users(id),
    lesson_id VARCHAR(20) NOT NULL REFERENCES lessons(id),
    activity_id UUID REFERENCES lesson_activities(id), -- Links to specific activity (preserves reference after renumbering)
    activity_type VARCHAR(50) NOT NULL,
    activity_order INTEGER NOT NULL,
    score INTEGER,
    max_score INTEGER,
    attempts INTEGER DEFAULT 1,
    time_spent INTEGER, -- in seconds
    completed_at TIMESTAMP NOT NULL,
    answers JSONB, -- User answers/responses
    feedback JSONB, -- AI feedback and corrections
    created_at TIMESTAMP DEFAULT NOW(),
    UNIQUE(user_id, lesson_id, activity_id) -- Updated to use activity_id instead of activity_order
);

-- Index for activity_id lookups
CREATE INDEX IF NOT EXISTS idx_lesson_activity_results_activity_id 
ON lesson_activity_results(activity_id);

-- Single evaluation test table (complete test with questions)
CREATE TABLE evaluation_test (
    id VARCHAR(20) PRIMARY KEY DEFAULT 'EVAL-1', -- Single test ID
    test_name VARCHAR(255) NOT NULL DEFAULT 'English Level Evaluation',
    test_type VARCHAR(50) NOT NULL DEFAULT 'comprehensive',
    description TEXT,
    passing_score INTEGER DEFAULT 60, -- Minimum percentage to pass
    allowed_time INTEGER DEFAULT 45, -- Total time in minutes
    is_active BOOLEAN DEFAULT TRUE,
    questions JSONB NOT NULL, -- Complete questions array with all data
    created_at TIMESTAMP DEFAULT NOW(),
    updated_at TIMESTAMP DEFAULT NOW()
);

-- Achievements table (static achievement definitions)
CREATE TABLE achievements (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    code VARCHAR(50) UNIQUE NOT NULL,
    name VARCHAR(255) NOT NULL,
    description TEXT NOT NULL,
    icon VARCHAR(50) NOT NULL, -- Emoji or icon identifier (UTF-8 supported)
    category VARCHAR(50) NOT NULL,
    requirement_type VARCHAR(50) NOT NULL, -- 'lesson_count', 'score', 'activity_count', 'time', 'level_complete', 'stars', 'title', 'score_threshold_count', 'perfect_score_count', 'score_average', 'distinct_levels'
    requirement_value INTEGER, -- For 'level_complete', this is 0 (means "all" - uses dynamic count). For 'score_threshold_count', this is the score threshold (e.g., 90)
    requirement_count INTEGER, -- For 'score_threshold_count', this is the number of lessons needed (e.g., 10). For others, same as requirement_value
    rarity VARCHAR(20) DEFAULT 'common', -- 'common', 'rare', 'epic', 'legendary'
    points INTEGER DEFAULT 10,
    created_at TIMESTAMP DEFAULT NOW()
);

-- User achievements table (earned achievements only)
CREATE TABLE user_achievements (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    achievement_id UUID NOT NULL REFERENCES achievements(id) ON DELETE CASCADE,
    earned_at TIMESTAMP DEFAULT NOW(),
    UNIQUE(user_id, achievement_id)
);

-- =========================================
-- DATABASE FUNCTIONS
-- =========================================

-- Function to calculate user completion percentage (0-100)
CREATE OR REPLACE FUNCTION calculate_user_completion_percentage(user_uuid UUID)
RETURNS NUMERIC AS $$
DECLARE
    completion_percentage NUMERIC;
BEGIN
    SELECT COALESCE(
        -- Math formula: weighted average of lesson scores
        ROUND(AVG(up.score)::numeric, 2),
        0
    )
    INTO completion_percentage
    FROM user_progress up
    WHERE up.user_id = user_uuid
    AND up.completed = true;

    -- Cap at 100%
    RETURN LEAST(completion_percentage, 100.0);
END;
$$ LANGUAGE plpgsql;

-- Function to get user title based on lesson completion in a specific level (10 titles per level)
-- Title is determined by: completed_lessons / total_lessons_in_level (0-100% within that level)
-- Each level has 10 unique titles covering 0-10%, 10-20%, ..., 90-100% completion
CREATE OR REPLACE FUNCTION get_user_title_by_level(user_uuid UUID, level_name VARCHAR(10))
RETURNS TEXT AS $$
DECLARE
    completed_count INTEGER;
    total_count INTEGER;
    completion_percentage NUMERIC;
    title_index INTEGER;
BEGIN
    -- Count completed lessons for this user in this level
    SELECT COUNT(*)
    INTO completed_count
    FROM user_progress up
    JOIN lessons l ON up.lesson_id = l.id
    WHERE up.user_id = user_uuid
      AND l.level = level_name
      AND up.completed = true;
    
    -- Count total lessons in this level
    SELECT COUNT(*)
    INTO total_count
    FROM lessons
    WHERE level = level_name;
    
    -- If no lessons in level, return default
    IF total_count = 0 THEN
        RETURN 'Tiny Whisker';
    END IF;
    
    -- Calculate completion percentage within this level (0-100%)
    completion_percentage := (completed_count::NUMERIC / total_count::NUMERIC) * 100;
    
    -- Calculate title index (1-10) based on completion percentage within level
    -- Title 1: 0% to 10%, Title 2: 10% to 20%, ..., Title 10: 90% to 100%
    IF completion_percentage = 0 THEN
        title_index := 1;
    ELSE
        title_index := LEAST(10, FLOOR(completion_percentage / 10) + 1);
    END IF;
    
    -- Return level-specific title based on level and index
    -- A1: titles 1-10, A2: titles 11-20, B1: titles 21-30, B2: titles 31-40, C1: titles 41-50, C2: titles 51-60
    RETURN CASE level_name
        WHEN 'A1' THEN
            CASE title_index
                WHEN 1 THEN 'Tiny Whisker'
                WHEN 2 THEN 'Soft Paw'
                WHEN 3 THEN 'Curious Kitten'
                WHEN 4 THEN 'Bright Eyes'
                WHEN 5 THEN 'Happy Purr'
                WHEN 6 THEN 'Magic Meow'
                WHEN 7 THEN 'Wiggly Tail'
                WHEN 8 THEN 'Spark Paw'
                WHEN 9 THEN 'Charm Cat'
                WHEN 10 THEN 'Glow Whisker'
                ELSE 'Tiny Whisker'
            END
        WHEN 'A2' THEN
            CASE title_index
                WHEN 1 THEN 'Sunny Purr'
                WHEN 2 THEN 'Twinkle Fur'
                WHEN 3 THEN 'Clever Kitty'
                WHEN 4 THEN 'Moon Meow'
                WHEN 5 THEN 'Gentle Spellcat'
                WHEN 6 THEN 'Starry Whisker'
                WHEN 7 THEN 'Dreamy Paws'
                WHEN 8 THEN 'Golden Meow'
                WHEN 9 THEN 'Lucky Cat'
                WHEN 10 THEN 'Whisper Whisker'
                ELSE 'Sunny Purr'
            END
        WHEN 'B1' THEN
            CASE title_index
                WHEN 1 THEN 'Silky Paws'
                WHEN 2 THEN 'Dancing Tail'
                WHEN 3 THEN 'Shimmer Cat'
                WHEN 4 THEN 'Velvet Purr'
                WHEN 5 THEN 'Crystal Eyes'
                WHEN 6 THEN 'Rainbow Whisker'
                WHEN 7 THEN 'Cosmic Kitty'
                WHEN 8 THEN 'Aurora Meow'
                WHEN 9 THEN 'Nebula Paws'
                WHEN 10 THEN 'Stardust Tail'
                ELSE 'Silky Paws'
            END
        WHEN 'B2' THEN
            CASE title_index
                WHEN 1 THEN 'Galaxy Cat'
                WHEN 2 THEN 'Celestial Whisker'
                WHEN 3 THEN 'Ethereal Purr'
                WHEN 4 THEN 'Mystic Eyes'
                WHEN 5 THEN 'Enchanted Kitty'
                WHEN 6 THEN 'Sage Meow'
                WHEN 7 THEN 'Wise Whisker'
                WHEN 8 THEN 'Noble Paws'
                WHEN 9 THEN 'Royal Tail'
                WHEN 10 THEN 'Majestic Cat'
                ELSE 'Galaxy Cat'
            END
        WHEN 'C1' THEN
            CASE title_index
                WHEN 1 THEN 'Regal Purr'
                WHEN 2 THEN 'Crown Whisker'
                WHEN 3 THEN 'Throne Kitty'
                WHEN 4 THEN 'Empire Meow'
                WHEN 5 THEN 'Legendary Paws'
                WHEN 6 THEN 'Mythic Tail'
                WHEN 7 THEN 'Ancient Cat'
                WHEN 8 THEN 'Timeless Whisker'
                WHEN 9 THEN 'Eternal Purr'
                WHEN 10 THEN 'Immortal Eyes'
                ELSE 'Regal Purr'
            END
        WHEN 'C2' THEN
            CASE title_index
                WHEN 1 THEN 'Divine Kitty'
                WHEN 2 THEN 'Sacred Meow'
                WHEN 3 THEN 'Holy Whisker'
                WHEN 4 THEN 'Transcendent Paws'
                WHEN 5 THEN 'Ascended Tail'
                WHEN 6 THEN 'Enlightened Cat'
                WHEN 7 THEN 'Awakened Purr'
                WHEN 8 THEN 'Master Whisker'
                WHEN 9 THEN 'Grandmaster Kitty'
                WHEN 10 THEN 'TutorCat'
                ELSE 'Divine Kitty'
            END
        ELSE 'Tiny Whisker'
    END;
END;
$$ LANGUAGE plpgsql;

-- Function to get next title based on lesson completion in a specific level
-- Returns the number of lessons needed to reach the next title (1-10)
-- Each level has 10 titles covering 0-10%, 10-20%, ..., 90-100% completion
CREATE OR REPLACE FUNCTION get_next_title_lessons_needed(user_uuid UUID, level_name VARCHAR(10))
RETURNS INTEGER AS $$
DECLARE
    completed_count INTEGER;
    total_count INTEGER;
    completion_percentage NUMERIC;
    current_title_index INTEGER;
    next_title_index INTEGER;
    lessons_needed INTEGER;
BEGIN
    -- Count completed lessons for this user in this level
    SELECT COUNT(*)
    INTO completed_count
    FROM user_progress up
    JOIN lessons l ON up.lesson_id = l.id
    WHERE up.user_id = user_uuid
      AND l.level = level_name
      AND up.completed = true;
    
    -- Count total lessons in this level
    SELECT COUNT(*)
    INTO total_count
    FROM lessons
    WHERE level = level_name;
    
    -- If no lessons in level or already at max title, return NULL
    IF total_count = 0 OR completed_count >= total_count THEN
        RETURN NULL;
    END IF;
    
    -- Calculate completion percentage within this level (0-100%)
    completion_percentage := (completed_count::NUMERIC / total_count::NUMERIC) * 100;
    
    -- Calculate current title index (1-10) based on completion percentage
    -- Title 1: 0% to 10%, Title 2: 10% to 20%, ..., Title 10: 90% to 100%
    IF completion_percentage = 0 THEN
        current_title_index := 1;
    ELSE
        current_title_index := LEAST(10, FLOOR(completion_percentage / 10) + 1);
    END IF;
    
    -- If already at max title (10), return NULL
    IF current_title_index >= 10 THEN
        RETURN NULL;
    END IF;
    
    -- Calculate lessons needed for next title
    next_title_index := current_title_index + 1;
    -- Next title requires: next_title_index * 10% of total lessons
    -- Example: For title 2 (10-20%), need 10% of total = total_count * 0.1
    lessons_needed := CEIL(next_title_index * total_count::NUMERIC / 10) - completed_count;
    
    RETURN GREATEST(1, lessons_needed); -- At least 1 lesson needed
END;
$$ LANGUAGE plpgsql;

-- Function to clean up expired OTPs (call this periodically)
CREATE OR REPLACE FUNCTION cleanup_expired_otps()
RETURNS INTEGER AS $$
DECLARE
    deleted_count INTEGER;
BEGIN
    DELETE FROM otp_verifications
    WHERE expires_at < NOW() - INTERVAL '1 hour'; -- Keep expired records for 1 hour for debugging

    GET DIAGNOSTICS deleted_count = ROW_COUNT;
    RETURN deleted_count;
END;
$$ LANGUAGE plpgsql;

-- Function to get total lessons in a level (dynamic - works with any number of lessons)
CREATE OR REPLACE FUNCTION get_total_lessons_in_level(level_name VARCHAR(10))
RETURNS INTEGER AS $$
DECLARE
    total_count INTEGER;
BEGIN
    SELECT COUNT(*) INTO total_count
    FROM lessons
    WHERE level = level_name;
    
    RETURN COALESCE(total_count, 0);
END;
$$ LANGUAGE plpgsql;

-- Function to get user's completed lessons in a level (dynamic)
CREATE OR REPLACE FUNCTION get_user_completed_lessons_in_level(user_uuid UUID, level_name VARCHAR(10))
RETURNS INTEGER AS $$
DECLARE
    completed_count INTEGER;
BEGIN
    SELECT COUNT(*) INTO completed_count
    FROM user_progress up
    JOIN lessons l ON up.lesson_id = l.id
    WHERE up.user_id = user_uuid
      AND l.level = level_name
      AND up.completed = true;
    
    RETURN COALESCE(completed_count, 0);
END;
$$ LANGUAGE plpgsql;

-- Function to check and award achievements (simplified)
CREATE OR REPLACE FUNCTION check_achievements_on_lesson_complete(p_user_id UUID)
RETURNS TABLE(achievement_code VARCHAR(50), achievement_name VARCHAR(255), icon VARCHAR(50)) AS $$
DECLARE
    v_lesson_count INTEGER;
    v_perfect_scores INTEGER;
    v_avg_score NUMERIC;
    v_stars INTEGER;
    v_level VARCHAR(10);
    v_achievement_record RECORD;
    v_distinct_levels INTEGER;
BEGIN
    -- Get basic stats from existing tables
    SELECT COUNT(*) INTO v_lesson_count
    FROM user_progress
    WHERE user_id = p_user_id AND completed = true;
    
    SELECT COUNT(*) INTO v_perfect_scores
    FROM user_progress
    WHERE user_id = p_user_id AND completed = true AND score >= 100;
    
    SELECT COALESCE(AVG(score), 0) INTO v_avg_score
    FROM user_progress
    WHERE user_id = p_user_id AND completed = true;
    
    SELECT COALESCE(total_stars, 0) INTO v_stars
    FROM users
    WHERE id = p_user_id
    LIMIT 1;
    
    -- Check all achievements and award if criteria met
    FOR v_achievement_record IN 
        SELECT * FROM achievements 
        WHERE id NOT IN (
            SELECT achievement_id FROM user_achievements WHERE user_id = p_user_id
        )
    LOOP
        DECLARE
            v_should_award BOOLEAN := false;
            v_level_count INTEGER;
            v_total_in_level INTEGER;
        BEGIN
            -- Check achievement based on requirement_type
            CASE v_achievement_record.requirement_type
                WHEN 'lesson_count' THEN
                    IF v_lesson_count >= v_achievement_record.requirement_value THEN
                        v_should_award := true;
                    END IF;
                
                WHEN 'distinct_levels' THEN
                    -- Check if user completed lessons in the required number of distinct levels
                    IF v_distinct_levels >= v_achievement_record.requirement_value THEN
                        v_should_award := true;
                    END IF;
                
                WHEN 'perfect_score_count' THEN
                    IF v_perfect_scores >= v_achievement_record.requirement_value THEN
                        v_should_award := true;
                    END IF;
                
                WHEN 'score_average' THEN
                    -- For score_average, we need both the average score AND minimum lesson count
                    -- requirement_value is the score threshold, requirement_count is the minimum lessons needed
                    -- If requirement_count is NULL, we can't award (need explicit lesson count)
                    IF v_avg_score >= v_achievement_record.requirement_value 
                       AND v_achievement_record.requirement_count IS NOT NULL
                       AND v_lesson_count >= v_achievement_record.requirement_count THEN
                        v_should_award := true;
                    END IF;
                
                WHEN 'score_threshold_count' THEN
                    -- Count lessons with score >= threshold, need requirement_count such lessons
                    DECLARE
                        v_threshold_count INTEGER;
                        v_needed_count INTEGER;
                    BEGIN
                        SELECT COUNT(*) INTO v_threshold_count
                        FROM user_progress
                        WHERE user_id = p_user_id 
                          AND completed = true 
                          AND score >= v_achievement_record.requirement_value;
                        
                        v_needed_count := COALESCE(v_achievement_record.requirement_count, v_achievement_record.requirement_value);
                        
                        IF v_threshold_count >= v_needed_count THEN
                            v_should_award := true;
                        END IF;
                    END;
                
                WHEN 'stars' THEN
                    IF v_stars >= v_achievement_record.requirement_value THEN
                        v_should_award := true;
                    END IF;
                
                WHEN 'level_complete' THEN
                    -- Check if user completed all lessons in a level (dynamic count)
                    -- Extract level from code (e.g., 'a1_master' -> 'A1')
                    DECLARE
                        level_name VARCHAR(10);
                    BEGIN
                        -- Extract level from achievement code (format: 'a1_master', 'b2_master', etc.)
                        IF v_achievement_record.code LIKE 'a1_%' THEN
                            level_name := 'A1';
                        ELSIF v_achievement_record.code LIKE 'a2_%' THEN
                            level_name := 'A2';
                        ELSIF v_achievement_record.code LIKE 'b1_%' THEN
                            level_name := 'B1';
                        ELSIF v_achievement_record.code LIKE 'b2_%' THEN
                            level_name := 'B2';
                        ELSIF v_achievement_record.code LIKE 'c1_%' THEN
                            level_name := 'C1';
                        ELSIF v_achievement_record.code LIKE 'c2_%' THEN
                            level_name := 'C2';
                        END IF;
                        
                        IF level_name IS NOT NULL THEN
                            v_level_count := get_user_completed_lessons_in_level(p_user_id, level_name);
                            v_total_in_level := get_total_lessons_in_level(level_name);
                            
                            -- Award if user completed all lessons in that level (dynamic count)
                            IF v_level_count >= v_total_in_level AND v_total_in_level > 0 THEN
                                v_should_award := true;
                            END IF;
                        END IF;
                    END;
                
                ELSE
                    -- Unknown requirement type - don't award
                    v_should_award := false;
            END CASE;
            
            -- Award achievement if criteria met
            IF v_should_award THEN
                INSERT INTO user_achievements (user_id, achievement_id)
                VALUES (p_user_id, v_achievement_record.id)
                ON CONFLICT (user_id, achievement_id) DO NOTHING;
                
                -- Return newly earned achievement
                RETURN QUERY
                SELECT 
                    v_achievement_record.code,
                    v_achievement_record.name,
                    v_achievement_record.icon;
            END IF;
        END;
    END LOOP;
    
    RETURN;
END;
$$ LANGUAGE plpgsql;

-- Function to get user achievements with progress
CREATE OR REPLACE FUNCTION get_user_achievements_with_progress(p_user_id UUID)
RETURNS TABLE (
    achievement_id UUID,
    code VARCHAR(50),
    name VARCHAR(255),
    description TEXT,
    icon VARCHAR(50),
    category VARCHAR(50),
    rarity VARCHAR(20),
    points INTEGER,
    earned_at TIMESTAMP,
    current_progress INTEGER,
    target_progress INTEGER,
    progress_percentage NUMERIC
) AS $$
BEGIN
    RETURN QUERY
    SELECT 
        a.id,
        a.code,
        a.name,
        a.description,
        a.icon,
        a.category,
        a.rarity,
        a.points,
        ua.earned_at,
        -- Calculate current progress on-the-fly based on requirement_type
        CASE a.requirement_type
            WHEN 'lesson_count' THEN
                (SELECT COUNT(*)::INTEGER FROM user_progress WHERE user_id = p_user_id AND completed = true)
            WHEN 'perfect_score_count' THEN
                (SELECT COUNT(*)::INTEGER FROM user_progress WHERE user_id = p_user_id AND completed = true AND score >= 100)
            WHEN 'score_average' THEN
                -- For score_average, return the number of completed lessons (progress toward requirement_count)
                (SELECT COUNT(*)::INTEGER FROM user_progress WHERE user_id = p_user_id AND completed = true)
            WHEN 'score_threshold_count' THEN
                (SELECT COUNT(*)::INTEGER FROM user_progress WHERE user_id = p_user_id AND completed = true AND score >= a.requirement_value)
            WHEN 'stars' THEN
                (SELECT total_stars FROM users WHERE id = p_user_id)
            WHEN 'level_complete' THEN
                -- For level completion, calculate based on level in code
                CASE 
                    WHEN a.code LIKE 'a1_master' THEN get_user_completed_lessons_in_level(p_user_id, 'A1')
                    WHEN a.code LIKE 'a2_master' THEN get_user_completed_lessons_in_level(p_user_id, 'A2')
                    WHEN a.code LIKE 'b1_master' THEN get_user_completed_lessons_in_level(p_user_id, 'B1')
                    WHEN a.code LIKE 'b2_master' THEN get_user_completed_lessons_in_level(p_user_id, 'B2')
                    WHEN a.code LIKE 'c1_master' THEN get_user_completed_lessons_in_level(p_user_id, 'C1')
                    WHEN a.code LIKE 'c2_master' THEN get_user_completed_lessons_in_level(p_user_id, 'C2')
                    ELSE 0
                END
            WHEN 'distinct_levels' THEN
                -- For distinct_levels, return the number of distinct levels with completed lessons
                (SELECT COUNT(DISTINCT l.level)::INTEGER
                 FROM user_progress up
                 JOIN lessons l ON up.lesson_id = l.id
                 WHERE up.user_id = p_user_id AND up.completed = true)
            ELSE 0
        END as current_progress,
        -- Target progress: for level_complete, use dynamic total; otherwise use requirement_value
        CASE 
            WHEN a.requirement_type = 'level_complete' THEN
                CASE 
                    WHEN a.code LIKE 'a1_master' THEN get_total_lessons_in_level('A1')
                    WHEN a.code LIKE 'a2_master' THEN get_total_lessons_in_level('A2')
                    WHEN a.code LIKE 'b1_master' THEN get_total_lessons_in_level('B1')
                    WHEN a.code LIKE 'b2_master' THEN get_total_lessons_in_level('B2')
                    WHEN a.code LIKE 'c1_master' THEN get_total_lessons_in_level('C1')
                    WHEN a.code LIKE 'c2_master' THEN get_total_lessons_in_level('C2')
                    ELSE 0
                END
            WHEN a.requirement_type = 'score_threshold_count' THEN
                COALESCE(a.requirement_count, a.requirement_value)
            WHEN a.requirement_type = 'score_average' THEN
                -- For score_average, target is the number of lessons needed (requirement_count)
                COALESCE(a.requirement_count, a.requirement_value)
            WHEN a.requirement_type = 'distinct_levels' THEN
                -- For distinct_levels, target is the number of distinct levels needed
                a.requirement_value
            ELSE a.requirement_value
        END as target_progress,
        CASE 
            WHEN a.requirement_type = 'level_complete' THEN
                -- For level completion, use dynamic total
                CASE 
                    WHEN a.code LIKE 'a1_master' THEN 
                        ROUND((get_user_completed_lessons_in_level(p_user_id, 'A1')::NUMERIC / NULLIF(get_total_lessons_in_level('A1'), 0)) * 100, 1)
                    WHEN a.code LIKE 'a2_master' THEN 
                        ROUND((get_user_completed_lessons_in_level(p_user_id, 'A2')::NUMERIC / NULLIF(get_total_lessons_in_level('A2'), 0)) * 100, 1)
                    WHEN a.code LIKE 'b1_master' THEN 
                        ROUND((get_user_completed_lessons_in_level(p_user_id, 'B1')::NUMERIC / NULLIF(get_total_lessons_in_level('B1'), 0)) * 100, 1)
                    WHEN a.code LIKE 'b2_master' THEN 
                        ROUND((get_user_completed_lessons_in_level(p_user_id, 'B2')::NUMERIC / NULLIF(get_total_lessons_in_level('B2'), 0)) * 100, 1)
                    WHEN a.code LIKE 'c1_master' THEN 
                        ROUND((get_user_completed_lessons_in_level(p_user_id, 'C1')::NUMERIC / NULLIF(get_total_lessons_in_level('C1'), 0)) * 100, 1)
                    WHEN a.code LIKE 'c2_master' THEN 
                        ROUND((get_user_completed_lessons_in_level(p_user_id, 'C2')::NUMERIC / NULLIF(get_total_lessons_in_level('C2'), 0)) * 100, 1)
                    ELSE 0
                END
            WHEN a.requirement_type = 'score_threshold_count' THEN
                ROUND((SELECT COUNT(*)::NUMERIC FROM user_progress WHERE user_id = p_user_id AND completed = true AND score >= a.requirement_value) / NULLIF(COALESCE(a.requirement_count, a.requirement_value), 0) * 100, 1)
            WHEN a.requirement_type = 'score_average' THEN
                -- For score_average, calculate progress based on lessons completed vs requirement_count
                -- Progress is: lessons_completed / requirement_count * 100
                CASE 
                    WHEN COALESCE(a.requirement_count, a.requirement_value) > 0 THEN
                        ROUND(
                            (SELECT COUNT(*)::NUMERIC FROM user_progress WHERE user_id = p_user_id AND completed = true) 
                            / NULLIF(COALESCE(a.requirement_count, a.requirement_value), 0) * 100, 
                            1
                        )
                    ELSE 0
                END
            WHEN a.requirement_type = 'distinct_levels' THEN
                -- For distinct_levels, calculate progress based on distinct levels completed
                ROUND(
                    (SELECT COUNT(DISTINCT l.level)::NUMERIC
                     FROM user_progress up
                     JOIN lessons l ON up.lesson_id = l.id
                     WHERE up.user_id = p_user_id AND up.completed = true)
                    / NULLIF(a.requirement_value, 0) * 100,
                    1
                )
            WHEN a.requirement_type = 'stars' THEN
                -- For stars, calculate progress as: current_stars / required_stars * 100
                ROUND(
                    (SELECT COALESCE(total_stars, 0)::NUMERIC FROM users WHERE id = p_user_id)
                    / NULLIF(a.requirement_value, 0) * 100,
                    1
                )
            WHEN a.requirement_value > 0 THEN
                ROUND((CASE a.requirement_type
                    WHEN 'lesson_count' THEN (SELECT COUNT(*)::NUMERIC FROM user_progress WHERE user_id = p_user_id AND completed = true)
                    WHEN 'perfect_score_count' THEN (SELECT COUNT(*)::NUMERIC FROM user_progress WHERE user_id = p_user_id AND completed = true AND score >= 100)
                    ELSE 0
                END / a.requirement_value::NUMERIC) * 100, 1)
            ELSE 0
        END as progress_percentage
    FROM achievements a
    LEFT JOIN user_achievements ua ON a.id = ua.achievement_id AND ua.user_id = p_user_id
    ORDER BY 
        CASE WHEN ua.earned_at IS NOT NULL THEN 0 ELSE 1 END,
        a.category,
        a.points DESC;
END;
$$ LANGUAGE plpgsql;

-- Function to get standardized activity content structure
CREATE OR REPLACE FUNCTION get_activity_content(activity_row lesson_activities)
RETURNS JSONB AS $$
DECLARE
    result JSONB;
BEGIN
    -- Standardize content based on activity type
    CASE activity_row.activity_type
        WHEN 'warm_up_speaking' THEN
            result := jsonb_build_object(
                'prompt', COALESCE(activity_row.content->>'prompt', ''),
                'instructions', COALESCE(activity_row.content->>'instructions', 'Press microphone button and speak clearly on the topic'),
                'ai_feedback_enabled', COALESCE((activity_row.content->>'ai_feedback_enabled')::boolean, true),
                'time_limit_seconds', COALESCE((activity_row.content->>'time_limit_seconds')::integer, 60)
            );
        
        WHEN 'vocabulary_intro' THEN
            result := jsonb_build_object(
                'title', COALESCE(activity_row.content->>'title', ''),
                'description', COALESCE(activity_row.content->>'description', '')
            );
        
        WHEN 'vocabulary_matching_drag' THEN
            result := jsonb_build_object(
                'instructions', COALESCE(activity_row.content->>'instructions', 'Drag words to match with their meanings')
            );
        
        WHEN 'vocabulary_fill_blanks' THEN
            result := jsonb_build_object(
                'text', COALESCE(activity_row.content->>'text', ''),
                'blanks', COALESCE(activity_row.content->'blanks', '[]'::jsonb),
                'instructions', COALESCE(activity_row.content->>'instructions', 'Fill in the blanks with correct words')
            );
        
        WHEN 'grammar_explanation' THEN
            result := jsonb_build_object(
                'title', COALESCE(activity_row.content->>'title', ''),
                'rules', COALESCE(activity_row.content->>'rules', activity_row.content->>'explanation', ''),
                'explanation', COALESCE(activity_row.content->>'rules', activity_row.content->>'explanation', ''),
                'examples', COALESCE(activity_row.content->'examples', '[]'::jsonb)
            );
        
        WHEN 'grammar_sentences' THEN
            result := jsonb_build_object(
                'instructions', COALESCE(activity_row.content->>'instructions', 'Arrange the words to form correct sentences')
            );
        
        WHEN 'speaking_practice' THEN
            result := jsonb_build_object(
                'prompts', COALESCE(activity_row.content->'prompts', '[]'::jsonb),
                'ai_feedback_enabled', COALESCE((activity_row.content->>'ai_feedback_enabled')::boolean, true),
                'feedback_criteria', COALESCE(activity_row.content->'feedback_criteria', jsonb_build_object(
                    'grammar', true,
                    'vocabulary', true,
                    'pronunciation', true
                ))
            );
        
        WHEN 'listening_practice' THEN
            result := jsonb_build_object(
                'audio_url', COALESCE(activity_row.content->>'audio_url', ''),
                'transcript', COALESCE(activity_row.content->>'transcript', ''),
                'questions', COALESCE(activity_row.content->'questions', '[]'::jsonb),
                'instructions', COALESCE(activity_row.content->>'instructions', 'Listen to the audio and answer the questions')
            );
        
        ELSE
            -- Return content as-is for unknown types
            result := activity_row.content;
    END CASE;
    
    RETURN result;
END;
$$ LANGUAGE plpgsql IMMUTABLE;

-- Function to check if activity has content
CREATE OR REPLACE FUNCTION has_activity_content(activity_row lesson_activities)
RETURNS BOOLEAN AS $$
BEGIN
    RETURN CASE activity_row.activity_type
        WHEN 'warm_up_speaking' THEN
            (activity_row.content->>'prompt') IS NOT NULL AND (activity_row.content->>'prompt') != ''
        
        WHEN 'vocabulary_intro' THEN
            EXISTS (
                SELECT 1 FROM vocabulary_items 
                WHERE activity_id = activity_row.id
            )
        
        WHEN 'vocabulary_matching_drag' THEN
            EXISTS (
                SELECT 1 FROM vocabulary_items 
                WHERE activity_id = activity_row.id
            )
        
        WHEN 'vocabulary_fill_blanks' THEN
            (activity_row.content->>'text') IS NOT NULL 
            AND (activity_row.content->>'text') != ''
            AND (activity_row.content->'blanks') IS NOT NULL 
            AND jsonb_array_length(activity_row.content->'blanks') > 0
        
        WHEN 'grammar_explanation' THEN
            (activity_row.content->>'explanation') IS NOT NULL 
            AND (activity_row.content->>'explanation') != ''
        
        WHEN 'grammar_sentences' THEN
            EXISTS (
                SELECT 1 FROM grammar_sentences 
                WHERE activity_id = activity_row.id
            )
        
        WHEN 'speaking_practice' THEN
            (activity_row.content->'prompts') IS NOT NULL 
            AND jsonb_array_length(activity_row.content->'prompts') > 0
        
        WHEN 'listening_practice' THEN
            (activity_row.content->>'audio_url') IS NOT NULL 
            AND (activity_row.content->>'audio_url') != ''
        
        ELSE
            activity_row.content IS NOT NULL 
            AND activity_row.content != '{}'::jsonb
    END;
END;
$$ LANGUAGE plpgsql IMMUTABLE;

-- =========================================
-- DATABASE VIEWS
-- =========================================

-- Complete lesson view (combines lessons with all activities)
CREATE VIEW lesson_complete AS
SELECT
    l.id as lesson_id,
    l.level,
    l.topic,
    l.lesson_number,
    l.created_at as lesson_created_at,
    l.updated_at as lesson_updated_at,
    json_agg(
        json_build_object(
            'id', la.id,
            'activity_type', la.activity_type,
            'activity_order', la.activity_order,
            'title', la.title,
            'description', la.description,
            'estimated_time_seconds', la.estimated_time_seconds,
            'content', get_activity_content(la), -- Use standardized content
            'has_content', has_activity_content(la), -- Helper flag
            'vocabulary_items', COALESCE(vocab_data.items, '[]'::json),
            'grammar_sentences', COALESCE(grammar_data.sentences, '[]'::json),
            'created_at', la.created_at,
            'updated_at', la.updated_at
        ) ORDER BY la.activity_order
    ) FILTER (WHERE la.id IS NOT NULL) as activities
FROM lessons l
LEFT JOIN lesson_activities la ON l.id = la.lesson_id
LEFT JOIN (
    SELECT
        activity_id,
        json_agg(
            json_build_object(
                'id', id,
                'english_word', english_word,
                'thai_translation', thai_translation,
                'audio_url', audio_url
            ) ORDER BY id
        ) as items
    FROM vocabulary_items
    GROUP BY activity_id
) vocab_data ON la.id = vocab_data.activity_id
LEFT JOIN (
    SELECT
        activity_id,
        json_agg(
            json_build_object(
                'id', id,
                'original_sentence', original_sentence,
                'correct_sentence', correct_sentence,
                'words_array', words_array
            ) ORDER BY id
        ) as sentences
    FROM grammar_sentences
    GROUP BY activity_id
) grammar_data ON la.id = grammar_data.activity_id
GROUP BY l.id, l.level, l.topic, l.lesson_number, l.created_at, l.updated_at;

-- Detailed activities view with all related data
CREATE VIEW lesson_activities_detailed AS
SELECT 
  la.id,
  la.lesson_id,
  la.activity_type,
  la.activity_order,
  la.title,
  la.description,
  la.estimated_time_seconds,
  la.content,
  la.created_at,
  la.updated_at,
  -- Vocabulary items as JSON array (order first, then aggregate)
  COALESCE(
    (SELECT json_agg(row_to_json(v))
     FROM (SELECT * FROM vocabulary_items WHERE activity_id = la.id ORDER BY id) v),
    '[]'::json
  ) as vocabulary_items,
  -- Grammar sentences as JSON array (order first, then aggregate)
  COALESCE(
    (SELECT json_agg(row_to_json(g))
     FROM (SELECT * FROM grammar_sentences WHERE activity_id = la.id ORDER BY id) g),
    '[]'::json
  ) as grammar_sentences,
  -- Helper flags
  has_activity_content(la) as has_content,
  get_activity_content(la) as standardized_content
FROM lesson_activities la
ORDER BY la.lesson_id, la.activity_order;

-- Lesson activities summary view
CREATE VIEW lesson_activities_summary AS
SELECT
    l.id as lesson_id,
    l.level,
    l.topic,
    l.lesson_number,
    COUNT(la.id) as total_activities,
    COUNT(CASE WHEN la.activity_type = 'warm_up_speaking' THEN 1 END) as warm_up_count,
    COUNT(CASE WHEN la.activity_type LIKE 'vocab%' THEN 1 END) as vocabulary_activities_count,
    COUNT(CASE WHEN la.activity_type LIKE 'grammar%' THEN 1 END) as grammar_activities_count,
    COUNT(CASE WHEN la.activity_type LIKE '%speaking%' THEN 1 END) as speaking_activities_count,
    COUNT(CASE WHEN la.activity_type LIKE '%reading%' THEN 1 END) as reading_activities_count,
    array_agg(la.activity_type ORDER BY la.activity_order) as activity_sequence,
    l.created_at as lesson_created_at,
    l.updated_at as lesson_updated_at
FROM lessons l
LEFT JOIN lesson_activities la ON l.id = la.lesson_id
GROUP BY l.id, l.level, l.topic, l.lesson_number, l.created_at, l.updated_at;

-- User lesson progress with completion percentage and titles view
CREATE VIEW user_lesson_progress AS
SELECT
    l.id as lesson_id,
    l.level,
    l.topic,
    l.lesson_number,
    u.id as user_id,
    up.score,
    up.completed,
    up.completed_at,
    up.attempts,
    -- Use database functions for completion percentage and title calculations
    calculate_user_completion_percentage(u.id) as completion_percentage,
    -- Level-specific title based on completion within that level (0-100%)
    get_user_title_by_level(u.id, l.level) as current_title,
    -- Level-specific next title progress (based on lessons needed in this level)
    get_next_title_lessons_needed(u.id, l.level) as next_title_lessons_needed,
    -- Progress percentage within level
    ROUND(
        (ROW_NUMBER() OVER (PARTITION BY l.level ORDER BY l.lesson_number) * 100.0) /
        COUNT(*) OVER (PARTITION BY l.level), 1
    ) as level_progress_percentage
FROM lessons l
CROSS JOIN users u -- Cross join to get all lessons for all users
LEFT JOIN user_progress up ON up.lesson_id = l.id AND up.user_id = u.id
ORDER BY u.id, l.level, l.lesson_number;

-- =========================================
-- INDEXES FOR PERFORMANCE
-- =========================================

-- Users table indexes
CREATE INDEX idx_users_email ON users(email);
CREATE INDEX idx_users_username_lower ON users(LOWER(username));
CREATE INDEX idx_users_level ON users(level);
CREATE INDEX idx_users_created_at ON users(created_at);

-- OTP verifications indexes
CREATE INDEX idx_otp_verifications_identifier ON otp_verifications(identifier);
CREATE INDEX idx_otp_verifications_purpose ON otp_verifications(purpose);
CREATE INDEX idx_otp_verifications_expires_at ON otp_verifications(expires_at);
CREATE INDEX idx_otp_verifications_used ON otp_verifications(used);

-- User progress indexes
CREATE INDEX idx_user_progress_user_id ON user_progress(user_id);
CREATE INDEX idx_user_progress_lesson_id ON user_progress(lesson_id);
CREATE INDEX idx_user_progress_user_lesson ON user_progress(user_id, lesson_id); -- Composite for JOINs
CREATE INDEX idx_user_progress_completed ON user_progress(completed);
CREATE INDEX idx_user_progress_completed_at ON user_progress(completed_at);

-- Lessons indexes
CREATE INDEX idx_lessons_level ON lessons(level);
CREATE INDEX idx_lessons_level_number ON lessons(level, lesson_number); -- Composite for level queries
CREATE INDEX idx_lessons_lesson_number ON lessons(lesson_number);

-- Lesson activities indexes
CREATE INDEX idx_lesson_activities_lesson_id ON lesson_activities(lesson_id);
CREATE INDEX idx_lesson_activities_lesson_order ON lesson_activities(lesson_id, activity_order); -- Composite for ordered queries
CREATE INDEX idx_lesson_activities_activity_type ON lesson_activities(activity_type);
CREATE INDEX idx_lesson_activities_activity_order ON lesson_activities(activity_order);
CREATE INDEX idx_lesson_activities_type_order ON lesson_activities(lesson_id, activity_type, activity_order); -- For filtering by type and order
CREATE INDEX idx_lesson_activities_content_gin ON lesson_activities USING GIN (content); -- GIN index for JSONB queries
CREATE INDEX idx_lesson_activities_title ON lesson_activities(title) WHERE title IS NOT NULL; -- For title searches

-- Vocabulary items indexes
CREATE INDEX idx_vocabulary_items_activity_id ON vocabulary_items(activity_id);

-- Grammar sentences indexes
CREATE INDEX idx_grammar_sentences_activity_id ON grammar_sentences(activity_id);

-- User sessions indexes
CREATE INDEX idx_user_sessions_user_id ON user_sessions(user_id);
CREATE INDEX idx_user_sessions_session_token ON user_sessions(session_token);
CREATE INDEX idx_user_sessions_expires_at ON user_sessions(expires_at);

-- Evaluation results indexes
CREATE INDEX idx_evaluation_results_user_id ON evaluation_results(user_id);
CREATE INDEX idx_evaluation_results_calculated_level ON evaluation_results(calculated_level);
CREATE INDEX idx_evaluation_results_completed_at ON evaluation_results(completed_at);

-- Lesson activity results indexes
CREATE INDEX idx_lesson_activity_results_user_id ON lesson_activity_results(user_id);
CREATE INDEX idx_lesson_activity_results_lesson_id ON lesson_activity_results(lesson_id);
CREATE INDEX idx_lesson_activity_results_activity_type ON lesson_activity_results(activity_type);
CREATE INDEX idx_lesson_activity_results_completed_at ON lesson_activity_results(completed_at);

-- Evaluation test indexes
CREATE INDEX idx_evaluation_test_is_active ON evaluation_test(is_active);

-- Achievements indexes
CREATE INDEX idx_achievements_category ON achievements(category);
CREATE INDEX idx_achievements_code ON achievements(code);
CREATE INDEX idx_achievements_requirement_type ON achievements(requirement_type);

-- User achievements indexes
CREATE INDEX idx_user_achievements_user_id ON user_achievements(user_id);
CREATE INDEX idx_user_achievements_earned_at ON user_achievements(earned_at DESC);
CREATE INDEX idx_user_achievements_achievement_id ON user_achievements(achievement_id);

-- Evaluation test results indexes

-- =========================================
-- SAMPLE DATA INSERTS (for testing)
-- =========================================

-- Insert sample user
-- INSERT INTO users (email, username, level) VALUES ('test@example.com', 'TestUser', 'A1');

-- Insert sample lesson
-- INSERT INTO lessons (id, level, topic, lesson_number) VALUES ('A1-L1', 'A1', 'Personal Information', 1);

-- Insert sample lesson activities
-- INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, content) VALUES
-- ('A1-T1-L1', 'warm_up_speaking', 1, '{"prompt": "What is your name and where are you from?", "evaluation": {"mode": "semantic", "required_intent": ["name", "origin"], "min_items": 1, "score": false}, "fail_prompt": "Please tell me your name or where you are from.", "pass_condition": "contains_personal_info", "next_unlocked": true}'::jsonb),
-- ('A1-T1-L1', 'vocabulary_intro', 2, '{"items": [{"en": "name", "th": "ชื่อ"}, {"en": "country", "th": "ประเทศ"}, {"en": "from", "th": "จาก"}, {"en": "live", "th": "อาศัยอยู่"}, {"en": "student", "th": "นักเรียน"}]}'::jsonb);

-- =========================================
-- USEFUL QUERIES
-- =========================================

-- Get user's current progress summary
-- SELECT
--     u.username,
--     calculate_user_completion_percentage(u.id) as completion_percentage,
--     get_user_title(calculate_user_completion_percentage(u.id)) as current_title,
--     COUNT(up.id) as lessons_completed
-- FROM users u
-- LEFT JOIN user_progress up ON u.id = up.user_id AND up.completed = true
-- WHERE u.id = 'your-user-uuid'
-- GROUP BY u.id, u.username;

-- Get lesson with all activities
-- SELECT * FROM lesson_complete WHERE lesson_id = 'A1-T1-L1';

-- Get user dashboard data
-- SELECT * FROM user_lesson_progress WHERE user_id = 'your-user-uuid';

-- Add unique constraint to lesson_activity_results for UPSERT operations
-- This allows incremental activity saving without duplicates
-- Uses activity_id to preserve references even after renumbering
-- Note: This may fail if constraint already exists - that's okay
DO $$
BEGIN
    -- Drop old constraint if it exists (using activity_order)
    IF EXISTS (
        SELECT 1 FROM pg_constraint 
        WHERE conname = 'unique_user_lesson_activity_order'
    ) THEN
        ALTER TABLE lesson_activity_results 
        DROP CONSTRAINT unique_user_lesson_activity_order;
    END IF;
    
    -- Add new constraint using activity_id
    IF NOT EXISTS (
        SELECT 1 FROM pg_constraint 
        WHERE conname = 'unique_user_lesson_activity_id'
    ) THEN
        ALTER TABLE lesson_activity_results 
        ADD CONSTRAINT unique_user_lesson_activity_id 
        UNIQUE (user_id, lesson_id, activity_id);
    END IF;
END $$;

-- Add requirement_count column to achievements table if it doesn't exist
DO $$
BEGIN
    IF NOT EXISTS (
        SELECT 1 FROM information_schema.columns 
        WHERE table_name = 'achievements' AND column_name = 'requirement_count'
    ) THEN
        ALTER TABLE achievements 
        ADD COLUMN requirement_count INTEGER DEFAULT NULL;
        
        RAISE NOTICE 'Added requirement_count column to achievements table';
    ELSE
        RAISE NOTICE 'requirement_count column already exists';
    END IF;
END $$;

-- =========================================
-- MIGRATION: Fix Achievement Progress Calculations
-- =========================================
-- This updates existing achievements that use score_average incorrectly
-- to use score_threshold_count with proper requirement_count values

DO $$
BEGIN
    -- Update "Excellent" achievement: Score 90%+ on 10 lessons
    UPDATE achievements
    SET requirement_type = 'score_threshold_count',
        requirement_value = 90,
        requirement_count = 10
    WHERE code = 'excellent'
      AND requirement_type = 'score_average';

    -- Update "Above Average" achievement: Score 80%+ on 20 lessons
    UPDATE achievements
    SET requirement_type = 'score_threshold_count',
        requirement_value = 80,
        requirement_count = 20
    WHERE code = 'above_average'
      AND requirement_type = 'score_average';

    -- Update "Above Average" performance achievement: Score 80%+ on 5 lessons
    UPDATE achievements
    SET requirement_type = 'score_threshold_count',
        requirement_value = 80,
        requirement_count = 5
    WHERE code = 'above_average_perf'
      AND requirement_type = 'score_average';

    -- Update "Outstanding" achievement: Score 95%+ on 5 lessons
    UPDATE achievements
    SET requirement_type = 'score_threshold_count',
        requirement_value = 95,
        requirement_count = 5
    WHERE code = 'outstanding'
      AND requirement_type = 'score_average';

    -- Update "Consistent Performer" achievement: Score 80%+ on 10 lessons
    UPDATE achievements
    SET requirement_type = 'score_threshold_count',
        requirement_value = 80,
        requirement_count = 10
    WHERE code = 'consistent_performer'
      AND requirement_type = 'score_average';

    -- Update "Grammar Guru" achievement: Score 90%+ on 10 grammar activities
    UPDATE achievements
    SET requirement_type = 'score_threshold_count',
        requirement_value = 90,
        requirement_count = 10
    WHERE code = 'grammar_guru'
      AND requirement_type = 'score_average';

    -- Update "Vocabulary Master" achievement: Score 90%+ on 10 vocabulary activities
    UPDATE achievements
    SET requirement_type = 'score_threshold_count',
        requirement_value = 90,
        requirement_count = 10
    WHERE code = 'vocabulary_master'
      AND requirement_type = 'score_average';

    -- Update "Speaking Star" achievement: Score 90%+ on 10 speaking activities
    UPDATE achievements
    SET requirement_type = 'score_threshold_count',
        requirement_value = 90,
        requirement_count = 10
    WHERE code = 'speaking_star'
      AND requirement_type = 'score_average';

    -- Update "Quick Learner" performance achievement: Score 90%+ on 5 lessons
    UPDATE achievements
    SET requirement_type = 'score_threshold_count',
        requirement_value = 90,
        requirement_count = 5
    WHERE code = 'quick_learner_perf'
      AND requirement_type = 'score_average';

    -- Update "Consistency King" achievement: Score 85%+ on 30 lessons
    UPDATE achievements
    SET requirement_type = 'score_threshold_count',
        requirement_value = 85,
        requirement_count = 30
    WHERE code = 'consistency_king'
      AND requirement_type = 'score_average';

    -- Fix score_average achievements to require minimum lesson counts
    UPDATE achievements
    SET requirement_count = 25
    WHERE code = 'high_achiever'
      AND requirement_type = 'score_average'
      AND requirement_count IS NULL;

    UPDATE achievements
    SET requirement_count = 25
    WHERE code = 'master_student'
      AND requirement_type = 'score_average'
      AND requirement_count IS NULL;

    UPDATE achievements
    SET requirement_count = 50
    WHERE code = 'excellence'
      AND requirement_type = 'score_average'
      AND requirement_count IS NULL;

    UPDATE achievements
    SET requirement_count = 10
    WHERE code = 'top_performer'
      AND requirement_type = 'score_average'
      AND requirement_count IS NULL;

    UPDATE achievements
    SET requirement_count = 1
    WHERE code = 'good_start'
      AND requirement_type = 'score_average'
      AND requirement_count IS NULL;

    RAISE NOTICE 'Updated achievement progress calculations successfully!';
END $$;

-- =========================================
-- INSERT ALL 100 ACHIEVEMENTS
-- =========================================
-- This script inserts all 100 achievements into the database
-- Run this after the achievements system structure is created
-- Note: Uses ON CONFLICT to prevent duplicates if run multiple times

DO $$
BEGIN
    -- Lessons Category (40 achievements)
    INSERT INTO achievements (code, name, description, icon, category, requirement_type, requirement_value, rarity, points, requirement_count) VALUES
    ('first_steps', 'First Steps', 'Complete your first lesson', '🎯', 'lessons', 'lesson_count', 1, 'common', 10, NULL),
    ('getting_started', 'Getting Started', 'Complete 3 lessons', '🚀', 'lessons', 'lesson_count', 3, 'common', 15, NULL),
    ('on_a_roll', 'On a Roll', 'Complete 5 lessons', '⭐', 'lessons', 'lesson_count', 5, 'common', 20, NULL),
    ('making_progress', 'Making Progress', 'Complete 10 lessons', '📈', 'lessons', 'lesson_count', 10, 'common', 25, NULL),
    ('halfway_there', 'Halfway There', 'Complete 25 lessons', '🎪', 'lessons', 'lesson_count', 25, 'rare', 30, NULL),
    ('almost_there', 'Almost There', 'Complete 50 lessons', '🏆', 'lessons', 'lesson_count', 50, 'rare', 40, NULL),
    ('century_club', 'Century Club', 'Complete 100 lessons', '💯', 'lessons', 'lesson_count', 100, 'epic', 50, NULL),
    ('lesson_master', 'Lesson Master', 'Complete 200 lessons', '👑', 'lessons', 'lesson_count', 200, 'legendary', 100, NULL),
    ('perfect_score', 'Perfect Score', 'Score 100% on a lesson', '✨', 'lessons', 'perfect_score_count', 1, 'common', 15, NULL),
    ('perfectionist', 'Perfectionist', 'Score 100% on 5 lessons', '🌟', 'lessons', 'perfect_score_count', 5, 'rare', 30, NULL),
    ('flawless', 'Flawless', 'Score 100% on 10 lessons', '💎', 'lessons', 'perfect_score_count', 10, 'epic', 50, NULL),
    ('excellent', 'Excellent', 'Score 90%+ on 10 lessons', '🎖️', 'lessons', 'score_threshold_count', 90, 'rare', 25, 10),
    ('above_average', 'Above Average', 'Score 80%+ on 20 lessons', '📊', 'lessons', 'score_threshold_count', 80, 'common', 20, 20),
    ('high_achiever', 'High Achiever', 'Average 90%+ across 25 lessons', '🏅', 'lessons', 'score_average', 90, 'epic', 45, 25),
    ('a1_explorer', 'A1 Explorer', 'Complete 5 A1 lessons', '🔍', 'lessons', 'lesson_count', 5, 'common', 15, NULL),
    ('a1_master', 'A1 Master', 'Complete all A1 lessons', '🥇', 'lessons', 'level_complete', 0, 'rare', 40, NULL),
    ('a2_explorer', 'A2 Explorer', 'Complete 5 A2 lessons', '🔍', 'lessons', 'lesson_count', 5, 'common', 15, NULL),
    ('a2_master', 'A2 Master', 'Complete all A2 lessons', '🥇', 'lessons', 'level_complete', 0, 'rare', 40, NULL),
    ('b1_explorer', 'B1 Explorer', 'Complete 5 B1 lessons', '🔍', 'lessons', 'lesson_count', 5, 'common', 15, NULL),
    ('b1_master', 'B1 Master', 'Complete all B1 lessons', '🥇', 'lessons', 'level_complete', 0, 'rare', 40, NULL),
    ('b2_explorer', 'B2 Explorer', 'Complete 5 B2 lessons', '🔍', 'lessons', 'lesson_count', 5, 'common', 15, NULL),
    ('b2_master', 'B2 Master', 'Complete all B2 lessons', '🥇', 'lessons', 'level_complete', 0, 'rare', 40, NULL),
    ('c1_explorer', 'C1 Explorer', 'Complete 5 C1 lessons', '🔍', 'lessons', 'lesson_count', 5, 'common', 15, NULL),
    ('c1_master', 'C1 Master', 'Complete all C1 lessons', '🥇', 'lessons', 'level_complete', 0, 'rare', 40, NULL),
    ('c2_explorer', 'C2 Explorer', 'Complete 5 C2 lessons', '🔍', 'lessons', 'lesson_count', 5, 'common', 15, NULL),
    ('c2_master', 'C2 Master', 'Complete all C2 lessons', '🥇', 'lessons', 'level_complete', 0, 'rare', 40, NULL),
    ('multi_level', 'Multi-Level', 'Complete lessons in 3 different levels', '🌍', 'lessons', 'distinct_levels', 3, 'rare', 30, NULL),
    ('all_levels', 'All Levels', 'Complete lessons in all 6 levels', '🌐', 'lessons', 'distinct_levels', 6, 'epic', 60, NULL),
    ('quick_study', 'Quick Study', 'Complete 3 lessons in one day', '⚡', 'lessons', 'lesson_count', 3, 'common', 20, NULL),
    ('marathon', 'Marathon', 'Complete 5 lessons in one day', '🏃', 'lessons', 'lesson_count', 5, 'rare', 35, NULL),
    ('weekend_warrior', 'Weekend Warrior', 'Complete 5 lessons on weekends', '🎮', 'lessons', 'lesson_count', 5, 'rare', 30, NULL),
    ('first_try', 'First Try', 'Pass 1 lesson on first attempt', '🎲', 'lessons', 'lesson_count', 1, 'common', 15, NULL),
    ('quick_learner', 'Quick Learner', 'Pass 5 lessons on first attempt', '🧠', 'lessons', 'lesson_count', 5, 'rare', 30, NULL),
    ('natural_talent', 'Natural Talent', 'Pass 10 lessons on first attempt', '💫', 'lessons', 'lesson_count', 10, 'epic', 50, NULL),
    ('speed_learner', 'Speed Learner', 'Complete 1 lesson in under 15 minutes', '⏱️', 'lessons', 'lesson_count', 1, 'common', 15, NULL),
    ('efficient', 'Efficient', 'Complete 5 lessons averaging under 15 minutes', '⚙️', 'lessons', 'lesson_count', 5, 'rare', 30, NULL),
    ('quick_thinker', 'Quick Thinker', 'Complete 10 lessons in under 15 minutes each', '🧩', 'lessons', 'lesson_count', 10, 'epic', 45, NULL),
    ('grammar_expert', 'Grammar Expert', 'Complete 20 grammar activities', '📝', 'lessons', 'activity_count', 20, 'rare', 35, NULL),
    ('vocabulary_pro', 'Vocabulary Pro', 'Complete 20 vocabulary activities', '📚', 'lessons', 'activity_count', 20, 'rare', 35, NULL),
    ('speaking_champion', 'Speaking Champion', 'Complete 20 speaking activities', '🎤', 'lessons', 'activity_count', 20, 'rare', 35, NULL)
    ON CONFLICT (code) DO NOTHING;

    -- Streaks Category (10 achievements)
    -- Note: Streak achievements require date-based calculations, simplified to lesson_count for now
    INSERT INTO achievements (code, name, description, icon, category, requirement_type, requirement_value, rarity, points, requirement_count) VALUES
    ('streak_starter', 'Streak Starter', 'Complete lessons for 3 consecutive days', '🔥', 'streaks', 'lesson_count', 3, 'common', 20, NULL),
    ('week_warrior', 'Week Warrior', 'Complete lessons for 7 consecutive days', '📅', 'streaks', 'lesson_count', 7, 'rare', 30, NULL),
    ('two_week_champion', 'Two Week Champion', 'Complete lessons for 14 consecutive days', '🏅', 'streaks', 'lesson_count', 14, 'rare', 40, NULL),
    ('monthly_master', 'Monthly Master', 'Complete lessons for 30 consecutive days', '📆', 'streaks', 'lesson_count', 30, 'epic', 60, NULL),
    ('quarter_champion', 'Quarter Champion', 'Complete lessons for 90 consecutive days', '🎯', 'streaks', 'lesson_count', 90, 'legendary', 100, NULL),
    ('perfect_week', 'Perfect Week', 'Complete lesson every day for 7 days', '✨', 'streaks', 'lesson_count', 7, 'rare', 35, NULL),
    ('perfect_month', 'Perfect Month', 'Complete lesson every day for 30 days', '🌟', 'streaks', 'lesson_count', 30, 'epic', 70, NULL),
    ('unstoppable', 'Unstoppable', 'Complete lessons for 100 consecutive days', '💪', 'streaks', 'lesson_count', 100, 'legendary', 120, NULL),
    ('dedicated', 'Dedicated', 'Complete lessons on 50 different days', '📊', 'streaks', 'lesson_count', 50, 'rare', 40, NULL),
    ('consistent', 'Consistent', 'Complete lessons on 100 different days', '📈', 'streaks', 'lesson_count', 100, 'epic', 60, NULL)
    ON CONFLICT (code) DO NOTHING;

    -- Score & Performance Category (20 achievements)
    INSERT INTO achievements (code, name, description, icon, category, requirement_type, requirement_value, rarity, points, requirement_count) VALUES
    ('good_start', 'Good Start', 'Score 70%+ on first lesson', '👍', 'performance', 'score_average', 70, 'common', 15, 1),
    ('above_average_perf', 'Above Average', 'Score 80%+ on 5 lessons', '📊', 'performance', 'score_threshold_count', 80, 'common', 20, 5),
    ('outstanding', 'Outstanding', 'Score 95%+ on 5 lessons', '⭐', 'performance', 'score_threshold_count', 95, 'rare', 35, 5),
    ('perfect_performance', 'Perfect Performance', 'Score 100% on 3 lessons', '💯', 'performance', 'perfect_score_count', 3, 'rare', 30, NULL),
    ('consistent_performer', 'Consistent Performer', 'Score 80%+ on 10 lessons', '🎯', 'performance', 'score_threshold_count', 80, 'rare', 30, 10),
    ('master_student', 'Master Student', 'Average 95%+ across 25 lessons', '👑', 'performance', 'score_average', 95, 'epic', 60, 25),
    ('elite_performer', 'Elite Performer', 'Score 100% on 15 lessons', '🏆', 'performance', 'perfect_score_count', 15, 'epic', 70, NULL),
    ('grammar_guru', 'Grammar Guru', 'Score 90%+ on 10 grammar activities', '📝', 'performance', 'score_threshold_count', 90, 'rare', 35, 10),
    ('vocabulary_master', 'Vocabulary Master', 'Score 90%+ on 10 vocabulary activities', '📚', 'performance', 'score_threshold_count', 90, 'rare', 35, 10),
    ('speaking_star', 'Speaking Star', 'Score 90%+ on 10 speaking activities', '🎤', 'performance', 'score_threshold_count', 90, 'rare', 35, 10),
    ('activity_ace', 'Activity Ace', 'Complete 30 activities with 100% score', '🎯', 'performance', 'perfect_score_count', 30, 'epic', 55, NULL),
    ('no_mistakes', 'No Mistakes', 'Complete 5 lessons with 100% score', '✨', 'performance', 'perfect_score_count', 5, 'rare', 30, NULL),
    ('quick_learner_perf', 'Quick Learner', 'Complete 5 lessons with 90%+ on first attempt', '🧠', 'performance', 'score_threshold_count', 90, 'rare', 30, 5),
    ('improvement_master', 'Improvement Master', 'Improve score by 20%+ on 5 lessons', '📈', 'performance', 'lesson_count', 5, 'rare', 30, NULL),
    ('steady_progress', 'Steady Progress', 'Improve score on 10 consecutive lessons', '📊', 'performance', 'lesson_count', 10, 'epic', 45, NULL),
    ('top_performer', 'Top Performer', 'Score in top 10% of all lessons', '🥇', 'performance', 'score_average', 95, 'epic', 60, 10),
    ('excellence', 'Excellence', 'Maintain 90%+ average across 50 lessons', '🌟', 'performance', 'score_average', 90, 'legendary', 80, 50),
    ('precision', 'Precision', 'Score exactly 100% on 10 lessons', '🎯', 'performance', 'perfect_score_count', 10, 'epic', 50, NULL),
    ('consistency_king', 'Consistency King', 'Score 85%+ on 30 lessons', '👑', 'performance', 'score_threshold_count', 85, 'epic', 55, 30),
    ('perfection_seeker', 'Perfection Seeker', 'Score 100% on 25 lessons', '💎', 'performance', 'perfect_score_count', 25, 'legendary', 90, NULL)
    ON CONFLICT (code) DO NOTHING;

    -- Stars & Rewards Category (10 achievements)
    INSERT INTO achievements (code, name, description, icon, category, requirement_type, requirement_value, rarity, points, requirement_count) VALUES
    ('star_collector', 'Star Collector', 'Earn 10 stars', '⭐', 'stars', 'stars', 10, 'common', 20, NULL),
    ('star_enthusiast', 'Star Enthusiast', 'Earn 25 stars', '🌟', 'stars', 'stars', 25, 'common', 25, NULL),
    ('star_master', 'Star Master', 'Earn 50 stars', '💫', 'stars', 'stars', 50, 'rare', 35, NULL),
    ('star_champion', 'Star Champion', 'Earn 100 stars', '🏆', 'stars', 'stars', 100, 'rare', 45, NULL),
    ('star_legend', 'Star Legend', 'Earn 200 stars', '👑', 'stars', 'stars', 200, 'epic', 60, NULL),
    ('star_hero', 'Star Hero', 'Earn 300 stars', '🦸', 'stars', 'stars', 300, 'epic', 70, NULL),
    ('star_icon', 'Star Icon', 'Earn 500 stars', '⭐', 'stars', 'stars', 500, 'legendary', 90, NULL),
    ('three_star_master', 'Three Star Master', 'Earn 3 stars on 10 lessons', '💯', 'stars', 'lesson_count', 10, 'rare', 35, NULL),
    ('perfect_star', 'Perfect Star', 'Earn 3 stars on 25 lessons', '✨', 'stars', 'lesson_count', 25, 'epic', 55, NULL),
    ('star_collection', 'Star Collection', 'Earn 3 stars on 50 lessons', '🌟', 'stars', 'lesson_count', 50, 'legendary', 80, NULL)
    ON CONFLICT (code) DO NOTHING;

    -- Titles & Progression Category (10 achievements)
    INSERT INTO achievements (code, name, description, icon, category, requirement_type, requirement_value, rarity, points, requirement_count) VALUES
    ('title_earner', 'Title Earner', 'Earn your first title', '🏷️', 'titles', 'lesson_count', 1, 'common', 15, NULL),
    ('title_collector', 'Title Collector', 'Earn 5 different titles', '📜', 'titles', 'lesson_count', 5, 'common', 25, NULL),
    ('title_master', 'Title Master', 'Earn 10 different titles', '👑', 'titles', 'lesson_count', 10, 'rare', 35, NULL),
    ('title_legend', 'Title Legend', 'Earn 20 different titles', '🌟', 'titles', 'lesson_count', 20, 'epic', 55, NULL),
    ('level_up', 'Level Up', 'Reach A2 level', '⬆️', 'titles', 'lesson_count', 10, 'common', 20, NULL),
    ('advanced', 'Advanced', 'Reach B1 level', '📈', 'titles', 'lesson_count', 20, 'rare', 30, NULL),
    ('expert', 'Expert', 'Reach B2 level', '🎓', 'titles', 'lesson_count', 30, 'rare', 40, NULL),
    ('master_level', 'Master Level', 'Reach C1 level', '👑', 'titles', 'lesson_count', 40, 'epic', 60, NULL),
    ('grandmaster', 'Grandmaster', 'Reach C2 level', '🏆', 'titles', 'lesson_count', 50, 'epic', 70, NULL),
    ('tutorcat', 'TutorCat', 'Reach the ultimate title', '🐱', 'titles', 'lesson_count', 60, 'legendary', 100, NULL)
    ON CONFLICT (code) DO NOTHING;

    -- Activity Types Category (10 achievements)
    INSERT INTO achievements (code, name, description, icon, category, requirement_type, requirement_value, rarity, points, requirement_count) VALUES
    ('warmup_warrior', 'Warmup Warrior', 'Complete 10 warmup activities', '🔥', 'activities', 'activity_count', 10, 'common', 20, NULL),
    ('vocab_veteran', 'Vocab Veteran', 'Complete 30 vocabulary activities', '📚', 'activities', 'activity_count', 30, 'rare', 35, NULL),
    ('grammar_geek', 'Grammar Geek', 'Complete 30 grammar activities', '📝', 'activities', 'activity_count', 30, 'rare', 35, NULL),
    ('speaking_specialist', 'Speaking Specialist', 'Complete 30 speaking activities', '🎤', 'activities', 'activity_count', 30, 'rare', 35, NULL),
    ('listening_learner', 'Listening Learner', 'Complete 10 listening activities', '👂', 'activities', 'activity_count', 10, 'common', 20, NULL),
    ('reading_rookie', 'Reading Rookie', 'Complete 10 reading activities', '📖', 'activities', 'activity_count', 10, 'common', 20, NULL),
    ('activity_enthusiast', 'Activity Enthusiast', 'Complete 100 activities', '🎯', 'activities', 'activity_count', 100, 'epic', 60, NULL),
    ('activity_master', 'Activity Master', 'Complete 200 activities', '👑', 'activities', 'activity_count', 200, 'epic', 70, NULL),
    ('all_around', 'All Around', 'Complete all activity types', '🌐', 'activities', 'activity_count', 6, 'rare', 40, NULL),
    ('completionist', 'Completionist', 'Complete all lessons', '💯', 'activities', 'lesson_count', 100, 'legendary', 100, NULL)
    ON CONFLICT (code) DO NOTHING;

    RAISE NOTICE 'Inserted all 100 achievements successfully!';
END $$;

-- =========================================
-- UTILITY: Award Existing Achievements
-- =========================================
-- Script to check and award achievements for existing user progress
-- This will award achievements that users should have earned based on their current progress
-- Run this for a specific user or all users

-- Uncomment and run to award achievements for all users:
/*
DO $$
DECLARE
    v_user_record RECORD;
    v_earned_count INTEGER := 0;
BEGIN
    -- Loop through all users
    FOR v_user_record IN 
        SELECT id FROM users
    LOOP
        -- Check and award achievements for this user
        -- The function will only award achievements that haven't been earned yet
        PERFORM check_achievements_on_lesson_complete(v_user_record.id);
        
        -- Count how many achievements were just earned (this is approximate)
        SELECT COUNT(*) INTO v_earned_count
        FROM user_achievements
        WHERE user_id = v_user_record.id;
        
        RAISE NOTICE 'Checked achievements for user % - Total earned: %', v_user_record.id, v_earned_count;
    END LOOP;
    
    RAISE NOTICE 'Finished checking achievements for all users!';
END $$;
*/

-- Alternative: Check achievements for a specific user
-- Replace 'USER_UUID_HERE' with the actual user ID
/*
DO $$
DECLARE
    v_user_id UUID := 'USER_UUID_HERE';
    v_earned_achievements RECORD;
BEGIN
    -- Check and award achievements
    FOR v_earned_achievements IN 
        SELECT * FROM check_achievements_on_lesson_complete(v_user_id)
    LOOP
        RAISE NOTICE 'Awarded achievement: % (%)', v_earned_achievements.achievement_name, v_earned_achievements.achievement_code;
    END LOOP;
END $$;
*/
*/