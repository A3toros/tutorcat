-- =========================================
-- Pre-fill Database with Sample Lesson Data
-- A2-L23: Job Schedules
-- =========================================

DELETE FROM grammar_sentences WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'A2-L23');
DELETE FROM vocabulary_items WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'A2-L23');
DELETE FROM lesson_activities WHERE lesson_id = 'A2-L23';
DELETE FROM lessons WHERE id = 'A2-L23';

INSERT INTO lessons (id, level, lesson_number, topic) VALUES
('A2-L23', 'A2', 23, 'Job Schedules')
ON CONFLICT (id) DO UPDATE SET topic = EXCLUDED.topic;

DO $$
DECLARE
    lesson_id_var TEXT := 'A2-L23';
    activity_id_var UUID;
BEGIN
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'warm_up_speaking', 1, 'Work Times', 'Talk about work hours', '{"prompt": "What time do you usually start work or school?"}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_intro', 2, 'Schedule Words', 'Learn job schedule vocabulary', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'shift', 'กะงาน', NULL),
    (activity_id_var, 'schedule', 'ตารางงาน', NULL),
    (activity_id_var, 'overtime', 'ล่วงเวลา', NULL),
    (activity_id_var, 'start', 'เริ่ม', NULL),
    (activity_id_var, 'finish', 'เลิก', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_matching_drag', 3, 'Match Schedule Words', 'Match job schedule words', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'shift', 'กะงาน', NULL),
    (activity_id_var, 'schedule', 'ตารางงาน', NULL),
    (activity_id_var, 'overtime', 'ล่วงเวลา', NULL),
    (activity_id_var, 'start', 'เริ่ม', NULL),
    (activity_id_var, 'finish', 'เลิก', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 4, 'Complete the Sentences 1', 'Fill with the correct word', '{"text": "My ___ starts at 9. I ___ at 6. Today there is ___.", "blanks": [{"id": "blank1", "text": "shift", "options": ["shift", "start", "finish", "overtime"], "correctAnswer": "shift"}, {"id": "blank2", "text": "finish", "options": ["finish", "start", "overtime", "shift"], "correctAnswer": "finish"}, {"id": "blank3", "text": "overtime", "options": ["overtime", "finish", "shift", "start"], "correctAnswer": "overtime"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 5, 'Complete the Sentences 2', 'Fill with the correct word', '{"text": "My ___ shows I ___ at 8. We ___ two hours tonight.", "blanks": [{"id": "blank1", "text": "schedule", "options": ["schedule", "start", "finish", "overtime"], "correctAnswer": "schedule"}, {"id": "blank2", "text": "start", "options": ["start", "finish", "schedule", "overtime"], "correctAnswer": "start"}, {"id": "blank3", "text": "work", "options": ["work", "finish", "start", "overtime"], "correctAnswer": "work"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_explanation', 6, 'Prepositions of Time (work)', 'Talk about start/finish times', '{"rules": "Use at for clock times; on for days.\n- I start at 9.\n- We finish at 6.\n- He works on Saturday.", "examples": ["I start at nine.", "We finish at six.", "She works on Sunday.", "Do you do overtime on Fridays?", "They start at 8 a.m."]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 7, 'Build Sentences 1', 'Arrange words', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'I start at nine', 'I start at nine.', '["I", "start", "at", "nine."]'::jsonb),
    (activity_id_var, 'We finish at six', 'We finish at six.', '["We", "finish", "at", "six."]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 8, 'Build Sentences 2', 'Arrange words', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'Do you work on Sunday', 'Do you work on Sunday?', '["Do", "you", "work", "on", "Sunday?"]'::jsonb),
    (activity_id_var, 'They do overtime on Friday', 'They do overtime on Friday.', '["They", "do", "overtime", "on", "Friday."]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'speaking_practice', 9, 'Talk About Schedules', 'Practice work times', '{"prompts": ["What time do you usually start work or school?", "Do you work or study on weekends?", "How do you feel about working overtime?", "What is your normal daily schedule?", "Do you prefer morning or evening shifts?"]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (
      lesson_id,
      activity_type,
      activity_order,
      title,
      description,
      content
    ) VALUES (
      'A2-L23',
      'speaking_improvement',
      10,
      'Speaking Improvement',
      'Read the improved version of your speech',
      '{"type": "speaking_improvement", "similarityThreshold": 70}'::jsonb
    );
END $$;

