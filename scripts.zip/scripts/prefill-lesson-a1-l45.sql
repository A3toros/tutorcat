-- ===== LESSON A1-L45 =====

-- =========================================
-- Pre-fill Database with Sample Lesson Data
-- A1-L45: Going to School or Work
-- =========================================
DELETE FROM lesson_activity_results WHERE lesson_id = 'A1-L45';
DELETE FROM user_progress WHERE lesson_id = 'A1-L45';
DELETE FROM lesson_history WHERE lesson_id = 'A1-L45';
DELETE FROM grammar_sentences WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'A1-L45');
DELETE FROM vocabulary_items WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'A1-L45');
DELETE FROM lesson_activities WHERE lesson_id = 'A1-L45';
DELETE FROM lessons WHERE id = 'A1-L45';

INSERT INTO lessons (id, level, lesson_number, topic) VALUES
('A1-L45', 'A1', 45, 'Going to School or Work')
ON CONFLICT (id) DO UPDATE SET topic = EXCLUDED.topic;

DO $$
DECLARE
    lesson_id_var TEXT := 'A1-L45';
    activity_id_var UUID;
BEGIN
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'warm_up_speaking', 1, 'How do you go?', 'Talk about going to school or work', '{"prompt": "Do you walk to school?"}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_intro', 2, 'Transport Words', 'Learn transport words', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'bus', 'รถบัส', NULL),
    (activity_id_var, 'walk', 'เดิน', NULL),
    (activity_id_var, 'late', 'สาย', NULL),
    (activity_id_var, 'early', 'เช้า', NULL),
    (activity_id_var, 'bag', 'กระเป๋า', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_matching_drag', 3, 'Match Transport Words', 'Match transport words', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'bus', 'รถบัส', NULL),
    (activity_id_var, 'walk', 'เดิน', NULL),
    (activity_id_var, 'late', 'สาย', NULL),
    (activity_id_var, 'early', 'เช้า', NULL),
    (activity_id_var, 'bag', 'กระเป๋า', NULL);

    -- 4. Vocabulary Fill Blanks #1
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 4, 'Complete the Sentences 1', 'Fill in the blanks with correct words', '{"text": "I take the ___ to school. I ___ every morning. I am never ___.", "blanks": [{"id": "blank1", "text": "bus", "options": ["bus", "walk", "late", "early"], "correctAnswer": "bus"}, {"id": "blank2", "text": "walk", "options": ["bus", "walk", "late", "bag"], "correctAnswer": "walk"}, {"id": "blank3", "text": "late", "options": ["late", "early", "bus", "bag"], "correctAnswer": "late"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    -- 5. Vocabulary Fill Blanks #2
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 5, 'Complete the Sentences 2', 'Fill in the blanks with correct words', '{"text": "I wake up ___ in the morning. I carry my ___ to school. I am never ___.", "blanks": [{"id": "blank1", "text": "early", "options": ["early", "late", "bus", "walk"], "correctAnswer": "early"}, {"id": "blank2", "text": "bag", "options": ["bag", "bus", "walk", "late"], "correctAnswer": "bag"}, {"id": "blank3", "text": "late", "options": ["late", "early", "bus", "walk"], "correctAnswer": "late"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    -- 6. Grammar Explanation
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_explanation', 6, 'Present Simple (Routines)', 'Learn present simple for routines', '{"rules": "Use present simple for daily routines and habits:\n\n- I walk to school every day.\n- She takes the bus.\n- We are never late.\n- Use present simple with time expressions: every day, every morning, always, never", "examples": ["I walk to school every day.", "She takes the bus.", "We are never late.", "I wake up early.", "He carries his bag."]}'::jsonb)
    RETURNING id INTO activity_id_var;

    -- 7. Grammar Sentences #1
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 7, 'Build Sentences 1', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'I walk to school', 'I walk to school.', '["I", "walk", "to", "school."]'::jsonb),
    (activity_id_var, 'She takes the bus', 'She takes the bus.', '["She", "takes", "the", "bus."]'::jsonb);

    -- 8. Grammar Sentences #2
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 8, 'Build Sentences 2', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'We are late', 'We are late.', '["We", "are", "late."]'::jsonb),
    (activity_id_var, 'I wake up early', 'I wake up early.', '["I", "wake", "up", "early."]'::jsonb);

    -- 9. Speaking Practice
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'speaking_practice', 9, 'Talk About Transport', 'Practice talking about transport', '{"prompts": ["How do you go to school?", "Do you like walking?", "What time do you leave home?", "Are you ever late?", "What do you carry to school?"]}'::jsonb)
    RETURNING id INTO activity_id_var;

    -- 10. Speaking Improvement
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'speaking_improvement', 10, 'Speaking Improvement', 'Read the improved version of your speech', '{"type": "speaking_improvement", "similarityThreshold": 70}'::jsonb)
    RETURNING id INTO activity_id_var;
END $$;