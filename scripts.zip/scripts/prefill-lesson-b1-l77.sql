-- =========================================
-- Pre-fill Database with Sample Lesson Data
-- B1-L77: Reporting News
-- =========================================

DELETE FROM grammar_sentences WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'B1-L77');
DELETE FROM vocabulary_items WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'B1-L77');
DELETE FROM lesson_activities WHERE lesson_id = 'B1-L77';
DELETE FROM lessons WHERE id = 'B1-L77';

INSERT INTO lessons (id, level, lesson_number, topic) VALUES
('B1-L77', 'B1', 77, 'Reporting News')
ON CONFLICT (id) DO UPDATE SET topic = EXCLUDED.topic;

DO $$
DECLARE
    lesson_id_var TEXT := 'B1-L77';
    activity_id_var UUID;
BEGIN
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'warm_up_speaking', 1, 'Sharing News', 'Talk about passing on news accurately', '{"prompt": "How do you repeat urgent news accurately?"}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_intro', 2, 'News Reporting Words', 'Learn vocabulary about reporting news', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'report', 'รายงาน', NULL),
    (activity_id_var, 'quote', 'อ้างคำพูด', NULL),
    (activity_id_var, 'confirm', 'ยืนยัน', NULL),
    (activity_id_var, 'deny', 'ปฏิเสธ', NULL),
    (activity_id_var, 'announce', 'ประกาศ', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_matching_drag', 3, 'Match Reporting Words', 'Match words with meanings', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'report', 'รายงาน', NULL),
    (activity_id_var, 'quote', 'อ้างคำพูด', NULL),
    (activity_id_var, 'confirm', 'ยืนยัน', NULL),
    (activity_id_var, 'deny', 'ปฏิเสธ', NULL),
    (activity_id_var, 'announce', 'ประกาศ', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 4, 'Complete the Sentences 1', 'Fill with the correct word', '{"text": "We must ___ facts. They will ___ a statement. Please ___ who said it.", "blanks": [{"id": "blank1", "text": "report", "options": ["report", "announce", "quote", "confirm"], "correctAnswer": "report"}, {"id": "blank2", "text": "announce", "options": ["announce", "quote", "confirm", "deny"], "correctAnswer": "announce"}, {"id": "blank3", "text": "quote", "options": ["quote", "announce", "report", "deny"], "correctAnswer": "quote"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 5, 'Complete the Sentences 2', 'Fill with the correct word', '{"text": "Sources will ___. Others may ___. We must ___ details before sharing.", "blanks": [{"id": "blank1", "text": "confirm", "options": ["confirm", "deny", "report", "announce"], "correctAnswer": "confirm"}, {"id": "blank2", "text": "deny", "options": ["deny", "confirm", "quote", "report"], "correctAnswer": "deny"}, {"id": "blank3", "text": "confirm", "options": ["confirm", "quote", "announce", "deny"], "correctAnswer": "confirm"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    -- Grammar Explanation: Reported Speech (capstone) for urgent news
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_explanation', 6, 'Reported Speech (Statements) Capstone', 'Use said/told + (object) + that + clause; accurate tense shifts', '{"rules": "Reported speech for statements: subject + said/told + (object) + that + clause. Use told + object. Shift tenses when reporting past statements. Keep clarity and accuracy.\\n- They said that the road was closed.\\n- She told us that help was on the way.", "examples": ["They said that the road was closed.", "She told us that help was on the way.", "He said that the event would start soon.", "I told them that the alert was confirmed.", "The officer said that people should stay calm."]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 7, 'Build Sentences 1', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'They said that the road was closed', 'They said that the road was closed', '["They", "said", "that", "the", "road", "was", "closed"]'::jsonb),
    (activity_id_var, 'She told us that help was on the way', 'She told us that help was on the way', '["She", "told", "us", "that", "help", "was", "on", "the", "way"]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 8, 'Build Sentences 2', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'He said that the event would start soon', 'He said that the event would start soon', '["He", "said", "that", "the", "event", "would", "start", "soon"]'::jsonb),
    (activity_id_var, 'I told them that the alert was confirmed', 'I told them that the alert was confirmed', '["I", "told", "them", "that", "the", "alert", "was", "confirmed"]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'speaking_practice', 9, 'Talk About Reporting News', 'Practice talking about sharing news accurately', '{"prompts": ["How do you repeat urgent news accurately?", "When do you add context?", "Describe sharing breaking news with friends."]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (
      lesson_id,
      activity_type,
      activity_order,
      title,
      description,
      content
    ) VALUES (
      'B1-L77',
      'speaking_improvement',
      10,
      'Speaking Improvement',
      'Read the improved version of your speech',
      '{"type": "speaking_improvement", "similarityThreshold": 70}'::jsonb
    );
END $$;

