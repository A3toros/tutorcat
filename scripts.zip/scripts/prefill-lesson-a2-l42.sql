-- =========================================
-- Pre-fill Database with Sample Lesson Data
-- A2-L42: Asking for a Different Size
-- =========================================

DELETE FROM grammar_sentences WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'A2-L42');
DELETE FROM vocabulary_items WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'A2-L42');
DELETE FROM lesson_activities WHERE lesson_id = 'A2-L42';
DELETE FROM lessons WHERE id = 'A2-L42';

INSERT INTO lessons (id, level, lesson_number, topic) VALUES
('A2-L42', 'A2', 42, 'Asking for a Different Size')
ON CONFLICT (id) DO UPDATE SET topic = EXCLUDED.topic;

DO $$
DECLARE
    lesson_id_var TEXT := 'A2-L42';
    activity_id_var UUID;
BEGIN
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'warm_up_speaking', 1, 'Clothes Size', 'Talk about sizes when shopping', '{"prompt": "Are these clothes too big or too small for you?"}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_intro', 2, 'Size Words', 'Learn size and fit words', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'size', 'ขนาด', NULL),
    (activity_id_var, 'fit', 'พอดี', NULL),
    (activity_id_var, 'tight', 'คับ', NULL),
    (activity_id_var, 'loose', 'หลวม', NULL),
    (activity_id_var, 'try on', 'ลอง', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_matching_drag', 3, 'Match Size Words', 'Match clothes size words', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'size', 'ขนาด', NULL),
    (activity_id_var, 'fit', 'พอดี', NULL),
    (activity_id_var, 'tight', 'คับ', NULL),
    (activity_id_var, 'loose', 'หลวม', NULL),
    (activity_id_var, 'try on', 'ลอง', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 4, 'Complete the Sentences 1', 'Fill with the correct word', '{"text": "This ___ is too ___. It doesn''t ___.", "blanks": [{"id": "blank1", "text": "size", "options": ["size", "tight", "fit", "loose"], "correctAnswer": "size"}, {"id": "blank2", "text": "tight", "options": ["tight", "loose", "fit", "size"], "correctAnswer": "tight"}, {"id": "blank3", "text": "fit", "options": ["fit", "size", "loose", "tight"], "correctAnswer": "fit"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 5, 'Complete the Sentences 2', 'Fill with the correct word', '{"text": "Can I ___ a bigger ___? This shirt is too ___.", "blanks": [{"id": "blank1", "text": "try on", "options": ["try on", "size", "tight", "loose"], "correctAnswer": "try on"}, {"id": "blank2", "text": "size", "options": ["size", "loose", "tight", "fit"], "correctAnswer": "size"}, {"id": "blank3", "text": "loose", "options": ["loose", "tight", "fit", "size"], "correctAnswer": "loose"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_explanation', 6, 'Comparatives', 'Compare sizes politely', '{"rules": "Use comparative adjectives to compare.\n- big → bigger; small → smaller; tight → tighter; loose → looser.\nPattern: I need a bigger size.", "examples": ["This shirt is tighter than I like.", "Can I try a bigger size?", "These pants are looser than those.", "This size is smaller than medium.", "A larger size fits better."]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 7, 'Build Sentences 1', 'Arrange words', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'Can I try a bigger size', 'Can I try a bigger size?', '["Can", "I", "try", "a", "bigger", "size?"]'::jsonb),
    (activity_id_var, 'This shirt is tighter than that one', 'This shirt is tighter than that one.', '["This", "shirt", "is", "tighter", "than", "that", "one."]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 8, 'Build Sentences 2', 'Arrange words', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'These pants are looser than those', 'These pants are looser than those.', '["These", "pants", "are", "looser", "than", "those."]'::jsonb),
    (activity_id_var, 'I need a smaller size', 'I need a smaller size.', '["I", "need", "a", "smaller", "size."]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'speaking_practice', 9, 'Talk About Sizes', 'Practice asking for sizes', '{"prompts": ["Are these clothes too big or too small for you?", "Do you ask for a bigger or smaller size?", "Which size fits you better?", "How do you know if clothes fit well?", "Who usually helps you when you shop?"]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (
      lesson_id,
      activity_type,
      activity_order,
      title,
      description,
      content
    ) VALUES (
      'A2-L42',
      'speaking_improvement',
      10,
      'Speaking Improvement',
      'Read the improved version of your speech',
      '{"type": "speaking_improvement", "similarityThreshold": 70}'::jsonb
    );
END $$;

