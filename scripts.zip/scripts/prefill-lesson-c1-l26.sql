-- =========================================
-- Pre-fill Database with Sample Lesson Data
-- C1-L26: Cancel Culture and Debate
-- =========================================
DELETE FROM lesson_activity_results WHERE lesson_id = 'C1-L26';
DELETE FROM user_progress WHERE lesson_id = 'C1-L26';
DELETE FROM lesson_history WHERE lesson_id = 'C1-L26';
DELETE FROM grammar_sentences WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'C1-L26');
DELETE FROM vocabulary_items WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'C1-L26');
DELETE FROM lesson_activities WHERE lesson_id = 'C1-L26';
DELETE FROM lessons WHERE id = 'C1-L26';

INSERT INTO lessons (id, level, lesson_number, topic) VALUES
('C1-L26', 'C1', 26, 'Cancel Culture and Debate')
ON CONFLICT (id) DO UPDATE SET topic = EXCLUDED.topic;

DO $$
DECLARE
    lesson_id_var TEXT := 'C1-L26';
    activity_id_var UUID;
BEGIN
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'warm_up_speaking', 1, 'Cancel Culture', 'Discuss cancel culture and debate', '{"prompt": "When does accountability become silencing?"}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_intro', 2, 'Cancel Culture Vocabulary', 'Learn vocabulary about cancel culture', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'accountability', 'ความรับผิดชอบ', NULL),
    (activity_id_var, 'criticism', 'การวิจารณ์', NULL),
    (activity_id_var, 'outrage', 'ความโกรธ', NULL),
    (activity_id_var, 'debate', 'การโต้วาที', NULL),
    (activity_id_var, 'silencing', 'การทำให้เงียบ', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_matching_drag', 3, 'Match Cancel Culture Words', 'Match English words with Thai meanings', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'accountability', 'ความรับผิดชอบ', NULL),
    (activity_id_var, 'criticism', 'การวิจารณ์', NULL),
    (activity_id_var, 'outrage', 'ความโกรธ', NULL),
    (activity_id_var, 'debate', 'การโต้วาที', NULL),
    (activity_id_var, 'silencing', 'การทำให้เงียบ', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 4, 'Complete the Sentences 1', 'Fill with the correct word', '{"text": "Public ___ demands ___. Constructive ___ differs from ___.", "blanks": [{"id": "blank1", "text": "criticism", "options": ["criticism", "accountability", "outrage", "debate"], "correctAnswer": "criticism"}, {"id": "blank2", "text": "accountability", "options": ["accountability", "criticism", "outrage", "silencing"], "correctAnswer": "accountability"}, {"id": "blank3", "text": "debate", "options": ["debate", "criticism", "accountability", "outrage"], "correctAnswer": "debate"}, {"id": "blank4", "text": "silencing", "options": ["silencing", "criticism", "accountability", "outrage"], "correctAnswer": "silencing"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 5, 'Complete the Sentences 2', 'Fill with the correct word', '{"text": "Online ___ escalates quickly. Respectful ___ promotes understanding.", "blanks": [{"id": "blank1", "text": "outrage", "options": ["outrage", "criticism", "accountability", "debate"], "correctAnswer": "outrage"}, {"id": "blank2", "text": "debate", "options": ["debate", "criticism", "accountability", "outrage"], "correctAnswer": "debate"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_explanation', 6, 'Contrast Linking at C1 Level', 'Learn advanced contrast linking', '{"rules": "C1 contrast linking shows nuanced relationships:\n- \"While/Whereas\" (formal contrast): \"While accountability is important, silencing is harmful.\"\n- \"However/Nevertheless\" (concession): \"Criticism matters; however, silencing prevents debate.\"\n- \"On the one hand... on the other hand\" (balanced contrast)\n- \"Despite/In spite of\" (contrary expectation): \"Despite accountability, silencing occurs.\"\n\nUse for:\n- Presenting balanced views: \"On one hand, accountability is needed; on the other, silencing is wrong.\"\n- Acknowledging complexity: \"While criticism is valid, outrage can be excessive.\"\n- Showing contradiction: \"Accountability is important; however, silencing prevents dialogue.\"", "examples": ["While accountability is important, silencing prevents debate.", "Criticism matters; however, outrage can be excessive.", "On the one hand, accountability is needed; on the other, silencing is harmful.", "Despite valid criticism, silencing undermines free speech.", "Whereas debate promotes understanding, silencing prevents dialogue."]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 7, 'Build Sentences 1', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'While accountability is important, silencing prevents debate.', 'While accountability is important, silencing prevents debate.', '["While", "accountability", "is", "important,", "silencing", "prevents", "debate."]'::jsonb),
    (activity_id_var, 'Criticism matters; however, outrage can be excessive.', 'Criticism matters; however, outrage can be excessive.', '["Criticism", "matters;", "however,", "outrage", "can", "be", "excessive."]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 8, 'Build Sentences 2', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'On the one hand, accountability is needed; on the other, silencing is harmful.', 'On the one hand, accountability is needed; on the other, silencing is harmful.', '["On", "the", "one", "hand,", "accountability", "is", "needed;", "on", "the", "other,", "silencing", "is", "harmful."]'::jsonb),
    (activity_id_var, 'Despite valid criticism, silencing undermines free speech.', 'Despite valid criticism, silencing undermines free speech.', '["Despite", "valid", "criticism,", "silencing", "undermines", "free", "speech."]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'speaking_practice', 9, 'Discuss Cancel Culture', 'Practice speaking about cancel culture', '{"prompts": ["How do you define cancel culture?", "When is public criticism justified?", "How can debate remain respectful?", "What risks come with online outrage?", "How should disagreements be handled?"]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (
      lesson_id,
      activity_type,
      activity_order,
      title,
      description,
      content
    ) VALUES (
      'C1-L26',
      'speaking_improvement',
      10,
      'Speaking Improvement',
      'Read the improved version of your speech',
      '{"type": "speaking_improvement", "similarityThreshold": 70}'::jsonb
    );
END $$;
