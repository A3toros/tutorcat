-- =========================================
-- Pre-fill Database with Sample Lesson Data
-- B1-L71: Community Life
-- =========================================

DELETE FROM grammar_sentences WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'B1-L71');
DELETE FROM vocabulary_items WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'B1-L71');
DELETE FROM lesson_activities WHERE lesson_id = 'B1-L71';
DELETE FROM lessons WHERE id = 'B1-L71';

INSERT INTO lessons (id, level, lesson_number, topic) VALUES
('B1-L71', 'B1', 71, 'Community Life')
ON CONFLICT (id) DO UPDATE SET topic = EXCLUDED.topic;

DO $$
DECLARE
    lesson_id_var TEXT := 'B1-L71';
    activity_id_var UUID;
BEGIN
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'warm_up_speaking', 1, 'Your Community', 'Talk about what makes your community strong', '{"prompt": "What makes your community feel strong?"}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_intro', 2, 'Community Words', 'Learn vocabulary about community life', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'neighbor', 'เพื่อนบ้าน', NULL),
    (activity_id_var, 'event', 'กิจกรรม', NULL),
    (activity_id_var, 'park', 'สวนสาธารณะ', NULL),
    (activity_id_var, 'service', 'บริการ', NULL),
    (activity_id_var, 'support', 'การสนับสนุน', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_matching_drag', 3, 'Match Community Words', 'Match words with meanings', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'neighbor', 'เพื่อนบ้าน', NULL),
    (activity_id_var, 'event', 'กิจกรรม', NULL),
    (activity_id_var, 'park', 'สวนสาธารณะ', NULL),
    (activity_id_var, 'service', 'บริการ', NULL),
    (activity_id_var, 'support', 'การสนับสนุน', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 4, 'Complete the Sentences 1', 'Fill with the correct word', '{"text": "My ___ invited me. We met at the ___. A local ___ helped families.", "blanks": [{"id": "blank1", "text": "neighbor", "options": ["neighbor", "event", "park", "service"], "correctAnswer": "neighbor"}, {"id": "blank2", "text": "park", "options": ["park", "event", "service", "support"], "correctAnswer": "park"}, {"id": "blank3", "text": "service", "options": ["service", "support", "event", "neighbor"], "correctAnswer": "service"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 5, 'Complete the Sentences 2', 'Fill with the correct word', '{"text": "The ___ was lively. People offered ___. We felt strong ___ from others.", "blanks": [{"id": "blank1", "text": "event", "options": ["event", "neighbor", "park", "service"], "correctAnswer": "event"}, {"id": "blank2", "text": "support", "options": ["support", "service", "park", "event"], "correctAnswer": "support"}, {"id": "blank3", "text": "support", "options": ["support", "service", "event", "neighbor"], "correctAnswer": "support"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    -- Grammar Explanation: Articles (review) in community contexts
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_explanation', 6, 'Articles in Community Life', 'Use the/zero article for specific vs general community items', '{"rules": "Use the for specific known items: the park, the event. Use zero article for general plural/uncountable: attend events, join services.\\nKeep usage simple and clear.", "examples": ["The park is busy on weekends.", "We joined community events this year.", "The service is free for neighbors.", "People share support at the event.", "Volunteers help at the park."]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 7, 'Build Sentences 1', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'The park is busy on weekends', 'The park is busy on weekends', '["The", "park", "is", "busy", "on", "weekends"]'::jsonb),
    (activity_id_var, 'We joined community events this year', 'We joined community events this year', '["We", "joined", "community", "events", "this", "year"]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 8, 'Build Sentences 2', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'The service is free for neighbors', 'The service is free for neighbors', '["The", "service", "is", "free", "for", "neighbors"]'::jsonb),
    (activity_id_var, 'Volunteers help at the park', 'Volunteers help at the park', '["Volunteers", "help", "at", "the", "park"]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'speaking_practice', 9, 'Talk About Community', 'Practice talking about community life', '{"prompts": ["What makes your community feel strong?", "Which local event do you actually enjoy?", "How do you get involved where you live?"]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (
      lesson_id,
      activity_type,
      activity_order,
      title,
      description,
      content
    ) VALUES (
      'B1-L71',
      'speaking_improvement',
      10,
      'Speaking Improvement',
      'Read the improved version of your speech',
      '{"type": "speaking_improvement", "similarityThreshold": 70}'::jsonb
    );
END $$;

