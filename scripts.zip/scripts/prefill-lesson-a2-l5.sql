-- =========================================
-- Pre-fill Database with Sample Lesson Data
-- A2-L5: Health & Illness
-- =========================================

-- Clear existing sample data for A2-L5 (optional - comment out if you want to keep existing data)
DELETE FROM grammar_sentences WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'A2-L5');
DELETE FROM vocabulary_items WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'A2-L5');
DELETE FROM lesson_activities WHERE lesson_id = 'A2-L5';
DELETE FROM lessons WHERE id = 'A2-L5';

INSERT INTO lessons (id, level, lesson_number, topic) VALUES
('A2-L5', 'A2', 5, 'Health & Illness')
ON CONFLICT (id) DO UPDATE SET topic = EXCLUDED.topic;

DO $$
DECLARE
    lesson_id_var TEXT := 'A2-L5';
    activity_id_var UUID;
BEGIN
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content) VALUES (lesson_id_var, 'warm_up_speaking', 1, 'Health Talk', 'Talk about health', '{"prompt": "What do you do to stay healthy?"}'::jsonb) RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content) VALUES (lesson_id_var, 'vocabulary_intro', 2, 'Health Words', 'Learn health vocabulary', '{}'::jsonb) RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'headache', 'ปวดหัว', NULL),
    (activity_id_var, 'fever', 'ไข้', NULL),
    (activity_id_var, 'medicine', 'ยา', NULL),
    (activity_id_var, 'doctor', 'หมอ', NULL),
    (activity_id_var, 'hospital', 'โรงพยาบาล', NULL);

    -- 3. Vocabulary Matching Drag #1 (5 pairs - same words)
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content) VALUES (lesson_id_var, 'vocabulary_matching_drag', 3, 'Match Health Words 1', 'Match English words with Thai meanings', '{}'::jsonb) RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'headache', 'ปวดหัว', NULL),
    (activity_id_var, 'fever', 'ไข้', NULL),
    (activity_id_var, 'medicine', 'ยา', NULL),
    (activity_id_var, 'doctor', 'หมอ', NULL),
    (activity_id_var, 'hospital', 'โรงพยาบาล', NULL);

    

    -- 4. Vocabulary Fill Blanks #1 (4 words: headache, fever, medicine, doctor - hospital left out)
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content) VALUES (lesson_id_var, 'vocabulary_fill_blanks', 4, 'Complete the Sentences 1', 'Fill in the blanks with correct words', '{"text": "I have a bad ___ and my head hurts. I also have a high ___ of 39 degrees. I need to take ___ for my symptoms. I should see a ___ tomorrow if I don''t feel better.", "blanks": [{"id": "blank1", "text": "headache", "options": ["headache", "fever", "medicine", "doctor"], "correctAnswer": "headache"}, {"id": "blank2", "text": "fever", "options": ["headache", "fever", "medicine", "doctor"], "correctAnswer": "fever"}, {"id": "blank3", "text": "medicine", "options": ["headache", "fever", "medicine", "doctor"], "correctAnswer": "medicine"}, {"id": "blank4", "text": "doctor", "options": ["headache", "fever", "medicine", "doctor"], "correctAnswer": "doctor"}]}'::jsonb) RETURNING id INTO activity_id_var;

    -- 4. Vocabulary Fill Blanks #2 (4 words: headache, fever, medicine, hospital - doctor left out)
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content) VALUES (lesson_id_var, 'vocabulary_fill_blanks', 5, 'Complete the Sentences 2', 'Fill in the blanks with correct words', '{"text": "My ___ is very bad and won''t stop. I have a high ___ of 40 degrees. I took some ___ but it didn''t help. I went to the ___ for emergency care.", "blanks": [{"id": "blank1", "text": "headache", "options": ["headache", "fever", "medicine", "hospital"], "correctAnswer": "headache"}, {"id": "blank2", "text": "fever", "options": ["headache", "fever", "medicine", "hospital"], "correctAnswer": "fever"}, {"id": "blank3", "text": "medicine", "options": ["headache", "fever", "medicine", "hospital"], "correctAnswer": "medicine"}, {"id": "blank4", "text": "hospital", "options": ["headache", "fever", "medicine", "hospital"], "correctAnswer": "hospital"}]}'::jsonb) RETURNING id INTO activity_id_var;

    -- 4. Grammar Explanation (5 examples - CEFR A2: Health vocabulary, describing symptoms)
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content) VALUES (lesson_id_var, 'grammar_explanation', 6, 'I have / I feel', 'Learn to describe health problems', '{"rules": "Use ''I have'' for symptoms and ''I feel'' for feelings:\n\n- I have + symptom (I have a headache)\n- I feel + adjective (I feel sick)\n- I feel + better/worse (I feel better now)\n- What''s wrong? / What''s the matter?\n- Should + verb (You should see a doctor)", "examples": ["I have a headache.", "I feel sick today.", "She has a fever.", "I feel better now.", "What''s wrong with you?"]}'::jsonb) RETURNING id INTO activity_id_var;

    -- 4. Grammar Sentences #1
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content) VALUES (lesson_id_var, 'grammar_sentences', 7, 'Build Sentences 1', 'Arrange words to make sentences', '{}'::jsonb) RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'I have a headache', 'I have a headache', '["I", "have", "a", "headache"]'::jsonb),
    (activity_id_var, 'I feel sick today', 'I feel sick today', '["I", "feel", "sick", "today"]'::jsonb);
    -- 4. Grammar Sentences #2
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content) VALUES (lesson_id_var, 'grammar_sentences', 8, 'Build Sentences 2', 'Arrange words to make sentences', '{}'::jsonb) RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'She has a fever', 'She has a fever', '["She", "has", "a", "fever"]'::jsonb),
    (activity_id_var, 'I feel better now', 'I feel better now', '["I", "feel", "better", "now"]'::jsonb);
    -- 4. Speaking Practice (5 prompts - CEFR A2: Health conversations)
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content) VALUES (lesson_id_var, 'speaking_practice', 9, 'Talk About Health', 'Practice talking about health', '{"prompts": ["How do you feel today?", "What do you do when you feel sick?", "Have you ever been to a hospital or clinic?", "What do you do when you have a headache or fever?", "Do you exercise to stay healthy?"]}'::jsonb) RETURNING id INTO activity_id_var;

END $$;
