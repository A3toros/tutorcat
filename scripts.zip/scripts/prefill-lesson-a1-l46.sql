-- ===== LESSON A1-L46 =====

-- =========================================
-- Pre-fill Database with Sample Lesson Data
-- A1-L46: Bathroom Objects
-- =========================================

DELETE FROM grammar_sentences WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'A1-L46');
DELETE FROM vocabulary_items WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'A1-L46');
DELETE FROM lesson_activities WHERE lesson_id = 'A1-L46';
DELETE FROM lessons WHERE id = 'A1-L46';

INSERT INTO lessons (id, level, lesson_number, topic) VALUES
('A1-L46', 'A1', 46, 'Bathroom Objects')
ON CONFLICT (id) DO UPDATE SET topic = EXCLUDED.topic;

DO $$
DECLARE
    lesson_id_var TEXT := 'A1-L46';
    activity_id_var UUID;
BEGIN
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'warm_up_speaking', 1, 'Bathroom Things', 'Talk about bathroom objects', '{"prompt": "Is there a towel?"}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_intro', 2, 'Bathroom Words', 'Learn bathroom words', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'soap', 'สบู่', NULL),
    (activity_id_var, 'towel', 'ผ้าเช็ดตัว', NULL),
    (activity_id_var, 'mirror', 'กระจก', NULL),
    (activity_id_var, 'sink', 'อ่างล้างหน้า', NULL),
    (activity_id_var, 'toilet', 'โถส้วม', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_matching_drag', 3, 'Match Bathroom Words', 'Match bathroom words', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'soap', 'สบู่', NULL),
    (activity_id_var, 'towel', 'ผ้าเช็ดตัว', NULL),
    (activity_id_var, 'mirror', 'กระจก', NULL),
    (activity_id_var, 'sink', 'อ่างล้างหน้า', NULL),
    (activity_id_var, 'toilet', 'โถส้วม', NULL);

    -- 4. Vocabulary Fill Blanks #1
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 4, 'Complete the Sentences 1', 'Fill in the blanks with correct words', '{"text": "There is a ___ in the bathroom. There is a ___ on the wall. There is a ___ next to the sink.", "blanks": [{"id": "blank1", "text": "towel", "options": ["towel", "soap", "mirror", "sink"], "correctAnswer": "towel"}, {"id": "blank2", "text": "mirror", "options": ["mirror", "soap", "towel", "toilet"], "correctAnswer": "mirror"}, {"id": "blank3", "text": "soap", "options": ["soap", "towel", "mirror", "sink"], "correctAnswer": "soap"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    -- 5. Vocabulary Fill Blanks #2
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 5, 'Complete the Sentences 2', 'Fill in the blanks with correct words', '{"text": "There is a ___ in the bathroom. The ___ is white. I wash my hands in the ___.", "blanks": [{"id": "blank1", "text": "toilet", "options": ["toilet", "sink", "mirror", "towel"], "correctAnswer": "toilet"}, {"id": "blank2", "text": "sink", "options": ["sink", "toilet", "mirror", "soap"], "correctAnswer": "sink"}, {"id": "blank3", "text": "sink", "options": ["sink", "toilet", "mirror", "towel"], "correctAnswer": "sink"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    -- 6. Grammar Explanation
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_explanation', 6, 'There is/are + Objects', 'Learn there is/are with objects', '{"rules": "Use there is/there are to talk about objects:\n\n- There is + singular (There is a towel)\n- There are + plural (There are mirrors)\n- Use this is for pointing (This is the sink)\n- Use a/an for singular, no article for plural", "examples": ["There is a towel.", "There are mirrors.", "This is the sink.", "There is soap.", "There are two sinks."]}'::jsonb)
    RETURNING id INTO activity_id_var;

    -- 7. Grammar Sentences #1
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 7, 'Build Sentences 1', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'There is a towel', 'There is a towel.', '["There", "is", "a", "towel."]'::jsonb),
    (activity_id_var, 'There are mirrors', 'There are mirrors.', '["There", "are", "mirrors."]'::jsonb);

    -- 8. Grammar Sentences #2
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 8, 'Build Sentences 2', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'This is the sink', 'This is the sink.', '["This", "is", "the", "sink."]'::jsonb),
    (activity_id_var, 'There is soap', 'There is soap.', '["There", "is", "soap."]'::jsonb);

    -- 9. Speaking Practice
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'speaking_practice', 9, 'Talk About Bathroom', 'Practice talking about bathroom', '{"prompts": ["What do you see in your bathroom?", "Is there a mirror in the bathroom?", "What color is your towel?", "Where is the soap?", "Is there a sink?"]}'::jsonb)
    RETURNING id INTO activity_id_var;

    -- 10. Speaking Improvement
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'speaking_improvement', 10, 'Speaking Improvement', 'Read the improved version of your speech', '{"type": "speaking_improvement", "similarityThreshold": 70}'::jsonb)
    RETURNING id INTO activity_id_var;
END $$;