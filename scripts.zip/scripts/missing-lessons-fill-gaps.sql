-- =========================================
-- MISSING LESSONS TO FILL GAPS
-- =========================================
-- This file contains lessons to fill the gaps identified in the existing SQL files:
-- A1: Missing lessons 45-50 (6 lessons)
-- B1: Missing lessons 61-70 (10 lessons)
-- B2: Missing lessons 51-60 and 81-90 (20 lessons)
-- Total: 36 missing lessons
--
-- To use: Run this file after running the main lesson files to fill the gaps.
-- =========================================

-- ===== A1 MISSING LESSONS 45-50 =====

-- ===== LESSON A1-L45 =====

-- =========================================
-- Pre-fill Database with Sample Lesson Data
-- A1-L45: Going to School or Work
-- =========================================
DELETE FROM lesson_activity_results WHERE lesson_id = 'A1-L45';
DELETE FROM user_progress WHERE lesson_id = 'A1-L45';
DELETE FROM lesson_history WHERE lesson_id = 'A1-L45';
DELETE FROM grammar_sentences WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'A1-L45');
DELETE FROM vocabulary_items WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'A1-L45');
DELETE FROM lesson_activities WHERE lesson_id = 'A1-L45';
DELETE FROM lessons WHERE id = 'A1-L45';

INSERT INTO lessons (id, level, lesson_number, topic) VALUES
('A1-L45', 'A1', 45, 'Going to School or Work')
ON CONFLICT (id) DO UPDATE SET topic = EXCLUDED.topic;

DO $$
DECLARE
    lesson_id_var TEXT := 'A1-L45';
    activity_id_var UUID;
BEGIN
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'warm_up_speaking', 1, 'How do you go?', 'Talk about going to school or work', '{"prompt": "Do you walk to school?"}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_intro', 2, 'Transport Words', 'Learn transport words', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'bus', 'รถบัส', NULL),
    (activity_id_var, 'walk', 'เดิน', NULL),
    (activity_id_var, 'late', 'สาย', NULL),
    (activity_id_var, 'early', 'เช้า', NULL),
    (activity_id_var, 'bag', 'กระเป๋า', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_matching_drag', 3, 'Match Transport Words', 'Match transport words', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'bus', 'รถบัส', NULL),
    (activity_id_var, 'walk', 'เดิน', NULL),
    (activity_id_var, 'late', 'สาย', NULL),
    (activity_id_var, 'early', 'เช้า', NULL),
    (activity_id_var, 'bag', 'กระเป๋า', NULL);

    -- 4. Vocabulary Fill Blanks #1
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 4, 'Complete the Sentences 1', 'Fill in the blanks with correct words', '{"text": "I take the ___ to school. I ___ every morning. I am never ___.", "blanks": [{"id": "blank1", "text": "bus", "options": ["bus", "walk", "late", "early"], "correctAnswer": "bus"}, {"id": "blank2", "text": "walk", "options": ["bus", "walk", "late", "bag"], "correctAnswer": "walk"}, {"id": "blank3", "text": "late", "options": ["late", "early", "bus", "bag"], "correctAnswer": "late"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    -- 5. Vocabulary Fill Blanks #2
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 5, 'Complete the Sentences 2', 'Fill in the blanks with correct words', '{"text": "I wake up ___ in the morning. I carry my ___ to school. I am never ___.", "blanks": [{"id": "blank1", "text": "early", "options": ["early", "late", "bus", "walk"], "correctAnswer": "early"}, {"id": "blank2", "text": "bag", "options": ["bag", "bus", "walk", "late"], "correctAnswer": "bag"}, {"id": "blank3", "text": "late", "options": ["late", "early", "bus", "walk"], "correctAnswer": "late"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    -- 6. Grammar Explanation
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_explanation', 6, 'Present Simple (Routines)', 'Learn present simple for routines', '{"rules": "Use present simple for daily routines and habits:\n\n- I walk to school every day.\n- She takes the bus.\n- We are never late.\n- Use present simple with time expressions: every day, every morning, always, never", "examples": ["I walk to school every day.", "She takes the bus.", "We are never late.", "I wake up early.", "He carries his bag."]}'::jsonb)
    RETURNING id INTO activity_id_var;

    -- 7. Grammar Sentences #1
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 7, 'Build Sentences 1', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'I walk to school', 'I walk to school.', '["I", "walk", "to", "school."]'::jsonb),
    (activity_id_var, 'She takes the bus', 'She takes the bus.', '["She", "takes", "the", "bus."]'::jsonb);

    -- 8. Grammar Sentences #2
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 8, 'Build Sentences 2', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'We are late', 'We are late.', '["We", "are", "late."]'::jsonb),
    (activity_id_var, 'I wake up early', 'I wake up early.', '["I", "wake", "up", "early."]'::jsonb);

    -- 9. Speaking Practice
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'speaking_practice', 9, 'Talk About Transport', 'Practice talking about transport', '{"prompts": ["How do you go to school?", "Do you like walking?", "What time do you leave home?", "Are you ever late?", "What do you carry to school?"]}'::jsonb)
    RETURNING id INTO activity_id_var;

    -- 10. Speaking Improvement
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'speaking_improvement', 10, 'Speaking Improvement', 'Read the improved version of your speech', '{"type": "speaking_improvement", "similarityThreshold": 70}'::jsonb)
    RETURNING id INTO activity_id_var;
END $$;


-- ===== LESSON A1-L46 =====

-- =========================================
-- Pre-fill Database with Sample Lesson Data
-- A1-L46: Bathroom Objects
-- =========================================

DELETE FROM grammar_sentences WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'A1-L46');
DELETE FROM vocabulary_items WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'A1-L46');
DELETE FROM lesson_activities WHERE lesson_id = 'A1-L46';
DELETE FROM lessons WHERE id = 'A1-L46';

INSERT INTO lessons (id, level, lesson_number, topic) VALUES
('A1-L46', 'A1', 46, 'Bathroom Objects')
ON CONFLICT (id) DO UPDATE SET topic = EXCLUDED.topic;

DO $$
DECLARE
    lesson_id_var TEXT := 'A1-L46';
    activity_id_var UUID;
BEGIN
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'warm_up_speaking', 1, 'Bathroom Things', 'Talk about bathroom objects', '{"prompt": "Is there a towel?"}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_intro', 2, 'Bathroom Words', 'Learn bathroom words', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'soap', 'สบู่', NULL),
    (activity_id_var, 'towel', 'ผ้าเช็ดตัว', NULL),
    (activity_id_var, 'mirror', 'กระจก', NULL),
    (activity_id_var, 'sink', 'อ่างล้างหน้า', NULL),
    (activity_id_var, 'toilet', 'โถส้วม', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_matching_drag', 3, 'Match Bathroom Words', 'Match bathroom words', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'soap', 'สบู่', NULL),
    (activity_id_var, 'towel', 'ผ้าเช็ดตัว', NULL),
    (activity_id_var, 'mirror', 'กระจก', NULL),
    (activity_id_var, 'sink', 'อ่างล้างหน้า', NULL),
    (activity_id_var, 'toilet', 'โถส้วม', NULL);

    -- 4. Vocabulary Fill Blanks #1
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 4, 'Complete the Sentences 1', 'Fill in the blanks with correct words', '{"text": "There is a ___ in the bathroom. There is a ___ on the wall. There is a ___ next to the sink.", "blanks": [{"id": "blank1", "text": "towel", "options": ["towel", "soap", "mirror", "sink"], "correctAnswer": "towel"}, {"id": "blank2", "text": "mirror", "options": ["mirror", "soap", "towel", "toilet"], "correctAnswer": "mirror"}, {"id": "blank3", "text": "soap", "options": ["soap", "towel", "mirror", "sink"], "correctAnswer": "soap"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    -- 5. Vocabulary Fill Blanks #2
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 5, 'Complete the Sentences 2', 'Fill in the blanks with correct words', '{"text": "There is a ___ in the bathroom. The ___ is white. I wash my hands in the ___.", "blanks": [{"id": "blank1", "text": "toilet", "options": ["toilet", "sink", "mirror", "towel"], "correctAnswer": "toilet"}, {"id": "blank2", "text": "sink", "options": ["sink", "toilet", "mirror", "soap"], "correctAnswer": "sink"}, {"id": "blank3", "text": "sink", "options": ["sink", "toilet", "mirror", "towel"], "correctAnswer": "sink"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    -- 6. Grammar Explanation
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_explanation', 6, 'There is/are + Objects', 'Learn there is/are with objects', '{"rules": "Use there is/there are to talk about objects:\n\n- There is + singular (There is a towel)\n- There are + plural (There are mirrors)\n- Use this is for pointing (This is the sink)\n- Use a/an for singular, no article for plural", "examples": ["There is a towel.", "There are mirrors.", "This is the sink.", "There is soap.", "There are two sinks."]}'::jsonb)
    RETURNING id INTO activity_id_var;

    -- 7. Grammar Sentences #1
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 7, 'Build Sentences 1', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'There is a towel', 'There is a towel.', '["There", "is", "a", "towel."]'::jsonb),
    (activity_id_var, 'There are mirrors', 'There are mirrors.', '["There", "are", "mirrors."]'::jsonb);

    -- 8. Grammar Sentences #2
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 8, 'Build Sentences 2', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'This is the sink', 'This is the sink.', '["This", "is", "the", "sink."]'::jsonb),
    (activity_id_var, 'There is soap', 'There is soap.', '["There", "is", "soap."]'::jsonb);

    -- 9. Speaking Practice
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'speaking_practice', 9, 'Talk About Bathroom', 'Practice talking about bathroom', '{"prompts": ["What do you see in your bathroom?", "Is there a mirror in the bathroom?", "What color is your towel?", "Where is the soap?", "Is there a sink?"]}'::jsonb)
    RETURNING id INTO activity_id_var;

    -- 10. Speaking Improvement
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'speaking_improvement', 10, 'Speaking Improvement', 'Read the improved version of your speech', '{"type": "speaking_improvement", "similarityThreshold": 70}'::jsonb)
    RETURNING id INTO activity_id_var;
END $$;


-- ===== LESSON A1-L47 =====

-- =========================================
-- Pre-fill Database with Sample Lesson Data
-- A1-L47: Favorite Things
-- =========================================

DELETE FROM grammar_sentences WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'A1-L47');
DELETE FROM vocabulary_items WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'A1-L47');
DELETE FROM lesson_activities WHERE lesson_id = 'A1-L47';
DELETE FROM lessons WHERE id = 'A1-L47';

INSERT INTO lessons (id, level, lesson_number, topic) VALUES
('A1-L47', 'A1', 47, 'Favorite Things')
ON CONFLICT (id) DO UPDATE SET topic = EXCLUDED.topic;

DO $$
DECLARE
    lesson_id_var TEXT := 'A1-L47';
    activity_id_var UUID;
BEGIN
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'warm_up_speaking', 1, 'What do you like?', 'Talk about favorite things', '{"prompt": "Do you like rice?"}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_intro', 2, 'Favorite Words', 'Learn favorite words', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'toy', 'ของเล่น', NULL),
    (activity_id_var, 'game', 'เกม', NULL),
    (activity_id_var, 'song', 'เพลง', NULL),
    (activity_id_var, 'movie', 'หนัง', NULL),
    (activity_id_var, 'book', 'หนังสือ', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_matching_drag', 3, 'Match Favorite Words', 'Match favorite words', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'toy', 'ของเล่น', NULL),
    (activity_id_var, 'game', 'เกม', NULL),
    (activity_id_var, 'song', 'เพลง', NULL),
    (activity_id_var, 'movie', 'หนัง', NULL),
    (activity_id_var, 'book', 'หนังสือ', NULL);

    -- 4. Vocabulary Fill Blanks #1
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 4, 'Complete the Sentences 1', 'Fill in the blanks with correct words', '{"text": "I like to play with my ___. I listen to my favorite ___. I read a ___.", "blanks": [{"id": "blank1", "text": "toy", "options": ["toy", "game", "song", "movie"], "correctAnswer": "toy"}, {"id": "blank2", "text": "song", "options": ["song", "toy", "game", "book"], "correctAnswer": "song"}, {"id": "blank3", "text": "book", "options": ["book", "toy", "song", "movie"], "correctAnswer": "book"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    -- 5. Vocabulary Fill Blanks #2
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 5, 'Complete the Sentences 2', 'Fill in the blanks with correct words', '{"text": "I play a ___. I watch a ___. My favorite ___ is fun.", "blanks": [{"id": "blank1", "text": "game", "options": ["game", "toy", "song", "movie"], "correctAnswer": "game"}, {"id": "blank2", "text": "movie", "options": ["movie", "toy", "game", "book"], "correctAnswer": "movie"}, {"id": "blank3", "text": "game", "options": ["game", "toy", "song", "book"], "correctAnswer": "game"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    -- 6. Grammar Explanation
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_explanation', 6, 'Like / Don''t Like', 'Learn like/don''t like preferences', '{"rules": "Use like to talk about preferences:\n\n- I like + noun (I like rice)\n- She likes + noun (She likes games)\n- They don''t like + noun (They don''t like movies)\n- Use likes for he/she/it, like for I/you/we/they", "examples": ["I like rice.", "She likes games.", "They don''t like movies.", "We like books.", "He doesn''t like toys."]}'::jsonb)
    RETURNING id INTO activity_id_var;

    -- 7. Grammar Sentences #1
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 7, 'Build Sentences 1', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'I like rice', 'I like rice.', '["I", "like", "rice."]'::jsonb),
    (activity_id_var, 'She likes games', 'She likes games.', '["She", "likes", "games."]'::jsonb);

    -- 8. Grammar Sentences #2
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 8, 'Build Sentences 2', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'They don''t like movies', 'They don''t like movies.', '["They", "don''t", "like", "movies."]'::jsonb),
    (activity_id_var, 'We like books', 'We like books.', '["We", "like", "books."]'::jsonb);

    -- 9. Speaking Practice
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'speaking_practice', 9, 'Talk About Favorites', 'Practice talking about favorites', '{"prompts": ["What is your favorite food?", "Do you like listening to music?", "What games do you play?", "What is your favorite movie?", "Do you like reading books?"]}'::jsonb)
    RETURNING id INTO activity_id_var;

    -- 10. Speaking Improvement
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'speaking_improvement', 10, 'Speaking Improvement', 'Read the improved version of your speech', '{"type": "speaking_improvement", "similarityThreshold": 70}'::jsonb)
    RETURNING id INTO activity_id_var;
END $$;


-- ===== LESSON A1-L48 =====

-- =========================================
-- Pre-fill Database with Sample Lesson Data
-- A1-L48: Near and Far
-- =========================================

DELETE FROM grammar_sentences WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'A1-L48');
DELETE FROM vocabulary_items WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'A1-L48');
DELETE FROM lesson_activities WHERE lesson_id = 'A1-L48';
DELETE FROM lessons WHERE id = 'A1-L48';

INSERT INTO lessons (id, level, lesson_number, topic) VALUES
('A1-L48', 'A1', 48, 'Near and Far')
ON CONFLICT (id) DO UPDATE SET topic = EXCLUDED.topic;

DO $$
DECLARE
    lesson_id_var TEXT := 'A1-L48';
    activity_id_var UUID;
BEGIN
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'warm_up_speaking', 1, 'Near or far?', 'Talk about near and far', '{"prompt": "Is this near?"}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_intro', 2, 'Position Words', 'Learn position words', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'near', 'ใกล้', NULL),
    (activity_id_var, 'far', 'ไกล', NULL),
    (activity_id_var, 'here', 'ที่นี่', NULL),
    (activity_id_var, 'there', 'ที่นั่น', NULL),
    (activity_id_var, 'close', 'ใกล้ชิด', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_matching_drag', 3, 'Match Position Words', 'Match position words', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'near', 'ใกล้', NULL),
    (activity_id_var, 'far', 'ไกล', NULL),
    (activity_id_var, 'here', 'ที่นี่', NULL),
    (activity_id_var, 'there', 'ที่นั่น', NULL),
    (activity_id_var, 'close', 'ใกล้ชิด', NULL);

    -- 4. Vocabulary Fill Blanks #1
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 4, 'Complete the Sentences 1', 'Fill in the blanks with correct words', '{"text": "The school is ___ my house. The park is ___. I am ___.", "blanks": [{"id": "blank1", "text": "near", "options": ["near", "far", "here", "there"], "correctAnswer": "near"}, {"id": "blank2", "text": "far", "options": ["far", "near", "here", "close"], "correctAnswer": "far"}, {"id": "blank3", "text": "here", "options": ["here", "there", "near", "far"], "correctAnswer": "here"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    -- 5. Vocabulary Fill Blanks #2
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 5, 'Complete the Sentences 2', 'Fill in the blanks with correct words', '{"text": "The store is ___. My friend is ___. We are ___.", "blanks": [{"id": "blank1", "text": "there", "options": ["there", "here", "near", "far"], "correctAnswer": "there"}, {"id": "blank2", "text": "close", "options": ["close", "far", "here", "there"], "correctAnswer": "close"}, {"id": "blank3", "text": "near", "options": ["near", "far", "here", "there"], "correctAnswer": "near"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    -- 6. Grammar Explanation
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_explanation', 6, 'This/That/These/Those', 'Learn this/that/these/those', '{"rules": "Use this/that/these/those to point to things:\n\n- This (near, singular): This is near\n- That (far, singular): That is far\n- These (near, plural): These are close\n- Those (far, plural): Those are far\n- Use is with this/that, are with these/those", "examples": ["This is near.", "That is far.", "These are close.", "Those are far.", "This is here."]}'::jsonb)
    RETURNING id INTO activity_id_var;

    -- 7. Grammar Sentences #1
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 7, 'Build Sentences 1', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'This is near', 'This is near.', '["This", "is", "near."]'::jsonb),
    (activity_id_var, 'That is far', 'That is far.', '["That", "is", "far."]'::jsonb);

    -- 8. Grammar Sentences #2
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 8, 'Build Sentences 2', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'These are close', 'These are close.', '["These", "are", "close."]'::jsonb),
    (activity_id_var, 'That is there', 'That is there.', '["That", "is", "there."]'::jsonb);

    -- 9. Speaking Practice
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'speaking_practice', 9, 'Talk About Positions', 'Practice talking about positions', '{"prompts": ["Where is your school?", "Is your home near the school?", "What is near your house?", "What is far from your house?", "Where are you now?"]}'::jsonb)
    RETURNING id INTO activity_id_var;

    -- 10. Speaking Improvement
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'speaking_improvement', 10, 'Speaking Improvement', 'Read the improved version of your speech', '{"type": "speaking_improvement", "similarityThreshold": 70}'::jsonb)
    RETURNING id INTO activity_id_var;
END $$;


-- ===== LESSON A1-L49 =====

-- =========================================
-- Pre-fill Database with Sample Lesson Data
-- A1-L49: Pets
-- =========================================

DELETE FROM grammar_sentences WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'A1-L49');
DELETE FROM vocabulary_items WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'A1-L49');
DELETE FROM lesson_activities WHERE lesson_id = 'A1-L49';
DELETE FROM lessons WHERE id = 'A1-L49';

INSERT INTO lessons (id, level, lesson_number, topic) VALUES
('A1-L49', 'A1', 49, 'Pets')
ON CONFLICT (id) DO UPDATE SET topic = EXCLUDED.topic;

DO $$
DECLARE
    lesson_id_var TEXT := 'A1-L49';
    activity_id_var UUID;
BEGIN
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'warm_up_speaking', 1, 'Do you have pets?', 'Talk about pets', '{"prompt": "Do you have a dog?"}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_intro', 2, 'Pet Words', 'Learn pet words', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'cat', 'แมว', NULL),
    (activity_id_var, 'dog', 'สุนัข', NULL),
    (activity_id_var, 'fish', 'ปลา', NULL),
    (activity_id_var, 'bird', 'นก', NULL),
    (activity_id_var, 'hamster', 'แฮมสเตอร์', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_matching_drag', 3, 'Match Pet Words', 'Match pet words', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'cat', 'แมว', NULL),
    (activity_id_var, 'dog', 'สุนัข', NULL),
    (activity_id_var, 'fish', 'ปลา', NULL),
    (activity_id_var, 'bird', 'นก', NULL),
    (activity_id_var, 'hamster', 'แฮมสเตอร์', NULL);

    -- 4. Vocabulary Fill Blanks #1
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 4, 'Complete the Sentences 1', 'Fill in the blanks with correct words', '{"text": "I have a ___. She has a ___. We have a ___.", "blanks": [{"id": "blank1", "text": "cat", "options": ["cat", "dog", "fish", "bird"], "correctAnswer": "cat"}, {"id": "blank2", "text": "dog", "options": ["dog", "cat", "fish", "hamster"], "correctAnswer": "dog"}, {"id": "blank3", "text": "fish", "options": ["fish", "cat", "dog", "bird"], "correctAnswer": "fish"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    -- 5. Vocabulary Fill Blanks #2
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 5, 'Complete the Sentences 2', 'Fill in the blanks with correct words', '{"text": "They have a ___. I have a ___. She has a ___.", "blanks": [{"id": "blank1", "text": "bird", "options": ["bird", "cat", "dog", "fish"], "correctAnswer": "bird"}, {"id": "blank2", "text": "hamster", "options": ["hamster", "cat", "dog", "bird"], "correctAnswer": "hamster"}, {"id": "blank3", "text": "cat", "options": ["cat", "dog", "fish", "bird"], "correctAnswer": "cat"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    -- 6. Grammar Explanation
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_explanation', 6, 'Have Got / Has Got', 'Learn have/has got for possession', '{"rules": "Use have got/has got to talk about what you own:\n\n- I/You/We/They have got (I have got a cat)\n- He/She/It has got (She has got a dog)\n- Have got = have (informal)\n- Use a/an with singular pets", "examples": ["I have got a cat.", "She has got a dog.", "They have got fish.", "We have got a bird.", "He has got a hamster."]}'::jsonb)
    RETURNING id INTO activity_id_var;

    -- 7. Grammar Sentences #1
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 7, 'Build Sentences 1', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'I have got a cat', 'I have got a cat.', '["I", "have", "got", "a", "cat."]'::jsonb),
    (activity_id_var, 'She has got a dog', 'She has got a dog.', '["She", "has", "got", "a", "dog."]'::jsonb);

    -- 8. Grammar Sentences #2
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 8, 'Build Sentences 2', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'They have got fish', 'They have got fish.', '["They", "have", "got", "fish."]'::jsonb),
    (activity_id_var, 'We have got a bird', 'We have got a bird.', '["We", "have", "got", "a", "bird."]'::jsonb);

    -- 9. Speaking Practice
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'speaking_practice', 9, 'Talk About Pets', 'Practice talking about pets', '{"prompts": ["Do you have a pet?", "What animals do you like?", "Do you want a dog or cat?", "What is your favorite pet?", "Do you like cats or dogs?"]}'::jsonb)
    RETURNING id INTO activity_id_var;

    -- 10. Speaking Improvement
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'speaking_improvement', 10, 'Speaking Improvement', 'Read the improved version of your speech', '{"type": "speaking_improvement", "similarityThreshold": 70}'::jsonb)
    RETURNING id INTO activity_id_var;
END $$;


-- ===== LESSON A1-L50 =====

-- =========================================
-- Pre-fill Database with Sample Lesson Data
-- A1-L50: Money (coins and notes)
-- =========================================

DELETE FROM grammar_sentences WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'A1-L50');
DELETE FROM vocabulary_items WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'A1-L50');
DELETE FROM lesson_activities WHERE lesson_id = 'A1-L50';
DELETE FROM lessons WHERE id = 'A1-L50';

INSERT INTO lessons (id, level, lesson_number, topic) VALUES
('A1-L50', 'A1', 50, 'Money (coins and notes)')
ON CONFLICT (id) DO UPDATE SET topic = EXCLUDED.topic;

DO $$
DECLARE
    lesson_id_var TEXT := 'A1-L50';
    activity_id_var UUID;
BEGIN
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'warm_up_speaking', 1, 'How much?', 'Talk about money and prices', '{"prompt": "How much is this?"}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_intro', 2, 'Money Words', 'Learn money words', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'coin', 'เหรียญ', NULL),
    (activity_id_var, 'note', 'ธนบัตร', NULL),
    (activity_id_var, 'dollar', 'ดอลลาร์', NULL),
    (activity_id_var, 'baht', 'บาท', NULL),
    (activity_id_var, 'pay', 'จ่าย', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_matching_drag', 3, 'Match Money Words', 'Match money words', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'coin', 'เหรียญ', NULL),
    (activity_id_var, 'note', 'ธนบัตร', NULL),
    (activity_id_var, 'dollar', 'ดอลลาร์', NULL),
    (activity_id_var, 'baht', 'บาท', NULL),
    (activity_id_var, 'pay', 'จ่าย', NULL);

    -- 4. Vocabulary Fill Blanks #1
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 4, 'Complete the Sentences 1', 'Fill in the blanks with correct words', '{"text": "I have a ___. I have a ___. I ___ with money.", "blanks": [{"id": "blank1", "text": "coin", "options": ["coin", "note", "dollar", "baht"], "correctAnswer": "coin"}, {"id": "blank2", "text": "note", "options": ["note", "coin", "dollar", "baht"], "correctAnswer": "note"}, {"id": "blank3", "text": "pay", "options": ["pay", "coin", "note", "dollar"], "correctAnswer": "pay"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    -- 5. Vocabulary Fill Blanks #2
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 5, 'Complete the Sentences 2', 'Fill in the blanks with correct words', '{"text": "This costs 10 ___. I have 5 ___. She pays with ___.", "blanks": [{"id": "blank1", "text": "baht", "options": ["baht", "dollar", "coin", "note"], "correctAnswer": "baht"}, {"id": "blank2", "text": "coins", "options": ["coins", "notes", "dollars", "baht"], "correctAnswer": "coins"}, {"id": "blank3", "text": "notes", "options": ["notes", "coins", "dollars", "baht"], "correctAnswer": "notes"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    -- 6. Grammar Explanation
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_explanation', 6, 'Numbers + Prices', 'Learn numbers with prices', '{"rules": "Use numbers with money words:\n\n- This costs + number + money (This costs 10 baht)\n- I have + number + coins/notes (I have 5 coins)\n- Pay with + money (She pays with notes)\n- Use plural for coins/notes when counting", "examples": ["This costs 10 baht.", "I have 5 coins.", "She pays with notes.", "It costs 20 dollars.", "We have 3 notes."]}'::jsonb)
    RETURNING id INTO activity_id_var;

    -- 7. Grammar Sentences #1
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 7, 'Build Sentences 1', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'This costs 10 baht', 'This costs 10 baht.', '["This", "costs", "10", "baht."]'::jsonb),
    (activity_id_var, 'I have 5 coins', 'I have 5 coins.', '["I", "have", "5", "coins."]'::jsonb);

    -- 8. Grammar Sentences #2
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 8, 'Build Sentences 2', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'She pays with notes', 'She pays with notes.', '["She", "pays", "with", "notes."]'::jsonb),
    (activity_id_var, 'It costs 20 dollars', 'It costs 20 dollars.', '["It", "costs", "20", "dollars."]'::jsonb);

    -- 9. Speaking Practice
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'speaking_practice', 9, 'Talk About Money', 'Practice talking about money', '{"prompts": ["How much is your lunch?", "Do you save money?", "What do you buy with coins?", "How much money do you have?", "Do you use coins or notes?"]}'::jsonb)
    RETURNING id INTO activity_id_var;

    -- 10. Speaking Improvement
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'speaking_improvement', 10, 'Speaking Improvement', 'Read the improved version of your speech', '{"type": "speaking_improvement", "similarityThreshold": 70}'::jsonb)
    RETURNING id INTO activity_id_var;
END $$;


-- ===== B1 MISSING LESSONS 61-70 =====

-- ===== LESSON B1-L61 =====

-- =========================================
-- Pre-fill Database with Sample Lesson Data
-- B1-L61: Social Responsibilities
-- =========================================

DELETE FROM grammar_sentences WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'B1-L61');
DELETE FROM vocabulary_items WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'B1-L61');
DELETE FROM lesson_activities WHERE lesson_id = 'B1-L61';
DELETE FROM lessons WHERE id = 'B1-L61';

INSERT INTO lessons (id, level, lesson_number, topic) VALUES
('B1-L61', 'B1', 61, 'Social Responsibilities')
ON CONFLICT (id) DO UPDATE SET topic = EXCLUDED.topic;

DO $$
DECLARE
    lesson_id_var TEXT := 'B1-L61';
    activity_id_var UUID;
BEGIN
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'warm_up_speaking', 1, 'Community Involvement', 'Talk about helping others in your community', '{"prompt": "Who inspires you to help others?"}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_intro', 2, 'Community Action Words', 'Learn words related to community service', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'volunteer', 'อาสาสมัคร', NULL),
    (activity_id_var, 'donate', 'บริจาค', NULL),
    (activity_id_var, 'organize', 'จัดระเบียบ', NULL),
    (activity_id_var, 'advocate', 'สนับสนุน', NULL),
    (activity_id_var, 'participate', 'เข้าร่วม', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_matching_drag', 3, 'Match Community Words', 'Match community action words', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'volunteer', 'อาสาสมัคร', NULL),
    (activity_id_var, 'donate', 'บริจาค', NULL),
    (activity_id_var, 'organize', 'จัดระเบียบ', NULL),
    (activity_id_var, 'advocate', 'สนับสนุน', NULL),
    (activity_id_var, 'participate', 'เข้าร่วม', NULL);

    -- 4. Vocabulary Fill Blanks #1
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 4, 'Complete the Sentences 1', 'Fill in the blanks with correct words', '{"text": "I ___ at the community center. We ___ money to help others. They ___ events for the neighborhood.", "blanks": [{"id": "blank1", "text": "volunteer", "options": ["volunteer", "donate", "organize", "advocate"], "correctAnswer": "volunteer"}, {"id": "blank2", "text": "donate", "options": ["donate", "volunteer", "organize", "participate"], "correctAnswer": "donate"}, {"id": "blank3", "text": "organize", "options": ["organize", "volunteer", "donate", "advocate"], "correctAnswer": "organize"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    -- 5. Vocabulary Fill Blanks #2
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 5, 'Complete the Sentences 2', 'Fill in the blanks with correct words', '{"text": "She ___ for better schools. We ___ in community activities. They ___ for change.", "blanks": [{"id": "blank1", "text": "advocates", "options": ["advocates", "volunteers", "donates", "organizes"], "correctAnswer": "advocates"}, {"id": "blank2", "text": "participate", "options": ["participate", "volunteer", "donate", "organize"], "correctAnswer": "participate"}, {"id": "blank3", "text": "advocate", "options": ["advocate", "volunteer", "donate", "organize"], "correctAnswer": "advocate"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    -- 6. Grammar Explanation
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_explanation', 6, 'Defining Relative Clauses', 'Learn who/which/that in relative clauses', '{"rules": "Use relative clauses to give more information about nouns:\n\n- Who for people (a person who helps)\n- Which for things (a group which helps)\n- That for people or things (a place that needs help)\n- Relative clauses come after the noun they describe", "examples": ["This is a person who helps others.", "I support a group which helps children.", "She volunteers at a place that needs help.", "People who volunteer make a difference.", "Organizations which help others are important."]}'::jsonb)
    RETURNING id INTO activity_id_var;

    -- 7. Grammar Sentences #1
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 7, 'Build Sentences 1', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'This is a person who helps others', 'This is a person who helps others.', '["This", "is", "a", "person", "who", "helps", "others."]'::jsonb),
    (activity_id_var, 'I support a group which helps children', 'I support a group which helps children.', '["I", "support", "a", "group", "which", "helps", "children."]'::jsonb);

    -- 8. Grammar Sentences #2
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 8, 'Build Sentences 2', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'She volunteers at a place that needs help', 'She volunteers at a place that needs help.', '["She", "volunteers", "at", "a", "place", "that", "needs", "help."]'::jsonb),
    (activity_id_var, 'People who volunteer make a difference', 'People who volunteer make a difference.', '["People", "who", "volunteer", "make", "a", "difference."]'::jsonb);

    -- 9. Speaking Practice
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'speaking_practice', 9, 'Talk About Helping Others', 'Practice talking about helping people', '{"prompts": ["Do you help people in your neighborhood?", "What do you do to help your family?", "Who is your favorite person to help?", "Do you volunteer anywhere?", "What causes do you support?"]}'::jsonb)
    RETURNING id INTO activity_id_var;

    -- 10. Speaking Improvement
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'speaking_improvement', 10, 'Speaking Improvement', 'Read the improved version of your speech', '{"type": "speaking_improvement", "similarityThreshold": 70}'::jsonb)
    RETURNING id INTO activity_id_var;
END $$;


-- ===== LESSON B1-L62 =====

-- =========================================
-- Pre-fill Database with Sample Lesson Data
-- B1-L62: Protecting Nature
-- =========================================

DELETE FROM grammar_sentences WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'B1-L62');
DELETE FROM vocabulary_items WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'B1-L62');
DELETE FROM lesson_activities WHERE lesson_id = 'B1-L62';
DELETE FROM lessons WHERE id = 'B1-L62';

INSERT INTO lessons (id, level, lesson_number, topic) VALUES
('B1-L62', 'B1', 62, 'Protecting Nature')
ON CONFLICT (id) DO UPDATE SET topic = EXCLUDED.topic;

DO $$
DECLARE
    lesson_id_var TEXT := 'B1-L62';
    activity_id_var UUID;
BEGIN
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'warm_up_speaking', 1, 'Environmental Issues', 'Talk about nature protection in your area', '{"prompt": "What places near you are being protected?"}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_intro', 2, 'Conservation Words', 'Learn words related to environmental protection', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'conserved', 'อนุรักษ์', NULL),
    (activity_id_var, 'protected', 'ปกป้อง', NULL),
    (activity_id_var, 'restored', 'ฟื้นฟู', NULL),
    (activity_id_var, 'cleaned', 'ทำความสะอาด', NULL),
    (activity_id_var, 'planted', 'ปลูก', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_matching_drag', 3, 'Match Conservation Words', 'Match environmental protection words', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'conserved', 'อนุรักษ์', NULL),
    (activity_id_var, 'protected', 'ปกป้อง', NULL),
    (activity_id_var, 'restored', 'ฟื้นฟู', NULL),
    (activity_id_var, 'cleaned', 'ทำความสะอาด', NULL),
    (activity_id_var, 'planted', 'ปลูก', NULL);

    -- 4. Vocabulary Fill Blanks #1
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 4, 'Complete the Sentences 1', 'Fill in the blanks with correct words', '{"text": "Forests are ___ by volunteers. The river is ___ by law. Parks are ___ every year.", "blanks": [{"id": "blank1", "text": "conserved", "options": ["conserved", "protected", "restored", "cleaned"], "correctAnswer": "conserved"}, {"id": "blank2", "text": "protected", "options": ["protected", "conserved", "restored", "planted"], "correctAnswer": "protected"}, {"id": "blank3", "text": "cleaned", "options": ["cleaned", "conserved", "protected", "planted"], "correctAnswer": "cleaned"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    -- 5. Vocabulary Fill Blanks #2
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 5, 'Complete the Sentences 2', 'Fill in the blanks with correct words', '{"text": "The area was ___ last year. Trees are ___ every spring. Nature is being ___.", "blanks": [{"id": "blank1", "text": "restored", "options": ["restored", "conserved", "protected", "cleaned"], "correctAnswer": "restored"}, {"id": "blank2", "text": "planted", "options": ["planted", "conserved", "protected", "restored"], "correctAnswer": "planted"}, {"id": "blank3", "text": "protected", "options": ["protected", "conserved", "restored", "planted"], "correctAnswer": "protected"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    -- 6. Grammar Explanation
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_explanation', 6, 'Present Passive Voice', 'Learn present passive constructions', '{"rules": "Use passive voice when the action is more important than who does it:\n\n- Form: be + past participle (are conserved, is protected)\n- Use by to show who does the action (by volunteers, by law)\n- Use is for singular, are for plural\n- Focus on what happens, not who does it", "examples": ["Forests are conserved by volunteers.", "The river is protected by law.", "Trees are planted every year.", "Parks are cleaned regularly.", "Nature is being restored."]}'::jsonb)
    RETURNING id INTO activity_id_var;

    -- 7. Grammar Sentences #1
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 7, 'Build Sentences 1', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'Forests are conserved by volunteers', 'Forests are conserved by volunteers.', '["Forests", "are", "conserved", "by", "volunteers."]'::jsonb),
    (activity_id_var, 'The river is protected by law', 'The river is protected by law.', '["The", "river", "is", "protected", "by", "law."]'::jsonb);

    -- 8. Grammar Sentences #2
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 8, 'Build Sentences 2', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'Trees are planted every year', 'Trees are planted every year.', '["Trees", "are", "planted", "every", "year."]'::jsonb),
    (activity_id_var, 'Parks are cleaned regularly', 'Parks are cleaned regularly.', '["Parks", "are", "cleaned", "regularly."]'::jsonb);

    -- 9. Speaking Practice
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'speaking_practice', 9, 'Talk About Nature', 'Practice talking about the environment', '{"prompts": ["Do you like going to the park?", "What animals live near your home?", "Do you recycle at home?", "What can we do to protect nature?", "Are there protected areas near you?"]}'::jsonb)
    RETURNING id INTO activity_id_var;

    -- 10. Speaking Improvement
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'speaking_improvement', 10, 'Speaking Improvement', 'Read the improved version of your speech', '{"type": "speaking_improvement", "similarityThreshold": 70}'::jsonb)
    RETURNING id INTO activity_id_var;
END $$;


-- ===== LESSON B1-L63 =====

-- =========================================
-- Pre-fill Database with Sample Lesson Data
-- B1-L63: Learning New Skills
-- =========================================

DELETE FROM grammar_sentences WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'B1-L63');
DELETE FROM vocabulary_items WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'B1-L63');
DELETE FROM lesson_activities WHERE lesson_id = 'B1-L63';
DELETE FROM lessons WHERE id = 'B1-L63';

INSERT INTO lessons (id, level, lesson_number, topic) VALUES
('B1-L63', 'B1', 63, 'Learning New Skills')
ON CONFLICT (id) DO UPDATE SET topic = EXCLUDED.topic;

DO $$
DECLARE
    lesson_id_var TEXT := 'B1-L63';
    activity_id_var UUID;
BEGIN
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'warm_up_speaking', 1, 'Skill Development', 'Talk about learning new abilities', '{"prompt": "What skill are you trying to master right now?"}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_intro', 2, 'Learning Process Words', 'Learn words related to skill acquisition', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'practice', 'ฝึกฝน', NULL),
    (activity_id_var, 'attempt', 'พยายาม', NULL),
    (activity_id_var, 'master', 'เชี่ยวชาญ', NULL),
    (activity_id_var, 'struggle', 'ต่อสู้', NULL),
    (activity_id_var, 'repeat', 'ทำซ้ำ', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_matching_drag', 3, 'Match Learning Words', 'Match skill development words', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'practice', 'ฝึกฝน', NULL),
    (activity_id_var, 'attempt', 'พยายาม', NULL),
    (activity_id_var, 'master', 'เชี่ยวชาญ', NULL),
    (activity_id_var, 'struggle', 'ต่อสู้', NULL),
    (activity_id_var, 'repeat', 'ทำซ้ำ', NULL);

    -- 4. Vocabulary Fill Blanks #1
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 4, 'Complete the Sentences 1', 'Fill in the blanks with correct words', '{"text": "I ___ new skills every day. She ___ to learn the guitar. We ___ difficult tasks.", "blanks": [{"id": "blank1", "text": "practice", "options": ["practice", "attempt", "master", "struggle"], "correctAnswer": "practice"}, {"id": "blank2", "text": "attempts", "options": ["attempts", "practices", "masters", "struggles"], "correctAnswer": "attempts"}, {"id": "blank3", "text": "struggle", "options": ["struggle", "practice", "attempt", "master"], "correctAnswer": "struggle"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    -- 5. Vocabulary Fill Blanks #2
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 5, 'Complete the Sentences 2', 'Fill in the blanks with correct words', '{"text": "They want to ___ the skill. I ___ the exercise many times. She tries to ___ new techniques.", "blanks": [{"id": "blank1", "text": "master", "options": ["master", "practice", "attempt", "struggle"], "correctAnswer": "master"}, {"id": "blank2", "text": "repeat", "options": ["repeat", "practice", "attempt", "master"], "correctAnswer": "repeat"}, {"id": "blank3", "text": "master", "options": ["master", "practice", "attempt", "repeat"], "correctAnswer": "master"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    -- 6. Grammar Explanation
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_explanation', 6, 'Gerunds and Infinitives', 'Learn verb forms after other verbs', '{"rules": "Some verbs are followed by gerunds (-ing), others by infinitives (to + verb):\n\n- Gerunds after: enjoy, avoid, finish (I enjoy practicing)\n- Infinitives after: hope, want, decide (She hopes to master)\n- Some verbs can use both with different meanings\n- Practice with common verb patterns", "examples": ["I enjoy practicing new skills.", "She hopes to master the guitar.", "They avoid struggling with difficult tasks.", "We want to learn quickly.", "He finishes practicing at 5pm."]}'::jsonb)
    RETURNING id INTO activity_id_var;

    -- 7. Grammar Sentences #1
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 7, 'Build Sentences 1', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'I enjoy practicing new skills', 'I enjoy practicing new skills.', '["I", "enjoy", "practicing", "new", "skills."]'::jsonb),
    (activity_id_var, 'She hopes to master the guitar', 'She hopes to master the guitar.', '["She", "hopes", "to", "master", "the", "guitar."]'::jsonb);

    -- 8. Grammar Sentences #2
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 8, 'Build Sentences 2', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'They avoid struggling with difficult tasks', 'They avoid struggling with difficult tasks.', '["They", "avoid", "struggling", "with", "difficult", "tasks."]'::jsonb),
    (activity_id_var, 'We want to learn quickly', 'We want to learn quickly.', '["We", "want", "to", "learn", "quickly."]'::jsonb);

    -- 9. Speaking Practice
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'speaking_practice', 9, 'Talk About Learning', 'Practice talking about school and studying', '{"prompts": ["What subject do you like best?", "Who helps you with homework?", "What do you do when you don''t understand?", "What skill are you trying to learn?", "How do you practice new skills?"]}'::jsonb)
    RETURNING id INTO activity_id_var;

    -- 10. Speaking Improvement
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'speaking_improvement', 10, 'Speaking Improvement', 'Read the improved version of your speech', '{"type": "speaking_improvement", "similarityThreshold": 70}'::jsonb)
    RETURNING id INTO activity_id_var;
END $$;


-- ===== LESSON B1-L64 =====

-- =========================================
-- Pre-fill Database with Sample Lesson Data
-- B1-L64: Technology Predictions
-- =========================================

DELETE FROM grammar_sentences WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'B1-L64');
DELETE FROM vocabulary_items WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'B1-L64');
DELETE FROM lesson_activities WHERE lesson_id = 'B1-L64';
DELETE FROM lessons WHERE id = 'B1-L64';

INSERT INTO lessons (id, level, lesson_number, topic) VALUES
('B1-L64', 'B1', 64, 'Technology Predictions')
ON CONFLICT (id) DO UPDATE SET topic = EXCLUDED.topic;

DO $$
DECLARE
    lesson_id_var TEXT := 'B1-L64';
    activity_id_var UUID;
BEGIN
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'warm_up_speaking', 1, 'Future Technology', 'Talk about how technology will change life', '{"prompt": "What tech do you think will change your daily life?"}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_intro', 2, 'Tech Future Words', 'Learn words related to technology predictions', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'predict', 'ทำนาย', NULL),
    (activity_id_var, 'expect', 'คาดหวัง', NULL),
    (activity_id_var, 'advance', 'ก้าวหน้า', NULL),
    (activity_id_var, 'replace', 'แทนที่', NULL),
    (activity_id_var, 'automate', 'ทำให้เป็นอัตโนมัติ', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_matching_drag', 3, 'Match Tech Words', 'Match technology prediction words', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'predict', 'ทำนาย', NULL),
    (activity_id_var, 'expect', 'คาดหวัง', NULL),
    (activity_id_var, 'advance', 'ก้าวหน้า', NULL),
    (activity_id_var, 'replace', 'แทนที่', NULL),
    (activity_id_var, 'automate', 'ทำให้เป็นอัตโนมัติ', NULL);

    -- 4. Vocabulary Fill Blanks #1
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 4, 'Complete the Sentences 1', 'Fill in the blanks with correct words', '{"text": "Experts ___ that AI will change work. We ___ technology to ___.", "blanks": [{"id": "blank1", "text": "predict", "options": ["predict", "expect", "advance", "replace"], "correctAnswer": "predict"}, {"id": "blank2", "text": "expect", "options": ["expect", "predict", "advance", "automate"], "correctAnswer": "expect"}, {"id": "blank3", "text": "advance", "options": ["advance", "predict", "expect", "replace"], "correctAnswer": "advance"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    -- 5. Vocabulary Fill Blanks #2
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 5, 'Complete the Sentences 2', 'Fill in the blanks with correct words', '{"text": "Robots will ___ some jobs. Machines will ___ many tasks. Technology will ___.", "blanks": [{"id": "blank1", "text": "replace", "options": ["replace", "predict", "expect", "advance"], "correctAnswer": "replace"}, {"id": "blank2", "text": "automate", "options": ["automate", "replace", "predict", "advance"], "correctAnswer": "automate"}, {"id": "blank3", "text": "advance", "options": ["advance", "replace", "automate", "predict"], "correctAnswer": "advance"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    -- 6. Grammar Explanation
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_explanation', 6, 'Will vs Going to for Predictions', 'Learn future forms for predictions', '{"rules": "Use will and going to for future predictions:\n\n- Will for general predictions (Technology will change)\n- Going to for plans/intentions (I am going to learn)\n- Will + base verb (will change, will replace)\n- Be + going to + base verb (am going to learn)\n- Both can be used for predictions", "examples": ["Technology will change everything.", "I am going to learn about AI.", "Robots will replace some jobs.", "We are going to see big changes.", "AI will automate many tasks."]}'::jsonb)
    RETURNING id INTO activity_id_var;

    -- 7. Grammar Sentences #1
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 7, 'Build Sentences 1', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'Technology will change everything', 'Technology will change everything.', '["Technology", "will", "change", "everything."]'::jsonb),
    (activity_id_var, 'I am going to learn about AI', 'I am going to learn about AI.', '["I", "am", "going", "to", "learn", "about", "AI."]'::jsonb);

    -- 8. Grammar Sentences #2
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 8, 'Build Sentences 2', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'Robots will replace some jobs', 'Robots will replace some jobs.', '["Robots", "will", "replace", "some", "jobs."]'::jsonb),
    (activity_id_var, 'We are going to see big changes', 'We are going to see big changes.', '["We", "are", "going", "to", "see", "big", "changes."]'::jsonb);

    -- 9. Speaking Practice
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'speaking_practice', 9, 'Talk About Technology', 'Practice talking about computers and phones', '{"prompts": ["What do you use your phone for?", "Do you play computer games?", "Who taught you to use the computer?", "How will technology change in the future?", "What technology do you want to learn about?"]}'::jsonb)
    RETURNING id INTO activity_id_var;

    -- 10. Speaking Improvement
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'speaking_improvement', 10, 'Speaking Improvement', 'Read the improved version of your speech', '{"type": "speaking_improvement", "similarityThreshold": 70}'::jsonb)
    RETURNING id INTO activity_id_var;
END $$;


-- ===== LESSON B1-L65 =====

-- =========================================
-- Pre-fill Database with Sample Lesson Data
-- B1-L65: Balancing Health and Work
-- =========================================

DELETE FROM grammar_sentences WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'B1-L65');
DELETE FROM vocabulary_items WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'B1-L65');
DELETE FROM lesson_activities WHERE lesson_id = 'B1-L65';
DELETE FROM lessons WHERE id = 'B1-L65';

INSERT INTO lessons (id, level, lesson_number, topic) VALUES
('B1-L65', 'B1', 65, 'Balancing Health and Work')
ON CONFLICT (id) DO UPDATE SET topic = EXCLUDED.topic;

DO $$
DECLARE
    lesson_id_var TEXT := 'B1-L65';
    activity_id_var UUID;
BEGIN
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'warm_up_speaking', 1, 'Work-Life Health Balance', 'Talk about staying healthy while working', '{"prompt": "What must you do to stay healthy at work?"}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_intro', 2, 'Health at Work Words', 'Learn words related to workplace health', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'prioritize', 'จัดลำดับความสำคัญ', NULL),
    (activity_id_var, 'rest', 'พักผ่อน', NULL),
    (activity_id_var, 'hydrate', 'ดื่มน้ำ', NULL),
    (activity_id_var, 'pause', 'หยุดชั่วคราว', NULL),
    (activity_id_var, 'stretch', 'ยืดกล้ามเนื้อ', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_matching_drag', 3, 'Match Health Words', 'Match workplace health words', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'prioritize', 'จัดลำดับความสำคัญ', NULL),
    (activity_id_var, 'rest', 'พักผ่อน', NULL),
    (activity_id_var, 'hydrate', 'ดื่มน้ำ', NULL),
    (activity_id_var, 'pause', 'หยุดชั่วคราว', NULL),
    (activity_id_var, 'stretch', 'ยืดกล้ามเนื้อ', NULL);

    -- 4. Vocabulary Fill Blanks #1
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 4, 'Complete the Sentences 1', 'Fill in the blanks with correct words', '{"text": "You should ___ when tired. Workers must ___. I need to ___.", "blanks": [{"id": "blank1", "text": "rest", "options": ["rest", "prioritize", "hydrate", "pause"], "correctAnswer": "rest"}, {"id": "blank2", "text": "pause", "options": ["pause", "rest", "hydrate", "stretch"], "correctAnswer": "pause"}, {"id": "blank3", "text": "hydrate", "options": ["hydrate", "rest", "pause", "stretch"], "correctAnswer": "hydrate"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    -- 5. Vocabulary Fill Blanks #2
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 5, 'Complete the Sentences 2', 'Fill in the blanks with correct words', '{"text": "We should ___ our health. I ___ every hour. They ___ to stay healthy.", "blanks": [{"id": "blank1", "text": "prioritize", "options": ["prioritize", "rest", "hydrate", "pause"], "correctAnswer": "prioritize"}, {"id": "blank2", "text": "stretch", "options": ["stretch", "rest", "hydrate", "pause"], "correctAnswer": "stretch"}, {"id": "blank3", "text": "rest", "options": ["rest", "prioritize", "hydrate", "stretch"], "correctAnswer": "rest"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    -- 6. Grammar Explanation
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_explanation', 6, 'Should and Must for Advice', 'Learn modal verbs for obligations and advice', '{"rules": "Use should and must to give advice and express obligations:\n\n- Should for advice/recommendations (You should rest)\n- Must for strong obligations/rules (Workers must take breaks)\n- Should + base verb (should rest, should drink)\n- Must + base verb (must take, must do)\n- Should is less strong than must", "examples": ["You should rest when you are tired.", "Workers must take breaks.", "I should drink more water.", "We must prioritize health.", "They should stretch regularly."]}'::jsonb)
    RETURNING id INTO activity_id_var;

    -- 7. Grammar Sentences #1
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 7, 'Build Sentences 1', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'You should rest when you are tired', 'You should rest when you are tired.', '["You", "should", "rest", "when", "you", "are", "tired."]'::jsonb),
    (activity_id_var, 'Workers must take breaks', 'Workers must take breaks.', '["Workers", "must", "take", "breaks."]'::jsonb);

    -- 8. Grammar Sentences #2
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 8, 'Build Sentences 2', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'I should drink more water', 'I should drink more water.', '["I", "should", "drink", "more", "water."]'::jsonb),
    (activity_id_var, 'We must prioritize health', 'We must prioritize health.', '["We", "must", "prioritize", "health."]'::jsonb);

    -- 9. Speaking Practice
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'speaking_practice', 9, 'Talk About Daily Routine', 'Practice talking about your daily schedule', '{"prompts": ["What time do you wake up?", "When do you eat dinner?", "Do you exercise every day?", "How do you stay healthy at work?", "What should people do to stay healthy?"]}'::jsonb)
    RETURNING id INTO activity_id_var;

    -- 10. Speaking Improvement
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'speaking_improvement', 10, 'Speaking Improvement', 'Read the improved version of your speech', '{"type": "speaking_improvement", "similarityThreshold": 70}'::jsonb)
    RETURNING id INTO activity_id_var;
END $$;


-- ===== LESSON B1-L66 =====

-- =========================================
-- Pre-fill Database with Sample Lesson Data
-- B1-L66: Travel Tips
-- =========================================

DELETE FROM grammar_sentences WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'B1-L66');
DELETE FROM vocabulary_items WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'B1-L66');
DELETE FROM lesson_activities WHERE lesson_id = 'B1-L66';
DELETE FROM lessons WHERE id = 'B1-L66';

INSERT INTO lessons (id, level, lesson_number, topic) VALUES
('B1-L66', 'B1', 66, 'Travel Tips')
ON CONFLICT (id) DO UPDATE SET topic = EXCLUDED.topic;

DO $$
DECLARE
    lesson_id_var TEXT := 'B1-L66';
    activity_id_var UUID;
BEGIN
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'warm_up_speaking', 1, 'Travel Experiences', 'Talk about learning from travel experiences', '{"prompt": "What were you doing when a travel tip saved you?"}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_intro', 2, 'Travel Advice Words', 'Learn words related to travel tips', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'pack', 'แพ็ค', NULL),
    (activity_id_var, 'navigate', 'นำทาง', NULL),
    (activity_id_var, 'bargain', 'ต่อราคา', NULL),
    (activity_id_var, 'warn', 'เตือน', NULL),
    (activity_id_var, 'avoid', 'หลีกเลี่ยง', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_matching_drag', 3, 'Match Travel Words', 'Match travel advice words', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'pack', 'แพ็ค', NULL),
    (activity_id_var, 'navigate', 'นำทาง', NULL),
    (activity_id_var, 'bargain', 'ต่อราคา', NULL),
    (activity_id_var, 'warn', 'เตือน', NULL),
    (activity_id_var, 'avoid', 'หลีกเลี่ยง', NULL);

    -- 4. Vocabulary Fill Blanks #1
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 4, 'Complete the Sentences 1', 'Fill in the blanks with correct words', '{"text": "I need to ___ my bags. She knows how to ___. We ___ for better prices.", "blanks": [{"id": "blank1", "text": "pack", "options": ["pack", "navigate", "bargain", "warn"], "correctAnswer": "pack"}, {"id": "blank2", "text": "navigate", "options": ["navigate", "pack", "bargain", "avoid"], "correctAnswer": "navigate"}, {"id": "blank3", "text": "bargain", "options": ["bargain", "pack", "navigate", "warn"], "correctAnswer": "bargain"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    -- 5. Vocabulary Fill Blanks #2
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 5, 'Complete the Sentences 2', 'Fill in the blanks with correct words', '{"text": "They ___ us about danger. I ___ crowded places. We ___ problems.", "blanks": [{"id": "blank1", "text": "warn", "options": ["warn", "pack", "navigate", "bargain"], "correctAnswer": "warn"}, {"id": "blank2", "text": "avoid", "options": ["avoid", "pack", "navigate", "warn"], "correctAnswer": "avoid"}, {"id": "blank3", "text": "avoid", "options": ["avoid", "warn", "pack", "navigate"], "correctAnswer": "avoid"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    -- 6. Grammar Explanation
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_explanation', 6, 'Past Continuous for Stories', 'Learn past continuous for background actions', '{"rules": "Use past continuous to describe background actions in stories:\n\n- Form: was/were + verb-ing (was packing, were bargaining)\n- Use when to show interruption (when I found, when GPS failed)\n- Past continuous = background action\n- Past simple = interrupting action\n- Use was for I/he/she/it, were for we/you/they", "examples": ["I was packing when I found my passport.", "She was navigating when the GPS failed.", "They were bargaining when the market closed.", "We were traveling when it started raining.", "He was exploring when he got lost."]}'::jsonb)
    RETURNING id INTO activity_id_var;

    -- 7. Grammar Sentences #1
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 7, 'Build Sentences 1', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'I was packing when I found my passport', 'I was packing when I found my passport.', '["I", "was", "packing", "when", "I", "found", "my", "passport."]'::jsonb),
    (activity_id_var, 'She was navigating when the GPS failed', 'She was navigating when the GPS failed.', '["She", "was", "navigating", "when", "the", "GPS", "failed."]'::jsonb);

    -- 8. Grammar Sentences #2
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 8, 'Build Sentences 2', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'They were bargaining when the market closed', 'They were bargaining when the market closed.', '["They", "were", "bargaining", "when", "the", "market", "closed."]'::jsonb),
    (activity_id_var, 'We were traveling when it started raining', 'We were traveling when it started raining.', '["We", "were", "traveling", "when", "it", "started", "raining."]'::jsonb);

    -- 9. Speaking Practice
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'speaking_practice', 9, 'Talk About Vacation', 'Practice talking about holidays and trips', '{"prompts": ["Where did you go last summer?", "Did you take pictures on your trip?", "What did you buy as a souvenir?", "What travel tips do you know?", "Have you ever gotten lost while traveling?"]}'::jsonb)
    RETURNING id INTO activity_id_var;

    -- 10. Speaking Improvement
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'speaking_improvement', 10, 'Speaking Improvement', 'Read the improved version of your speech', '{"type": "speaking_improvement", "similarityThreshold": 70}'::jsonb)
    RETURNING id INTO activity_id_var;
END $$;


-- ===== LESSON B1-L67 =====

-- =========================================
-- Pre-fill Database with Sample Lesson Data
-- B1-L67: Language Learning & Barriers
-- =========================================

DELETE FROM grammar_sentences WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'B1-L67');
DELETE FROM vocabulary_items WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'B1-L67');
DELETE FROM lesson_activities WHERE lesson_id = 'B1-L67';
DELETE FROM lessons WHERE id = 'B1-L67';

INSERT INTO lessons (id, level, lesson_number, topic) VALUES
('B1-L67', 'B1', 67, 'Language Learning & Barriers')
ON CONFLICT (id) DO UPDATE SET topic = EXCLUDED.topic;

DO $$
DECLARE
    lesson_id_var TEXT := 'B1-L67';
    activity_id_var UUID;
BEGIN
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'warm_up_speaking', 1, 'Language Challenges', 'Talk about overcoming language barriers', '{"prompt": "How do you repeat instructions for friends?"}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_intro', 2, 'Communication Words', 'Learn words related to language barriers', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'explain', 'อธิบาย', NULL),
    (activity_id_var, 'repeat', 'ทำซ้ำ', NULL),
    (activity_id_var, 'clarify', 'ชี้แจง', NULL),
    (activity_id_var, 'translate', 'แปล', NULL),
    (activity_id_var, 'interpret', 'ตีความ', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_matching_drag', 3, 'Match Communication Words', 'Match language barrier words', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'explain', 'อธิบาย', NULL),
    (activity_id_var, 'repeat', 'ทำซ้ำ', NULL),
    (activity_id_var, 'clarify', 'ชี้แจง', NULL),
    (activity_id_var, 'translate', 'แปล', NULL),
    (activity_id_var, 'interpret', 'ตีความ', NULL);

    -- 4. Vocabulary Fill Blanks #1
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 4, 'Complete the Sentences 1', 'Fill in the blanks with correct words', '{"text": "Can you ___ this for me? Please ___ what you said. I need to ___ the meaning.", "blanks": [{"id": "blank1", "text": "explain", "options": ["explain", "repeat", "clarify", "translate"], "correctAnswer": "explain"}, {"id": "blank2", "text": "repeat", "options": ["repeat", "explain", "clarify", "translate"], "correctAnswer": "repeat"}, {"id": "blank3", "text": "clarify", "options": ["clarify", "explain", "repeat", "translate"], "correctAnswer": "clarify"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    -- 5. Vocabulary Fill Blanks #2
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 5, 'Complete the Sentences 2', 'Fill in the blanks with correct words', '{"text": "I can ___ this text. She helps to ___ between languages. They ___ the message.", "blanks": [{"id": "blank1", "text": "translate", "options": ["translate", "explain", "repeat", "clarify"], "correctAnswer": "translate"}, {"id": "blank2", "text": "interpret", "options": ["interpret", "translate", "explain", "repeat"], "correctAnswer": "interpret"}, {"id": "blank3", "text": "interpret", "options": ["interpret", "translate", "explain", "clarify"], "correctAnswer": "interpret"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    -- 6. Grammar Explanation
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_explanation', 6, 'Reported Speech for Communication', 'Learn reporting what others said', '{"rules": "Use reported speech to tell what someone said:\n\n- Change pronouns (I → she, my → her)\n- Change tenses (need → needed, is → was)\n- Use that after said/told (She said that...)\n- Change word order in questions (Where is → where...was)\n- Use asked for questions, said/told for statements", "examples": ["She said that she needed help.", "He asked where the station was.", "They explained that I should turn left.", "I told him that I understood.", "She asked if I spoke English."]}'::jsonb)
    RETURNING id INTO activity_id_var;

    -- 7. Grammar Sentences #1
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 7, 'Build Sentences 1', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'She said that she needed help', 'She said that she needed help.', '["She", "said", "that", "she", "needed", "help."]'::jsonb),
    (activity_id_var, 'He asked where the station was', 'He asked where the station was.', '["He", "asked", "where", "the", "station", "was."]'::jsonb);

    -- 8. Grammar Sentences #2
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 8, 'Build Sentences 2', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'They explained that I should turn left', 'They explained that I should turn left.', '["They", "explained", "that", "I", "should", "turn", "left."]'::jsonb),
    (activity_id_var, 'I told him that I understood', 'I told him that I understood.', '["I", "told", "him", "that", "I", "understood."]'::jsonb);

    -- 9. Speaking Practice
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'speaking_practice', 9, 'Talk About Languages', 'Practice talking about speaking other languages', '{"prompts": ["Can you speak English?", "What language does your family speak?", "Do you learn Chinese at school?", "How do you practice speaking English?", "Have you ever needed a translator?"]}'::jsonb)
    RETURNING id INTO activity_id_var;

    -- 10. Speaking Improvement
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'speaking_improvement', 10, 'Speaking Improvement', 'Read the improved version of your speech', '{"type": "speaking_improvement", "similarityThreshold": 70}'::jsonb)
    RETURNING id INTO activity_id_var;
END $$;


-- ===== LESSON B1-L68 =====

-- =========================================
-- Pre-fill Database with Sample Lesson Data
-- B1-L68: Comparing Housing Options
-- =========================================

DELETE FROM grammar_sentences WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'B1-L68');
DELETE FROM vocabulary_items WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'B1-L68');
DELETE FROM lesson_activities WHERE lesson_id = 'B1-L68';
DELETE FROM lessons WHERE id = 'B1-L68';

INSERT INTO lessons (id, level, lesson_number, topic) VALUES
('B1-L68', 'B1', 68, 'Comparing Housing Options')
ON CONFLICT (id) DO UPDATE SET topic = EXCLUDED.topic;

DO $$
DECLARE
    lesson_id_var TEXT := 'B1-L68';
    activity_id_var UUID;
BEGIN
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'warm_up_speaking', 1, 'Housing Choices', 'Talk about different living situations', '{"prompt": "When is a place too noisy for you?"}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_intro', 2, 'Housing Quality Words', 'Learn words for describing living spaces', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'spacious', 'กว้างขวาง', NULL),
    (activity_id_var, 'noisy', 'เสียงดัง', NULL),
    (activity_id_var, 'affordable', 'ราคาไม่แพง', NULL),
    (activity_id_var, 'safe', 'ปลอดภัย', NULL),
    (activity_id_var, 'convenient', 'สะดวก', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_matching_drag', 3, 'Match Housing Words', 'Match housing quality words', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'spacious', 'กว้างขวาง', NULL),
    (activity_id_var, 'noisy', 'เสียงดัง', NULL),
    (activity_id_var, 'affordable', 'ราคาไม่แพง', NULL),
    (activity_id_var, 'safe', 'ปลอดภัย', NULL),
    (activity_id_var, 'convenient', 'สะดวก', NULL);

    -- 4. Vocabulary Fill Blanks #1
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 4, 'Complete the Sentences 1', 'Fill in the blanks with correct words', '{"text": "This apartment is very ___. The area is ___. The price is ___.", "blanks": [{"id": "blank1", "text": "spacious", "options": ["spacious", "noisy", "affordable", "safe"], "correctAnswer": "spacious"}, {"id": "blank2", "text": "safe", "options": ["safe", "noisy", "affordable", "convenient"], "correctAnswer": "safe"}, {"id": "blank3", "text": "affordable", "options": ["affordable", "spacious", "noisy", "safe"], "correctAnswer": "affordable"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    -- 5. Vocabulary Fill Blanks #2
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 5, 'Complete the Sentences 2', 'Fill in the blanks with correct words', '{"text": "The place is too ___. This location is ___. That area is not ___.", "blanks": [{"id": "blank1", "text": "noisy", "options": ["noisy", "spacious", "affordable", "safe"], "correctAnswer": "noisy"}, {"id": "blank2", "text": "convenient", "options": ["convenient", "spacious", "noisy", "safe"], "correctAnswer": "convenient"}, {"id": "blank3", "text": "safe", "options": ["safe", "convenient", "noisy", "affordable"], "correctAnswer": "safe"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    -- 6. Grammar Explanation
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_explanation', 6, 'Too and Enough Comparisons', 'Learn too/enough for comparisons', '{"rules": "Use too and enough to compare and express limits:\n\n- Too = more than needed/desired (too small, too expensive)\n- Enough = sufficient/adequate (big enough, cheap enough)\n- Too + adjective (too small, too noisy)\n- Adjective + enough (big enough, safe enough)\n- Use for to specify purpose (for us, for a family)", "examples": ["This apartment is too small for us.", "That house is big enough for a family.", "The rent is too expensive here.", "This place is safe enough for children.", "It is too noisy to sleep."]}'::jsonb)
    RETURNING id INTO activity_id_var;

    -- 7. Grammar Sentences #1
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 7, 'Build Sentences 1', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'This apartment is too small for us', 'This apartment is too small for us.', '["This", "apartment", "is", "too", "small", "for", "us."]'::jsonb),
    (activity_id_var, 'That house is big enough for a family', 'That house is big enough for a family.', '["That", "house", "is", "big", "enough", "for", "a", "family."]'::jsonb);

    -- 8. Grammar Sentences #2
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 8, 'Build Sentences 2', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'The rent is too expensive here', 'The rent is too expensive here.', '["The", "rent", "is", "too", "expensive", "here."]'::jsonb),
    (activity_id_var, 'This place is safe enough for children', 'This place is safe enough for children.', '["This", "place", "is", "safe", "enough", "for", "children."]'::jsonb);

    -- 9. Speaking Practice
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'speaking_practice', 9, 'Talk About Your Home', 'Practice talking about where you live', '{"prompts": ["How many rooms are in your house?", "Do you have a garden?", "What is your favorite room?", "Is your home too small or big enough?", "What makes a good place to live?"]}'::jsonb)
    RETURNING id INTO activity_id_var;

    -- 10. Speaking Improvement
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'speaking_improvement', 10, 'Speaking Improvement', 'Read the improved version of your speech', '{"type": "speaking_improvement", "similarityThreshold": 70}'::jsonb)
    RETURNING id INTO activity_id_var;
END $$;


-- ===== LESSON B1-L69 =====

-- =========================================
-- Pre-fill Database with Sample Lesson Data
-- B1-L69: Healthy Habits
-- =========================================

DELETE FROM grammar_sentences WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'B1-L69');
DELETE FROM vocabulary_items WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'B1-L69');
DELETE FROM lesson_activities WHERE lesson_id = 'B1-L69';
DELETE FROM lessons WHERE id = 'B1-L69';

INSERT INTO lessons (id, level, lesson_number, topic) VALUES
('B1-L69', 'B1', 69, 'Healthy Habits')
ON CONFLICT (id) DO UPDATE SET topic = EXCLUDED.topic;

DO $$
DECLARE
    lesson_id_var TEXT := 'B1-L69';
    activity_id_var UUID;
BEGIN
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'warm_up_speaking', 1, 'Healthy Habits', 'Talk about staying healthy', '{"prompt": "Do you eat breakfast every day?"}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_intro', 2, 'Health Routine Words', 'Learn words for healthy daily habits', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'routine', 'กิจวัตรประจำวัน', NULL),
    (activity_id_var, 'hydrate', 'ดื่มน้ำ', NULL),
    (activity_id_var, 'stretch', 'ยืดกล้ามเนื้อ', NULL),
    (activity_id_var, 'consistent', 'สม่ำเสมอ', NULL),
    (activity_id_var, 'crash', 'ทรุดลง', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_matching_drag', 3, 'Match Health Words', 'Match healthy habit words', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'routine', 'กิจวัตรประจำวัน', NULL),
    (activity_id_var, 'hydrate', 'ดื่มน้ำ', NULL),
    (activity_id_var, 'stretch', 'ยืดกล้ามเนื้อ', NULL),
    (activity_id_var, 'consistent', 'สม่ำเสมอ', NULL),
    (activity_id_var, 'crash', 'ทรุดลง', NULL);

    -- 4. Vocabulary Fill Blanks #1
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 4, 'Complete the Sentences 1', 'Fill in the blanks with correct words', '{"text": "I have a daily ___. I need to ___ every day. I ___ in the morning.", "blanks": [{"id": "blank1", "text": "routine", "options": ["routine", "hydrate", "stretch", "consistent"], "correctAnswer": "routine"}, {"id": "blank2", "text": "hydrate", "options": ["hydrate", "routine", "stretch", "consistent"], "correctAnswer": "hydrate"}, {"id": "blank3", "text": "stretch", "options": ["stretch", "routine", "hydrate", "consistent"], "correctAnswer": "stretch"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    -- 5. Vocabulary Fill Blanks #2
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 5, 'Complete the Sentences 2', 'Fill in the blanks with correct words', '{"text": "I am ___ with my exercise. If I don''t sleep, I ___. We need to be ___.", "blanks": [{"id": "blank1", "text": "consistent", "options": ["consistent", "routine", "hydrate", "stretch"], "correctAnswer": "consistent"}, {"id": "blank2", "text": "crash", "options": ["crash", "routine", "hydrate", "consistent"], "correctAnswer": "crash"}, {"id": "blank3", "text": "consistent", "options": ["consistent", "routine", "crash", "stretch"], "correctAnswer": "consistent"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    -- 6. Grammar Explanation
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_explanation', 6, 'Zero Conditional for Facts', 'Learn if/when for general truths', '{"rules": "Use zero conditional for general truths and facts:\n\n- Form: If/When + present simple, present simple\n- If you exercise, you feel better\n- When you sleep well, you have energy\n- Use if or when (both mean the same)\n- Both clauses use present simple\n- Expresses general truths, not specific situations", "examples": ["If you exercise regularly, you feel better.", "When you sleep well, you have more energy.", "If you eat healthy food, you stay strong.", "When you hydrate, you feel good.", "If you are consistent, you see results."]}'::jsonb)
    RETURNING id INTO activity_id_var;

    -- 7. Grammar Sentences #1
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 7, 'Build Sentences 1', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'If you exercise regularly you feel better', 'If you exercise regularly, you feel better.', '["If", "you", "exercise", "regularly,", "you", "feel", "better."]'::jsonb),
    (activity_id_var, 'When you sleep well you have more energy', 'When you sleep well, you have more energy.', '["When", "you", "sleep", "well,", "you", "have", "more", "energy."]'::jsonb);

    -- 8. Grammar Sentences #2
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 8, 'Build Sentences 2', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'If you eat healthy food you stay strong', 'If you eat healthy food, you stay strong.', '["If", "you", "eat", "healthy", "food,", "you", "stay", "strong."]'::jsonb),
    (activity_id_var, 'When you hydrate you feel good', 'When you hydrate, you feel good.', '["When", "you", "hydrate,", "you", "feel", "good."]'::jsonb);

    -- 9. Speaking Practice
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'speaking_practice', 9, 'Talk About Health', 'Practice talking about healthy living', '{"prompts": ["What healthy food do you eat?", "How many hours do you sleep?", "What exercise do you do?", "What is your daily routine?", "How do you stay healthy?"]}'::jsonb)
    RETURNING id INTO activity_id_var;

    -- 10. Speaking Improvement
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'speaking_improvement', 10, 'Speaking Improvement', 'Read the improved version of your speech', '{"type": "speaking_improvement", "similarityThreshold": 70}'::jsonb)
    RETURNING id INTO activity_id_var;
END $$;


-- ===== LESSON B1-L70 =====

-- =========================================
-- Pre-fill Database with Sample Lesson Data
-- B1-L70: Career Changes
-- =========================================

DELETE FROM grammar_sentences WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'B1-L70');
DELETE FROM vocabulary_items WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'B1-L70');
DELETE FROM lesson_activities WHERE lesson_id = 'B1-L70';
DELETE FROM lessons WHERE id = 'B1-L70';

INSERT INTO lessons (id, level, lesson_number, topic) VALUES
('B1-L70', 'B1', 70, 'Career Changes')
ON CONFLICT (id) DO UPDATE SET topic = EXCLUDED.topic;

DO $$
DECLARE
    lesson_id_var TEXT := 'B1-L70';
    activity_id_var UUID;
BEGIN
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'warm_up_speaking', 1, 'Career Transitions', 'Talk about changing jobs or careers', '{"prompt": "Have you changed career paths?"}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_intro', 2, 'Career Change Words', 'Learn words related to career transitions', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'switch', 'เปลี่ยน', NULL),
    (activity_id_var, 'promote', 'เลื่อนตำแหน่ง', NULL),
    (activity_id_var, 'resign', 'ลาออก', NULL),
    (activity_id_var, 'retrain', 'ฝึกใหม่', NULL),
    (activity_id_var, 'adjust', 'ปรับตัว', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_matching_drag', 3, 'Match Career Words', 'Match career change words', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'switch', 'เปลี่ยน', NULL),
    (activity_id_var, 'promote', 'เลื่อนตำแหน่ง', NULL),
    (activity_id_var, 'resign', 'ลาออก', NULL),
    (activity_id_var, 'retrain', 'ฝึกใหม่', NULL),
    (activity_id_var, 'adjust', 'ปรับตัว', NULL);

    -- 4. Vocabulary Fill Blanks #1
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 4, 'Complete the Sentences 1', 'Fill in the blanks with correct words', '{"text": "I want to ___ careers. She will be ___. They need to ___.", "blanks": [{"id": "blank1", "text": "switch", "options": ["switch", "promote", "resign", "retrain"], "correctAnswer": "switch"}, {"id": "blank2", "text": "promoted", "options": ["promoted", "switch", "resign", "retrain"], "correctAnswer": "promoted"}, {"id": "blank3", "text": "retrain", "options": ["retrain", "switch", "promote", "resign"], "correctAnswer": "retrain"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    -- 5. Vocabulary Fill Blanks #2
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 5, 'Complete the Sentences 2', 'Fill in the blanks with correct words', '{"text": "He decided to ___. I need to ___ to the new job. They ___ from their positions.", "blanks": [{"id": "blank1", "text": "resign", "options": ["resign", "switch", "promote", "adjust"], "correctAnswer": "resign"}, {"id": "blank2", "text": "adjust", "options": ["adjust", "switch", "promote", "resign"], "correctAnswer": "adjust"}, {"id": "blank3", "text": "resigned", "options": ["resigned", "switch", "promote", "adjust"], "correctAnswer": "resigned"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    -- 6. Grammar Explanation
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_explanation', 6, 'Present Perfect for Experiences', 'Learn present perfect for life experiences', '{"rules": "Use present perfect to talk about life experiences:\n\n- Form: have/has + past participle (have switched, has been promoted)\n- Use for experiences in your life (I have switched jobs)\n- Use ever/never for questions/negatives (Have you ever...?)\n- Use for/since with time periods (for 5 years, since 2020)\n- Don''t use specific past time (yesterday, last week)", "examples": ["I have switched jobs twice.", "She has been promoted three times.", "They have retrained for new careers.", "Have you ever changed careers?", "I have worked here for 5 years."]}'::jsonb)
    RETURNING id INTO activity_id_var;

    -- 7. Grammar Sentences #1
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 7, 'Build Sentences 1', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'I have switched jobs twice', 'I have switched jobs twice.', '["I", "have", "switched", "jobs", "twice."]'::jsonb),
    (activity_id_var, 'She has been promoted three times', 'She has been promoted three times.', '["She", "has", "been", "promoted", "three", "times."]'::jsonb);

    -- 8. Grammar Sentences #2
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 8, 'Build Sentences 2', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'They have retrained for new careers', 'They have retrained for new careers.', '["They", "have", "retrained", "for", "new", "careers."]'::jsonb),
    (activity_id_var, 'I have worked here for 5 years', 'I have worked here for 5 years.', '["I", "have", "worked", "here", "for", "5", "years."]'::jsonb);

    -- 9. Speaking Practice
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'speaking_practice', 9, 'Talk About Future Jobs', 'Practice talking about work and jobs', '{"prompts": ["What job does your father have?", "Do you want to be a teacher?", "Where do you want to work?", "Have you ever changed jobs?", "What career would you like to switch to?"]}'::jsonb)
    RETURNING id INTO activity_id_var;

    -- 10. Speaking Improvement
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'speaking_improvement', 10, 'Speaking Improvement', 'Read the improved version of your speech', '{"type": "speaking_improvement", "similarityThreshold": 70}'::jsonb)
    RETURNING id INTO activity_id_var;
END $$;


-- ===== B2 MISSING LESSONS 51-60 and 81-90 =====

-- ===== LESSON B2-L51 =====

-- =========================================
-- Pre-fill Database with Sample Lesson Data
-- B2-L51: Conflict resolution among peers
-- =========================================

DELETE FROM grammar_sentences WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'B2-L51');
DELETE FROM vocabulary_items WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'B2-L51');
DELETE FROM lesson_activities WHERE lesson_id = 'B2-L51';
DELETE FROM lessons WHERE id = 'B2-L51';

INSERT INTO lessons (id, level, lesson_number, topic) VALUES
('B2-L51', 'B2', 51, 'Conflict resolution among peers')
ON CONFLICT (id) DO UPDATE SET topic = EXCLUDED.topic;

DO $$
DECLARE
    lesson_id_var TEXT := 'B2-L51';
    activity_id_var UUID;
BEGIN
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'warm_up_speaking', 1, 'Resolution Approaches', 'Talk about handling peer conflicts', '{"prompt": "How do you solve problems with friends?"}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_intro', 2, 'Conflict Resolution Words', 'Learn words for handling disagreements', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'mediate', 'ไกล่เกลี่ย', NULL),
    (activity_id_var, 'compromise', 'ประนีประนอม', NULL),
    (activity_id_var, 'tension', 'ความตึงเครียด', NULL),
    (activity_id_var, 'pause', 'หยุดชั่วคราว', NULL),
    (activity_id_var, 'resolve', 'แก้ไข', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_matching_drag', 3, 'Match Resolution Words', 'Match conflict resolution words', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'mediate', 'ไกล่เกลี่ย', NULL),
    (activity_id_var, 'compromise', 'ประนีประนอม', NULL),
    (activity_id_var, 'tension', 'ความตึงเครียด', NULL),
    (activity_id_var, 'pause', 'หยุดชั่วคราว', NULL),
    (activity_id_var, 'resolve', 'แก้ไข', NULL);

    -- 4. Vocabulary Fill Blanks #1
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 4, 'Complete the Sentences 1', 'Fill in the blanks with correct words', '{"text": "I can ___ between friends. We need to ___. There is ___.", "blanks": [{"id": "blank1", "text": "mediate", "options": ["mediate", "compromise", "tension", "pause"], "correctAnswer": "mediate"}, {"id": "blank2", "text": "compromise", "options": ["compromise", "mediate", "tension", "resolve"], "correctAnswer": "compromise"}, {"id": "blank3", "text": "tension", "options": ["tension", "mediate", "compromise", "pause"], "correctAnswer": "tension"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    -- 5. Vocabulary Fill Blanks #2
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 5, 'Complete the Sentences 2', 'Fill in the blanks with correct words', '{"text": "Let''s ___ for a moment. We need to ___ this issue. They ___ the problem.", "blanks": [{"id": "blank1", "text": "pause", "options": ["pause", "mediate", "compromise", "tension"], "correctAnswer": "pause"}, {"id": "blank2", "text": "resolve", "options": ["resolve", "mediate", "compromise", "pause"], "correctAnswer": "resolve"}, {"id": "blank3", "text": "resolved", "options": ["resolved", "mediate", "compromise", "pause"], "correctAnswer": "resolved"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    -- 6. Grammar Explanation
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_explanation', 6, 'Present Perfect Continuous for Development', 'Learn present perfect continuous for ongoing development', '{"rules": "Use present perfect continuous for ongoing actions that started in the past:\n\n- Form: have/has + been + verb-ing (have been developing)\n- Use for actions that started in past and continue now\n- Emphasizes duration and ongoing nature\n- Often used with for/since (for 2 years, since last month)\n- Shows development or change over time", "examples": ["I have been developing better communication skills.", "She has been working on conflict resolution.", "They have been learning to mediate disputes.", "We have been practicing for months.", "He has been improving since last year."]}'::jsonb)
    RETURNING id INTO activity_id_var;

    -- 7. Grammar Sentences #1
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 7, 'Build Sentences 1', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'I have been developing better communication skills', 'I have been developing better communication skills.', '["I", "have", "been", "developing", "better", "communication", "skills."]'::jsonb),
    (activity_id_var, 'She has been working on conflict resolution', 'She has been working on conflict resolution.', '["She", "has", "been", "working", "on", "conflict", "resolution."]'::jsonb);

    -- 8. Grammar Sentences #2
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 8, 'Build Sentences 2', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'They have been learning to mediate disputes', 'They have been learning to mediate disputes.', '["They", "have", "been", "learning", "to", "mediate", "disputes."]'::jsonb),
    (activity_id_var, 'We have been practicing for months', 'We have been practicing for months.', '["We", "have", "been", "practicing", "for", "months."]'::jsonb);

    -- 9. Speaking Practice
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'speaking_practice', 9, 'Discuss Conflict Resolution', 'Practice talking about resolving peer conflicts', '{"prompts": ["How do you solve problems with friends?", "What do you do when you disagree?", "Who helps you when you have arguments?", "How do you mediate conflicts?", "What skills have you been developing?"]}'::jsonb)
    RETURNING id INTO activity_id_var;

    -- 10. Speaking Improvement
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'speaking_improvement', 10, 'Speaking Improvement', 'Read the improved version of your speech', '{"type": "speaking_improvement", "similarityThreshold": 70}'::jsonb)
    RETURNING id INTO activity_id_var;
END $$;


-- ===== LESSON B2-L52 =====

-- =========================================
-- Pre-fill Database with Sample Lesson Data
-- B2-L52: Financial responsibility
-- =========================================

DELETE FROM grammar_sentences WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'B2-L52');
DELETE FROM vocabulary_items WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'B2-L52');
DELETE FROM lesson_activities WHERE lesson_id = 'B2-L52';
DELETE FROM lessons WHERE id = 'B2-L52';

INSERT INTO lessons (id, level, lesson_number, topic) VALUES
('B2-L52', 'B2', 52, 'Financial responsibility')
ON CONFLICT (id) DO UPDATE SET topic = EXCLUDED.topic;

DO $$
DECLARE
    lesson_id_var TEXT := 'B2-L52';
    activity_id_var UUID;
BEGIN
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'warm_up_speaking', 1, 'Money Management', 'Talk about staying on top of finances', '{"prompt": "How do you manage your money?"}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_intro', 2, 'Financial Responsibility Words', 'Learn words for managing money', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'due', 'ครบกำหนด', NULL),
    (activity_id_var, 'obligation', 'ภาระผูกพัน', NULL),
    (activity_id_var, 'arrears', 'ค้างชำระ', NULL),
    (activity_id_var, 'mindful', 'ระมัดระวัง', NULL),
    (activity_id_var, 'plan', 'วางแผน', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_matching_drag', 3, 'Match Finance Words', 'Match financial responsibility words', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'due', 'ครบกำหนด', NULL),
    (activity_id_var, 'obligation', 'ภาระผูกพัน', NULL),
    (activity_id_var, 'arrears', 'ค้างชำระ', NULL),
    (activity_id_var, 'mindful', 'ระมัดระวัง', NULL),
    (activity_id_var, 'plan', 'วางแผน', NULL);

    -- 4. Vocabulary Fill Blanks #1
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 4, 'Complete the Sentences 1', 'Fill in the blanks with correct words', '{"text": "The payment is ___. I have an ___. We are in ___.", "blanks": [{"id": "blank1", "text": "due", "options": ["due", "obligation", "arrears", "mindful"], "correctAnswer": "due"}, {"id": "blank2", "text": "obligation", "options": ["obligation", "due", "arrears", "plan"], "correctAnswer": "obligation"}, {"id": "blank3", "text": "arrears", "options": ["arrears", "due", "obligation", "mindful"], "correctAnswer": "arrears"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    -- 5. Vocabulary Fill Blanks #2
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 5, 'Complete the Sentences 2', 'Fill in the blanks with correct words', '{"text": "I am ___ of spending. We need to ___ ahead. They ___ their finances.", "blanks": [{"id": "blank1", "text": "mindful", "options": ["mindful", "due", "obligation", "plan"], "correctAnswer": "mindful"}, {"id": "blank2", "text": "plan", "options": ["plan", "due", "obligation", "mindful"], "correctAnswer": "plan"}, {"id": "blank3", "text": "plan", "options": ["plan", "mindful", "due", "obligation"], "correctAnswer": "plan"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    -- 6. Grammar Explanation
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_explanation', 6, 'Future Continuous for Ongoing Actions', 'Learn future continuous for future ongoing situations', '{"rules": "Use future continuous for actions that will be in progress at a future time:\n\n- Form: will + be + verb-ing (will be tracking, will be setting)\n- Use for actions happening at a specific future time\n- Emphasizes ongoing nature of future action\n- Often used with time expressions (next month, at 3pm)\n- Shows continuous action in the future", "examples": ["I will be tracking my expenses carefully.", "She will be setting financial reminders.", "They will be planning their budget next month.", "We will be managing our money better.", "He will be saving for the future."]}'::jsonb)
    RETURNING id INTO activity_id_var;

    -- 7. Grammar Sentences #1
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 7, 'Build Sentences 1', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'I will be tracking my expenses carefully', 'I will be tracking my expenses carefully.', '["I", "will", "be", "tracking", "my", "expenses", "carefully."]'::jsonb),
    (activity_id_var, 'She will be setting financial reminders', 'She will be setting financial reminders.', '["She", "will", "be", "setting", "financial", "reminders."]'::jsonb);

    -- 8. Grammar Sentences #2
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 8, 'Build Sentences 2', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'They will be planning their budget next month', 'They will be planning their budget next month.', '["They", "will", "be", "planning", "their", "budget", "next", "month."]'::jsonb),
    (activity_id_var, 'We will be managing our money better', 'We will be managing our money better.', '["We", "will", "be", "managing", "our", "money", "better."]'::jsonb);

    -- 9. Speaking Practice
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'speaking_practice', 9, 'Discuss Financial Planning', 'Practice talking about financial responsibility', '{"prompts": ["How do you save money?", "What do you buy with cash?", "Do you use credit cards?", "How do you track expenses?", "What financial plans do you have?"]}'::jsonb)
    RETURNING id INTO activity_id_var;

    -- 10. Speaking Improvement
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'speaking_improvement', 10, 'Speaking Improvement', 'Read the improved version of your speech', '{"type": "speaking_improvement", "similarityThreshold": 70}'::jsonb)
    RETURNING id INTO activity_id_var;
END $$;


-- ===== LESSON B2-L53 =====

-- =========================================
-- Pre-fill Database with Sample Lesson Data
-- B2-L53: Travel and learning
-- =========================================

DELETE FROM grammar_sentences WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'B2-L53');
DELETE FROM vocabulary_items WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'B2-L53');
DELETE FROM lesson_activities WHERE lesson_id = 'B2-L53';
DELETE FROM lessons WHERE id = 'B2-L53';

INSERT INTO lessons (id, level, lesson_number, topic) VALUES
('B2-L53', 'B2', 53, 'Travel and learning')
ON CONFLICT (id) DO UPDATE SET topic = EXCLUDED.topic;

DO $$
DECLARE
    lesson_id_var TEXT := 'B2-L53';
    activity_id_var UUID;
BEGIN
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'warm_up_speaking', 1, 'Travel Stories', 'Talk about your travel experiences', '{"prompt": "Tell me about an interesting place you visited."}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_intro', 2, 'Travel Learning Words', 'Learn words for travel and personal growth', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'immerse', 'ดำดิ่ง', NULL),
    (activity_id_var, 'exposure', 'การเปิดรับ', NULL),
    (activity_id_var, 'insight', 'ความเข้าใจ', NULL),
    (activity_id_var, 'broaden', 'ขยาย', NULL),
    (activity_id_var, 'curiosity', 'ความอยากรู้', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_matching_drag', 3, 'Match Travel Learning Words', 'Match words related to travel and learning', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'immerse', 'ดำดิ่ง', NULL),
    (activity_id_var, 'exposure', 'การเปิดรับ', NULL),
    (activity_id_var, 'insight', 'ความเข้าใจ', NULL),
    (activity_id_var, 'broaden', 'ขยาย', NULL),
    (activity_id_var, 'curiosity', 'ความอยากรู้', NULL);

    -- 4. Vocabulary Fill Blanks #1
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 4, 'Complete the Sentences 1', 'Fill in the blanks with correct words', '{"text": "I want to ___ myself in the culture. Travel gives me ___. I gained new ___.", "blanks": [{"id": "blank1", "text": "immerse", "options": ["immerse", "exposure", "insight", "broaden"], "correctAnswer": "immerse"}, {"id": "blank2", "text": "exposure", "options": ["exposure", "immerse", "insight", "curiosity"], "correctAnswer": "exposure"}, {"id": "blank3", "text": "insight", "options": ["insight", "immerse", "exposure", "broaden"], "correctAnswer": "insight"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    -- 5. Vocabulary Fill Blanks #2
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 5, 'Complete the Sentences 2', 'Fill in the blanks with correct words', '{"text": "Travel helps ___ my mind. I have ___ about new places. My ___ grows with travel.", "blanks": [{"id": "blank1", "text": "broaden", "options": ["broaden", "immerse", "exposure", "insight"], "correctAnswer": "broaden"}, {"id": "blank2", "text": "insight", "options": ["insight", "immerse", "exposure", "curiosity"], "correctAnswer": "insight"}, {"id": "blank3", "text": "curiosity", "options": ["curiosity", "immerse", "exposure", "broaden"], "correctAnswer": "curiosity"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    -- 6. Grammar Explanation
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_explanation', 6, 'Non-defining Relative Clauses', 'Learn relative clauses that add extra information', '{"rules": "Use non-defining relative clauses to add extra information:\n\n- Use commas before and after the clause\n- Use which for things, who for people\n- The information is extra, not essential\n- Can be removed without changing main meaning\n- Use which/who (not that) in non-defining clauses", "examples": ["The trip, which lasted two weeks, completely changed my perspective.", "My friend, who speaks three languages, helped me navigate.", "The culture, which values community, taught me important lessons.", "The city, which I visited last year, was beautiful.", "My teacher, who traveled a lot, shared many stories."]}'::jsonb)
    RETURNING id INTO activity_id_var;

    -- 7. Grammar Sentences #1
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 7, 'Build Sentences 1', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'The trip which lasted two weeks completely changed my perspective', 'The trip, which lasted two weeks, completely changed my perspective.', '["The", "trip,", "which", "lasted", "two", "weeks,", "completely", "changed", "my", "perspective."]'::jsonb),
    (activity_id_var, 'My friend who speaks three languages helped me navigate', 'My friend, who speaks three languages, helped me navigate.', '["My", "friend,", "who", "speaks", "three", "languages,", "helped", "me", "navigate."]'::jsonb);

    -- 8. Grammar Sentences #2
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 8, 'Build Sentences 2', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'The culture which values community taught me important lessons', 'The culture, which values community, taught me important lessons.', '["The", "culture,", "which", "values", "community,", "taught", "me", "important", "lessons."]'::jsonb),
    (activity_id_var, 'The city which I visited last year was beautiful', 'The city, which I visited last year, was beautiful.', '["The", "city,", "which", "I", "visited", "last", "year,", "was", "beautiful."]'::jsonb);

    -- 9. Speaking Practice
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'speaking_practice', 9, 'Share Travel Stories', 'Practice talking about travel experiences', '{"prompts": ["What surprised you most when traveling?", "What new food did you try?", "Who did you meet on your trip?", "How did travel broaden your perspective?", "What insights did you gain from traveling?"]}'::jsonb)
    RETURNING id INTO activity_id_var;

    -- 10. Speaking Improvement
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'speaking_improvement', 10, 'Speaking Improvement', 'Read the improved version of your speech', '{"type": "speaking_improvement", "similarityThreshold": 70}'::jsonb)
    RETURNING id INTO activity_id_var;
END $$;


-- ===== LESSON B2-L54 =====

-- =========================================
-- Pre-fill Database with Sample Lesson Data
-- B2-L54: Entertainment choices
-- =========================================

DELETE FROM grammar_sentences WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'B2-L54');
DELETE FROM vocabulary_items WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'B2-L54');
DELETE FROM lesson_activities WHERE lesson_id = 'B2-L54';
DELETE FROM lessons WHERE id = 'B2-L54';

INSERT INTO lessons (id, level, lesson_number, topic) VALUES
('B2-L54', 'B2', 54, 'Entertainment choices')
ON CONFLICT (id) DO UPDATE SET topic = EXCLUDED.topic;

DO $$
DECLARE
    lesson_id_var TEXT := 'B2-L54';
    activity_id_var UUID;
BEGIN
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'warm_up_speaking', 1, 'Media Choices', 'Talk about entertainment preferences', '{"prompt": "If you cut one platform, what changes?"}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_intro', 2, 'Entertainment Words', 'Learn words related to entertainment choices', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'genre', 'ประเภท', NULL),
    (activity_id_var, 'binge', 'ดูต่อเนื่อง', NULL),
    (activity_id_var, 'mood', 'อารมณ์', NULL),
    (activity_id_var, 'uplift', 'ให้กำลังใจ', NULL),
    (activity_id_var, 'resonate', 'สั่นไหว', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_matching_drag', 3, 'Match Entertainment Words', 'Match entertainment-related words', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'genre', 'ประเภท', NULL),
    (activity_id_var, 'binge', 'ดูต่อเนื่อง', NULL),
    (activity_id_var, 'mood', 'อารมณ์', NULL),
    (activity_id_var, 'uplift', 'ให้กำลังใจ', NULL),
    (activity_id_var, 'resonate', 'สั่นไหว', NULL);

    -- 4. Vocabulary Fill Blanks #1
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 4, 'Complete the Sentences 1', 'Fill in the blanks with correct words', '{"text": "I like this ___. I ___ watch shows. My ___ affects my choice.", "blanks": [{"id": "blank1", "text": "genre", "options": ["genre", "binge", "mood", "uplift"], "correctAnswer": "genre"}, {"id": "blank2", "text": "binge", "options": ["binge", "genre", "mood", "resonate"], "correctAnswer": "binge"}, {"id": "blank3", "text": "mood", "options": ["mood", "genre", "binge", "uplift"], "correctAnswer": "mood"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    -- 5. Vocabulary Fill Blanks #2
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 5, 'Complete the Sentences 2', 'Fill in the blanks with correct words', '{"text": "This show can ___ me. The story ___ with me. I feel ___.", "blanks": [{"id": "blank1", "text": "uplift", "options": ["uplift", "genre", "binge", "mood"], "correctAnswer": "uplift"}, {"id": "blank2", "text": "resonates", "options": ["resonates", "genre", "binge", "uplift"], "correctAnswer": "resonates"}, {"id": "blank3", "text": "uplifted", "options": ["uplifted", "genre", "binge", "mood"], "correctAnswer": "uplifted"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    -- 6. Grammar Explanation
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_explanation', 6, 'Second Conditional for Hypotheticals', 'Learn if/when for unreal situations', '{"rules": "Use second conditional for hypothetical or unreal situations:\n\n- Form: If + past simple, would + base verb\n- If you cut services, what would you do?\n- If a show resonated, you would recommend it\n- Use were for all subjects (If I were, If you were)\n- Expresses unlikely or imaginary situations\n- Often used for advice or suggestions", "examples": ["If you cut streaming services, what would you do for entertainment?", "If a show resonated with you, you would recommend it to friends.", "If you were in a bad mood, which genre would you choose?", "If I had more time, I would watch more shows.", "What would you do if you couldn''t watch TV?"]}'::jsonb)
    RETURNING id INTO activity_id_var;

    -- 7. Grammar Sentences #1
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 7, 'Build Sentences 1', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'If you cut streaming services what would you do for entertainment', 'If you cut streaming services, what would you do for entertainment?', '["If", "you", "cut", "streaming", "services,", "what", "would", "you", "do", "for", "entertainment?"]'::jsonb),
    (activity_id_var, 'If a show resonated with you you would recommend it to friends', 'If a show resonated with you, you would recommend it to friends.', '["If", "a", "show", "resonated", "with", "you,", "you", "would", "recommend", "it", "to", "friends."]'::jsonb);

    -- 8. Grammar Sentences #2
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 8, 'Build Sentences 2', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'If you were in a bad mood which genre would you choose', 'If you were in a bad mood, which genre would you choose?', '["If", "you", "were", "in", "a", "bad", "mood,", "which", "genre", "would", "you", "choose?"]'::jsonb),
    (activity_id_var, 'If I had more time I would watch more shows', 'If I had more time, I would watch more shows.', '["If", "I", "had", "more", "time,", "I", "would", "watch", "more", "shows."]'::jsonb);

    -- 9. Speaking Practice
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'speaking_practice', 9, 'Talk About Movies and TV', 'Practice talking about watching shows', '{"prompts": ["What is your favorite TV show?", "Do you watch movies with your family?", "Who is your favorite movie star?", "What genre do you prefer?", "If you could only watch one show, what would it be?"]}'::jsonb)
    RETURNING id INTO activity_id_var;

    -- 10. Speaking Improvement
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'speaking_improvement', 10, 'Speaking Improvement', 'Read the improved version of your speech', '{"type": "speaking_improvement", "similarityThreshold": 70}'::jsonb)
    RETURNING id INTO activity_id_var;
END $$;


-- ===== LESSON B2-L81 =====

-- =========================================
-- Pre-fill Database with Sample Lesson Data
-- B2-L81: Evaluating information
-- =========================================

DELETE FROM grammar_sentences WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'B2-L81');
DELETE FROM vocabulary_items WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'B2-L81');
DELETE FROM lesson_activities WHERE lesson_id = 'B2-L81';
DELETE FROM lessons WHERE id = 'B2-L81';

INSERT INTO lessons (id, level, lesson_number, topic) VALUES
('B2-L81', 'B2', 81, 'Evaluating information')
ON CONFLICT (id) DO UPDATE SET topic = EXCLUDED.topic;

DO $$
DECLARE
    lesson_id_var TEXT := 'B2-L81';
    activity_id_var UUID;
BEGIN
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'warm_up_speaking', 1, 'Information Check', 'Talk about checking information online', '{"prompt": "How do you know if news is true?"}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_intro', 2, 'Information Words', 'Learn words for checking information', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'opinion', 'ความเห็น', NULL),
    (activity_id_var, 'bias', 'อคติ', NULL),
    (activity_id_var, 'headline', 'หัวข้อข่าว', NULL),
    (activity_id_var, 'verify', 'ตรวจสอบ', NULL),
    (activity_id_var, 'platform', 'แพลตฟอร์ม', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_matching_drag', 3, 'Match Information Words', 'Match information checking words', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'opinion', 'ความเห็น', NULL),
    (activity_id_var, 'bias', 'อคติ', NULL),
    (activity_id_var, 'headline', 'หัวข้อข่าว', NULL),
    (activity_id_var, 'verify', 'ตรวจสอบ', NULL),
    (activity_id_var, 'platform', 'แพลตฟอร์ม', NULL);

    -- 4. Vocabulary Fill Blanks #1
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 4, 'Complete the Sentences 1', 'Fill in the blanks with correct words', '{"text": "This is just an ___. There is ___. Check the ___.", "blanks": [{"id": "blank1", "text": "opinion", "options": ["opinion", "bias", "headline", "verify"], "correctAnswer": "opinion"}, {"id": "blank2", "text": "bias", "options": ["bias", "opinion", "headline", "platform"], "correctAnswer": "bias"}, {"id": "blank3", "text": "headline", "options": ["headline", "opinion", "bias", "verify"], "correctAnswer": "headline"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    -- 5. Vocabulary Fill Blanks #2
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 5, 'Complete the Sentences 2', 'Fill in the blanks with correct words', '{"text": "I need to ___ this information. Which ___ do you use? We should ___.", "blanks": [{"id": "blank1", "text": "verify", "options": ["verify", "opinion", "bias", "headline"], "correctAnswer": "verify"}, {"id": "blank2", "text": "platform", "options": ["platform", "verify", "opinion", "bias"], "correctAnswer": "platform"}, {"id": "blank3", "text": "verify", "options": ["verify", "platform", "opinion", "bias"], "correctAnswer": "verify"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    -- 6. Grammar Explanation
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_explanation', 6, 'Reduced Relative Clauses', 'Learn shortened relative clauses for information', '{"rules": "Use reduced relative clauses to make sentences shorter:\n\n- Remove relative pronoun (who/which/that) and be verb\n- The news (which) we trust → The news we trust\n- Information (which was) checked quickly → Information checked quickly\n- Sources (which were) chosen carefully → Sources chosen carefully\n- Use past participle for passive meaning", "examples": ["The news we trust comes from verified sources.", "Information checked quickly is often accurate.", "Sources chosen carefully build trust.", "Articles written by experts are reliable.", "News shared without checking can be false."]}'::jsonb)
    RETURNING id INTO activity_id_var;

    -- 7. Grammar Sentences #1
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 7, 'Build Sentences 1', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'The news we trust comes from verified sources', 'The news we trust comes from verified sources.', '["The", "news", "we", "trust", "comes", "from", "verified", "sources."]'::jsonb),
    (activity_id_var, 'Information checked quickly is often accurate', 'Information checked quickly is often accurate.', '["Information", "checked", "quickly", "is", "often", "accurate."]'::jsonb);

    -- 8. Grammar Sentences #2
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 8, 'Build Sentences 2', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'Sources chosen carefully build trust', 'Sources chosen carefully build trust.', '["Sources", "chosen", "carefully", "build", "trust."]'::jsonb),
    (activity_id_var, 'Articles written by experts are reliable', 'Articles written by experts are reliable.', '["Articles", "written", "by", "experts", "are", "reliable."]'::jsonb);

    -- 9. Speaking Practice
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'speaking_practice', 9, 'Talk About Information', 'Practice talking about checking information', '{"prompts": ["How do you check if news is real?", "Which websites do you trust?", "When do you share information?", "How do you verify information?", "What platforms do you use for news?"]}'::jsonb)
    RETURNING id INTO activity_id_var;

    -- 10. Speaking Improvement
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'speaking_improvement', 10, 'Speaking Improvement', 'Read the improved version of your speech', '{"type": "speaking_improvement", "similarityThreshold": 70}'::jsonb)
    RETURNING id INTO activity_id_var;
END $$;


-- ===== LESSON B2-L82 =====

-- =========================================
-- Pre-fill Database with Sample Lesson Data
-- B2-L82: Responsible media use (habits)
-- =========================================

DELETE FROM grammar_sentences WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'B2-L82');
DELETE FROM vocabulary_items WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'B2-L82');
DELETE FROM lesson_activities WHERE lesson_id = 'B2-L82';
DELETE FROM lessons WHERE id = 'B2-L82';

INSERT INTO lessons (id, level, lesson_number, topic) VALUES
('B2-L82', 'B2', 82, 'Responsible media use (habits)')
ON CONFLICT (id) DO UPDATE SET topic = EXCLUDED.topic;

DO $$
DECLARE
    lesson_id_var TEXT := 'B2-L82';
    activity_id_var UUID;
BEGIN
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'warm_up_speaking', 1, 'Screen Time', 'Talk about how you use social media', '{"prompt": "How much time do you spend on your phone?"}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_intro', 2, 'Media Responsibility Words', 'Learn words for responsible media use', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'moderate', 'ควบคุม', NULL),
    (activity_id_var, 'report', 'รายงาน', NULL),
    (activity_id_var, 'restrict', 'จำกัด', NULL),
    (activity_id_var, 'verify', 'ตรวจสอบ', NULL),
    (activity_id_var, 'consent', 'ความยินยอม', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_matching_drag', 3, 'Match Media Words', 'Match responsible media words', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'moderate', 'ควบคุม', NULL),
    (activity_id_var, 'report', 'รายงาน', NULL),
    (activity_id_var, 'restrict', 'จำกัด', NULL),
    (activity_id_var, 'verify', 'ตรวจสอบ', NULL),
    (activity_id_var, 'consent', 'ความยินยอม', NULL);

    -- 4. Vocabulary Fill Blanks #1
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 4, 'Complete the Sentences 1', 'Fill in the blanks with correct words', '{"text": "I need to ___ my use. I will ___ bad content. We should ___.", "blanks": [{"id": "blank1", "text": "moderate", "options": ["moderate", "report", "restrict", "verify"], "correctAnswer": "moderate"}, {"id": "blank2", "text": "report", "options": ["report", "moderate", "restrict", "consent"], "correctAnswer": "report"}, {"id": "blank3", "text": "restrict", "options": ["restrict", "moderate", "report", "verify"], "correctAnswer": "restrict"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    -- 5. Vocabulary Fill Blanks #2
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 5, 'Complete the Sentences 2', 'Fill in the blanks with correct words', '{"text": "I need to ___ this first. Get their ___. We must ___.", "blanks": [{"id": "blank1", "text": "verify", "options": ["verify", "moderate", "report", "restrict"], "correctAnswer": "verify"}, {"id": "blank2", "text": "consent", "options": ["consent", "moderate", "report", "verify"], "correctAnswer": "consent"}, {"id": "blank3", "text": "verify", "options": ["verify", "consent", "moderate", "report"], "correctAnswer": "verify"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    -- 6. Grammar Explanation
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_explanation', 6, 'Present Perfect Continuous for Habits', 'Learn present perfect continuous for ongoing habits', '{"rules": "Use present perfect continuous for habits that started in the past and continue now:\n\n- Form: have/has + been + verb-ing (have been moderating)\n- Use for ongoing habits or repeated actions\n- Emphasizes duration and continuity\n- Often used with time expressions (for months, since last year)\n- Shows habits that are still happening", "examples": ["I have been moderating my social media use.", "She has been reporting inappropriate content.", "They have been verifying information before sharing.", "We have been restricting screen time.", "He has been checking sources regularly."]}'::jsonb)
    RETURNING id INTO activity_id_var;

    -- 7. Grammar Sentences #1
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 7, 'Build Sentences 1', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'I have been moderating my social media use', 'I have been moderating my social media use.', '["I", "have", "been", "moderating", "my", "social", "media", "use."]'::jsonb),
    (activity_id_var, 'She has been reporting inappropriate content', 'She has been reporting inappropriate content.', '["She", "has", "been", "reporting", "inappropriate", "content."]'::jsonb);

    -- 8. Grammar Sentences #2
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 8, 'Build Sentences 2', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'They have been verifying information before sharing', 'They have been verifying information before sharing.', '["They", "have", "been", "verifying", "information", "before", "sharing."]'::jsonb),
    (activity_id_var, 'We have been restricting screen time', 'We have been restricting screen time.', '["We", "have", "been", "restricting", "screen", "time."]'::jsonb);

    -- 9. Speaking Practice
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'speaking_practice', 9, 'Talk About Social Media', 'Practice talking about online habits', '{"prompts": ["What apps do you use most?", "When do you take breaks from your phone?", "Who do you talk to online?", "How do you moderate your media use?", "What habits have you been developing?"]}'::jsonb)
    RETURNING id INTO activity_id_var;

    -- 10. Speaking Improvement
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'speaking_improvement', 10, 'Speaking Improvement', 'Read the improved version of your speech', '{"type": "speaking_improvement", "similarityThreshold": 70}'::jsonb)
    RETURNING id INTO activity_id_var;
END $$;


-- ===== LESSON B2-L55 =====

-- =========================================
-- Pre-fill Database with Sample Lesson Data
-- B2-L55: Learning from experience
-- =========================================

DELETE FROM grammar_sentences WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'B2-L55');
DELETE FROM vocabulary_items WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'B2-L55');
DELETE FROM lesson_activities WHERE lesson_id = 'B2-L55';
DELETE FROM lessons WHERE id = 'B2-L55';

INSERT INTO lessons (id, level, lesson_number, topic) VALUES
('B2-L55', 'B2', 55, 'Learning from experience')
ON CONFLICT (id) DO UPDATE SET topic = EXCLUDED.topic;

DO $$
DECLARE
    lesson_id_var TEXT := 'B2-L55';
    activity_id_var UUID;
BEGIN
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'warm_up_speaking', 1, 'Life Lessons', 'Talk about what you learned from experiences', '{"prompt": "Although it was hard, what did you learn?"}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_intro', 2, 'Learning Words', 'Learn words related to learning from experience', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'lesson', 'บทเรียน', NULL),
    (activity_id_var, 'revise', 'แก้ไข', NULL),
    (activity_id_var, 'iterate', 'ทำซ้ำ', NULL),
    (activity_id_var, 'hindsight', 'มองย้อนหลัง', NULL),
    (activity_id_var, 'improve', 'ปรับปรุง', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_matching_drag', 3, 'Match Learning Words', 'Match words related to learning from experience', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'lesson', 'บทเรียน', NULL),
    (activity_id_var, 'revise', 'แก้ไข', NULL),
    (activity_id_var, 'iterate', 'ทำซ้ำ', NULL),
    (activity_id_var, 'hindsight', 'มองย้อนหลัง', NULL),
    (activity_id_var, 'improve', 'ปรับปรุง', NULL);

    -- 4. Vocabulary Fill Blanks #1
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 4, 'Complete the Sentences 1', 'Fill in the blanks with correct words', '{"text": "I learned a valuable ___. I need to ___ my work. We ___ the process.", "blanks": [{"id": "blank1", "text": "lesson", "options": ["lesson", "revise", "iterate", "hindsight"], "correctAnswer": "lesson"}, {"id": "blank2", "text": "revise", "options": ["revise", "lesson", "iterate", "improve"], "correctAnswer": "revise"}, {"id": "blank3", "text": "iterate", "options": ["iterate", "lesson", "revise", "hindsight"], "correctAnswer": "iterate"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    -- 5. Vocabulary Fill Blanks #2
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 5, 'Complete the Sentences 2', 'Fill in the blanks with correct words', '{"text": "In ___, I see my mistakes. I want to ___ my skills. We ___ our approach.", "blanks": [{"id": "blank1", "text": "hindsight", "options": ["hindsight", "lesson", "revise", "improve"], "correctAnswer": "hindsight"}, {"id": "blank2", "text": "improve", "options": ["improve", "lesson", "revise", "hindsight"], "correctAnswer": "improve"}, {"id": "blank3", "text": "improve", "options": ["improve", "hindsight", "revise", "iterate"], "correctAnswer": "improve"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    -- 6. Grammar Explanation
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_explanation', 6, 'Contrast with Although/However', 'Learn although/however for contrast', '{"rules": "Use although and however to show contrast:\n\n- Although = at the start of a clause (Although it was difficult, I learned)\n- However = between sentences or clauses (I failed; however, I studied harder)\n- But = in the middle of a sentence (It was hard, but I learned)\n- All show contrast between two ideas\n- Although and but are similar, but different positions", "examples": ["Although it was difficult, I learned a valuable lesson.", "I failed the test; however, I studied harder next time.", "The project was challenging, but I improved my skills.", "Although I struggled, I didn''t give up.", "It was hard; however, I succeeded in the end."]}'::jsonb)
    RETURNING id INTO activity_id_var;

    -- 7. Grammar Sentences #1
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 7, 'Build Sentences 1', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'Although it was difficult I learned a valuable lesson', 'Although it was difficult, I learned a valuable lesson.', '["Although", "it", "was", "difficult,", "I", "learned", "a", "valuable", "lesson."]'::jsonb),
    (activity_id_var, 'I failed the test however I studied harder next time', 'I failed the test; however, I studied harder next time.', '["I", "failed", "the", "test;", "however,", "I", "studied", "harder", "next", "time."]'::jsonb);

    -- 8. Grammar Sentences #2
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 8, 'Build Sentences 2', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'The project was challenging but I improved my skills', 'The project was challenging, but I improved my skills.', '["The", "project", "was", "challenging,", "but", "I", "improved", "my", "skills."]'::jsonb),
    (activity_id_var, 'Although I struggled I did not give up', 'Although I struggled, I didn''t give up.', '["Although", "I", "struggled,", "I", "didn''t", "give", "up."]'::jsonb);

    -- 9. Speaking Practice
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'speaking_practice', 9, 'Talk About School', 'Practice talking about learning experiences', '{"prompts": ["What was your favorite subject?", "Who is your favorite teacher?", "What did you learn last week?", "What lesson did you learn from a difficult experience?", "How do you improve when things are hard?"]}'::jsonb)
    RETURNING id INTO activity_id_var;

    -- 10. Speaking Improvement
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'speaking_improvement', 10, 'Speaking Improvement', 'Read the improved version of your speech', '{"type": "speaking_improvement", "similarityThreshold": 70}'::jsonb)
    RETURNING id INTO activity_id_var;
END $$;


-- ===== LESSON B2-L83 =====

-- =========================================
-- Pre-fill Database with Sample Lesson Data
-- B2-L83: Advertising influence (signals)
-- =========================================

DELETE FROM grammar_sentences WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'B2-L83');
DELETE FROM vocabulary_items WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'B2-L83');
DELETE FROM lesson_activities WHERE lesson_id = 'B2-L83';
DELETE FROM lessons WHERE id = 'B2-L83';

INSERT INTO lessons (id, level, lesson_number, topic) VALUES
('B2-L83', 'B2', 83, 'Advertising influence (signals)')
ON CONFLICT (id) DO UPDATE SET topic = EXCLUDED.topic;

DO $$
DECLARE
    lesson_id_var TEXT := 'B2-L83';
    activity_id_var UUID;
BEGIN
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'warm_up_speaking', 1, 'Ad Influence', 'Talk about how advertisements affect you', '{"prompt": "How can you tell an ad is shaping you?"}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_intro', 2, 'Advertising Words', 'Learn words related to advertising influence', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'persuasive', 'โน้มน้าวใจ', NULL),
    (activity_id_var, 'subtle', 'ละเอียด', NULL),
    (activity_id_var, 'impulse', 'แรงกระตุ้น', NULL),
    (activity_id_var, 'sponsorship', 'การสนับสนุน', NULL),
    (activity_id_var, 'trigger', 'กระตุ้น', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_matching_drag', 3, 'Match Advertising Words', 'Match words related to advertising', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'persuasive', 'โน้มน้าวใจ', NULL),
    (activity_id_var, 'subtle', 'ละเอียด', NULL),
    (activity_id_var, 'impulse', 'แรงกระตุ้น', NULL),
    (activity_id_var, 'sponsorship', 'การสนับสนุน', NULL),
    (activity_id_var, 'trigger', 'กระตุ้น', NULL);

    -- 4. Vocabulary Fill Blanks #1
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 4, 'Complete the Sentences 1', 'Fill in the blanks with correct words', '{"text": "This ad is very ___. The message is ___. It creates an ___.", "blanks": [{"id": "blank1", "text": "persuasive", "options": ["persuasive", "subtle", "impulse", "sponsorship"], "correctAnswer": "persuasive"}, {"id": "blank2", "text": "subtle", "options": ["subtle", "persuasive", "impulse", "trigger"], "correctAnswer": "subtle"}, {"id": "blank3", "text": "impulse", "options": ["impulse", "persuasive", "subtle", "sponsorship"], "correctAnswer": "impulse"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    -- 5. Vocabulary Fill Blanks #2
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 5, 'Complete the Sentences 2', 'Fill in the blanks with correct words', '{"text": "The ___ is clear. This can ___ buying. We see ___.", "blanks": [{"id": "blank1", "text": "sponsorship", "options": ["sponsorship", "persuasive", "subtle", "impulse"], "correctAnswer": "sponsorship"}, {"id": "blank2", "text": "trigger", "options": ["trigger", "persuasive", "subtle", "sponsorship"], "correctAnswer": "trigger"}, {"id": "blank3", "text": "sponsorship", "options": ["sponsorship", "trigger", "persuasive", "subtle"], "correctAnswer": "sponsorship"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    -- 6. Grammar Explanation
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_explanation', 6, 'Modals for Deduction', 'Learn must/might/can''t for logical conclusions', '{"rules": "Use modal verbs to make logical deductions:\n\n- Must = very certain conclusion (must be targeting)\n- Might = possible conclusion (might be chosen)\n- Can''t = impossible conclusion (can''t be a coincidence)\n- Use must/might/can''t + be + verb-ing for ongoing actions\n- Use must/might/can''t + be + past participle for passive\n- Expresses logical thinking, not facts", "examples": ["This advertisement must be targeting young people.", "The colors might be chosen to attract attention.", "This can''t be a coincidence; it''s sponsored content.", "They must be trying to influence us.", "It might be working on some people."]}'::jsonb)
    RETURNING id INTO activity_id_var;

    -- 7. Grammar Sentences #1
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 7, 'Build Sentences 1', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'This advertisement must be targeting young people', 'This advertisement must be targeting young people.', '["This", "advertisement", "must", "be", "targeting", "young", "people."]'::jsonb),
    (activity_id_var, 'The colors might be chosen to attract attention', 'The colors might be chosen to attract attention.', '["The", "colors", "might", "be", "chosen", "to", "attract", "attention."]'::jsonb);

    -- 8. Grammar Sentences #2
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 8, 'Build Sentences 2', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'This cannot be a coincidence it is sponsored content', 'This can''t be a coincidence; it''s sponsored content.', '["This", "can''t", "be", "a", "coincidence;", "it''s", "sponsored", "content."]'::jsonb),
    (activity_id_var, 'They must be trying to influence us', 'They must be trying to influence us.', '["They", "must", "be", "trying", "to", "influence", "us."]'::jsonb);

    -- 9. Speaking Practice
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'speaking_practice', 9, 'Talk About Commercials', 'Practice talking about TV ads', '{"prompts": ["What commercials do you remember?", "Do you like funny ads?", "What product ads do you see?", "How do ads influence you?", "What makes an ad persuasive?"]}'::jsonb)
    RETURNING id INTO activity_id_var;

    -- 10. Speaking Improvement
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'speaking_improvement', 10, 'Speaking Improvement', 'Read the improved version of your speech', '{"type": "speaking_improvement", "similarityThreshold": 70}'::jsonb)
    RETURNING id INTO activity_id_var;
END $$;


-- ===== LESSON B2-L56 =====

-- =========================================
-- Pre-fill Database with Sample Lesson Data
-- B2-L56: Advertising influence
-- =========================================

DELETE FROM grammar_sentences WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'B2-L56');
DELETE FROM vocabulary_items WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'B2-L56');
DELETE FROM lesson_activities WHERE lesson_id = 'B2-L56';
DELETE FROM lessons WHERE id = 'B2-L56';

INSERT INTO lessons (id, level, lesson_number, topic) VALUES
('B2-L56', 'B2', 56, 'Advertising influence')
ON CONFLICT (id) DO UPDATE SET topic = EXCLUDED.topic;

DO $$
DECLARE
    lesson_id_var TEXT := 'B2-L56';
    activity_id_var UUID;
BEGIN
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'warm_up_speaking', 1, 'Ad Awareness', 'Talk about how ads influence consumer behavior', '{"prompt": "How can you tell an ad is shaping you?"}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_intro', 2, 'Advertising Impact Words', 'Learn words related to advertising influence', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'persuasive', 'โน้มน้าวใจ', NULL),
    (activity_id_var, 'subtle', 'ละเอียด', NULL),
    (activity_id_var, 'impulse', 'แรงกระตุ้น', NULL),
    (activity_id_var, 'sponsorship', 'การสนับสนุน', NULL),
    (activity_id_var, 'trigger', 'กระตุ้น', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_matching_drag', 3, 'Match Advertising Words', 'Match words related to advertising effects', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'persuasive', 'โน้มน้าวใจ', NULL),
    (activity_id_var, 'subtle', 'ละเอียด', NULL),
    (activity_id_var, 'impulse', 'แรงกระตุ้น', NULL),
    (activity_id_var, 'sponsorship', 'การสนับสนุน', NULL),
    (activity_id_var, 'trigger', 'กระตุ้น', NULL);

    -- 4. Vocabulary Fill Blanks #1
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 4, 'Complete the Sentences 1', 'Fill in the blanks with correct words', '{"text": "This ad is very ___. The message is ___. It creates an ___.", "blanks": [{"id": "blank1", "text": "persuasive", "options": ["persuasive", "subtle", "impulse", "sponsorship"], "correctAnswer": "persuasive"}, {"id": "blank2", "text": "subtle", "options": ["subtle", "persuasive", "impulse", "trigger"], "correctAnswer": "subtle"}, {"id": "blank3", "text": "impulse", "options": ["impulse", "persuasive", "subtle", "sponsorship"], "correctAnswer": "impulse"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    -- 5. Vocabulary Fill Blanks #2
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 5, 'Complete the Sentences 2', 'Fill in the blanks with correct words', '{"text": "The ___ is clear. This can ___ buying. We see ___.", "blanks": [{"id": "blank1", "text": "sponsorship", "options": ["sponsorship", "persuasive", "subtle", "impulse"], "correctAnswer": "sponsorship"}, {"id": "blank2", "text": "trigger", "options": ["trigger", "persuasive", "subtle", "sponsorship"], "correctAnswer": "trigger"}, {"id": "blank3", "text": "sponsorship", "options": ["sponsorship", "trigger", "persuasive", "subtle"], "correctAnswer": "sponsorship"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    -- 6. Grammar Explanation
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_explanation', 6, 'Modals for Deduction', 'Learn must/might/can''t for logical conclusions', '{"rules": "Use modal verbs to make logical deductions:\n\n- Must = very certain conclusion (must be targeting)\n- Might = possible conclusion (might be chosen)\n- Can''t = impossible conclusion (can''t be unbiased)\n- Use must/might/can''t + be + verb-ing for ongoing actions\n- Use must/might/can''t + be + past participle for passive\n- Expresses logical thinking, not facts", "examples": ["This advertisement must be targeting young adults.", "The colors might be chosen to create desire.", "This can''t be unbiased; it''s sponsored content.", "They must be trying to influence us.", "It might be working on some people."]}'::jsonb)
    RETURNING id INTO activity_id_var;

    -- 7. Grammar Sentences #1
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 7, 'Build Sentences 1', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'This advertisement must be targeting young adults', 'This advertisement must be targeting young adults.', '["This", "advertisement", "must", "be", "targeting", "young", "adults."]'::jsonb),
    (activity_id_var, 'The colors might be chosen to create desire', 'The colors might be chosen to create desire.', '["The", "colors", "might", "be", "chosen", "to", "create", "desire."]'::jsonb);

    -- 8. Grammar Sentences #2
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 8, 'Build Sentences 2', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'This cannot be unbiased it is sponsored content', 'This can''t be unbiased; it''s sponsored content.', '["This", "can''t", "be", "unbiased;", "it''s", "sponsored", "content."]'::jsonb),
    (activity_id_var, 'They must be trying to influence us', 'They must be trying to influence us.', '["They", "must", "be", "trying", "to", "influence", "us."]'::jsonb);

    -- 9. Speaking Practice
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'speaking_practice', 9, 'Talk About Ads', 'Practice talking about advertisements', '{"prompts": ["What food ads do you see?", "Do you buy things from ads?", "What drink commercials are funny?", "How do ads influence you?", "What makes an ad persuasive?"]}'::jsonb)
    RETURNING id INTO activity_id_var;

    -- 10. Speaking Improvement
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'speaking_improvement', 10, 'Speaking Improvement', 'Read the improved version of your speech', '{"type": "speaking_improvement", "similarityThreshold": 70}'::jsonb)
    RETURNING id INTO activity_id_var;
END $$;


-- ===== LESSON B2-L57 =====

-- =========================================
-- Pre-fill Database with Sample Lesson Data
-- B2-L57: Daily responsibilities
-- =========================================

DELETE FROM grammar_sentences WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'B2-L57');
DELETE FROM vocabulary_items WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'B2-L57');
DELETE FROM lesson_activities WHERE lesson_id = 'B2-L57';
DELETE FROM lessons WHERE id = 'B2-L57';

INSERT INTO lessons (id, level, lesson_number, topic) VALUES
('B2-L57', 'B2', 57, 'Daily responsibilities')
ON CONFLICT (id) DO UPDATE SET topic = EXCLUDED.topic;

DO $$
DECLARE
    lesson_id_var TEXT := 'B2-L57';
    activity_id_var UUID;
BEGIN
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'warm_up_speaking', 1, 'Task Management', 'Talk about managing daily responsibilities', '{"prompt": "What should you have done yesterday?"}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_intro', 2, 'Responsibility Words', 'Learn words related to daily tasks', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'assign', 'มอบหมาย', NULL),
    (activity_id_var, 'remind', 'เตือน', NULL),
    (activity_id_var, 'overdue', 'เกินกำหนด', NULL),
    (activity_id_var, 'routine', 'กิจวัตร', NULL),
    (activity_id_var, 'checklist', 'รายการตรวจสอบ', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_matching_drag', 3, 'Match Responsibility Words', 'Match words related to tasks', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'assign', 'มอบหมาย', NULL),
    (activity_id_var, 'remind', 'เตือน', NULL),
    (activity_id_var, 'overdue', 'เกินกำหนด', NULL),
    (activity_id_var, 'routine', 'กิจวัตร', NULL),
    (activity_id_var, 'checklist', 'รายการตรวจสอบ', NULL);

    -- 4. Vocabulary Fill Blanks #1
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 4, 'Complete the Sentences 1', 'Fill in the blanks with correct words', '{"text": "I will ___ you a task. Please ___ me tomorrow. This task is ___.", "blanks": [{"id": "blank1", "text": "assign", "options": ["assign", "remind", "overdue", "routine"], "correctAnswer": "assign"}, {"id": "blank2", "text": "remind", "options": ["remind", "assign", "overdue", "checklist"], "correctAnswer": "remind"}, {"id": "blank3", "text": "overdue", "options": ["overdue", "assign", "remind", "routine"], "correctAnswer": "overdue"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    -- 5. Vocabulary Fill Blanks #2
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 5, 'Complete the Sentences 2', 'Fill in the blanks with correct words', '{"text": "I have a daily ___. Check your ___. Follow the ___.", "blanks": [{"id": "blank1", "text": "routine", "options": ["routine", "assign", "remind", "overdue"], "correctAnswer": "routine"}, {"id": "blank2", "text": "checklist", "options": ["checklist", "assign", "remind", "routine"], "correctAnswer": "checklist"}, {"id": "blank3", "text": "checklist", "options": ["checklist", "routine", "assign", "remind"], "correctAnswer": "checklist"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    -- 6. Grammar Explanation
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_explanation', 6, 'Past Modals (should have/could have)', 'Learn should have/could have for past regrets', '{"rules": "Use past modals to talk about past regrets or missed opportunities:\n\n- Should have = something you should have done but didn''t (I should have completed)\n- Could have = something you could have done but didn''t (She could have reminded)\n- Form: should/could + have + past participle\n- Expresses regret or criticism about the past\n- Use for things that didn''t happen but should/could have", "examples": ["I should have completed the task yesterday.", "She could have reminded me about the deadline.", "They should have checked the checklist.", "I could have finished earlier.", "You should have asked for help."]}'::jsonb)
    RETURNING id INTO activity_id_var;

    -- 7. Grammar Sentences #1
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 7, 'Build Sentences 1', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'I should have completed the task yesterday', 'I should have completed the task yesterday.', '["I", "should", "have", "completed", "the", "task", "yesterday."]'::jsonb),
    (activity_id_var, 'She could have reminded me about the deadline', 'She could have reminded me about the deadline.', '["She", "could", "have", "reminded", "me", "about", "the", "deadline."]'::jsonb);

    -- 8. Grammar Sentences #2
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 8, 'Build Sentences 2', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'They should have checked the checklist', 'They should have checked the checklist.', '["They", "should", "have", "checked", "the", "checklist."]'::jsonb),
    (activity_id_var, 'I could have finished earlier', 'I could have finished earlier.', '["I", "could", "have", "finished", "earlier."]'::jsonb);

    -- 9. Speaking Practice
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'speaking_practice', 9, 'Talk About Tasks', 'Practice talking about daily tasks', '{"prompts": ["What do you do after school?", "Who helps you with chores?", "When do you do your homework?", "What should you have done yesterday?", "What tasks are overdue?"]}'::jsonb)
    RETURNING id INTO activity_id_var;

    -- 10. Speaking Improvement
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'speaking_improvement', 10, 'Speaking Improvement', 'Read the improved version of your speech', '{"type": "speaking_improvement", "similarityThreshold": 70}'::jsonb)
    RETURNING id INTO activity_id_var;
END $$;


-- ===== LESSON B2-L58 =====

-- =========================================
-- Pre-fill Database with Sample Lesson Data
-- B2-L58: City life vs small towns
-- =========================================

DELETE FROM grammar_sentences WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'B2-L58');
DELETE FROM vocabulary_items WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'B2-L58');
DELETE FROM lesson_activities WHERE lesson_id = 'B2-L58';
DELETE FROM lessons WHERE id = 'B2-L58';

INSERT INTO lessons (id, level, lesson_number, topic) VALUES
('B2-L58', 'B2', 58, 'City life vs small towns')
ON CONFLICT (id) DO UPDATE SET topic = EXCLUDED.topic;

DO $$
DECLARE
    lesson_id_var TEXT := 'B2-L58';
    activity_id_var UUID;
BEGIN
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'warm_up_speaking', 1, 'Urban vs Rural', 'Talk about living in cities versus small towns', '{"prompt": "If you lived elsewhere, how would focus change now?"}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_intro', 2, 'Lifestyle Comparison Words', 'Learn words for comparing urban and rural life', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'commute', 'เดินทาง', NULL),
    (activity_id_var, 'pace', 'จังหวะ', NULL),
    (activity_id_var, 'noise', 'เสียงดัง', NULL),
    (activity_id_var, 'tight-knit', 'ใกล้ชิด', NULL),
    (activity_id_var, 'amenities', 'สิ่งอำนวยความสะดวก', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_matching_drag', 3, 'Match Lifestyle Words', 'Match words for urban vs rural life', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'commute', 'เดินทาง', NULL),
    (activity_id_var, 'pace', 'จังหวะ', NULL),
    (activity_id_var, 'noise', 'เสียงดัง', NULL),
    (activity_id_var, 'tight-knit', 'ใกล้ชิด', NULL),
    (activity_id_var, 'amenities', 'สิ่งอำนวยความสะดวก', NULL);

    -- 4. Vocabulary Fill Blanks #1
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 4, 'Complete the Sentences 1', 'Fill in the blanks with correct words', '{"text": "I ___ to work. The ___ of life is fast. There is too much ___.", "blanks": [{"id": "blank1", "text": "commute", "options": ["commute", "pace", "noise", "tight-knit"], "correctAnswer": "commute"}, {"id": "blank2", "text": "pace", "options": ["pace", "commute", "noise", "amenities"], "correctAnswer": "pace"}, {"id": "blank3", "text": "noise", "options": ["noise", "commute", "pace", "tight-knit"], "correctAnswer": "noise"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    -- 5. Vocabulary Fill Blanks #2
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 5, 'Complete the Sentences 2', 'Fill in the blanks with correct words', '{"text": "We are a ___ community. The city has many ___. I prefer the ___.", "blanks": [{"id": "blank1", "text": "tight-knit", "options": ["tight-knit", "commute", "pace", "noise"], "correctAnswer": "tight-knit"}, {"id": "blank2", "text": "amenities", "options": ["amenities", "commute", "pace", "tight-knit"], "correctAnswer": "amenities"}, {"id": "blank3", "text": "pace", "options": ["pace", "amenities", "commute", "tight-knit"], "correctAnswer": "pace"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    -- 6. Grammar Explanation
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_explanation', 6, 'Mixed Conditionals', 'Learn conditionals mixing past and present', '{"rules": "Use mixed conditionals to connect past conditions with present results:\n\n- If + past perfect, would + base verb (If I had grown up, I would be)\n- If + past simple, would + base verb (If she moved, her lifestyle would change)\n- Connects past actions/conditions to present/future results\n- Shows how past choices affect current situation\n- Combines third and second conditional patterns", "examples": ["If I had grown up in a small town, I would be more relaxed now.", "If she moved to the city, her lifestyle would change completely.", "If they had chosen rural life, they would have fewer amenities.", "If I had studied harder, I would have better opportunities now.", "If you lived elsewhere, how would your focus change?"]}'::jsonb)
    RETURNING id INTO activity_id_var;

    -- 7. Grammar Sentences #1
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 7, 'Build Sentences 1', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'If I had grown up in a small town I would be more relaxed now', 'If I had grown up in a small town, I would be more relaxed now.', '["If", "I", "had", "grown", "up", "in", "a", "small", "town,", "I", "would", "be", "more", "relaxed", "now."]'::jsonb),
    (activity_id_var, 'If she moved to the city her lifestyle would change completely', 'If she moved to the city, her lifestyle would change completely.', '["If", "she", "moved", "to", "the", "city,", "her", "lifestyle", "would", "change", "completely."]'::jsonb);

    -- 8. Grammar Sentences #2
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 8, 'Build Sentences 2', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'If they had chosen rural life they would have fewer amenities', 'If they had chosen rural life, they would have fewer amenities.', '["If", "they", "had", "chosen", "rural", "life,", "they", "would", "have", "fewer", "amenities."]'::jsonb),
    (activity_id_var, 'If I had studied harder I would have better opportunities now', 'If I had studied harder, I would have better opportunities now.', '["If", "I", "had", "studied", "harder,", "I", "would", "have", "better", "opportunities", "now."]'::jsonb);

    -- 9. Speaking Practice
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'speaking_practice', 9, 'Talk About Cities and Towns', 'Practice talking about where people live', '{"prompts": ["Do you live in a big city?", "Is there a farm near your town?", "What stores are in your neighborhood?", "Would you prefer city or small town life?", "How does where you live affect your lifestyle?"]}'::jsonb)
    RETURNING id INTO activity_id_var;

    -- 10. Speaking Improvement
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'speaking_improvement', 10, 'Speaking Improvement', 'Read the improved version of your speech', '{"type": "speaking_improvement", "similarityThreshold": 70}'::jsonb)
    RETURNING id INTO activity_id_var;
END $$;


-- ===== LESSON B2-L84 =====

-- =========================================
-- Pre-fill Database with Sample Lesson Data
-- B2-L84: Public transport experiences (compare)
-- =========================================

DELETE FROM grammar_sentences WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'B2-L84');
DELETE FROM vocabulary_items WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'B2-L84');
DELETE FROM lesson_activities WHERE lesson_id = 'B2-L84';
DELETE FROM lessons WHERE id = 'B2-L84';

INSERT INTO lessons (id, level, lesson_number, topic) VALUES
('B2-L84', 'B2', 84, 'Public transport experiences (compare)')
ON CONFLICT (id) DO UPDATE SET topic = EXCLUDED.topic;

DO $$
DECLARE
    lesson_id_var TEXT := 'B2-L84';
    activity_id_var UUID;
BEGIN
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'warm_up_speaking', 1, 'Transit Tales', 'Talk about public transportation experiences', '{"prompt": "Although delays happen, what keeps you calm?"}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_intro', 2, 'Transport Experience Words', 'Learn words related to transit experiences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'delay', 'ล่าช้า', NULL),
    (activity_id_var, 'route', 'เส้นทาง', NULL),
    (activity_id_var, 'announcement', 'ประกาศ', NULL),
    (activity_id_var, 'crowd', 'ฝูงชน', NULL),
    (activity_id_var, 'validate', 'ตรวจสอบ', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_matching_drag', 3, 'Match Transport Words', 'Match words related to public transport', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'delay', 'ล่าช้า', NULL),
    (activity_id_var, 'route', 'เส้นทาง', NULL),
    (activity_id_var, 'announcement', 'ประกาศ', NULL),
    (activity_id_var, 'crowd', 'ฝูงชน', NULL),
    (activity_id_var, 'validate', 'ตรวจสอบ', NULL);

    -- 4. Vocabulary Fill Blanks #1
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 4, 'Complete the Sentences 1', 'Fill in the blanks with correct words', '{"text": "There was a ___. I took a different ___. I heard the ___.", "blanks": [{"id": "blank1", "text": "delay", "options": ["delay", "route", "announcement", "crowd"], "correctAnswer": "delay"}, {"id": "blank2", "text": "route", "options": ["route", "delay", "announcement", "validate"], "correctAnswer": "route"}, {"id": "blank3", "text": "announcement", "options": ["announcement", "delay", "route", "crowd"], "correctAnswer": "announcement"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    -- 5. Vocabulary Fill Blanks #2
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 5, 'Complete the Sentences 2', 'Fill in the blanks with correct words', '{"text": "There was a big ___. I need to ___ my ticket. We should ___.", "blanks": [{"id": "blank1", "text": "crowd", "options": ["crowd", "delay", "route", "announcement"], "correctAnswer": "crowd"}, {"id": "blank2", "text": "validate", "options": ["validate", "delay", "route", "crowd"], "correctAnswer": "validate"}, {"id": "blank3", "text": "validate", "options": ["validate", "crowd", "delay", "route"], "correctAnswer": "validate"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    -- 6. Grammar Explanation
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_explanation', 6, 'Contrast with Although/However', 'Learn although/however for contrast', '{"rules": "Use although and however to show contrast:\n\n- Although = at the start of a clause (Although the train was delayed, I arrived)\n- However = between sentences or clauses (The bus was crowded; however, the ride was smooth)\n- But = in the middle of a sentence (It was delayed, but I arrived)\n- All show contrast between two ideas\n- Although and but are similar, but different positions", "examples": ["Although the train was delayed, I arrived on time.", "The bus was crowded; however, the ride was smooth.", "Although announcements were clear, many missed their stop.", "It was late; however, I didn''t mind.", "Although it was busy, the service was good."]}'::jsonb)
    RETURNING id INTO activity_id_var;

    -- 7. Grammar Sentences #1
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 7, 'Build Sentences 1', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'Although the train was delayed I arrived on time', 'Although the train was delayed, I arrived on time.', '["Although", "the", "train", "was", "delayed,", "I", "arrived", "on", "time."]'::jsonb),
    (activity_id_var, 'The bus was crowded however the ride was smooth', 'The bus was crowded; however, the ride was smooth.', '["The", "bus", "was", "crowded;", "however,", "the", "ride", "was", "smooth."]'::jsonb);

    -- 8. Grammar Sentences #2
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 8, 'Build Sentences 2', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'Although announcements were clear many missed their stop', 'Although announcements were clear, many missed their stop.', '["Although", "announcements", "were", "clear,", "many", "missed", "their", "stop."]'::jsonb),
    (activity_id_var, 'It was late however I did not mind', 'It was late; however, I didn''t mind.', '["It", "was", "late;", "however,", "I", "didn''t", "mind."]'::jsonb);

    -- 9. Speaking Practice
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'speaking_practice', 9, 'Talk About Transportation', 'Practice talking about getting around', '{"prompts": ["How do you get to school?", "Do you take the bus to town?", "Who do you sit with on the bus?", "Have you ever experienced a delay?", "How do you handle crowded transport?"]}'::jsonb)
    RETURNING id INTO activity_id_var;

    -- 10. Speaking Improvement
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'speaking_improvement', 10, 'Speaking Improvement', 'Read the improved version of your speech', '{"type": "speaking_improvement", "similarityThreshold": 70}'::jsonb)
    RETURNING id INTO activity_id_var;
END $$;


-- ===== LESSON B2-L59 =====

-- =========================================
-- Pre-fill Database with Sample Lesson Data
-- B2-L59: Learning styles (switching)
-- =========================================

DELETE FROM grammar_sentences WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'B2-L59');
DELETE FROM vocabulary_items WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'B2-L59');
DELETE FROM lesson_activities WHERE lesson_id = 'B2-L59';
DELETE FROM lessons WHERE id = 'B2-L59';

INSERT INTO lessons (id, level, lesson_number, topic) VALUES
('B2-L59', 'B2', 59, 'Learning styles (switching)')
ON CONFLICT (id) DO UPDATE SET topic = EXCLUDED.topic;

DO $$
DECLARE
    lesson_id_var TEXT := 'B2-L59';
    activity_id_var UUID;
BEGIN
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'warm_up_speaking', 1, 'Learning Styles', 'Talk about how you study best', '{"prompt": "Do you prefer reading or watching videos?"}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_intro', 2, 'Learning Style Words', 'Learn words related to different learning approaches', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'visual', 'ภาพ', NULL),
    (activity_id_var, 'auditory', 'เสียง', NULL),
    (activity_id_var, 'kinesthetic', 'การเคลื่อนไหว', NULL),
    (activity_id_var, 'adapt', 'ปรับตัว', NULL),
    (activity_id_var, 'mismatch', 'ไม่ตรงกัน', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_matching_drag', 3, 'Match Learning Style Words', 'Match words related to learning methods', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'visual', 'ภาพ', NULL),
    (activity_id_var, 'auditory', 'เสียง', NULL),
    (activity_id_var, 'kinesthetic', 'การเคลื่อนไหว', NULL),
    (activity_id_var, 'adapt', 'ปรับตัว', NULL),
    (activity_id_var, 'mismatch', 'ไม่ตรงกัน', NULL);

    -- 4. Vocabulary Fill Blanks #1
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 4, 'Complete the Sentences 1', 'Fill in the blanks with correct words', '{"text": "I am a ___ learner. I prefer ___ learning. I need ___ activities.", "blanks": [{"id": "blank1", "text": "visual", "options": ["visual", "auditory", "kinesthetic", "adapt"], "correctAnswer": "visual"}, {"id": "blank2", "text": "auditory", "options": ["auditory", "visual", "kinesthetic", "mismatch"], "correctAnswer": "auditory"}, {"id": "blank3", "text": "kinesthetic", "options": ["kinesthetic", "visual", "auditory", "adapt"], "correctAnswer": "kinesthetic"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    -- 5. Vocabulary Fill Blanks #2
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 5, 'Complete the Sentences 2', 'Fill in the blanks with correct words', '{"text": "I need to ___ to new methods. There is a ___. We must ___.", "blanks": [{"id": "blank1", "text": "adapt", "options": ["adapt", "visual", "auditory", "mismatch"], "correctAnswer": "adapt"}, {"id": "blank2", "text": "mismatch", "options": ["mismatch", "visual", "auditory", "adapt"], "correctAnswer": "mismatch"}, {"id": "blank3", "text": "adapt", "options": ["adapt", "mismatch", "visual", "auditory"], "correctAnswer": "adapt"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    -- 6. Grammar Explanation
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_explanation', 6, 'Reason and Result (so/such...that)', 'Learn so/such...that for cause and effect', '{"rules": "Use so/such...that to show cause and effect:\n\n- So + adjective/adverb + that (so effective that)\n- Such + (a/an) + adjective + noun + that (such good memory that)\n- Shows strong cause and effect relationship\n- So is used with adjectives/adverbs\n- Such is used with nouns\n- That introduces the result clause", "examples": ["The method was so effective that I improved quickly.", "She has such good memory that she learns fast.", "The style was so different that it changed my approach.", "It was such a good method that everyone improved.", "I was so focused that I finished early."]}'::jsonb)
    RETURNING id INTO activity_id_var;

    -- 7. Grammar Sentences #1
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 7, 'Build Sentences 1', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'The method was so effective that I improved quickly', 'The method was so effective that I improved quickly.', '["The", "method", "was", "so", "effective", "that", "I", "improved", "quickly."]'::jsonb),
    (activity_id_var, 'She has such good memory that she learns fast', 'She has such good memory that she learns fast.', '["She", "has", "such", "good", "memory", "that", "she", "learns", "fast."]'::jsonb);

    -- 8. Grammar Sentences #2
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 8, 'Build Sentences 2', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'The style was so different that it changed my approach', 'The style was so different that it changed my approach.', '["The", "style", "was", "so", "different", "that", "it", "changed", "my", "approach."]'::jsonb),
    (activity_id_var, 'It was such a good method that everyone improved', 'It was such a good method that everyone improved.', '["It", "was", "such", "a", "good", "method", "that", "everyone", "improved."]'::jsonb);

    -- 9. Speaking Practice
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'speaking_practice', 9, 'Discuss Study Habits', 'Practice talking about how you learn', '{"prompts": ["How do you study best?", "When do you change your study method?", "Who helps you learn?", "What learning style works for you?", "How do you adapt to different teaching methods?"]}'::jsonb)
    RETURNING id INTO activity_id_var;

    -- 10. Speaking Improvement
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'speaking_improvement', 10, 'Speaking Improvement', 'Read the improved version of your speech', '{"type": "speaking_improvement", "similarityThreshold": 70}'::jsonb)
    RETURNING id INTO activity_id_var;
END $$;


-- ===== LESSON B2-L60 =====

-- =========================================
-- Pre-fill Database with Sample Lesson Data
-- B2-L60: Personal responsibility
-- =========================================

DELETE FROM grammar_sentences WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'B2-L60');
DELETE FROM vocabulary_items WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'B2-L60');
DELETE FROM lesson_activities WHERE lesson_id = 'B2-L60';
DELETE FROM lessons WHERE id = 'B2-L60';

INSERT INTO lessons (id, level, lesson_number, topic) VALUES
('B2-L60', 'B2', 60, 'Personal responsibility')
ON CONFLICT (id) DO UPDATE SET topic = EXCLUDED.topic;

DO $$
DECLARE
    lesson_id_var TEXT := 'B2-L60';
    activity_id_var UUID;
BEGIN
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'warm_up_speaking', 1, 'Personal Responsibility', 'Talk about being responsible', '{"prompt": "What tasks do you do at home?"}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_intro', 2, 'Responsibility Words', 'Learn words related to personal accountability', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'accountable', 'รับผิดชอบ', NULL),
    (activity_id_var, 'duty', 'หน้าที่', NULL),
    (activity_id_var, 'consequence', 'ผลที่ตามมา', NULL),
    (activity_id_var, 'uphold', 'รักษา', NULL),
    (activity_id_var, 'neglect', 'ละเลย', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_matching_drag', 3, 'Match Responsibility Words', 'Match words related to accountability', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'accountable', 'รับผิดชอบ', NULL),
    (activity_id_var, 'duty', 'หน้าที่', NULL),
    (activity_id_var, 'consequence', 'ผลที่ตามมา', NULL),
    (activity_id_var, 'uphold', 'รักษา', NULL),
    (activity_id_var, 'neglect', 'ละเลย', NULL);

    -- 4. Vocabulary Fill Blanks #1
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 4, 'Complete the Sentences 1', 'Fill in the blanks with correct words', '{"text": "I am ___ for my actions. It is my ___. There are ___.", "blanks": [{"id": "blank1", "text": "accountable", "options": ["accountable", "duty", "consequence", "uphold"], "correctAnswer": "accountable"}, {"id": "blank2", "text": "duty", "options": ["duty", "accountable", "consequence", "neglect"], "correctAnswer": "duty"}, {"id": "blank3", "text": "consequences", "options": ["consequences", "accountable", "duty", "uphold"], "correctAnswer": "consequences"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    -- 5. Vocabulary Fill Blanks #2
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 5, 'Complete the Sentences 2', 'Fill in the blanks with correct words', '{"text": "We must ___ our standards. Do not ___ your duties. I will ___ my responsibilities.", "blanks": [{"id": "blank1", "text": "uphold", "options": ["uphold", "accountable", "duty", "neglect"], "correctAnswer": "uphold"}, {"id": "blank2", "text": "neglect", "options": ["neglect", "accountable", "duty", "uphold"], "correctAnswer": "neglect"}, {"id": "blank3", "text": "uphold", "options": ["uphold", "neglect", "accountable", "duty"], "correctAnswer": "uphold"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    -- 6. Grammar Explanation
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_explanation', 6, 'Passive with Modals', 'Learn passive voice with modal verbs', '{"rules": "Use passive voice with modal verbs to show obligation or possibility:\n\n- Form: modal + be + past participle (must be made, should be shared)\n- Use when the action is more important than who does it\n- Modal + be + past participle (must be, should be, can be)\n- Use by to show who does the action (by you, by everyone)\n- Common modals: must, should, can, might, could", "examples": ["The decision must be made by you.", "Responsibilities should be shared equally.", "Standards must be upheld by everyone.", "Tasks can be completed together.", "Rules should be followed by all."]}'::jsonb)
    RETURNING id INTO activity_id_var;

    -- 7. Grammar Sentences #1
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 7, 'Build Sentences 1', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'The decision must be made by you', 'The decision must be made by you.', '["The", "decision", "must", "be", "made", "by", "you."]'::jsonb),
    (activity_id_var, 'Responsibilities should be shared equally', 'Responsibilities should be shared equally.', '["Responsibilities", "should", "be", "shared", "equally."]'::jsonb);

    -- 8. Grammar Sentences #2
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 8, 'Build Sentences 2', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'Standards must be upheld by everyone', 'Standards must be upheld by everyone.', '["Standards", "must", "be", "upheld", "by", "everyone."]'::jsonb),
    (activity_id_var, 'Tasks can be completed together', 'Tasks can be completed together.', '["Tasks", "can", "be", "completed", "together."]'::jsonb);

    -- 9. Speaking Practice
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'speaking_practice', 9, 'Talk About Responsibility', 'Practice talking about being responsible', '{"prompts": ["What chores do you do?", "Who helps with family tasks?", "How do you help others?", "What are your duties at home?", "How do you uphold your responsibilities?"]}'::jsonb)
    RETURNING id INTO activity_id_var;

    -- 10. Speaking Improvement
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'speaking_improvement', 10, 'Speaking Improvement', 'Read the improved version of your speech', '{"type": "speaking_improvement", "similarityThreshold": 70}'::jsonb)
    RETURNING id INTO activity_id_var;
END $$;


-- ===== LESSON B2-L85 =====

-- =========================================
-- Pre-fill Database with Sample Lesson Data
-- B2-L85: Freedom of expression (limits)
-- =========================================

DELETE FROM grammar_sentences WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'B2-L85');
DELETE FROM vocabulary_items WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'B2-L85');
DELETE FROM lesson_activities WHERE lesson_id = 'B2-L85';
DELETE FROM lessons WHERE id = 'B2-L85';

INSERT INTO lessons (id, level, lesson_number, topic) VALUES
('B2-L85', 'B2', 85, 'Freedom of expression (limits)')
ON CONFLICT (id) DO UPDATE SET topic = EXCLUDED.topic;

DO $$
DECLARE
    lesson_id_var TEXT := 'B2-L85';
    activity_id_var UUID;
BEGIN
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'warm_up_speaking', 1, 'Expression Boundaries', 'Talk about limits to free speech', '{"prompt": "What rule is so important you defend it?"}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_intro', 2, 'Expression Words', 'Learn words related to freedom of expression', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'express', 'แสดงออก', NULL),
    (activity_id_var, 'censor', 'ตรวจสอบเนื้อหา', NULL),
    (activity_id_var, 'nuance', 'ความแตกต่างเล็กน้อย', NULL),
    (activity_id_var, 'offend', 'ทำให้ขุ่นเคือง', NULL),
    (activity_id_var, 'debate', 'อภิปราย', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_matching_drag', 3, 'Match Expression Words', 'Match words related to free speech', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'express', 'แสดงออก', NULL),
    (activity_id_var, 'censor', 'ตรวจสอบเนื้อหา', NULL),
    (activity_id_var, 'nuance', 'ความแตกต่างเล็กน้อย', NULL),
    (activity_id_var, 'offend', 'ทำให้ขุ่นเคือง', NULL),
    (activity_id_var, 'debate', 'อภิปราย', NULL);

    -- 4. Vocabulary Fill Blanks #1
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 4, 'Complete the Sentences 1', 'Fill in the blanks with correct words', '{"text": "I want to ___ my opinion. They may ___ content. There is a ___.", "blanks": [{"id": "blank1", "text": "express", "options": ["express", "censor", "nuance", "offend"], "correctAnswer": "express"}, {"id": "blank2", "text": "censor", "options": ["censor", "express", "nuance", "debate"], "correctAnswer": "censor"}, {"id": "blank3", "text": "nuance", "options": ["nuance", "express", "censor", "offend"], "correctAnswer": "nuance"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    -- 5. Vocabulary Fill Blanks #2
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 5, 'Complete the Sentences 2', 'Fill in the blanks with correct words', '{"text": "I don''t want to ___ anyone. We need to ___. They ___.", "blanks": [{"id": "blank1", "text": "offend", "options": ["offend", "express", "censor", "nuance"], "correctAnswer": "offend"}, {"id": "blank2", "text": "debate", "options": ["debate", "express", "censor", "offend"], "correctAnswer": "debate"}, {"id": "blank3", "text": "debate", "options": ["debate", "offend", "express", "censor"], "correctAnswer": "debate"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    -- 6. Grammar Explanation
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_explanation', 6, 'Reason and Result (so/such...that)', 'Learn so/such...that for cause and effect', '{"rules": "Use so/such...that to show cause and effect:\n\n- So + adjective/adverb + that (so strict that)\n- Such + (a/an) + adjective + noun + that (such a powerful tool that)\n- Shows strong cause and effect relationship\n- So is used with adjectives/adverbs\n- Such is used with nouns\n- That introduces the result clause", "examples": ["The law is so strict that it limits expression.", "Words can be such a powerful tool that they change opinions.", "The debate was so heated that people stopped listening.", "It was such a strong argument that everyone agreed.", "I was so careful that I didn''t offend anyone."]}'::jsonb)
    RETURNING id INTO activity_id_var;

    -- 7. Grammar Sentences #1
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 7, 'Build Sentences 1', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'The law is so strict that it limits expression', 'The law is so strict that it limits expression.', '["The", "law", "is", "so", "strict", "that", "it", "limits", "expression."]'::jsonb),
    (activity_id_var, 'Words can be such a powerful tool that they change opinions', 'Words can be such a powerful tool that they change opinions.', '["Words", "can", "be", "such", "a", "powerful", "tool", "that", "they", "change", "opinions."]'::jsonb);

    -- 8. Grammar Sentences #2
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 8, 'Build Sentences 2', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'The debate was so heated that people stopped listening', 'The debate was so heated that people stopped listening.', '["The", "debate", "was", "so", "heated", "that", "people", "stopped", "listening."]'::jsonb),
    (activity_id_var, 'It was such a strong argument that everyone agreed', 'It was such a strong argument that everyone agreed.', '["It", "was", "such", "a", "strong", "argument", "that", "everyone", "agreed."]'::jsonb);

    -- 9. Speaking Practice
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'speaking_practice', 9, 'Talk About Communication', 'Practice talking about talking to people', '{"prompts": ["Do you talk to strangers?", "What do you say when you meet someone?", "How do you say goodbye?", "How do you express your opinions?", "What topics do you debate about?"]}'::jsonb)
    RETURNING id INTO activity_id_var;

    -- 10. Speaking Improvement
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'speaking_improvement', 10, 'Speaking Improvement', 'Read the improved version of your speech', '{"type": "speaking_improvement", "similarityThreshold": 70}'::jsonb)
    RETURNING id INTO activity_id_var;
END $$;


-- ===== LESSON B2-L86 =====

-- =========================================
-- Pre-fill Database with Sample Lesson Data
-- B2-L86: Technology dependence
-- =========================================

DELETE FROM grammar_sentences WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'B2-L86');
DELETE FROM vocabulary_items WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'B2-L86');
DELETE FROM lesson_activities WHERE lesson_id = 'B2-L86';
DELETE FROM lessons WHERE id = 'B2-L86';

INSERT INTO lessons (id, level, lesson_number, topic) VALUES
('B2-L86', 'B2', 86, 'Technology dependence')
ON CONFLICT (id) DO UPDATE SET topic = EXCLUDED.topic;

DO $$
DECLARE
    lesson_id_var TEXT := 'B2-L86';
    activity_id_var UUID;
BEGIN
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'warm_up_speaking', 1, 'Digital Reliance', 'Talk about dependence on technology', '{"prompt": "If you unplugged earlier, how would today feel?"}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_intro', 2, 'Tech Dependence Words', 'Learn words related to technology reliance', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'notification', 'การแจ้งเตือน', NULL),
    (activity_id_var, 'screen', 'หน้าจอ', NULL),
    (activity_id_var, 'focus', 'โฟกัส', NULL),
    (activity_id_var, 'limit', 'จำกัด', NULL),
    (activity_id_var, 'detox', 'ล้างพิษ', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_matching_drag', 3, 'Match Tech Dependence Words', 'Match words related to digital reliance', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'notification', 'การแจ้งเตือน', NULL),
    (activity_id_var, 'screen', 'หน้าจอ', NULL),
    (activity_id_var, 'focus', 'โฟกัส', NULL),
    (activity_id_var, 'limit', 'จำกัด', NULL),
    (activity_id_var, 'detox', 'ล้างพิษ', NULL);

    -- 4. Vocabulary Fill Blanks #1
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 4, 'Complete the Sentences 1', 'Fill in the blanks with correct words', '{"text": "I got a ___. I look at my ___. I lose ___.", "blanks": [{"id": "blank1", "text": "notification", "options": ["notification", "screen", "focus", "limit"], "correctAnswer": "notification"}, {"id": "blank2", "text": "screen", "options": ["screen", "notification", "focus", "detox"], "correctAnswer": "screen"}, {"id": "blank3", "text": "focus", "options": ["focus", "notification", "screen", "limit"], "correctAnswer": "focus"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    -- 5. Vocabulary Fill Blanks #2
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 5, 'Complete the Sentences 2', 'Fill in the blanks with correct words', '{"text": "I need to ___ my use. I should do a ___. We must ___.", "blanks": [{"id": "blank1", "text": "limit", "options": ["limit", "notification", "screen", "focus"], "correctAnswer": "limit"}, {"id": "blank2", "text": "detox", "options": ["detox", "limit", "screen", "focus"], "correctAnswer": "detox"}, {"id": "blank3", "text": "limit", "options": ["limit", "detox", "screen", "focus"], "correctAnswer": "limit"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    -- 6. Grammar Explanation
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_explanation', 6, 'Mixed Conditionals', 'Learn conditionals mixing past and present', '{"rules": "Use mixed conditionals to connect past conditions with present results:\n\n- If + past perfect, would + base verb (If I had set limits, I would be)\n- If + past simple, would + base verb (If she unplugged, her focus would improve)\n- Connects past actions/conditions to present/future results\n- Shows how past choices affect current situation\n- Combines third and second conditional patterns", "examples": ["If I had set limits earlier, I would be less dependent now.", "If she unplugged completely, her focus would improve immediately.", "If they had digital detoxes, they would sleep better.", "If I had started earlier, I would have better habits now.", "If you unplugged earlier, how would today feel?"]}'::jsonb)
    RETURNING id INTO activity_id_var;

    -- 7. Grammar Sentences #1
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 7, 'Build Sentences 1', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'If I had set limits earlier I would be less dependent now', 'If I had set limits earlier, I would be less dependent now.', '["If", "I", "had", "set", "limits", "earlier,", "I", "would", "be", "less", "dependent", "now."]'::jsonb),
    (activity_id_var, 'If she unplugged completely her focus would improve immediately', 'If she unplugged completely, her focus would improve immediately.', '["If", "she", "unplugged", "completely,", "her", "focus", "would", "improve", "immediately."]'::jsonb);

    -- 8. Grammar Sentences #2
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 8, 'Build Sentences 2', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'If they had digital detoxes they would sleep better', 'If they had digital detoxes, they would sleep better.', '["If", "they", "had", "digital", "detoxes,", "they", "would", "sleep", "better."]'::jsonb),
    (activity_id_var, 'If I had started earlier I would have better habits now', 'If I had started earlier, I would have better habits now.', '["If", "I", "had", "started", "earlier,", "I", "would", "have", "better", "habits", "now."]'::jsonb);

    -- 9. Speaking Practice
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'speaking_practice', 9, 'Talk About Technology', 'Practice talking about digital habits', '{"prompts": ["When do you put your phone away?", "What do you do without your phone?", "Who calls you on the phone?", "How do you limit your screen time?", "Have you ever done a digital detox?"]}'::jsonb)
    RETURNING id INTO activity_id_var;

    -- 10. Speaking Improvement
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'speaking_improvement', 10, 'Speaking Improvement', 'Read the improved version of your speech', '{"type": "speaking_improvement", "similarityThreshold": 70}'::jsonb)
    RETURNING id INTO activity_id_var;
END $$;


-- ===== LESSON B2-L87 =====

-- =========================================
-- Pre-fill Database with Sample Lesson Data
-- B2-L87: Cultural identity
-- =========================================

DELETE FROM grammar_sentences WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'B2-L87');
DELETE FROM vocabulary_items WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'B2-L87');
DELETE FROM lesson_activities WHERE lesson_id = 'B2-L87';
DELETE FROM lessons WHERE id = 'B2-L87';

INSERT INTO lessons (id, level, lesson_number, topic) VALUES
('B2-L87', 'B2', 87, 'Cultural identity')
ON CONFLICT (id) DO UPDATE SET topic = EXCLUDED.topic;

DO $$
DECLARE
    lesson_id_var TEXT := 'B2-L87';
    activity_id_var UUID;
BEGIN
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'warm_up_speaking', 1, 'Identity Exploration', 'Talk about cultural background and identity', '{"prompt": "When do you rarely feel understood?"}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_intro', 2, 'Identity Words', 'Learn words related to cultural identity', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'heritage', 'มรดก', NULL),
    (activity_id_var, 'adapt', 'ปรับตัว', NULL),
    (activity_id_var, 'stereotype', 'ภาพเหมารวม', NULL),
    (activity_id_var, 'pride', 'ความภาคภูมิใจ', NULL),
    (activity_id_var, 'blend', 'ผสมผสาน', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_matching_drag', 3, 'Match Identity Words', 'Match words related to cultural identity', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'heritage', 'มรดก', NULL),
    (activity_id_var, 'adapt', 'ปรับตัว', NULL),
    (activity_id_var, 'stereotype', 'ภาพเหมารวม', NULL),
    (activity_id_var, 'pride', 'ความภาคภูมิใจ', NULL),
    (activity_id_var, 'blend', 'ผสมผสาน', NULL);

    -- 4. Vocabulary Fill Blanks #1
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 4, 'Complete the Sentences 1', 'Fill in the blanks with correct words', '{"text": "I value my ___. I need to ___. I don''t like ___.", "blanks": [{"id": "blank1", "text": "heritage", "options": ["heritage", "adapt", "stereotype", "pride"], "correctAnswer": "heritage"}, {"id": "blank2", "text": "adapt", "options": ["adapt", "heritage", "stereotype", "blend"], "correctAnswer": "adapt"}, {"id": "blank3", "text": "stereotypes", "options": ["stereotypes", "heritage", "adapt", "pride"], "correctAnswer": "stereotypes"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    -- 5. Vocabulary Fill Blanks #2
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 5, 'Complete the Sentences 2', 'Fill in the blanks with correct words', '{"text": "I feel ___. We need to ___. They ___.", "blanks": [{"id": "blank1", "text": "pride", "options": ["pride", "heritage", "adapt", "stereotype"], "correctAnswer": "pride"}, {"id": "blank2", "text": "blend", "options": ["blend", "heritage", "adapt", "pride"], "correctAnswer": "blend"}, {"id": "blank3", "text": "blend", "options": ["blend", "pride", "heritage", "adapt"], "correctAnswer": "blend"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    -- 6. Grammar Explanation
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_explanation', 6, 'Inversion with Negative Adverbials', 'Learn inversion with rarely/seldom/hardly', '{"rules": "Use inversion with negative adverbials for emphasis:\n\n- Rarely/Seldom/Hardly ever + auxiliary + subject + verb\n- Rarely do I feel (not I rarely feel)\n- Seldom have I questioned (not I seldom have questioned)\n- Hardly ever do stereotypes apply (not Stereotypes hardly ever apply)\n- Inversion makes the statement more formal and emphatic\n- Use do/does/did for present/past simple, have/has for present perfect", "examples": ["Rarely do I feel misunderstood in my culture.", "Seldom have I questioned my heritage.", "Hardly ever do stereotypes apply to me.", "Rarely have I felt so proud.", "Seldom do I see such understanding."]}'::jsonb)
    RETURNING id INTO activity_id_var;

    -- 7. Grammar Sentences #1
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 7, 'Build Sentences 1', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'Rarely do I feel misunderstood in my culture', 'Rarely do I feel misunderstood in my culture.', '["Rarely", "do", "I", "feel", "misunderstood", "in", "my", "culture."]'::jsonb),
    (activity_id_var, 'Seldom have I questioned my heritage', 'Seldom have I questioned my heritage.', '["Seldom", "have", "I", "questioned", "my", "heritage."]'::jsonb);

    -- 8. Grammar Sentences #2
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 8, 'Build Sentences 2', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'Hardly ever do stereotypes apply to me', 'Hardly ever do stereotypes apply to me.', '["Hardly", "ever", "do", "stereotypes", "apply", "to", "me."]'::jsonb),
    (activity_id_var, 'Rarely have I felt so proud', 'Rarely have I felt so proud.', '["Rarely", "have", "I", "felt", "so", "proud."]'::jsonb);

    -- 9. Speaking Practice
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'speaking_practice', 9, 'Discuss Cultural Identity', 'Practice talking about cultural background', '{"prompts": ["When do you rarely feel understood?", "How do you explain your identity?", "What do you keep?", "How do you adapt to new cultures?", "What makes you proud of your heritage?"]}'::jsonb)
    RETURNING id INTO activity_id_var;

    -- 10. Speaking Improvement
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'speaking_improvement', 10, 'Speaking Improvement', 'Read the improved version of your speech', '{"type": "speaking_improvement", "similarityThreshold": 70}'::jsonb)
    RETURNING id INTO activity_id_var;
END $$;


-- ===== LESSON B2-L88 =====

-- =========================================
-- Pre-fill Database with Sample Lesson Data
-- B2-L88: Education and personal growth
-- =========================================

DELETE FROM grammar_sentences WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'B2-L88');
DELETE FROM vocabulary_items WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'B2-L88');
DELETE FROM lesson_activities WHERE lesson_id = 'B2-L88';
DELETE FROM lessons WHERE id = 'B2-L88';

INSERT INTO lessons (id, level, lesson_number, topic) VALUES
('B2-L88', 'B2', 88, 'Education and personal growth')
ON CONFLICT (id) DO UPDATE SET topic = EXCLUDED.topic;

DO $$
DECLARE
    lesson_id_var TEXT := 'B2-L88';
    activity_id_var UUID;
BEGIN
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'warm_up_speaking', 1, 'Growth Through Learning', 'Talk about how education changes us', '{"prompt": "What had you learned before you grew fastest?"}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_intro', 2, 'Growth Words', 'Learn words related to personal development', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'milestone', 'จุดสำคัญ', NULL),
    (activity_id_var, 'mentor', 'ที่ปรึกษา', NULL),
    (activity_id_var, 'feedback', 'ความคิดเห็น', NULL),
    (activity_id_var, 'reflect', 'สะท้อน', NULL),
    (activity_id_var, 'progress', 'ความก้าวหน้า', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_matching_drag', 3, 'Match Growth Words', 'Match words related to personal development', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'milestone', 'จุดสำคัญ', NULL),
    (activity_id_var, 'mentor', 'ที่ปรึกษา', NULL),
    (activity_id_var, 'feedback', 'ความคิดเห็น', NULL),
    (activity_id_var, 'reflect', 'สะท้อน', NULL),
    (activity_id_var, 'progress', 'ความก้าวหน้า', NULL);

    -- 4. Vocabulary Fill Blanks #1
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 4, 'Complete the Sentences 1', 'Fill in the blanks with correct words', '{"text": "I reached a ___. I have a ___. I got ___.", "blanks": [{"id": "blank1", "text": "milestone", "options": ["milestone", "mentor", "feedback", "reflect"], "correctAnswer": "milestone"}, {"id": "blank2", "text": "mentor", "options": ["mentor", "milestone", "feedback", "progress"], "correctAnswer": "mentor"}, {"id": "blank3", "text": "feedback", "options": ["feedback", "milestone", "mentor", "reflect"], "correctAnswer": "feedback"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    -- 5. Vocabulary Fill Blanks #2
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 5, 'Complete the Sentences 2', 'Fill in the blanks with correct words', '{"text": "I need to ___ on this. I see my ___. We make ___.", "blanks": [{"id": "blank1", "text": "reflect", "options": ["reflect", "milestone", "mentor", "feedback"], "correctAnswer": "reflect"}, {"id": "blank2", "text": "progress", "options": ["progress", "milestone", "mentor", "reflect"], "correctAnswer": "progress"}, {"id": "blank3", "text": "progress", "options": ["progress", "reflect", "milestone", "mentor"], "correctAnswer": "progress"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    -- 6. Grammar Explanation
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_explanation', 6, 'Past Perfect', 'Learn past perfect for completed actions before other past actions', '{"rules": "Use past perfect to show an action completed before another past action:\n\n- Form: had + past participle (had studied, had reflected)\n- Use when one past action happened before another\n- Often used with before/after/when\n- Shows the sequence of past events\n- The earlier action uses past perfect, the later uses past simple", "examples": ["I had studied for years before I got my degree.", "She had reflected on her experiences before making changes.", "They had received feedback before improving their skills.", "I had learned a lot before I started teaching.", "She had practiced before she succeeded."]}'::jsonb)
    RETURNING id INTO activity_id_var;

    -- 7. Grammar Sentences #1
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 7, 'Build Sentences 1', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'I had studied for years before I got my degree', 'I had studied for years before I got my degree.', '["I", "had", "studied", "for", "years", "before", "I", "got", "my", "degree."]'::jsonb),
    (activity_id_var, 'She had reflected on her experiences before making changes', 'She had reflected on her experiences before making changes.', '["She", "had", "reflected", "on", "her", "experiences", "before", "making", "changes."]'::jsonb);

    -- 8. Grammar Sentences #2
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 8, 'Build Sentences 2', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'They had received feedback before improving their skills', 'They had received feedback before improving their skills.', '["They", "had", "received", "feedback", "before", "improving", "their", "skills."]'::jsonb),
    (activity_id_var, 'I had learned a lot before I started teaching', 'I had learned a lot before I started teaching.', '["I", "had", "learned", "a", "lot", "before", "I", "started", "teaching."]'::jsonb);

    -- 9. Speaking Practice
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'speaking_practice', 9, 'Share Growth Stories', 'Practice talking about educational development', '{"prompts": ["What had you learned before you grew fastest?", "Who guided you?", "What changed?", "What milestones have you reached?", "How do you reflect on your progress?"]}'::jsonb)
    RETURNING id INTO activity_id_var;

    -- 10. Speaking Improvement
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'speaking_improvement', 10, 'Speaking Improvement', 'Read the improved version of your speech', '{"type": "speaking_improvement", "similarityThreshold": 70}'::jsonb)
    RETURNING id INTO activity_id_var;
END $$;


-- ===== LESSON B2-L89 =====

-- =========================================
-- Pre-fill Database with Sample Lesson Data
-- B2-L89: Ambition and motivation
-- =========================================

DELETE FROM grammar_sentences WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'B2-L89');
DELETE FROM vocabulary_items WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'B2-L89');
DELETE FROM lesson_activities WHERE lesson_id = 'B2-L89';
DELETE FROM lessons WHERE id = 'B2-L89';

INSERT INTO lessons (id, level, lesson_number, topic) VALUES
('B2-L89', 'B2', 89, 'Ambition and motivation')
ON CONFLICT (id) DO UPDATE SET topic = EXCLUDED.topic;

DO $$
DECLARE
    lesson_id_var TEXT := 'B2-L89';
    activity_id_var UUID;
BEGIN
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'warm_up_speaking', 1, 'Goals and Motivation', 'Talk about your goals', '{"prompt": "What do you want to achieve this year?"}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_intro', 2, 'Motivation Words', 'Learn words related to ambition and drive', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'drive', 'แรงผลักดัน', NULL),
    (activity_id_var, 'plateau', 'ที่ราบสูง', NULL),
    (activity_id_var, 'spark', 'ประกายไฟ', NULL),
    (activity_id_var, 'momentum', 'แรงผลักดัน', NULL),
    (activity_id_var, 'setback', 'ความล้มเหลว', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_matching_drag', 3, 'Match Motivation Words', 'Match words related to ambition', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'drive', 'แรงผลักดัน', NULL),
    (activity_id_var, 'plateau', 'ที่ราบสูง', NULL),
    (activity_id_var, 'spark', 'ประกายไฟ', NULL),
    (activity_id_var, 'momentum', 'แรงผลักดัน', NULL),
    (activity_id_var, 'setback', 'ความล้มเหลว', NULL);

    -- 4. Vocabulary Fill Blanks #1
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 4, 'Complete the Sentences 1', 'Fill in the blanks with correct words', '{"text": "I have the ___. I hit a ___. I need a ___.", "blanks": [{"id": "blank1", "text": "drive", "options": ["drive", "plateau", "spark", "momentum"], "correctAnswer": "drive"}, {"id": "blank2", "text": "plateau", "options": ["plateau", "drive", "spark", "setback"], "correctAnswer": "plateau"}, {"id": "blank3", "text": "spark", "options": ["spark", "drive", "plateau", "momentum"], "correctAnswer": "spark"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    -- 5. Vocabulary Fill Blanks #2
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 5, 'Complete the Sentences 2', 'Fill in the blanks with correct words', '{"text": "I have ___. I faced a ___. We need ___.", "blanks": [{"id": "blank1", "text": "momentum", "options": ["momentum", "drive", "plateau", "spark"], "correctAnswer": "momentum"}, {"id": "blank2", "text": "setback", "options": ["setback", "drive", "plateau", "momentum"], "correctAnswer": "setback"}, {"id": "blank3", "text": "momentum", "options": ["momentum", "setback", "drive", "plateau"], "correctAnswer": "momentum"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    -- 6. Grammar Explanation
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_explanation', 6, 'Passive with Modals', 'Learn passive voice with modal verbs', '{"rules": "Use passive voice with modal verbs to show obligation or possibility:\n\n- Form: modal + be + past participle (should be pursued, must be set)\n- Use when the action is more important than who does it\n- Modal + be + past participle (should be, must be, can be)\n- Use by to show who does the action (by success, by you)\n- Common modals: must, should, can, might, could", "examples": ["Ambitions should be pursued with passion.", "Goals must be set realistically.", "Motivation can be sparked by success.", "Dreams should be followed.", "Challenges can be overcome with effort."]}'::jsonb)
    RETURNING id INTO activity_id_var;

    -- 7. Grammar Sentences #1
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 7, 'Build Sentences 1', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'Ambitions should be pursued with passion', 'Ambitions should be pursued with passion.', '["Ambitions", "should", "be", "pursued", "with", "passion."]'::jsonb),
    (activity_id_var, 'Goals must be set realistically', 'Goals must be set realistically.', '["Goals", "must", "be", "set", "realistically."]'::jsonb);

    -- 8. Grammar Sentences #2
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 8, 'Build Sentences 2', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'Motivation can be sparked by success', 'Motivation can be sparked by success.', '["Motivation", "can", "be", "sparked", "by", "success."]'::jsonb),
    (activity_id_var, 'Dreams should be followed', 'Dreams should be followed.', '["Dreams", "should", "be", "followed."]'::jsonb);

    -- 9. Speaking Practice
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'speaking_practice', 9, 'Talk About Goals', 'Practice talking about ambitions', '{"prompts": ["What job do you want in the future?", "How do you stay motivated?", "Who encourages you?", "What drives you to succeed?", "How do you handle setbacks?"]}'::jsonb)
    RETURNING id INTO activity_id_var;

    -- 10. Speaking Improvement
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'speaking_improvement', 10, 'Speaking Improvement', 'Read the improved version of your speech', '{"type": "speaking_improvement", "similarityThreshold": 70}'::jsonb)
    RETURNING id INTO activity_id_var;
END $$;


-- ===== LESSON B2-L90 =====

-- =========================================
-- Pre-fill Database with Sample Lesson Data
-- B2-L90: Planning for adulthood
-- =========================================

DELETE FROM grammar_sentences WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'B2-L90');
DELETE FROM vocabulary_items WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'B2-L90');
DELETE FROM lesson_activities WHERE lesson_id = 'B2-L90';
DELETE FROM lessons WHERE id = 'B2-L90';

INSERT INTO lessons (id, level, lesson_number, topic) VALUES
('B2-L90', 'B2', 90, 'Planning for adulthood')
ON CONFLICT (id) DO UPDATE SET topic = EXCLUDED.topic;

DO $$
DECLARE
    lesson_id_var TEXT := 'B2-L90';
    activity_id_var UUID;
BEGIN
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'warm_up_speaking', 1, 'Future Planning', 'Talk about preparing for adult responsibilities', '{"prompt": "If you shifted plans now, what would future you gain?"}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_intro', 2, 'Adulthood Words', 'Learn words related to adult planning', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'milestone', 'จุดสำคัญ', NULL),
    (activity_id_var, 'stable', 'มั่นคง', NULL),
    (activity_id_var, 'anticipate', 'คาดหวัง', NULL),
    (activity_id_var, 'prepare', 'เตรียม', NULL),
    (activity_id_var, 'transition', 'การเปลี่ยนแปลง', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_matching_drag', 3, 'Match Adulthood Words', 'Match words related to adult planning', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'milestone', 'จุดสำคัญ', NULL),
    (activity_id_var, 'stable', 'มั่นคง', NULL),
    (activity_id_var, 'anticipate', 'คาดหวัง', NULL),
    (activity_id_var, 'prepare', 'เตรียม', NULL),
    (activity_id_var, 'transition', 'การเปลี่ยนแปลง', NULL);

    -- 4. Vocabulary Fill Blanks #1
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 4, 'Complete the Sentences 1', 'Fill in the blanks with correct words', '{"text": "I reached a ___. I want to be ___. I need to ___.", "blanks": [{"id": "blank1", "text": "milestone", "options": ["milestone", "stable", "anticipate", "prepare"], "correctAnswer": "milestone"}, {"id": "blank2", "text": "stable", "options": ["stable", "milestone", "anticipate", "transition"], "correctAnswer": "stable"}, {"id": "blank3", "text": "anticipate", "options": ["anticipate", "milestone", "stable", "prepare"], "correctAnswer": "anticipate"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    -- 5. Vocabulary Fill Blanks #2
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 5, 'Complete the Sentences 2', 'Fill in the blanks with correct words', '{"text": "I need to ___ for this. It is a ___. We must ___.", "blanks": [{"id": "blank1", "text": "prepare", "options": ["prepare", "milestone", "stable", "anticipate"], "correctAnswer": "prepare"}, {"id": "blank2", "text": "transition", "options": ["transition", "milestone", "stable", "prepare"], "correctAnswer": "transition"}, {"id": "blank3", "text": "prepare", "options": ["prepare", "transition", "milestone", "stable"], "correctAnswer": "prepare"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    -- 6. Grammar Explanation
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_explanation', 6, 'Second Conditional', 'Learn if/when for hypothetical situations', '{"rules": "Use second conditional for hypothetical or unreal situations:\n\n- Form: If + past simple, would + base verb\n- If I planned better, I would have more stability\n- If she anticipated, she would prepare\n- Use were for all subjects (If I were, If you were)\n- Expresses unlikely or imaginary situations\n- Often used for advice, suggestions, or hypothetical planning", "examples": ["If I planned better now, I would have more stability later.", "If she anticipated challenges, she would prepare differently.", "If they focused on milestones, they would feel more accomplished.", "If I were you, I would start preparing now.", "What would you do if you had to plan your future?"]}'::jsonb)
    RETURNING id INTO activity_id_var;

    -- 7. Grammar Sentences #1
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 7, 'Build Sentences 1', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'If I planned better now I would have more stability later', 'If I planned better now, I would have more stability later.', '["If", "I", "planned", "better", "now,", "I", "would", "have", "more", "stability", "later."]'::jsonb),
    (activity_id_var, 'If she anticipated challenges she would prepare differently', 'If she anticipated challenges, she would prepare differently.', '["If", "she", "anticipated", "challenges,", "she", "would", "prepare", "differently."]'::jsonb);

    -- 8. Grammar Sentences #2
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 8, 'Build Sentences 2', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'If they focused on milestones they would feel more accomplished', 'If they focused on milestones, they would feel more accomplished.', '["If", "they", "focused", "on", "milestones,", "they", "would", "feel", "more", "accomplished."]'::jsonb),
    (activity_id_var, 'If I were you I would start preparing now', 'If I were you, I would start preparing now.', '["If", "I", "were", "you,", "I", "would", "start", "preparing", "now."]'::jsonb);

    -- 9. Speaking Practice
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'speaking_practice', 9, 'Discuss Adult Planning', 'Practice talking about future responsibilities', '{"prompts": ["If you shifted plans now, what would future you gain?", "How do you prepare?", "Who keeps you realistic?", "What milestones do you want to reach?", "How do you anticipate challenges?"]}'::jsonb)
    RETURNING id INTO activity_id_var;

    -- 10. Speaking Improvement
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'speaking_improvement', 10, 'Speaking Improvement', 'Read the improved version of your speech', '{"type": "speaking_improvement", "similarityThreshold": 70}'::jsonb)
    RETURNING id INTO activity_id_var;
END $$;


-- =========================================
-- END OF MISSING LESSONS
-- =========================================
--
-- Summary of added lessons:
-- A1: L45-L50 (6 lessons) ✅ COMPLETE
-- B1: L61-L70 (10 lessons) ✅ COMPLETE
-- B2: L51-L60, L81-L90 (20 lessons) ✅ COMPLETE
--
-- Total: 36 lessons added ✅ ALL GAPS FILLED
--
-- This file contains all missing lessons to fill the gaps identified in the database.
-- =========================================
