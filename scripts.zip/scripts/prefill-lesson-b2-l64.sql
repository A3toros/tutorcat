-- =========================================
-- Pre-fill Database with Sample Lesson Data
-- B2-L64: Responsible media use
-- =========================================

DELETE FROM grammar_sentences WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'B2-L64');
DELETE FROM vocabulary_items WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'B2-L64');
DELETE FROM lesson_activities WHERE lesson_id = 'B2-L64';
DELETE FROM lessons WHERE id = 'B2-L64';

INSERT INTO lessons (id, level, lesson_number, topic) VALUES
('B2-L64', 'B2', 64, 'Responsible media use')
ON CONFLICT (id) DO UPDATE SET topic = EXCLUDED.topic;

DO $$
DECLARE
    lesson_id_var TEXT := 'B2-L64';
    activity_id_var UUID;
BEGIN
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'warm_up_speaking', 1, 'Line Drawing', 'Talk about limits online', '{"prompt": "Where do you draw the line, and how do you handle reports?"}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_intro', 2, 'Responsible Media Words', 'Key words for moderation', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'moderate', 'ตรวจสอบ/ควบคุมเนื้อหา', NULL),
    (activity_id_var, 'report', 'รายงาน', NULL),
    (activity_id_var, 'restrict', 'จำกัด', NULL),
    (activity_id_var, 'verify', 'ตรวจสอบ', NULL),
    (activity_id_var, 'consent', 'ความยินยอม', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_matching_drag', 3, 'Match Responsible Media Words', 'Match words with meanings', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'moderate', 'ตรวจสอบ/ควบคุมเนื้อหา', NULL),
    (activity_id_var, 'report', 'รายงาน', NULL),
    (activity_id_var, 'restrict', 'จำกัด', NULL),
    (activity_id_var, 'verify', 'ตรวจสอบ', NULL),
    (activity_id_var, 'consent', 'ความยินยอม', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 4, 'Complete the Sentences 1', 'Fill with the correct word', '{"text": "I ___ harmful posts. I ___ before sharing. Some groups ___ access.", "blanks": [{"id": "blank1", "text": "moderate", "options": ["moderate", "report", "restrict", "consent"], "correctAnswer": "moderate"}, {"id": "blank2", "text": "verify", "options": ["verify", "restrict", "moderate", "report"], "correctAnswer": "verify"}, {"id": "blank3", "text": "restrict", "options": ["restrict", "consent", "report", "moderate"], "correctAnswer": "restrict"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 5, 'Complete the Sentences 2', 'Fill with the correct word', '{"text": "I ___ when rules break. I ask for ___ before sharing photos.", "blanks": [{"id": "blank1", "text": "report", "options": ["report", "moderate", "restrict", "verify"], "correctAnswer": "report"}, {"id": "blank2", "text": "consent", "options": ["consent", "verify", "moderate", "restrict"], "correctAnswer": "consent"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_explanation', 6, 'Contrast & Concession', 'Balance rules vs freedom', '{"rules": "Use although for contrast in one sentence; however to contrast sentences; whereas to compare two subjects.\\n- Although the rule is strict, it protects consent.\\n- The post was funny; however, it broke guidelines.\\n- This group verifies sources, whereas that one does not.", "examples": ["Although we restrict posts, we invite feedback.", "The rule is strict; however, it keeps consent clear.", "This forum verifies sources, whereas that one shares rumors.", "Although reports take time, they build trust.", "He moderates often; however, he still enjoys posting."]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 7, 'Build Sentences 1', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'Although we restrict posts, we invite feedback', 'Although we restrict posts, we invite feedback.', '["Although", "we", "restrict", "posts,", "we", "invite", "feedback."]'::jsonb),
    (activity_id_var, 'The rule is strict; however, it keeps consent clear', 'The rule is strict; however, it keeps consent clear.', '["The", "rule", "is", "strict;", "however,", "it", "keeps", "consent", "clear."]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 8, 'Build Sentences 2', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'This forum verifies sources, whereas that one shares rumors', 'This forum verifies sources, whereas that one shares rumors.', '["This", "forum", "verifies", "sources,", "whereas", "that", "one", "shares", "rumors."]'::jsonb),
    (activity_id_var, 'Although reports take time, they build trust', 'Although reports take time, they build trust.', '["Although", "reports", "take", "time,", "they", "build", "trust."]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'speaking_practice', 9, 'Talk About Media Responsibility', 'Practice contrasts', '{"prompts": ["Where do you draw the line online?", "How do you handle reports in your groups?", "When do you ask for consent before sharing?"]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (
      lesson_id,
      activity_type,
      activity_order,
      title,
      description,
      content
    ) VALUES (
      'B2-L64',
      'speaking_improvement',
      10,
      'Speaking Improvement',
      'Read the improved version of your speech',
      '{"type": "speaking_improvement", "similarityThreshold": 70}'::jsonb
    );
END $$;


