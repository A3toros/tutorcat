-- =========================================
-- Pre-fill Database with Sample Lesson Data
-- A1-L83: People at Work
-- =========================================

DELETE FROM grammar_sentences WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'A1-L83');
DELETE FROM vocabulary_items WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'A1-L83');
DELETE FROM lesson_activities WHERE lesson_id = 'A1-L83';
DELETE FROM lessons WHERE id = 'A1-L83';

INSERT INTO lessons (id, level, lesson_number, topic) VALUES
('A1-L83', 'A1', 83, 'People at Work')
ON CONFLICT (id) DO UPDATE SET topic = EXCLUDED.topic;

DO $$
DECLARE
    lesson_id_var TEXT := 'A1-L83';
    activity_id_var UUID;
BEGIN
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'warm_up_speaking', 1, 'Jobs', 'Talk about people at work', '{"prompt": "Is he a chef?"}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_intro', 2, 'Job Words', 'Learn work people words', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'chef', 'เชฟ', NULL),
    (activity_id_var, 'nurse', 'พยาบาล', NULL),
    (activity_id_var, 'guard', 'ยาม', NULL),
    (activity_id_var, 'clerk', 'เสมียน', NULL),
    (activity_id_var, 'farmer', 'ชาวนา', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_matching_drag', 3, 'Match Work Words', 'Match job words', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'chef', 'เชฟ', NULL),
    (activity_id_var, 'nurse', 'พยาบาล', NULL),
    (activity_id_var, 'guard', 'ยาม', NULL),
    (activity_id_var, 'clerk', 'เสมียน', NULL),
    (activity_id_var, 'farmer', 'ชาวนา', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 4, 'Complete the Sentences 1', 'Fill with the correct word', '{"text": "He is a ___. She is a ___.", "blanks": [{"id": "blank1", "text": "chef", "options": ["chef", "nurse", "guard", "farmer"], "correctAnswer": "chef"}, {"id": "blank2", "text": "nurse", "options": ["nurse", "guard", "clerk", "chef"], "correctAnswer": "nurse"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 5, 'Complete the Sentences 2', 'Fill with the correct word', '{"text": "He is a ___. She is a ___.", "blanks": [{"id": "blank1", "text": "guard", "options": ["guard", "clerk", "chef", "nurse"], "correctAnswer": "guard"}, {"id": "blank2", "text": "clerk", "options": ["clerk", "farmer", "guard", "chef"], "correctAnswer": "clerk"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_explanation', 6, 'Be + Job', 'Describe jobs of people', '{"rules": "Use be to tell job.\n- He is a chef.\n- She is a nurse.\nAsk: Is he a guard?", "examples": ["He is a chef.", "She is a nurse.", "He is a guard.", "She is a clerk.", "Is he a farmer?"]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 7, 'Build Sentences 1', 'Arrange words', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'He is a chef', 'He is a chef.', '["He", "is", "a", "chef."]'::jsonb),
    (activity_id_var, 'She is a nurse', 'She is a nurse.', '["She", "is", "a", "nurse."]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 8, 'Build Sentences 2', 'Arrange words', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'He is a guard', 'He is a guard.', '["He", "is", "a", "guard."]'::jsonb),
    (activity_id_var, 'Is he a farmer', 'Is he a farmer?', '["Is", "he", "a", "farmer?"]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'speaking_practice', 9, 'Talk About Jobs', 'Practice be + job', '{"prompts": ["Is he a chef?", "Is she a nurse?", "Is he a guard?", "Is she a clerk?", "Is he a farmer?"]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (
      lesson_id,
      activity_type,
      activity_order,
      title,
      description,
      content
    ) VALUES (
      'A1-L83',
      'speaking_improvement',
      10,
      'Speaking Improvement',
      'Read the improved version of your speech',
      '{"type": "speaking_improvement", "similarityThreshold": 70}'::jsonb
    );
END $$;

