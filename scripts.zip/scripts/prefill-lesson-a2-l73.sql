-- =========================================
-- Pre-fill Database with Sample Lesson Data
-- A2-L73: Looking for a Job
-- =========================================

DELETE FROM grammar_sentences WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'A2-L73');
DELETE FROM vocabulary_items WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'A2-L73');
DELETE FROM lesson_activities WHERE lesson_id = 'A2-L73';
DELETE FROM lessons WHERE id = 'A2-L73';

INSERT INTO lessons (id, level, lesson_number, topic) VALUES
('A2-L73', 'A2', 73, 'Looking for a Job')
ON CONFLICT (id) DO UPDATE SET topic = EXCLUDED.topic;

DO $$
DECLARE
    lesson_id_var TEXT := 'A2-L73';
    activity_id_var UUID;
BEGIN
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'warm_up_speaking', 1, 'Job Search', 'Talk about job plans', '{"prompt": "Are you going to look for a new job?"}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_intro', 2, 'Job Search Words', 'Learn job search vocabulary', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'apply', 'สมัคร', NULL),
    (activity_id_var, 'resume', 'เรซูเม่', NULL),
    (activity_id_var, 'interview', 'สัมภาษณ์', NULL),
    (activity_id_var, 'hire', 'จ้างงาน', NULL),
    (activity_id_var, 'start date', 'วันเริ่มงาน', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_matching_drag', 3, 'Match Job Search Words', 'Match job search words', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'apply', 'สมัคร', NULL),
    (activity_id_var, 'resume', 'เรซูเม่', NULL),
    (activity_id_var, 'interview', 'สัมภาษณ์', NULL),
    (activity_id_var, 'hire', 'จ้างงาน', NULL),
    (activity_id_var, 'start date', 'วันเริ่มงาน', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 4, 'Complete the Sentences 1', 'Fill with the correct word', '{"text": "I will ___ this week. I updated my ___. I have an ___.", "blanks": [{"id": "blank1", "text": "apply", "options": ["apply", "resume", "interview", "hire"], "correctAnswer": "apply"}, {"id": "blank2", "text": "resume", "options": ["resume", "interview", "apply", "start date"], "correctAnswer": "resume"}, {"id": "blank3", "text": "interview", "options": ["interview", "hire", "apply", "resume"], "correctAnswer": "interview"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 5, 'Complete the Sentences 2', 'Fill with the correct word', '{"text": "They want to ___ me. My ___ is next month.", "blanks": [{"id": "blank1", "text": "hire", "options": ["hire", "start date", "resume", "apply"], "correctAnswer": "hire"}, {"id": "blank2", "text": "start date", "options": ["start date", "hire", "interview", "apply"], "correctAnswer": "start date"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_explanation', 6, 'Going to (Future Plans)', 'Talk about job plans', '{"rules": "Use going to for planned actions.\n- I am going to apply.\n- She is going to prepare for an interview.\nForm: am/is/are + going to + verb.", "examples": ["I am going to apply this week.", "She is going to send her resume.", "We are going to practice interview questions.", "Are you going to accept the offer?", "They are going to set a start date."]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 7, 'Build Sentences 1', 'Arrange words', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'I am going to apply this week', 'I am going to apply this week.', '["I", "am", "going", "to", "apply", "this", "week."]'::jsonb),
    (activity_id_var, 'We are going to practice interview questions', 'We are going to practice interview questions.', '["We", "are", "going", "to", "practice", "interview", "questions."]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 8, 'Build Sentences 2', 'Arrange words', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'Are you going to accept the offer', 'Are you going to accept the offer?', '["Are", "you", "going", "to", "accept", "the", "offer?"]'::jsonb),
    (activity_id_var, 'They are going to set a start date', 'They are going to set a start date.', '["They", "are", "going", "to", "set", "a", "start", "date."]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'speaking_practice', 9, 'Talk About Job Search', 'Practice job plans', '{"prompts": ["Are you going to look for a new job?", "What kind of job are you going to apply for?", "How are you going to prepare for interviews?", "Who is going to help you with your resume?", "When are you going to start applying?"]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (
      lesson_id,
      activity_type,
      activity_order,
      title,
      description,
      content
    ) VALUES (
      'A2-L73',
      'speaking_improvement',
      10,
      'Speaking Improvement',
      'Read the improved version of your speech',
      '{"type": "speaking_improvement", "similarityThreshold": 70}'::jsonb
    );
END $$;

