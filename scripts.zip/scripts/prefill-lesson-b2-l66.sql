-- =========================================
-- Pre-fill Database with Sample Lesson Data
-- B2-L66: Forming opinions
-- =========================================

DELETE FROM grammar_sentences WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'B2-L66');
DELETE FROM vocabulary_items WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'B2-L66');
DELETE FROM lesson_activities WHERE lesson_id = 'B2-L66';
DELETE FROM lessons WHERE id = 'B2-L66';

INSERT INTO lessons (id, level, lesson_number, topic) VALUES
('B2-L66', 'B2', 66, 'Forming opinions')
ON CONFLICT (id) DO UPDATE SET topic = EXCLUDED.topic;

DO $$
DECLARE
    lesson_id_var TEXT := 'B2-L66';
    activity_id_var UUID;
BEGIN
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'warm_up_speaking', 1, 'Opinion Signals', 'Talk about confidence in views', '{"prompt": "How can you tell your view is solid, and what might change it?"}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_intro', 2, 'Opinion Words', 'Key words for evidence and bias', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'assumption', 'ข้อสันนิษฐาน', NULL),
    (activity_id_var, 'evidence', 'หลักฐาน', NULL),
    (activity_id_var, 'revise', 'ปรับทบทวน', NULL),
    (activity_id_var, 'conclude', 'สรุป', NULL),
    (activity_id_var, 'bias', 'อคติ', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_matching_drag', 3, 'Match Opinion Words', 'Match words with meanings', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'assumption', 'ข้อสันนิษฐาน', NULL),
    (activity_id_var, 'evidence', 'หลักฐาน', NULL),
    (activity_id_var, 'revise', 'ปรับทบทวน', NULL),
    (activity_id_var, 'conclude', 'สรุป', NULL),
    (activity_id_var, 'bias', 'อคติ', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 4, 'Complete the Sentences 1', 'Fill with the correct word', '{"text": "My first ___ was wrong. New ___ made me ___.", "blanks": [{"id": "blank1", "text": "assumption", "options": ["assumption", "evidence", "bias", "revise"], "correctAnswer": "assumption"}, {"id": "blank2", "text": "evidence", "options": ["evidence", "assumption", "bias", "conclude"], "correctAnswer": "evidence"}, {"id": "blank3", "text": "revise", "options": ["revise", "conclude", "bias", "evidence"], "correctAnswer": "revise"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 5, 'Complete the Sentences 2', 'Fill with the correct word', '{"text": "I try to spot ___. I only ___ after checking facts.", "blanks": [{"id": "blank1", "text": "bias", "options": ["bias", "assumption", "revise", "evidence"], "correctAnswer": "bias"}, {"id": "blank2", "text": "conclude", "options": ["conclude", "revise", "assumption", "bias"], "correctAnswer": "conclude"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_explanation', 6, 'Modals for Deduction', 'Judge strength of opinions', '{"rules": "Use must/might/can’t + base verb for present deduction; modal + have + past participle for past.\\n- The evidence must be strong.\\n- This might be bias.\\n- It can’t be reliable without sources.", "examples": ["This must be solid; multiple sources agree.", "There might be bias; check the funding.", "That can’t be reliable; no evidence cited.", "He must have revised his view; the facts changed.", "It might have been an assumption; now we have data."]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 7, 'Build Sentences 1', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'This must be solid; multiple sources agree', 'This must be solid; multiple sources agree.', '["This", "must", "be", "solid;", "multiple", "sources", "agree."]'::jsonb),
    (activity_id_var, 'There might be bias; check the funding', 'There might be bias; check the funding.', '["There", "might", "be", "bias;", "check", "the", "funding."]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 8, 'Build Sentences 2', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'That can’t be reliable; no evidence is cited', 'That can’t be reliable; no evidence is cited.', '["That", "can’t", "be", "reliable;", "no", "evidence", "is", "cited."]'::jsonb),
    (activity_id_var, 'He must have revised his view; the facts changed', 'He must have revised his view; the facts changed.', '["He", "must", "have", "revised", "his", "view;", "the", "facts", "changed."]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'speaking_practice', 9, 'Talk About Opinions', 'Practice deduction', '{"prompts": ["How can you tell your view is solid?", "What might change your opinion?", "When do you revise a conclusion?"]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (
      lesson_id,
      activity_type,
      activity_order,
      title,
      description,
      content
    ) VALUES (
      'B2-L66',
      'speaking_improvement',
      10,
      'Speaking Improvement',
      'Read the improved version of your speech',
      '{"type": "speaking_improvement", "similarityThreshold": 70}'::jsonb
    );
END $$;


