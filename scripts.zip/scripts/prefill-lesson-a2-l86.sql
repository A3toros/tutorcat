-- =========================================
-- Pre-fill Database with Sample Lesson Data
-- A2-L86: Email Communication
-- =========================================

DELETE FROM grammar_sentences WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'A2-L86');
DELETE FROM vocabulary_items WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'A2-L86');
DELETE FROM lesson_activities WHERE lesson_id = 'A2-L86';
DELETE FROM lessons WHERE id = 'A2-L86';

INSERT INTO lessons (id, level, lesson_number, topic) VALUES
('A2-L86', 'A2', 86, 'Email Communication')
ON CONFLICT (id) DO UPDATE SET topic = EXCLUDED.topic;

DO $$
DECLARE
    lesson_id_var TEXT := 'A2-L86';
    activity_id_var UUID;
BEGIN
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'warm_up_speaking', 1, 'Emails', 'Talk about writing emails', '{"prompt": "How do you start an email?"}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_intro', 2, 'Email Words', 'Learn email basics', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'email', 'อีเมล', NULL),
    (activity_id_var, 'subject', 'หัวเรื่อง', NULL),
    (activity_id_var, 'attach', 'แนบ', NULL),
    (activity_id_var, 'send', 'ส่ง', NULL),
    (activity_id_var, 'reply', 'ตอบกลับ', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_matching_drag', 3, 'Match Email Words', 'Match email words', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'email', 'อีเมล', NULL),
    (activity_id_var, 'subject', 'หัวเรื่อง', NULL),
    (activity_id_var, 'attach', 'แนบ', NULL),
    (activity_id_var, 'send', 'ส่ง', NULL),
    (activity_id_var, 'reply', 'ตอบกลับ', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 4, 'Complete the Sentences 1', 'Fill with the correct word', '{"text": "Write a clear ___. ___ the file. Please ___ soon.", "blanks": [{"id": "blank1", "text": "subject", "options": ["subject", "attach", "send", "reply"], "correctAnswer": "subject"}, {"id": "blank2", "text": "Attach", "options": ["Attach", "Send", "Reply", "Email"], "correctAnswer": "Attach"}, {"id": "blank3", "text": "reply", "options": ["reply", "attach", "subject", "send"], "correctAnswer": "reply"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 5, 'Complete the Sentences 2', 'Fill with the correct word', '{"text": "Click ___ to send. Did you ___ to my ___.", "blanks": [{"id": "blank1", "text": "send", "options": ["send", "reply", "subject", "attach"], "correctAnswer": "send"}, {"id": "blank2", "text": "reply", "options": ["reply", "subject", "send", "attach"], "correctAnswer": "reply"}, {"id": "blank3", "text": "email", "options": ["email", "subject", "attach", "reply"], "correctAnswer": "email"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_explanation', 6, 'Email Openings/Closings', 'Use simple formal/informal openings', '{"rules": "Use short openings and closings.\nFormal: Dear [Name], / Regards,\nInformal: Hi [Name], / Thanks,\nKeep sentences clear and present simple.", "examples": ["Dear Ana, I am writing about the meeting.", "Regards, John", "Hi Tom, Can you check this file?", "Thanks, May", "Please see the attached report."]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 7, 'Build Sentences 1', 'Arrange words', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'Dear Ana I am writing about the meeting', 'Dear Ana, I am writing about the meeting.', '["Dear", "Ana,", "I", "am", "writing", "about", "the", "meeting."]'::jsonb),
    (activity_id_var, 'Please see the attached report', 'Please see the attached report.', '["Please", "see", "the", "attached", "report."]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 8, 'Build Sentences 2', 'Arrange words', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'Hi Tom Can you check this file', 'Hi Tom, can you check this file?', '["Hi", "Tom,", "can", "you", "check", "this", "file?"]'::jsonb),
    (activity_id_var, 'Thanks May', 'Thanks, May', '["Thanks,", "May"]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'speaking_practice', 9, 'Talk About Emails', 'Practice email basics', '{"prompts": ["How do you start a formal email?", "How do you start an informal email?", "Do you write short or long emails?", "How often do you check your email?", "Have you ever sent an email by mistake?"]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (
      lesson_id,
      activity_type,
      activity_order,
      title,
      description,
      content
    ) VALUES (
      'A2-L86',
      'speaking_improvement',
      10,
      'Speaking Improvement',
      'Read the improved version of your speech',
      '{"type": "speaking_improvement", "similarityThreshold": 70}'::jsonb
    );
END $$;

