-- =========================================
-- Pre-fill Database with Sample Lesson Data
-- B1-L72: Digital Privacy
-- =========================================

DELETE FROM grammar_sentences WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'B1-L72');
DELETE FROM vocabulary_items WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'B1-L72');
DELETE FROM lesson_activities WHERE lesson_id = 'B1-L72';
DELETE FROM lessons WHERE id = 'B1-L72';

INSERT INTO lessons (id, level, lesson_number, topic) VALUES
('B1-L72', 'B1', 72, 'Digital Privacy')
ON CONFLICT (id) DO UPDATE SET topic = EXCLUDED.topic;

DO $$
DECLARE
    lesson_id_var TEXT := 'B1-L72';
    activity_id_var UUID;
BEGIN
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'warm_up_speaking', 1, 'Privacy Choices', 'Talk about protecting data online', '{"prompt": "What should you never post online?"}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_intro', 2, 'Privacy Words', 'Learn vocabulary about digital privacy', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'consent', 'การยินยอม', NULL),
    (activity_id_var, 'encrypt', 'เข้ารหัส', NULL),
    (activity_id_var, 'password', 'รหัสผ่าน', NULL),
    (activity_id_var, 'share', 'แบ่งปัน', NULL),
    (activity_id_var, 'leak', 'รั่วไหล', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_matching_drag', 3, 'Match Privacy Words', 'Match words with meanings', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'consent', 'การยินยอม', NULL),
    (activity_id_var, 'encrypt', 'เข้ารหัส', NULL),
    (activity_id_var, 'password', 'รหัสผ่าน', NULL),
    (activity_id_var, 'share', 'แบ่งปัน', NULL),
    (activity_id_var, 'leak', 'รั่วไหล', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 4, 'Complete the Sentences 1', 'Fill with the correct word', '{"text": "Ask for ___. Always ___ data. Keep your ___ strong.", "blanks": [{"id": "blank1", "text": "consent", "options": ["consent", "encrypt", "password", "share"], "correctAnswer": "consent"}, {"id": "blank2", "text": "encrypt", "options": ["encrypt", "share", "password", "leak"], "correctAnswer": "encrypt"}, {"id": "blank3", "text": "password", "options": ["password", "encrypt", "consent", "share"], "correctAnswer": "password"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 5, 'Complete the Sentences 2', 'Fill with the correct word', '{"text": "Do not ___ everything. Prevent data ___. Never post without ___.", "blanks": [{"id": "blank1", "text": "share", "options": ["share", "encrypt", "consent", "leak"], "correctAnswer": "share"}, {"id": "blank2", "text": "leaks", "options": ["leaks", "passwords", "shares", "consent"], "correctAnswer": "leaks"}, {"id": "blank3", "text": "consent", "options": ["consent", "share", "encrypt", "password"], "correctAnswer": "consent"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    -- Grammar Explanation: Modals (have to / should) for privacy rules
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_explanation', 6, 'Modals for Privacy Rules', 'Use have to / should to state rules and advice for privacy', '{"rules": "Use have to for obligations. Use should for advice.\\n- You have to protect passwords.\\n- You should encrypt files.\\nNo contractions.", "examples": ["You have to use strong passwords.", "You should encrypt sensitive files.", "They have to get consent before sharing.", "We should limit what we post publicly.", "He has to change passwords regularly."]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 7, 'Build Sentences 1', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'You have to use strong passwords', 'You have to use strong passwords', '["You", "have", "to", "use", "strong", "passwords"]'::jsonb),
    (activity_id_var, 'You should encrypt sensitive files', 'You should encrypt sensitive files', '["You", "should", "encrypt", "sensitive", "files"]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 8, 'Build Sentences 2', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'They have to get consent before sharing', 'They have to get consent before sharing', '["They", "have", "to", "get", "consent", "before", "sharing"]'::jsonb),
    (activity_id_var, 'We should limit what we post publicly', 'We should limit what we post publicly', '["We", "should", "limit", "what", "we", "post", "publicly"]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'speaking_practice', 9, 'Talk About Digital Privacy', 'Practice talking about online privacy', '{"prompts": ["What should you never post online?", "When do you have to refuse sharing data?", "How do you keep your accounts safe?"]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (
      lesson_id,
      activity_type,
      activity_order,
      title,
      description,
      content
    ) VALUES (
      'B1-L72',
      'speaking_improvement',
      10,
      'Speaking Improvement',
      'Read the improved version of your speech',
      '{"type": "speaking_improvement", "similarityThreshold": 70}'::jsonb
    );
END $$;

