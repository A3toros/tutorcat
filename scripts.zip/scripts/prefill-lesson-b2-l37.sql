-- =========================================
-- Pre-fill Database with Sample Lesson Data
-- B2-L37: Personal achievements
-- =========================================

DELETE FROM grammar_sentences WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'B2-L37');
DELETE FROM vocabulary_items WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'B2-L37');
DELETE FROM lesson_activities WHERE lesson_id = 'B2-L37';
DELETE FROM lessons WHERE id = 'B2-L37';

INSERT INTO lessons (id, level, lesson_number, topic) VALUES
('B2-L37', 'B2', 37, 'Personal achievements')
ON CONFLICT (id) DO UPDATE SET topic = EXCLUDED.topic;

DO $$
DECLARE
    lesson_id_var TEXT := 'B2-L37';
    activity_id_var UUID;
BEGIN
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'warm_up_speaking', 1, 'Wins & Gaps', 'Talk about celebrating and improving', '{"prompt": "What should you have celebrated more, and what could you still improve?"}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_intro', 2, 'Achievement Words', 'Key words for milestones and feedback', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'milestone', 'เหตุการณ์สำคัญ', NULL),
    (activity_id_var, 'effort', 'ความพยายาม', NULL),
    (activity_id_var, 'celebrate', 'เฉลิมฉลอง', NULL),
    (activity_id_var, 'mentor', 'พี่เลี้ยง/ที่ปรึกษา', NULL),
    (activity_id_var, 'revise', 'ปรับทบทวน', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_matching_drag', 3, 'Match Achievement Words', 'Match words with meanings', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'milestone', 'เหตุการณ์สำคัญ', NULL),
    (activity_id_var, 'effort', 'ความพยายาม', NULL),
    (activity_id_var, 'celebrate', 'เฉลิมฉลอง', NULL),
    (activity_id_var, 'mentor', 'พี่เลี้ยง/ที่ปรึกษา', NULL),
    (activity_id_var, 'revise', 'ปรับทบทวน', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 4, 'Complete the Sentences 1', 'Fill with the correct word', '{"text": "I hit a ___. My ___ was high. My ___ helped me ___.", "blanks": [{"id": "blank1", "text": "milestone", "options": ["milestone", "effort", "mentor", "revise"], "correctAnswer": "milestone"}, {"id": "blank2", "text": "effort", "options": ["effort", "celebrate", "revise", "mentor"], "correctAnswer": "effort"}, {"id": "blank3", "text": "mentor", "options": ["mentor", "milestone", "revise", "celebrate"], "correctAnswer": "mentor"}, {"id": "blank4", "text": "revise", "options": ["revise", "celebrate", "effort", "mentor"], "correctAnswer": "revise"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 5, 'Complete the Sentences 2', 'Fill with the correct word', '{"text": "We ___ small wins. I plan to ___ my draft.", "blanks": [{"id": "blank1", "text": "celebrate", "options": ["celebrate", "revise", "effort", "milestone"], "correctAnswer": "celebrate"}, {"id": "blank2", "text": "revise", "options": ["revise", "celebrate", "mentor", "effort"], "correctAnswer": "revise"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_explanation', 6, 'Past Modals (should have / could have)', 'Reflect on missed actions or options', '{"rules": "Use should have + past participle for missed obligations/advice; could have for missed possibilities.\\n- I should have rested earlier.\\n- I could have asked for help.\\nUse might have for uncertain possibilities.", "examples": ["I should have celebrated that milestone.", "I could have asked my mentor sooner.", "We should have revised the plan earlier.", "She could have shared the win with the team.", "He might have improved faster with feedback."]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 7, 'Build Sentences 1', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'I should have celebrated that milestone', 'I should have celebrated that milestone.', '["I", "should", "have", "celebrated", "that", "milestone."]'::jsonb),
    (activity_id_var, 'I could have asked my mentor sooner', 'I could have asked my mentor sooner.', '["I", "could", "have", "asked", "my", "mentor", "sooner."]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 8, 'Build Sentences 2', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'We should have revised the plan earlier', 'We should have revised the plan earlier.', '["We", "should", "have", "revised", "the", "plan", "earlier."]'::jsonb),
    (activity_id_var, 'He might have improved faster with feedback', 'He might have improved faster with feedback.', '["He", "might", "have", "improved", "faster", "with", "feedback."]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'speaking_practice', 9, 'Talk About Achievements', 'Practice past modals', '{"prompts": ["What should you have celebrated more?", "What could you still improve now?", "Who could have helped you sooner?"]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (
      lesson_id,
      activity_type,
      activity_order,
      title,
      description,
      content
    ) VALUES (
      'B2-L37',
      'speaking_improvement',
      10,
      'Speaking Improvement',
      'Read the improved version of your speech',
      '{"type": "speaking_improvement", "similarityThreshold": 70}'::jsonb
    );
END $$;


