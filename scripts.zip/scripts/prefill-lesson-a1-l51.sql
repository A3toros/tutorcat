-- =========================================
-- Pre-fill Database with Sample Lesson Data
-- A1-L51: Your House
-- =========================================

DELETE FROM grammar_sentences WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'A1-L51');
DELETE FROM vocabulary_items WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'A1-L51');
DELETE FROM lesson_activities WHERE lesson_id = 'A1-L51';
DELETE FROM lessons WHERE id = 'A1-L51';

INSERT INTO lessons (id, level, lesson_number, topic) VALUES
('A1-L51', 'A1', 51, 'Your House')
ON CONFLICT (id) DO UPDATE SET topic = EXCLUDED.topic;

DO $$
DECLARE
    lesson_id_var TEXT := 'A1-L51';
    activity_id_var UUID;
BEGIN
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'warm_up_speaking', 1, 'Your House', 'Talk about your house', '{"prompt": "Is there a garden?"}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_intro', 2, 'House Words', 'Learn house words', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'house', 'บ้าน', NULL),
    (activity_id_var, 'floor', 'ชั้น', NULL),
    (activity_id_var, 'roof', 'หลังคา', NULL),
    (activity_id_var, 'garden', 'สวน', NULL),
    (activity_id_var, 'gate', 'ประตูรั้ว', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_matching_drag', 3, 'Match House Words', 'Match house words', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'house', 'บ้าน', NULL),
    (activity_id_var, 'floor', 'ชั้น', NULL),
    (activity_id_var, 'roof', 'หลังคา', NULL),
    (activity_id_var, 'garden', 'สวน', NULL),
    (activity_id_var, 'gate', 'ประตูรั้ว', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 4, 'Complete the Sentences 1', 'Fill with the correct word', '{"text": "There is a ___. The ___ is green.", "blanks": [{"id": "blank1", "text": "house", "options": ["house", "roof", "floor", "garden"], "correctAnswer": "house"}, {"id": "blank2", "text": "garden", "options": ["garden", "floor", "gate", "roof"], "correctAnswer": "garden"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 5, 'Complete the Sentences 2', 'Fill with the correct word', '{"text": "There are two ___. The ___ is red.", "blanks": [{"id": "blank1", "text": "floors", "options": ["floors", "gates", "roofs", "gardens"], "correctAnswer": "floors"}, {"id": "blank2", "text": "gate", "options": ["gate", "roof", "floor", "house"], "correctAnswer": "gate"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_explanation', 6, 'There is / There are', 'Describe parts of a house', '{"rules": "Use there is for one; there are for many.\n- There is a garden.\n- There are two floors.\nAsk: Is there a gate?", "examples": ["There is a garden.", "There is a roof.", "There are two floors.", "Is there a gate?", "Are there two houses?"]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 7, 'Build Sentences 1', 'Arrange words', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'There is a garden', 'There is a garden.', '["There", "is", "a", "garden."]'::jsonb),
    (activity_id_var, 'There are two floors', 'There are two floors.', '["There", "are", "two", "floors."]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 8, 'Build Sentences 2', 'Arrange words', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'Is there a gate', 'Is there a gate?', '["Is", "there", "a", "gate?"]'::jsonb),
    (activity_id_var, 'Are there two houses', 'Are there two houses?', '["Are", "there", "two", "houses?"]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'speaking_practice', 9, 'Talk About Your House', 'Practice there is/are', '{"prompts": ["Is there a garden?", "How many floors?", "Is the gate big?", "Is there a roof?", "Is there one house or two?"]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (
      lesson_id,
      activity_type,
      activity_order,
      title,
      description,
      content
    ) VALUES (
      'A1-L51',
      'speaking_improvement',
      10,
      'Speaking Improvement',
      'Read the improved version of your speech',
      '{"type": "speaking_improvement", "similarityThreshold": 70}'::jsonb
    );
END $$;

