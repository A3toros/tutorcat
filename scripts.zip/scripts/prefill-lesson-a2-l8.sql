-- =========================================
-- Pre-fill Database with Sample Lesson Data
-- A2-L8: Feelings & Emotions
-- =========================================

-- Clear existing sample data for A2-L8 (optional - comment out if you want to keep existing data)
DELETE FROM grammar_sentences WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'A2-L8');
DELETE FROM vocabulary_items WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'A2-L8');
DELETE FROM lesson_activities WHERE lesson_id = 'A2-L8';
DELETE FROM lessons WHERE id = 'A2-L8';

INSERT INTO lessons (id, level, lesson_number, topic) VALUES
('A2-L8', 'A2', 8, 'Feelings & Emotions')
ON CONFLICT (id) DO UPDATE SET topic = EXCLUDED.topic;

DO $$
DECLARE
    lesson_id_var TEXT := 'A2-L8';
    activity_id_var UUID;
BEGIN
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content) VALUES (lesson_id_var, 'warm_up_speaking', 1, 'Emotion Talk', 'Talk about feelings', '{"prompt": "How do you feel today?"}'::jsonb) RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content) VALUES (lesson_id_var, 'vocabulary_intro', 2, 'Emotion Words', 'Learn emotion vocabulary', '{}'::jsonb) RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'happy', 'มีความสุข', NULL),
    (activity_id_var, 'sad', 'เศร้า', NULL),
    (activity_id_var, 'angry', 'โกรธ', NULL),
    (activity_id_var, 'excited', 'ตื่นเต้น', NULL),
    (activity_id_var, 'tired', 'เหนื่อย', NULL);

    -- 3. Vocabulary Matching Drag #1 (5 pairs - same words)
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content) VALUES (lesson_id_var, 'vocabulary_matching_drag', 3, 'Match Emotions 1', 'Match English words with Thai meanings', '{}'::jsonb) RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'happy', 'มีความสุข', NULL),
    (activity_id_var, 'sad', 'เศร้า', NULL),
    (activity_id_var, 'angry', 'โกรธ', NULL),
    (activity_id_var, 'excited', 'ตื่นเต้น', NULL),
    (activity_id_var, 'tired', 'เหนื่อย', NULL);


    -- 4. Vocabulary Fill Blanks #1 (4 words: happy, sad, angry, excited - tired left out)
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content) VALUES (lesson_id_var, 'vocabulary_fill_blanks', 4, 'Complete the Sentences 1', 'Fill in the blanks with correct words', '{"text": "I feel ___ when I get good grades. She looks ___ when she loses her toy. He gets ___ when someone takes his pencil. We are ___ about the party tomorrow.", "blanks": [{"id": "blank1", "text": "happy", "options": ["happy", "sad", "angry", "excited"], "correctAnswer": "happy"}, {"id": "blank2", "text": "sad", "options": ["happy", "sad", "angry", "excited"], "correctAnswer": "sad"}, {"id": "blank3", "text": "angry", "options": ["happy", "sad", "angry", "excited"], "correctAnswer": "angry"}, {"id": "blank4", "text": "excited", "options": ["happy", "sad", "angry", "excited"], "correctAnswer": "excited"}]}'::jsonb) RETURNING id INTO activity_id_var;

    -- 4. Vocabulary Fill Blanks #2 (4 words: happy, sad, angry, tired - excited left out)
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content) VALUES (lesson_id_var, 'vocabulary_fill_blanks', 5, 'Complete the Sentences 2', 'Fill in the blanks with correct words', '{"text": "The child is ___ with a big smile. I feel ___ when my friend moves away. My brother gets ___ when he loses games. I am ___ after playing all day.", "blanks": [{"id": "blank1", "text": "happy", "options": ["happy", "sad", "angry", "tired"], "correctAnswer": "happy"}, {"id": "blank2", "text": "sad", "options": ["happy", "sad", "angry", "tired"], "correctAnswer": "sad"}, {"id": "blank3", "text": "angry", "options": ["happy", "sad", "angry", "tired"], "correctAnswer": "angry"}, {"id": "blank4", "text": "tired", "options": ["happy", "sad", "angry", "tired"], "correctAnswer": "tired"}]}'::jsonb) RETURNING id INTO activity_id_var;

    -- 4. Grammar Explanation (5 examples - CEFR A2: Expressing emotions)
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content) VALUES (lesson_id_var, 'grammar_explanation', 6, 'Expressing Emotions', 'Learn to talk about feelings', '{"rules": "Use ''feel'' + adjective to express emotions:\n\n- I feel + emotion (I feel happy)\n- She feels + emotion (She feels sad)\n- Questions: How do you feel? (How do you feel?)\n- Negative: I don''t feel... (I don''t feel angry)\n- Look + emotion (look happy, look tired)", "examples": ["I feel very happy today.", "She feels sad about her dog.", "How do you feel right now?", "He doesn''t feel angry anymore.", "You look tired after school."]}'::jsonb) RETURNING id INTO activity_id_var;
    -- 4. Grammar Sentences #1
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content) VALUES (lesson_id_var, 'grammar_sentences', 7, 'Build Sentences 1', 'Arrange words to make sentences', '{}'::jsonb) RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'I feel very happy today', 'I feel very happy today', '["I", "feel", "very", "happy", "today"]'::jsonb),
    (activity_id_var, 'She feels sad about her dog', 'She feels sad about her dog', '["She", "feels", "sad", "about", "her", "dog"]'::jsonb);
    -- 4. Grammar Sentences #2
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content) VALUES (lesson_id_var, 'grammar_sentences', 8, 'Build Sentences 2', 'Arrange words to make sentences', '{}'::jsonb) RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'How do you feel right now', 'How do you feel right now?', '["How", "do", "you", "feel", "right", "now?"]'::jsonb),
    (activity_id_var, 'He doesn t feel angry anymore', 'He doesn''t feel angry anymore', '["He", "doesn''t", "feel", "angry", "anymore"]'::jsonb);
    -- 4. Speaking Practice (5 prompts - CEFR A2: Emotions and feelings)
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content) VALUES (lesson_id_var, 'speaking_practice', 9, 'Talk About Feelings', 'Practice talking about emotions', '{"prompts": ["How do you feel when you win a game or competition?", "What makes you feel sad or unhappy?", "When do you feel excited?", "Do you feel tired after school or work?", "How do you feel when you meet your friends?"]}'::jsonb) RETURNING id INTO activity_id_var;

END $$;
