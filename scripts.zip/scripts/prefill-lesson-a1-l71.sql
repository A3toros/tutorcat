-- =========================================
-- Pre-fill Database with Sample Lesson Data
-- A1-L71: Personal Information
-- =========================================

DELETE FROM grammar_sentences WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'A1-L71');
DELETE FROM vocabulary_items WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'A1-L71');
DELETE FROM lesson_activities WHERE lesson_id = 'A1-L71';
DELETE FROM lessons WHERE id = 'A1-L71';

INSERT INTO lessons (id, level, lesson_number, topic) VALUES
('A1-L71', 'A1', 71, 'Personal Information')
ON CONFLICT (id) DO UPDATE SET topic = EXCLUDED.topic;

DO $$
DECLARE
    lesson_id_var TEXT := 'A1-L71';
    activity_id_var UUID;
BEGIN
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'warm_up_speaking', 1, 'About You', 'Share basic info', '{"prompt": "What is your name?"}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_intro', 2, 'Personal Words', 'Learn personal info words', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'name', 'ชื่อ', NULL),
    (activity_id_var, 'phone', 'โทรศัพท์', NULL),
    (activity_id_var, 'email', 'อีเมล', NULL),
    (activity_id_var, 'address', 'ที่อยู่', NULL),
    (activity_id_var, 'age', 'อายุ', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_matching_drag', 3, 'Match Personal Words', 'Match personal info words', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'name', 'ชื่อ', NULL),
    (activity_id_var, 'phone', 'โทรศัพท์', NULL),
    (activity_id_var, 'email', 'อีเมล', NULL),
    (activity_id_var, 'address', 'ที่อยู่', NULL),
    (activity_id_var, 'age', 'อายุ', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 4, 'Complete the Sentences 1', 'Fill with the correct word', '{"text": "My ___ is Ann. I am 12 ___ old.", "blanks": [{"id": "blank1", "text": "name", "options": ["name", "age", "email", "address"], "correctAnswer": "name"}, {"id": "blank2", "text": "years", "options": ["years", "name", "email", "address"], "correctAnswer": "years"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 5, 'Complete the Sentences 2', 'Fill with the correct word', '{"text": "I live at this ___. This is my ___.", "blanks": [{"id": "blank1", "text": "address", "options": ["address", "phone", "email", "age"], "correctAnswer": "address"}, {"id": "blank2", "text": "email", "options": ["email", "phone", "address", "name"], "correctAnswer": "email"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_explanation', 6, 'Be + Personal Facts', 'Say basic facts', '{"rules": "Use be for name/age/from.\n- I am Ann. I am 12. I am from Bangkok.\nAsk: What is your name? Where are you from?", "examples": ["I am Ann.", "I am 12 years old.", "I am from Bangkok.", "What is your name?", "Where are you from?"]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 7, 'Build Sentences 1', 'Arrange words', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'I am Ann', 'I am Ann.', '["I", "am", "Ann."]'::jsonb),
    (activity_id_var, 'I am twelve years old', 'I am twelve years old.', '["I", "am", "twelve", "years", "old."]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 8, 'Build Sentences 2', 'Arrange words', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'I am from Bangkok', 'I am from Bangkok.', '["I", "am", "from", "Bangkok."]'::jsonb),
    (activity_id_var, 'Where are you from', 'Where are you from?', '["Where", "are", "you", "from?"]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'speaking_practice', 9, 'Share About You', 'Practice safe personal info', '{"prompts": ["What is your name?", "How old are you?", "Where are you from?", "Where do you live?", "What is your email?"]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (
      lesson_id,
      activity_type,
      activity_order,
      title,
      description,
      content
    ) VALUES (
      'A1-L71',
      'speaking_improvement',
      10,
      'Speaking Improvement',
      'Read the improved version of your speech',
      '{"type": "speaking_improvement", "similarityThreshold": 70}'::jsonb
    );
END $$;

