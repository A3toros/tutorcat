-- =========================================
-- Pre-fill Database with Sample Lesson Data
-- A1-L65: Cleaning and Tidying
-- =========================================

DELETE FROM grammar_sentences WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'A1-L65');
DELETE FROM vocabulary_items WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'A1-L65');
DELETE FROM lesson_activities WHERE lesson_id = 'A1-L65';
DELETE FROM lessons WHERE id = 'A1-L65';

INSERT INTO lessons (id, level, lesson_number, topic) VALUES
('A1-L65', 'A1', 65, 'Cleaning and Tidying')
ON CONFLICT (id) DO UPDATE SET topic = EXCLUDED.topic;

DO $$
DECLARE
    lesson_id_var TEXT := 'A1-L65';
    activity_id_var UUID;
BEGIN
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'warm_up_speaking', 1, 'Clean Up', 'Talk about cleaning', '{"prompt": "Do you clean your room?"}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_intro', 2, 'Cleaning Words', 'Learn cleaning words', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'clean', 'ทำความสะอาด', NULL),
    (activity_id_var, 'wash', 'ล้าง', NULL),
    (activity_id_var, 'sweep', 'กวาด', NULL),
    (activity_id_var, 'tidy', 'จัดให้เรียบร้อย', NULL),
    (activity_id_var, 'trash', 'ขยะ', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_matching_drag', 3, 'Match Cleaning Words', 'Match cleaning words', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'clean', 'ทำความสะอาด', NULL),
    (activity_id_var, 'wash', 'ล้าง', NULL),
    (activity_id_var, 'sweep', 'กวาด', NULL),
    (activity_id_var, 'tidy', 'จัดให้เรียบร้อย', NULL),
    (activity_id_var, 'trash', 'ขยะ', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 4, 'Complete the Sentences 1', 'Fill with the correct word', '{"text": "I ___ my room. I ___ the floor.", "blanks": [{"id": "blank1", "text": "clean", "options": ["clean", "wash", "sweep", "tidy"], "correctAnswer": "clean"}, {"id": "blank2", "text": "sweep", "options": ["sweep", "wash", "tidy", "clean"], "correctAnswer": "sweep"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 5, 'Complete the Sentences 2', 'Fill with the correct word', '{"text": "I ___ the dishes. I take out the ___.", "blanks": [{"id": "blank1", "text": "wash", "options": ["wash", "clean", "sweep", "tidy"], "correctAnswer": "wash"}, {"id": "blank2", "text": "trash", "options": ["trash", "floor", "room", "dish"], "correctAnswer": "trash"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_explanation', 6, 'Imperatives (home)', 'Give simple cleaning commands', '{"rules": "Use base verb for commands.\n- Clean the room. Wash the dishes. Sweep the floor.\nAdd please for polite tone.", "examples": ["Clean the room, please.", "Wash the dishes.", "Sweep the floor.", "Tidy the bed.", "Take out the trash."]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 7, 'Build Sentences 1', 'Arrange words', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'Clean the room please', 'Clean the room, please.', '["Clean", "the", "room,", "please."]'::jsonb),
    (activity_id_var, 'Wash the dishes', 'Wash the dishes.', '["Wash", "the", "dishes."]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 8, 'Build Sentences 2', 'Arrange words', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'Sweep the floor', 'Sweep the floor.', '["Sweep", "the", "floor."]'::jsonb),
    (activity_id_var, 'Take out the trash', 'Take out the trash.', '["Take", "out", "the", "trash."]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'speaking_practice', 9, 'Talk About Cleaning', 'Practice imperatives for home', '{"prompts": ["Do you clean your room?", "Do you wash dishes?", "Do you sweep the floor?", "Do you tidy the bed?", "Do you take out trash?"]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (
      lesson_id,
      activity_type,
      activity_order,
      title,
      description,
      content
    ) VALUES (
      'A1-L65',
      'speaking_improvement',
      10,
      'Speaking Improvement',
      'Read the improved version of your speech',
      '{"type": "speaking_improvement", "similarityThreshold": 70}'::jsonb
    );
END $$;

