-- =========================================
-- Pre-fill Database with Sample Lesson Data
-- A1-L37: Your Body
-- =========================================

DELETE FROM grammar_sentences WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'A1-L37');
DELETE FROM vocabulary_items WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'A1-L37');
DELETE FROM lesson_activities WHERE lesson_id = 'A1-L37';
DELETE FROM lessons WHERE id = 'A1-L37';

INSERT INTO lessons (id, level, lesson_number, topic) VALUES
('A1-L37', 'A1', 37, 'Your Body')
ON CONFLICT (id) DO UPDATE SET topic = EXCLUDED.topic;

DO $$
DECLARE
    lesson_id_var TEXT := 'A1-L37';
    activity_id_var UUID;
BEGIN
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'warm_up_speaking', 1, 'Body Parts', 'Talk about your body', '{"prompt": "How many eyes do you have?"}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_intro', 2, 'Body Words', 'Learn body words', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'head', 'ศีรษะ', NULL),
    (activity_id_var, 'hand', 'มือ', NULL),
    (activity_id_var, 'leg', 'ขา', NULL),
    (activity_id_var, 'eye', 'ตา', NULL),
    (activity_id_var, 'mouth', 'ปาก', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_matching_drag', 3, 'Match Body Words', 'Match body words', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'head', 'ศีรษะ', NULL),
    (activity_id_var, 'hand', 'มือ', NULL),
    (activity_id_var, 'leg', 'ขา', NULL),
    (activity_id_var, 'eye', 'ตา', NULL),
    (activity_id_var, 'mouth', 'ปาก', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 4, 'Complete the Sentences 1', 'Fill with the correct word', '{"text": "I have two ___. I have two ___.", "blanks": [{"id": "blank1", "text": "hands", "options": ["hands", "eyes", "legs", "mouth"], "correctAnswer": "hands"}, {"id": "blank2", "text": "legs", "options": ["legs", "eyes", "head", "mouth"], "correctAnswer": "legs"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 5, 'Complete the Sentences 2', 'Fill with the correct word', '{"text": "I have two ___. I have one ___.", "blanks": [{"id": "blank1", "text": "eyes", "options": ["eyes", "hands", "legs", "mouth"], "correctAnswer": "eyes"}, {"id": "blank2", "text": "mouth", "options": ["mouth", "head", "hand", "eye"], "correctAnswer": "mouth"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_explanation', 6, 'Have / Has Got', 'Talk about what you have', '{"rules": "Use have/has got to show possession.\n- I have two eyes.\n- She has a small hand.\nAsk: Do you have a big head?", "examples": ["I have two eyes.", "I have two hands.", "She has a small head.", "Do you have a big mouth?", "Do you have long legs?"]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 7, 'Build Sentences 1', 'Arrange words', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'I have two eyes', 'I have two eyes.', '["I", "have", "two", "eyes."]'::jsonb),
    (activity_id_var, 'She has a small head', 'She has a small head.', '["She", "has", "a", "small", "head."]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 8, 'Build Sentences 2', 'Arrange words', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'Do you have a big mouth', 'Do you have a big mouth?', '["Do", "you", "have", "a", "big", "mouth?"]'::jsonb),
    (activity_id_var, 'Do you have long legs', 'Do you have long legs?', '["Do", "you", "have", "long", "legs?"]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'speaking_practice', 9, 'Talk About Your Body', 'Practice have/has got', '{"prompts": ["How many eyes do you have?", "Do you have long legs?", "Do you have big hands?", "Do you have a small head?", "Do you have a big mouth?"]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (
      lesson_id,
      activity_type,
      activity_order,
      title,
      description,
      content
    ) VALUES (
      'A1-L37',
      'speaking_improvement',
      10,
      'Speaking Improvement',
      'Read the improved version of your speech',
      '{"type": "speaking_improvement", "similarityThreshold": 70}'::jsonb
    );
END $$;

