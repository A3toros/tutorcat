-- =========================================
-- Pre-fill Database with Sample Lesson Data
-- B2-L79: Media and emotions (questions)
-- =========================================

DELETE FROM grammar_sentences WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'B2-L79');
DELETE FROM vocabulary_items WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'B2-L79');
DELETE FROM lesson_activities WHERE lesson_id = 'B2-L79';
DELETE FROM lessons WHERE id = 'B2-L79';

INSERT INTO lessons (id, level, lesson_number, topic) VALUES
('B2-L79', 'B2', 79, 'Media and emotions (questions)')
ON CONFLICT (id) DO UPDATE SET topic = EXCLUDED.topic;

DO $$
DECLARE
    lesson_id_var TEXT := 'B2-L79';
    activity_id_var UUID;
BEGIN
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'warm_up_speaking', 1, 'Checking Feelings', 'Talk about asking/answering feelings', '{"prompt": "What did someone ask about how you felt, and what do you ask friends?"}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_intro', 2, 'Emotion Question Words', 'Key words for checking feelings', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'trigger', 'สิ่งกระตุ้น', NULL),
    (activity_id_var, 'detach', 'แยกตัว/เว้นระยะ', NULL),
    (activity_id_var, 'empathy', 'ความเข้าใจผู้อื่น', NULL),
    (activity_id_var, 'overwhelm', 'ความรู้สึกล้น', NULL),
    (activity_id_var, 'comfort', 'ความสบายใจ', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_matching_drag', 3, 'Match Emotion Question Words', 'Match words with meanings', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'trigger', 'สิ่งกระตุ้น', NULL),
    (activity_id_var, 'detach', 'แยกตัว/เว้นระยะ', NULL),
    (activity_id_var, 'empathy', 'ความเข้าใจผู้อื่น', NULL),
    (activity_id_var, 'overwhelm', 'ความรู้สึกล้น', NULL),
    (activity_id_var, 'comfort', 'ความสบายใจ', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 4, 'Complete the Sentences 1', 'Fill with the correct word', '{"text": "They asked what ___ me. I shared how I ___ when tired.", "blanks": [{"id": "blank1", "text": "triggered", "options": ["triggered", "detached", "overwhelmed", "comforted"], "correctAnswer": "triggered"}, {"id": "blank2", "text": "detach", "options": ["detach", "overwhelm", "comfort", "empathy"], "correctAnswer": "detach"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 5, 'Complete the Sentences 2', 'Fill with the correct word', '{"text": "A friend showed ___. A call gave me ___.", "blanks": [{"id": "blank1", "text": "empathy", "options": ["empathy", "comfort", "overwhelm", "detach"], "correctAnswer": "empathy"}, {"id": "blank2", "text": "comfort", "options": ["comfort", "empathy", "trigger", "detach"], "correctAnswer": "comfort"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_explanation', 6, 'Reported Speech (questions)', 'Report what people asked about feelings', '{"rules": "Use ask + wh- / if-whether; change to statement order, backshift if needed.\\n- \"How do you feel now?\" → They asked how I felt then.\\n- \"Did that overwhelm you?\" → She asked if that had overwhelmed me.", "examples": ["They asked how I felt after the news.", "She asked if the clip overwhelmed me.", "He asked what triggered my reaction.", "We asked whether you needed to detach.", "I asked how my friend found comfort."]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 7, 'Build Sentences 1', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'They asked how I felt after the news', 'They asked how I felt after the news.', '["They", "asked", "how", "I", "felt", "after", "the", "news."]'::jsonb),
    (activity_id_var, 'She asked if the clip overwhelmed me', 'She asked if the clip overwhelmed me.', '["She", "asked", "if", "the", "clip", "overwhelmed", "me."]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 8, 'Build Sentences 2', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'He asked what triggered my reaction', 'He asked what triggered my reaction.', '["He", "asked", "what", "triggered", "my", "reaction."]'::jsonb),
    (activity_id_var, 'We asked whether you needed to detach', 'We asked whether you needed to detach.', '["We", "asked", "whether", "you", "needed", "to", "detach."]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'speaking_practice', 9, 'Talk About Feeling Questions', 'Practice reporting questions', '{"prompts": ["What did someone ask about how you felt?", "What do you ask friends when they look overwhelmed?", "How do you ask for comfort without oversharing?"]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (
      lesson_id,
      activity_type,
      activity_order,
      title,
      description,
      content
    ) VALUES (
      'B2-L79',
      'speaking_improvement',
      10,
      'Speaking Improvement',
      'Read the improved version of your speech',
      '{"type": "speaking_improvement", "similarityThreshold": 70}'::jsonb
    );
END $$;


