-- =========================================
-- Pre-fill Database with Sample Lesson Data
-- B1-L4: Health & Lifestyle Choices
-- =========================================

-- Clear existing sample data for B1-L4 (optional - comment out if you want to keep existing data)
DELETE FROM grammar_sentences WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'B1-L4');
DELETE FROM vocabulary_items WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'B1-L4');
DELETE FROM lesson_activities WHERE lesson_id = 'B1-L4';
DELETE FROM lessons WHERE id = 'B1-L4';

INSERT INTO lessons (id, level, lesson_number, topic) VALUES
('B1-L4', 'B1', 4, 'Health & Lifestyle Choices')
ON CONFLICT (id) DO UPDATE SET topic = EXCLUDED.topic;

DO $$
DECLARE
    lesson_id_var TEXT := 'B1-L4';
    activity_id_var UUID;
BEGIN
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content) VALUES (lesson_id_var, 'warm_up_speaking', 1, 'Healthy Lifestyle', 'Talk about health', '{"prompt": "What do you do to stay healthy?"}'::jsonb) RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content) VALUES (lesson_id_var, 'vocabulary_intro', 2, 'Health Words', 'Learn health vocabulary', '{}'::jsonb) RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'exercise', 'การออกกำลังกาย', NULL),
    (activity_id_var, 'nutrition', 'โภชนาการ', NULL),
    (activity_id_var, 'wellness', 'สุขภาพดี', NULL),
    (activity_id_var, 'routine', 'กิจวัตร', NULL),
    (activity_id_var, 'balance', 'สมดุล', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content) VALUES (lesson_id_var, 'vocabulary_matching_drag', 3, 'Match Health Words', 'Match English words with Thai meanings', '{}'::jsonb) RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'exercise', 'การออกกำลังกาย', NULL),
    (activity_id_var, 'nutrition', 'โภชนาการ', NULL),
    (activity_id_var, 'wellness', 'สุขภาพดี', NULL),
    (activity_id_var, 'routine', 'กิจวัตร', NULL),
    (activity_id_var, 'balance', 'สมดุล', NULL);

    -- 4. Vocabulary Fill Blanks #1 (4 words: exercise, nutrition, wellness, routine - balance left out)
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content) VALUES (lesson_id_var, 'vocabulary_fill_blanks', 4, 'Complete the Sentences 1', 'Fill in the blanks with correct words', '{"text": "I do ___ every day. Good ___ is important. I focus on my ___. I have a healthy ___.", "blanks": [{"id": "blank1", "text": "exercise", "options": ["exercise", "nutrition", "wellness", "routine"], "correctAnswer": "exercise"}, {"id": "blank2", "text": "nutrition", "options": ["exercise", "nutrition", "wellness", "routine"], "correctAnswer": "nutrition"}, {"id": "blank3", "text": "wellness", "options": ["exercise", "nutrition", "wellness", "routine"], "correctAnswer": "wellness"}, {"id": "blank4", "text": "routine", "options": ["exercise", "nutrition", "wellness", "routine"], "correctAnswer": "routine"}]}'::jsonb) RETURNING id INTO activity_id_var;

    -- 4. Vocabulary Fill Blanks #2 (4 words: exercise, nutrition, wellness, balance - routine left out)
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content) VALUES (lesson_id_var, 'vocabulary_fill_blanks', 5, 'Complete the Sentences 2', 'Fill in the blanks with correct words', '{"text": "Regular ___ helps. Good ___ matters. I care about my ___. I need ___.", "blanks": [{"id": "blank1", "text": "exercise", "options": ["exercise", "nutrition", "wellness", "balance"], "correctAnswer": "exercise"}, {"id": "blank2", "text": "nutrition", "options": ["exercise", "nutrition", "wellness", "balance"], "correctAnswer": "nutrition"}, {"id": "blank3", "text": "wellness", "options": ["exercise", "nutrition", "wellness", "balance"], "correctAnswer": "wellness"}, {"id": "blank4", "text": "balance", "options": ["exercise", "nutrition", "wellness", "balance"], "correctAnswer": "balance"}]}'::jsonb) RETURNING id INTO activity_id_var;

    -- 4. Grammar Explanation (5 examples - CEFR B1: Present perfect, giving advice)
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content) VALUES (lesson_id_var, 'grammar_explanation', 6, 'Giving Advice - Should, Ought to', 'Learn to give health advice', '{"rules": "Use modal verbs to give advice:\n\n- You should + verb (You should exercise)\n- You ought to + verb (You ought to eat well)\n- You had better + verb (You had better rest)\n- I recommend + verb-ing (I recommend exercising)\n- It''s important to + verb (It''s important to sleep)", "examples": ["You should exercise regularly.", "You ought to eat more vegetables.", "I recommend getting enough sleep.", "It''s important to stay hydrated.", "You had better see a doctor."]}'::jsonb) RETURNING id INTO activity_id_var;

    -- 4. Grammar Sentences #1
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content) VALUES (lesson_id_var, 'grammar_sentences', 7, 'Build Sentences 1', 'Arrange words to make sentences', '{}'::jsonb) RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'You should exercise regularly', 'You should exercise regularly', '["You", "should", "exercise", "regularly"]'::jsonb),
    (activity_id_var, 'You ought to eat more vegetables', 'You ought to eat more vegetables', '["You", "ought", "to", "eat", "more", "vegetables"]'::jsonb);
    -- 4. Grammar Sentences #2
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content) VALUES (lesson_id_var, 'grammar_sentences', 8, 'Build Sentences 2', 'Arrange words to make sentences', '{}'::jsonb) RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'I recommend getting enough sleep', 'I recommend getting enough sleep', '["I", "recommend", "getting", "enough", "sleep"]'::jsonb),
    (activity_id_var, 'It is important to stay hydrated', 'It is important to stay hydrated', '["It", "is", "important", "to", "stay", "hydrated"]'::jsonb);
    -- 4. Speaking Practice (5 prompts - CEFR B1: Health and lifestyle)
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content) VALUES (lesson_id_var, 'speaking_practice', 9, 'Talk About Health', 'Practice talking about lifestyle', '{"prompts": ["What do you do to stay healthy?", "How important is exercise to you?", "What changes have you made to improve your health?", "What advice would you give someone about staying healthy?", "How do you balance work and wellness?"]}'::jsonb) RETURNING id INTO activity_id_var;

END $$;
INSERT INTO lesson_activities (
  lesson_id,
  activity_type,
  activity_order,
  title,
  description,
  content
) VALUES (
  'B1-L4',
  'speaking_improvement',
  10,
  'Speaking Improvement',
  'Read the improved version of your speech',
  '{"type": "speaking_improvement", "similarityThreshold": 70}'::jsonb
);