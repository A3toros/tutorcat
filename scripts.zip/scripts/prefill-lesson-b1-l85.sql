-- =========================================
-- Pre-fill Database with Sample Lesson Data
-- B1-L85: Remote Work Challenges
-- =========================================

DELETE FROM grammar_sentences WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'B1-L85');
DELETE FROM vocabulary_items WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'B1-L85');
DELETE FROM lesson_activities WHERE lesson_id = 'B1-L85';
DELETE FROM lessons WHERE id = 'B1-L85';

INSERT INTO lessons (id, level, lesson_number, topic) VALUES
('B1-L85', 'B1', 85, 'Remote Work Challenges')
ON CONFLICT (id) DO UPDATE SET topic = EXCLUDED.topic;

DO $$
DECLARE
    lesson_id_var TEXT := 'B1-L85';
    activity_id_var UUID;
BEGIN
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'warm_up_speaking', 1, 'Remote Difficulties', 'Talk about challenges working from home', '{"prompt": "What challenges have you faced working remotely?"}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_intro', 2, 'Challenge Words', 'Learn vocabulary about remote work challenges', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'isolate', 'แยกตัว', NULL),
    (activity_id_var, 'distract', 'รบกวนสมาธิ', NULL),
    (activity_id_var, 'coordinate', 'ประสานงาน', NULL),
    (activity_id_var, 'adapt', 'ปรับตัว', NULL),
    (activity_id_var, 'motivate', 'กระตุ้น/สร้างแรงจูงใจ', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_matching_drag', 3, 'Match Challenge Words', 'Match words with meanings', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'isolate', 'แยกตัว', NULL),
    (activity_id_var, 'distract', 'รบกวนสมาธิ', NULL),
    (activity_id_var, 'coordinate', 'ประสานงาน', NULL),
    (activity_id_var, 'adapt', 'ปรับตัว', NULL),
    (activity_id_var, 'motivate', 'กระตุ้น/สร้างแรงจูงใจ', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 4, 'Complete the Sentences 1', 'Fill with the correct word', '{"text": "Working alone can ___. Calls often ___. We must ___ across time zones.", "blanks": [{"id": "blank1", "text": "isolate", "options": ["isolate", "distract", "coordinate", "adapt"], "correctAnswer": "isolate"}, {"id": "blank2", "text": "distract", "options": ["distract", "coordinate", "motivate", "adapt"], "correctAnswer": "distract"}, {"id": "blank3", "text": "coordinate", "options": ["coordinate", "adapt", "isolate", "motivate"], "correctAnswer": "coordinate"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 5, 'Complete the Sentences 2', 'Fill with the correct word', '{"text": "I try to ___. Teams need to ___. Leaders should ___ the team.", "blanks": [{"id": "blank1", "text": "adapt", "options": ["adapt", "coordinate", "isolate", "distract"], "correctAnswer": "adapt"}, {"id": "blank2", "text": "adapt", "options": ["adapt", "motivate", "coordinate", "isolate"], "correctAnswer": "adapt"}, {"id": "blank3", "text": "motivate", "options": ["motivate", "adapt", "coordinate", "isolate"], "correctAnswer": "motivate"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    -- Grammar Explanation: Present Perfect (light review)
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_explanation', 6, 'Present Perfect for Remote Challenges', 'Use have/has + past participle for experiences up to now', '{"rules": "Present perfect for experiences and changes up to now.\\n- I have adapted to remote tools.\\n- We have coordinated across time zones.\\nAvoid exact past times.", "examples": ["I have adapted to a new remote schedule.", "We have coordinated across time zones for months.", "She has felt isolated working alone.", "They have struggled to stay motivated some weeks.", "He has reduced distractions at home."]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 7, 'Build Sentences 1', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'I have adapted to a new remote schedule', 'I have adapted to a new remote schedule', '["I", "have", "adapted", "to", "a", "new", "remote", "schedule"]'::jsonb),
    (activity_id_var, 'We have coordinated across time zones for months', 'We have coordinated across time zones for months', '["We", "have", "coordinated", "across", "time", "zones", "for", "months"]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 8, 'Build Sentences 2', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'She has felt isolated working alone', 'She has felt isolated working alone', '["She", "has", "felt", "isolated", "working", "alone"]'::jsonb),
    (activity_id_var, 'They have struggled to stay motivated some weeks', 'They have struggled to stay motivated some weeks', '["They", "have", "struggled", "to", "stay", "motivated", "some", "weeks"]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'speaking_practice', 9, 'Talk About Remote Challenges', 'Practice talking about remote work struggles', '{"prompts": ["What challenges have you faced working remotely?", "How have you adapted at home?", "What keeps you motivated when alone?"]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (
      lesson_id,
      activity_type,
      activity_order,
      title,
      description,
      content
    ) VALUES (
      'B1-L85',
      'speaking_improvement',
      10,
      'Speaking Improvement',
      'Read the improved version of your speech',
      '{"type": "speaking_improvement", "similarityThreshold": 70}'::jsonb
    );
END $$;

