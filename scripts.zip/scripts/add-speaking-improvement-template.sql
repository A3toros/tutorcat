-- =========================================
-- Template: Add speaking_improvement activity to a lesson
-- =========================================
-- Instructions:
-- 1. Replace 'LESSON_ID_HERE' with the actual lesson ID (e.g., 'A1-L1', 'A2-L2')
-- 2. Run this SQL
-- =========================================

-- Add the speaking_improvement activity (always at order 10)
-- Replace LESSON_ID_HERE with the actual lesson ID
INSERT INTO lesson_activities (
    lesson_id,
    activity_type,
    activity_order,
    title,
    description,
    content,
    active
) VALUES (
    'LESSON_ID_HERE',                    -- Replace with lesson ID (e.g., 'A1-L1')
    'speaking_improvement',
    10,                                  -- Always order 10
    'Speaking Improvement',
    'Read the improved version of your speech',
    '{"type": "speaking_improvement", "similarityThreshold": 70}'::jsonb,
    TRUE
)
ON CONFLICT (lesson_id, activity_order) DO UPDATE SET
    activity_type = EXCLUDED.activity_type,
    title = EXCLUDED.title,
    description = EXCLUDED.description,
    content = EXCLUDED.content,
    active = EXCLUDED.active;

-- =========================================
-- Example for A2-L1:
-- =========================================
/*
INSERT INTO lesson_activities (
    lesson_id,
    activity_type,
    activity_order,
    title,
    description,
    content,
    active
) VALUES (
    'A2-L1',
    'speaking_improvement',
    10,
    'Speaking Improvement',
    'Read the improved version of your speech',
    '{"type": "speaking_improvement", "similarityThreshold": 70}'::jsonb,
    TRUE
)
ON CONFLICT (lesson_id, activity_order) DO UPDATE SET
    activity_type = EXCLUDED.activity_type,
    title = EXCLUDED.title,
    description = EXCLUDED.description,
    content = EXCLUDED.content,
    active = EXCLUDED.active;
*/
