-- =========================================
-- Pre-fill Database with Sample Lesson Data
-- A1-L4: Food & Drinks
-- =========================================

-- Clear existing sample data for A1-L4 (optional - comment out if you want to keep existing data)
DELETE FROM lesson_activity_results WHERE lesson_id = 'A1-L4';
DELETE FROM user_progress WHERE lesson_id = 'A1-L4';
DELETE FROM lesson_history WHERE lesson_id = 'A1-L4';
DELETE FROM grammar_sentences WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'A1-L4');
DELETE FROM vocabulary_items WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'A1-L4');
DELETE FROM lesson_activities WHERE lesson_id = 'A1-L4';
DELETE FROM lessons WHERE id = 'A1-L4';

INSERT INTO lessons (id, level, lesson_number, topic) VALUES
('A1-L4', 'A1', 4, 'Food & Drinks')
ON CONFLICT (id) DO UPDATE SET topic = EXCLUDED.topic;

DO $$
DECLARE
    lesson_id_var TEXT := 'A1-L4';
    activity_id_var UUID;
BEGIN
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content) VALUES (lesson_id_var, 'warm_up_speaking', 1, 'Talk About Food', 'What food do you like?', '{"prompt": "What is your favorite food?"}'::jsonb) RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content) VALUES (lesson_id_var, 'vocabulary_intro', 2, 'Food Words', 'Learn food vocabulary', '{}'::jsonb) RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'rice', 'ข้าว', NULL),
    (activity_id_var, 'noodles', 'ก๋วยเตี๋ยว', NULL),
    (activity_id_var, 'chicken', 'ไก่', NULL),
    (activity_id_var, 'fish', 'ปลา', NULL),
    (activity_id_var, 'vegetables', 'ผัก', NULL);

    -- 3. Vocabulary Matching Drag #1 (5 pairs - same words)
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content) VALUES (lesson_id_var, 'vocabulary_matching_drag', 3, 'Match Food Words 1', 'Match English words with Thai meanings', '{}'::jsonb) RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'rice', 'ข้าว', NULL),
    (activity_id_var, 'noodles', 'ก๋วยเตี๋ยว', NULL),
    (activity_id_var, 'chicken', 'ไก่', NULL),
    (activity_id_var, 'fish', 'ปลา', NULL),
    (activity_id_var, 'vegetables', 'ผัก', NULL);

    

    -- 4. Vocabulary Fill Blanks #1 (4 words: rice, noodles, chicken, fish - vegetables left out)
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content) VALUES (lesson_id_var, 'vocabulary_fill_blanks', 4, 'Complete the Sentences 1', 'Fill in the blanks with correct words', '{"text": "I eat ___ with every meal. I cook ___ soup for lunch. My favorite food is ___. I also like to eat grilled ___.", "blanks": [{"id": "blank1", "text": "rice", "options": ["rice", "book", "car", "table"], "correctAnswer": "rice"}, {"id": "blank2", "text": "noodles", "options": ["noodles", "chair", "door", "window"], "correctAnswer": "noodles"}, {"id": "blank3", "text": "chicken", "options": ["chicken", "phone", "water", "tree"], "correctAnswer": "chicken"}, {"id": "blank4", "text": "fish", "options": ["fish", "pen", "paper", "desk"], "correctAnswer": "fish"}]}'::jsonb) RETURNING id INTO activity_id_var;

    -- 4. Vocabulary Fill Blanks #2 (4 words: rice, noodles, chicken, vegetables - fish left out)
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content) VALUES (lesson_id_var, 'vocabulary_fill_blanks', 5, 'Complete the Sentences 2', 'Fill in the blanks with correct words', '{"text": "I eat ___ with chicken. I cook ___ soup. I also have fried ___. I like to eat fresh ___.", "blanks": [{"id": "blank1", "text": "rice", "options": ["rice", "car", "book", "table"], "correctAnswer": "rice"}, {"id": "blank2", "text": "noodles", "options": ["noodles", "chair", "door", "window"], "correctAnswer": "noodles"}, {"id": "blank3", "text": "chicken", "options": ["chicken", "phone", "water", "tree"], "correctAnswer": "chicken"}, {"id": "blank4", "text": "vegetables", "options": ["vegetables", "pen", "paper", "desk"], "correctAnswer": "vegetables"}]}'::jsonb) RETURNING id INTO activity_id_var;

    -- 4. Grammar Explanation (5 examples)
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content) VALUES (lesson_id_var, 'grammar_explanation', 6, 'I like / I don''t like', 'Learn to express preferences', '{"rules": "Use ''I like'' for things you enjoy and ''I don''t like'' for things you don''t enjoy.\n\n- I like + noun (I like rice)\n- I don''t like + noun (I don''t like fish)\n- Do you like + noun? (Do you like chicken?)\n- He/She likes + noun (She likes vegetables)", "examples": ["I like rice.", "I don''t like fish.", "Do you like chicken?", "She likes vegetables.", "We don''t like spicy food."]}'::jsonb) RETURNING id INTO activity_id_var;

    -- 4. Grammar Sentences #1
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content) VALUES (lesson_id_var, 'grammar_sentences', 7, 'Build Sentences 1', 'Arrange words to make sentences', '{}'::jsonb) RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'I cook rice for my family', 'I cook rice for my family', '["I", "cook", "rice", "for", "my", "family"]'::jsonb),
    (activity_id_var, 'Do you like fish', 'Do you like fish?', '["Do", "you", "like", "fish?"]'::jsonb);
    -- 4. Grammar Sentences #2
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content) VALUES (lesson_id_var, 'grammar_sentences', 8, 'Build Sentences 2', 'Arrange words to make sentences', '{}'::jsonb) RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'She likes eating vegetables', 'She likes eating vegetables', '["She", "likes", "eating", "vegetables"]'::jsonb),
    (activity_id_var, 'I don t like spicy food', 'I don''t like spicy food', '["I", "don''t", "like", "spicy", "food"]'::jsonb);
    -- 4. Speaking Practice (5 prompts - CEFR A1)
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content) VALUES (lesson_id_var, 'speaking_practice', 9, 'Talk About Food Preferences', 'Practice talking about food', '{"prompts": ["What food do you like?", "What food don''t you like?", "What is your favorite dish?", "Do you like spicy food?", "What do you eat for breakfast?"]}'::jsonb) RETURNING id INTO activity_id_var;

END $$;
