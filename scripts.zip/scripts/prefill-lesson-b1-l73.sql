-- =========================================
-- Pre-fill Database with Sample Lesson Data
-- B1-L73: Studying Online vs Offline
-- =========================================

DELETE FROM grammar_sentences WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'B1-L73');
DELETE FROM vocabulary_items WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'B1-L73');
DELETE FROM lesson_activities WHERE lesson_id = 'B1-L73';
DELETE FROM lessons WHERE id = 'B1-L73';

INSERT INTO lessons (id, level, lesson_number, topic) VALUES
('B1-L73', 'B1', 73, 'Studying Online vs Offline')
ON CONFLICT (id) DO UPDATE SET topic = EXCLUDED.topic;

DO $$
DECLARE
    lesson_id_var TEXT := 'B1-L73';
    activity_id_var UUID;
BEGIN
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'warm_up_speaking', 1, 'Online or Offline', 'Talk about class formats', '{"prompt": "How will classes change for you?"}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_intro', 2, 'Study Words', 'Learn vocabulary about studying formats', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'lecture', 'การบรรยาย', NULL),
    (activity_id_var, 'interact', 'โต้ตอบ', NULL),
    (activity_id_var, 'focus', 'จดจ่อ', NULL),
    (activity_id_var, 'distract', 'รบกวนสมาธิ', NULL),
    (activity_id_var, 'resource', 'แหล่งข้อมูล', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_matching_drag', 3, 'Match Study Words', 'Match words with meanings', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'lecture', 'การบรรยาย', NULL),
    (activity_id_var, 'interact', 'โต้ตอบ', NULL),
    (activity_id_var, 'focus', 'จดจ่อ', NULL),
    (activity_id_var, 'distract', 'รบกวนสมาธิ', NULL),
    (activity_id_var, 'resource', 'แหล่งข้อมูล', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 4, 'Complete the Sentences 1', 'Fill with the correct word', '{"text": "The ___ is live. I can ___ with classmates. Phones can ___ me.", "blanks": [{"id": "blank1", "text": "lecture", "options": ["lecture", "interact", "focus", "distract"], "correctAnswer": "lecture"}, {"id": "blank2", "text": "interact", "options": ["interact", "distract", "focus", "resource"], "correctAnswer": "interact"}, {"id": "blank3", "text": "distract", "options": ["distract", "focus", "lecture", "resource"], "correctAnswer": "distract"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 5, 'Complete the Sentences 2', 'Fill with the correct word', '{"text": "I try to ___. Online classes need good ___. Offline study uses campus ___.", "blanks": [{"id": "blank1", "text": "focus", "options": ["focus", "interact", "distract", "resource"], "correctAnswer": "focus"}, {"id": "blank2", "text": "resources", "options": ["resources", "lectures", "interactions", "focus"], "correctAnswer": "resources"}, {"id": "blank3", "text": "resources", "options": ["resources", "focus", "lecture", "distract"], "correctAnswer": "resources"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    -- Grammar Explanation: Future (will vs going to) — study plans
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_explanation', 6, 'Future: Will vs Going To (Study Plans)', 'Use will for uncertain decisions; going to for planned actions', '{"rules": "Use will for uncertain or quick decisions. Use going to for planned changes.\\n- I will try offline classes next term.\\n- I am going to set rules to avoid distraction.\\nAvoid contractions.", "examples": ["I am going to set a study schedule this month.", "We will see if offline classes help more.", "She is going to limit phone use during lectures.", "They will decide after the first week.", "He is going to interact more in forums."]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 7, 'Build Sentences 1', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'I am going to set a study schedule this month', 'I am going to set a study schedule this month', '["I", "am", "going", "to", "set", "a", "study", "schedule", "this", "month"]'::jsonb),
    (activity_id_var, 'We will see if offline classes help more', 'We will see if offline classes help more', '["We", "will", "see", "if", "offline", "classes", "help", "more"]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 8, 'Build Sentences 2', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'She is going to limit phone use during lectures', 'She is going to limit phone use during lectures', '["She", "is", "going", "to", "limit", "phone", "use", "during", "lectures"]'::jsonb),
    (activity_id_var, 'They will decide after the first week', 'They will decide after the first week', '["They", "will", "decide", "after", "the", "first", "week"]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'speaking_practice', 9, 'Talk About Study Formats', 'Practice talking about online vs offline study', '{"prompts": ["How will classes change for you?", "What are you going to keep from online study?", "When do you insist on in-person learning?"]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (
      lesson_id,
      activity_type,
      activity_order,
      title,
      description,
      content
    ) VALUES (
      'B1-L73',
      'speaking_improvement',
      10,
      'Speaking Improvement',
      'Read the improved version of your speech',
      '{"type": "speaking_improvement", "similarityThreshold": 70}'::jsonb
    );
END $$;

