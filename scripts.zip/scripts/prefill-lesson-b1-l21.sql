-- =========================================
-- Pre-fill Database with Sample Lesson Data
-- B1-L21: Cultural Differences
-- =========================================

DELETE FROM grammar_sentences WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'B1-L21');
DELETE FROM vocabulary_items WHERE activity_id IN (SELECT id FROM lesson_activities WHERE lesson_id = 'B1-L21');
DELETE FROM lesson_activities WHERE lesson_id = 'B1-L21';
DELETE FROM lessons WHERE id = 'B1-L21';

INSERT INTO lessons (id, level, lesson_number, topic) VALUES
('B1-L21', 'B1', 21, 'Cultural Differences')
ON CONFLICT (id) DO UPDATE SET topic = EXCLUDED.topic;

DO $$
DECLARE
    lesson_id_var TEXT := 'B1-L21';
    activity_id_var UUID;
BEGIN
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'warm_up_speaking', 1, 'New Cultures', 'Talk about adapting to new cultures', '{"prompt": "How do you avoid awkward moments in a new culture?"}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_intro', 2, 'Culture Words', 'Learn vocabulary about cultural differences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'greet', 'ทักทาย', NULL),
    (activity_id_var, 'gesture', 'ท่าทาง', NULL),
    (activity_id_var, 'custom', 'ประเพณี', NULL),
    (activity_id_var, 'polite', 'สุภาพ', NULL),
    (activity_id_var, 'offend', 'ทำให้ขุ่นเคือง', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_matching_drag', 3, 'Match Culture Words', 'Match words with meanings', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO vocabulary_items (activity_id, english_word, thai_translation, audio_url) VALUES
    (activity_id_var, 'greet', 'ทักทาย', NULL),
    (activity_id_var, 'gesture', 'ท่าทาง', NULL),
    (activity_id_var, 'custom', 'ประเพณี', NULL),
    (activity_id_var, 'polite', 'สุภาพ', NULL),
    (activity_id_var, 'offend', 'ทำให้ขุ่นเคือง', NULL);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 4, 'Complete the Sentences 1', 'Fill with the correct word', '{"text": "People ___ in many ways. A small ___ can mean respect. Each ___ feels different.", "blanks": [{"id": "blank1", "text": "greet", "options": ["greet", "gesture", "custom", "polite"], "correctAnswer": "greet"}, {"id": "blank2", "text": "gesture", "options": ["gesture", "custom", "offend", "polite"], "correctAnswer": "gesture"}, {"id": "blank3", "text": "custom", "options": ["custom", "greet", "gesture", "offend"], "correctAnswer": "custom"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'vocabulary_fill_blanks', 5, 'Complete the Sentences 2', 'Fill with the correct word', '{"text": "Staying ___ helps. We avoid actions that ___ someone. Ask before you ___ in a new way.", "blanks": [{"id": "blank1", "text": "polite", "options": ["polite", "offend", "greet", "custom"], "correctAnswer": "polite"}, {"id": "blank2", "text": "offend", "options": ["offend", "gesture", "custom", "polite"], "correctAnswer": "offend"}, {"id": "blank3", "text": "greet", "options": ["greet", "polite", "offend", "custom"], "correctAnswer": "greet"}]}'::jsonb)
    RETURNING id INTO activity_id_var;

    -- Grammar Explanation: First Conditional
    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_explanation', 6, 'First Conditional for Cultural Situations', 'Use if + present, will + base verb to talk about likely results', '{"rules": "First conditional: If + present simple, will + base verb for likely results.\\n- If you greet with a smile, people will relax.\\n- If you ask, they will explain the custom.\\nNo contractions.", "examples": ["If you greet politely, people will welcome you.", "If you copy a local gesture, they will appreciate it.", "If you ask about a custom, they will explain it.", "If you stay calm, you will avoid offending others.", "If you learn basic phrases, you will feel more confident."]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 7, 'Build Sentences 1', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'If you greet politely people will welcome you', 'If you greet politely, people will welcome you', '["If", "you", "greet", "politely,", "people", "will", "welcome", "you"]'::jsonb),
    (activity_id_var, 'If you copy a local gesture they will appreciate it', 'If you copy a local gesture, they will appreciate it', '["If", "you", "copy", "a", "local", "gesture,", "they", "will", "appreciate", "it"]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'grammar_sentences', 8, 'Build Sentences 2', 'Arrange words to make sentences', '{}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO grammar_sentences (activity_id, original_sentence, correct_sentence, words_array) VALUES
    (activity_id_var, 'If you ask about a custom they will explain it', 'If you ask about a custom, they will explain it', '["If", "you", "ask", "about", "a", "custom,", "they", "will", "explain", "it"]'::jsonb),
    (activity_id_var, 'If you stay calm you will avoid offending others', 'If you stay calm, you will avoid offending others', '["If", "you", "stay", "calm,", "you", "will", "avoid", "offending", "others"]'::jsonb);

    INSERT INTO lesson_activities (lesson_id, activity_type, activity_order, title, description, content)
    VALUES (lesson_id_var, 'speaking_practice', 9, 'Talk About Cultural Differences', 'Practice talking about adapting to culture', '{"prompts": ["How do you avoid awkward moments in a new culture?", "What surprised you most when you traveled?", "When do you decide to adapt your behavior?"]}'::jsonb)
    RETURNING id INTO activity_id_var;

    INSERT INTO lesson_activities (
      lesson_id,
      activity_type,
      activity_order,
      title,
      description,
      content
    ) VALUES (
      'B1-L21',
      'speaking_improvement',
      10,
      'Speaking Improvement',
      'Read the improved version of your speech',
      '{"type": "speaking_improvement", "similarityThreshold": 70}'::jsonb
    );
END $$;

